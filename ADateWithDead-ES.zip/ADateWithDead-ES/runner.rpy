﻿init python:
    import pygame
    import random
    import time
    random.seed(time.perf_counter_ns())
    def distance(x, y):
        if x >= y:
            result = x - y
        else:
            result = y - x
        return result

    class runner_woman(renpy.Displayable):
        def __init__(self, image, parent):
            super(renpy.Displayable,self).__init__()
            self.image = image
            self.x = 710
            self.y = 0
            self.parent = parent
            self.counted = False
        def render(self,width,height,st,at):
            self.x -= self.parent.speed
            if self.x < -355:
                try:
                    self.parent.women.remove(self)
                except:
                    pass

            t = Transform(self.image, xanchor=0.5, yanchor=0.5, zoom = 8, nearest = True)
            child_render = renpy.render(t, width, height, st, at)
            cw, ch = child_render.get_size()

            rv = renpy.Render(cw, ch)
            rv.blit(child_render, (self.x,self.y))

            renpy.redraw(self, 0)

            return rv
    class runner_class(renpy.Displayable):
        def __init__(self, images, jump_image, women_list):
            super(renpy.Displayable,self).__init__()
            self.images = images
            self.jump_image = jump_image
            self.women_list = women_list
            self.women = []
            self.speed = 6
            self.score = 0
            self.x = 0
            self.y = 0
            self.y_velocity = 0
            self.image_index = 0
            self.caught = None
            self.stage = "intro"
            self.flip = 1
        def restart(self):
            self.women = []
            self.speed = 6
            self.score = 0
            self.x = 0
            self.y = 0
            self.y_velocity = 0
            self.image_index = 0
            self.caught = None
            self.stage = "running"
        def add(self, woman, x = 1000, counted = False):
            w = runner_woman(woman, self)
            w.x = x
            w.counted = counted
            self.women.append(w)

        def jump(self):
            # Salta con espacio (PC) o al tocar la pantalla (Android)
            if self.y == 0 and not self.caught:
                self.y_velocity = -20
                renpy.play("audio/sfx/jump.ogg", "sound")
        def run(self):
            self.image_index += 1
            if self.image_index > 3:
                self.image_index = 0
        def spawn(self):
            if len(self.women) < 10:
                woman = random.choice(self.women_list)
                for i in self.women:
                    if i.image == woman:
                        self.spawn()
                        break
                else:
                    self.women.append(runner_woman(woman, self))

        def render(self,width,height,st,at):
            if not self.caught:
                self.y += self.y_velocity
                if self.y < 0:
                    self.y_velocity += 1
                    img = self.jump_image
                else:
                    self.y_velocity = 0
                    img = self.images[self.image_index]
                for i in self.women:
                    if -60 < i.x < 60:
                        if self.y > -100:
                            self.caught = i
                            renpy.play("audio/sfx/lose.ogg", "sound")
                    if not i.counted:
                        if i.x < 0:
                            i.counted = True
                            self.score += 1
                            if not self.score%10:
                                self.speed += 1
                                renpy.play("audio/sfx/level up.ogg", "sound")

            else:
                self.speed = 0
                img = self.jump_image
            t = Transform(img, xanchor=0.5, yanchor=0.5, zoom = 8, nearest = True, xzoom = self.flip)
            child_render = renpy.render(t, width, height, st, at)
            cw, ch = child_render.get_size()

            rv = renpy.Render(cw, ch)
            rv.blit(child_render, (self.x,self.y))

            renpy.redraw(self, 0)

            return rv
init:
    image runner_idle:
        "images/runner/idle_0.png"
        pause 0.2
        "images/runner/idle_1.png"
        pause 0.2
        "images/runner/idle_2.png"
        pause 0.2
        "images/runner/idle_3.png"
        repeat


    image runner_jump = "images/runner/idle_0.png"
    image runner_run_1 = "images/runner/run_0.png"
    image runner_run_2 = "images/runner/run_1.png"
    image runner_run_3 = "images/runner/run_2.png"
    image runner_run_4 = "images/runner/run_3.png"

    image runner_woman_1 = Crop((0, 16, 16, 16), "images/runner/runner.png")
    image runner_woman_2 = Crop((16, 16, 16, 16), "images/runner/runner.png")
    image runner_woman_3 = Crop((32, 16, 16, 16), "images/runner/runner.png")
    image runner_woman_4 = Crop((48, 16, 16, 16), "images/runner/runner.png")

    image runner_woman_5 = Crop((0, 32, 16, 16), "images/runner/runner.png")
    image runner_woman_6 = Crop((16, 32, 16, 16), "images/runner/runner.png")
    image runner_woman_7 = Crop((32, 32, 16, 16), "images/runner/runner.png")
    image runner_woman_8 = Crop((48, 32, 16, 16), "images/runner/runner.png")

    image runner_woman_9 = Crop((0, 48, 16, 16), "images/runner/runner.png")
    image runner_woman_10 = Crop((16, 48, 16, 16), "images/runner/runner.png")
    image runner_woman_11 = Crop((32, 48, 16, 16), "images/runner/runner.png")
    image runner_woman_12 = Crop((48, 48, 16, 16), "images/runner/runner.png")

    image runner_woman_13 = Crop((0, 64, 16, 16), "images/runner/runner.png")
    image runner_woman_14 = Crop((16, 64, 16, 16), "images/runner/runner.png")
    image runner_woman_15 = Crop((32, 64, 16, 16), "images/runner/runner.png")
    image runner_woman_16 = Crop((48, 64, 16, 16), "images/runner/runner.png")

default runner_instance = runner_class(
    [
        "runner_run_1",
        "runner_run_2",
        "runner_run_3",
        "runner_run_4",
    ],
    "runner_idle",
    [
        "runner_woman_1",
        "runner_woman_2",
        "runner_woman_3",
        "runner_woman_4",
        "runner_woman_5",
        "runner_woman_6",
        "runner_woman_7",
        "runner_woman_8",
        "runner_woman_9",
        "runner_woman_10",
        "runner_woman_11",
        "runner_woman_12",
        "runner_woman_13",
        "runner_woman_14",
        "runner_woman_15",
        "runner_woman_16",
    ]
)

default runinstance = runner_instance
screen runner_screen(runinstance = runner_instance):
    modal True
    tag computer
    zorder 201
    use computer_screen
    add "gui/custom/computer/pong_base.png" at popup_transformtest
    text _("runner.exe") color "#000" align 0.33, 0.085 at popup_transformtest:
        if _preferences.language == "japanese":
            yoffset 5
    textbutton "x" action Hide("runner_screen", dissolve) align 0.865, 0.08  text_color "#000" text_hover_color "#3b36ff" at popup_transformtest
    hbox:
        viewport:
            area (560, 148, 1142, 725)
            add "pa_1" align 0.5, 0.5 at popup_transformtest
            add "pa_2" align 0.5, 0.5 at scrollbg1, popup_transformtest
            add "pa_3" align 0.5, 0.5 at scrollbg2, popup_transformtest
            add "pa_4" align 0.5, 0.5 at scrollbg3, popup_transformtest
            add "pa_5" align 0.5, 0.5 at scrollbg4, popup_transformtest

    # Tocar la ventana del juego = saltar (Android)
    button:
        area (560, 148, 1142, 725)
        background None
        action Function(runinstance.jump)

    key "K_SPACE" action Function(runinstance.jump)
    for i in runinstance.women:
        add i align .5,.5
    add runinstance align .5,.5 at logo_transform
    if runinstance.stage == "running":
        if not runinstance.caught:
            timer .1 repeat True action Function(runinstance.run)
            timer (random.random()*3)+1 repeat True action Function(runinstance.spawn)


        else:
            hbox:
                viewport:
                    area (560, 148, 1142, 725)
                    add "#000"

            vbox spacing 10:
                xalign 0.5
                yalign 0.5
                xanchor 0.5
                xpos 1130

                text _("Perdiste.") color "#fff" size 50 xalign 0.5
                textbutton _("Jugar de nuevo") action Function(runinstance.restart):
                    text_color "#fff"
                    text_hover_color "#3b36ff"
                    xalign 0.5
                textbutton _("Salir") action [Function(runinstance.restart), Hide("runner_screen", dissolve), Show("computer_screen")]:
                    text_color "#fff"
                    text_hover_color "#3b36ff"
                    xalign 0.5
        vbox:
            xalign 0.0
            yalign 0.78
            xanchor 0.0
            xpos 580
            text _(f"Esquivados: {runinstance.score}") at logo_transform
            text _(f"Velocidad: {runinstance.speed}") at logo_transform

    add "gui/custom/computer/games_hover.png" zoom 0.5 align 0.51, 0.961
    add "gui/custom/computer/active_app.png" align 0.513, 0.968


transform zoom(z, n = False):
    nearest n
    zoom z

transform zoom2(z):
    nearest True
    zoom z align (.5,.5)

transform scrollbg1:
    xalign 0.34
    linear 10.0 xalign 1.0
    repeat
transform scrollbg2:
    xalign 0.34
    linear 7.0 xalign 1.0
    repeat
transform scrollbg3:
    xalign 0.34
    linear 6.0 xalign 1.0
    repeat
transform scrollbg4:
    xalign 0.34
    linear 4.0 xalign 1.0
    repeat

image pa_1:
    "images/runner/1.png"
    zoom 2.0
image pa_2:
    "images/runner/2.png"
    zoom 2.0

image pa_3:
    "images/runner/3.png"
    zoom 2.0

image pa_4:
    "images/runner/4.png"
    zoom 2.0

image pa_5:
    "images/runner/5.png"
    zoom 2.0


# label runner_example:
#     $ runner_instance.flip = 1
#     $ runner_instance.stage = "running"
#     $ runner_instance.speed = 6
#     call screen runner_screen
