translate es strings:

    old "she"
    new "ella"

    old "her"
    new "ella"

    old "She"
    new "Ella"

    old "Her"
    new "Ella"
    
    old "he"
    new "él"

    old "him"
    new "él"

    old "He"
    new "Él"

    old "Him"
    new "Él"
    
    old "they"
    new "elle"

    old "them"
    new "elle"

    old "They"
    new "Elle"

    old "Them"
    new "Elle"
   
    old "female"
    new "a mujer"

    old "girl"
    new "a chica"

    old "Girl"
    new "a Chica"

    old "women"
    new "as mujeres"

    old "woman"
    new "a mujer"

    old "wife"
    new "esposa"
    
    old "male"
    new " hombre"

    old "guy"
    new " chico"

    old "Guy"
    new " Chico"

    old "men"
    new "os hombres"

    old "man"
    new " hombre"

    old "husband"
    new "esposo"

    old "person"
    new "a persona"

    old "Person"
    new "a Persona"

    old "people"
    new "as personas"

    old "partner"
    new "pareja"

    old "pretty"
    new "linda"

    old "beautiful"
    new "hermosa"

    old "cute"
    new "lindo"

    old "handsome"
    new "guapo"

    old "captivating"
    new "cautivante"

    old "divine"
    new "radiante"

