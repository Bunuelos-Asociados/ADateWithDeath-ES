translate es strings:

    old "Music"
    new "Música"

    old "Paint"
    new "Pintura"

    old "Chatroom"
    new "Chat"

    old "Gallery"
    new "Galería"

    old "Internet"
    new "Internet"

    old "Leave"
    new "Salir"

    old "Cloudy"
    new "Nublado"

    old "Sunny"
    new "Soleado"

    old "Past"
    new "Pasado"

    old "Present"
    new "Presente"

    old "Future"
    new "Futuro"

    old "minesweeper"
    new "Buscaminas"

    old "Yes."
    new "Sí."

    old "Ask again tomorrow."
    new "Pregunta de nuevo mañana."

    old "No."
    new "No."

    old "Did you really need a test for this?"
    new "¿De verdad necesitabas una prueba para esto?"

    old "Nope, your computer is on strike today. Just kidding, it's on, obviously."
    new "Nope, tu computadora está en huelga hoy. Es broma, obviamente está encendida."

    old "Try turning it on and off again."
    new "Intenta apagarla y encenderla de nuevo."

    old "Is a hot dog a sandwich? Irrelevant, but your computer is definitely on."
    new "¿Un hot dog es un sándwich? Irrelevante, pero tu computadora está encendida."

    old "On? Yes. Off? No."
    new "¿Encendida? Sí. ¿Apagada? No."

    old "If you're reading this, I hope you have a wonderful day. Also, yes."
    new "Si estás leyendo esto, espero que tengas un día maravilloso. Y sí, está encendida."

    old "I had a vision, and it's telling me 'yes'."
    new "Tuve una visión y me dice que 'sí'."

    old "Grim: Feeling a little catty today #KittyCat"
    new "Parca: ¿Te sientes un poco felino hoy? #Gatito"

    old "Grim: Whoops I seemed to drop something on the floor, \nthanks for picking it up for me!"
    new "Parca: Ups, parece que dejé caer algo al suelo,\n¡gracias por recogerlo por mí!"

    old "Grim: Oh noooo don't lift my shirt...!"
    new "Parca: Oh nooo, ¡no levantes mi camisa...!"

    old "Loading, please wait"
    new "Cargando, por favor espera"

    old "Taking longer than expected"
    new "Está tardando más de lo esperado"

    old "You're still here, huh?"
    new "¿Aún sigues aquí, eh?"

    old "Nothing better to do?"
    new "¿No tienes nada mejor que hacer?"

    old "I hope you don't think there's a reward for waiting"
    new "Espero que no creas que hay una recompensa por esperar"

    old "There's definitely not"
    new "Definitivamente no la hay"

    old "You already have the achievement!"
    new "¡Ya tienes el logro!"

    old "This will begin the chatroom. Proceed?"
    new "Esto iniciará la sala de chat. ¿Deseas continuar?"

    old "Yes"
    new "Sí"

    old "No"
    new "No"

    old "Music Player"
    new "Reproductor de música"

    old "Collected Images"
    new "Imágenes recopiladas"

    old "Games"
    new "Juegos"

    old "Wallpapers"
    new "Fondos"

    old "untitled.jpg - Draw"
    new "sin_título.jpg - Dibujar"

    old "Do you want to wipe the canvas?"
    new "¿Quieres borrar el lienzo?"


    old "Your past was filled with comfort and contentment."
    new "Tu pasado estuvo lleno de comodidad y satisfacción."

    old "Your past was filled with curiousity."
    new "Tu pasado estuvo lleno de curiosidad."

    old "Your past was filled with catnaps."
    new "Tu pasado estuvo lleno de siestas gatunas."

    old "Your past was filled with playfulness."
    new "Tu pasado estuvo lleno de juegos."

    old "Your past was filled with frustration, which you overcame."
    new "Tu pasado estuvo lleno de frustraciones, que lograste superar."

    old "In the past, you were always a clever kitten."
    new "En el pasado, siempre fuiste un gatito ingenioso."

    old "In the past, you were overcome with projects."
    new "En el pasado, estabas abrumado por proyectos."

    old "In the past, you bounced back from plenty of problems."
    new "En el pasado, te recuperaste de muchos problemas."

    old "In the past, you were always wildly perceptive."
    new "En el pasado, siempre fuiste increíblemente perceptivo."

    old "In the past, you loved competition."
    new "En el pasado, amabas la competencia."


    old "Right now, you're like a content cat, lounging in the sunbeam of life."
    new "Ahora mismo eres como un gato satisfecho, descansando en el rayo de sol de la vida."

    old "Your curiosity is at its peak, akin to a kitten chasing mysterious shadows."
    new "Tu curiosidad está en su punto más alto, como un gatito persiguiendo sombras misteriosas."

    old "Currently, you're in need of a catnap – a break from the hustle and bustle of life."
    new "Actualmente necesitas una siesta gatuna: un descanso del ajetreo de la vida."

    old "Your playfulness knows no bounds, much like a kitten chasing its tail."
    new "Tu espíritu juguetón no conoce límites, como un gatito persiguiendo su cola."

    old "Life's annoyances are like an itch, and you're ready to scratch them away."
    new "Las molestias de la vida son como una picazón, y estás listo para rascarlas."

    old "Your wit and resourcefulness shine bright, resembling a cat plotting its next mischief."
    new "Tu ingenio y astucia brillan, como un gato tramando su próxima travesura."

    old "You're entangled in life's exciting projects, like a kitten wrapped in a ball of yarn."
    new "Estás enredado en proyectos emocionantes de la vida, como un gatito envuelto en un ovillo de lana."

    old "You're currently being resilient against powers that work against you."
    new "Actualmente demuestras resiliencia frente a fuerzas que actúan contra ti."

    old "Your intuition is sharp, mirroring a cat's keen gaze in the dark."
    new "Tu intuición es aguda, como la mirada penetrante de un gato en la oscuridad."

    old "You're tackling life's challenges with the playfulness of a cat chasing a mouse."
    new "Enfrentas los retos de la vida con la picardía de un gato persiguiendo un ratón."


    old "In the future, you'll find the ultimate state of contentment, much like a cat in a cozy sunbeam."
    new "En el futuro alcanzarás el máximo estado de satisfacción, como un gato en un rayo de sol acogedor."

    old "Your curiosity will lead you on an adventure in the days to come."
    new "Tu curiosidad te llevará a una aventura en los días venideros."

    old "A peaceful catnap in your future indicates rest and rejuvenation."
    new "Una tranquila siesta gatuna en tu futuro indica descanso y renovación."

    old "Your playfulness will be your guiding star."
    new "Tu espíritu juguetón será tu estrella guía."

    old "In the future, you'll scratch away life's annoyances."
    new "En el futuro, rascarás las molestias de la vida."

    old "Your future holds moments of wit and resourcefulness, much like a cat plotting its next adventure."
    new "Tu futuro traerá momentos de ingenio y astucia, como un gato planeando su próxima aventura."

    old "In the days to come, you'll be entranced by life's colorful threads."
    new "En los días por venir, quedarás fascinado con los hilos coloridos de la vida."

    old "Resilience will be your hallmark in the future."
    new "La resiliencia será tu sello en el futuro."

    old "In the future, you will need to depend on your intuition to have a favorable outcome to your bet."
    new "En el futuro, deberás confiar en tu intuición para lograr un desenlace favorable en tu apuesta."

    old "Your future promises fun challenges, like a cat chasing a mouse."
    new "Tu futuro promete retos divertidos, como un gato persiguiendo un ratón."

