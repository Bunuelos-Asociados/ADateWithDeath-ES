translate es strings:

    old "Click to Begin"
    new "Haz clic para comenzar"

    old "You lose!"
    new "¡Perdiste!"

    old "Rules"
    new "Reglas"

    old "You have five turns to guess the five letter word."
    new "Tienes cinco intentos para adivinar la palabra de cinco letras."

    old "A correct letter turns green, a correct letter in the wrong place"
    new "Una letra correcta se vuelve verde, una letra correcta en el lugar equivocado"

    old "turns yellow, and an incorrect letter turns gray."
    new "se vuelve amarilla, y una letra incorrecta se vuelve gris."

    old "You win!"
    new "¡Ganaste!"

    old "The word was: [lingo_word]."
    new "La palabra era: [lingo_word]."

    old "You lose."
    new "Perdiste."

    old "Play again"
    new "Jugar de nuevo"

    old "Play Again"
    new "Jugar De Nuevo"

    old "runner.exe"
    new "runner.exe"

    old "Dodged: {runinstance.score}"
    new "Esquivados: {runinstance.score}"

    old "Speed: {runinstance.speed}"
    new "Velocidad: {runinstance.speed}"

    old "Lets start with a word we choose. This time \"lingo\""
    new "Empecemos con una palabra que elegimos. Esta vez \"lingo\"."

    old "Easy when you know the answer right?"
    new "Fácil cuando sabes la respuesta, ¿verdad?"

    old "Let's try with a random word from a list of 5757."
    new "Probemos con una palabra aleatoria de una lista de 5757."

    old "Impressive! guessed \"[word]\" in [tries] attempts."
    new "¡Impresionante! Adivinaste \"[word]\" en [tries] intentos."

    old "Guessed \"[word]\" in [tries] attempts. Not bad."
    new "Adivinaste \"[word]\" en [tries] intentos. Nada mal."

    old "Couldn't guess it? it was: \"[word]\"."
    new "¿No pudiste adivinarla? Era: \"[word]\"."

    old "Now let's enable resetting."
    new "Ahora vamos a activar la opción de reinicio."

    old "the word was \"[word]\""
    new "La palabra era \"[word]\"."