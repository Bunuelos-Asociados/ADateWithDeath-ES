translate es strings:

    old "COMPLETE"
    new "  LISTO "

    old "Wall Color"
    new "Color - Pared"

    old "Desk Decor"
    new "Escritorio"

    old "Bed Color"
    new "Color - Cama"

    old "Room Decor"
    new "Habitación"

    old "Polaroid Set"
    new "Set Fotos"

    old "Fairylights Set"
    new "Set de Luces de Hadas"

    old "Plant Lover Set"
    new "Set Amante de las Plantas"

    old "Posters Set"
    new "Set Pósters"

    old "Neat Set"
    new "Set Neat"
