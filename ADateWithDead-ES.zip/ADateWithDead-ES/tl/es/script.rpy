
# game/script.rpyc:530
translate es start_84a025ce:

    # center_text "You've been here before, haven't you?"
    center_text "Ya has estado aquí antes, ¿no es así?"

# game/script.rpyc:531
translate es start_a68fbade:

    # center_text "You've been that perfectly ordinary person, with a perfectly ordinary job and a perfectly ordinary apartment."
    center_text "Has sido esa persona perfectamente común, con un trabajo perfectamente común y un apartamento perfectamente común."

# game/script.rpyc:532
translate es start_b44a86b7:

    # center_text "You met someone who called himself the Grim Reaper, and you fell in love..."
    center_text "Conociste a alguien que se hacía llamar la Parca, y te enamoraste…"

# game/script.rpyc:533
translate es start_602e1841:

    # center_text "But is that the end of the story?"
    center_text "Pero, ¿ese es el final de la historia?"

# game/script.rpyc:534
translate es start_74b0946e:

    # center_text "To you, it feels like there's something... more left."
    center_text "Para ti, se siente como si quedara... algo más."

# game/script.rpyc:535
translate es start_63279fc0:

    # center_text "Begin at the start of the original game, or jump to the end of day 5 and begin Beyond the Bet?"
    center_text "¿Quieres comenzar desde el inicio del juego original, o saltar al final del día 5 y empezar Más allá de la apuesta?"

# game/script.rpyc:540
translate es start_8024c3a9:

    # center_text "You shake your head... you must just be misremembering a dream."
    center_text "Sacudes la cabeza... debes estar recordando mal un sueño."

# game/script.rpyc:560
translate es start_6577b4f9:

    # center_text "You've always been a perfectly ordinary person."
    center_text "Siempre has sido una persona perfectamente común."

# game/script.rpyc:563
translate es start_e89f2caf:

    # center_text "An ordinary person with an ordinary job and an ordinary apartment."
    center_text "Una persona común con un trabajo común y un apartamento común."

# game/script.rpyc:564
translate es start_07a8d23d:

    # center_text "That is, putting aside some of the strange occurrences that happen around you."
    center_text "Es decir, dejando de lado algunas de las extrañas ocurrencias que suceden a tu alrededor."

# game/script.rpyc:565
translate es start_05bc066c:

    # center_text "Who hasn't been involved in a train crash, a house fire, a hurricane and a parachute-related skydiving issue all in the span of a few months, after all?"
    center_text "Después de todo, ¿quién no ha estado involucrado en un accidente de tren, un incendio en casa, un huracán y un problema de paracaídas en paracaidismo, todo en el lapso de unos meses?"

# game/script.rpyc:566
translate es start_0b9bd1f2:

    # center_text "You've always been this way. You've found yourself in many unlucky situations, but come out unscathed every time."
    center_text "Siempre has sido así. Te has encontrado en muchas situaciones desafortunadas, pero siempre has salido ileso."

# game/script.rpyc:567
translate es start_792d7811:

    # center_text "Friends and family have always called you lucky—but at this point, you don't even bat an eyelash at these occurrences."
    center_text "Tus amigos y familiares siempre te han considerado como una persona afortunada, pero a estas alturas, ya ni siquiera parpadeas ante estas cosas."

# game/script.rpyc:568
translate es start_fae24f8c:

    # center_text "A piano falls from a six story building above you? You simply step to the side."
    center_text "¿Un piano cae desde un edificio de seis pisos justo encima de ti? Simplemente das un paso al costado."

# game/script.rpyc:569
translate es start_d52c867f:

    # center_text "You trip on your shoelace and fall down a flight of stairs? Not even a scratch."
    center_text "¿Tropiezas con tus agujetas y caes por unas escaleras? Ni un rasguño."

# game/script.rpyc:570
translate es start_bd1f1c14:

    # center_text "It's on one of these unusually ordinary days when you arrive home, and look into your mirror."
    center_text "Es en uno de esos días inusualmente ordinarios cuando llegas a casa y miras en tu espejo."

# game/script.rpyc:571
translate es start_b5b79c6c:

    # center_text "What do you see?"
    center_text "¿Qué ves?"

translate es strings:

    old "1. Start from the beginning"
    new "1. Empezar desde el principio"

    old "2. Jump to Beyond the Bet"
    new "2. Ir a Beyond the Bet (DLC)"

    old "Awaiting status..."
    new "Esperando estado..."

    old "Soul#8129"
    new "Alma#8129"

    old "Grim Reaper"
    new "La Parca"

    old "Testing, testing"
    new "Probando, probando"

    old "Direct Messages"
    new "Mensajes Directos"