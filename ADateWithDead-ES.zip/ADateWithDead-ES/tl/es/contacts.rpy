translate es strings:

    old "On an adventure!"
    new "¡De aventura!"

    old "Slug boy slug boy"
    new "Chico babosa"

    old "Spread your wings"
    new "Abre tus alas"

    old "Magic in stories"
    new "Magia en historias"

    old "Don't message me"
    new "No escribas"

    old "Follow me on MewTube!"
    new "Sígueme en MewTube"

    old "DNI"
    new "DNI"

    old "How fast is Sanic?"
    new "¿Qué tan rápido Sanic?"

    old "surviving off coffee"
    new "Café para sobrevivir"

    old "I like snacks"
    new "Me gustan snacks"

    old "Your local Insomniac"
    new "Tu insomne"

    old "State of being: tired"
    new "Estado: cansad@"

    old "gleep norp"
    new "gleep norp"

    old "yes, swooping is bad"
    new "sí, lanzarse es malo"

    old "that's how fish be"
    new "Así son los peces"

    old "To better skies~"
    new "Hacia cielos~"

    old "This too will pass!"
    new "¡Esto pasará!"

    old "don't bother me I stg"
    new "No me molestes"

    old "catboy yaoi"
    new "catboy yaoi"

    old "Being cremated is..."
    new "Ser cremado..."

    old "3am  I'm still awake"
    new "3 a.m., sigo despiert@"

    old "Was that the bite of 87?"
    new "¿La mordida del 87?"

    old "nap time :33"
    new "Siesta :33"

    old "Crocheting and Crying"
    new "Tejiendo y llorando"

    old "Burns bright as day"
    new "Arde como el día"

    old "A wolf in sheep's PJs"
    new "Lobo en pijama"

    old "Running into traffic"
    new "Huyendo al tráfico"

    old "playin rhythm games!"
    new "¡Ritmo games!"

    old "Hora mortis nostrae"
    new "Hora de muerte"

    old "Art-Fashion Princess"
    new "Princesa arte & moda"

    old "Grim Reaper's Daily"
    new "Diario de la Parca"

    old "Let's go get boba :D"
    new "Vamos por boba :D"

    old "Enjoying the night sky!"
    new "¡Cielo nocturno!"

    old "Fixated on you..."
    new "Fijad@ en ti..."

    old "calm"
    new "Calma"

    old "Reading some Manga"
    new "Leyendo manga"

    old "I am best boy, ofc"
    new "Soy el mejor, obvio"

    old "Phoenix Time"
    new "Hora fénix"

    old "silly prince @ ur service"
    new "Príncipe tonto a tu servicio"

    old "Stuck in gacha hell"
    new "Atrapad@ en gacha"

    old "Pondering the Void"
    new "Contemplando vacío"

    old "bunny plushies..."
    new "Peluches conejito..."

    old "Slaying Dragons brb"
    new "Matando dragones"

    old "Angerborking rn :3"
    new "Rabia ladrando :3"

    old "It’s not Tuesday"
    new "No es martes"

    old "BA in Yapology"
    new "Lic. en Yapología"

    old "Always flying!"
    new "¡Siempre volando!"

    old "The thing is..."
    new "La cosa es..."

    old "invested in 2D men"
    new "Obsesion con chicos 2D"

    old "Wandering the universe"
    new "Vagando por el universo"

    old "A smile suits a hero"
    new "Sonrisa de héroe"

    old "Wish it was raining..."
    new "Ojalá lloviera..."

    old "Made too many puns."
    new "Muchos juegos de palabras"

    old "Sparkle on, superstar"
    new "Brilla, estrella"

    old "god's court jester"
    new "Bufón de Dios"

    old "Wanna see the stars?"
    new "¿Ver las estrellas?"

    old "corbingling it atm"
    new "Corbingling ahora"

    old "Fullsend Gremlin 24/7"
    new "Gremlin full 24/7"

    old "be the chaos u want to c"
    new "Sé el caos que quieres"

    old "feelin kinda gae"
    new "Algo gei"

    old "Wanna be a Soda Can?"
    new "¿Ser una lata?"

    old "born to :3c forced to >:("
    new "Nací :3c obligado >:("

    old "Alt F5 to chat to me!"
    new "¡Alt F5 para chatear!"

    old "reading hot steamy bl"
    new "Leyendo BL caliente"

    old "The doctor is in."
    new "Doctor disponible"

    old "Always sleepy zzz~"
    new "Siempre dormid@ zzz~"

    old "At work, please DND"
    new "Trabajo, no molestar"

    old "I'm incredibly smart"
    new "Soy muy inteligente"

    old "Un-bee-lievable"
    new "In-a-bee-lievable"

    old "*sips tea*"
    new "*bebe té*"

    old "patty meltin'"
    new "patty derritiéndose"

    old "I'm at your service ♥"
    new "Estoy a tu servicio ♥"

    old "Horny 4 the Paranormy"
    new "Caliente por lo paranormal"

    old "Just one chance PLS"
    new "Una oportunidad, PORFA"

    old "Time Traveling..."
    new "Viajando en el tiempo..."

    old "always tired"
    new "siempre cansad@"

    old "chasing clouds"
    new "persiguiendo nubes"

    old "*Honking Draws Near*"
    new "*Se acerca un bocinazo*"

    old "Searchin 4 my hubbies"
    new "Buscando a mis esposos"


    old "the altar of the end"
    new "el altar del fin"

    old "Hot chips & Spaceships"
    new "Chips calientes & naves"

    old "Prez is best waifu"
    new "Prez es la mejor waifu"

    old "Tired 24/7"
    new "Cansad@ 24/7"

    old "anyone seen my pen?"
    new "¿Vieron mi bolígrafo?"

    old "Bearly hanging on"
    new "Bearly hanging on"   # (juego de palabras con "bear", puede quedar así)

    old "The Hound Yet Stays"
    new "El sabueso aún permanece"

    old "cubitum eamus?"
    new "cubitum eamus?"   # (latín: “¿nos vamos a acostar?”)

    old "drowning in the void"
    new "ahogándome en el vacío"

    old "Vibing w/ my bbygirls"
    new "Fluyendo con mis bbygirls"


    old "lesbian rights!"
    new "¡derechos lésbicos!"

    old "Paint w/ worlds colors"
    new "Pinta con colores del mundo"

    old "More Fish In The Sea"
    new "Más peces en el mar"

    old "\\(>o<)/ !!!"
    new "\\(>o<)/ !!!"   # se conserva como está (emoticono)

    old "cheesed to meet u?"
    new "cheesed to meet u?"   # (juego de palabras con “cheese”, puede dejarse como “un placer queso-conocerte”)

    old "KABOOM N' DOOM"
    new "¡KABOOM Y PERDICIÓN!"

    old "The Untamed Hero"
    new "El héroe indomable"

    old "Magic blue & burning"
    new "Magia azul y ardiente"

    old "teehee"
    new "jejeje"

    old "Catch me if you can ;)"
    new "Atrápame si puedes ;)"

    old "Leashed by an Elf"
    new "Atad@ por un elfo"

    old "Fanfic IS art MOM!!"
    new "¡¡El fanfic ES arte, MAMÁ!!"

    old "Watching PMMM again"
    new "Viendo PMMM otra vez"

    old "call this # now!!"
    new "¡llama a este número ya!"

    old "Hisssss ~>•)~~~~~^"
    new "Hisssss ~>•)~~~~~^"   # se conserva como onomatopeya

    old "Din-din when?"
    new "¿Cuándo es la cena?"

    old "Keep Romancing"
    new "Sigue enamorando"

    old "When’s summer break :("
    new "¿Cuándo son las vacaciones? :("

    old "Was it a cat I saw?"
    new "¿Era un gato lo que vi?"

    old "What's a babygirl?"
    new "¿Qué es una babygirl?"


    old "Playing Cyberpunk"
    new "Jugando Cyberpunk"

    old "Out causing chaos <3"
    new "Ando causando caos <3"

    old "I'm not here"
    new "No estoy aquí"

    old "Fiendish Delights"
    new "Delicias diabólicas"

    old "Triple-A-Collector~"
    new "Coleccionista Triple-A~"

    old "bbg grim will be mine"
    new "bbg Parca será mío"

    old "Off stargazing~"
    new "A mirar estrellas~"

    old "vampire enthusiast"
    new "Vampirofan"

    old "hungry and sleepy rip"
    new "Hambrient@ y dormid@"

    old "the spiralerrrrr"
    new "el espiralerrrrr"

    old "Joy & Whimsy"
    new "Alegría & fantasía"

    old "*quack*"
    new "*cuac*"

    old "witchy woo woo stuff"
    new "cosas brujiles woo woo"

    old "Waste time wisely"
    new "Pierde el tiempo sabiamente"

    old "Oops! Got your soul!"
    new "¡Ups! Me llevé tu alma!"

    old "weewoo"
    new "wiuu wiuu"   # (imitando sirena)

    old "In need of coffee."
    new "Necesito café."

    old "Collecting merch"
    new "Coleccionando merch"

    old "meow >:3c"
    new "miau >:3c"

    old "avoiding death"
    new "evitando la muerte"


    old "Busy being fabulous"
    new "Ocupad@ siendo fabulos@"

    old "The Answer is…Blep"
    new "La respuesta es... blep"

    old "Moon in the Morning"
    new "Luna en la mañana"

    old "In love with a dork"
    new "Enamoradq de un tont@"

    old "meowing in the closet"
    new "maullando en el armario"

    old "Youwillnotesacpeayaya"
    new "Nuncavasalirayay"   # (imitando el estilo caótico original)

    old "Artblock hurts"
    new "Bloqueo creativo"

    old "Tick, tock."
    new "Tic, tac."

    old "lil introvert here"
    new "pequeñ@ introvertid@ aquí"

    old "In search of a muse"
    new "En busca de una musa"

    old "It's WIMDY"
    new "It's WIMDY"   # (imitando la deformación cómica de “windy”)

    old "meow meow meow"
    new "miau miau miau"

    old "ribbit ribbit"
    new "croac croac"

    old "life is very... humerus!"
    new "life is very... humerus!"   # (manteniendo el juego de palabras con el hueso)

    old "w/ my BabyGirl"
    new "con mi BabyGirl"

    old "Writing for my life!"
    new "Escribiendo por mi vida"

    old "Rmbr to haunt locally!"
    new "Recuerda espantar localmente!"

    old "goober moment!!!"
    new "momento bobo!!!"

    old "drawing EstiArk"
    new "dibujando EstiArk"

    old "your calico cat <3"
    new "tu gatito carey <3"

    old "Wait. Where am I?!"
    new "Espera. ¿Dónde estoy?!"

    old "I guess u can have it"
    new "Puedes quedártelo"

    old "how do I log off?"
    new "¿cómo cierro sesión?"

    old "out rn, slow replies"
    new "afuera, respondo lento"

    old "Being in love? Yikes!"
    new "¿Estar enamorado? ¡Uf!"

    old "have u seen this dog? "
    new "¿has visto este perro?"

    old "Too gay to function"
    new "Muy gay para funcionar"

    old "Galileo was here"
    new "Galileo estuvo aquí"

    old "toggle moon powers"
    new "activar poderes lunares"

    old "insane men liker"
    new "fan de hombres locos"

    old "lying in a flower bed"
    new "recostad@ en un jardín"

    old "today sure is a day"
    new "hoy sin duda es un día"

    old "taste grass it's nice"
    new "prueba el pasto, está rico"

    old "Bows, arrows, n bunnies"
    new "Arcos, flechas y conejitos"

    old "Me,kill people?Never."
    new "¿Yo, matar gente? Jamás."

    old "Drawing and crying"
    new "Dibujando y llorando"

    old "Fangirl w/ me @ twitter"
    new "Fangirl conmigo @ twitter"

    old "What do you want now"
    new "¿Qué quieres ahora?"

    old "Let's go peacefully"
    new "Vámonos en paz"


    old "Keep smiling, love!"
    new "¡Sigue sonriendo, amor!"

    old "Claimed a fictional man"
    new "Reclamé un hombre ficticio"

    old "yummy zooplankton"
    new "zooplancton delicioso"

    old "*crying emoji*"
    new "*emoji llorando*"

    old "bouncing off walls"
    new "rebotando paredes"

    old "Local Lurker Lurking"
    new "Local Lurker Lurking"

    old "Where's my lucky girl!"
    new "¡mi chica de la suerte!"

    old "rl is overrated :3"
    new "rl está sobrevalorada :3"

    old "Making Ai robots cry"
    new "Haciendo llorar a las IA"

    old "Écoute. Ressent. Pense."
    new "Escucha. Siente. Piensa."

    old "I'm tired of this Grandpa"
    new "Estoy cansad@ de esto, abuelo"

    old "Trying to art, help..."
    new "Intentando arte, ayuda..."

    old "You're like Poison"
    new "Eres como veneno"

    old "Y'kno, like, nya?"
    new "Ya sabes, como, nya?"

    old "Stuck in gacha hell."
    new "El infierno del gacha."

    old "Lurking in the void :}"
    new "Acechando en el vacío :}"

    old "Be not afraid..."
    new "No tengas miedo..."

    old "very normal + sane"
    new "muy normal + cuerd@"

    old "simping hrs >3<"
    new "hora de simpear >3<"

    old "streaming now <3"
    new "transmitiendo ahora <3"



    old "Everyday is boba day!"
    new "¡Todos son día de boba!"

    old "BRB. Pulling waifus."
    new "Vuelvo. Sacando waifus."

    old "UwU"
    new "UwU"

    old "No rest for the wicked!"
    new "¡No hay descanso!"

    old "Much work, few naps."
    new "Trabajo, pocas siestas."

    old "there goes the beans"
    new "ahí van los frijoles"

    old "crying+petting my cat"
    new "llorando+acariciando gato"

    old "have you heard of t..."
    new "¿has oído hablar de t..."

    old "the soul babies miss u"
    new "los bebés alma te extrañan"

    old "Azrael's #1 Fan"
    new "Fan #1 de Azrael"

    old "love our skrunkle! <3"
    new "¡amo a nuestro skrunkle! <3"

    old "Forever burning bright~"
    new "Ardiendo por siempre~"

    old "Aight keep ur secrets"
    new "Está bien, guarda secretos"

    old "Very sleepy dragon"
    new "Dragón muy somnoliento"

    old "Delulu is the solulu"
    new "Delulu es la solulu"

    old "pro weird person"
    new "persona prof. rara"

    old "Happy Noises"
    new "Ruiditos felices"

    old "Trying my best <3"
    new "Mi mejor esfuerzo <3"

    old "sell my soul for cake"
    new "vendo mi alma por pastel"

    old "*Bonk, Bonk, Bonk*"
    new "*Bonk, Bonk, Bonk*"


    old "Allé marcher pou"
    new "Allé marcher pou"   # parece incompleto o en otro idioma, lo dejamos igual

    old "restless days..."
    new "días inquietos..."

    old "You will be booped"
    new "Vas a ser boopead@"

    old "Finding a way forward"
    new "Encontrando un camino"

    old "you can't heal stupid"
    new "no se curara la estupidez"

    old "hungry for soba"
    new "con hambre de soba"

    old "When flowers bloom"
    new "Cuando florecen las flores"

    old "best stupid takes"
    new "comentarios tontos"

    old "Opps ;)"
    new "Ups ;)"

    old "Flower you today?"
    new "¿Flores para ti hoy?"

    old "no u, cutie"
    new "no, tú, lind@"

    old "Casperamel latte???"
    new "¿Latte de casperamel???"

    old "Having a blast gaming"
    new "Pasándola genial jugando"

    old "nap time nap time!"
    new "¡hora de la siesta!"

    old "Hello Lovelies~"
    new "Hola, hermos@s~"

    old "Hold me at midnight"
    new "Abrázame a medianoche"

    old "Bring your Lactaid!"
    new "¡Trae tu Lactaid!"

    old "Really just a duck..."
    new "Realmente solo un pato..."

    old "I <3 pathetic men"
    new "Yo <3 hombres patéticos"

    old "And a little sparkle!"
    new "¡Y un poco de brillo!"

    old "Forever eepy :3"
    new "Siempre duermo :3"

    old "no thought head empty"
    new "sin pensamientos, vacío"

    old "my babygirl Casper"
    new "mi babygirl Casper"

    old "A+? More like A Mess-"
    new "¿A+? Más bien un desastre-"

    old "weeping, sobbing"
    new "llorando, sollozando"

    old "Gaming anyone?"
    new "¿Alguien pa jugar?"

    old "keep me in your heart"
    new "guárdame en tu corazón"

    old "knife to meat you"
    new "knife to meat you"  # juego de palabras meat/meet

    old "Feelin moo-dy"
    new "Feelin moo-dy"  # juego de palabras con "moo"

    old "Active?"
    new "¿Activ@?"

    old "Unnecessary feelings"
    new "Sentimientos innecesarios"

    old "Sunshine? How ironic"
    new "¿Solecito? Qué irónico"

    old "Erm? What the scallop"
    new "¿Eh? Qué caracoles"

    old "always napping"
    new "siempre durmiendo"

    old "Free hugs for 1$"
    new "Abrazos gratis 1$"

    old "in my hamster ball"
    new "en mi bola de hámster"

    old "Reach for the stars"
    new "Alcanza las estrellas"

    old "ballin' vs bawlin'"
    new "triunfando vs llorando"

    old "always sleepy~"
    new "siempre con sueño~"

    old "I'm a healer but..."
    new "Soy sanador@ pero..."

    old "WitchWandersForest"
    new "BrujaVagandoPorElBosque"

    old "— available 24/7."
    new "— disponible 24/7."

    old "Drifting among stars"
    new "Flotando entre estrellas"

    old "Excited for tonight"
    new "Emocionad@ por esta noche"

    old "committing tax fraud"
    new "cometiendo fraude fiscal"

    old "doin all a mothboy can"
    new "haciendo lo k mothboy puede"

    old "hi!! (manipulatively)"
    new "¡hola! (manipuladoramente)"

    old "A dream is a freedom"
    new "Un sueño es una libertad"

    old "Be my complicated"
    new "Sé mi complicación"

    old "U wish I was dead tired"
    new "muert@ de cansancio"

    old "Chillin'"
    new "Relajad@"

    old "Spread paw-sitivity"
    new "Spread paw-sitivity"

    old "reading bedtime fics~"
    new "leyendo fics para dormir~"

    old "Otome brainrot *_*"
    new "Obsesión por otome *_*"

    old "Waiting for Grim"
    new "Esperando a la Parca"

    old "be gay do crime"
    new "sé gay haz crímenes"

    old "Laying in the flowers"
    new "Acostad@ entre las flores"

    old "Queen of Chaos"
    new "Reina del caos"

    old "AFK"
    new "AFK"

    old "Can I fall in love?"
    new "¿Puedo enamorarme?"


    old "You cannot hide Grim!"
    new "¡No puedes huir, Parca!"

    old "60hrs in a vn is fine"
    new "60 horas en una VN está bien"

    old "Take your time."
    new "Tómate tu tiempo."

    old "Time to court death."
    new "Cortejar a la muerte."

    old "always tired, never of u"
    new "siempre cansad@, nunca de ti"

    old "Tartagalicious hehe:D"
    new "Tartagalicioso jeje :D"

    old "Let's meet again, YJH"
    new "Volvamos a vernos, YJH"

    old "Eternally Sleepy"
    new "Eternamente con sueño"

    old "Just kinda here"
    new "Solo estoy por aquí"

    old "Prob doodlin a bbg"
    new "Prob dibujando a una bbg"

    old "LocalSunflowerNearU"
    new "Girasol local cerca de ti"

    old "Hi there, gorgeous!"
    new "¡Hola, guap@!"

    old "Grim can snap my-"
    new "Parca rompe mi-"

    old "Do you want donuts?"
    new "¿Quieres donas?"

    old "Chillin with the cats"
    new "Relajad@ con los gatos"

    old "Don't talk."
    new "No hables."

    old "Getting burned hurts"
    new "Quemarse duele"

    old "we ride at DAWN !!!"
    new "¡cabalgamos al AMANECER!"

    old "Here for now"
    new "Aquí por ahora"

    old "Wassup Gamers"
    new "Qué pasa, gamers"

    old "honk :o)"
    new "claxon :o)"

    old "can’t rain all the time"
    new "no puede llover todo el tiempo"

    old "to be man, to be beast"
    new "ser hombre, ser bestia"

    old "Father of 2 soulbabies"
    new "Padre de 2 bebés alma"

    old "Ectoplasmic Goo"
    new "Baba ectoplásmica"


    old "Too late! Nom nom"
    new "¡Tarde! Ñam ñam"

    old "Collecting anime men"
    new "Colec. chicos anime"

    old "Meow meow meow"
    new "Miau miau miau"

    old "Confusion"
    new "Confusión"

    old "Salt is angry sugar"
    new "La sal es azúcar enojada"

    old "birthday party"
    new "fiesta de cumple"

    old "But first, coffee. "
    new "Pero primero, café."

    old "*shlorp*"
    new "*sorbo raro*"

    old "Born from ashes"
    new "Nacid@ de las cenizas"

    old "Casper own my heart<3"
    new "Casper es dueño de mi <3"

    old "99 pigalloons oink by"
    new "99 cerdito-globos oink"

    old "I don't roll on Shabbos"
    new "No juego en Shabat"

    old "watching KPXI47"
    new "viendo KPXI47"

    old "No Regerts Just Vibes"
    new "Sin remordimientos, vibras"

    old "Out Foraging"
    new "De recolección"

    old "thank you gacha gods!"
    new "¡gracias, dios del gacha!"

    old "Good morning :3"
    new "Buenos días :3"

    old "I miss skeletal wings"
    new "Mis alas esqueléticas"

    old "Blood and cuddles pls"
    new "Sangre y mimos, porfa"

    old "Always making things!"
    new "¡Siempre creando cosas!"

    old "my royal council <3"
    new "mi consejo real <3"

    old "bah"
    new "bah"

    old ":3"
    new ":3"

    old "Magically back to bed"
    new "Mágicamente a la cama"


    old "Long Live The Queen~"
    new "Larga vida a la reina~"

    old "Nitimur In Vetitum"
    new "Anhelamos lo prohibido"

    old "'In Death, Sacrifice'"
    new "'En la muerte, sacrificio'"

    old "Darlin, what if you fly?"
    new "Cariño, ¿y si vuelas?"

    old "To simp or not to simp"
    new "¿Hacer simping o no?"

    old "i love jazz <3 :) 251"
    new "amo el jazz <3 :) 251"

    old "Rot In Heaven..."
    new "Púdrete en el cielo..."

    old "RatKing.exe not found"
    new "RatKing.exe no encontrado"

    old "Probably Singing <3"
    new "Probablemente cantando <3"

    old "Haunting in real time"
    new "Acechando en tiempo real"

    old "*Aggressive Crying*"
    new "*Llanto agresivo*"

    old "Grim, wanna chill?"
    new "Parca, ¿relajate?"

    old "eepy"
    new "mimiendo"

    old "O Death, come near me"
    new "O Muerte, acércate a mí"

    old "Teasing the bbygirl"
    new "Molestando a bbygirl"

    old "Eating your snacks :3"
    new "Comiendo tus snacks :3"

    old "I know what u r O_O"
    new "Sé lo que eres O_O"

    old "Follow 4 babygirl art"
    new "Sigueme, arte babygirl"

    old "Dragons in your area."
    new "Dragones en tu zona."

    old "Not 3 frogs in a coat"
    new "No son 3 ranas en abrigo"

    old "Frogs are cool :3"
    new "Las ranas molan :3"

    old "I bet on losing dogs"
    new "Por los perros perdedores"

    old "Never a dull moment!"
    new "¡Nunca un momento aburrido!"

    old "forgot, not forgotten."
    new "olvidado, no desaparecido."

    old "Nothing is impossible?"
    new "¿Nada es imposible?"

    old "1v1 me in minesweeper"
    new "1v1 en buscaminas"

    old "Overworked, overslept"
    new "Explotado y trasnochado"

    old "whimsical cringe fish"
    new "pez cursi y caprichoso"

    old "Brkn gems still shine"
    new "Gemas rotas aún brillan"

    old "A newbie Grim Reaper"
    new "Una Parca novato"


    old "Headpats and gaming"
    new "Mimitos y videojuegos"

    old "drawing in a corner..."
    new "dibujando en una esquina..."

    old "Slaying a Dragon"
    new "Matando a un dragón"

    old "Illusion master"
    new "Maestr@ de ilusiones"

    old "Straight up jorkin it"
    new "Dándole duro sin más"

    old "too smol to shatter"
    new "mi chiqui para romperse"

    old "have you eaten yet?"
    new "¿ya has comido?"

    old "Basking in the sun"
    new "Tomando el sol"

    old "Sleepy n confused..."
    new "Somnolient@ y confundid@..."

    old "I want cookies ;_;"
    new "Quiero galletas ;_;"

    old "Certified Simp <3"
    new "Simp certificado <3"

    old "Crit+++ Eng---"
    new "Crít+++ Ing---"

    old "Busy ghosting ur mom."
    new "Haciendo ghosting a tu mamá."

    old "Fictional men? PLZ!"
    new "¿Hombres ficticios? ¡PLZ!"

    old "Just Clownin' Around"
    new "Solo payaseando"

    old "Brainstorming..."
    new "Lluvia de ideas..."

    old "This is Mitchi"
    new "Soy Mitchi"

    old "Per aspera ad astra"
    new "Per aspera ad astra"

    old "reading orv <3"
    new "leyendo ORV <3"

    old "Pls be kind to urself"
    new "Porfa sé amable contigo"

    old "Stick around with me"
    new "Quédate conmigo"

    old "Soul babies are real!"
    new "¡Los bebés alma son reales!"

    old "Writing stories"
    new "Escribiendo historias"

    old "here for a fun day"
    new "aquí para un día divertido"

    old "your local herbo"
    new "tu herbo local"

    old "A sentimental rose."
    new "Una rosa sentimental."

    old "Tank stance pls"
    new "Postura de tanque pls"

    old "Wow"
    new "Wow"

    old "Ahh I love my Grimmy"
    new "Ahh, amo a mi Parquita"

    old "f4t4l system error"
    new "error de sistema f4t4l"

    old "A god looking for love"
    new "Un dios buscando amor"

    old "Life’s Kicking Me"
    new "La vida me patea"

    old "Struggle Gaming -_-"
    new "Juegos de sufrimiento -_-"

    old "will cry at any point"
    new "puedo llorar en cualquier momento"

    old "Run to Rootbeer"
    new "Corre hacia la Rootbeer"

    old "How did i get here?"
    new "¿Cómo llegué aquí?"

    old "Social battery low"
    new "Batería social baja"

    old "this one for u babe"
    new "esta es para ti, cariño"

    old "cuties never die <3"
    new "lind@s nunca mueren <3"

    old "Times ticking"
    new "El tiempo corre"

    old "Vaim on valmis..."
    new "Vaim está listo..."

    old "I want to be a raccoon"
    new "Quiero ser un mapache"

    old "peach mango pie"
    new "pastel de durazno y mango"

    old "Max Leveled in Nappin"
    new "Nivel máximo en siestas"

    old "currently preoccupied"
    new "actualmente ocupad@"

    old "Making jewellery, DND"
    new "Haciendo joyería, DnD"

    old "Playing FFXIV"
    new "Jugando FFXIV"

    old "Trying...just trying "
    new "Intentando... intentando"

    old "Local Wildcard (Busy)"
    new "Comodín local (Ocupad@)"

    old "Hakuna Matiddies..."
    new "Hakuna Matetas..."

    old "Alex x Casper 4eva"
    new "Alex x Casper x siempre"

    old "Live fast pet dogs"
    new "Vive, acaricia perros"

    old "I <3 whimpering men"
    new "Yo <3 hombres que gimen"

    old "arting til i EXPLODE"
    new "dibujando hasta EXPLOTAR"

    old "*silently cries*"
    new "*llora en silencio*"

    old "Playing: Groundrim"
    new "Jugando: Groundrim"

    old "Goodnight asshole"
    new "Buenas noches, idiota"

    old "darlin' can i be ur fave"
    new "cariño, ¿puedo ser tu fav?"

    old "Cover me in lamps"
    new "Cúbreme de lámparas"


    old "gloosh skoosh"
    new "glush skush"

    old "No thoughts, only bbg"
    new "Sin pensamientos, solo bbg"

    old "drawing..."
    new "dibujando..."

    old "bites you cutely <3"
    new "te muerde tiernamente <3"

    old "...boo?"
    new "...¿buuu?"

    old "my dogs are so cute!"
    new "¡mis perros son lindos!"

    old "honks my clown nose"
    new "toca mi nariz de payaso"

    old "Cactus died :^("
    new "El cactus murió :^("

    old "Swiming around ~"
    new "Nadando por ahí ~"

    old "berry milk overdose"
    new "sobredosis leche de mora"

    old "I’m a clown, I frown"
    new "Soy un payaso, pucheros"

    old "hunting giant spiders"
    new "cazando arañas gigantes"

    old "certified cisn’t"
    new "certificado cisn’t"

    old "Eat, Sleep, BOYFRIEND"
    new "Comer, Dormir, NOVIO"

    old "My wallet...."
    new "Mi billetera...."

    old "May your heart race"
    new "Tu corazón se acelere"

    old "babygirl connoisseur"
    new "conocedor de babygirls"

    old "Playing TDS"
    new "Jugando TDS"

    old "Love U Boo <3"
    new "Te amo, Boo <3"

    old "Cat & dreams r my life"
    new "Los gatos son mi vida"

    old "Stealing your boba"
    new "Robando tu boba"

    old "Blaze your own path!"
    new "¡Forja tu propio camino!"

    old "Will bite for money!"
    new "Muerdo por dinero!"

    old "definitely not vibing rn"
    new "definitivamente no fluyendo rn"

    old "DNA: Do Not Anger"
    new "ADN: No Enfadar"

    old "Just a lovely being"
    new "Solo un ser encantador"

    old "Are you happy?"
    new "¿Eres feliz?"

    old "born of emotions"
    new "nacido de emociones"

    old "Hauntthedigitalrealm"
    new "Acecha el reino digital"

    old "Very eepy"
    new "Muy mimido"


    old "Coffee break"
    new "Pausa para café"

    old "#birdcord #win"
    new "#birdcord #victoria"

    old "Out Cleaving"
    new "Partiendo por ahí"

    old "Dimension hopping :3"
    new "Saltando dimensiones :3"

    old "I know what you are!"
    new "¡Sé lo que eres!"

    old "In my unknowable era"
    new "En mi era incognoscible"

    old "Lil ol' gremlin"
    new "Pequeño gremlin"

    old "I put the me in men"
    new "Puse el 'yo' en 'hombres'"

    old "Be free! Be free!"
    new "¡Sé libre! ¡Sé libre!"

    old "It's Crowshi's fault"
    new "Es culpa de Crowshi"

    old "what do u need darl?"
    new "¿qué necesitas, cariño?"

    old "It's time to drink water!"
    new "¡Es hora de beber agua!"

    old "Your Sweetest Escape"
    new "Tu escape más dulce"

    old "Bager King"
    new "Rey tejón"

    old "why do you hate me"
    new "¿por qué me odias?"

    old "Meet Me Halfway, Love"
    new "Encuéntrame a medio camino, amor"

    old "Ahazu's little star"
    new "La pequeña estrella de Ahazu"

    old "stealin' ur shit teehee"
    new "robando tus cosas jeje"

    old "killing ur faves sorry"
    new "matando a tus favs, :("