
# game/chapters/badend_roomexplore.rpyc:215
translate es bed_hubbadend_72d9e0e5:

    # "You're feeling a little... sluggish today."
    "Estás sintiéndote con un poco... de lentitud hoy."

# game/chapters/badend_roomexplore.rpyc:216
translate es bed_hubbadend_65dcf9e3:

    # "Even sitting on the edge of your bed, you can't be bothered even thinking of standing to do anything else."
    "Incluso estando en el borde de tu cama, no tienes ánimos ni siquiera de pensar en levantarte para hacer algo más."

# game/chapters/badend_roomexplore.rpyc:217
translate es bed_hubbadend_89161ccd:

    # "Strange."
    "Extraño."

# game/chapters/badend_roomexplore.rpyc:223
translate es door_hubbadend_3d403dd1:

    # "The hallway beyond is silent."
    "El pasillo más allá está en silencio."

# game/chapters/badend_roomexplore.rpyc:224
translate es door_hubbadend_a043409e:

    # "You wonder what's happened with your neighbors, but you're too tired to really care..."
    "Te preguntas qué habrá pasado con tus vecinos, pero sientes demasiado cansancio como para preocuparte realmente..."

# game/chapters/badend_roomexplore.rpyc:237
translate es snake_hubbadend_688f43ae:

    # "[pet_name] has seemed a little down all day."
    "[pet_name] ha estado un poco triste todo el día."

# game/chapters/badend_roomexplore.rpyc:238
translate es snake_hubbadend_a1404f7e:

    # "You've been worrying that [pet_she] is getting sick again, so you've been wishing as hard as you can."
    "Sientes preocupación porque [pet_she!t] se esta enfermando otra vez, así que has estado deseando con todas tus fuerzas."

# game/chapters/badend_roomexplore.rpyc:239
translate es snake_hubbadend_f25bd1bc:

    # "But, despite what Casper said about your so-called 'abilities', nothing has changed."
    "Pero, a pesar de lo que dijo Casper sobre tus supuestas 'habilidades', nada ha cambiado."

# game/chapters/badend_roomexplore.rpyc:245
translate es snake_hubbadend_19531c55:

    # "You concentrate, then concentrate some more..."
    "Te concentras, y luego te concentras un poco más..."

# game/chapters/badend_roomexplore.rpyc:246
translate es snake_hubbadend_0b0d98ea:

    # "But you don't notice any changes."
    "Pero no notas ningún cambio."

# game/chapters/badend_roomexplore.rpyc:247
translate es snake_hubbadend_5adf06fd:

    # "Maybe you just need to keep trying?"
    "¿Quizás solo necesites seguir intentándolo?"

# game/chapters/badend_roomexplore.rpyc:251
translate es snake_hubbadend_fe24f979:

    # "You decide to leave [pet_name] alone for now."
    "Decides dejar a [pet_name] en paz por ahora."

# game/chapters/badend_roomexplore.rpyc:265
translate es bingus_hubbadend_688f43ae:

    # "[pet_name] has seemed a little down all day."
    "[pet_name] ha estado un poco triste todo el día."

# game/chapters/badend_roomexplore.rpyc:266
translate es bingus_hubbadend_a1404f7e:

    # "You've been worrying that [pet_she] is getting sick again, so you've been wishing as hard as you can."
    "Sientes preocupación porque [pet_she!t] se esta enfermando otra vez, así que has estado deseando con todas tus fuerzas."

# game/chapters/badend_roomexplore.rpyc:267
translate es bingus_hubbadend_f25bd1bc:

    # "But, despite what Casper said about your so-called 'abilities', nothing has changed."
    "Pero, a pesar de lo que dijo Casper sobre tus supuestas 'habilidades', nada ha cambiado."

# game/chapters/badend_roomexplore.rpyc:273
translate es bingus_hubbadend_19531c55:

    # "You concentrate, then concentrate some more..."
    "Te concentras, y luego te concentras un poco más..."

# game/chapters/badend_roomexplore.rpyc:274
translate es bingus_hubbadend_0b0d98ea:

    # "But you don't notice any changes."
    "Pero no notas ningún cambio."

# game/chapters/badend_roomexplore.rpyc:275
translate es bingus_hubbadend_5adf06fd:

    # "Maybe you just need to keep trying?"
    "¿Quizás solo necesites seguir intentándolo?"

# game/chapters/badend_roomexplore.rpyc:279
translate es bingus_hubbadend_fe24f979:

    # "You decide to leave [pet_name] alone for now."
    "Decides dejar a [pet_name] en paz por ahora."

# game/chapters/badend_roomexplore.rpyc:293
translate es bunny_hubbadend_688f43ae:

    # "[pet_name] has seemed a little down all day."
    "[pet_name] ha estado un poco triste todo el día."

# game/chapters/badend_roomexplore.rpyc:294
translate es bunny_hubbadend_a1404f7e:

    # "You've been worrying that [pet_she] is getting sick again, so you've been wishing as hard as you can."
    "Sientes preocupación porque [pet_she!t] se esta enfermando otra vez, así que has estado deseando con todas tus fuerzas."

# game/chapters/badend_roomexplore.rpyc:295
translate es bunny_hubbadend_f25bd1bc:

    # "But, despite what Casper said about your so-called 'abilities', nothing has changed."
    "Pero, a pesar de lo que dijo Casper sobre tus supuestas 'habilidades', nada ha cambiado."

# game/chapters/badend_roomexplore.rpyc:301
translate es bunny_hubbadend_19531c55:

    # "You concentrate, then concentrate some more..."
    "Te concentras, y luego te concentras un poco más..."

# game/chapters/badend_roomexplore.rpyc:302
translate es bunny_hubbadend_0b0d98ea:

    # "But you don't notice any changes."
    "Pero no notas ningún cambio."

# game/chapters/badend_roomexplore.rpyc:303
translate es bunny_hubbadend_5adf06fd:

    # "Maybe you just need to keep trying?"
    "¿Quizás solo necesites seguir intentándolo?"

# game/chapters/badend_roomexplore.rpyc:307
translate es bunny_hubbadend_fe24f979:

    # "You decide to leave [pet_name] alone for now."
    "Decides dejar a [pet_name] en paz por ahora."

# game/chapters/badend_roomexplore.rpyc:321
translate es cat_hubbadend_688f43ae:

    # "[pet_name] has seemed a little down all day."
    "[pet_name] ha estado un poco triste todo el día."

# game/chapters/badend_roomexplore.rpyc:322
translate es cat_hubbadend_a1404f7e:

    # "You've been worrying that [pet_she] is getting sick again, so you've been wishing as hard as you can."
    "Sientes preocupación porque [pet_she!t] se esta enfermando otra vez, así que has estado deseando con todas tus fuerzas."

# game/chapters/badend_roomexplore.rpyc:323
translate es cat_hubbadend_f25bd1bc:

    # "But, despite what Casper said about your so-called 'abilities', nothing has changed."
    "Pero, a pesar de lo que dijo Casper sobre tus supuestas 'habilidades', nada ha cambiado."

# game/chapters/badend_roomexplore.rpyc:329
translate es cat_hubbadend_19531c55:

    # "You concentrate, then concentrate some more..."
    "Te concentras, y luego te concentras un poco más..."

# game/chapters/badend_roomexplore.rpyc:330
translate es cat_hubbadend_0b0d98ea:

    # "But you don't notice any changes."
    "Pero no notas ningún cambio."

# game/chapters/badend_roomexplore.rpyc:331
translate es cat_hubbadend_5adf06fd:

    # "Maybe you just need to keep trying?"
    "¿Quizás solo necesites seguir intentándolo?"

# game/chapters/badend_roomexplore.rpyc:335
translate es cat_hubbadend_fe24f979:

    # "You decide to leave [pet_name] alone for now."
    "Decides dejar a [pet_name] en paz por ahora."

# game/chapters/badend_roomexplore.rpyc:349
translate es dog_hubbadend_688f43ae:

    # "[pet_name] has seemed a little down all day."
    "[pet_name] ha estado un poco triste todo el día."

# game/chapters/badend_roomexplore.rpyc:350
translate es dog_hubbadend_a1404f7e:

    # "You've been worrying that [pet_she] is getting sick again, so you've been wishing as hard as you can."
    "Sientes preocupación porque [pet_she!t] se esta enfermando otra vez, así que has estado deseando con todas tus fuerzas."

# game/chapters/badend_roomexplore.rpyc:351
translate es dog_hubbadend_f25bd1bc:

    # "But, despite what Casper said about your so-called 'abilities', nothing has changed."
    "Pero, a pesar de lo que dijo Casper sobre tus supuestas 'habilidades', nada ha cambiado."

# game/chapters/badend_roomexplore.rpyc:357
translate es dog_hubbadend_19531c55:

    # "You concentrate, then concentrate some more..."
    "Te concentras, y luego te concentras un poco más..."

# game/chapters/badend_roomexplore.rpyc:358
translate es dog_hubbadend_0b0d98ea:

    # "But you don't notice any changes."
    "Pero no notas ningún cambio."

# game/chapters/badend_roomexplore.rpyc:359
translate es dog_hubbadend_5adf06fd:

    # "Maybe you just need to keep trying?"
    "¿Quizás solo necesites seguir intentándolo?"

# game/chapters/badend_roomexplore.rpyc:363
translate es dog_hubbadend_fe24f979:

    # "You decide to leave [pet_name] alone for now."
    "Decides dejar a [pet_name] en paz por ahora."

# game/chapters/badend_roomexplore.rpyc:377
translate es hamster_hubbadend_688f43ae:

    # "[pet_name] has seemed a little down all day."
    "[pet_name] ha estado un poco triste todo el día."

# game/chapters/badend_roomexplore.rpyc:378
translate es hamster_hubbadend_a1404f7e:

    # "You've been worrying that [pet_she] is getting sick again, so you've been wishing as hard as you can."
    "Sientes preocupación porque [pet_she!t] se esta enfermando otra vez, así que has estado deseando con todas tus fuerzas."

# game/chapters/badend_roomexplore.rpyc:379
translate es hamster_hubbadend_f25bd1bc:

    # "But, despite what Casper said about your so-called 'abilities', nothing has changed."
    "Pero, a pesar de lo que dijo Casper sobre tus supuestas 'habilidades', nada ha cambiado."

# game/chapters/badend_roomexplore.rpyc:385
translate es hamster_hubbadend_19531c55:

    # "You concentrate, then concentrate some more..."
    "Te concentras, y luego te concentras un poco más..."

# game/chapters/badend_roomexplore.rpyc:386
translate es hamster_hubbadend_0b0d98ea:

    # "But you don't notice any changes."
    "Pero no notas ningún cambio."

# game/chapters/badend_roomexplore.rpyc:387
translate es hamster_hubbadend_5adf06fd:

    # "Maybe you just need to keep trying?"
    "¿Quizás solo necesites seguir intentándolo?"

# game/chapters/badend_roomexplore.rpyc:391
translate es hamster_hubbadend_fe24f979:

    # "You decide to leave [pet_name] alone for now."
    "Decides dejar a [pet_name] en paz por ahora."

# game/chapters/badend_roomexplore.rpyc:399
translate es plant_hubbadend_0e3d137f:

    # "You go to water your plant, but..."
    "Vas a regar tu planta, pero..."

# game/chapters/badend_roomexplore.rpyc:404
translate es plant_hubbadend_26e21a33:

    # "It's... shrunk?"
    "¿Se ha... encogido?"

# game/chapters/badend_roomexplore.rpyc:405
translate es plant_hubbadend_a3cd780e:

    # "It's withered up into barely a sprout, and is completely dry to boot."
    "Se ha marchitado hasta quedar apenas como un brote, y además está completamente seca."

# game/chapters/badend_roomexplore.rpyc:406
translate es plant_hubbadend_2b58e62e:

    # "How strange and disappointing."
    "Qué extraño y decepcionante."

translate es strings:

    old "1. Try to heal [pet_name] again."
    new "1. Intentar sanar a [pet_name] otra vez."

    old "2. Leave [pet_name] to rest."
    new "2. Dejar que [pet_name] descanse."

    old "{i}You flip to the end of your favorite childhood book. Resting against the page is a quote that's stuck with you.{/i}"
    new "{i}Pasas a la última página de tu libro favorito de la infancia. Sobre la hoja descansa una cita que siempre has recordado.{/i}"
