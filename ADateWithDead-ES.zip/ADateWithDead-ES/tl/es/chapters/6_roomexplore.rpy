
# game/chapters/6_roomexplore.rpyc:216
translate es bed_hub6_c0bdcd4c:

    # "Sitting on your bed, you have a perfect view of a certain bouquet of yellow flowers that was given to you yesterday."
    "Cuando te sientas en la cama, tienes una vista perfecta de un ramo de flores amarillas que te regalaron ayer."

# game/chapters/6_roomexplore.rpyc:217
translate es bed_hub6_967b6279:

    # "Given to you by... the Grim Reaper, of all people."
    "Te las regaló... nada menos que la Parca."

# game/chapters/6_roomexplore.rpyc:218
translate es bed_hub6_f4ae7946:

    # "The thought makes you somewhat giddy. Who could have guessed that strange talking weirdo could be such a romantic?"
    "La idea te hace sentir un ligero mareo. ¿Quién hubiera imaginado que ese bicho raro que dice tonterías pudiera ser tan romántico?"

# game/chapters/6_roomexplore.rpyc:219
translate es bed_hub6_7e3e2e90:

    # "Though you've never received flowers before, you have given them to someone else..."
    "Aunque nunca antes te habían regalado flores, tú sí se las has regalado a otra persona..."

# game/chapters/6_roomexplore.rpyc:235
translate es bed_hub6_03572a02:

    # "You have always thought of flowers as a special thing. A simple thing, but still special."
    "Siempre has considerado las flores como algo especial. Algo sencillo, pero especial al fin y al cabo."

# game/chapters/6_roomexplore.rpyc:236
translate es bed_hub6_a62d2724:

    # "And you felt very special when you looked at the flowers Casper brought you yesterday."
    "Y te sintiste muy especial cuando viste las flores que Casper te trajo ayer."

# game/chapters/6_roomexplore.rpyc:247
translate es door_hub6_bbd8e42a:

    # "You hear footsteps from the hallway. You wonder if it's your neighbors again?"
    "Oyes pasos en el pasillo. ¿Te preguntas si serán tus vecinos otra vez?"

# game/chapters/6_roomexplore.rpyc:253
translate es door_hub6_52eb8252:

    # "You hear a sniffling coming from the hallway, then the sound of someone sliding down to the floor."
    "Oyes un sollozo procedente del pasillo, seguido del sonido de alguien deslizándose hasta el suelo."

# game/chapters/6_roomexplore.rpyc:254
translate es door_hub6_06af4f93:

    # "You imagine someone is currently leaning against the doorway of their apartment."
    "Imaginas que alguien está apoyado contra la puerta de su apartamento."

# game/chapters/6_roomexplore.rpyc:255
translate es door_hub6_4db76323:

    # "You hear a fumbling - the sound of someone digging through their bag, searching for something."
    "Oyes un ruido - como si alguien estuviera rebuscando en su bolso, buscando algo."

# game/chapters/6_roomexplore.rpyc:256
translate es door_hub6_07880855:

    # "Then a sigh."
    "Luego, un suspiro."

# game/chapters/6_roomexplore.rpyc:257
translate es door_hub6_0b700eb9:

    # "A ringing. The sound of someone who desperately seeks another."
    "Un timbre. El sonido de alguien que busca desesperadamente a otra persona."

# game/chapters/6_roomexplore.rpyc:258
translate es door_hub6_571aa237:

    # "And then, finally, a voice."
    "Y entonces, por fin, una voz."

# game/chapters/6_roomexplore.rpyc:259
translate es door_hub6_0b1481c8:

    # "'Mom, are you there? Can you talk right now?' a light and airy voice starts."
    "'Mamá, ¿estás ahí? ¿Puedes hablar ahora?', comienza una voz ligera y melodiosa."

# game/chapters/6_roomexplore.rpyc:260
translate es door_hub6_8f07a59a:

    # "'No, I'm fine. No, I wasn't crying...'"
    "'No, estoy bien. No, no estaba llorando...'"

# game/chapters/6_roomexplore.rpyc:261
translate es door_hub6_e2c7a5cb:

    # "'I just wanted to talk for a bit. If that's okay.'"
    "'Solo quería hablar un rato. Si no te importa."

# game/chapters/6_roomexplore.rpyc:262
translate es door_hub6_b4994b24:

    # "Another sniffle."
    "Otro sollozo."

# game/chapters/6_roomexplore.rpyc:263
translate es door_hub6_326dfbb2:

    # "'Nothing happened, really. I'm just confused. And I lost my keys, but I'll worry about that in a minute...'"
    "'No ha pasado nada, de verdad. Solo es confusión. Y he perdido las llaves, pero ya me preocuparé de eso dentro de un momento...'"

# game/chapters/6_roomexplore.rpyc:264
translate es door_hub6_dc28c832:

    # "There's silence for a minute. You imagine their mother is currently fretting, trying to console their child despite not knowing what's wrong."
    "Hay un minuto de silencio. Imaginas a su madre preocupada, tratando de consolar a su hijo sin saber qué le pasa."

# game/chapters/6_roomexplore.rpyc:265
translate es door_hub6_be23173c:

    # "'Have you ever liked someone so much that it's made you terrified?'"
    "'¿Alguna vez te ha gustado alguien tanto que te ha dado miedo?'"

# game/chapters/6_roomexplore.rpyc:266
translate es door_hub6_a813b3cf:

    # "'I really like them, mom. I've only known them for like a week, but I feel like it's been so much longer...'"
    "'Me gusta mucho, mamá. Solo le conozco desde hace una semana, pero siento como si fuera mucho más tiempo...'"

# game/chapters/6_roomexplore.rpyc:267
translate es door_hub6_0b49988a:

    # "'And I'm scared.'"
    "'Y tengo miedo.'"

# game/chapters/6_roomexplore.rpyc:268
translate es door_hub6_4beb1ab3:

    # "There's vulnerability in that voice. Immense vulnerability."
    "Hay vulnerabilidad en esa voz. Una vulnerabilidad inmensa."

# game/chapters/6_roomexplore.rpyc:269
translate es door_hub6_480ae9e4:

    # "Their voice is like a plea to something they cannot see."
    "Su voz es como una súplica a algo que no puede ver."

# game/chapters/6_roomexplore.rpyc:270
translate es door_hub6_94ecefc1:

    # "Like a wish upon a star."
    "Como un deseo pedido a una estrella."

# game/chapters/6_roomexplore.rpyc:271
translate es door_hub6_1913f0a4:

    # "'I want to understand them. I want to make things work. But I'm scared I will make things worse.'"
    "'Quiero entender a esa persona. Quiero que las cosas funcionen. Pero tengo miedo de empeorar las cosas.'"

# game/chapters/6_roomexplore.rpyc:272
translate es door_hub6_d6020bd7:

    # "'I'm scared that neither of us are what we expect of each other.'"
    "'Tengo miedo de que ninguno de los dos sea lo que esperamos del otro.'"

# game/chapters/6_roomexplore.rpyc:273
translate es door_hub6_8932e9cb:

    # "The fear of not living up to expectations, the fear of misunderstandings. Such human emotions."
    "El miedo a no estar a la altura de las expectativas, el miedo a los malentendidos. Emociones tan humanas."

# game/chapters/6_roomexplore.rpyc:274
translate es door_hub6_bf243446:

    # "'I know, Mom. I know I should talk to them, but it's so much. It's like there's this weight, this secret between us, and I don't know how to bridge the gap.'"
    "'Lo sé, mamá. Sé que debería hablar con esa persona, pero es demasiado. Es como si hubiera un peso, un secreto entre nosotros, y no sé cómo cerrar la distancia.'"

# game/chapters/6_roomexplore.rpyc:275
translate es door_hub6_a88c3fb9:

    # "'I think I heard them say something last night, something important. But they didn't open up completely, and now I'm torn between wanting to know and being afraid of what I might discover.'"
    "'Creo que anoche le oí decir algo, algo importante. Pero no se sinceraron del todo, y ahora estoy entre querer saber y tener miedo de lo que pueda descubrir.'"

# game/chapters/6_roomexplore.rpyc:276
translate es door_hub6_f2ea5841:

    # "An internal struggle. A deep desire."
    "Una lucha interna. Un deseo profundo."

# game/chapters/6_roomexplore.rpyc:277
translate es door_hub6_b4462bca:

    # "'But, Mom, I can't stay away. I've never believed in fate, but this is... I just... I need some guidance. What do I do?'"
    "'Pero, mamá, no puedo mantenerme al margen. Nunca he creído en el destino, pero esto es... Es solo que... Necesito orientación. ¿Qué hago?'"

# game/chapters/6_roomexplore.rpyc:278
translate es door_hub6_cef912f6:

    # "Silence again."
    "Silencio de nuevo."

# game/chapters/6_roomexplore.rpyc:279
translate es door_hub6_f3a4e945:

    # "You imagine their mother is speaking words of wisdom, filled with kindness, love and worry."
    "Te imaginas a su madre pronunciando palabras de sabiduría, llenas de amabilidad, amor y preocupación."

# game/chapters/6_roomexplore.rpyc:280
translate es door_hub6_3209ea9a:

    # "'...Okay. I'll go talk to them tomorrow and make a decision.'"
    "'...Está bien. Mañana hablaré con esa persona y tomaré una decisión.'"

# game/chapters/6_roomexplore.rpyc:281
translate es door_hub6_e2832f78:

    # "'Thank you, Mom. I love you.'"
    "'Gracias, mamá. Te amo.'"

# game/chapters/6_roomexplore.rpyc:282
translate es door_hub6_a9f941ab:

    # "The sound of the call ending reaches you even beyond the hallway, and then there's silence."
    "El sonido de la llamada que termina te llega incluso más allá del pasillo, y luego se hace el silencio."

# game/chapters/6_roomexplore.rpyc:283
translate es door_hub6_5f6e59cd:

    # "You hope they find their keys."
    "Esperas que encuentre sus llaves."

# game/chapters/6_roomexplore.rpyc:298
translate es door_hub6_52eb8252_1:

    # "You hear a sniffling coming from the hallway, then the sound of someone sliding down to the floor."
    "Oyes un sollozo procedente del pasillo, seguido del sonido de alguien deslizándose hasta el suelo."

# game/chapters/6_roomexplore.rpyc:299
translate es door_hub6_06af4f93_1:

    # "You imagine someone is currently leaning against the doorway of their apartment."
    "Imaginas que alguien está apoyado contra la puerta de su apartamento."

# game/chapters/6_roomexplore.rpyc:300
translate es door_hub6_4db76323_1:

    # "You hear a fumbling - the sound of someone digging through their bag, searching for something."
    "Oyes un ruido - como si alguien estuviera rebuscando en su bolso, buscando algo."

# game/chapters/6_roomexplore.rpyc:301
translate es door_hub6_07880855_1:

    # "Then a sigh."
    "Luego, un suspiro."

# game/chapters/6_roomexplore.rpyc:302
translate es door_hub6_0b700eb9_1:

    # "A ringing. The sound of someone who desperately seeks another."
    "Un timbre. El sonido de alguien que busca desesperadamente a otra persona."

# game/chapters/6_roomexplore.rpyc:303
translate es door_hub6_571aa237_1:

    # "And then, finally, a voice."
    "Y entonces, por fin, una voz."

# game/chapters/6_roomexplore.rpyc:304
translate es door_hub6_0b1481c8_1:

    # "'Mom, are you there? Can you talk right now?' a light and airy voice starts."
    "'Mamá, ¿estás ahí? ¿Puedes hablar ahora?', comienza una voz ligera y melodiosa."

# game/chapters/6_roomexplore.rpyc:305
translate es door_hub6_8f07a59a_1:

    # "'No, I'm fine. No, I wasn't crying...'"
    "'No, estoy bien. No, no estaba llorando...'"

# game/chapters/6_roomexplore.rpyc:306
translate es door_hub6_e2c7a5cb_1:

    # "'I just wanted to talk for a bit. If that's okay.'"
    "'Solo quería hablar un rato. Si no te importa."

# game/chapters/6_roomexplore.rpyc:307
translate es door_hub6_b4994b24_1:

    # "Another sniffle."
    "Otro sollozo."

# game/chapters/6_roomexplore.rpyc:308
translate es door_hub6_326dfbb2_1:

    # "'Nothing happened, really. I'm just confused. And I lost my keys, but I'll worry about that in a minute...'"
    "'No ha pasado nada, de verdad. Solo es confusión. Y he perdido las llaves, pero ya me preocuparé de eso dentro de un momento...'"

# game/chapters/6_roomexplore.rpyc:309
translate es door_hub6_dc28c832_1:

    # "There's silence for a minute. You imagine their mother is currently fretting, trying to console their child despite not knowing what's wrong."
    "Hay un minuto de silencio. Imaginas a su madre preocupada, tratando de consolar a su hijo sin saber qué le pasa."

# game/chapters/6_roomexplore.rpyc:310
translate es door_hub6_be23173c_1:

    # "'Have you ever liked someone so much that it's made you terrified?'"
    "'¿Alguna vez te ha gustado alguien tanto que te ha dado miedo?'"

# game/chapters/6_roomexplore.rpyc:311
translate es door_hub6_a813b3cf_1:

    # "'I really like them, mom. I've only known them for like a week, but I feel like it's been so much longer...'"
    "'Me gusta mucho, mamá. Solo le conozco desde hace una semana, pero siento como si fuera mucho más tiempo...'"

# game/chapters/6_roomexplore.rpyc:312
translate es door_hub6_0b49988a_1:

    # "'And I'm scared.'"
    "'Y tengo miedo.'"

# game/chapters/6_roomexplore.rpyc:313
translate es door_hub6_4beb1ab3_1:

    # "There's vulnerability in that voice. Immense vulnerability."
    "Hay vulnerabilidad en esa voz. Una vulnerabilidad inmensa."

# game/chapters/6_roomexplore.rpyc:314
translate es door_hub6_480ae9e4_1:

    # "Their voice is like a plea to something they cannot see."
    "Su voz es como una súplica a algo que no puede ver."

# game/chapters/6_roomexplore.rpyc:315
translate es door_hub6_94ecefc1_1:

    # "Like a wish upon a star."
    "Como un deseo pedido a una estrella."

# game/chapters/6_roomexplore.rpyc:316
translate es door_hub6_1913f0a4_1:

    # "'I want to understand them. I want to make things work. But I'm scared I will make things worse.'"
    "'Quiero entender a esa persona. Quiero que las cosas funcionen. Pero tengo miedo de empeorar las cosas.'"

# game/chapters/6_roomexplore.rpyc:317
translate es door_hub6_d6020bd7_1:

    # "'I'm scared that neither of us are what we expect of each other.'"
    "'Tengo miedo de que ninguno de los dos sea lo que esperamos del otro.'"

# game/chapters/6_roomexplore.rpyc:318
translate es door_hub6_8932e9cb_1:

    # "The fear of not living up to expectations, the fear of misunderstandings. Such human emotions."
    "El miedo a no estar a la altura de las expectativas, el miedo a los malentendidos. Emociones tan humanas."

# game/chapters/6_roomexplore.rpyc:319
translate es door_hub6_bf243446_1:

    # "'I know, Mom. I know I should talk to them, but it's so much. It's like there's this weight, this secret between us, and I don't know how to bridge the gap.'"
    "'Lo sé, mamá. Sé que debería hablar con esa persona, pero es demasiado. Es como si hubiera un peso, un secreto entre nosotros, y no sé cómo cerrar la distancia.'"

# game/chapters/6_roomexplore.rpyc:320
translate es door_hub6_a88c3fb9_1:

    # "'I think I heard them say something last night, something important. But they didn't open up completely, and now I'm torn between wanting to know and being afraid of what I might discover.'"
    "'Creo que anoche le oí decir algo, algo importante. Pero no se sinceraron del todo, y ahora estoy entre querer saber y tener miedo de lo que pueda descubrir.'"

# game/chapters/6_roomexplore.rpyc:321
translate es door_hub6_f2ea5841_1:

    # "An internal struggle. A deep desire."
    "Una lucha interna. Un deseo profundo."

# game/chapters/6_roomexplore.rpyc:322
translate es door_hub6_b4462bca_1:

    # "'But, Mom, I can't stay away. I've never believed in fate, but this is... I just... I need some guidance. What do I do?'"
    "'Pero, mamá, no puedo mantenerme al margen. Nunca he creído en el destino, pero esto es... Es solo que... Necesito orientación. ¿Qué hago?'"

# game/chapters/6_roomexplore.rpyc:323
translate es door_hub6_cef912f6_1:

    # "Silence again."
    "Silencio de nuevo."

# game/chapters/6_roomexplore.rpyc:324
translate es door_hub6_f3a4e945_1:

    # "You imagine their mother is speaking words of wisdom, filled with kindness, love and worry."
    "Te imaginas a su madre pronunciando palabras de sabiduría, llenas de amabilidad, amor y preocupación."

# game/chapters/6_roomexplore.rpyc:325
translate es door_hub6_3209ea9a_1:

    # "'...Okay. I'll go talk to them tomorrow and make a decision.'"
    "'...Está bien. Mañana hablaré con esa persona y tomaré una decisión.'"

# game/chapters/6_roomexplore.rpyc:326
translate es door_hub6_e2832f78_1:

    # "'Thank you, Mom. I love you.'"
    "'Gracias, mamá. Te amo.'"

# game/chapters/6_roomexplore.rpyc:327
translate es door_hub6_a9f941ab_1:

    # "The sound of the call ending reaches you even beyond the hallway, and then there's silence."
    "El sonido de la llamada que termina te llega incluso más allá del pasillo, y luego se hace el silencio."

# game/chapters/6_roomexplore.rpyc:328
translate es door_hub6_5f6e59cd_1:

    # "You hope they find their keys."
    "Esperas que encuentre sus llaves."

# game/chapters/6_roomexplore.rpyc:340
translate es door_hub6_b82ac03c:

    # "The hallway beyond is silent now."
    "El pasillo está ahora en silencio."

# game/chapters/6_roomexplore.rpyc:341
translate es door_hub6_33f78972:

    # "You hope tomorrow will bring resolution."
    "Esperas que mañana llegue una solución."

# game/chapters/6_roomexplore.rpyc:355
translate es snake_hub6_21a76a54:

    # "[pet_name] seems to be doing well today!"
    "¡[pet_name] parece estar bien hoy!"

# game/chapters/6_roomexplore.rpyc:356
translate es snake_hub6_f1b7a781:

    # "You sit down on the bed next to [pet_her2] and think towards the future..."
    "Te sientas en la cama junto a [pet_she!t] y piensas en el futuro..."

# game/chapters/6_roomexplore.rpyc:357
translate es snake_hub6_2a45099f:

    # "If you ever manage to afford a house with the market looking like it is, you..."
    "Si alguna vez logras comprar una casa con el mercado tal y como está, tú..."

# game/chapters/6_roomexplore.rpyc:362
translate es snake_hub6_d8b52889:

    # "You've always liked dogs. They appeal to you, but you want one that needs a big yard... and you don't have that. {i}Yet.{/i}"
    "Siempre te han gustado los perros. Te encantan, pero quieres uno que necesite un jardín grande... y no lo tienes. {i}Todavía.{/i}"

# game/chapters/6_roomexplore.rpyc:366
translate es snake_hub6_aa6976c3:

    # "Is there anything greater in the world than cats? Well, [pet_name] first of all, but you do love cats."
    "¿Hay algo mejor en el mundo que los gatos? Bueno, [pet_name] en primer lugar, pero tú adoras a los gatos."

# game/chapters/6_roomexplore.rpyc:370
translate es snake_hub6_209ecbae:

    # "What's better than one snake? Two, if you had the room for more enclosures."
    "¿Qué es mejor que una serpiente? Dos, si tienes espacio para más recintos."

# game/chapters/6_roomexplore.rpyc:374
translate es snake_hub6_176f6622:

    # "Pets need so much time, effort and love... and money. One pet is plenty for you."
    "Las mascotas requieren mucho tiempo, esfuerzo, cariño... y dinero. Una mascota es suficiente para ti."

# game/chapters/6_roomexplore.rpyc:376
translate es snake_hub6_97641580:

    # "For now, you enjoy [pet_name]'s company immensely. You hope that, Grim Reaper and strange soul notwithstanding, you have many fun times ahead of you together."
    "Por ahora, disfrutas enormemente de la compañía de [pet_name]. Esperas que, a pesar de la Parca y de esa alma extraña, les esperen muchos momentos divertidos juntos."

# game/chapters/6_roomexplore.rpyc:382
translate es snake_hub6_414bf7f5:

    # "'Why did the snake go to school?' you ask [pet_name]."
    "'¿Qué hacen dos serpientes cuando se pelean?' preguntas a [pet_name]."

# game/chapters/6_roomexplore.rpyc:383
translate es snake_hub6_6de53b57:

    # "[pet_name] doesn't reply, but that doesn't stop you from continuing your joke."
    "[pet_name] no responde, pero eso no te impide continuar tu chiste."

# game/chapters/6_roomexplore.rpyc:384
translate es snake_hub6_8432cb99:

    # "'To improve in hiss-tory!'"
    "'¡Se enredan en sus problemas.!'"

# game/chapters/6_roomexplore.rpyc:385
translate es snake_hub6_0cfddb63:

    # "[pet_name] completely cracks up laughing.... not."
    "[pet_name] se parte de risa... o no."

# game/chapters/6_roomexplore.rpyc:386
translate es snake_hub6_9c89023a:

    # "But you still think your joke was appreciated. Maybe."
    "Pero sigues pensando que tu chiste fue bien recibido. Quizás."

# game/chapters/6_roomexplore.rpyc:398
translate es bingus_hub6_21a76a54:

    # "[pet_name] seems to be doing well today!"
    "¡[pet_name] parece estar bien hoy!"

# game/chapters/6_roomexplore.rpyc:399
translate es bingus_hub6_f1b7a781:

    # "You sit down on the bed next to [pet_her2] and think towards the future..."
    "Te sientas en la cama junto a [pet_she!t] y piensas en el futuro..."

# game/chapters/6_roomexplore.rpyc:400
translate es bingus_hub6_2a45099f:

    # "If you ever manage to afford a house with the market looking like it is, you..."
    "Si alguna vez logras comprar una casa con el mercado tal y como está, tú..."

# game/chapters/6_roomexplore.rpyc:405
translate es bingus_hub6_d8b52889:

    # "You've always liked dogs. They appeal to you, but you want one that needs a big yard... and you don't have that. {i}Yet.{/i}"
    "Siempre te han gustado los perros. Te encantan, pero quieres uno que necesite un jardín grande... y no lo tienes. {i}Todavía.{/i}"

# game/chapters/6_roomexplore.rpyc:409
translate es bingus_hub6_9d665288:

    # "You've always liked birds. Having a big aviary would be nice."
    "Siempre te han gustado los pájaros. Tener un gran aviario sería bueno."

# game/chapters/6_roomexplore.rpyc:413
translate es bingus_hub6_33bb3961:

    # "What's better than one cat? Two. Or three."
    "¿Qué es mejor que un gato? Dos. O tres."

# game/chapters/6_roomexplore.rpyc:417
translate es bingus_hub6_176f6622:

    # "Pets need so much time, effort and love... and money. One pet is plenty for you."
    "Las mascotas requieren mucho tiempo, esfuerzo, cariño... y dinero. Una mascota es suficiente para ti."

# game/chapters/6_roomexplore.rpyc:419
translate es bingus_hub6_97641580:

    # "For now, you enjoy [pet_name]'s company immensely. You hope that, Grim Reaper and strange soul notwithstanding, you have many fun times ahead of you together."
    "Por ahora, disfrutas enormemente de la compañía de [pet_name]. Esperas que, a pesar de la Parca y de esa alma extraña, les esperen muchos momentos divertidos juntos."

# game/chapters/6_roomexplore.rpyc:425
translate es bingus_hub6_8815343c:

    # "'Why was the Sphynx a great detective?' you ask [pet_name]."
    "'¿Por qué el gato esfinge era un gran detective?' preguntas a [pet_name]."

# game/chapters/6_roomexplore.rpyc:426
translate es bingus_hub6_4fb3270a:

    # "[pet_name] doesn't reply, but you know [pet_she] can't wait for the punchline."
    "[pet_name] no responde, pero ya sabes que [pet_she!t] no puedo esperar a escuchar el remate."

# game/chapters/6_roomexplore.rpyc:427
translate es bingus_hub6_e63e61e0:

    # "'Because it always uncovered the {i}naked{/i} truth!'"
    "'Porque siempre llegaba a los hechos {i}al desnudo{/i}.!'"

# game/chapters/6_roomexplore.rpyc:428
translate es bingus_hub6_954404e2:

    # "'Get it? Because you don't have fur. You're naked.' you continue. [pet_name] doesn't laugh."
    "'¿Lo entiendes? Porque no tienes pelaje. Estás al desnudo.' continúas. [pet_name] no se ríe."

# game/chapters/6_roomexplore.rpyc:429
translate es bingus_hub6_7b889282:

    # "Well, you thought it was a good joke."
    "Bueno, pensaste que era una buena broma."

# game/chapters/6_roomexplore.rpyc:441
translate es bunny_hub6_21a76a54:

    # "[pet_name] seems to be doing well today!"
    "¡[pet_name] parece estar bien hoy!"

# game/chapters/6_roomexplore.rpyc:442
translate es bunny_hub6_f1b7a781:

    # "You sit down on the bed next to [pet_her2] and think towards the future..."
    "Te sientas en la cama junto a [pet_she!t] y piensas en el futuro..."

# game/chapters/6_roomexplore.rpyc:443
translate es bunny_hub6_2a45099f:

    # "If you ever manage to afford a house with the market looking like it is, you..."
    "Si alguna vez logras comprar una casa con el mercado tal y como está, tú..."

# game/chapters/6_roomexplore.rpyc:448
translate es bunny_hub6_d8b52889:

    # "You've always liked dogs. They appeal to you, but you want one that needs a big yard... and you don't have that. {i}Yet.{/i}"
    "Siempre te han gustado los perros. Te encantan, pero quieres uno que necesite un jardín grande... y no lo tienes. {i}Todavía.{/i}"

# game/chapters/6_roomexplore.rpyc:452
translate es bunny_hub6_9d665288:

    # "You've always liked birds. Having a big aviary would be nice."
    "Siempre te han gustado los pájaros. Tener un gran aviario sería bueno."

# game/chapters/6_roomexplore.rpyc:456
translate es bunny_hub6_332e4842:

    # "What's better than one bunny? More."
    "¿Qué es mejor que un conejito? Más conejitos."

# game/chapters/6_roomexplore.rpyc:460
translate es bunny_hub6_176f6622:

    # "Pets need so much time, effort and love... and money. One pet is plenty for you."
    "Las mascotas requieren mucho tiempo, esfuerzo, cariño... y dinero. Una mascota es suficiente para ti."

# game/chapters/6_roomexplore.rpyc:462
translate es bunny_hub6_97641580:

    # "For now, you enjoy [pet_name]'s company immensely. You hope that, Grim Reaper and strange soul notwithstanding, you have many fun times ahead of you together."
    "Por ahora, disfrutas enormemente de la compañía de [pet_name]. Esperas que, a pesar de la Parca y de esa alma extraña, les esperen muchos momentos divertidos juntos."

# game/chapters/6_roomexplore.rpyc:467
translate es bunny_hub6_fd8c52c1:

    # "'What do you call a rabbit who wears a fur coat in the summer?' you ask [pet_name]."
    "'¿Por qué el conejo no quería jugar a las escondidas?' preguntas a [pet_name]."

# game/chapters/6_roomexplore.rpyc:468
translate es bunny_hub6_4fb3270a:

    # "[pet_name] doesn't reply, but you know [pet_she] can't wait for the punchline."
    "[pet_name] no responde, pero ya sabes que [pet_she!t] no puedo esperar a escuchar el remate."

# game/chapters/6_roomexplore.rpyc:469
translate es bunny_hub6_9e204c1d:

    # "'A hot cross bunny!'"
    "'¡Porque siempre lo pillaban por las orejas.!'"

# game/chapters/6_roomexplore.rpyc:470
translate es bunny_hub6_71cc6c4b:

    # "[pet_name] doesn't laugh. That's probably because [pet_name] is a rabbit."
    "[pet_name] no se ríe. Eso es probablemente porque [pet_name] es un conejo."

# game/chapters/6_roomexplore.rpyc:471
translate es bunny_hub6_ed3f7a8a:

    # "You're sure the joke was enjoyed."
    "Tienes la certeza de que disfruto el chiste."

# game/chapters/6_roomexplore.rpyc:483
translate es cat_hub6_21a76a54:

    # "[pet_name] seems to be doing well today!"
    "¡[pet_name] parece estar bien hoy!"

# game/chapters/6_roomexplore.rpyc:484
translate es cat_hub6_f1b7a781:

    # "You sit down on the bed next to [pet_her2] and think towards the future..."
    "Te sientas en la cama junto a [pet_she!t] y piensas en el futuro..."

# game/chapters/6_roomexplore.rpyc:485
translate es cat_hub6_2a45099f:

    # "If you ever manage to afford a house with the market looking like it is, you..."
    "Si alguna vez logras comprar una casa con el mercado tal y como está, tú..."

# game/chapters/6_roomexplore.rpyc:490
translate es cat_hub6_d8b52889:

    # "You've always liked dogs. They appeal to you, but you want one that needs a big yard... and you don't have that. {i}Yet.{/i}"
    "Siempre te han gustado los perros. Te encantan, pero quieres uno que necesite un jardín grande... y no lo tienes. {i}Todavía.{/i}"

# game/chapters/6_roomexplore.rpyc:494
translate es cat_hub6_9d665288:

    # "You've always liked birds. Having a big aviary would be nice."
    "Siempre te han gustado los pájaros. Tener un gran aviario sería bueno."

# game/chapters/6_roomexplore.rpyc:498
translate es cat_hub6_33bb3961:

    # "What's better than one cat? Two. Or three."
    "¿Qué es mejor que un gato? Dos. O tres."

# game/chapters/6_roomexplore.rpyc:502
translate es cat_hub6_176f6622:

    # "Pets need so much time, effort and love... and money. One pet is plenty for you."
    "Las mascotas requieren mucho tiempo, esfuerzo, cariño... y dinero. Una mascota es suficiente para ti."

# game/chapters/6_roomexplore.rpyc:504
translate es cat_hub6_97641580:

    # "For now, you enjoy [pet_name]'s company immensely. You hope that, Grim Reaper and strange soul notwithstanding, you have many fun times ahead of you together."
    "Por ahora, disfrutas enormemente de la compañía de [pet_name]. Esperas que, a pesar de la Parca y de esa alma extraña, les esperen muchos momentos divertidos juntos."

# game/chapters/6_roomexplore.rpyc:509
translate es cat_hub6_8991e7a1:

    # "'What's a cat's favorite dessert?' you ask [pet_name]."
    "'¿Cuál es el colmo de un gato músico?' preguntas a [pet_name]."

# game/chapters/6_roomexplore.rpyc:510
translate es cat_hub6_4fb3270a:

    # "[pet_name] doesn't reply, but you know [pet_she] can't wait for the punchline."
    "[pet_name] no responde, pero ya sabes que [pet_she!t] no puedo esperar a escuchar el remate."

# game/chapters/6_roomexplore.rpyc:511
translate es cat_hub6_6e0ad5ce:

    # "'Mice cream!'"
    "'¡Tener una banda de purr-cusión!'"

# game/chapters/6_roomexplore.rpyc:512
translate es cat_hub6_f3552b96:

    # "[pet_name] doesn't laugh. In fact, you think [pet_name] looks to be judging you heavily."
    "[pet_name] no se ríe. De hecho, crees que [pet_name] parece estar juzgándote mucho."

# game/chapters/6_roomexplore.rpyc:513
translate es cat_hub6_2536a239:

    # "Well... you enjoyed the joke, at least."
    "Bueno... disfrutaste el chiste, al menos."

# game/chapters/6_roomexplore.rpyc:525
translate es dog_hub6_21a76a54:

    # "[pet_name] seems to be doing well today!"
    "¡[pet_name] parece estar bien hoy!"

# game/chapters/6_roomexplore.rpyc:526
translate es dog_hub6_f1b7a781:

    # "You sit down on the bed next to [pet_her2] and think towards the future..."
    "Te sientas en la cama junto a [pet_she!t] y piensas en el futuro..."

# game/chapters/6_roomexplore.rpyc:527
translate es dog_hub6_2a45099f:

    # "If you ever manage to afford a house with the market looking like it is, you..."
    "Si alguna vez logras comprar una casa con el mercado tal y como está, tú..."

# game/chapters/6_roomexplore.rpyc:532
translate es dog_hub6_aa6976c3:

    # "Is there anything greater in the world than cats? Well, [pet_name] first of all, but you do love cats."
    "¿Hay algo mejor en el mundo que los gatos? Bueno, [pet_name] en primer lugar, pero tú adoras a los gatos."

# game/chapters/6_roomexplore.rpyc:536
translate es dog_hub6_9d665288:

    # "You've always liked birds. Having a big aviary would be nice."
    "Siempre te han gustado los pájaros. Tener un gran aviario sería bueno."

# game/chapters/6_roomexplore.rpyc:540
translate es dog_hub6_4b6c0ed3:

    # "What's better than one dog? Two, of course!"
    "¿Qué es mejor que un perro? ¡Dos, por supuesto!"

# game/chapters/6_roomexplore.rpyc:544
translate es dog_hub6_176f6622:

    # "Pets need so much time, effort and love... and money. One pet is plenty for you."
    "Las mascotas requieren mucho tiempo, esfuerzo, cariño... y dinero. Una mascota es suficiente para ti."

# game/chapters/6_roomexplore.rpyc:546
translate es dog_hub6_97641580:

    # "For now, you enjoy [pet_name]'s company immensely. You hope that, Grim Reaper and strange soul notwithstanding, you have many fun times ahead of you together."
    "Por ahora, disfrutas enormemente de la compañía de [pet_name]. Esperas que, a pesar de la Parca y de esa alma extraña, les esperen muchos momentos divertidos juntos."

# game/chapters/6_roomexplore.rpyc:551
translate es dog_hub6_f18a88f8:

    # "'What do you call a dog magician?' you ask [pet_name]."
    "'¿Qué hace un perro con un taladro?' preguntas a [pet_name]."

# game/chapters/6_roomexplore.rpyc:552
translate es dog_hub6_4fb3270a:

    # "[pet_name] doesn't reply, but you know [pet_she] can't wait for the punchline."
    "[pet_name] no responde, pero ya sabes que [pet_she!t] no puedo esperar a escuchar el remate."

# game/chapters/6_roomexplore.rpyc:553
translate es dog_hub6_27dbb87b:

    # "'A labracadabrador!'"
    "'¡Taladra-ladra-ladra!'"

# game/chapters/6_roomexplore.rpyc:554
translate es dog_hub6_85bd48ac:

    # "[pet_name] doesn't laugh, but that's probably because [pet_she]'s a dog."
    "[pet_name] no se ríe, pero probablemente sea porque [pet_she!t] es un perro."

# game/chapters/6_roomexplore.rpyc:555
translate es dog_hub6_628a0467:

    # "The joke was definitely appreciated."
    "El chiste definitivamente fue apreciado."

# game/chapters/6_roomexplore.rpyc:567
translate es hamster_hub6_21a76a54:

    # "[pet_name] seems to be doing well today!"
    "¡[pet_name] parece estar bien hoy!"

# game/chapters/6_roomexplore.rpyc:568
translate es hamster_hub6_f1b7a781:

    # "You sit down on the bed next to [pet_her2] and think towards the future..."
    "Te sientas en la cama junto a [pet_she!t] y piensas en el futuro..."

# game/chapters/6_roomexplore.rpyc:569
translate es hamster_hub6_2a45099f:

    # "If you ever manage to afford a house with the market looking like it is, you..."
    "Si alguna vez logras comprar una casa con el mercado tal y como está, tú..."

# game/chapters/6_roomexplore.rpyc:574
translate es hamster_hub6_aa6976c3:

    # "Is there anything greater in the world than cats? Well, [pet_name] first of all, but you do love cats."
    "¿Hay algo mejor en el mundo que los gatos? Bueno, [pet_name] en primer lugar, pero tú adoras a los gatos."

# game/chapters/6_roomexplore.rpyc:578
translate es hamster_hub6_9d665288:

    # "You've always liked birds. Having a big aviary would be nice."
    "Siempre te han gustado los pájaros. Tener un gran aviario sería bueno."

# game/chapters/6_roomexplore.rpyc:582
translate es hamster_hub6_7573068b:

    # "You don't have the room for extra enclosures at the moment... but one day!"
    "No tienes el espacio para recintos adicionales en este momento... ¡pero algún día!"

# game/chapters/6_roomexplore.rpyc:586
translate es hamster_hub6_176f6622:

    # "Pets need so much time, effort and love... and money. One pet is plenty for you."
    "Las mascotas requieren mucho tiempo, esfuerzo, cariño... y dinero. Una mascota es suficiente para ti."

# game/chapters/6_roomexplore.rpyc:588
translate es hamster_hub6_97641580:

    # "For now, you enjoy [pet_name]'s company immensely. You hope that, Grim Reaper and strange soul notwithstanding, you have many fun times ahead of you together."
    "Por ahora, disfrutas enormemente de la compañía de [pet_name]. Esperas que, a pesar de la Parca y de esa alma extraña, les esperen muchos momentos divertidos juntos."

# game/chapters/6_roomexplore.rpyc:593
translate es hamster_hub6_19a09656:

    # "'What's a hamster's favorite game show?' you ask [pet_name]."
    "'¿Cuál es el programa de juegos favorito de los hámsters?' preguntas a [pet_name]."

# game/chapters/6_roomexplore.rpyc:594
translate es hamster_hub6_4fb3270a:

    # "[pet_name] doesn't reply, but you know [pet_she] can't wait for the punchline."
    "[pet_name] no responde, pero ya sabes que [pet_she!t] no puedo esperar a escuchar el remate."

# game/chapters/6_roomexplore.rpyc:595
translate es hamster_hub6_71a32cab:

    # "'Wheel of Fortune!'"
    "'¡Rueda de la fortuna!'"

# game/chapters/6_roomexplore.rpyc:596
translate es hamster_hub6_987152b4:

    # "'Get it?' you continue, 'because you love your wheel so much!'"
    "'¿Lo entiendes?', continúas, '¡porque te encanta tu rueda!'"

# game/chapters/6_roomexplore.rpyc:597
translate es hamster_hub6_8f27007f:

    # "[pet_name] doesn't laugh, but that's probably because [pet_she]'s a hamster."
    "[pet_name] no se ríe, pero eso probablemente sea porque [pet_she!t] es un hámster."

# game/chapters/6_roomexplore.rpyc:598
translate es hamster_hub6_628a0467:

    # "The joke was definitely appreciated."
    "El chiste definitivamente fue apreciado."

# game/chapters/6_roomexplore.rpyc:617
translate es plant_hub6_c1229c6a:

    # "You give your little sprout a big drink of water."
    "Le das a tu pequeño retoño un buen trago de agua."

# game/chapters/6_roomexplore.rpyc:618
translate es plant_hub6_c5de961c:

    # "Though you don't speak sprout, it seems to say thank you."
    "Aunque no hablas idioma retoño, parece decirte gracias."

# game/chapters/6_roomexplore.rpyc:620
translate es plant_hub6_518e64fd:

    # "Your little sprout has grown some leaves!"
    "¡Tu pequeño retoño ha sacado algunas hojas!"

# game/chapters/6_roomexplore.rpyc:621
translate es plant_hub6_8036dce1:

    # "You can't help but feel proud as you give it a big drink of water."
    "No puedes evitar sentir orgullo mientras le das un gran trago de agua."

# game/chapters/6_roomexplore.rpyc:623
translate es plant_hub6_adaac543:

    # "Even more leaves have appeared now!"
    "¡Ahora han aparecido aún más hojas!"

# game/chapters/6_roomexplore.rpyc:624
translate es plant_hub6_a4970463:

    # "You water it generously and feel excited that, this time, you didn't kill your plant instantly."
    "Lo riegas generosamente y sientes emoción porque, esta vez, no mataste tu planta al instante."

# game/chapters/6_roomexplore.rpyc:626
translate es plant_hub6_2087a70f:

    # "Your little plant is growing healthily!"
    "¡Tu pequeña planta está creciendo saludablemente!"

# game/chapters/6_roomexplore.rpyc:627
translate es plant_hub6_80d209cf:

    # "You give it a big drink of water, excited about its growth."
    "Le das un buen trago de agua, con entusiasmo por su crecimiento."

# game/chapters/6_roomexplore.rpyc:629
translate es plant_hub6_41affa3b:

    # "Your little plant has sprouted some buds!"
    "¡Tu pequeña planta ha brotado algunos capullos!"

# game/chapters/6_roomexplore.rpyc:630
translate es plant_hub6_75fbf720:

    # "You almost tear up when you notice them. They're so cute - you can't wait to see what the flowers will look like."
    "Casi lloras cuando los notas. Son tan lindos, no puedes esperar a ver cómo se verán las flores."

# game/chapters/6_roomexplore.rpyc:632
translate es plant_hub6_33ab5804:

    # "The buds on your little plant seem to be doing well!"
    "¡Los capullos en tu pequeña planta parecen estar bien!"

# game/chapters/6_roomexplore.rpyc:633
translate es plant_hub6_19058b26:

    # "You can't believe how healthy it is..."
    "No te imaginas lo saludable que es..."

# game/chapters/6_roomexplore.rpyc:648
translate es plant_hub6_03e35dbb:

    # "One seems like an unlucky number to you."
    "El uno te parece un número de mala suerte."

# game/chapters/6_roomexplore.rpyc:649
translate es plant_hub6_4a128500:

    # "Better to water it twice, right?"
    "Es mejor regarlo dos veces, ¿no?"

# game/chapters/6_roomexplore.rpyc:663
translate es plant_hub6_b3a702e0:

    # "You know what number is better than two?"
    "¿Sabes qué número es mejor que el dos?"

# game/chapters/6_roomexplore.rpyc:664
translate es plant_hub6_d698ea09:

    # "Three!"
    "¡Tres!"

# game/chapters/6_roomexplore.rpyc:665
translate es plant_hub6_712e11cc:

    # "You empty your watering can into the plant, but it's not enough."
    "Viertes el contenido de la regadera sobre la planta, pero no es suficiente."

# game/chapters/6_roomexplore.rpyc:666
translate es plant_hub6_7c9c787c:

    # "You go fill it a second time. Then a third time."
    "Ve a llenarlo una segunda vez. Luego, una tercera vez."

# game/chapters/6_roomexplore.rpyc:667
translate es plant_hub6_a756208f:

    # "You're drowning this plant, and yet you keep going."
    "Estás ahogando esta planta y, sin embargo, sigues adelante."

# game/chapters/6_roomexplore.rpyc:668
translate es plant_hub6_d140d894:

    # "You don't follow the rules. The rules follow you."
    "Tú no sigues las reglas. Las reglas te siguen a ti."

translate es strings:

    old "1. Your teacher in middle school."
    new "1. Tu profesor en la escuela secundaria."

    old "1. Would love to get a dog!"
    new "1. ¡Te encantaría tener un perro!"

    old "1. Would love to get a cat!"
    new "1. ¡Te encantaría tener un gato!"

    old "2. Your crush when you were ten."
    new "2. Tu amor platónico cuando tenías diez años."

    old "2. Would love a cat. Or two cats. Or three?"
    new "2. Te encantaría tener un gato. ¿O dos? ¿O tres?"

    old "2. A bird would be nice."
    new "2. Un ave estaría bien."

    old "3. Your childhood best friend."
    new "3. Tu mejor amigo de la infancia."

    old "3. A family member."
    new "3. Un miembro de la familia."

    old "3. Would like another snake."
    new "3. Te gustaría tener otra serpiente."

    old "3. Would like another cat!"
    new "3. ¡Te gustaría tener otro gato!"

    old "3. More bunnies!"
    new "3. ¡Más conejos!"

    old "3. You want more cats!"
    new "3. ¡Quieres más gatos!"

    old "3. You want more dogs!"
    new "3. ¡Quieres más perros!"

    old "3. You want more hamsters!"
    new "3. ¡Quieres más hámsters!"

    old "4. Probably don't want any more pets."
    new "4. Probablemente no quieras más mascotas."

    old "Tell [pet_name] a joke."
    new "Contarle un chiste a [pet_name]."

    old "{i}Diary #2{/i}"
    new "{i}Diario #2{/i}"

    old "today i found a HUGE bug."
    new "hoy encontré un BICHO ENORME."

    old "it was so cool it had wings and legs but no arms."
    new "era tan genial, tenía alas y patas, pero no brazos."

    old "or maybe they were all arms and it had no legs."
    new "o tal vez eran todos brazos y no tenía patas."

    old "IDK."
    new "no lo sé."

    old "what i DO know, is that it was the best thing i've ever seen in my entire life!"
    new "¡lo que SÍ sé es que fue lo mejor que he visto en toda mi vida!"

    old "anywayz."
    new "en fin."

    old "something wicked cool happened at school."
    new "pasó algo súper genial en la escuela."

    old "i was climbing this tree (we call it 'the' tree btw but i don't think thats its actual name but IDK i haven't asked), and i was REALLY high up."
    new "estaba trepando a un árbol (lo llamamos 'el' árbol, aunque creo que ese no es su nombre real, pero no lo sé, nunca he preguntado), y estaba MUY arriba."

    old "AND I FELL!!!"
    new "¡¡¡Y ME CAÍ!!!"

    old "i fell so far i thought was was going to DIE and i got in sooo much trouble ROFLMAO."
    new "me caí desde tan alto que pensé que iba a MORIR y me metí en un montón de problemas jajajajajaja."

    old "the teachers kept saying i could have broken my leg or my back or something and i was lucky i just got a scratch."
    new "los profes seguían diciendo que podía haberme roto una pierna o la espalda o algo, y que tuve suerte de solo rasparme."

    old "what my teachers dont know is that i am totally {s}enda{/s} {s}inde{/s} indestructable!!! nothing can kill me!!!!!!"
    new "lo que mis profes no saben es que soy totalmente {s}inda{/s} {s}estra{/s} ¡¡¡¡indestructible!!!! ¡¡¡¡¡nada puede matarme!!!!!"

    old "anywayz thats all thats been happening."
    new "en fin, eso es todo lo que ha pasado."

    old "i gotta go play now."
    new "ahora tengo que ir a jugar."

    old "BAIIII"
    new "ADIOOOO"
