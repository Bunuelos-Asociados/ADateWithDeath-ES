
# game/chapters/end_2.rpyc:22
translate es end2_start_ce6326d9:

    # center_text "You woke up early this morning feeling particularly well rested."
    center_text "Te has despertado temprano esta mañana con una sensación especial de descanso."

# game/chapters/end_2.rpyc:23
translate es end2_start_f9385cf7:

    # center_text "No one came for your soul in the night, which means..."
    center_text "Nadie vino por tu alma durante la noche, lo que significa que..."

# game/chapters/end_2.rpyc:24
translate es end2_start_b25b7a28:

    # center_text "Today is the final day of your bet!"
    center_text "¡Hoy es el día final de tu apuesta!"

# game/chapters/end_2.rpyc:25
translate es end2_start_3331b1c7:

    # center_text "You almost can't contain your excitement. After all, you seem to have this in the bag."
    center_text "Casi no puedes contener tu emoción. Después de todo, parece que tienes esto en el bolsillo."

# game/chapters/end_2.rpyc:26
translate es end2_start_9aea9fc5:

    # center_text "You decide not to go out anywhere today - safer to stay at home and ride out your win."
    center_text "Decides no salir a ningún lado hoy - es más seguro quedarte en casa y esperar tu victoria."

# game/chapters/end_2.rpyc:27
translate es end2_start_d6f1731b:

    # center_text "It's still early in the morning as you wait for the eventual message from your own personal Grim Reaper."
    center_text "Aún es temprano en la mañana mientras esperas el inevitable mensaje de tu Parca personal."

# game/chapters/end_2.rpyc:68
translate es day7_start_kissend_1f6c1adb:

    # player "G'morning Caspeeeeeer."
    player "Bueeenos días, Caspeeeeeer."

# game/chapters/end_2.rpyc:71
translate es day7_start_kissend_7724a68d:

    # player "What a lovely day it is."
    player "Qué día tan encantador."

# game/chapters/end_2.rpyc:74
translate es day7_start_kissend_8eb4bd9f:

    # player "The sun is shining."
    player "El sol brilla."

# game/chapters/end_2.rpyc:76
translate es day7_start_kissend_3148bb8f:

    # GR "the shine is always shining, whether you can see it or not."
    GR "el brillo siempre brilla, aunque no puedas verlo."

# game/chapters/end_2.rpyc:77
translate es day7_start_kissend_1c76bb57:

    # GR "but... sure. i imagine it is a nice day for you."
    GR "pero... claro. imagino que para ti es un buen día."

# game/chapters/end_2.rpyc:81
translate es day7_start_kissend_364cbd66:

    # player "You're so wise."
    player "Eres tan sabio."

# game/chapters/end_2.rpyc:83
translate es day7_start_kissend_9ee0b705:

    # player "Whatever you saaay."
    player "Lo que tú digas."

# game/chapters/end_2.rpyc:86
translate es day7_start_kissend_e85a8aec:

    # player "But what I was getting at was that it's such a {i}lovely day{/i}."
    player "Pero a lo que iba es que es un día tan {i}hermoso{/i}."

# game/chapters/end_2.rpyc:89
translate es day7_start_kissend_a350abd1:

    # player "{i}Today{/i}."
    player "{i}Hoy{/i}."

# game/chapters/end_2.rpyc:90
translate es day7_start_kissend_742a036b:

    # GR "the day is fine."
    GR "el día está bien."

# game/chapters/end_2.rpyc:93
translate es day7_start_kissend_1f8b872b:

    # player "My little reaper... you're about to run out of time ;)"
    player "Mi parquita... estás a punto de quedarte sin tiempo ;)"

# game/chapters/end_2.rpyc:94
translate es day7_start_kissend_f920392a:

    # GR "AH."
    GR "AH."

# game/chapters/end_2.rpyc:95
translate es day7_start_kissend_6d587722:

    # GR "so the day has come already... it seems time has run away from me..."
    GR "así que el día ya ha llegado... parece que el tiempo se me ha escapado..."

# game/chapters/end_2.rpyc:96
translate es day7_start_kissend_a1f593c6:

    # GR "but there is no issue."
    GR "pero no hay problema."

# game/chapters/end_2.rpyc:99
translate es day7_start_kissend_533a9717:

    # player "No?"
    player "¿No?"

# game/chapters/end_2.rpyc:101
translate es day7_start_kissend_5aa80383:

    # player "Is there not?"
    player "¿No lo hay?"

# game/chapters/end_2.rpyc:102
translate es day7_start_kissend_cbc2b396:

    # GR "be grateful because i am allowing you a few more hours. i am infinitely kind."
    GR "sé agradecido, porque te estoy permitiendo unas horas más. soy infinitamente amable."

# game/chapters/end_2.rpyc:105
translate es day7_start_kissend_82cc8758:

    # player "Oh wow, your generosity knows no bounds."
    player "Oh, wow, tu generosidad no conoce límites."

# game/chapters/end_2.rpyc:108
translate es day7_start_kissend_3e35858a:

    # player "How will I ever thank you?"
    player "¿Cómo te lo agradeceré algún día?"

# game/chapters/end_2.rpyc:109
translate es day7_start_kissend_af579540:

    # GR "thank me by not resisting this any further. it is... difficult enough as it is."
    GR "agradeceme no resistiéndote más. esto es... lo bastante difícil tal y como está."

# game/chapters/end_2.rpyc:110
translate es day7_start_kissend_7ab5559e:

    # GR "hand over what remains of your soul. please."
    GR "entrégame lo que queda de tu alma. por favor."

# game/chapters/end_2.rpyc:113
translate es day7_start_kissend_72b0d333:

    # player "Where's the fun in that?"
    player "¿Dónde está la diversión en eso?"

# game/chapters/end_2.rpyc:115
translate es day7_start_kissend_03202628:

    # player "I'd rather make it more difficult for you."
    player "Prefiero ponértelo más difícil."

# game/chapters/end_2.rpyc:117
translate es day7_start_kissend_19aac859:

    # player "I will {i}definitely{/i} do that."
    player "{i}Definitivamente{/i} haré eso."

# game/chapters/end_2.rpyc:119
translate es day7_start_kissend_f7789005:

    # GR "you are difficult right until the end."
    GR "eres difícil hasta el final."

# game/chapters/end_2.rpyc:123
translate es day7_start_kissend_646f7d48:

    # player "Don't you like the chase?"
    player "¿No te gusta la persecución?"

# game/chapters/end_2.rpyc:125
translate es day7_start_kissend_fe8487b9:

    # GR "sure. in moderation."
    GR "claro. con moderación."

# game/chapters/end_2.rpyc:126
translate es day7_start_kissend_9024c19f:

    # GR "i feel like i've been chasing you your entire life."
    GR "siento que te he estado persiguiendo toda tu vida."

# game/chapters/end_2.rpyc:130
translate es day7_start_kissend_f2b1df67:

    # player "Awww, Grim's been chasing me <3"
    player "Awww, Parca me ha estado persiguiendo <3"

# game/chapters/end_2.rpyc:131
translate es day7_start_kissend_28b7e43f:

    # GR "yes, well... your soul is in you. so i need to chase you. stupid."
    GR "sí, bueno... tu alma está en ti. así que tengo que perseguirte. idiota."

# game/chapters/end_2.rpyc:136
translate es day7_start_kissend_027cf8be:

    # player "You're a romantic at heart, Casper."
    player "Eres un romántico en el fondo, Casper."

# game/chapters/end_2.rpyc:139
translate es day7_start_kissend_9e607853:

    # GR "mortal, on the last day of your life, i find it only fair that i share with you what i have discovered."
    GR "mortal, en el último día de tu vida, me parece justo compartir contigo lo que he descubierto."

# game/chapters/end_2.rpyc:143
translate es day7_start_kissend_6d645bbb:

    # player "You been studying, Grimmy?"
    player "¿Has estado investigando, Parquita?"

# game/chapters/end_2.rpyc:145
translate es day7_start_kissend_ebc9eb7a:

    # GR "yes."
    GR "sí."

# game/chapters/end_2.rpyc:146
translate es day7_start_kissend_b93dc99e:

    # GR "as i said yesterday, your soul is incomplete because you keep giving parts of it away."
    GR "como dije ayer, tu alma está incompleta porque sigues entregando partes de ella."

# game/chapters/end_2.rpyc:147
translate es day7_start_kissend_42f05f00:

    # GR "something that is... usually not possible for a mortal."
    GR "algo que... normalmente no es posible para un mortal."

# game/chapters/end_2.rpyc:148
translate es day7_start_kissend_50e4392b:

    # GR "that answered some of my questions."
    GR "eso respondió algunas de mis preguntas."

# game/chapters/end_2.rpyc:149
translate es day7_start_kissend_282b70e9:

    # GR "why your soul seemed to feel so strange, how you managed to take my soul sickness away..."
    GR "por qué tu alma parecía tan extraña, cómo lograste quitarme mi enfermedad del alma..."

# game/chapters/end_2.rpyc:150
translate es day7_start_kissend_f2471d4b:

    # GR "but it didn't answer enough. i have so many more questions."
    GR "pero no respondió lo suficiente. tengo muchas más preguntas."

# game/chapters/end_2.rpyc:151
translate es day7_start_kissend_207ffc15:

    # GR "i found the answer."
    GR "encontré la respuesta."

# game/chapters/end_2.rpyc:155
translate es day7_start_kissend_0f5f02ca:

    # player "!!!"
    player "!!!"

# game/chapters/end_2.rpyc:159
translate es day7_start_kissend_ca2087c9:

    # player "Lay it on me, Casper!"
    player "¡Dímela, Casper!"

# game/chapters/end_2.rpyc:161
translate es day7_start_kissend_026bf5ab:

    # GR "[playerfirstname!l], you embody life just as i embody death."
    GR "[playerfirstname!l], encarnas la vida así como yo encarnó la muerte."

# game/chapters/end_2.rpyc:165
translate es day7_start_kissend_c237b9ba:

    # player "...?"
    player "...?"

# game/chapters/end_2.rpyc:167
translate es day7_start_kissend_46c9b84d:

    # GR "my research lead me to a rare trait that shows... maybe only every thousand or so years in a mortal."
    GR "mi investigación me llevó a un rasgo raro que aparece... quizá solo cada mil años en un mortal."

# game/chapters/end_2.rpyc:168
translate es day7_start_kissend_c48cea89:

    # GR "you have the touch of life on your soul."
    GR "tienes el toque de la vida en tu alma."

# game/chapters/end_2.rpyc:169
translate es day7_start_kissend_f676de59:

    # GR "you {i}are{/i} life, so to speak."
    GR "tú {i}eres{/i} vida, por así decirlo."

# game/chapters/end_2.rpyc:170
translate es day7_start_kissend_a4b099f0:

    # GR "that is why i have not been able to take your soul."
    GR "por eso no he podido tomar tu alma."

# game/chapters/end_2.rpyc:171
translate es day7_start_kissend_9a3ba732:

    # GR "that is how you avoid death without a thought."
    GR "así es como evitas la muerte sin pensarlo."

# game/chapters/end_2.rpyc:172
translate es day7_start_kissend_5ebaedf1:

    # GR "that is why you can heal as you do."
    GR "por eso puedes sanar como lo haces."

# game/chapters/end_2.rpyc:173
translate es day7_start_kissend_fac7ad14:

    # GR "you are special. you've always been special."
    GR "eres especial. siempre lo has sido."

# game/chapters/end_2.rpyc:177
translate es day7_start_kissend_03775ec8:

    # player "..."
    player "..."

# game/chapters/end_2.rpyc:181
translate es day7_start_kissend_5b23d895:

    # player "So I'm immortal now?"
    player "¿Así que ahora soy inmortal?"

# game/chapters/end_2.rpyc:183
translate es day7_start_kissend_30ced879:

    # GR "i am unsure."
    GR "no estoy seguro."

# game/chapters/end_2.rpyc:184
translate es day7_start_kissend_a4d15129:

    # GR "perhaps."
    GR "quizá."

# game/chapters/end_2.rpyc:185
translate es day7_start_kissend_3a6aafaa:

    # GR "there's only one way to find out."
    GR "solo hay una manera de averiguarlo."

# game/chapters/end_2.rpyc:186
translate es day7_start_kissend_d4faa1b7:

    # GR "and that will be me trying to take your soul one final time."
    GR "y será que intente tomar tu alma una última vez."

# game/chapters/end_2.rpyc:191
translate es day7_start_kissend_d869d123:

    # player "Reeeaaally?"
    player "¿De veeeerdad?"

# game/chapters/end_2.rpyc:195
translate es day7_start_kissend_d1c4a04f:

    # player "It doesn't sound like it'll work for you."
    player "No suena como que te vaya a funcionar."

# game/chapters/end_2.rpyc:199
translate es day7_start_kissend_8e56a9ea:

    # player "And you've left it so last minute..."
    player "Y lo dejaste para último minuto..."

# game/chapters/end_2.rpyc:203
translate es day7_start_kissend_67c27874:

    # player "If you REALLY wanted it that badly..."
    player "Si de VERDAD la quisieras tanto..."

# game/chapters/end_2.rpyc:207
translate es day7_start_kissend_0b152f3c:

    # player "I don't think you would have let time slip."
    player "No creo que hubieras dejado pasar el tiempo."

# game/chapters/end_2.rpyc:210
translate es day7_start_kissend_14f8c909:

    # player "Oh, I know..."
    player "Oh, ya sé..."

# game/chapters/end_2.rpyc:214
translate es day7_start_kissend_4283b819:

    # player "It's because you're in love with me, right?"
    player "Es porque estás enamorado de mí, ¿verdad?"

# game/chapters/end_2.rpyc:216
translate es day7_start_kissend_20e41447:

    # GR "i... i..."
    GR "yo... yo..."

# game/chapters/end_2.rpyc:217
translate es day7_start_kissend_dfa4b87e:

    # GR "w... what... i... don't know... what you're... talking about, probably..."
    GR "q... qué... yo... no sé... de qué estás... hablando, probablemente..."

# game/chapters/end_2.rpyc:221
translate es day7_start_kissend_1cc3613a:

    # player "You said it yesterday, right?"
    player "Lo dijiste ayer, ¿no?"

# game/chapters/end_2.rpyc:225
translate es day7_start_kissend_869e463a:

    # player "You like me. You want to hate me, but you can't."
    player "Te gusto. Quieres odiarme, pero no puedes."

# game/chapters/end_2.rpyc:229
translate es day7_start_kissend_85ad8a2d:

    # player "Must be frustrating for you, little reaper."
    player "Debe ser frustrante para ti, parquita."

# game/chapters/end_2.rpyc:231
translate es day7_start_kissend_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/end_2.rpyc:235
translate es day7_start_kissend_8a71d330:

    # player "Unless you've changed your mind?"
    player "¿A menos que hayas cambiado de opinión?"

# game/chapters/end_2.rpyc:237
translate es day7_start_kissend_41615513:

    # GR "my mind, perhaps i could sway..."
    GR "mi mente, tal vez podría cambiar..."

# game/chapters/end_2.rpyc:238
translate es day7_start_kissend_401a10ef:

    # GR "my heart is not so weak..."
    GR "mi corazón no es tan débil..."

# game/chapters/end_2.rpyc:239
translate es day7_start_kissend_0b16bee0:

    # GR "ahem."
    GR "ejem."

# game/chapters/end_2.rpyc:240
translate es day7_start_kissend_e5ed696e:

    # GR "i cannot let my feelings get in the way of my work. your soul must be taken."
    GR "no puedo dejar que mis sentimientos interfieran con mi trabajo. debo tomar tu alma."

# game/chapters/end_2.rpyc:241
translate es day7_start_kissend_271898d7:

    # GR "if... if i am not the one to take it..."
    GR "si... si no soy yo quien la toma..."

# game/chapters/end_2.rpyc:242
translate es day7_start_kissend_b25820f2:

    # GR "if i let you... go..."
    GR "si te dejo... ir..."

# game/chapters/end_2.rpyc:243
translate es day7_start_kissend_aca8da78:

    # GR "then... then... someone else would come for you."
    GR "entonces... entonces... alguien más vendría por ti."

# game/chapters/end_2.rpyc:244
translate es day7_start_kissend_4a89093e:

    # GR "and i would be terminated."
    GR "y yo sería eliminado."

# game/chapters/end_2.rpyc:248
translate es day7_start_kissend_ffba70d5:

    # player "You could hang around and protect me."
    player "Podrías quedarte y protegerme."

# game/chapters/end_2.rpyc:252
translate es day7_start_kissend_0704d523:

    # player "I can keep away your soul sickness, and you can keep other reapers away."
    player "Puedo mantener lejos tu enfermedad del alma, y tú puedes mantener alejadas a las otras parcas."

# game/chapters/end_2.rpyc:256
translate es day7_start_kissend_e9838e92:

    # player "Casper and [playerfirstname], on the run together... foreverrrrr."
    player "Casper y [playerfirstname], huyendo juntos... por siempreeee."

# game/chapters/end_2.rpyc:259
translate es day7_start_kissend_3195d961:

    # GR "i... that sounds..."
    GR "yo... eso suena..."

# game/chapters/end_2.rpyc:260
translate es day7_start_kissend_230dec51:

    # GR "...."
    GR "...."

# game/chapters/end_2.rpyc:261
translate es day7_start_kissend_afce6dd7:

    # GR "i must see this competition, this bet, through to the end."
    GR "debo ver esta competencia, esta apuesta, hasta el final."

# game/chapters/end_2.rpyc:262
translate es day7_start_kissend_7dafdbb8:

    # GR "gods know what awaits us at the end of it."
    GR "los dioses saben qué nos espera al final de todo esto."

# game/chapters/end_2.rpyc:267
translate es day7_start_kissend_31fec21a:

    # player "I know already."
    player "Yo ya lo sé."

# game/chapters/end_2.rpyc:271
translate es day7_start_kissend_134e1e38:

    # player "I win, keep your soul, and you."
    player "Gano, me quedo con tu alma, y contigo."

# game/chapters/end_2.rpyc:273
translate es day7_start_kissend_230dec51_1:

    # GR "...."
    GR "...."

# game/chapters/end_2.rpyc:274
translate es day7_start_kissend_5c7c7f55:

    # GR "..........."
    GR "..........."

# game/chapters/end_2.rpyc:275
translate es day7_start_kissend_964f4b8e:

    # GR "n-no! i will win! i am the grim reaper!"
    GR "¡n-no! ¡yo ganaré! ¡soy la parca!"

# game/chapters/end_2.rpyc:276
translate es day7_start_kissend_72e2b9eb:

    # GR "mortals... mortals fear me..."
    GR "los mortales... los mortales me temen..."

# game/chapters/end_2.rpyc:277
translate es day7_start_kissend_06732b31:

    # GR "just you wait."
    GR "ya lo verás."

# game/chapters/end_2.rpyc:281
translate es day7_start_kissend_6e77e1ba:

    # player "I don't mind waiting a little longer."
    player "No me importa esperar un poco más."

# game/chapters/end_2.rpyc:284
translate es day7_start_kissend_c42c7351:

    # player "I mean it's been a whole week already of you being unsuccessful."
    player "Quiero decir, ya ha pasado toda una semana sin que tengas éxito."

# game/chapters/end_2.rpyc:286
translate es day7_start_kissend_0bf000a4:

    # player "I guess you just spent the entire week messing around, huh?"
    player "Supongo que pasaste toda la semana perdiendo el tiempo, ¿eh?"

# game/chapters/end_2.rpyc:289
translate es day7_start_kissend_e6196131:

    # player "Can't wait to take a bite out of your soul ;)"
    player "No puedo esperar para darle un mordisco a tu alma ;)"

# game/chapters/end_2.rpyc:291
translate es day7_start_kissend_4ecb0df3:

    # GR "dream all you want, sunshine."
    GR "sueña todo lo que quieras, solecito."

# game/chapters/end_2.rpyc:292
translate es day7_start_kissend_79433d40:

    # GR "i... fully intend to keep my soul."
    GR "yo... tengo toda la intención de conservar mi alma."

# game/chapters/end_2.rpyc:296
translate es day7_start_kissend_50df4c22:

    # player "Whatever happened to 'I cannot lie.'?"
    player "¿Qué pasó con eso de 'No puedo mentir'?"

# game/chapters/end_2.rpyc:299
translate es day7_start_kissend_b6a6f505:

    # player "When did you learn how to be sarcastic btw?"
    player "Por cierto, ¿cuándo aprendiste a ser sarcástico?"

# game/chapters/end_2.rpyc:302
translate es day7_start_kissend_0485047e:

    # player "You use that to get around not being able to lie too, don't you?"
    player "Usas eso también para evitar no poder mentir, ¿verdad?"

# game/chapters/end_2.rpyc:304
translate es day7_start_kissend_a78aa4ae:

    # GR "i... have not spoken a single lie."
    GR "yo... no he dicho una sola mentira."

# game/chapters/end_2.rpyc:305
translate es day7_start_kissend_accc5d1f:

    # GR "there is... always exceptions to rules, sweetheart."
    GR "siempre hay... excepciones a las reglas, cariño."

# game/chapters/end_2.rpyc:308
translate es day7_start_kissend_941097a1:

    # player "Awww, I'm your sweetheart?"
    player "Awww, ¿soy tu cariño?"

# game/chapters/end_2.rpyc:310
translate es day7_start_kissend_ab8a9f06:

    # player "Okay, I like when you call me that."
    player "Está bien, me gusta cuando me llamas así."

# game/chapters/end_2.rpyc:313
translate es day7_start_kissend_e3211473:

    # player "That's adorable."
    player "Eso es adorable."

# game/chapters/end_2.rpyc:315
translate es day7_start_kissend_4d2eed44:

    # GR "don't... get ahead of yourself. i didn't mean it like that..."
    GR "no... te adelantes. no lo decía así..."

# game/chapters/end_2.rpyc:318
translate es day7_start_kissend_35fd99fe:

    # player "You can be my sweetheart too."
    player "Tú también puedes ser mi cariño."

# game/chapters/end_2.rpyc:320
translate es day7_start_kissend_060f4c03:

    # player "Now now Casper, no need to feel shy."
    player "Vamos, Casper, no hay necesidad de ponerse tímido."

# game/chapters/end_2.rpyc:323
translate es day7_start_kissend_25619be3:

    # player "You can call me your sweetheart if you'd like~"
    player "Puedes llamarme tu cariño si quieres~"

# game/chapters/end_2.rpyc:325
translate es day7_start_kissend_f38df6bb:

    # GR "you know what."
    GR "sabes qué."

# game/chapters/end_2.rpyc:326
translate es day7_start_kissend_b885ea68:

    # GR "maybe i should just come and take it now, after all."
    GR "quizás debería ir a tomarla ahora, después de todo."

# game/chapters/end_2.rpyc:330
translate es day7_start_kissend_888c52b1:

    # player "Aww poor Casper, still can't handle being teased?"
    player "Aww pobre Casper, ¿todavía no puedes soportar que te molesten?"

# game/chapters/end_2.rpyc:333
translate es day7_start_kissend_1d8da62b:

    # player "My little guy is so shy sometimes."
    player "Mi pequeño a veces es tan tímido."

# game/chapters/end_2.rpyc:336
translate es day7_start_kissend_02c026ae:

    # player "I'm so lucky I get to see your blushing face."
    player "Tengo tanta suerte de poder ver tu carita sonrojada."

# game/chapters/end_2.rpyc:338
translate es day7_start_kissend_ed837a1d:

    # GR "i am not blushing!"
    GR "¡no estoy sonrojado!"

# game/chapters/end_2.rpyc:339
translate es day7_start_kissend_01f89abf:

    # GR "nor can you even see me right this instant to even assume such a ridiculous thing."
    GR "ni siquiera puedes verme en este momento para asumir algo tan ridículo."

# game/chapters/end_2.rpyc:342
translate es day7_start_kissend_bb182499:

    # player "Oh please, we both know you blush super easily."
    player "Oh, por favor, los dos sabemos que te sonrojas facilísimo."

# game/chapters/end_2.rpyc:345
translate es day7_start_kissend_6d9597b8:

    # player "I could bat my eyelashes at you and you'd go bright red."
    player "Podría pestañearte un par de veces y te pondrías rojo como un tomate."

# game/chapters/end_2.rpyc:346
translate es day7_start_kissend_84aeb12f:

    # GR "ha. as if. i am... very cool. i would not do that."
    GR "ja. como si. yo soy... muy genial. no haría eso."

# game/chapters/end_2.rpyc:350
translate es day7_start_kissend_62c58b35:

    # player "When you inevitably call me later, we'll test it out."
    player "Cuando inevitablemente me llames más tarde, lo comprobaremos."

# game/chapters/end_2.rpyc:352
translate es day7_start_kissend_c6781166:

    # GR "you should not waste your final hours on something like... that."
    GR "no deberías desperdiciar tus últimas horas en algo como... eso."

# game/chapters/end_2.rpyc:355
translate es day7_start_kissend_20a05c71:

    # player "Anyhow, I think it's a good use of my time."
    player "De todos modos, creo que es un buen uso de mi tiempo."

# game/chapters/end_2.rpyc:358
translate es day7_start_kissend_457a9d7c:

    # player "In fact, maybe it's even the best use of my time."
    player "De hecho, tal vez sea el mejor uso de mi tiempo."

# game/chapters/end_2.rpyc:362
translate es day7_start_kissend_7ffd1394:

    # player "Don't steal away my fun <3"
    player "No me robes la diversión <3"

# game/chapters/end_2.rpyc:365
translate es day7_start_kissend_da896446:

    # player "We both know you like flirting awkwardly with me."
    player "Ambos sabemos que te gusta coquetear torpemente conmigo."

# game/chapters/end_2.rpyc:368
translate es day7_start_kissend_2d815487:

    # player "A pet name like 'sweetheart' seems right up your alley."
    player "Un apodo como 'cariño' te queda perfecto."

# game/chapters/end_2.rpyc:369
translate es day7_start_kissend_02f33e71:

    # GR "just because i use one pet name, does not mean that i have a liking for them."
    GR "solo porque use un apodo no significa que me gusten."

# game/chapters/end_2.rpyc:372
translate es day7_start_kissend_c1f3f381:

    # player "So you don't like them?"
    player "¿Entonces no te gustan?"

# game/chapters/end_2.rpyc:374
translate es day7_start_kissend_7772a27d_1:

    # GR "..."
    GR "..."

# game/chapters/end_2.rpyc:375
translate es day7_start_kissend_4679b7a1:

    # GR "i... am not answering your question."
    GR "yo... no voy a responder a tu pregunta."

# game/chapters/end_2.rpyc:379
translate es day7_start_kissend_ff5f8006:

    # player "You know it's okay to admit you like them right?"
    player "Sabes que está bien admitir que te gustan, ¿verdad?"

# game/chapters/end_2.rpyc:381
translate es day7_start_kissend_bebb8bc4:

    # GR "i never said i liked them."
    GR "nunca dije que me gustaran."

# game/chapters/end_2.rpyc:385
translate es day7_start_kissend_42a6ec59:

    # player "And yet you also won't say you don't."
    player "Y aun así tampoco dices que no."

# game/chapters/end_2.rpyc:388
translate es day7_start_kissend_23009075:

    # player "So which is it?"
    player "Entonces, ¿cuál es?"

# game/chapters/end_2.rpyc:389
translate es day7_start_kissend_a8de0b43:

    # GR "my answer is..."
    GR "mi respuesta es..."

# game/chapters/end_2.rpyc:390
translate es day7_start_kissend_ebc9eb7a_1:

    # GR "yes."
    GR "sí."

# game/chapters/end_2.rpyc:393
translate es day7_start_kissend_96728cfe:

    # player "You like them?"
    player "¿Te gustan?"

# game/chapters/end_2.rpyc:394
translate es day7_start_kissend_5e9315e6:

    # GR "like is... such a strong word."
    GR "'gustar' es... una palabra muy fuerte."

# game/chapters/end_2.rpyc:398
translate es day7_start_kissend_00f5e71c:

    # player "You called me sweetheart first! Deal with it, {i}my love{/i}~"
    player "¡Tú me llamaste cariño primero! Así que aguántate, {i}mi amor{/i}~"

# game/chapters/end_2.rpyc:399
translate es day7_start_kissend_f96cdb11:

    # GR "hells..."
    GR "demonios..."

# game/chapters/end_2.rpyc:402
translate es day7_start_kissend_cb067497:

    # player "C'mon {i}Honey{/i}, no need to be so shy."
    player "Vamos {i}cielito{/i}, no tienes que ser tan tímido."

# game/chapters/end_2.rpyc:403
translate es day7_start_kissend_7772a27d_2:

    # GR "..."
    GR "..."

# game/chapters/end_2.rpyc:404
translate es day7_start_kissend_f48582ce:

    # GR "shut... shut that mortal mouth of yours..."
    GR "cierra... cierra esa boca mortal tuya..."

# game/chapters/end_2.rpyc:405
translate es day7_start_kissend_77d70c09:

    # GR "i... you can't just... come out and call me that..."
    GR "yo... no puedes simplemente... venir y llamarme así..."

# game/chapters/end_2.rpyc:408
translate es day7_start_kissend_d9a5ae13:

    # player "I can feel you blushing from the other side of my computer screen."
    player "Puedo sentir que te sonrojas desde el otro lado de mi pantalla."

# game/chapters/end_2.rpyc:411
translate es day7_start_kissend_0255b951:

    # player "{i}Darling{/i}."
    player "{i}Querido{/i}."

# game/chapters/end_2.rpyc:412
translate es day7_start_kissend_8b171bd8:

    # GR "that's it."
    GR "eso fue todo."

# game/chapters/end_2.rpyc:413
translate es day7_start_kissend_79151ca1:

    # GR "i'm changing your nickname."
    GR "voy a cambiarte el apodo."

# game/chapters/end_2.rpyc:416
translate es day7_start_kissend_eea111d5:

    # player "Oh???"
    player "¿¿¿Oh???"

# game/chapters/end_2.rpyc:419
translate es day7_start_kissend_c2ed9588:

    # player "I can't wait to see what you come up with~"
    player "No puedo esperar a ver con qué sales~"

# game/chapters/end_2.rpyc:421
translate es day7_start_kissend_c0b6e70b:

    # player "I hope it's as cute as 'sweetheart'."
    player "Espero que sea tan lindo como 'cariño'."

# game/chapters/end_2.rpyc:422
translate es day7_start_kissend_385316c1:

    # GR "you are truly... a nightmare."
    GR "realmente eres... una pesadilla."

# game/chapters/end_2.rpyc:423
translate es day7_start_kissend_c4c1b972:

    # GR "nightmare..."
    GR "pesadilla..."

# game/chapters/end_2.rpyc:424
translate es day7_start_kissend_d17c097c:

    # GR "my little nightmare."
    GR "mi pequeña pesadilla."

# game/chapters/end_2.rpyc:427
translate es day7_start_kissend_03775ec8_1:

    # player "..."
    player "..."

# game/chapters/end_2.rpyc:430
translate es day7_start_kissend_9e8eed0c:

    # player "For a second it was insulting, but then you added the 'my'."
    player "Por un segundo fue insultante, pero luego añadiste el 'mi'."

# game/chapters/end_2.rpyc:433
translate es day7_start_kissend_f8df01d9:

    # player "And now I kind of like it."
    player "Y ahora como que me gusta."

# game/chapters/end_2.rpyc:434
translate es day7_start_kissend_e3cfc3c0:

    # GR "lets... stick with sunshine."
    GR "quedémonos... con solecito."

# game/chapters/end_2.rpyc:437
translate es day7_start_kissend_ba4f73b0:

    # player "I don't mind which you use."
    player "No me importa cuál uses."

# game/chapters/end_2.rpyc:440
translate es day7_start_kissend_ef08de0a:

    # player "Use either."
    player "Usa cualquiera."

# game/chapters/end_2.rpyc:443
translate es day7_start_kissend_ad1c504a:

    # player "Use both!"
    player "¡Usa ambos!"

# game/chapters/end_2.rpyc:444
translate es day7_start_kissend_5f29d4ab:

    # GR "right..."
    GR "claro..."

# game/chapters/end_2.rpyc:449
translate es day7_start_kissend_88d37c7f:

    # player "Use nightmare!"
    player "¡Usa pesadilla!"

# game/chapters/end_2.rpyc:452
translate es day7_start_kissend_07ec9c8c:

    # player "It suits me, and it's hilarious!"
    player "¡Me queda bien y es divertidísimo!"

# game/chapters/end_2.rpyc:453
translate es day7_start_kissend_99bc6dcb:

    # GR "if you... say so."
    GR "si tú... lo dices."

# game/chapters/end_2.rpyc:454
translate es day7_start_kissend_7928bafe:

    # GR "you really are strange beyond words..."
    GR "realmente eres un bicho raro más de lo que las palabras pueden describir..."

# game/chapters/end_2.rpyc:457
translate es day7_start_kissend_97851806:

    # player "Sunshine it is!"
    player "¡Entonces Solecito será!"

# game/chapters/end_2.rpyc:460
translate es day7_start_kissend_6e851708:

    # player "I feel attached to that one."
    player "Me encariñé con ese."

# game/chapters/end_2.rpyc:461
translate es day7_start_kissend_af49aab8:

    # GR "it does seem to be the best fit."
    GR "parece ser el que mejor encaja."

# game/chapters/end_2.rpyc:462
translate es day7_start_kissend_7f421d19:

    # GR "and nightmare seems to contradict that somewhat."
    GR "y pesadilla parece contradecir eso un poco."

# game/chapters/end_2.rpyc:465
translate es day7_start_kissend_8a4d97a2:

    # player "Mmm."
    player "Mmm."

# game/chapters/end_2.rpyc:468
translate es day7_start_kissend_3bcf59b8:

    # player "And Sunshine sounds extra cute when you say it."
    player "Y 'Solecito' suena especialmente tierno cuando tú lo dices."

# game/chapters/end_2.rpyc:471
translate es day7_start_kissend_dd74afb7:

    # player "Very domestic of you."
    player "Muy hogareño de tu parte."

# game/chapters/end_2.rpyc:472
translate es day7_start_kissend_5f29d4ab_1:

    # GR "right..."
    GR "claro..."

# game/chapters/end_2.rpyc:475
translate es day7_start_kissend_06361183:

    # player "Well, since you've so graciously given me a few more hours..."
    player "Bueno, ya que me has concedido tan amablemente unas horas más..."

# game/chapters/end_2.rpyc:478
translate es day7_start_kissend_ec15d1be:

    # player "What are you actually doing, considering you aren't reaping my soul?"
    player "¿Qué estás haciendo realmente, teniendo en cuenta que no estás cosechando mi alma?"

# game/chapters/end_2.rpyc:479
translate es day7_start_kissend_ff97fc15:

    # GR "nothing much."
    GR "nada en especial."

# game/chapters/end_2.rpyc:480
translate es day7_start_kissend_9c751597:

    # GR "contemplating. thinking. it is not going very well."
    GR "contemplando. pensando. no va muy bien."

# game/chapters/end_2.rpyc:483
translate es day7_start_kissend_ef6b45b5:

    # player "Ohhhh, that's deep."
    player "Ohhhh, qué profundo."

# game/chapters/end_2.rpyc:486
translate es day7_start_kissend_49aa1b3c:

    # player "Thinking about me, huh?"
    player "Pensando en mí, ¿eh?"

# game/chapters/end_2.rpyc:487
translate es day7_start_kissend_27f62b92:

    # GR "why would i ever do that?"
    GR "¿por qué haría eso?"

# game/chapters/end_2.rpyc:490
translate es day7_start_kissend_73bfe6dd:

    # player "Because you liiiiike me."
    player "Porque te guuuusto."

# game/chapters/end_2.rpyc:491
translate es day7_start_kissend_949f2162:

    # GR "......."
    GR "......."

# game/chapters/end_2.rpyc:494
translate es day7_start_kissend_4d0131e1:

    # player "That seems unlike you."
    player "Eso no suena como tú."

# game/chapters/end_2.rpyc:497
translate es day7_start_kissend_c4353818:

    # player "Is there something wrong today?"
    player "¿Pasa algo hoy?"

# game/chapters/end_2.rpyc:498
translate es day7_start_kissend_1d1a50a5:

    # GR "to be totally honest with you?"
    GR "¿quieres que sea totalmente honesto contigo?"

# game/chapters/end_2.rpyc:499
translate es day7_start_kissend_ed7b6cb2:

    # GR "everything is wrong today and every part of my mind is fighting with itself."
    GR "todo está mal hoy y cada parte de mi mente está peleando consigo misma."

# game/chapters/end_2.rpyc:503
translate es day7_start_kissend_4783caa6:

    # player "Sounds tough, buddy."
    player "Suena difícil, amigo."

# game/chapters/end_2.rpyc:505
translate es day7_start_kissend_e25db5d1:

    # GR "it is tough, yes."
    GR "sí, lo es."

# game/chapters/end_2.rpyc:508
translate es day7_start_kissend_e0aacc1d:

    # GR "shall we take this conversation to a call, little nightmare of mine?"
    GR "¿llevamos esta conversación a una llamada, mi pequeña pesadilla?"

# game/chapters/end_2.rpyc:510
translate es day7_start_kissend_6ba29352:

    # GR "shall we take this conversation to a call, sunshine?"
    GR "¿llevamos esta conversación a una llamada, solecito?"

# game/chapters/end_2.rpyc:514
translate es day7_start_kissend_fbc9f02b:

    # player "Miss my [pretty] face, do you?"
    player "¿Extrañas mi bonita cara , eh?"

# game/chapters/end_2.rpyc:516
translate es day7_start_kissend_c15b59f8:

    # player "Wanna hear my voice that badly?"
    player "¿Tanto te apetece escuchar mi voz?"

# game/chapters/end_2.rpyc:518
translate es day7_start_kissend_0740318c:

    # player "Anything you want, babygirl~"
    player "Lo que quieras, babygirl~"

# game/chapters/end_2.rpyc:521
translate es day7_start_kissend_70b93071:

    # player "Who am I to deny such a request!"
    player "¿Quién soy yo para negarme a tal petición?"

# game/chapters/end_2.rpyc:555
translate es call1_daykissend_2c195dab:

    # GRC "Well, you're certainly full of energy."
    GRC "Bueno, sin duda tienes mucha energía."

# game/chapters/end_2.rpyc:556
translate es call1_daykissend_baa3141f:

    # GRC "That excited at the prospect of talking to me?"
    GRC "¿Te ha entusiasmado la posibilidad de hablar conmigo?"

# game/chapters/end_2.rpyc:562
translate es call1_daykissend_637efc44:

    # GRC "I'd call you a liar, but you actually sound like you're telling the truth."
    GRC "Diría que mientes, pero en realidad suenas como si dijeras la verdad."

# game/chapters/end_2.rpyc:566
translate es call1_daykissend_8a40b11e:

    # GRC "Hello, Sunshine."
    GRC "Hola, Solecito."

# game/chapters/end_2.rpyc:567
translate es call1_daykissend_5ad02d39:

    # GRC "It is good to see you admitting to my good looks."
    GRC "Es bueno verte admitir que soy guapo."

# game/chapters/end_2.rpyc:578
translate es call1_daykissend_c823b7e2:

    # GRC "That sounds fake as fuck."
    GRC "Eso suena falsísimo."

# game/chapters/end_2.rpyc:584
translate es call1_daykissend_35be16ee:

    # GRC "And 'crush'? I am not a child..."
    GRC "¿Y 'crush'? No soy un niño..."

# game/chapters/end_2.rpyc:586
translate es call1_daykissend_839ddd8a:

    # GRC "...You look... nice... today..."
    GRC "...Te ves... bien... hoy..."

# game/chapters/end_2.rpyc:595
translate es call1_daykissend_8c6a9883:

    # GRC "Don't say my name like that..."
    GRC "No digas mi nombre así..."

# game/chapters/end_2.rpyc:603
translate es call1_daykissend_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/end_2.rpyc:607
translate es call1_daykissend_99ed60c3:

    # GRC "I... I am... unused to such attention..."
    GRC "Yo... yo no estoy acostumbrado a tanta atención..."

# game/chapters/end_2.rpyc:609
translate es call1_daykissend_4dd2d39f:

    # GRC "I don't... usually go around getting to know my prey."
    GRC "No suelo... ir por ahí conociendo a mis presas."

# game/chapters/end_2.rpyc:618
translate es call1_daykissend_7b11fe43:

    # GRC "It pains me that I cannot argue with that..."
    GRC "Me duele no poder discutir eso..."

# game/chapters/end_2.rpyc:630
translate es call1_daykissend_1756d874:

    # GRC "...Fine."
    GRC "...Está bien."

# game/chapters/end_2.rpyc:632
translate es call1_daykissend_177a5f76:

    # GRC "If you must know, I was doing my skincare routine. While thinking about you. I mean, about your soul."
    GRC "Si quieres saberlo, estaba haciendo mi rutina de skincare. Mientras pensaba en ti. Quiero decir, en tu alma."

# game/chapters/end_2.rpyc:635
translate es call1_daykissend_4c87ce04:

    # GRC "It's important to maintain a good complexion."
    GRC "Es importante mantener una buena complexión."

# game/chapters/end_2.rpyc:643
translate es call1_daykissend_0b19cf61:

    # GRC "Exactly!"
    GRC "¡Exactamente!"

# game/chapters/end_2.rpyc:650
translate es call1_daykissend_f9350920:

    # GRC "Of course I do."
    GRC "Por supuesto que sí."

# game/chapters/end_2.rpyc:651
translate es call1_daykissend_07115148:

    # GRC "It should be obvious that I care about my looks."
    GRC "Debería ser obvio que me preocupo por mi aspecto."

# game/chapters/end_2.rpyc:655
translate es call1_daykissend_eaa0c83b:

    # GRC "Please tell me you're joking?"
    GRC "Por favor dime que estás bromeando."

# game/chapters/end_2.rpyc:663
translate es call1_daykissend_9eeb6b23:

    # GRC "That is abysmal."
    GRC "Eso es terrible."

# game/chapters/end_2.rpyc:664
translate es call1_daykissend_643a1664:

    # GRC "I will be correcting that."
    GRC "Voy a corregirlo."

# game/chapters/end_2.rpyc:670
translate es call1_daykissend_3b8672b3:

    # GRC "Twice a day."
    GRC "Dos veces al día."

# game/chapters/end_2.rpyc:671
translate es call1_daykissend_ee434647:

    # GRC "Cleanse, tone, serum, eye cream, day cream, sunscreen in the morning."
    GRC "Limpiar, tonificar, suero, contorno de ojos, crema de día, protector solar por la mañana."

# game/chapters/end_2.rpyc:672
translate es call1_daykissend_3fef97c4:

    # GRC "Then cleanse, mask, tone, serum, eye cream, night cream in the evening."
    GRC "Luego limpiar, mascarilla, tonificar, suero, contorno de ojos, crema de noche por la tarde."

# game/chapters/end_2.rpyc:682
translate es call1_daykissend_ef704d8c:

    # GRC "Not surprising."
    GRC "No me sorprende."

# game/chapters/end_2.rpyc:684
translate es call1_daykissend_4e143898:

    # GRC "Perhaps I would... allow you to touch."
    GRC "Quizás te... permitiría tocar."

# game/chapters/end_2.rpyc:685
translate es call1_daykissend_fcbe83c8:

    # GRC "But this is... well, as much as I enjoy talking about skincare..."
    GRC "Pero esto es... bueno, por más que me guste hablar de cuidado facial..."

# game/chapters/end_2.rpyc:686
translate es call1_daykissend_584e8ee8:

    # GRC "There is something more important on my mind."
    GRC "Hay algo más importante en mi mente."

# game/chapters/end_2.rpyc:692
translate es call1_daykissend_89cd4cb1:

    # GRC "...You."
    GRC "...Tú."

# game/chapters/end_2.rpyc:693
translate es call1_daykissend_1b272866:

    # GRC "There is... a decision I am thinking over."
    GRC "Hay... una decisión que estoy considerando."

# game/chapters/end_2.rpyc:694
translate es call1_daykissend_cf54a56f:

    # GRC "One that is very..."
    GRC "Una que es muy..."

# game/chapters/end_2.rpyc:696
translate es call1_daykissend_13c8763f:

    # GRC "Important?"
    GRC "¿Importante?"

# game/chapters/end_2.rpyc:697
translate es call1_daykissend_7f29a528:

    # GRC "Life altering, if you will."
    GRC "Que cambiaría mi vida, por así decirlo."

# game/chapters/end_2.rpyc:701
translate es call1_daykissend_32f44438:

    # GRC "Yes."
    GRC "Sí."

# game/chapters/end_2.rpyc:702
translate es call1_daykissend_6ad28ec5:

    # GRC "It is not something I should consider, and yet..."
    GRC "No es algo que debería considerar, y aun así..."

# game/chapters/end_2.rpyc:703
translate es call1_daykissend_8d99c3f0:

    # GRC "I'm thinking about it anyway."
    GRC "Lo estoy pensando de todos modos."

# game/chapters/end_2.rpyc:704
translate es call1_daykissend_b4afa4ae:

    # GRC "Considering it. Weighing my options."
    GRC "Considerándolo. Considerando mis opciones."

# game/chapters/end_2.rpyc:710
translate es call1_daykissend_43936eb7:

    # GRC "Something entirely foolish."
    GRC "Algo completamente tonto."

# game/chapters/end_2.rpyc:712
translate es call1_daykissend_93264625:

    # GRC "But perhaps I'm more of a fool than I first thought..."
    GRC "Pero quizás soy más tonto de lo que pensaba..."

# game/chapters/end_2.rpyc:716
translate es call1_daykissend_e5e4f986:

    # GRC "I am thinking of doing something stupid, yes."
    GRC "Estoy pensando en hacer algo estúpido, sí."

# game/chapters/end_2.rpyc:723
translate es call1_daykissend_c3433993:

    # GRC "It will put me in the most trouble I could be in."
    GRC "Me meterá en el mayor problema posible."

# game/chapters/end_2.rpyc:731
translate es call1_daykissend_a49dd7a9:

    # GRC "Speak not a word of this to another soul."
    GRC "No digas ni una palabra de esto a otra alma."

# game/chapters/end_2.rpyc:732
translate es call1_daykissend_d10e574d:

    # GRC "Because it will not only get me in trouble, but you as well."
    GRC "Porque no solo me meterá en problemas a mí, sino también a ti."

# game/chapters/end_2.rpyc:734
translate es call1_daykissend_24c30802:

    # GRC "This is... a choice just for the two of us."
    GRC "Esta es... una decisión solo para los dos."

# game/chapters/end_2.rpyc:739
translate es call1_daykissend_eda1e6bf:

    # GRC "Do you understand?"
    GRC "¿Lo entiendes?"

# game/chapters/end_2.rpyc:743
translate es call1_daykissend_a9f371d2:

    # GRC "...Fuck."
    GRC "...Maldición."

# game/chapters/end_2.rpyc:744
translate es call1_daykissend_ea5b2164:

    # GRC "I'm thinking about... breaking protocol."
    GRC "Estoy pensando en... romper el protocolo."

# game/chapters/end_2.rpyc:749
translate es call1_daykissend_a8640369:

    # GRC "I mean, I'm thinking of refusing to collect your soul."
    GRC "Quiero decir, estoy pensando en negarme a recolectar tu alma."

# game/chapters/end_2.rpyc:750
translate es call1_daykissend_2b53b5de:

    # GRC "Refusing to collect any more, at all..."
    GRC "Negarme a recolectar cualquiera más, en absoluto..."

# game/chapters/end_2.rpyc:753
translate es call1_daykissend_59bd682c:

    # GRC "I have never heard of one of my kind 'quitting' before."
    GRC "Nunca he oído de alguien de los míos que 'renuncie'."

# game/chapters/end_2.rpyc:754
translate es call1_daykissend_3da7c4b2:

    # GRC "You either work, or are terminated."
    GRC "O trabajas, o te eliminan."

# game/chapters/end_2.rpyc:755
translate es call1_daykissend_97daabe5:

    # GRC "But I am capable of making my own decisions... for better or worse."
    GRC "Pero soy capaz de tomar mis propias decisiones... para bien o para mal."

# game/chapters/end_2.rpyc:758
translate es call1_daykissend_02ca2471:

    # GRC "I do not recall any case where a reaper has not collected what was due."
    GRC "No recuerdo ningún caso donde una parca no haya recogido lo que se le debía."

# game/chapters/end_2.rpyc:760
translate es call1_daykissend_775248fd:

    # GRC "But I have free will."
    GRC "Pero tengo libre albedrío."

# game/chapters/end_2.rpyc:762
translate es call1_daykissend_9739c76d:

    # GRC "So I would say it is something I am capable of doing, yes."
    GRC "Así que diría que es algo que soy capaz de hacer, sí."

# game/chapters/end_2.rpyc:769
translate es call1_daykissend_210fda16:

    # GRC "Because of you."
    GRC "Por ti."

# game/chapters/end_2.rpyc:772
translate es call1_daykissend_e16f9ab5:

    # GRC "I'm thinking about it because of you, my Little Nightmare."
    GRC "Estoy pensándolo por ti, mi pequeña Pesadilla."

# game/chapters/end_2.rpyc:775
translate es call1_daykissend_8558dfcb:

    # GRC "I'm thinking about it because of you, Sunshine."
    GRC "Estoy pensándolo por ti, Solecito."

# game/chapters/end_2.rpyc:780
translate es call1_daykissend_49e5235b:

    # GRC "...You've always gotten me into trouble. Perhaps I... don't mind."
    GRC "...Siempre logras meterme en problemas. Quizás... no me importe."

# game/chapters/end_2.rpyc:782
translate es call1_daykissend_7e4d516f:

    # GRC "If I do this, then it's because it is something I want. For myself."
    GRC "Si hago esto, será porque es algo que quiero. Para mí."

# game/chapters/end_2.rpyc:783
translate es call1_daykissend_4841cb76:

    # GRC "And I... quite like the sound of doing whatever I want for a change."
    GRC "Y... me gusta la idea de hacer lo que quiera, por una vez."

# game/chapters/end_2.rpyc:785
translate es call1_daykissend_8379017c:

    # GRC "Not having to follow some... set of rules I was destined to follow."
    GRC "No tener que seguir un... conjunto de reglas que estaba destinado a cumplir."

# game/chapters/end_2.rpyc:789
translate es call1_daykissend_230a3197:

    # GRC "How is that throwing my life away?"
    GRC "¿Cómo es eso desperdiciar mi vida?"

# game/chapters/end_2.rpyc:791
translate es call1_daykissend_49b9734f:

    # GRC "It sounds like starting a     new life to me."
    GRC "A mí me suena a empezar una nueva."

# game/chapters/end_2.rpyc:793
translate es call1_daykissend_c86f6a93:

    # GRC "One where I can make all the choices I want."
    GRC "Una donde pueda tomar todas las decisiones que quiera."

# game/chapters/end_2.rpyc:794
translate es call1_daykissend_0997312c:

    # GRC "One where I can follow my own set of rules."
    GRC "Una donde pueda seguir mis propias reglas."

# game/chapters/end_2.rpyc:799
translate es call1_daykissend_f255bf57:

    # GRC "I... I think you're right."
    GRC "Yo... creo que tienes razón."

# game/chapters/end_2.rpyc:802
translate es call1_daykissend_28e3c646:

    # GRC "Why?"
    GRC "¿Por qué?"

# game/chapters/end_2.rpyc:804
translate es call1_daykissend_561bbf4e:

    # GRC "Because I... want to."
    GRC "Porque... quiero hacerlo."

# game/chapters/end_2.rpyc:805
translate es call1_daykissend_86a171c4:

    # GRC "It's... nice. To want to do something... just for myself."
    GRC "Es... agradable. Querer hacer algo... solo por mí mismo."

# game/chapters/end_2.rpyc:808
translate es call1_daykissend_b0c4d38e:

    # GRC "But..."
    GRC "Pero..."

# game/chapters/end_2.rpyc:810
translate es call1_daykissend_454b08fb:

    # GRC "If it's... just a one-sided wish, even I wouldn't be arrogant enough to force it on you."
    GRC "Si es... solo un deseo unilateral, ni siquiera yo sería tan arrogante como para imponértelo."

# game/chapters/end_2.rpyc:811
translate es call1_daykissend_8da23161:

    # GRC "...."
    GRC "...."

# game/chapters/end_2.rpyc:813
translate es call1_daykissend_fc974764:

    # GRC "If you... just a few words, and I... would throw everything away. For you."
    GRC "Si tú... solo dijeras unas pocas palabras, y yo... lo dejaría todo. Por ti."

# game/chapters/end_2.rpyc:829
translate es call1_daykissend_55bdc250:

    # GRC "......"
    GRC "......"

# game/chapters/end_2.rpyc:833
translate es call1_daykissend_f6ab0b71:

    # GRC "You... really...? About... me?"
    GRC "¿Tú... de verdad...? ¿Por... mí?"

# game/chapters/end_2.rpyc:845
translate es call1_daykissend_55bdc250_1:

    # GRC "......"
    GRC "......"

# game/chapters/end_2.rpyc:859
translate es call1_daykissend_4e2cabb5:

    # GRC "If I came over right now, would you open the window?"
    GRC "Si viniera ahora mismo, ¿abrirías la ventana?"

# game/chapters/end_2.rpyc:872
translate es call1_daykissend_fceab151:

    # GRC "Perfect."
    GRC "Perfecto."

# game/chapters/end_2.rpyc:876
translate es call1_daykissend_a5fad84b:

    # GRC "It's hardly sneaking if I {i}just{/i} let you know I'd be coming."
    GRC "No es hacerme el misterioso si {i}simplemente{/i} te aviso de que voy a ir."

# game/chapters/end_2.rpyc:885
translate es call1_daykissend_7c04bc16:

    # GRC "As soon as I hang up."
    GRC "Tan pronto como cuelgue."

# game/chapters/end_2.rpyc:886
translate es call1_daykissend_da814107:

    # GRC "I'll come right on over."
    GRC "Iré directamente."

# game/chapters/end_2.rpyc:888
translate es call1_daykissend_b0c4d38e_1:

    # GRC "But..."
    GRC "Pero..."

# game/chapters/end_2.rpyc:889
translate es call1_daykissend_6ad9b17c:

    # GRC "I know you just joked about running away together, but..."
    GRC "Sé que acabas de bromear con lo de huir juntos, pero..."

# game/chapters/end_2.rpyc:890
translate es call1_daykissend_4a162d04:

    # GRC "I will REALLY effectively be on the run."
    GRC "Yo REALMENTE estaré huyendo."

# game/chapters/end_2.rpyc:891
translate es call1_daykissend_150503c5:

    # GRC "I cannot stay here."
    GRC "No puedo quedarme aquí."

# game/chapters/end_2.rpyc:899
translate es call1_daykissend_6f530def:

    # GRC "Do you... have a couch?"
    GRC "¿Tienes un sofá?"

# game/chapters/end_2.rpyc:902
translate es call1_daykissend_325880bd:

    # GRC "Why not?"
    GRC "¿Por qué no?"

# game/chapters/end_2.rpyc:903
translate es call1_daykissend_fffd860b:

    # GRC "You'll open the window for me, but not let me sleep on a couch?"
    GRC "¿Abrirás la ventana para mí, pero no me dejarás dormir en un sofá?"

# game/chapters/end_2.rpyc:910
translate es call1_daykissend_55d4264f:

    # GRC "That's... lovely."
    GRC "Eso es... encantador."

# game/chapters/end_2.rpyc:911
translate es call1_daykissend_c98beba7:

    # GRC "But I'm talking about a place I can sleep."
    GRC "Pero hablo de un lugar donde pueda dormir."

# game/chapters/end_2.rpyc:921
translate es call1_daykissend_ece2b1ab:

    # GRC "I know that."
    GRC "Lo sé."

# game/chapters/end_2.rpyc:922
translate es call1_daykissend_a6663ab6:

    # GRC "But I'm talking about a place where {i}I{/i} can sleep."
    GRC "Pero hablo de un lugar donde {i}yo{/i} pueda dormir."

# game/chapters/end_2.rpyc:936
translate es call1_daykissend_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/end_2.rpyc:937
translate es call1_daykissend_10cf39a7:

    # GRC "You want to sleep in the same bed?"
    GRC "¿Quieres dormir en la misma cama?"

# game/chapters/end_2.rpyc:953
translate es call1_daykissend_22797cc2:

    # GRC "That we did..."
    GRC "Que nosotros..."

# game/chapters/end_2.rpyc:957
translate es call1_daykissend_cdd2de14:

    # GRC "I'm... comfortable with it."
    GRC "Estoy... cómodo con eso."

# game/chapters/end_2.rpyc:958
translate es call1_daykissend_5dfc0760:

    # GRC "Are you... sure?"
    GRC "¿Estás... seguro?"

# game/chapters/end_2.rpyc:975
translate es call1_daykissend_55274627:

    # GRC "I cannot believe you."
    GRC "No puedo creerte."

# game/chapters/end_2.rpyc:976
translate es call1_daykissend_5d3e7b2d:

    # GRC "You literally just invited someone who was trying to actively kill you into your bed."
    GRC "Literalmente acabas de invitar a alguien que intentaba matarte activamente a tu cama."

# game/chapters/end_2.rpyc:983
translate es call1_daykissend_27e0f302:

    # GRC "No, I suppose I'm not."
    GRC "No, supongo que no."

# game/chapters/end_2.rpyc:984
translate es call1_daykissend_548992ef:

    # GRC "Gods, what am I doing...?"
    GRC "Dioses, ¿qué estoy haciendo...?"

# game/chapters/end_2.rpyc:990
translate es call1_daykissend_51338533:

    # GRC "It's a strange thought... but it also makes me excited."
    GRC "Es un pensamiento extraño... pero también me emociona."

# game/chapters/end_2.rpyc:997
translate es call1_daykissend_4e7bfbb5:

    # GRC "Following my heart..."
    GRC "Seguir a mi corazón..."

# game/chapters/end_2.rpyc:998
translate es call1_daykissend_fd23873c:

    # GRC "And letting myself dream."
    GRC "Y permitirme soñar."

# game/chapters/end_2.rpyc:1002
translate es call1_daykissend_6aee33ae:

    # GRC "It sounds... terrifying."
    GRC "Suena... aterrador."

# game/chapters/end_2.rpyc:1003
translate es call1_daykissend_2a10f2d9:

    # GRC "But perfect."
    GRC "Pero perfecto."

# game/chapters/end_2.rpyc:1010
translate es call1_daykissend_ba72d308:

    # GRC "I never thought I would..."
    GRC "Nunca pensé que..."

# game/chapters/end_2.rpyc:1011
translate es call1_daykissend_879b2bbf:

    # GRC "Get the chance to even think about something like that..."
    GRC "Tendría la oportunidad de siquiera pensar en algo así..."

# game/chapters/end_2.rpyc:1015
translate es call1_daykissend_693474cd:

    # GRC "Leave the window open, okay?"
    GRC "Deja la ventana abierta, ¿de acuerdo?"

# game/chapters/end_2.rpyc:1017
translate es call1_daykissend_ccb02ea0:

    # GRC "I'll see you soon, my Little Nightmare."
    GRC "Te veré pronto, mi pequeña Pesadilla."

# game/chapters/end_2.rpyc:1019
translate es call1_daykissend_a696847f:

    # GRC "I'll see you soon, Sunshine."
    GRC "Te veré pronto, Solecito."

# game/chapters/end_2.rpyc:1046
translate es chat2_daykissend_edbf32b3:

    # "The sun shines beautifully through your unlocked window."
    "El sol brilla hermosamente a través de tu ventana sin cerrar."

# game/chapters/end_2.rpyc:1047
translate es chat2_daykissend_c1528caf:

    # "You stand and walk towards your bed, and you can't help but think..."
    "Te levantas y caminas hacia tu cama, y no puedes evitar pensar..."

# game/chapters/end_2.rpyc:1048
translate es chat2_daykissend_bf78d61a:

    # "Today is a good day to be alive."
    "Hoy es un buen día para estar vivo."

# game/chapters/end_2.rpyc:1049
translate es chat2_daykissend_66022229:

    # "It doesn't take long for the sound of your window being shifted pulls you out of your head."
    "No pasa mucho tiempo antes de que el sonido de tu ventana moviéndose te saque de tus pensamientos."

# game/chapters/end_2.rpyc:1050
translate es chat2_daykissend_08847dae:

    # "There you see the prettiest, sweetest, stupidest, dumbest man you have ever met."
    "Allí ves al hombre más lindo, dulce, estúpido y tonto que jamás has conocido."

# game/chapters/end_2.rpyc:1051
translate es chat2_daykissend_4a8f53ac:

    # "Your heart swells, and your body moves before you can even think."
    "Tu corazón se llena de emoción y tu cuerpo se mueve antes de que puedas siquiera pensar."

# game/chapters/end_2.rpyc:1058
translate es chat2_daykissend_1dc1b57f:

    # GRC "[playerfirstname]."
    GRC "[playerfirstname]."

# game/chapters/end_2.rpyc:1059
translate es chat2_daykissend_cd305772:

    # GRC "You really did leave it open for me."
    GRC "De verdad me la dejaste abierta."

# game/chapters/end_2.rpyc:1060
translate es chat2_daykissend_351d8517:

    # GRC "And you even cleaned off the desk-"
    GRC "Y hasta limpiaste el escritorio—"

# game/chapters/end_2.rpyc:1076
translate es chat2_daykissend_0a2c4bf7:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/end_2.rpyc:1080
translate es chat2_daykissend_6cbcaddf:

    # GRC "How... how very forward of my mortal..."
    GRC "Qué... qué atrevido de parte de mi mortal..."

# game/chapters/end_2.rpyc:1081
translate es chat2_daykissend_f8127622:

    # GRC "When you said you didn't mind sharing the bed, I didn't expect you to push me down so... suddenly."
    GRC "Cuando dijiste que no te importaba compartir la cama, no esperaba que me empujaras así... tan de repente."

# game/chapters/end_2.rpyc:1088
translate es chat2_daykissend_d82e800a:

    # GRC "Cheeky little..."
    GRC "Qué descaro..."

# game/chapters/end_2.rpyc:1089
translate es chat2_daykissend_87305b47:

    # GRC "I know you said you were fine with sharing the bed..."
    GRC "Sé que dijiste que te parecía bien compartir la cama..."

# game/chapters/end_2.rpyc:1090
translate es chat2_daykissend_e9f6064f:

    # GRC "But I didn't expect you to..."
    GRC "Pero no esperaba que tú..."

# game/chapters/end_2.rpyc:1094
translate es chat2_daykissend_12718cc3:

    # GRC "I... had no clue."
    GRC "No... no tenía ni idea."

# game/chapters/end_2.rpyc:1095
translate es chat2_daykissend_d9978887:

    # GRC "I had a small thought that you were pulling some elaborate joke."
    GRC "Pensé por un momento que era una especie de broma elaborada."

# game/chapters/end_2.rpyc:1096
translate es chat2_daykissend_c52d3004:

    # GRC "That I would arrive here and you would be... gone."
    GRC "Que llegaría aquí y tú... ya no estarías."

# game/chapters/end_2.rpyc:1097
translate es chat2_daykissend_325b1edc:

    # GRC "But you're here."
    GRC "Pero estás aquí."

# game/chapters/end_2.rpyc:1103
translate es chat2_daykissend_2cd661f5:

    # GRC "This advance is... not unwelcome."
    GRC "Este atrevimiento... no es desagradable."

# game/chapters/end_2.rpyc:1108
translate es chat2_daykissend_0a2c4bf7_1:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/end_2.rpyc:1112
translate es chat2_daykissend_b2742a6f:

    # GRC "Shut up."
    GRC "Cállate."

# game/chapters/end_2.rpyc:1130
translate es chat2_daykissend_07ab7154:

    # GRC "...What?"
    GRC "...¿Qué?"

# game/chapters/end_2.rpyc:1136
translate es chat2_daykissend_166e097c:

    # GRC "You're STILL going on about that?!"
    GRC "¡¿Todavía SIGUES con eso?!"

# game/chapters/end_2.rpyc:1137
translate es chat2_daykissend_d16e5fa5:

    # GRC "It's not a thing!"
    GRC "¡No es algo real!"

# game/chapters/end_2.rpyc:1138
translate es chat2_daykissend_2b7a7356:

    # GRC "I don't even know what a soul baby is!"
    GRC "¡Ni siquiera sé qué es un bebé alma!"

# game/chapters/end_2.rpyc:1145
translate es chat2_daykissend_91330efa:

    # GRC "Ugh..."
    GRC "Ugh..."

# game/chapters/end_2.rpyc:1148
translate es chat2_daykissend_939e5287:

    # GRC "Maybe this was a..."
    GRC "Quizás esto fue una..."

# game/chapters/end_2.rpyc:1155
translate es chat2_daykissend_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/end_2.rpyc:1160
translate es chat2_daykissend_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/end_2.rpyc:1161
translate es chat2_daykissend_7a216b50:

    # GRC "I want to hate you so badly."
    GRC "Quiero odiarte tanto."

# game/chapters/end_2.rpyc:1171
translate es chat2_daykissend_0a2c4bf7_2:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/end_2.rpyc:1177
translate es chat2_daykissend_ad0b3224:

    # GRC "Say... what?"
    GRC "¿Dijiste... qué?"

# game/chapters/end_2.rpyc:1183
translate es chat2_daykissend_fb03d36c:

    # GRC "I... I...!"
    GRC "Yo... yo... ¡yo...!"

# game/chapters/end_2.rpyc:1184
translate es chat2_daykissend_3e80c831:

    # GRC "I obviously... I wouldn't be here if I didn't..."
    GRC "Obviamente... no estaría aquí si no..."

# game/chapters/end_2.rpyc:1185
translate es chat2_daykissend_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/end_2.rpyc:1186
translate es chat2_daykissend_e43837eb:

    # GRC "I... like you."
    GRC "Me... gustas."

# game/chapters/end_2.rpyc:1187
translate es chat2_daykissend_30d1896a:

    # GRC "No, that doesn't sound correct."
    GRC "No, eso no suena correcto."

# game/chapters/end_2.rpyc:1188
translate es chat2_daykissend_e4465198:

    # GRC "Gods, I'm so good at speaking, but when it comes to you I become a mess..."
    GRC "Dioses, soy tan bueno hablando, pero cuando se trata de ti me vuelvo un desastre..."

# game/chapters/end_2.rpyc:1189
translate es chat2_daykissend_bd0f6fc2:

    # GRC "What I feel for you is... more than just... 'like'."
    GRC "Lo que siento por ti es... más que solo... 'me gustas'."

# game/chapters/end_2.rpyc:1190
translate es chat2_daykissend_d97d69e8:

    # GRC "You are... everything I desire."
    GRC "Tú eres... todo lo que deseo."

# game/chapters/end_2.rpyc:1191
translate es chat2_daykissend_7659df49:

    # GRC "So... I probably... maybe..."
    GRC "Así que... probablemente... tal vez..."

# game/chapters/end_2.rpyc:1192
translate es chat2_daykissend_18fb6a9a:

    # GRC "Am in love with you."
    GRC "Estoy enamorado de ti."

# game/chapters/end_2.rpyc:1197
translate es chat2_daykissend_89e8213d:

    # GRC "I know."
    GRC "Lo sé."

# game/chapters/end_2.rpyc:1202
translate es chat2_daykissend_af7a311d:

    # GRC "Oh?"
    GRC "¿Oh?"

# game/chapters/end_2.rpyc:1206
translate es chat2_daykissend_cf257da8:

    # GRC "A... poor trade off..."
    GRC "Un... pobre intercambio..."

# game/chapters/end_2.rpyc:1212
translate es chat2_daykissend_5c2e6d0c:

    # GRC "What... do you want?"
    GRC "¿Qué... es lo que quieres?"

# game/chapters/end_2.rpyc:1217
translate es chat2_daykissend_0a2c4bf7_3:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/end_2.rpyc:1218
translate es chat2_daykissend_c2b8042e:

    # GRC "A... kiss?"
    GRC "¿Un... beso?"

# game/chapters/end_2.rpyc:1222
translate es chat2_daykissend_bc52bc60:

    # GRC "...Yes."
    GRC "...Sí."

# game/chapters/end_2.rpyc:1226
translate es chat2_daykissend_e29587e9:

    # GRC "A kiss is fine."
    GRC "Un beso está bien."

# game/chapters/end_2.rpyc:1227
translate es chat2_daykissend_2104071a:

    # GRC "A kiss is more than fine."
    GRC "Un beso está más que bien."

# game/chapters/end_2.rpyc:1228
translate es chat2_daykissend_bba2daf5:

    # GRC "A kiss is... great."
    GRC "Un beso es... genial."

# game/chapters/end_2.rpyc:1253
translate es chat2_daykissend_c1ff9e78:

    # GRC "Really, you're so demanding."
    GRC "De verdad, eres tan exigente."

# game/chapters/end_2.rpyc:1254
translate es chat2_daykissend_86747610:

    # GRC "I got stuck with the worst mortal of all..."
    GRC "Me tocó el peor mortal de todos..."

# game/chapters/end_2.rpyc:1255
translate es chat2_daykissend_2c346477:

    # GRC "Well?"
    GRC "¿Bueno?"

# game/chapters/end_2.rpyc:1262
translate es chat2_daykissend_49a7a508:

    # GRC "Kiss me then, Little Nightmare of mine."
    GRC "Bésame entonces, mi pequeña Pesadilla."

# game/chapters/end_2.rpyc:1264
translate es chat2_daykissend_014a4bd7:

    # GRC "Kiss me then, Sunshine."
    GRC "Bésame entonces, Solecito."

translate es strings:

    old "1. <G'morning Caspeeeeeer.>"
    new "1. <Bueeenos días, Caspeeeeeer.>"

    old "1. <What a lovely day it is.>"
    new "1. <Qué día tan encantador.>"

    old "1. <The sun is shining.>"
    new "1. <El sol brilla.>"

    old "1. <You're so wise.>"
    new "1. <Eres tan sabio.>"

    old "1. <But what I was getting at was that it's such a {i}lovely day{/i}.>"
    new "1. <Pero a lo que iba es que es un día tan {i}hermoso{/i}.>"

    old "1. <{i}Today{/i}.>"
    new "1. <{i}Hoy{/i}.>"

    old "1. <My little reaper... you're about to run out of time ;)>"
    new "1. <Mi parquita... estás a punto de quedarte sin tiempo ;)>"

    old "1. <Oh wow, your generosity knows no bounds.>"
    new "1. <Oh, wow, tu generosidad no conoce límites.>"

    old "1. <How will I ever thank you?>"
    new "1. <¿Cómo te lo agradeceré algún día?>"

    old "1. <Where's the fun in that?>"
    new "1. <¿Dónde está la diversión en eso?>"

    old "1. <Don't you like the chase?>"
    new "1. <¿No te gusta la persecución?>"

    old "1. <Awww, Grim's been chasing me <3>"
    new "1. <Awww, Parca me ha estado persiguiendo <3>"

    old "1. <You're a romantic at heart, Casper.>"
    new "1. <Eres un romántico en el fondo, Casper.>"

    old "1. <You been studying, Grimmy?>"
    new "1. <¿Has estado investigando, Parquita?>"

    old "1. <Reeeaaally?>"
    new "1. <¿De veeeerdad?>"

    old "1. <It doesn't sound like it'll work for you.>"
    new "1. <No suena como que te vaya a funcionar.>"

    old "1. <And you've left it so last minute...>"
    new "1. <Y lo dejaste para último minuto...>"

    old "1. <If you REALLY wanted it that badly...>"
    new "1. <Si de VERDAD la quisieras tanto...>"

    old "1. <I don't think you would have let time slip.>"
    new "1. <No creo que hubieras dejado pasar el tiempo.>"

    old "1. <Oh, I know...>"
    new "1. <Oh, ya sé...>"

    old "1. <It's because you're in love with me, right?>"
    new "1. <Es porque estás enamorado de mí, ¿verdad?>"

    old "1. <Must be frustrating for you, little reaper.>"
    new "1. <Debe ser frustrante para ti, parquita.>"

    old "1. <Unless you've changed your mind?>"
    new "1. <¿A menos que hayas cambiado de opinión?>"

    old "1. <You could hang around and protect me.>"
    new "1. <Podrías quedarte y protegerme.>"

    old "1. <I can keep away your soul sickness, and you can keep other reapers away.>"
    new "1. <Puedo mantener lejos tu enfermedad del alma, y tú puedes mantener alejadas a las otras parcas.>"

    old "1. <Casper and [playerfirstname], on the run together... foreverrrrr.>"
    new "1. <Casper y [playerfirstname], huyendo juntos... por siempreeee.>"

    old "1. <I know already.>"
    new "1. <Yo ya lo sé.>"

    old "1. <I win, keep your soul, and you.>"
    new "1. <Gano, me quedo con tu alma, y contigo.>"

    old "1. <I don't mind waiting a little longer.>"
    new "1. <No me importa esperar un poco más.>"

    old "1. <I mean it's been a whole week already of you being unsuccessful.>"
    new "1. <Quiero decir, ya ha pasado toda una semana sin que tengas éxito.>"

    old "1. <Can't wait to take a bite out of your soul ;)>"
    new "1. <No puedo esperar para darle un mordisco a tu alma ;)>"

    old "1. <Whatever happened to 'I cannot lie.'?>"
    new "1. <¿Qué pasó con eso de 'No puedo mentir'?>"

    old "1. <You use that to get around not being able to lie too, don't you?>"
    new "1. <Usas eso también para evitar no poder mentir, ¿verdad?>"

    old "1. <Awww, I'm your sweetheart?>"
    new "1. <Awww, ¿soy tu cariño?>"

    old "1. <That's adorable.>"
    new "1. <Eso es adorable.>"

    old "1. <You can be my sweetheart too.>"
    new "1. <Tú también puedes ser mi cariño.>"

    old "1. <You can call me your sweetheart if you'd like~>"
    new "1. <Puedes llamarme tu cariño si quieres~>"

    old "1. <Aww poor Casper, still can't handle being teased?>"
    new "1. <Aww pobre Casper, ¿todavía no puedes soportar que te molesten?>"

    old "1. <My little guy is so shy sometimes.>"
    new "1. <Mi pequeño a veces es tan tímido.>"

    old "1. <I'm so lucky I get to see your blushing face.>"
    new "1. <Tengo tanta suerte de poder ver tu carita sonrojada.>"

    old "1. <Oh please, we both know you blush super easily.>"
    new "1. <Oh, por favor, los dos sabemos que te sonrojas facilísimo.>"

    old "1. <I could bat my eyelashes at you and you'd go bright red.>"
    new "1. <Podría pestañearte un par de veces y te pondrías rojo como un tomate.>"

    old "1. <When you inevitably call me later, we'll test it out.>"
    new "1. <Cuando inevitablemente me llames más tarde, lo comprobaremos.>"

    old "1. <Anyhow, I think it's a good use of my time.>"
    new "1. <De todos modos, creo que es un buen uso de mi tiempo.>"

    old "1. <In fact, maybe it's even the best use of my time.>"
    new "1. <De hecho, tal vez sea el mejor uso de mi tiempo.>"

    old "1. <We both know you like flirting awkwardly with me.>"
    new "1. <Ambos sabemos que te gusta coquetear torpemente conmigo.>"

    old "1. <A pet name like 'sweetheart' seems right up your alley.>"
    new "1. <Un apodo como 'cariño' te queda perfecto.>"

    old "1. <So you don't like them?>"
    new "1. <¿Entonces no te gustan?>"

    old "1. <You know it's okay to admit you like them right?>"
    new "1. <Sabes que está bien admitir que te gustan, ¿verdad?>"

    old "1. <And yet you also won't say you don't.>"
    new "1. <Y aun así tampoco dices que no.>"


    old "1. <So which is it?>"
    new "1. <Entonces, ¿cuál es?>"

    old "1. <You like them?>"
    new "1. <¿Te gustan?>"

    old "1. <C'mon {i}Honey{/i}, no need to be so shy.>"
    new "1. <Vamos {i}cielito{/i}, no tienes que ser tan tímido.>"

    old "1. <I can feel you blushing from the other side of my computer screen.>"
    new "1. <Puedo sentir que te sonrojas desde el otro lado de mi pantalla.>"

    old "1. <{i}Darling{/i}.>"
    new "1. <{i}Querido{/i}.>"

    old "1. <Oh???>"
    new "1. <¿¿¿Oh???>"

    old "1. <I can't wait to see what you come up with~>"
    new "1. <No puedo esperar a ver con qué sales~>"

    old "1. <For a second it was insulting, but then you added the 'my'.>"
    new "1. <Por un segundo fue insultante, pero luego añadiste el 'mi'.>"

    old "1. <And now I kind of like it.>"
    new "1. <Y ahora como que me gusta.>"

    old "1. <I don't mind which you use.>"
    new "1. <No me importa cuál uses.>"

    old "1. <Use either.>"
    new "1. <Usa cualquiera.>"

    old "1. <Use both!>"
    new "1. <¡Usa ambos!>"

    old "1. <It suits me, and it's hilarious!>"
    new "1. <¡Me queda bien y es divertidísimo!>"

    old "1. <I feel attached to that one.>"
    new "1. <Me encariñé con ese.>"

    old "1. <And Sunshine sounds extra cute when you say it.>"
    new "1. <Y 'Solecito' suena especialmente tierno cuando tú lo dices.>"

    old "1. <Very domestic of you.>"
    new "1. <Muy hogareño de tu parte.>"

    old "1. <Well, since you've so graciously given me a few more hours...>"
    new "1. <Bueno, ya que me has concedido tan amablemente unas horas más...>"

    old "1. <What are you actually doing, considering you aren't reaping my soul?>"
    new "1. <¿Qué estás haciendo realmente, teniendo en cuenta que no estás cosechando mi alma?>"

    old "1. <Ohhhh, that's deep.>"
    new "1. <Ohhhh, qué profundo.>"

    old "1. <Thinking about me, huh?>"
    new "1. <Pensando en mí, ¿eh?>"

    old "1. <Because you liiiiike me.>"
    new "1. <Porque te guuuusto.>"

    old "1. <Is there something wrong today?>"
    new "1. <¿Pasa algo hoy?>"

    old "1. <Sounds tough, buddy.>"
    new "1. <Suena difícil, amigo.>"

    old "1. <Miss my [pretty] face, do you?>"
    new "1. <¿Extrañas mi bonita cara , eh?>"

    old "1. <Who am I to deny such a request!>"
    new "1. <¿Quién soy yo para negarme a tal petición?>"

    old "1. <Helloooo, helloooo!>"
    new "1. <¡Holaaaa, holaaaa!>"

    old "1. <Obviously.>"
    new "1. <Obviamente.>"

    old "1. <Now it's your turn.>"
    new "1. <Ahora es tu turno.>"

    old "1. <It's 'Give your crush a compliment' day.>"
    new "1. <Es el día de 'Dale un cumplido a tu crush'.>"

    old "1. <It's totally real. Completely.>"
    new "1. <Es totalmente real. Completamente.>"

    old "1. <Okay, don't hurt yourself.>"
    new "1. <Está bien, no te lastimes.>"

    old "1. <Oh? Why not?>"
    new "1. <¿Oh? ¿Por qué no?>"

    old "1. <Caspeeeeeeeer~>"
    new "1. <Caaaaspeeeeeeer~>"

    old "1. <Don't you like a [pretty] [girl] calling out to you like that?>"
    new "1. <¿No te gusta que un[girl!t] [pretty!t] te llame así?>"

    old "1. <I'd hope not.>"
    new "1. <Eso espero.>"

    old "1. <I'm your special mortal, after all.>"
    new "1. <Después de todo, soy tu mortal especial.>"

    old "1. <Oh, by the way...>"
    new "1. <Oh, por cierto...>"

    old "1. <You can't sneak out of answering my question \nproperly so easily!>"
    new "1. <¡No puedes escaparte tan fácil de responder \nbien mi pregunta!>"

    old "1. <What have you been up to today?>"
    new "1. <¿Qué has estado haciendo hoy?>"

    old "1. <Awww, that's cute.>"
    new "1. <Awww, qué tierno.>"

    old "1. <Of course, you wouldn't wanna break out or anything.>"
    new "1. <Por supuesto, no te gustaría escaparte ni nada por el estilo.>"

    old "1. <God forbid that ever happen to you.>"
    new "1. <Dios no quiera, que eso te pase a ti.>"

    old "1. <I'm dead serious.>"
    new "1. <Lo digo totalmente en serio.>"

    old "1. <I just rub it all over my face.>"
    new "1. <Solo me lo froto por toda la cara.>"

    old "1. <What do you do for skincare, then?>"
    new "1. <Entonces, ¿qué haces para el cuidado de tu piel?>"

    old "1. <No wonder you skin looks so soft.>"
    new "1. <Con razón tu piel se ve tan suave.>"

    old "1. <I wanna touch it.>"
    new "1. <Quiero tocarla.>"

    old "1. <And what's that?>"
    new "1. <¿Y qué es eso?>"

    old "1. <Okay, this sounds serious.>"
    new "1. <De acuerdo, esto suena serio.>"

    old "1. <What are you thinking about exactly, Casper?>"
    new "1. <¿En qué estás pensando exactamente, Casper?>"

    old "1. <Will it get you in trouble?>"
    new "1. <¿Te meterá en problemas?>"

    old "1. <Casper...?>"
    new "1. <¿Casper...?>"

    old "1. <What exactly is it you're considering?>"
    new "1. <¿Qué es exactamente lo que estás considerando?>"

    old "1. <Well yes, but what is it?>"
    new "1. <Bueno, sí, pero ¿qué es?>"

    old "1. <You mean...?>"
    new "1. <¿Quieres decir...?>"

    old "1. <You're going to... quit?>"
    new "1. <¿Vas a... renunciar?>"

    old "1. <And you are thinking about this because...?>"
    new "1. <¿Y estás pensando en eso porque...?>"

    old "1. <I don't want you to get into trouble \nbecause of me...>"
    new "1. <No quiero que te metas en problemas \npor mi culpa...>"

    old "1. <You sound pretty certain about your choice.>"
    new "1. <Suenas bastante seguro de tu decisión.>"

    old "1. <As funny as it would be if I was messing \nwith you right now...>"
    new "1. <Por más gracioso que sería si te estuviera \nmolestando ahora...>"

    old "1. <I'm totally serious.>"
    new "1. <Lo digo totalmente en serio.>"

    old "1. <You... have my heart.>"
    new "1. <Tú... tienes mi corazón.>"

    old "1. <Wanna run away together?>"
    new "1. <¿Quieres huir conmigo?>"

    old "1. <I mean, it'll be more you running than me. I've got an \napartment and a pet to worry about.>"
    new "1. <Quiero decir, serás tú quien corra más que yo. Tengo un \napartamento y una mascota de la que preocuparme.>"

    old "1. <...Of course I would.>"
    new "1. <...Por supuesto que lo haría.>"

    old "1. <Are you planning on sneaking in through my window?>"
    new "1. <¿Planeas colarte por mi ventana?>"

    old "1. <And when exactly do you plan to make \nyour grand entrance?>"
    new "1. <¿Y exactamente cuándo planeas hacer \ntu gran entrada?>"

    old "1. <I want to see you.>"
    new "1. <Quiero verte.>"

    old "1. <Where are you going to go?>"
    new "1. <¿A dónde vas a ir?>"

    old "1. <You are not sleeping on my couch!>"
    new "1. <¡No vas a dormir en mi sofá!>"

    old "1. <You can't sleep on the couch.>"
    new "1. <No puedes dormir en el sofá.>"

    old "1. <I have a perfectly comfortable bed.>"
    new "1. <Tengo una cama perfectamente cómoda.>"

    old "1. <On the perfectly comfortable bed I own.>"
    new "1. <En la cama perfectamente cómoda que tengo.>"

    old "1. <My bed.>"
    new "1. <Mi cama.>"

    old "1. <Why would I make you sleep on a couch...>"
    new "1. <¿Por qué te haría dormir en un sofá...?>"

    old "1. <Seriously, Casper...>"
    new "1. <En serio, Casper...>"

    old "1. <I'm not against the idea.>"
    new "1. <No estoy en contra de la idea.>"


    old "1. <In fact, I'd like it quite a lot.>"
    new "1. <De hecho, me gustaría bastante.>"

    old "1. <Surely you realize that by now.>"
    new "1. <Seguramente ya te has dado cuenta de eso.>"

    old "1. <In fact, I'm pretty sure we talked about what side of \nthe bed we'd have the other day!>"
    new "1. <¡De hecho, tengo bastante certeza de que el otro día \nhablamos sobre en qué lado de la cama dormiríamos!>"

    old "1. <I wouldn't offer it to you if I wasn't.>"
    new "1. <No te lo ofrecería si no fuera así.>"

    old "1. <There is plenty of room for us both.>"
    new "1. <Hay espacio de sobra para los dos.>"

    old "1. <I want to... lay by your side...>"
    new "1. <Quiero... acostarme a tu lado...>"

    old "1. <Or snuggle up, if you wanted to as well.>"
    new "1. <O acurrucarme contigo, si tú también quisieras.>"

    old "1. <I'll leave that up to you!>"
    new "1. <¡Lo dejaré a tu decisión!>"

    old "1. <Well, yeah, but I happen to like him a lot.>"
    new "1. <Bueno, sí, pero resulta que me gusta mucho.>"

    old "1. <And he isn't actively trying to kill me now!>"
    new "1. <¡Y ahora no está intentando matarme activamente!>"

    old "1. <Living life for yourself.>"
    new "1. <Vivir la vida por ti mismo.>"

    old "1. <Being free?>"
    new "1. <¿Ser libre?>"

    old "1. <Letting yourself dream?>"
    new "1. <¿Permitirte soñar?>"

    old "1. <Sounds like a nice life, huh?>"
    new "1. <Suena como una buena vida, ¿eh?>"

    old "1. <Making your own story?>"
    new "1. <¿Escribir tu propia historia?>"

    old "1. <Hello, Little Reaper~>"
    new "1. <Hola, parquita~>"

    old "1. <And what did you expect?>"
    new "1. <¿Y qué esperabas?>"

    old "1. <No? What did you think would happen?>"
    new "1. <¿No? ¿Qué creíste que pasaría?>"

    old "1. <I'm here.>"
    new "1. <Estoy aquí.>"

    old "1. <And there's that signature blush.>"
    new "1. <Y ahí está ese rubor tan característico.>"

    old "1. <No, I don't think I will.>"
    new "1. <No, no creo que lo haga.>"

    old "1. <Who would've thought I'd make a bet with a reaper...>"
    new "1. <Quién hubiera pensado que haría una apuesta con una parca...>"

    old "1. <And that he'd be on {i}my{/i} bed, blushing like this?>"
    new "1. <¿Y que estaría en {i}mi{/i} cama, sonrojado así?>"

    old "1. <With his hair spread everywhere so nicely.>"
    new "1. <Con su tan bonito cabello esparcido por todas partes.>"

    old "1. <You know what it's time for?>"
    new "1. <Saben qué momento ha llegado?>"

    old "1. <You. Me. Soul baby.>"
    new "1. <Tú. Yo. Bebé alma.>"

    old "1. <Let's work it out together.>"
    new "1. <Arreglémoslo juntos.>"

    old "1. <A what?>"
    new "1. <¿Un qué?>"

    old "1. <A bad idea?>"
    new "1. <¿Una mala idea?>"

    old "1. <Poor Casper, you can't even lie about it.>"
    new "1. <Pobre Casper, ni siquiera puedes mentir sobre eso.>"

    old "1. <But you can't, so you may as well love me.>"
    new "1. <Pero no puedes, así que mejor ámame.>"

    old "1. <I want to hear you say it in person.>"
    new "1. <Quiero escucharte decirlo en persona.>"

    old "1. <I won the bet, Casper.>"
    new "1. <Gané la apuesta, Casper.>"

    old "1. <You can keep your soul.>"
    new "1. <Puedes quedarte con tu alma.>"

    old "1. <I'd much rather have your heart.>"
    new "1. <Prefiero mucho más tener tu corazón.>"

    old "1. <Then give me something else, too.>"
    new "1. <Entonces dame algo más también.>"

    old "1. <How about a kiss?>"
    new "1. <¿Qué tal un beso?>"

    old "1. <Ha... cute.>"
    new "1. <Ha... lindo.>"

    old "1. <Close your eyes, Casper.>"
    new "1. <Cierra los ojos, Casper.>"

    old "2. <Whatever you saaay.>"
    new "2. <Lo que tú digas.>"

    old "2. <Is there not?>"
    new "2. <¿No lo hay?>"

    old "2. <I'd rather make it more difficult for you.>"
    new "2. <Prefiero ponértelo más difícil.>"

    old "2. <I guess you just spent the entire week messing around, huh?>"
    new "2. <Supongo que pasaste toda la semana perdiendo el tiempo, ¿eh?>"

    old "2. <When did you learn how to be sarcastic btw?>"
    new "2. <Por cierto, ¿cuándo aprendiste a ser sarcástico?>"

    old "2. <Okay, I like when you call me that.>"
    new "2. <Está bien, me gusta cuando me llamas así.>"

    old "2. <Now now Casper, no need to feel shy.>"
    new "2. <Vamos, Casper, no hay necesidad de ponerse tímido.>"

    old "2. <Don't steal away my fun <3>"
    new "2. <No me robes la diversión <3>"

    old "2. <I hope it's as cute as 'sweetheart'.>"
    new "2. <Espero que sea tan lindo como 'cariño'.>"

    old "2. <Use nightmare!>"
    new "2. <¡Usa pesadilla!>"

    old "2. <That seems unlike you.>"
    new "2. <Eso no suena como tú.>"

    old "2. <Wanna hear my voice that badly?>"
    new "2. <¿Tanto te apetece escuchar mi voz?>"

    old "2. <It's the highlight of my day.>"
    new ""


    old "2. <Hello handsome~>"
    new "2. <Hola, guapo~>"

    old "2. <That explains so much!>"
    new "2. <¡Eso explica muchas cosas!>"

    old "2. <Life altering?>"
    new "2. <¿Cambiará mi vida?>"

    old "2. <Is that something you {i}can{/i} do?>"
    new "2. <¿Es algo que {i}puedes{/i} hacer?>"

    old "2. <You don't need to throw your life away \nbecause of me...>"
    new "2. <No necesitas arruinar tu vida \npor mi culpa...>"

    old "2. <Yeah. I've never felt this way before.>"
    new "2. <Sí. Nunca me había sentido así antes.>"

    old "2. <For you? In a heartbeat.>"
    new "2. <¿Por ti? En un abrir y cerrar de ojos.>"

    old "2. <How long will you be?>"
    new "2. <¿Cuánto tiempo te tomará?>"

    old "2. <I can do you one better. I have a bed.>"
    new "2. <Puedo ofrecerte algo mejor. Tengo una cama.>"

    old "2. <That is what I am saying, yes.>"
    new "2. <Eso es lo que estoy diciendo, sí.>"

    old "2. <Following your heart.>"
    new "2. <Seguir a tu corazón.>"

    old "2. <Nice of you to join me, Casper.>"
    new "2. <Qué bueno que te unieras a mí, Casper.>"

    old "2. <O... okay.>"
    new "2. <O... está bien.>"

    old "3. <I will {i}definitely{/i} do that.>"
    new "3. <{i}Definitivamente{/i} haré eso.>"

    old "3. <You called me sweetheart first! Deal with it, {i}my love{/i}~>"
    new "3. <¡Tú me llamaste cariño primero! Así que aguántate, {i}mi amor{/i}~>"

    old "3. <Sunshine it is!>"
    new "3. <¡Entonces Solecito será!>"

    old "3. <Anything you want, babygirl~>"
    new "3. <Lo que quieras, babygirl~>"

    old "3. <Can't resist me can you, Caspeeeer?>"
    new "3. <No puedes resistirte a mí, ¿verdad, Caspeeeer?>"

    old "3. <The Grim Reaper has a skincare routine?>"
    new "3. <¿La Parca tiene una rutina de cuidado de la piel?>"

    old "3. <Are you thinking of doing something stupid?>"
    new "3. <¿Estás pensando en hacer algo estúpido?>"

    old "3. <Why would you do that...?>"
    new "3. <¿Por qué harías eso...?>"

    old "3. <It's already open for you, Casper.>"
    new "3. <Ya está abierta para ti, Casper.>"

    old "3. <As long as you're comfortable with it too.>"
    new "3. <Mientras tú también estés cómodo con eso.>"

    old "3. <Deciding your own fate.>"
    new "3. <Decidiendo tu propio destino.>"
