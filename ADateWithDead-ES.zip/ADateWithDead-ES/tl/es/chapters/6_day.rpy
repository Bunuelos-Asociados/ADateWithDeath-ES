
# game/chapters/6_day.rpyc:20
translate es day6_start_88900aa6:

    # center_text "You went out for a few errands today, but mostly you hung out around home."
    center_text "Saliste hoy a hacer algunos mandados, pero la mayor parte del tiempo estuviste en casa."

# game/chapters/6_day.rpyc:21
translate es day6_start_25d33745:

    # center_text "It was a good chance for a little out-of-season Spring cleaning."
    center_text "Fue una buena oportunidad para hacer un poco de limpieza de primavera fuera de temporada."

# game/chapters/6_day.rpyc:22
translate es day6_start_df08b08b:

    # center_text "All day, you kept an eye out for Casper and his attempts to take your soul, but..."
    center_text "Todo el día estuviste al tanto de Casper y sus intentos de llevarse tu alma, pero..."

# game/chapters/6_day.rpyc:23
translate es day6_start_38f0830a:

    # center_text "There was nothing."
    center_text "No pasó nada."

# game/chapters/6_day.rpyc:24
translate es day6_start_0f417991:

    # center_text "No strange fires, or collapsing elevators, or brakes cut on the bus..."
    center_text "No hubo incendios extraños, ni ascensores colapsando, ni frenos cortados en el autobús..."

# game/chapters/6_day.rpyc:25
translate es day6_start_fe0d6a37:

    # center_text "Today, for the first time in a long time, nothing strange happened to you."
    center_text "Hoy, por primera vez en mucho tiempo, no te pasó nada raro."

# game/chapters/6_day.rpyc:26
translate es day6_start_27eae7dd:

    # center_text "And for some reason, it felt weirder than if something had!"
    center_text "Y por alguna razón, ¡se sintió más extraño que si hubiera pasado algo!"

# game/chapters/6_day.rpyc:67
translate es day6_start2_88ae2f26:

    # player "I keep looking at the flowers."
    player "Sigo mirando las flores."

# game/chapters/6_day.rpyc:69
translate es day6_start2_dfd6d502:

    # player "These flowers are beautiful, Grim."
    player "Estas flores son hermosas, Parca."

# game/chapters/6_day.rpyc:73
translate es day6_start2_2783f96f:

    # player "Ah, I guess I should call you Casper."
    player "Ah, supongo que debería llamarte Casper."

# game/chapters/6_day.rpyc:75
translate es day6_start2_b15324b6:

    # GR "call me... whatever you wish to."
    GR "llámame... como tú quieras."

# game/chapters/6_day.rpyc:78
translate es day6_start2_87d19d1a:

    # player "I just wanna thank you again."
    player "Solo quería agradecerte otra vez."

# game/chapters/6_day.rpyc:80
translate es day6_start2_5b7e7ded:

    # player "I didn't think you had it in you."
    player "No pensé que fueras capaz de hacerlo."

# game/chapters/6_day.rpyc:83
translate es day6_start2_5a663fcb:

    # player "You really know how to sweep me off my feet."
    player "Realmente sabes cómo dejarme sin aliento."

# game/chapters/6_day.rpyc:86
translate es day6_start2_2f2080eb:

    # player "They're really pretty."
    player "Son realmente bonitas."

# game/chapters/6_day.rpyc:89
translate es day6_start2_fd6e6478:

    # GR "good. i am glad to see they are appreciated."
    GR "bien. me alegra ver que las aprecias."

# game/chapters/6_day.rpyc:90
translate es day6_start2_f48fdf42:

    # GR "the struggle was worth it."
    GR "valió la pena el esfuerzo."

# game/chapters/6_day.rpyc:93
translate es day6_start2_2969c96f:

    # player "The struggle?"
    player "¿El esfuerzo?"

# game/chapters/6_day.rpyc:95
translate es day6_start2_e977c28b:

    # player "Okay, now I'm starting to worry."
    player "Bien, ahora empiezo a preocuparme."

# game/chapters/6_day.rpyc:98
translate es day6_start2_6fa3483b:

    # player "You don't have any florists near you?"
    player "¿No tienes floristerías cerca?"

# game/chapters/6_day.rpyc:100
translate es day6_start2_82484d08:

    # GR "these aren't from a florist."
    GR "estas no son de una floristería."

# game/chapters/6_day.rpyc:101
translate es day6_start2_6ae23994:

    # GR "and no, there are no florists here."
    GR "y no, no hay floristerías aquí."

# game/chapters/6_day.rpyc:104
translate es day6_start2_716ab43c:

    # player "Then where {i}are{/i} they from?"
    player "Entonces, ¿de dónde {i}son{/i}?"

# game/chapters/6_day.rpyc:105
translate es day6_start2_ee8aec55:

    # GR "the yard of some other mortal."
    GR "del jardín de otro mortal."

# game/chapters/6_day.rpyc:106
translate es day6_start2_70d77a6e:

    # GR "for such a frail woman, she gave quite a chase."
    GR "para ser una mujer tan frágil, dio una buena persecución."

# game/chapters/6_day.rpyc:109
translate es day6_start2_03775ec8:

    # player "..."
    player "..."

# game/chapters/6_day.rpyc:112
translate es day6_start2_77ce5cac:

    # player "You stole these from an old lady?!"
    player "¿¡Le robaste a una anciana?!"

# game/chapters/6_day.rpyc:113
translate es day6_start2_4b88be8c:

    # GR "well. i never said she was old."
    GR "bueno. nunca dije que fuera anciana."

# game/chapters/6_day.rpyc:114
translate es day6_start2_8e2bd811:

    # GR "but yes, she was."
    GR "pero sí, lo era."

# game/chapters/6_day.rpyc:115
translate es day6_start2_a56dd639:

    # GR "her walking stick packed quite a punch."
    GR "su bastón tenía bastante fuerza."

# game/chapters/6_day.rpyc:118
translate es day6_start2_7876b3d2:

    # player "Hahahaha. Absolutely fantastic."
    player "Jajajajaja. Absolutamente fantástico."

# game/chapters/6_day.rpyc:122
translate es day6_start2_6b5d511a:

    # player "You're a little old lady thief."
    player "Eres un ladrón de viejitas."

# game/chapters/6_day.rpyc:124
translate es day6_start2_ddd80fa8:

    # GR "that makes it sound like i'm stealing old ladies."
    GR "eso hace que suene como si robara viejitas."

# game/chapters/6_day.rpyc:128
translate es day6_start2_3a44d833:

    # player "Who says you aren't?"
    player "¿Y quién dice que no?"

# game/chapters/6_day.rpyc:130
translate es day6_start2_e153eba7:

    # GR "me. anyway..."
    GR "yo. en fin..."

# game/chapters/6_day.rpyc:132
translate es day6_start2_531223ac:

    # GR "is it stealing if it was hanging over the other side of the fence?"
    GR "¿es robo si colgaban del otro lado de la cerca?"

# game/chapters/6_day.rpyc:136
translate es day6_start2_6c83c389:

    # player "Um... I'm not actually sure. Maybe?"
    player "Eh... No lo sé muy bien. ¿Tal vez?"

# game/chapters/6_day.rpyc:137
translate es day6_start2_c74553b8:

    # GR "see? it is definitely a grey area."
    GR "¿ves? definitivamente es un área gris."

# game/chapters/6_day.rpyc:139
translate es day6_start2_3815a931:

    # player "Legally, I think yes."
    player "Legalmente, creo que sí."

# game/chapters/6_day.rpyc:140
translate es day6_start2_b57c4c8e:

    # GR "legalities mean nothing to me."
    GR "las legalidades no significan nada para mí."

# game/chapters/6_day.rpyc:141
translate es day6_start2_e21fef42:

    # GR "i am above such things."
    GR "estoy por encima de esas cosas."

# game/chapters/6_day.rpyc:143
translate es day6_start2_cf8b0f92:

    # GR "she had plenty, anyway."
    GR "ella tenía muchas, de todos modos."

# game/chapters/6_day.rpyc:144
translate es day6_start2_06c0eaa9:

    # GR "they're in much better hands now."
    GR "ahora están en mejores manos."

# game/chapters/6_day.rpyc:147
translate es day6_start2_a16a1a3d:

    # player "Did you grow them yourself?"
    player "¿Las cultivaste tú mismo?"

# game/chapters/6_day.rpyc:148
translate es day6_start2_5d364529:

    # GR "no."
    GR "no."

# game/chapters/6_day.rpyc:149
translate es day6_start2_35cbb337:

    # GR "they would not bloom like this here. flowers are rare."
    GR "aquí no florecerían así. las flores son raras."

# game/chapters/6_day.rpyc:150
translate es day6_start2_df606e01:

    # GR "and do i look like some sort of gardener to you?"
    GR "¿y acaso tengo pinta de jardinero?"

# game/chapters/6_day.rpyc:154
translate es day6_start2_b69d4efa:

    # player "Yeah, you really give gardener vibes."
    player "Sí, das vibras de jardinero."

# game/chapters/6_day.rpyc:156
translate es day6_start2_35afd57e:

    # player "I bet you've never gardened in your life."
    player "Apuesto a que nunca has hecho jardinería en tu vida."

# game/chapters/6_day.rpyc:159
translate es day6_start2_67246f44:

    # player "How did you get them, then?"
    player "Entonces, ¿cómo las conseguiste?"

# game/chapters/6_day.rpyc:160
translate es day6_start2_0a089e8e:

    # GR "i took them from the front yard of a mortal woman."
    GR "las tomé del jardín delantero de una mujer mortal."

# game/chapters/6_day.rpyc:161
translate es day6_start2_61c23107:

    # GR "i believe she is what your kind refer to as a 'grandmother'."
    GR "creo que es lo que ustedes llaman una 'abuela'."

# game/chapters/6_day.rpyc:165
translate es day6_start2_ab302e7f:

    # player "You stole from an old woman?!"
    player "¿¡Le robaste a una anciana?!"

# game/chapters/6_day.rpyc:167
translate es day6_start2_fc9ccfcb:

    # GR "in her defense, she gave good chase. i was impressed."
    GR "en su defensa, corrió bien. me impresionó."

# game/chapters/6_day.rpyc:170
translate es day6_start2_ca0d5b80:

    # player "She chased you down?"
    player "¿Te persiguió?"

# game/chapters/6_day.rpyc:172
translate es day6_start2_0c14131c:

    # GR "she certainly tried her best."
    GR "ciertamente hizo su mejor esfuerzo."

# game/chapters/6_day.rpyc:173
translate es day6_start2_11c79ca2:

    # GR "but there was no hope for her to catch me."
    GR "pero no había esperanza de que me alcanzara."

# game/chapters/6_day.rpyc:174
translate es day6_start2_46b52620:

    # GR "either way, they are in much better hands with you."
    GR "de cualquier modo, están en mejores manos contigo."

# game/chapters/6_day.rpyc:180
translate es day6_start2_2b829f88:

    # player "I mean..."
    player "Quiero decir..."

# game/chapters/6_day.rpyc:183
translate es day6_start2_aa0be739:

    # player "Haven't you seen my plant during our calls?"
    player "¿No has visto mi planta durante nuestras llamadas?"

# game/chapters/6_day.rpyc:187
translate es day6_start2_ab51cfec:

    # player "It's right near my bed."
    player "Está justo al lado de mi cama."

# game/chapters/6_day.rpyc:189
translate es day6_start2_ae9b4844:

    # GR "your camera doesn't point at your bed, mortal."
    GR "tu cámara no apunta a tu cama, mortal."

# game/chapters/6_day.rpyc:190
translate es day6_start2_7c12e627:

    # GR "i... can't say i would mind if it did point that way, though."
    GR "yo... no diría que me molestaría si apuntara hacia allá, claro."

# game/chapters/6_day.rpyc:191
translate es day6_start2_456f1aea:

    # GR "simply for... research purposes, maybe."
    GR "simplemente por... motivos de investigación, tal vez."

# game/chapters/6_day.rpyc:195
translate es day6_start2_d28ee1d3:

    # player "Wow, Casper!"
    player "¡Wow, Casper!"

# game/chapters/6_day.rpyc:196
translate es day6_start2_3db01656:

    # GR "what? is that an issue?"
    GR "¿qué? ¿es un problema?"

# game/chapters/6_day.rpyc:197
translate es day6_start2_0783129a:

    # GR "feeling coy?"
    GR "¿te da vergüenza?"

# game/chapters/6_day.rpyc:198
translate es day6_start2_da8b5300:

    # GR "it is... possibly something important to my job as a reaper. maybe."
    GR "es... posiblemente algo importante para mi trabajo como parca. tal vez."

# game/chapters/6_day.rpyc:203
translate es day6_start2_3b365b60:

    # player "Is that how you get around not being able to lie?"
    player "¿Así es como te las arreglas para no mentir?"

# game/chapters/6_day.rpyc:207
translate es day6_start2_3fd0c9e2:

    # player "Lots of 'maybe' and 'possibly'?"
    player "¿Con muchos 'tal vez' y 'posiblemente'?"

# game/chapters/6_day.rpyc:209
translate es day6_start2_76d1fcf4:

    # GR "i quite possibly have no clue what you're maybe talking about."
    GR "posiblemente no tengo ni idea de qué estás tal vez hablando."

# game/chapters/6_day.rpyc:213
translate es day6_start2_4274cfd0:

    # player "And what research purposes would they be?"
    player "¿Y cuáles serían esos fines de investigación?"

# game/chapters/6_day.rpyc:215
translate es day6_start2_b89177bf:

    # GR "uh... important reaper ones."
    GR "uh... asuntos importantes de parcas."

# game/chapters/6_day.rpyc:219
translate es day6_start2_b2762382:

    # player "Which are?"
    player "¿Como cuáles?"

# game/chapters/6_day.rpyc:221
translate es day6_start2_c546d311:

    # GR "er..."
    GR "er..."

# game/chapters/6_day.rpyc:222
translate es day6_start2_3c27a14b:

    # GR "it is... crucial we understand our targets in ways they won't expect."
    GR "es... crucial que comprendamos a nuestros objetivos de formas que no esperen."

# game/chapters/6_day.rpyc:223
translate es day6_start2_e5280bf3:

    # GR "comprehensive soul harvesting strategies, and all that."
    GR "estrategias completas de recolección de almas, y todo eso."

# game/chapters/6_day.rpyc:227
translate es day6_start2_7674fadc:

    # player "So what have you learned about me so far?"
    player "¿Y qué has aprendido de mí hasta ahora?"

# game/chapters/6_day.rpyc:229
translate es day6_start2_885dc26d:

    # GR "huh?? you want me to go into that {i}now{/i}?"
    GR "¿¿eh?? ¿quieres que hable de eso {i}ahora{/i}?"

# game/chapters/6_day.rpyc:233
translate es day6_start2_dfd69874:

    # player "You wouldn't {i}lie{/i} about seeing my bed for research purposes, would you?"
    player "¿No {i}mentirías{/i} sobre mirar mi cama por motivos de investigación, verdad?"

# game/chapters/6_day.rpyc:235
translate es day6_start2_1bf43874:

    # GR "of... of course not! i cannot lie, after all!"
    GR "por... ¡por supuesto que no! ¡no puedo mentir, después de todo!"

# game/chapters/6_day.rpyc:236
translate es day6_start2_05aeba00:

    # GR "you... like your pet very much. you get a dorky look on your face when you tease me..."
    GR "tú... quieres mucho a tu mascota. pones una cara tonta cuando me molestas..."

# game/chapters/6_day.rpyc:237
translate es day6_start2_15681531:

    # GR "your favorite color is [day5_favoritecolor] and.. you are..."
    GR "tu color favorito es el [day5_favoritecolor!t] y... eres..."

# game/chapters/6_day.rpyc:238
translate es day6_start2_b8ba8bd3:

    # GR "quite... [pretty]."
    GR "bastante... [pretty!t]."

# game/chapters/6_day.rpyc:241
translate es day6_start2_da301633:

    # GR "you like going on and on about soul babies..."
    GR "te gusta hablar sin parar sobre bebés alma..."

# game/chapters/6_day.rpyc:244
translate es day6_start2_d279bcd0:

    # GR "you joke about getting married as if it were nothing..."
    GR "bromeas sobre casarte como si no fuera nada..."

# game/chapters/6_day.rpyc:247
translate es day6_start2_72293c0a:

    # GR "you read smutty books, apparently."
    GR "aparentemente lees libros subidos de tono."

# game/chapters/6_day.rpyc:249
translate es day6_start2_7c82df39:

    # GR "you're funny, as well as so annoying i cannot even put it into words..."
    GR "eres bromista, y también tan irritante que ni siquiera puedo ponerlo en palabras..."

# game/chapters/6_day.rpyc:250
translate es day6_start2_6c0dc2f3:

    # GR "not only that, but you're smart and talented and hardworking and..."
    GR "no solo eso, sino que eres inteligente, con talento y una persona trabajadora, y..."

# game/chapters/6_day.rpyc:254
translate es day6_start2_3bc778a7:

    # player "This is sounding less and less reaper related..."
    player "Esto suena cada vez menos relacionado con ser una parca..."

# game/chapters/6_day.rpyc:258
translate es day6_start2_ec14d0e8:

    # player "And more and more like you have a thing for me."
    player "Y más y más como si sintieras algo por mí."

# game/chapters/6_day.rpyc:260
translate es day6_start2_dd97b329:

    # GR "what??? don't be absurd."
    GR "¿¡qué??? no digas tonterías."

# game/chapters/6_day.rpyc:261
translate es day6_start2_77554a19:

    # GR "you must think of yourself awfully highly to believe you could attract the attention of me."
    GR "debes pensar muy bien de ti para creer que podrías atraer mi atención."

# game/chapters/6_day.rpyc:265
translate es day6_start2_802d2794:

    # player "With the way you talk about me?"
    player "¿Con la forma en que hablas de mí?"

# game/chapters/6_day.rpyc:269
translate es day6_start2_32bc6629:

    # player "I think it's {i}you{/i} that thinks awfully highly of {i}me{/i}."
    player "Creo que eres {i}tú{/i} quien piensa demasiado bien de {i}mí{/i}."

# game/chapters/6_day.rpyc:272
translate es day6_start2_9a2fdb42:

    # player "That's the nicest thing anyone's ever said about me."
    player "Eso es lo más lindo que alguien ha dicho de mí."

# game/chapters/6_day.rpyc:274
translate es day6_start2_f3b1f875:

    # GR "......"
    GR "......"

# game/chapters/6_day.rpyc:275
translate es day6_start2_414d2e6a:

    # GR "i... was not trying to be nice."
    GR "yo... no estaba tratando de ser amable."

# game/chapters/6_day.rpyc:276
translate es day6_start2_f3638a55:

    # GR "i was trying to be... honest."
    GR "estaba tratando de ser... honesto."

# game/chapters/6_day.rpyc:277
translate es day6_start2_e71c3afe:

    # GR "learning all of that is part of being a reaper, of course."
    GR "aprender todo eso es parte de ser una parca, por supuesto."

# game/chapters/6_day.rpyc:278
translate es day6_start2_2826a9a5:

    # GR "yes, a very important part, probably."
    GR "sí, una parte muy importante, probablemente."

# game/chapters/6_day.rpyc:282
translate es day6_start2_5a61af2b:

    # player "Sure it is."
    player "Claro que sí."

# game/chapters/6_day.rpyc:285
translate es day6_start2_77cb8ec7:

    # player "...Thanks, Casper."
    player "...Gracias, Casper."

# game/chapters/6_day.rpyc:287
translate es day6_start2_7b873397:

    # GR "anyway, this is all beside the point."
    GR "de todos modos, esto no tiene nada que ver con el tema."

# game/chapters/6_day.rpyc:289
translate es day6_start2_4a186c8b:

    # GR "but no, i haven't seen your plant by the bed."
    GR "pero no, no he visto tu planta junto a la cama."

# game/chapters/6_day.rpyc:293
translate es day6_start2_8fad044d:

    # player "...It's not looking very alive."
    player "...No se ve muy viva."

# game/chapters/6_day.rpyc:296
translate es day6_start2_80e98cad:

    # player "I'm not holding out hopes for the flower's survival."
    player "No tengo muchas esperanzas en la supervivencia de las flores."

# game/chapters/6_day.rpyc:298
translate es day6_start2_3d181b2b:

    # GR "they've already been cut from their source, so they won't last forever."
    GR "ya han sido cortadas de su fuente, así que no durarán para siempre."

# game/chapters/6_day.rpyc:299
translate es day6_start2_d7ac1e10:

    # GR "i'll just get more for you if they shrivel up."
    GR "te conseguiré más si se marchitan."

# game/chapters/6_day.rpyc:303
translate es day6_start2_1193aec1:

    # player "What, in the next day before you're meant to take my soul?"
    player "¿Qué, mañana, antes de que tengas que llevarte mi alma?"

# game/chapters/6_day.rpyc:304
translate es day6_start2_a6de612c:

    # GR "ah."
    GR "ah."

# game/chapters/6_day.rpyc:305
translate es day6_start2_7fa945f2:

    # GR "...yes."
    GR "...sí."

# game/chapters/6_day.rpyc:309
translate es day6_start2_9607d6b0:

    # player "Why would you do that for me?"
    player "¿Por qué harías eso por mí?"

# game/chapters/6_day.rpyc:311
translate es day6_start2_0979a889:

    # GR "does there need to be a reason? i simply feel like it."
    GR "¿necesita haber una razón? simplemente me apetece."

# game/chapters/6_day.rpyc:315
translate es day6_start2_7ec323ea:

    # player "No... I suppose not."
    player "No... supongo que no."

# game/chapters/6_day.rpyc:317
translate es day6_start2_9f379aff:

    # player "I kinda like things having reasons, but fine."
    player "Me gusta que las cosas tengan una razón, pero está bien."

# game/chapters/6_day.rpyc:319
translate es day6_start2_635e11fb:

    # GR "good."
    GR "bien."

# game/chapters/6_day.rpyc:320
translate es day6_start2_762e5590:

    # GR "i... enjoyed seeing your expression when i presented them to you."
    GR "yo... disfruté viendo tu expresión cuando te las presenté."

# game/chapters/6_day.rpyc:321
translate es day6_start2_216e6248:

    # GR "i do not usually do 'good' things, nor did i understand why someone would."
    GR "no suelo hacer cosas 'buenas', ni entendía por qué alguien lo haría."

# game/chapters/6_day.rpyc:322
translate es day6_start2_328e356a:

    # GR "perhaps now i understand it to some degree."
    GR "quizás ahora lo entiendo un poco."

# game/chapters/6_day.rpyc:329
translate es day6_start2_352d4f1c:

    # player "I've got something of a green thumb, luckily."
    player "Tengo buena mano con las plantas, por suerte."

# game/chapters/6_day.rpyc:332
translate es day6_start2_bfb689a2:

    # player "I've got a plant by my bed and it's growing nicely."
    player "Tengo una planta junto a la cama y está creciendo bien."

# game/chapters/6_day.rpyc:335
translate es day6_start2_33874e7d:

    # player "Maybe I've got the magic touch."
    player "Quizás tengo el toque mágico."

# game/chapters/6_day.rpyc:337
translate es day6_start2_721a1f2a:

    # GR "a magic touch, hmm."
    GR "¿un toque mágico, eh?"

# game/chapters/6_day.rpyc:341
translate es day6_start2_f78c7073:

    # player "I feel like you're insinuating something here."
    player "Siento que estás insinuando algo aquí."

# game/chapters/6_day.rpyc:345
translate es day6_start2_9cfb42b8:

    # player "I'm talking about the plant."
    player "Estoy hablando de la planta."

# game/chapters/6_day.rpyc:347
translate es day6_start2_11eff699:

    # GR "ah. yes, the plant."
    GR "ah. sí, la planta."

# game/chapters/6_day.rpyc:348
translate es day6_start2_a2e72d0c:

    # GR "i was just talking about you in general."
    GR "yo hablaba de ti en general."

# game/chapters/6_day.rpyc:352
translate es day6_start2_1b3a6214:

    # player "Wowee, mister flirt over here."
    player "Vayaaa, señor coqueto por aquí."

# game/chapters/6_day.rpyc:354
translate es day6_start2_c527d9e7:

    # GR "your hands {i}were{/i} very soft. i could tell, even through my gloves."
    GR "tus manos {i}eran{/i} muy suaves. pude notarlo, incluso a través de mis guantes."

# game/chapters/6_day.rpyc:355
translate es day6_start2_ac0e2d6e:

    # GR "soft and warm."
    GR "suaves y cálidas."

# game/chapters/6_day.rpyc:358
translate es day6_start2_4db1c9e8:

    # player "Shhh, you."
    player "Shhh, tú."

# game/chapters/6_day.rpyc:360
translate es day6_start2_b7dc83e1:

    # GR "shh me all you want, it is the truth."
    GR "mándame callar todo lo que quieras, sigue siendo verdad."

# game/chapters/6_day.rpyc:361
translate es day6_start2_5bbe87b3:

    # GR "i feel as though... if i reached out, our hands would fit each other's perfectly."
    GR "siento que... si extendiera mi mano, encajarían perfectamente con las tuyas."

# game/chapters/6_day.rpyc:364
translate es day6_start2_e641af87:

    # player "Are you trying to tell me something?"
    player "¿Estás tratando de decirme algo?"

# game/chapters/6_day.rpyc:366
translate es day6_start2_ce1c0943:

    # GR "perhaps. i will leave that to you to decide."
    GR "tal vez. dejaré que tú lo decidas."

# game/chapters/6_day.rpyc:374
translate es day6cont_815b0736:

    # player "So, I'm just wondering something."
    player "Bueno, solo me preguntaba algo."

# game/chapters/6_day.rpyc:377
translate es day6cont_dd3a5b0f:

    # player "Are you... feeling okay today?"
    player "¿Te sientes.. bien hoy?"

# game/chapters/6_day.rpyc:379
translate es day6cont_cf98cb7d:

    # GR "why wouldn't i be feeling okay?"
    GR "¿por qué no habría de sentirme bien?"

# game/chapters/6_day.rpyc:383
translate es day6cont_20e1c2bc:

    # player "You're just acting very..."
    player "Solo estás actuando muy..."

# game/chapters/6_day.rpyc:384
translate es day6cont_c553ae4e:

    # GR "flirtatious? if so, then i am being successful in my endeavor."
    GR "¿coqueto? si es así, entonces estoy teniendo éxito en mi propósito."

# game/chapters/6_day.rpyc:387
translate es day6cont_eb53cf6f:

    # player "Well, yes."
    player "Bueno, sí."

# game/chapters/6_day.rpyc:389
translate es day6cont_1c39bf1f:

    # player "I wasn't going to come out and say it but, yeah?"
    player "No iba a decirlo directamente, pero sí."

# game/chapters/6_day.rpyc:391
translate es day6cont_dfd7f8d8:

    # GR "i have read that flirting is a human custom."
    GR "he leído que coquetear es una costumbre humana."

# game/chapters/6_day.rpyc:394
translate es day6cont_adb8b755:

    # player "A custom...?"
    player "¿una costumbre...?"

# game/chapters/6_day.rpyc:395
translate es day6cont_0605cc1f:

    # GR "indeed."
    GR "en efecto."

# game/chapters/6_day.rpyc:396
translate es day6cont_eb10d566:

    # GR "to flirt with another is to show them that they are of significance to yourself."
    GR "coquetear con alguien es mostrarle que es importante para ti."

# game/chapters/6_day.rpyc:397
translate es day6cont_e7745bb4:

    # GR "or you would like them to be of significance to yourself."
    GR "o que te gustaría que lo fuera."

# game/chapters/6_day.rpyc:401
translate es day6cont_2df82358:

    # player "So... I'm of significance to you?"
    player "Entonces... ¿soy importante para ti?"

# game/chapters/6_day.rpyc:404
translate es day6cont_40482462:

    # GR "you are what i hunt most greatly over everything else. i would say that makes you significant."
    GR "eres lo que más deseo por encima de todo. diría que eso te hace importante."

# game/chapters/6_day.rpyc:405
translate es day6cont_741f685c:

    # GR "my research into various flirting methods say that, anyway."
    GR "mi investigación sobre los métodos de coqueteo dice eso, al menos."

# game/chapters/6_day.rpyc:408
translate es day6cont_463cc38b:

    # player "You've researched flirting methods?"
    player "¿Has investigado métodos de coqueteo?"

# game/chapters/6_day.rpyc:412
translate es day6cont_e3c2a29a:

    # player "You're cute. Cute and stupid."
    player "Eres adorable. Lindo y tonto."

# game/chapters/6_day.rpyc:413
translate es day6cont_e496e608:

    # GR "it's neither cute nor stupid. it's practical."
    GR "no es ni lindo ni tonto. es práctico."

# game/chapters/6_day.rpyc:414
translate es day6cont_0d836a7c:

    # GR "i'm ensuring the possibility of the best result."
    GR "estoy asegurando la posibilidad del mejor resultado."

# game/chapters/6_day.rpyc:415
translate es day6cont_c5aa7a0f:

    # GR "that is what i do best. adapt to be whatever is needed."
    GR "eso es lo que mejor hago. adaptarme a lo que sea necesario."

# game/chapters/6_day.rpyc:418
translate es day6cont_a11c7a3b:

    # player "And what {i}would{/i} be the best result for you?"
    player "¿Y cuál {i}sería{/i} el mejor resultado para ti?"

# game/chapters/6_day.rpyc:420
translate es day6cont_803ac39f:

    # GR "that is... something you do not need to know."
    GR "eso es... algo que no necesitas saber."

# game/chapters/6_day.rpyc:421
translate es day6cont_46b01fa7:

    # GR "i mean."
    GR "quiero decir."

# game/chapters/6_day.rpyc:422
translate es day6cont_5fbbb67b:

    # GR "it is obviously taking your soul. weakening your resolve enough to trick you."
    GR "obviamente sería tomar tu alma. debilitar tu voluntad lo suficiente para engañarte."

# game/chapters/6_day.rpyc:426
translate es day6cont_78794ec3:

    # player "Uh huh. Sure. All business."
    player "Uh huh. Claro. Pura profesionalidad."

# game/chapters/6_day.rpyc:428
translate es day6cont_f979705f:

    # GR "mortal, i wish i could say i hated you."
    GR "mortal, desearía poder decir que te odio."

# game/chapters/6_day.rpyc:429
translate es day6cont_4923aaf6:

    # GR "you are aggravating."
    GR "eres exasperante."

# game/chapters/6_day.rpyc:433
translate es day6cont_3069579c:

    # player "Too bad you can't lie, huh."
    player "Lástima que no puedas mentir, ¿eh?"

# game/chapters/6_day.rpyc:435
translate es day6cont_f94badc6:

    # GR "shut up."
    GR "cállate."

# game/chapters/6_day.rpyc:436
translate es day6cont_ec44b68f:

    # GR "you are too nosy. and annoying. and... i will think of more things later."
    GR "te entrometes demasiado. y eres una molestia. y... ya pensaré en más cosas luego."

# game/chapters/6_day.rpyc:440
translate es day6cont_f1057b15:

    # player "And you are surprisingly very soft and cautious."
    player "Y tú eres sorprendentemente muy delicado y cauteloso."

# game/chapters/6_day.rpyc:442
translate es day6cont_ba40d1b2:

    # GR "not words that have {i}ever{/i} been used to describe me."
    GR "no son palabras que {i}jamás{/i} se hayan usado para describirme."

# game/chapters/6_day.rpyc:446
translate es day6cont_04e6284a:

    # player "The more I get to know you, the less 'Grim Reaper' you seem."
    player "Cuanto más te conozco, menos pareces una 'Parca'."

# game/chapters/6_day.rpyc:448
translate es day6cont_f2ec837d:

    # GR "maybe i've shown too much of my true self to you."
    GR "tal vez te he mostrado demasiado de mi verdadero yo."

# game/chapters/6_day.rpyc:449
translate es day6cont_2480bd3e:

    # GR "to be honest, i am not even sure if i have a true self."
    GR "para ser honesto, ni siquiera estoy seguro de tener un yo verdadero."

# game/chapters/6_day.rpyc:450
translate es day6cont_d66894d5:

    # GR "i exist for my role. beyond that..."
    GR "existo por mi papel. más allá de eso..."

# game/chapters/6_day.rpyc:454
translate es day6cont_55dc8354:

    # player "I think you're plenty."
    player "Creo que eres más que suficiente."

# game/chapters/6_day.rpyc:458
translate es day6cont_4dfeac72:

    # player "I like talking with you and seeing new sides of you."
    player "Me gusta hablar contigo y ver tus diferentes facetas."

# game/chapters/6_day.rpyc:461
translate es day6cont_ab537066:

    # player "Isn't it refreshing to just be you? You can just be Casper."
    player "¿No es refrescante simplemente ser tú? Puedes ser solo Casper."

# game/chapters/6_day.rpyc:463
translate es day6cont_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/6_day.rpyc:464
translate es day6cont_5cf023fc:

    # GR "it's nice... i suppose."
    GR "es agradable... supongo."

# game/chapters/6_day.rpyc:465
translate es day6cont_9c7b4107:

    # GR "you called me flirtatious, but i believe you are the flirty one here."
    GR "me llamaste coqueto, pero creo que tú es quien coquetea aquí."

# game/chapters/6_day.rpyc:469
translate es day6cont_83e4f389:

    # player "Me? Never."
    player "¿Yo? Jamás."

# game/chapters/6_day.rpyc:470
translate es day6cont_df33306a:

    # GR "you are fortunate to be able to lie."
    GR "tienes suerte de poder mentir."

# game/chapters/6_day.rpyc:471
translate es day6cont_71344e2f:

    # GR "but i know your eyes have been on me from the start."
    GR "pero sé que tus ojos han estado sobre mí desde el principio."

# game/chapters/6_day.rpyc:473
translate es day6cont_a06428ae:

    # player "I've been flirting since the start."
    player "He estado coqueteando desde el principio."

# game/chapters/6_day.rpyc:474
translate es day6cont_cf2ed47a:

    # GR "i... see that now."
    GR "ya... lo veo ahora."

# game/chapters/6_day.rpyc:476
translate es day6cont_4c0f393b:

    # GR "i cannot fault you. i am a catch, after all."
    GR "no puedo culparte. soy un buen partido, después de todo."

# game/chapters/6_day.rpyc:477
translate es day6cont_c633f23f:

    # GR "{image=teehee}"
    GR "{image=teehee}"

# game/chapters/6_day.rpyc:481
translate es day6cont_3f0f285f:

    # player "Doot doot doot."
    player "Doot doot doot."

# game/chapters/6_day.rpyc:482
translate es day6cont_fad51915:

    # GR "why the dooting?"
    GR "¿por qué el 'doot'?"

# game/chapters/6_day.rpyc:486
translate es day6cont_ca37b7fb:

    # player "That's you tooting your own horn."
    player "Ese eres tú tocando tu propia trompeta."

# game/chapters/6_day.rpyc:488
translate es day6cont_5089e3d9:

    # GR "wow. mature."
    GR "vaya. muy maduro."

# game/chapters/6_day.rpyc:492
translate es day6cont_be24ebb4:

    # player "Hey, I didn't say you were wrong."
    player "Oye, no dije que estuvieras equivocado."

# game/chapters/6_day.rpyc:498
translate es day6cont_36c9e0a4:

    # player "I feel touched!"
    player "¡Me ha tocado el corazón!"

# game/chapters/6_day.rpyc:499
translate es day6cont_c3b493da:

    # GR "who is touching you? are you not there alone?"
    GR "¿quién te está tocando? ¿no estás a solas?"

# game/chapters/6_day.rpyc:503
translate es day6cont_362cdd81:

    # player "Such a big head, but such a little brain."
    player "Una cabeza tan grande, pero un cerebro tan pequeño."

# game/chapters/6_day.rpyc:505
translate es day6cont_05d8285b:

    # GR "my head is perfectly proportional to my body."
    GR "mi cabeza es perfectamente proporcional a mi cuerpo."

# game/chapters/6_day.rpyc:509
translate es day6cont_a5bde4e7:

    # player "No one is {i}touching me{/i}."
    player "Nadie me está {i}tocando{/i}."

# game/chapters/6_day.rpyc:511
translate es day6cont_81d32678:

    # GR "well. good."
    GR "bien. me alegra."

# game/chapters/6_day.rpyc:512
translate es day6cont_92e50535:

    # GR "no one is touching you yet."
    GR "nadie te está tocando aún."

# game/chapters/6_day.rpyc:516
translate es day6cont_6944e8d3:

    # player "Yet?"
    player "¿Aún?"

# game/chapters/6_day.rpyc:518
translate es day6cont_427e728b:

    # GR "i am trying to take it slow."
    GR "estoy intentando ir despacio."

# game/chapters/6_day.rpyc:522
translate es day6cont_4463df26:

    # player "Someone's confident!"
    player "¡Alguien está seguro de sí mismo!"

# game/chapters/6_day.rpyc:524
translate es day6cont_fde7d991:

    # GR "according to my notes, dates are important before anything further happens between people."
    GR "según mis notas, las citas son importantes antes de que ocurra algo más entre dos personas."

# game/chapters/6_day.rpyc:527
translate es day6cont_7e3526fa:

    # player "O-oh."
    player "O-oh."

# game/chapters/6_day.rpyc:529
translate es day6cont_2fe2b581:

    # player "Very forward of you."
    player "Muy directo de tu parte."

# game/chapters/6_day.rpyc:533
translate es day6cont_c5dc03a3:

    # player "Your notes are very in depth."
    player "Tus notas son muy detalladas."

# game/chapters/6_day.rpyc:536
translate es day6cont_be232e08:

    # player "Where did you get them?"
    player "¿De dónde las sacaste?"

# game/chapters/6_day.rpyc:538
translate es day6cont_f38c8391:

    # GR "through the wide information hub called the internet."
    GR "a través del amplio centro de información llamado internet."

# game/chapters/6_day.rpyc:539
translate es day6cont_68300e26:

    # GR "it is a compiled and comprehensive survey taken on how to romance correctly."
    GR "es una encuesta compilada y completa sobre cómo tener un romance correctamente."

# game/chapters/6_day.rpyc:542
translate es day6cont_eabdfef4:

    # player "Like a dummies guide to dating?"
    player "¿Como una guía para tontos sobre citas?"

# game/chapters/6_day.rpyc:544
translate es day6cont_a0203475:

    # GR "the text refers to it as a walkthrough, actually."
    GR "el texto en realidad se refiere a ello como una guía paso a paso."

# game/chapters/6_day.rpyc:548
translate es day6cont_f81c4c40:

    # player "An IRL dating sim!"
    player "¡Un simulador de citas en la vida real!"

# game/chapters/6_day.rpyc:549
translate es day6cont_2de670a2:

    # GR "i don't know what a 'dating sim' is, but sure."
    GR "no sé qué es un 'simulador de citas', pero claro."

# game/chapters/6_day.rpyc:550
translate es day6cont_87121360:

    # GR "there was useful information in it."
    GR "había información útil en eso."

# game/chapters/6_day.rpyc:551
translate es day6cont_1c776d23:

    # GR "as long as it works, i will not question its name."
    GR "mientras funcione, no cuestionaré su nombre."

# game/chapters/6_day.rpyc:554
translate es day6cont_e25aeca7:

    # player "What a strange thing to call it."
    player "Qué cosa tan extraña llamarlo así."

# game/chapters/6_day.rpyc:557
translate es day6cont_3809f5fa:

    # player "A dating walkthrough?"
    player "¿Una guía de citas?"

# game/chapters/6_day.rpyc:559
translate es day6cont_97755b17:

    # GR "yes. i am following it carefully."
    GR "sí. la estoy siguiendo cuidadosamente."

# game/chapters/6_day.rpyc:560
translate es day6cont_755a80ef:

    # GR "there are many steps."
    GR "hay muchos pasos."

# game/chapters/6_day.rpyc:564
translate es day6cont_66071e8c:

    # player "And what do you hope to get out of it?"
    player "¿Y qué esperas obtener con eso?"

# game/chapters/6_day.rpyc:566
translate es day6cont_8e21db9d:

    # GR "you."
    GR "tú."

# game/chapters/6_day.rpyc:567
translate es day6cont_35bf19fc:

    # GR "...r soul, obviously."
    GR "...tu alma, obviamente."

# game/chapters/6_day.rpyc:573
translate es day6cont_1d474c30:

    # player "Do you like me then, Casper?"
    player "¿Entonces te gusto, Casper?"

# game/chapters/6_day.rpyc:574
translate es day6cont_e6949fd2:

    # GR "like you? you are insufferable."
    GR "¿gustarme tú? eres insufrible."

# game/chapters/6_day.rpyc:575
translate es day6cont_628c3ec5:

    # GR "you're annoying, and aggravating, and you make fun of me all the time."
    GR "eres una molestia, irritante, y te burlas de mí todo el tiempo."

# game/chapters/6_day.rpyc:576
translate es day6cont_c8c83760:

    # GR "what reason would there be to like you?"
    GR "¿qué razón habría para que me gustaras?"

# game/chapters/6_day.rpyc:580
translate es day6cont_45f7a237:

    # player "And I bet you STILL like me."
    player "Y apuesto a que AÚN te gusto."

# game/chapters/6_day.rpyc:582
translate es day6cont_05656eac:

    # GR "i... shall neither deny nor confirm your suspicions."
    GR "yo... no negaré ni confirmaré tus sospechas."

# game/chapters/6_day.rpyc:586
translate es day6cont_39d047bb:

    # player "You know, that's really an answer itself."
    player "Sabes, eso ya es una respuesta en sí misma."

# game/chapters/6_day.rpyc:589
translate es day6cont_e13a09e2:

    # player "But fine, keep your secrets."
    player "Pero está bien, guarda tus secretos."

# game/chapters/6_day.rpyc:592
translate es day6cont_7bf52395:

    # GR "truly, you are ever so considerate."
    GR "realmente, eres una persona tan considerada."

# game/chapters/6_day.rpyc:596
translate es day6cont_64ee1340:

    # player "Thank you for noticing."
    player "Gracias por notarlo."

# game/chapters/6_day.rpyc:598
translate es day6cont_780d2864:

    # GR "that was sarcasm."
    GR "eso fue sarcasmo."

# game/chapters/6_day.rpyc:602
translate es day6cont_53859b6c:

    # player "Really? Wow, I never would have guessed."
    player "¿En serio? Wow, nunca lo habría adivinado."

# game/chapters/6_day.rpyc:605
translate es day6cont_1072536a:

    # player "But lets not look past the fact you are actually researching this."
    player "Pero no pasemos por alto el hecho de que en realidad estás investigando esto."

# game/chapters/6_day.rpyc:607
translate es day6cont_06e5de72:

    # GR "it really isn't that interesting."
    GR "no es tan interesante."

# game/chapters/6_day.rpyc:610
translate es day6cont_f8112ef6:

    # player "But it really is."
    player "Pero sí lo es."

# game/chapters/6_day.rpyc:613
translate es day6cont_50651433:

    # player "I've never known people to research how to flirt with someone."
    player "Nunca había conocido a alguien que investigara cómo coquetear con otra persona."

# game/chapters/6_day.rpyc:614
translate es day6cont_b3db45fc:

    # GR "as you are well aware of, i am not 'people'."
    GR "como bien sabes, yo no soy 'humano'."

# game/chapters/6_day.rpyc:618
translate es day6cont_f090a56a:

    # player "No, you certainly are not."
    player "No, ciertamente no lo eres."

# game/chapters/6_day.rpyc:621
translate es day6cont_c2ac72f8:

    # player "But that is not the point I am making right now."
    player "Pero ese no es el punto que estoy tratando de dar."

# game/chapters/6_day.rpyc:623
translate es day6cont_865e5a3a:

    # GR "i am a practical person."
    GR "soy una persona práctica."

# game/chapters/6_day.rpyc:624
translate es day6cont_be8f1fcd:

    # GR "if i'm to put my valuable time into something, then why wouldn't i ensure the best results?"
    GR "si voy a invertir mi valioso tiempo en algo, ¿por qué no asegurarme de obtener los mejores resultados?"

# game/chapters/6_day.rpyc:628
translate es day6cont_124b2149:

    # player "And the best results of your flirting would be...?"
    player "¿Y los mejores resultados de tu coqueteo serían...?"

# game/chapters/6_day.rpyc:631
translate es day6cont_08ed08f4:

    # player "A date? Dating?"
    player "¿Una cita? ¿Salir conmigo?"

# game/chapters/6_day.rpyc:633
translate es day6cont_9708b0b4:

    # GR "a... grim reaper cannot date a mortal."
    GR "una... parca no puede salir con un mortal."

# game/chapters/6_day.rpyc:634
translate es day6cont_e56cd767:

    # GR "the best result would be that i take your soul and move on with my life."
    GR "el mejor resultado sería tomar tu alma y seguir con mi vida."

# game/chapters/6_day.rpyc:638
translate es day6cont_7ed3c54d:

    # player "Is that the result you want?"
    player "¿Ese es el resultado que quieres?"

# game/chapters/6_day.rpyc:640
translate es day6cont_95151b2c:

    # GR "....."
    GR "....."

# game/chapters/6_day.rpyc:641
translate es day6cont_95c3f74f:

    # GR "i cannot say."
    GR "no puedo decirlo."

# game/chapters/6_day.rpyc:642
translate es day6cont_6f62651f:

    # GR "i know what the best result for me is, and yet i find myself hard pressed to choose."
    GR "sé cuál es el mejor resultado para mí, y aun así me cuesta decidirme."

# game/chapters/6_day.rpyc:643
translate es day6cont_f5af8987:

    # GR "...it is confusing. you have made me confused."
    GR "...es confuso. me has confundido."

# game/chapters/6_day.rpyc:644
translate es day6cont_2a636ec5:

    # GR "maybe all of your teasing has gone to my head."
    GR "tal vez todas tus burlas se me han subido a la cabeza."

# game/chapters/6_day.rpyc:649
translate es day6cont_2458c246:

    # player "You like it that much, huh?"
    player "¿Te gusta tanto, huh?"

# game/chapters/6_day.rpyc:653
translate es day6cont_c42bbb19:

    # player "I don't mind continuing it."
    player "No me importa seguir con ello."

# game/chapters/6_day.rpyc:657
translate es day6cont_d4227c9e:

    # player "My little kitten."
    player "Mi pequeño gatito."

# game/chapters/6_day.rpyc:659
translate es day6cont_bc93e58b:

    # player "My babygirl."
    player "Mi babygirl."

# game/chapters/6_day.rpyc:661
translate es day6cont_77cd275f:

    # GR "that is {i}not{/i} necessary...!"
    GR "¡eso {i}no{/i} es necesario...!"

# game/chapters/6_day.rpyc:662
translate es day6cont_c4842125:

    # GR "i never said i liked it! just that it confused me!"
    GR "¡nunca dije que me gustara! ¡solo que me confundía!"

# game/chapters/6_day.rpyc:663
translate es day6cont_3fe9dd85:

    # GR "no one has... ever treated me like you do."
    GR "nadie me ha... tratado como tú lo haces."

# game/chapters/6_day.rpyc:667
translate es day6cont_ba6fbd0a:

    # player "Is that a good thing, though?"
    player "¿Eso es algo bueno, entonces?"

# game/chapters/6_day.rpyc:669
translate es day6cont_30ced879:

    # GR "i am unsure."
    GR "no estoy seguro."

# game/chapters/6_day.rpyc:670
translate es day6cont_73ef918c:

    # GR "i think i may combust on the spot if someone else spoke to me the way you do."
    GR "creo que podría explotar en el acto si alguien más me hablara como tú lo haces."

# game/chapters/6_day.rpyc:671
translate es day6cont_656d1d13:

    # GR "so perhaps it is a good thing you are... unique in that regard."
    GR "así que tal vez sea bueno que seas... único en ese sentido."

# game/chapters/6_day.rpyc:682
translate es flirtaway_8c6e6815:

    # player "Well, even if you were only flirting with me to get my soul..."
    player "Bueno, incluso si solo coqueteabas conmigo para conseguir mi alma..."

# game/chapters/6_day.rpyc:686
translate es flirtaway_b63121a8:

    # player "Can't say I mind all that much."
    player "No puedo decir que me moleste tanto."

# game/chapters/6_day.rpyc:689
translate es flirtaway_9aceef63:

    # player "Flirt away o7"
    player "Sigue coqueteando o7"

# game/chapters/6_day.rpyc:690
translate es flirtaway_fa24d9f1:

    # GR "o7? what is an o7?"
    GR "¿o7? ¿qué es un o7?"

# game/chapters/6_day.rpyc:694
translate es flirtaway_4e9bd83f:

    # player "It's a salute, doofus."
    player "Es un saludo, tonto."

# game/chapters/6_day.rpyc:696
translate es flirtaway_6cba9de5:

    # GR "ah yes, i see now."
    GR "ah sí, ya lo veo."

# game/chapters/6_day.rpyc:697
translate es flirtaway_c3336138:

    # GR "i have never seen this salute. perhaps i shall adopt it."
    GR "nunca había visto ese saludo. tal vez lo adopte."

# game/chapters/6_day.rpyc:698
translate es flirtaway_b7d29831:

    # GR "o7"
    GR "o7"

# game/chapters/6_day.rpyc:699
translate es flirtaway_001cea67:

    # GR "ah, i have come up with another."
    GR "ah, se me ha ocurrido otro."

# game/chapters/6_day.rpyc:700
translate es flirtaway_dbfacc84:

    # GR "o/"
    GR "o/"

# game/chapters/6_day.rpyc:701
translate es flirtaway_d74bcac5:

    # GR "this one is a wave."
    GR "este es un saludo con la mano."

# game/chapters/6_day.rpyc:705
translate es flirtaway_ac96fe09:

    # player "Truly groundbreaking stuff."
    player "Verdaderamente revolucionario."

# game/chapters/6_day.rpyc:713
translate es day6cont2_a8521ebb:

    # player "By the way..."
    player "Por cierto..."

# game/chapters/6_day.rpyc:716
translate es day6cont2_c617e676:

    # player "Won't you get in trouble?"
    player "¿No te meterás en problemas?"

# game/chapters/6_day.rpyc:718
translate es day6cont2_3b4e5a8d:

    # GR "for flirting?"
    GR "¿por coquetear?"

# game/chapters/6_day.rpyc:719
translate es day6cont2_3e660148:

    # GR "well, that is not allowed, of course."
    GR "bueno, eso no está permitido, por supuesto."

# game/chapters/6_day.rpyc:723
translate es day6cont2_d590b715:

    # player "No no, for telling me classified information."
    player "No no, por contarme información clasificada."

# game/chapters/6_day.rpyc:725
translate es day6cont2_68e325f1:

    # GR "enlighten me, what classified information have i shared with you?"
    GR "ilumíname, ¿qué información clasificada te he compartido?"

# game/chapters/6_day.rpyc:729
translate es day6cont2_e74030b3:

    # player "Casper."
    player "Casper."

# game/chapters/6_day.rpyc:731
translate es day6cont2_7a428a14:

    # GR "yes?"
    GR "¿sí?"

# game/chapters/6_day.rpyc:734
translate es day6cont2_79735971:

    # player "You said your name was highly classifed."
    player "Dijiste que tu nombre era altamente clasificado."

# game/chapters/6_day.rpyc:737
translate es day6cont2_0e3d5264:

    # player "Not for mortal ears, right?"
    player "¿Que no debía ser oído por oídos mortales, cierto?"

# game/chapters/6_day.rpyc:739
translate es day6cont2_858db456:

    # GR "ah, that."
    GR "ah, eso."

# game/chapters/6_day.rpyc:740
translate es day6cont2_77772858:

    # GR "maybe some rules are worth breaking."
    GR "quizás algunas reglas valen la pena romperse."

# game/chapters/6_day.rpyc:741
translate es day6cont2_e0da8a6f:

    # GR "hearing you call me 'grim' in person made me feel 'cringe'."
    GR "oírte llamarme 'parca' en persona me hizo sentir 'cringe'."

# game/chapters/6_day.rpyc:745
translate es day6cont2_e4a628f1:

    # player "Who taught you that word..."
    player "¿Quién te enseñó esa palabra...?"

# game/chapters/6_day.rpyc:747
translate es day6cont2_228e4832:

    # GR "i am 'down' with the internet lingo, [playerfirstname!l]."
    GR "estoy 'al día' con el lenguaje de internet, [playerfirstname!l]."

# game/chapters/6_day.rpyc:748
translate es day6cont2_a41fe059:

    # GR "i know about 'cringe', 'pog', 'rizz'."
    GR "sé sobre 'cringe', 'pog', 'rizz'."

# game/chapters/6_day.rpyc:749
translate es day6cont2_bd7a8c22:

    # GR "i have even heard more of this 'babygirl'."
    GR "incluso he oído más sobre este 'babygirl'."

# game/chapters/6_day.rpyc:753
translate es day6cont2_4e2eb498:

    # player "Please don't say those words ever again."
    player "Por favor no vuelvas a decir esas palabras jamás."

# game/chapters/6_day.rpyc:755
translate es day6cont2_af3bbd5a:

    # player "You saying things like that is just incorrect. Cease."
    player "Decir cosas así simplemente no te queda. Basta."

# game/chapters/6_day.rpyc:757
translate es day6cont2_e9f126b8:

    # GR "your opinion has been noted and subsequently disregarded, sunshine."
    GR "tu opinión ha sido anotada y posteriormente ignorada, solecito."

# game/chapters/6_day.rpyc:761
translate es day6cont2_63ff8606:

    # player "But seriously, your name was actually classified?"
    player "Pero en serio, ¿tu nombre era realmente clasificado?"

# game/chapters/6_day.rpyc:764
translate es day6cont2_850391f8:

    # GR "correct. if anyone comes and asks about me, then it is best if you keep it quiet."
    GR "correcto. si alguien viene y pregunta por mí, será mejor que no digas nada."

# game/chapters/6_day.rpyc:767
translate es day6cont2_58e736bd:

    # player "I doubt anyone will, anyway."
    player "Dudo que alguien lo haga, de todos modos."

# game/chapters/6_day.rpyc:771
translate es day6cont2_b3bb43a4:

    # player "You're gonna have my soul by tomorrow, right?"
    player "Tendrás mi alma para mañana, ¿verdad?"

# game/chapters/6_day.rpyc:773
translate es day6cont2_f305bd7c:

    # GR "...right."
    GR "...cierto."

# game/chapters/6_day.rpyc:774
translate es day6cont2_f8f8984b:

    # GR "always best to be cautious, anyway."
    GR "siempre es mejor ser precavido, de todas formas."

# game/chapters/6_day.rpyc:775
translate es day6cont2_2e23507a:

    # GR "though you aren't the most cautious person."
    GR "aunque no eres la persona más precavida."

# game/chapters/6_day.rpyc:776
translate es day6cont2_8c072947:

    # GR "you allowed a total stranger to install a messaging program on your computer."
    GR "permitiste que un completo desconocido instalara un programa en tu computadora."

# game/chapters/6_day.rpyc:777
translate es day6cont2_a02eca36:

    # GR "then fell in love at first sight with his handsome face and charming personality."
    GR "luego te enamoraste a primera vista de su apuesto rostro y encantadora personalidad."

# game/chapters/6_day.rpyc:781
translate es day6cont2_7cfae8e0:

    # player "Haha, you're so funny."
    player "Jaja, eres muy gracioso."

# game/chapters/6_day.rpyc:785
translate es day6cont2_1cb972ad:

    # player "Handsome and charming? I don't think so."
    player "¿Apuesto y encantador? No lo creo."

# game/chapters/6_day.rpyc:787
translate es day6cont2_aede5058:

    # player "Handsome? Maybe. Charming? I don't think so."
    player "¿Apuesto? Tal vez. ¿Encantador? No lo creo."

# game/chapters/6_day.rpyc:789
translate es day6cont2_6fe7e379:

    # GR "i envy your ability to lie to me so easily."
    GR "envidio tu capacidad para mentirme con tanta facilidad."

# game/chapters/6_day.rpyc:790
translate es day6cont2_36cf0ce5:

    # GR "really, i do."
    GR "de verdad, lo hago."

# game/chapters/6_day.rpyc:791
translate es day6cont2_24c158d3:

    # GR "if you were a reaper, you wouldn't be able to say that."
    GR "si fueras una parca, no podrías decir eso."

# game/chapters/6_day.rpyc:794
translate es day6cont2_8bf738a1:

    # player "Oh noooo, my guard's so down right now!"
    player "¡Oh nooo, mi guardia está tan baja ahora mismo!"

# game/chapters/6_day.rpyc:797
translate es day6cont2_f5964252:

    # player "How terrible it would be if a grim reaper were to suddenly show great interest in me!"
    player "¡Qué terrible sería si una parca mostrara de repente gran interés en mí!"

# game/chapters/6_day.rpyc:800
translate es day6cont2_a5bae168:

    # player "Let's hope he doesn't bring me flowers and tell me how annoying I am."
    player "Esperemos que no me traiga flores y me diga la molestia que soy."

# game/chapters/6_day.rpyc:802
translate es day6cont2_eb469710:

    # GR "such a wild imagination on you."
    GR "tienes una imaginación tan salvaje."

# game/chapters/6_day.rpyc:803
translate es day6cont2_51aed399:

    # GR "how did you ever think up something so outrageous?"
    GR "¿cómo se te ocurrió algo tan absurdo?"

# game/chapters/6_day.rpyc:807
translate es day6cont2_2a9d51f2:

    # player "You must've been rubbing off on me."
    player "Debes de estar contagiándome."

# game/chapters/6_day.rpyc:809
translate es day6cont2_0ec8fd1d:

    # player "It's almost like that's how you actually are."
    player "Es casi como si así fueras realmente."

# game/chapters/6_day.rpyc:813
translate es day6cont2_1ff280e9:

    # player "You are a dork."
    player "Eres un tonto."

# game/chapters/6_day.rpyc:814
translate es day6cont2_3b840cb3:

    # GR "hah."
    GR "jaj."

# game/chapters/6_day.rpyc:815
translate es day6cont2_ea56bd88:

    # GR "i am far from a dork."
    GR "estoy lejos de ser un tonto."

# game/chapters/6_day.rpyc:816
translate es day6cont2_9da80808:

    # GR "i am charming and good looking."
    GR "soy encantador y apuesto."

# game/chapters/6_day.rpyc:819
translate es day6cont2_45ce3de3:

    # player "A charming and good looking dork."
    player "Un tonto encantador y apuesto."

# game/chapters/6_day.rpyc:822
translate es day6cont2_be149905:

    # player "The charming part could go either way though."
    player "Aunque la parte de encantador podría ir en cualquier dirección."

# game/chapters/6_day.rpyc:824
translate es day6cont2_986ea4c4:

    # GR "though i cannot lie, i am capable of seeing through them, little human."
    GR "aunque no puedo mentir, soy capaz de ver a través de ellas, humano."

# game/chapters/6_day.rpyc:827
translate es day6cont2_749647c3:

    # player ":)"
    player ":)"

# game/chapters/6_day.rpyc:829
translate es day6cont2_e5bd47a2:

    # player ";D"
    player ";D"

# game/chapters/6_day.rpyc:833
translate es day6cont2_e535256d:

    # player "If I let my guard down the reaper will steal me away~"
    player "Si bajo la guardia, la parca me robará~"

# game/chapters/6_day.rpyc:834
translate es day6cont2_9719ae51:

    # GR "i'm sure he'd see how troublesome you are and think twice."
    GR "estoy seguro de que vería el problema que eres y lo pensaría dos veces."

# game/chapters/6_day.rpyc:837
translate es day6cont2_7373cf6b:

    # player "And then he'd decide he can't be without me anyway."
    player "Y luego decidiría que no puede estar sin mí de todos modos."

# game/chapters/6_day.rpyc:840
translate es day6cont2_799c7d2d:

    # player "And then he will have to admit to himself how much he likes that."
    player "Y entonces tendría que admitir cuánto le gusta eso."

# game/chapters/6_day.rpyc:843
translate es day6cont2_210f6dbf:

    # player "How romantic."
    player "Qué romántico."

# game/chapters/6_day.rpyc:844
translate es day6cont2_57a3a043:

    # GR "maybe he would give you back because you are too much of a handful for him."
    GR "tal vez te devolvería porque eres demasiado para él."

# game/chapters/6_day.rpyc:847
translate es day6cont2_d0763fb3:

    # player "I think he likes to be kept on his toes, he'd have to keep me."
    player "Creo que le gusta mantenerse alerta, tendría que quedarse conmigo."

# game/chapters/6_day.rpyc:850
translate es day6cont2_ccdf9f54:

    # player "Don't you think?"
    player "¿No crees?"

# game/chapters/6_day.rpyc:851
translate es day6cont2_63104ab1:

    # GR "well, in this... hypothetical situation..."
    GR "bueno, en esta... situación hipotética..."

# game/chapters/6_day.rpyc:852
translate es day6cont2_55193562:

    # GR "i think you'll have to wait and see if he ever comes for you."
    GR "creo que tendrás que esperar y ver si alguna vez viene por ti."

# game/chapters/6_day.rpyc:853
translate es day6cont2_71933421:

    # GR "hopefully you have learnt some patience, because it might take him awhile."
    GR "con suerte has aprendido algo de paciencia, porque podría tardar un poco."

# game/chapters/6_day.rpyc:855
translate es day6cont2_24d4f09c:

    # GR "now that we are both here, though."
    GR "ahora que ambos estamos aquí, sin embargo."

# game/chapters/6_day.rpyc:856
translate es day6cont2_5db189e3:

    # GR "on a much more serious note..."
    GR "en una nota mucho más seria..."

# game/chapters/6_day.rpyc:857
translate es day6cont2_8b4ea32f:

    # GR "i must admit to you that other than giving you flowers, i had another ulterior motive for my visit."
    GR "debo confesarte que, además de darte flores, tenía otro motivo oculto para mi visita."

# game/chapters/6_day.rpyc:860
translate es day6cont2_870369f0:

    # player "Oh..."
    player "Oh..."

# game/chapters/6_day.rpyc:862
translate es day6cont2_9d65f142:

    # player "I knew it..."
    player "Lo sabía..."

# game/chapters/6_day.rpyc:863
translate es day6cont2_2909f684:

    # GR "don't misunderstand, [playerfirstname!l]."
    GR "no me malinterpretes, [playerfirstname!l]."

# game/chapters/6_day.rpyc:864
translate es day6cont2_6d77f3a9:

    # GR "i wanted to give you those flowers."
    GR "quería darte esas flores."

# game/chapters/6_day.rpyc:865
translate es day6cont2_be5abfbf:

    # GR "i also wanted to test out a theory i had."
    GR "también quería probar una teoría que tenía."

# game/chapters/6_day.rpyc:869
translate es day6cont2_d52893c7:

    # player "Alright, what was it then?"
    player "De acuerdo, ¿cuál era?"

# game/chapters/6_day.rpyc:871
translate es day6cont2_790d16ee:

    # GR "i was experienceing another bout of soul sickness yesterday."
    GR "ayer estaba experimentando otro ataque de enfermedad del alma."

# game/chapters/6_day.rpyc:872
translate es day6cont2_0e634b8c:

    # GR "it was a less severe case, but still an awful experience."
    GR "fue un caso menos severo, pero aun así una experiencia horrible."

# game/chapters/6_day.rpyc:876
translate es day6cont2_3976c39a:

    # player "Again? It's really a common thing for you reapers, huh?"
    player "¿Otra vez? Es algo bastante común entre las parcas, ¿huh?"

# game/chapters/6_day.rpyc:877
translate es day6cont2_ce79cb3c:

    # GR "actually, no. well... it never used to be for me."
    GR "en realidad, no. bueno... nunca solía serlo para mí."

# game/chapters/6_day.rpyc:878
translate es day6cont2_5734ec8f:

    # GR "i seem to be more susceptible lately."
    GR "parece que últimamente soy más susceptible."

# game/chapters/6_day.rpyc:879
translate es day6cont2_c03f1c17:

    # GR "which leads me to an important question."
    GR "lo que me lleva a una pregunta importante."

# game/chapters/6_day.rpyc:880
translate es day6cont2_8618ebb3:

    # GR "why? "
    GR "¿por qué?"

# game/chapters/6_day.rpyc:884
translate es day6cont2_c688179d:

    # player "Did you find out why?"
    player "¿Descubriste por qué?"

# game/chapters/6_day.rpyc:886
translate es day6cont2_8c159674:

    # GR "lets do this over a call."
    GR "hagamos esto por llamada."

# game/chapters/6_day.rpyc:890
translate es day6cont2_456dfb71:

    # player "Wait, is it serious?"
    player "Espera, ¿es grave?"

# game/chapters/6_day.rpyc:893
translate es day6cont2_e0cb4c95:

    # player "Are you going to die?"
    player "¿Vas a morir?"

# game/chapters/6_day.rpyc:896
translate es day6cont2_f9eaef87:

    # player "Please don't tell me you're dying."
    player "Por favor no me digas que te estás muriendo."

# game/chapters/6_day.rpyc:900
translate es day6cont2_44a0ab0d:

    # player "If that's what you're going to say, I'm not gonna answer."
    player "Si eso es lo que vas a decir, no voy a contestar."

# game/chapters/6_day.rpyc:903
translate es day6cont2_6dd53720:

    # player "Do you have some extra serious soul disease?"
    player "¿Tienes alguna enfermedad del alma súper grave?"

# game/chapters/6_day.rpyc:906
translate es day6cont2_e2a119d6:

    # player "Is it curable?"
    player "¿Es curable?"

# game/chapters/6_day.rpyc:909
translate es day6cont2_c7362415:

    # player "Is it really bad?"
    player "¿Es muy mala?"

# game/chapters/6_day.rpyc:912
translate es day6cont2_53b3eb43:

    # player "If you plan to tell me you're dying... I'm not gonna answer, okay?"
    player "Si planeas decirme que te estás muriendo... no voy a contestar, ¿de acuerdo?"

# game/chapters/6_day.rpyc:914
translate es day6cont2_149b96ff:

    # GR "i don't think i'm dying?"
    GR "no creo que me esté muriendo."

# game/chapters/6_day.rpyc:917
translate es day6cont2_42170ff4:

    # player "You don't think?!"
    player "¡¿No crees?!"

# game/chapters/6_day.rpyc:919
translate es day6cont2_302b55ce:

    # player "You're not really inspiring confidence right now...!"
    player "¡No estás inspirando mucha confianza ahora mismo...!"

# game/chapters/6_day.rpyc:921
translate es day6cont2_fcb4c12c:

    # GR "no, listen. i swear, you mortals are so bad at listening."
    GR "no, escucha. juro que ustedes, los mortales, son pésimos para escuchar."

# game/chapters/6_day.rpyc:922
translate es day6cont2_bc65a497:

    # GR "{i}you{/i} in particular."
    GR "{i}tú{/i} en particular."

# game/chapters/6_day.rpyc:923
translate es day6cont2_57111d5d:

    # GR "we talked about this the other day. think back on it."
    GR "hablamos de esto el otro día. piénsalo bien."

# game/chapters/6_day.rpyc:924
translate es day6cont2_38899629:

    # GR "do you remember?"
    GR "¿lo recuerdas?"

# game/chapters/6_day.rpyc:928
translate es day6cont2_32707389:

    # player "Of course. I remember."
    player "Por supuesto. Lo recuerdo."

# game/chapters/6_day.rpyc:929
translate es day6cont2_635e11fb:

    # GR "good."
    GR "bien."

# game/chapters/6_day.rpyc:931
translate es day6cont2_91421445:

    # player "Kinda hard to forget that day."
    player "Difícil olvidar ese día."

# game/chapters/6_day.rpyc:932
translate es day6cont2_c56e0717:

    # GR "tell me about it."
    GR "Cuéntame sobre eso."

# game/chapters/6_day.rpyc:935
translate es day6cont2_a443d62d:

    # player "Vaguely, yeah."
    player "Vagamente, sí."

# game/chapters/6_day.rpyc:936
translate es day6cont2_f83dc147:

    # GR "vaguely will do."
    GR "vagamente servirá."

# game/chapters/6_day.rpyc:938
translate es day6cont2_7758571d:

    # GR "do you remember how i felt the day after my sickness?"
    GR "¿recuerdas cómo me sentí el día después de mi enfermedad?"

# game/chapters/6_day.rpyc:942
translate es day6cont2_b9a24486:

    # player "You were fine."
    player "Estabas bien."

# game/chapters/6_day.rpyc:944
translate es day6cont2_80baf212:

    # GR "it made no sense."
    GR "no tenía sentido."

# game/chapters/6_day.rpyc:945
translate es day6cont2_f9605af8:

    # GR "i thought it just a mere coincidence that after the linking of our minds the symptoms disappeared."
    GR "pensé que solo era una mera coincidencia que, después de la conexión de nuestras mentes, los síntomas desaparecieran."

# game/chapters/6_day.rpyc:946
translate es day6cont2_c3f5bd4f:

    # GR "you jokingly claimed to be 'healing me with your presence'."
    GR "tú, en broma, dijiste que me 'curabas con tu presencia'."

# game/chapters/6_day.rpyc:947
translate es day6cont2_03605e7e:

    # GR "and then, yesterday..."
    GR "y luego, ayer..."

# game/chapters/6_day.rpyc:950
translate es day6cont2_b1a7bb09:

    # player "?"
    player "¿?"

# game/chapters/6_day.rpyc:952
translate es day6cont2_efb2cfd4:

    # player "What about it?"
    player "¿Qué pasa con eso?"

# game/chapters/6_day.rpyc:953
translate es day6cont2_b86eae26:

    # GR "that morning i was ferrying souls across the lifestream."
    GR "esa mañana estaba transportando almas a través del flujo vital."

# game/chapters/6_day.rpyc:954
translate es day6cont2_270d1b19:

    # GR "and it was like..."
    GR "y fue como..."

# game/chapters/6_day.rpyc:955
translate es day6cont2_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/6_day.rpyc:956
translate es day6cont2_f3acd545:

    # GR "hells, if they trace this conversation, the two of us may suffer for all of eternity."
    GR "demonios, si rastrean esta conversación, ambos podríamos sufrir por toda la eternidad."

# game/chapters/6_day.rpyc:960
translate es day6cont2_a8946573:

    # player "Are you sure you should be telling me this?"
    player "¿Estás seguro de que deberías decirme esto?"

# game/chapters/6_day.rpyc:961
translate es day6cont2_3e8e8900:

    # GR "no, no this needs to be said."
    GR "no, no, esto debe decirse."

# game/chapters/6_day.rpyc:962
translate es day6cont2_c9aa3170:

    # GR "it's important."
    GR "es importante."

# game/chapters/6_day.rpyc:963
translate es day6cont2_e0d7fa0b:

    # GR "to you most of all."
    GR "sobre todo para ti."

# game/chapters/6_day.rpyc:966
translate es day6cont2_9caaccf6:

    # player "At least we'd be suffering together!"
    player "¡Al menos sufriríamos juntos!"

# game/chapters/6_day.rpyc:967
translate es day6cont2_d3338010:

    # GR "you always look on the bright side of things, don't you?"
    GR "siempre ves el lado bueno de las cosas, ¿verdad?"

# game/chapters/6_day.rpyc:968
translate es day6cont2_f648d9b9:

    # GR "i picked the right flowers for you. bright like a sunflower."
    GR "elegí las flores adecuadas para ti. brillantes como un girasol."

# game/chapters/6_day.rpyc:969
translate es day6cont2_c7a80d4e:

    # GR "anyway..."
    GR "de todos modos..."

# game/chapters/6_day.rpyc:970
translate es day6cont2_37ee0bf3:

    # GR "this is important."
    GR "esto es importante."

# game/chapters/6_day.rpyc:975
translate es day6cont2_1cab3e4d:

    # player "You seem... very stressed about this."
    player "Pareces... muy estresado por esto."

# game/chapters/6_day.rpyc:978
translate es day6cont2_41fedfae:

    # player "It's kinda scaring me..."
    player "Está empezando a asustarme..."

# game/chapters/6_day.rpyc:980
translate es day6cont2_2d014123:

    # player "And now I feel stressed too!"
    player "¡Y ahora yo también me estoy estresando!"

# game/chapters/6_day.rpyc:982
translate es day6cont2_e988acfb:

    # player "Tell me, maybe I can help."
    player "Dime, tal vez pueda ayudarte."

# game/chapters/6_day.rpyc:984
translate es day6cont2_734f9969:

    # GR "then answer the call, and we can discuss it."
    GR "entonces contesta la llamada, y podremos hablar de eso."

# game/chapters/6_day.rpyc:1013
translate es call1_day6_8dd6f6fd:

    # GRC "Hey."
    GRC "Hey."

# game/chapters/6_day.rpyc:1027
translate es call1_day6_63fe1d27:

    # GRC "To put it bluntly..."
    GRC "Para decirlo sin rodeos..."

# game/chapters/6_day.rpyc:1041
translate es call1_day6_29d871b3:

    # GRC "I think it's because of you."
    GRC "Creo que es por ti."

# game/chapters/6_day.rpyc:1046
translate es call1_day6_1d43774a:

    # GRC "The soul sickness I'm experiencing."
    GRC "La enfermedad del alma que estoy experimentando."

# game/chapters/6_day.rpyc:1048
translate es call1_day6_a2286ee8:

    # GRC "I've gotten it much more since I've known you."
    GRC "La he tenido mucho más desde que te conozco."

# game/chapters/6_day.rpyc:1067
translate es call1_day6_376bec71:

    # GRC "I didn't know it tasted like that."
    GRC "No sabía que sabía así."

# game/chapters/6_day.rpyc:1073
translate es call1_day6_83961024:

    # GRC "Sarcasm tastes almost sour!"
    GRC "¡El sarcasmo sabe casi agrio!"

# game/chapters/6_day.rpyc:1083
translate es call1_day6_bb3d91ca:

    # GRC "No, that's not what I mean at all."
    GRC "No, eso no es lo que quiero decir en absoluto."

# game/chapters/6_day.rpyc:1086
translate es call1_day6_7e49df93:

    # GRC "Yes, it is from souls."
    GRC "Sí, proviene de las almas."

# game/chapters/6_day.rpyc:1087
translate es call1_day6_d0d8dbc1:

    # GRC "Yet I've suffered from it regardless."
    GRC "Aun así, he sufrido por ello igualmente."

# game/chapters/6_day.rpyc:1100
translate es call1_day6_11a6b232:

    # GRC "I don't think it is."
    GRC "No lo creo."

# game/chapters/6_day.rpyc:1101
translate es call1_day6_37fe566f:

    # GRC "Not anymore, anyway."
    GRC "Ya no, al menos."

# game/chapters/6_day.rpyc:1106
translate es call1_day6_8e48816c:

    # GRC "I'm not saying you are the cause of the sickness."
    GRC "No estoy diciendo que seas la causa de la enfermedad."

# game/chapters/6_day.rpyc:1108
translate es call1_day6_56061d7b:

    # GRC "But I do think you are the cause of why I seem to be more susceptible to it."
    GRC "Pero sí creo que eres la causa de por qué parezco ser más susceptible a ella."

# game/chapters/6_day.rpyc:1120
translate es call1_day6_07ef532f:

    # GRC "No, my soul was unbalanced before I came to you."
    GRC "No, mi alma ya estaba desequilibrada antes de venir a ti."

# game/chapters/6_day.rpyc:1130
translate es call1_day6_ef08d970:

    # GRC "I came to you to see if it would go away."
    GRC "Vine a ti para ver si desaparecía."

# game/chapters/6_day.rpyc:1133
translate es call1_day6_af010449:

    # GRC "That was my theory."
    GRC "Esa era mi teoría."

# game/chapters/6_day.rpyc:1143
translate es call1_day6_1d0cb8d2:

    # GRC "But it did."
    GRC "Pero lo hizo."

# game/chapters/6_day.rpyc:1145
translate es call1_day6_f09eb977:

    # GRC "Sunshine, it did."
    GRC "Solecito, lo hizo."

# game/chapters/6_day.rpyc:1150
translate es call1_day6_ee383ccc:

    # GRC "You didn't do it on purpose, then?"
    GRC "¿Entonces no lo hiciste a propósito?"

# game/chapters/6_day.rpyc:1152
translate es call1_day6_499956f6:

    # GRC "Do you have any clue what you're doing?"
    GRC "¿Tienes idea de lo que estás haciendo?"

# game/chapters/6_day.rpyc:1158
translate es call1_day6_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/6_day.rpyc:1167
translate es call1_day6_0f835f8e:

    # GRC "It's your soul."
    GRC "Es tu alma."

# game/chapters/6_day.rpyc:1169
translate es call1_day6_3e955a32:

    # GRC "You're... giving it away, so to speak."
    GRC "La estás... entregando, por así decirlo."

# game/chapters/6_day.rpyc:1182
translate es call1_day6_9afc2da2:

    # GRC "Do you ever wish, mortal?"
    GRC "¿Alguna vez lo has deseado, mortal?"

# game/chapters/6_day.rpyc:1183
translate es call1_day6_b5d00da6:

    # GRC "Feel something so strongly, want for something so badly?"
    GRC "¿Sientes algo tan intensamente, deseas algo con tanta fuerza?"

# game/chapters/6_day.rpyc:1197
translate es call1_day6_a96aa9cf:

    # GRC "You said that your pet was ill yesterday, correct?"
    GRC "Dijiste que tu mascota estaba enferma ayer, ¿cierto?"

# game/chapters/6_day.rpyc:1199
translate es call1_day6_484758fc:

    # GRC "And now they are fine, yes?"
    GRC "¿Y ahora está bien, sí?"

# game/chapters/6_day.rpyc:1203
translate es call1_day6_0d904be4:

    # GRC "I think you did it then, as well."
    GRC "Creo que lo hiciste entonces también."

# game/chapters/6_day.rpyc:1205
translate es call1_day6_25b35c03:

    # GRC "You are giving parts of yourself away."
    GRC "Estás entregando partes de ti."

# game/chapters/6_day.rpyc:1206
translate es call1_day6_4853852f:

    # GRC "To your sick pet."
    GRC "A tu mascota enferma."

# game/chapters/6_day.rpyc:1208
translate es call1_day6_c68e5604:

    # GRC "To your plant."
    GRC "A tu planta."

# game/chapters/6_day.rpyc:1210
translate es call1_day6_dfd5c67d:

    # GRC "To me."
    GRC "A mí."

# game/chapters/6_day.rpyc:1211
translate es call1_day6_118236ad:

    # GRC "Things you want to be healthy."
    GRC "A las cosas que quieres que estén sanas."

# game/chapters/6_day.rpyc:1212
translate es call1_day6_f43659df:

    # GRC "Things you want to live."
    GRC "A las cosas que quieres que vivan."

# game/chapters/6_day.rpyc:1217
translate es call1_day6_6f089762:

    # GRC "I think you are taking the taint away... or maybe neutralizing it. I don't know."
    GRC "Creo que estás eliminando la corrupción... o quizá neutralizándola. No lo sé."

# game/chapters/6_day.rpyc:1219
translate es call1_day6_6e33f2a2:

    # GRC "I got an even better look at your soul when I visited you."
    GRC "Tuve una mejor visión de tu alma cuando te visité."

# game/chapters/6_day.rpyc:1221
translate es call1_day6_df561057:

    # GRC "I understand the pulsing now. It's because you do not have a full soul."
    GRC "Ahora entiendo el pulso. Es porque no tienes un alma completa."

# game/chapters/6_day.rpyc:1230
translate es call1_day6_40d5b81f:

    # GRC "I have... never seen a soul that is not full..."
    GRC "Nunca.... he visto un alma que no esté completa..."

# game/chapters/6_day.rpyc:1232
translate es call1_day6_f9da1ad6:

    # GRC "So I cannot answer your question."
    GRC "Así que no puedo responder a tu pregunta."

# game/chapters/6_day.rpyc:1237
translate es call1_day6_85918f43:

    # GRC "But if you were to give it all away...."
    GRC "Pero si la entregaras toda..."

# game/chapters/6_day.rpyc:1239
translate es call1_day6_e4a86eea:

    # GRC "Well, I assume you would just... simply cease to be."
    GRC "Bueno, supongo que simplemente... dejarías de existir."

# game/chapters/6_day.rpyc:1246
translate es call1_day6_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/6_day.rpyc:1247
translate es call1_day6_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/6_day.rpyc:1253
translate es call1_day6_1e30d68b:

    # GRC "I would never forget. You. Our time together."
    GRC "Nunca lo olvidaría. A ti. Nuestro tiempo juntos."

# game/chapters/6_day.rpyc:1254
translate es call1_day6_2b8ab6e4:

    # GRC "So... maybe try to be careful."
    GRC "Así que... quizá intenta tener cuidado."

# game/chapters/6_day.rpyc:1255
translate es call1_day6_8d7a3fbb:

    # GRC "Don't wish too hard is all I'm saying."
    GRC "Solo digo que no desees con demasiada fuerza."

# game/chapters/6_day.rpyc:1266
translate es call1_day6_02c09232:

    # GRC "Uh."
    GRC "Uh."

# game/chapters/6_day.rpyc:1267
translate es call1_day6_2be91614:

    # GRC "I don't really know if that's how this works."
    GRC "No sé si eso funciona así realmente."

# game/chapters/6_day.rpyc:1269
translate es call1_day6_35bcad1c:

    # GRC "But if it makes you feel better Sunshine, sure."
    GRC "Pero si te hace sentir mejor, Solecito, claro."

# game/chapters/6_day.rpyc:1277
translate es call1_day6_8baf5f41:

    # GRC "Good."
    GRC "Bueno."

# game/chapters/6_day.rpyc:1278
translate es call1_day6_8d1e18ec:

    # GRC "I would expect no less from you."
    GRC "No esperaría menos de ti."

# game/chapters/6_day.rpyc:1286
translate es call1_day6_04e5a69d:

    # GRC "I'm sure it won't come to that. I've survived all this time on my own."
    GRC "Estoy seguro de que no llegará a eso. He sobrevivido todo este tiempo por mi cuenta."

# game/chapters/6_day.rpyc:1288
translate es call1_day6_94c82b72:

    # GRC "You don't need to overly concern yourself with my health."
    GRC "No necesitas preocuparte demasiado por mi salud."

# game/chapters/6_day.rpyc:1290
translate es call1_day6_aa2421a7:

    # GRC "Anyway, aren't you supposed to be focused on keeping your soul and not giving it away?"
    GRC "De todos modos, ¿no se supone que debes concentrarte en conservar tu alma y no en regalarla?"

# game/chapters/6_day.rpyc:1291
translate es call1_day6_ae00afe6:

    # GRC "Focus on our bet. Focus on trying to take my soul."
    GRC "Concéntrate en nuestra apuesta. Concéntrate en intentar tomar mi alma."

# game/chapters/6_day.rpyc:1305
translate es call1_day6_27736588:

    # GRC "I do like your confidence, my little mortal."
    GRC "Me gusta tu confianza, mi mortal."

# game/chapters/6_day.rpyc:1306
translate es call1_day6_fe588614:

    # GRC "We'll see how long that holds up."
    GRC "Ya veremos cuánto te dura."

# game/chapters/6_day.rpyc:1320
translate es call1_day6_da78e520:

    # GRC "I don't really think that would be a good idea."
    GRC "No creo que sea una buena idea."

# game/chapters/6_day.rpyc:1321
translate es call1_day6_4fcc199f:

    # GRC "This is obviously something you cannot control."
    GRC "Obviamente esto es algo que no puedes controlar."

# game/chapters/6_day.rpyc:1323
translate es call1_day6_d75a76e2:

    # GRC "You could take on more than your body could deal with."
    GRC "Podrías absorber más de lo que tu cuerpo puede soportar."

# game/chapters/6_day.rpyc:1327
translate es call1_day6_f6f8be8d:

    # GRC "That is not something that can be taught. At least, not by me..."
    GRC "Eso no es algo que se pueda enseñar. Al menos, no por mí..."

# game/chapters/6_day.rpyc:1329
translate es call1_day6_ec5d32be:

    # GRC "I don't understand how it's even possible. I've never met someone with your abilities."
    GRC "No entiendo cómo es siquiera posible. Nunca he conocido a alguien con tus habilidades."

# game/chapters/6_day.rpyc:1331
translate es call1_day6_92e9bf40:

    # GRC "How or why you're able to do what you can... I cannot even guess."
    GRC "Cómo o por qué puedes hacer lo que haces... ni siquiera puedo imaginarlo."

# game/chapters/6_day.rpyc:1346
translate es call1_day6_cf43eb42:

    # GRC "...You can do whatever you wish."
    GRC "...Puedes hacer lo que desees."

# game/chapters/6_day.rpyc:1348
translate es call1_day6_2e81d297:

    # GRC "You are aware I am trying to take your soul, right?"
    GRC "Eres consciente de que estoy intentando tomar tu alma, ¿verdad?"

# game/chapters/6_day.rpyc:1355
translate es call1_day6_1bad71ea:

    # GRC "And yet you still... you're such a confusing mortal."
    GRC "Y aun así tú... eres un mortal tan confuso."

# game/chapters/6_day.rpyc:1356
translate es call1_day6_25eec6b4:

    # GRC "Fine."
    GRC "Bueno."

# game/chapters/6_day.rpyc:1358
translate es call1_day6_6cfb4d49:

    # GRC "But if you take it too far, you'll..."
    GRC "Pero si lo llevas demasiado lejos, tú..."

# game/chapters/6_day.rpyc:1369
translate es call1_day6_78d4d036:

    # GRC "I wouldn't expect any less, Sunshine."
    GRC "No esperaría menos, cariño."

# game/chapters/6_day.rpyc:1377
translate es call1_day6_d52325f2:

    # GRC "You can try to... alleviate it, if you truly wish."
    GRC "Puedes intentar... aliviarlo, si realmente lo deseas."

# game/chapters/6_day.rpyc:1378
translate es call1_day6_4dc50001:

    # GRC "As long as I can keep an eye on you, it should be fine."
    GRC "Mientras pueda vigilarte, debería estar bien."

# game/chapters/6_day.rpyc:1380
translate es call1_day6_1f2fab6b:

    # GRC "Wouldn't want you to get too corrupted, after all."
    GRC "Después de todo, no quisiera que te corrompieras demasiado."

# game/chapters/6_day.rpyc:1389
translate es call1_day6_07ab7154:

    # GRC "...What?"
    GRC "...¿Qué?"

# game/chapters/6_day.rpyc:1405
translate es call1_day6_b54bb891:

    # GRC "And this bucket list of yours involves MARRIAGE?"
    GRC "¿Y esta lista de deseos tuya incluye MATRIMONIO?"

# game/chapters/6_day.rpyc:1419
translate es call1_day6_0bac6bac:

    # GRC "......."
    GRC "......."

# game/chapters/6_day.rpyc:1421
translate es call1_day6_b8c4edfa:

    # GRC "It... you... ugh...!"
    GRC "Eso... tú... ¡ugh...!"

# game/chapters/6_day.rpyc:1422
translate es call1_day6_f1e08086:

    # GRC "We're talking about something serious, you know..."
    GRC "Estamos hablando de algo serio, ¿sabes...?"

# game/chapters/6_day.rpyc:1423
translate es call1_day6_5b1469e6:

    # GRC "And then you start spouting nonsense about marriage..."
    GRC "Y luego empiezas a decir tonterías sobre el matrimonio..."

# game/chapters/6_day.rpyc:1429
translate es call1_day6_d1cec93b:

    # GRC "........."
    GRC "........."

# game/chapters/6_day.rpyc:1430
translate es call1_day6_3c6970ed:

    # GRC "Let's... let's worry about your soul for now, and working out why you are how you are..."
    GRC "Mejor... ocupémonos de tu alma por ahora, y de entender por qué eres como eres..."

# game/chapters/6_day.rpyc:1431
translate es call1_day6_34e31ad2:

    # GRC "Marriage... ahem, we can... talk about it later..."
    GRC "El matrimonio... ejem, podemos... hablar de eso después..."

# game/chapters/6_day.rpyc:1447
translate es call1_day6_96753f4b:

    # GRC "I'm glad you're taking this seriously."
    GRC "Me alegra que te tomes esto en serio."

# game/chapters/6_day.rpyc:1455
translate es call1_day6_a1fb91e2:

    # GRC "Some reapers are not miserable. Like me."
    GRC "Algunas parcas no son miserables. Como yo."

# game/chapters/6_day.rpyc:1467
translate es call1_day6_32302918:

    # GRC "You? Serious?"
    GRC "¿Tú? ¿En serio?"

# game/chapters/6_day.rpyc:1468
translate es call1_day6_4a58c5ce:

    # GRC "Is that possible for you?"
    GRC "¿Eso es posible para ti?"

# game/chapters/6_day.rpyc:1478
translate es call1_day6_b66116ea:

    # GRC "I don't know."
    GRC "No lo sé."

# game/chapters/6_day.rpyc:1480
translate es call1_day6_6bcbebae:

    # GRC "This is not a common thing to happen."
    GRC "Esto no es algo común."

# game/chapters/6_day.rpyc:1482
translate es call1_day6_84693ec3:

    # GRC "In fact it's so uncommon I'd say you are the first."
    GRC "De hecho, es tan inusual que diría que eres el primero caso."

# game/chapters/6_day.rpyc:1491
translate es call1_day6_8c9198d1:

    # GRC "I have no tips to give you. This is unprecedented."
    GRC "No tengo consejos que darte. Esto no tiene precedentes."

# game/chapters/6_day.rpyc:1492
translate es call1_day6_04400948:

    # GRC "Just... stop wishing and hoping to heal people."
    GRC "Solo... deja de desear y esperar curar a las personas."

# game/chapters/6_day.rpyc:1493
translate es call1_day6_b931dbb8:

    # GRC "And we'll see what happens from there."
    GRC "Y veremos qué pasa a partir de ahí."

# game/chapters/6_day.rpyc:1495
translate es call1_day6_98a5ed77:

    # GRC "Keep that magic healing for your pet, perhaps. I know you care deeply about the creature."
    GRC "Guarda esa magia sanadora para tu mascota, quizá. Sé que te importa mucho la criatura."

# game/chapters/6_day.rpyc:1506
translate es call1_day6_4e9b8f30:

    # GRC "I bet I am."
    GRC "Apuesto a que sí."

# game/chapters/6_day.rpyc:1507
translate es call1_day6_7b676143:

    # GRC "Go on, tell me. Is it my charm? My looks? My fashion sense?"
    GRC "Vamos, dime. ¿Es mi encanto? ¿Mi aspecto? ¿Mi sentido de la moda?"

# game/chapters/6_day.rpyc:1518
translate es call1_day6_a280de5a:

    # GRC "You."
    GRC "Tú."

# game/chapters/6_day.rpyc:1538
translate es call1_day6_eeb77df2:

    # GRC "Excuse me?"
    GRC "¿Perdón?"

# game/chapters/6_day.rpyc:1542
translate es call1_day6_0dfa6290:

    # GRC "I have not heard of it."
    GRC "No he oído hablar de eso."

# game/chapters/6_day.rpyc:1543
translate es call1_day6_a3bb667e:

    # GRC "So I suppose the answer is no."
    GRC "Así que supongo que la respuesta es no."

# game/chapters/6_day.rpyc:1553
translate es call1_day6_45715876:

    # GRC "...A 'friendly ghost' vibe??"
    GRC "...¿Una vibra de 'fantasma amigable'?"

# game/chapters/6_day.rpyc:1561
translate es call1_day6_5c9edb0e:

    # GRC "I am neither of those things."
    GRC "No soy ninguna de esas cosas."

# game/chapters/6_day.rpyc:1568
translate es call1_day6_606fe122:

    # GRC "Well, I'm certain that I am not a ghost."
    GRC "Bueno, estoy seguro de que no soy un fantasma."

# game/chapters/6_day.rpyc:1569
translate es call1_day6_ae851bc9:

    # GRC "Like I've said many times, you really do have a vivid imagination."
    GRC "Como he dicho muchas veces, realmente tienes una imaginación muy vívida."

# game/chapters/6_day.rpyc:1577
translate es call1_day6_b44f7fde:

    # GRC "Must you let it run so wild all the time?"
    GRC "¿Tienes que dejarla correr tan salvaje todo el tiempo?"

# game/chapters/6_day.rpyc:1588
translate es call1_day6_bf98cfd1:

    # GRC "And that is freeing to you how?"
    GRC "¿Y eso te resulta liberador de alguna forma?"

# game/chapters/6_day.rpyc:1589
translate es call1_day6_65178321:

    # GRC "That just sounds confusing to me."
    GRC "Eso solo me suena confuso."

# game/chapters/6_day.rpyc:1602
translate es call1_day6_6dde856d:

    # GRC "Hmmmm."
    GRC "Mmmm."

# game/chapters/6_day.rpyc:1607
translate es call1_day6_147bb49e:

    # GRC "You want to leave reality?"
    GRC "¿Quieres dejar la realidad?"

# game/chapters/6_day.rpyc:1620
translate es call1_day6_bde8ac18:

    # GRC "Maybe you should."
    GRC "Tal vez deberías."

# game/chapters/6_day.rpyc:1623
translate es call1_day6_83675cc2:

    # GRC "Hmm."
    GRC "Hmm."

# game/chapters/6_day.rpyc:1625
translate es call1_day6_fcb81a51:

    # GRC "Well, I cannot say I fully understand, but it seems like a good use of your creative talents."
    GRC "Bueno, no puedo decir que lo entienda del todo, pero parece un buen uso de tu talento creativo."

# game/chapters/6_day.rpyc:1629
translate es call1_day6_0ac5fb96:

    # GRC "Even if your imagination perhaps runs a little {i}too{/i} wild sometimes..."
    GRC "Aunque tu imaginación a veces se desborde un poco {i}demasiado{/i}..."

# game/chapters/6_day.rpyc:1641
translate es call1_day6_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/6_day.rpyc:1643
translate es call1_day6_54484d36:

    # GRC "Are you lonely?"
    GRC "¿Sientes soledad?"

# game/chapters/6_day.rpyc:1650
translate es call1_day6_008afe10_3:

    # GRC "..."
    GRC "..."

# game/chapters/6_day.rpyc:1652
translate es call1_day6_d37f16bb:

    # GRC "Well you have me to talk to now."
    GRC "Bueno, ahora me tienes a mí para hablar."

# game/chapters/6_day.rpyc:1660
translate es call1_day6_29527113:

    # GRC "I'll take 'not so bad', I suppose."
    GRC "Supongo que aceptaré un 'no tan mal'."

# game/chapters/6_day.rpyc:1664
translate es call1_day6_6ec5da7a:

    # GRC "But... you aren't like me."
    GRC "Pero... no eres como yo."

# game/chapters/6_day.rpyc:1669
translate es call1_day6_deb940b8:

    # GRC "Thank the Heavens."
    GRC "Gracias a los Cielos."

# game/chapters/6_day.rpyc:1682
translate es call1_day6_95e590f7:

    # GRC "Well."
    GRC "Bueno."

# game/chapters/6_day.rpyc:1684
translate es call1_day6_29ea981e:

    # GRC "Uh..."
    GRC "Eh..."

# game/chapters/6_day.rpyc:1686
translate es call1_day6_e08b0be3:

    # GRC "Do you want to be someone else, mortal?"
    GRC "¿Quieres ser alguien más, mortal?"

# game/chapters/6_day.rpyc:1687
translate es call1_day6_6c831fb4:

    # GRC "Because I think you can be whoever you want to be."
    GRC "Porque creo que puedes ser quien quieras ser."

# game/chapters/6_day.rpyc:1689
translate es call1_day6_32f77a9e:

    # GRC "Minus making deals with devils, maybe."
    GRC "Excepto si haces tratos con demonios, tal vez."

# game/chapters/6_day.rpyc:1691
translate es call1_day6_ac247ed2:

    # GRC "Because that would be stupid. Devils are something you should not mess with."
    GRC "Porque eso sería estúpido. Los demonios no son con los que deberías meterte."

# game/chapters/6_day.rpyc:1698
translate es call1_day6_c3f64545:

    # GRC "Of course it does."
    GRC "Por supuesto que sí."

# game/chapters/6_day.rpyc:1699
translate es call1_day6_6004a80f:

    # GRC "Your behaviour is..."
    GRC "Tu comportamiento es..."

# game/chapters/6_day.rpyc:1700
translate es call1_day6_2da2d5ee:

    # GRC "Certainly odd. I have never met another mortal like you."
    GRC "Ciertamente extraño. Nunca he conocido a otro mortal como tú."

# game/chapters/6_day.rpyc:1701
translate es call1_day6_45dc6155:

    # GRC "Not that I've spoken to many mortals, but you get the idea..."
    GRC "No es que haya hablado con muchos mortales, pero entiendes la idea..."

# game/chapters/6_day.rpyc:1713
translate es call1_day6_008afe10_4:

    # GRC "..."
    GRC "..."

# game/chapters/6_day.rpyc:1718
translate es call1_day6_1b68e1cd:

    # GRC "Small brains are so easily amused..."
    GRC "Los cerebros pequeños se entretienen tan fácilmente..."

# game/chapters/6_day.rpyc:1723
translate es call1_day6_c829cb92:

    # GRC "You aren't welcome. In the slightest."
    GRC "Tu presencia no es bienvenida. Ni un poco."

# game/chapters/6_day.rpyc:1732
translate es call1_day6_0a2c4bf7:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/6_day.rpyc:1741
translate es call1_day6_4300a427:

    # GRC "I am... not a maiden. Nor am I blushing. You are obviously blind."
    GRC "Yo no soy... una doncella. Ni estoy sonrojado. Es evidente que tienes ceguera."

# game/chapters/6_day.rpyc:1749
translate es call1_day6_4265b4e3:

    # GRC "Stop that."
    GRC "Detén eso."

# game/chapters/6_day.rpyc:1754
translate es call1_day6_01b79f87:

    # GRC "I am... intrigued."
    GRC "Estoy... intrigado."

# game/chapters/6_day.rpyc:1756
translate es call1_day6_b289c274:

    # GRC "But you also look rather pleased with yourself right now."
    GRC "Pero también pareces estar bastante conforme contigo en este momento."

# game/chapters/6_day.rpyc:1757
translate es call1_day6_443e85cc:

    # GRC "That makes me not want to know."
    GRC "Eso hace que no quiera saber."

# game/chapters/6_day.rpyc:1770
translate es call1_day6_6bf2263b:

    # GRC "And thank the Hells for that."
    GRC "Y gracias a los Infiernos por eso."

# game/chapters/6_day.rpyc:1778
translate es call1_day6_26d3593e:

    # GRC "Why do you look like that?"
    GRC "¿Por qué tienes esa cara?"

# game/chapters/6_day.rpyc:1783
translate es call1_day6_ef8ce177:

    # GRC "Seriously, what are you doing?"
    GRC "En serio, ¿qué estás haciendo?"

# game/chapters/6_day.rpyc:1784
translate es call1_day6_fa7046d8:

    # GRC "Your face is going red."
    GRC "Tu cara se está poniendo roja."

# game/chapters/6_day.rpyc:1789
translate es call1_day6_64873d2e:

    # GRC "Are you actually holding your breath right now?"
    GRC "¿De verdad estás conteniendo la respiración ahora mismo?"

# game/chapters/6_day.rpyc:1809
translate es call1_day6_f7507b35:

    # GRC "What?"
    GRC "¿Qué?"

# game/chapters/6_day.rpyc:1820
translate es call1_day6_008afe10_5:

    # GRC "..."
    GRC "..."

# game/chapters/6_day.rpyc:1822
translate es call1_day6_ba6eda82:

    # GRC "So {i}that's{/i} what you were doing..."
    GRC "Así que {i}eso{/i} era lo que estabas haciendo..."

# game/chapters/6_day.rpyc:1823
translate es call1_day6_6865bbe4:

    # GRC "Why did I ever think you couldn't get any stranger?"
    GRC "¿Por qué alguna vez pensé que no podías ser más bicho raro?"

# game/chapters/6_day.rpyc:1824
translate es call1_day6_52a12e7b:

    # GRC "How was holding your breath meant to help?"
    GRC "¿Cómo se suponía que contener la respiración iba a ayudar?"

# game/chapters/6_day.rpyc:1831
translate es call1_day6_363e0dc2:

    # GRC "Sure..."
    GRC "Claro..."

# game/chapters/6_day.rpyc:1841
translate es call1_day6_e2cef3b9:

    # GRC "I don't need to let my imagination get the better of me for those things."
    GRC "No necesito dejar que mi imaginación me domine para esas cosas."

# game/chapters/6_day.rpyc:1843
translate es call1_day6_05e12fdc:

    # GRC "I can unwind here in my own space."
    GRC "Puedo relajarme aquí, en mi propio espacio."

# game/chapters/6_day.rpyc:1850
translate es call1_day6_60c51e01:

    # GRC "Hells..."
    GRC "Infiernos..."

# game/chapters/6_day.rpyc:1851
translate es call1_day6_fdb66976:

    # GRC "Your mind is positively filthy, mortal. You ought to clean it up a little."
    GRC "Tu mente es positivamente sucia, mortal. Deberías limpiarla un poco."

# game/chapters/6_day.rpyc:1859
translate es call1_day6_d5f1d172:

    # GRC "You... are trouble. More trouble than I can deal with..."
    GRC "Tú... eres un problema. Más problema del que puedo manejar..."

# game/chapters/6_day.rpyc:1870
translate es call1_day6_008afe10_6:

    # GRC "..."
    GRC "..."

# game/chapters/6_day.rpyc:1878
translate es call1_day6_82e2076d:

    # GRC "You-"
    GRC "Tú-"

# game/chapters/6_day.rpyc:1884
translate es call1_day6_3418ff4b:

    # GRC "You are a little shit. Gods, I did nothing to deserve this..."
    GRC "Eres una pequeña mierda. Dioses, no hice nada para merecer esto..."

# game/chapters/6_day.rpyc:1904
translate es call1_day6_6699aaf2:

    # GRC "I was never edgy. I am death."
    GRC "Nunca fui un 'edgy'. Soy la muerte."

# game/chapters/6_day.rpyc:1914
translate es call1_day6_65122790_1:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/6_day.rpyc:1920
translate es call1_day6_c51dbd6f:

    # GRC "I don't believe I have changed all that much."
    GRC "No creo haber cambiado tanto."

# game/chapters/6_day.rpyc:1925
translate es call1_day6_008afe10_7:

    # GRC "..."
    GRC "..."

# game/chapters/6_day.rpyc:1927
translate es call1_day6_62f46324:

    # GRC "I don't see you as a friend."
    GRC "No te veo como una amistad."

# game/chapters/6_day.rpyc:1951
translate es call1_day6_188ad49a:

    # GRC "Wait a second-"
    GRC "Espera un segundo-"

# game/chapters/6_day.rpyc:1958
translate es call1_day6_8da23161:

    # GRC "...."
    GRC "...."

# game/chapters/6_day.rpyc:1967
translate es call1_day6_5da9a518:

    # GRC "You aren't listening."
    GRC "No estás escuchando."

# game/chapters/6_day.rpyc:1968
translate es call1_day6_7df7cefb:

    # GRC "It's true I do not think of you as a friend, but-"
    GRC "Es cierto que no te considero una amistad, pero-"

# game/chapters/6_day.rpyc:1979
translate es call1_day6_b946e1c2:

    # GRC "You misunderstand."
    GRC "Malinterpretas."

# game/chapters/6_day.rpyc:1981
translate es call1_day6_b0a781cb:

    # GRC "I thought it was.... pretty straightforward."
    GRC "Pensé que era... bastante claro."

# game/chapters/6_day.rpyc:1982
translate es call1_day6_3e90d1d7:

    # GRC "Fuck..."
    GRC "Mierda..."

# game/chapters/6_day.rpyc:1984
translate es call1_day6_663210a8:

    # GRC "I thought you were... more perceptive than this..."
    GRC "Pensé que tenias... más percepción que esto..."

# game/chapters/6_day.rpyc:1986
translate es call1_day6_9bbba847:

    # GRC "I have been flirting with you! For days!"
    GRC "¡He estado coqueteando contigo! ¡Durante días!"

# game/chapters/6_day.rpyc:1993
translate es call1_day6_a046ff1f:

    # GRC "You aren't {i}that{/i} stupid."
    GRC "No eres {i}tan{/i} idiota."

# game/chapters/6_day.rpyc:1998
translate es call1_day6_60c51e01_1:

    # GRC "Hells..."
    GRC "Infiernos..."

# game/chapters/6_day.rpyc:2002
translate es call1_day6_008afe10_8:

    # GRC "..."
    GRC "..."

# game/chapters/6_day.rpyc:2012
translate es call1_day6_0c65acbe:

    # GRC "Fuck."
    GRC "Mierda."

# game/chapters/6_day.rpyc:2014
translate es call1_day6_6e1f709e:

    # GRC "Gods, this isn't good..."
    GRC "Dioses, esto no es bueno..."

# game/chapters/6_day.rpyc:2022
translate es call1_day6_0a2c4bf7_1:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/6_day.rpyc:2026
translate es call1_day6_65122790_2:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/6_day.rpyc:2031
translate es call1_day6_1dc1b57f:

    # GRC "Sunshine..."
    GRC "Solecito..."

# game/chapters/6_day.rpyc:2039
translate es afterdots_4485545b:

    # GRC "It's not something I... expected. I could never have expected this."
    GRC "No es algo que... esperara. Nunca podría haber esperado esto."

# game/chapters/6_day.rpyc:2041
translate es afterdots_3e0dd4a5:

    # GRC "It's not something I chose! It's... it's a terrible idea all around, honestly..."
    GRC "¡No es algo que eligiera! Es... es una terrible idea en todos los sentidos, sinceramente..."

# game/chapters/6_day.rpyc:2046
translate es afterdots_e4e28fa5:

    # GRC "Stop talking."
    GRC "Deja de hablar."

# game/chapters/6_day.rpyc:2047
translate es afterdots_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/6_day.rpyc:2056
translate es confession_97905759:

    # GRC "I enjoy your company..."
    GRC "Disfruto de tu compañía..."

# game/chapters/6_day.rpyc:2058
translate es confession_98bd582b:

    # GRC "I really enjoy it, okay?"
    GRC "Realmente la disfruto, ¿de acuerdo?"

# game/chapters/6_day.rpyc:2060
translate es confession_49d78d75:

    # GRC "I enjoy it {i}too{/i} much. Way too much."
    GRC "La disfruto {i}demasiado{/i}. Demasiado."

# game/chapters/6_day.rpyc:2062
translate es confession_f7049bb7:

    # GRC "Why? Why me? Why do I have to feel like this? It's unfair, honestly."
    GRC "¿Por qué? ¿Por qué yo? ¿Por qué tengo que sentir esto? Es injusto, sinceramente."

# game/chapters/6_day.rpyc:2063
translate es confession_2388daa3:

    # GRC "I have done nothing but follow the rules up until now. I have been a good reaper."
    GRC "No he hecho más que seguir las reglas hasta ahora. He sido una buena parca."

# game/chapters/6_day.rpyc:2064
translate es confession_4db9b22b:

    # GRC "And now my heart tells me to throw it all away."
    GRC "Y ahora mi corazón me dice que lo eche todo a perder."

# game/chapters/6_day.rpyc:2072
translate es confession_0b409f4b:

    # GRC "Sunshine, I..."
    GRC "Solecito, yo..."

# game/chapters/6_day.rpyc:2079
translate es confession_f5cb970e:

    # GRC "O... Obviously."
    GRC "O... Obviamente."

# game/chapters/6_day.rpyc:2091
translate es confession_819a09b3:

    # GRC "I didn't expect to..."
    GRC "No esperaba..."

# game/chapters/6_day.rpyc:2092
translate es confession_fee8f453:

    # GRC "To feel like this."
    GRC "Sentir esto."

# game/chapters/6_day.rpyc:2094
translate es confession_2ef12f9c:

    # GRC "Feel so... strongly."
    GRC "Sentir tan... intensamente."

# game/chapters/6_day.rpyc:2096
translate es confession_dcbd773e:

    # GRC "You were supposed to just be another job. {i}Are{/i} supposed to be just another job."
    GRC "Se suponía que solo ibas a ser otro trabajo. {i}Se supone{/i} que solo eres otro trabajo."

# game/chapters/6_day.rpyc:2101
translate es confession_250eced8:

    # GRC "Your soul is one I must collect."
    GRC "Tu alma es una que debo recolectar."

# game/chapters/6_day.rpyc:2103
translate es confession_b6d472c3:

    # GRC "There is no way out of it. It is my job as a reaper."
    GRC "No hay salida de eso. Es mi trabajo como parca."

# game/chapters/6_day.rpyc:2104
translate es confession_40e042d7:

    # GRC "It's a task I must fulfill."
    GRC "Es una tarea que debo cumplir."

# game/chapters/6_day.rpyc:2106
translate es confession_cb31079a:

    # GRC "But, I... I find myself wanting to disobey, to break all the rules I have so carefully followed until this week..."
    GRC "Pero yo... me descubro queriendo desobedecer, romper todas las reglas que he seguido tan cuidadosamente hasta esta semana..."

# game/chapters/6_day.rpyc:2113
translate es confession_4395b1cf:

    # GRC "If I do, they'll just send someone else."
    GRC "Si lo hago, solo enviarán a alguien más."

# game/chapters/6_day.rpyc:2114
translate es confession_d28af715:

    # GRC "I am easily replaceable. I am one of thousands."
    GRC "Soy fácilmente reemplazable. Soy uno entre miles."

# game/chapters/6_day.rpyc:2121
translate es confession_4723e232:

    # GRC "But that's not what I'm trying to say exactly."
    GRC "Pero eso no es exactamente lo que intento decir."

# game/chapters/6_day.rpyc:2126
translate es confession_32768eb2:

    # GRC "What I am trying to say is that I..."
    GRC "Lo que intento decir es que yo..."

# game/chapters/6_day.rpyc:2127
translate es confession_1444e501:

    # GRC "I don't want to be friends."
    GRC "No quiero ser amigos."

# game/chapters/6_day.rpyc:2129
translate es confession_54c16c92:

    # GRC "I don't want that at all."
    GRC "No quiero eso en absoluto."

# game/chapters/6_day.rpyc:2131
translate es confession_961347f7:

    # GRC "I've found myself wanting to be selfish."
    GRC "Me he encontrado queriendo ser egoísta."

# game/chapters/6_day.rpyc:2132
translate es confession_32bf1b2e:

    # GRC "Because I want more. More from you."
    GRC "Porque quiero más. Más de ti."

# game/chapters/6_day.rpyc:2133
translate es confession_e23f01a3:

    # GRC "More than friendship."
    GRC "Más que amistad."

# game/chapters/6_day.rpyc:2136
translate es confession_3c5dad58:

    # GRC "Tell me about it."
    GRC "Cuéntame sobre eso."

# game/chapters/6_day.rpyc:2138
translate es confession_cca39763:

    # GRC "S... somehow..."
    GRC "D... de alguna forma..."

# game/chapters/6_day.rpyc:2140
translate es confession_d22d8225:

    # GRC "Certain."
    GRC "Cierto."

# game/chapters/6_day.rpyc:2142
translate es confession_1746aedc:

    # GRC "I want you more than I've wanted anything before."
    GRC "Te deseo más de lo que he deseado cualquier cosa antes."

# game/chapters/6_day.rpyc:2143
translate es confession_b67cf124:

    # GRC "There is nothing in existence I want more and it is infuriating."
    GRC "No hay nada en existencia que quiera más y eso me enfurece."

# game/chapters/6_day.rpyc:2151
translate es confession_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/6_day.rpyc:2156
translate es confession_c6bd6d62:

    # GRC "I like you, Sunshine. I don't know why, or how, or what to do about it, but I..."
    GRC "Me gustas, Solecito. No sé por qué, ni cómo, ni qué hacer al respecto, pero..."

# game/chapters/6_day.rpyc:2158
translate es confession_fabe6d44:

    # GRC "I like you very much."
    GRC "Me gustas mucho."

# game/chapters/6_day.rpyc:2164
translate es confession_8e9f5319:

    # GRC "It angers me how much I can't hate you."
    GRC "Me enoja lo mucho que no puedo odiarte."

# game/chapters/6_day.rpyc:2165
translate es confession_40b7074e:

    # GRC "I should!"
    GRC "¡Debería hacerlo!"

# game/chapters/6_day.rpyc:2167
translate es confession_80aec9b4:

    # GRC "But instead you've... done this to me... ruined me completely."
    GRC "Pero en cambio tú... me has hecho esto... me has arruinado por completo."

# game/chapters/6_day.rpyc:2168
translate es confession_bf268fd1:

    # GRC "ANYWAY."
    GRC "EN FIN."

# game/chapters/6_day.rpyc:2169
translate es confession_07d26964:

    # GRC "Cool."
    GRC "Genial."

# game/chapters/6_day.rpyc:2171
translate es confession_5ae6eeb1:

    # GRC "Now that that's all said and done, I'm going to go."
    GRC "Ahora que ya está todo dicho y hecho, me voy."

# game/chapters/6_day.rpyc:2173
translate es confession_d3af2c0b:

    # GRC "Time for a long, cold shower."
    GRC "Hora de una ducha larga y fría."

# game/chapters/6_day.rpyc:2196
translate es chat2_day6_5348a82a:

    # player "Wow! You really said all that then left?!"
    player "¡Vaya! !¿De verdad dijiste todo eso y luego te fuiste?!"

# game/chapters/6_day.rpyc:2199
translate es chat2_day6_ab2b789c:

    # player "Come back!"
    player "¡Vuelve!"

# game/chapters/6_day.rpyc:2202
translate es chat2_day6_d18af592:

    # player "You don't need to be so shy!"
    player "¡No necesitas ser tan tímido!"

# game/chapters/6_day.rpyc:2203
translate es chat2_day6_dcfbcb5f:

    # GR "i am not being shy."
    GR "no estoy siendo tímido."

# game/chapters/6_day.rpyc:2206
translate es chat2_day6_7c72b21d:

    # player "Sounds like something a shy person would say."
    player "Suena como algo que diría una persona tímida."

# game/chapters/6_day.rpyc:2207
translate es chat2_day6_c3e0d1b1:

    # GR "you'll find i am actually quite forward."
    GR "verás que en realidad soy bastante directo."

# game/chapters/6_day.rpyc:2208
translate es chat2_day6_31542386:

    # GR "a shy person wouldn't be so straightforward about their desires."
    GR "una persona tímida no sería tan clara sobre sus deseos."

# game/chapters/6_day.rpyc:2211
translate es chat2_day6_da844650:

    # player "So you desire me?"
    player "¿Así que me deseas?"

# game/chapters/6_day.rpyc:2212
translate es chat2_day6_ccfdb749:

    # GR "that... should be obvious to you!"
    GR "¡eso... debería serte obvio!"

# game/chapters/6_day.rpyc:2216
translate es chat2_day6_cbcad116:

    # player "Weeeell, you do need a cold shower now... "
    player "Bueeeno, ahora sí que necesitas una ducha fría..."

# game/chapters/6_day.rpyc:2217
translate es chat2_day6_cc21bd84:

    # GR "!!!"
    GR "!!!"

# game/chapters/6_day.rpyc:2218
translate es chat2_day6_ec9d2876:

    # GR "that is... unrelated!"
    GR "eso es... irrelevante!"

# game/chapters/6_day.rpyc:2219
translate es chat2_day6_f9e4153e:

    # GR "i must wash my hair! that's all!"
    GR "¡debo lavarme el cabello! ¡eso es todo!"

# game/chapters/6_day.rpyc:2223
translate es chat2_day6_1a1e439f:

    # player "Glad I have that effect on you, hehe ;D"
    player "Me alegra causar ese efecto en ti, jeje ;D"

# game/chapters/6_day.rpyc:2224
translate es chat2_day6_f6b82922:

    # GR "...i can just imagine the smirk on your face."
    GR "...puedo imaginarme perfectamente la sonrisa en tu cara."

# game/chapters/6_day.rpyc:2225
translate es chat2_day6_2950600a:

    # GR "you are a wicked [woman], mortal."
    GR "eres un[woman!t] con poca moral, mortal."

# game/chapters/6_day.rpyc:2228
translate es chat2_day6_94e0cdb2:

    # player "I'd still call you shy."
    player "Aun así diría que eres tímido."

# game/chapters/6_day.rpyc:2229
translate es chat2_day6_6f2155f3:

    # GR "how so?"
    GR "¿cómo así?"

# game/chapters/6_day.rpyc:2233
translate es chat2_day6_4910fa74:

    # player "It took you this long to admit what was obvious."
    player "Te tomó todo este tiempo admitir lo que era obvio."

# game/chapters/6_day.rpyc:2234
translate es chat2_day6_c30211c0:

    # GR "i..."
    GR "Yo..."

# game/chapters/6_day.rpyc:2237
translate es chat2_day6_d628459f:

    # player "And you did it with cheeks that looked like tomatoes."
    player "Y lo hiciste con las mejillas rojas como tomates."

# game/chapters/6_day.rpyc:2238
translate es chat2_day6_19f0b618:

    # GR "completely unrelated."
    GR "totalmente irrelevante."

# game/chapters/6_day.rpyc:2239
translate es chat2_day6_3ac10d2c:

    # GR "{image=grumpy}"
    GR "{image=grumpy}"

# game/chapters/6_day.rpyc:2244
translate es chat2_day6_1030d201:

    # player "By the way, since it's somewhat topical..."
    player "Por cierto, ya que el tema viene al caso..."

# game/chapters/6_day.rpyc:2247
translate es chat2_day6_d08c4ecd:

    # player "Do you ever cut your hair?"
    player "¿Alguna vez te cortas el cabello?"

# game/chapters/6_day.rpyc:2249
translate es chat2_day6_7cc66a34:

    # GR "you don't like my hair?"
    GR "¿no te gusta mi cabello?"

# game/chapters/6_day.rpyc:2252
translate es chat2_day6_be9dac41:

    # player "No, I absolutely do!"
    player "¡No, me encanta!"

# game/chapters/6_day.rpyc:2254
translate es chat2_day6_8c8f7853:

    # player "I'm actually kinda obsessed with it."
    player "De hecho estoy algo obsesionado con él."

# game/chapters/6_day.rpyc:2257
translate es chat2_day6_5db3fa12:

    # player "I was just curious. It's very long! It must have taken a long time to grow."
    player "Solo tenía curiosidad. ¡Es muy largo! Debió tomar mucho tiempo dejarlo crecer."

# game/chapters/6_day.rpyc:2258
translate es chat2_day6_ba221751:

    # GR "i don't."
    GR "no."

# game/chapters/6_day.rpyc:2259
translate es chat2_day6_3c7e4f18:

    # GR "there is no need for me to cut it, anyway."
    GR "de todas formas, no hay necesidad de cortarlo."

# game/chapters/6_day.rpyc:2262
translate es chat2_day6_9550eb67:

    # player "It really suits you."
    player "Te queda muy bien."

# game/chapters/6_day.rpyc:2263
translate es chat2_day6_2340fce9:

    # GR "thanks."
    GR "gracias."

# game/chapters/6_day.rpyc:2264
translate es chat2_day6_706cd605:

    # GR "your hairstyle... also suits you."
    GR "tu peinado... también te queda bien."

# game/chapters/6_day.rpyc:2266
translate es chat2_day6_b7df16c0:

    # player "I can't imagine you with shorter hair."
    player "No puedo imaginarte con el cabello más corto."

# game/chapters/6_day.rpyc:2269
translate es chat2_day6_2066a831:

    # player "The long hair is kinda iconic."
    player "El cabello largo es algo icónico."

# game/chapters/6_day.rpyc:2270
translate es chat2_day6_7a57311a:

    # GR "i agree."
    GR "estoy de acuerdo."

# game/chapters/6_day.rpyc:2273
translate es chat2_day6_7e199acb:

    # player "You'll just keep growing it, then?"
    player "¿Entonces seguirás dejándolo crecer?"

# game/chapters/6_day.rpyc:2274
translate es chat2_day6_5d364529:

    # GR "no."
    GR "no."

# game/chapters/6_day.rpyc:2277
translate es chat2_day6_333a538e:

    # player "But you just said..."
    player "Pero acabas de decir..."

# game/chapters/6_day.rpyc:2278
translate es chat2_day6_c45ddfe8:

    # GR "my hair does not grow like a mortals."
    GR "mi cabello no crece como el de los mortales."

# game/chapters/6_day.rpyc:2279
translate es chat2_day6_2b58f202:

    # GR "mine has simply always been this way."
    GR "el mío simplemente siempre ha sido así."

# game/chapters/6_day.rpyc:2282
translate es chat2_day6_821ebc5c:

    # player "If someone attacked you with scissors, it wouldn't grow back?"
    player "Si alguien te atacara con unas tijeras, ¿no volvería a crecer?"

# game/chapters/6_day.rpyc:2283
translate es chat2_day6_585c3336:

    # GR "do you plan to attack me with scissors?"
    GR "¿planeas atacarme con unas tijeras?"

# game/chapters/6_day.rpyc:2286
translate es chat2_day6_cf46fafb:

    # player "As fun as it would be to see you with shorter hair, no."
    player "Por más divertido que sería verte con el cabello corto, no."

# game/chapters/6_day.rpyc:2289
translate es chat2_day6_3e39f7c9:

    # player "I wouldn't do that to you."
    player "No te haría eso."

# game/chapters/6_day.rpyc:2292
translate es chat2_day6_45c4e868:

    # player "That's just mean."
    player "Eso sería cruel."

# game/chapters/6_day.rpyc:2295
translate es chat2_day6_6d087eb8:

    # player "And I... quite like how you are right now."
    player "Y yo... realmente me gustas tal como eres ahora."

# game/chapters/6_day.rpyc:2298
translate es chat2_day6_bc1b8032:

    # player "Pretty long hair and an attitude."
    player "Cabello largo y una actitud."

# game/chapters/6_day.rpyc:2301
translate es chat2_day6_626668c0:

    # player "What more could a [girl] ask for?"
    player "¿Qué más podría pedir un[girl!t]?"

# game/chapters/6_day.rpyc:2302
translate es chat2_day6_07c5684e:

    # GR "lots of money? fame? immortality?"
    GR "¿mucho dinero? ¿fama? ¿inmortalidad?"

# game/chapters/6_day.rpyc:2305
translate es chat2_day6_631a1605:

    # player "Alright, they sound good too."
    player "Bueno, suena bien también."

# game/chapters/6_day.rpyc:2308
translate es chat2_day6_59f2379a:

    # player "But I could also settle without."
    player "Pero también podría conformarme sin eso."

# game/chapters/6_day.rpyc:2311
translate es chat2_day6_b3a86444:

    # player "As long as I get my grumpy yet charming reaper that is."
    player "Mientras tenga a mi parca gruñona pero encantadora."

# game/chapters/6_day.rpyc:2312
translate es chat2_day6_5b66912c:

    # GR "i am sure there is plenty of charming reapers out there."
    GR "Estoy seguro de que hay muchas parcas encantadoras por ahí."

# game/chapters/6_day.rpyc:2315
translate es chat2_day6_b2f2e9af:

    # player "You forgot the grumpy part."
    player "Olvidaste la parte gruñona."

# game/chapters/6_day.rpyc:2316
translate es chat2_day6_8e7872ea:

    # GR "oh {i}so{/i} sorry, my bad."
    GR "oh {i}lo siento{/i}, mi error."

# game/chapters/6_day.rpyc:2319
translate es chat2_day6_c9ad7cd1:

    # player "Also, imagine the revenge you'd get on me..."
    player "Además, imagina la venganza que tendrías conmigo..."

# game/chapters/6_day.rpyc:2322
translate es chat2_day6_e2de89c9:

    # player "So no haircuts for you."
    player "Así que nada de cortes de cabello para ti."

# game/chapters/6_day.rpyc:2325
translate es chat2_day6_c72107d0:

    # player "I don't want one either though, just putting that out there."
    player "Aunque tampoco quiero uno, solo lo aclaro."

# game/chapters/6_day.rpyc:2326
translate es chat2_day6_34aaab5c:

    # GR "fortunately, i never offered you a haircut."
    GR "afortunadamente, nunca te ofrecí un corte de cabello."

# game/chapters/6_day.rpyc:2329
translate es chat2_day6_6e617216:

    # player "I was just making sure you knew not to cut it for me!"
    player "¡Solo quería asegurarme de que supieras que no debes cortarlo por mí!"

# game/chapters/6_day.rpyc:2330
translate es chat2_day6_0ec5cd6f:

    # GR "i am a {i}reaper{/i}, not a hairdresser."
    GR "soy un {i}parca{/i}, no un peluquero."

# game/chapters/6_day.rpyc:2333
translate es chat2_day6_097f7c19:

    # player "Hey, you can cut mine if you want."
    player "Oye, puedes cortarme el mío si quieres."

# game/chapters/6_day.rpyc:2336
translate es chat2_day6_ae060a08:

    # player "I've been thinking about getting it cut anyway."
    player "He estado pensando en cortarlo de todas formas."

# game/chapters/6_day.rpyc:2338
translate es chat2_day6_5f99c574:

    # player "I love spontaneous haircuts."
    player "Me encantan los cortes de cabello espontáneos."

# game/chapters/6_day.rpyc:2339
translate es chat2_day6_3b6cf974:

    # GR "i'm not cutting your hair."
    GR "no voy a cortarte el cabello."

# game/chapters/6_day.rpyc:2340
translate es chat2_day6_0ec5cd6f_1:

    # GR "i am a {i}reaper{/i}, not a hairdresser."
    GR "soy un {i}parca{/i}, no un peluquero."

# game/chapters/6_day.rpyc:2343
translate es chat2_day6_eb7c1812:

    # player "I feel like you'd be good at hairdressing too, for some reason."
    player "Siento que serías bueno como peluquero también, por alguna razón."

# game/chapters/6_day.rpyc:2346
translate es chat2_day6_cae85d52:

    # player "Ooooh, better watch your back Grim~"
    player "Ooooh, mejor cuídate las espaldas Parca~"

# game/chapters/6_day.rpyc:2347
translate es chat2_day6_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/6_day.rpyc:2350
translate es chat2_day6_1ee1676e:

    # player "I'm kidding, silly."
    player "Estoy bromeando, tontito."

# game/chapters/6_day.rpyc:2354
translate es chat2_day6_4e3c0247:

    # player "I wouldn't do that to anyone."
    player "No le haría eso a nadie."

# game/chapters/6_day.rpyc:2355
translate es chat2_day6_c05d6069:

    # GR "if you did, i would simply have to pluck each hair from your head."
    GR "si lo hicieras, simplemente tendría que arrancarte cada cabello de la cabeza."

# game/chapters/6_day.rpyc:2356
translate es chat2_day6_22ef4aa9:

    # GR "one by one."
    GR "uno por uno."

# game/chapters/6_day.rpyc:2357
translate es chat2_day6_c633f23f:

    # GR "{image=teehee}"
    GR "{image=teehee}"

# game/chapters/6_day.rpyc:2360
translate es chat2_day6_1a54cc60:

    # player "Noted."
    player "Anotado."

# game/chapters/6_day.rpyc:2362
translate es chat2_day6_a40eb36e:

    # player "Terrifying."
    player "Aterrador."

# game/chapters/6_day.rpyc:2365
translate es chat2_day6_7a7b00fa:

    # player "How do you feel about hair dye?"
    player "¿Qué opinas sobre teñirse el cabello?"

# game/chapters/6_day.rpyc:2366
translate es chat2_day6_5d364529_1:

    # GR "no."
    GR "no."

# game/chapters/6_day.rpyc:2369
translate es chat2_day6_d1b7374f:

    # player "You feel {i}no{/i} about hair dye?"
    player "¿No tienes {i}ninguna{/i} opinión sobre teñirse el cabello?"

# game/chapters/6_day.rpyc:2370
translate es chat2_day6_6adf895f:

    # GR "my hair is beautiful and pristine and i wish to keep it that way."
    GR "mi cabello es hermoso y puro y deseo mantenerlo así."

# game/chapters/6_day.rpyc:2373
translate es chat2_day6_f427a43b:

    # player "I still think you'd rock the black hair..."
    player "Todavía creo que te verías genial con el cabello negro..."

# game/chapters/6_day.rpyc:2374
translate es chat2_day6_056b134a:

    # GR "i am certain i would. but i like my hair the color it is."
    GR "estoy seguro de que sí. Pero me gusta el color que tiene mi cabello."

# game/chapters/6_day.rpyc:2377
translate es chat2_day6_cd995e2a:

    # player "I better return this hair dye, then..."
    player "Será mejor que devuelva este tinte para el cabello, entonces..."

# game/chapters/6_day.rpyc:2380
translate es chat2_day6_b2da3e0b:

    # player "I think I kept the receipt..."
    player "Creo que guardé el recibo..."

# game/chapters/6_day.rpyc:2381
translate es chat2_day6_7772a27d_1:

    # GR "..."
    GR "..."

# game/chapters/6_day.rpyc:2384
translate es chat2_day6_48c28d06:

    # player "Just kidding. Hehe."
    player "Es broma. Jeje."

# game/chapters/6_day.rpyc:2387
translate es chat2_day6_ecf1886a:

    # player "No hair dye! Got it!"
    player "¡Nada de tinte! ¡Entendido!"

# game/chapters/6_day.rpyc:2388
translate es chat2_day6_fd78f176:

    # GR "or haircuts."
    GR "o cortes de cabello."

# game/chapters/6_day.rpyc:2391
translate es chat2_day6_2b33a4ff:

    # player "Or haircuts!"
    player "¡O cortes de cabello!"

# game/chapters/6_day.rpyc:2394
translate es chat2_day6_0cfb3a47:

    # player "Can I play with it, though?"
    player "¿Puedo jugar con él, entonces?"

# game/chapters/6_day.rpyc:2397
translate es chat2_day6_8f287fbb:

    # player "Put pretty braids in it?"
    player "¿Hacerte trenzas bonitas?"

# game/chapters/6_day.rpyc:2398
translate es chat2_day6_312857ca:

    # GR "why? i... don't see how it would look good on me..."
    GR "¿por qué? Yo... no veo cómo me quedaría bien..."

# game/chapters/6_day.rpyc:2401
translate es chat2_day6_3cca776e:

    # player "I think it would look nice."
    player "Creo que se vería bonito."

# game/chapters/6_day.rpyc:2402
translate es chat2_day6_df1a005f:

    # GR "well, i... i wouldn't be totally opposed..."
    GR "bueno, yo... no estaría totalmente en contra..."

# game/chapters/6_day.rpyc:2403
translate es chat2_day6_d987e856:

    # GR "i will... have to think on the matter."
    GR "tendré... que pensarlo."

# game/chapters/6_day.rpyc:2406
translate es chat2_day6_6663007c:

    # player "Tell me when I can, then."
    player "Entonces dime cuándo puedo."

# game/chapters/6_day.rpyc:2407
translate es chat2_day6_d4ffb185:

    # GR "and if i decide to not let you?"
    GR "¿y si decido no dejarte?"

# game/chapters/6_day.rpyc:2410
translate es chat2_day6_539eb787:

    # player "You won't."
    player "No lo harás."

# game/chapters/6_day.rpyc:2413
translate es chat2_day6_29e90a2c:

    # player "I think you'd like the feeling of me playing with your hair."
    player "Creo que te gustaría la sensación de que juegue con tu cabello."

# game/chapters/6_day.rpyc:2414
translate es chat2_day6_7772a27d_2:

    # GR "..."
    GR "..."

# game/chapters/6_day.rpyc:2415
translate es chat2_day6_c854101d:

    # GR "maybe. who knows."
    GR "quizá. quién sabe."

# game/chapters/6_day.rpyc:2419
translate es chat2_day6_0cef4fef:

    # player "I'm using it as an excuse to touch you."
    player "Estoy usando eso como excusa para tocarte."

# game/chapters/6_day.rpyc:2420
translate es chat2_day6_cc21bd84_1:

    # GR "!!!"
    GR "!!!"

# game/chapters/6_day.rpyc:2423
translate es chat2_day6_99c5431d:

    # player "But I do also think it would look nice."
    player "Pero también creo que se vería bonito."

# game/chapters/6_day.rpyc:2426
translate es chat2_day6_b3814384:

    # player "But mainly I want to touch :D"
    player "Pero principalmente quiero tocarte :D"

# game/chapters/6_day.rpyc:2427
translate es chat2_day6_688eba9d:

    # GR "well... well maybe... that might sound nice..."
    GR "bueno... bueno, quizá... eso podría sonar agradable..."

# game/chapters/6_day.rpyc:2431
translate es chat2_day6_ec934462:

    # player "Maybe put some flowers in it?"
    player "¿Quizá poner algunas flores?"

# game/chapters/6_day.rpyc:2432
translate es chat2_day6_4f246c16:

    # GR "why would you want to do that?"
    GR "¿por qué querrías hacer eso?"

# game/chapters/6_day.rpyc:2435
translate es chat2_day6_0f3b1a80:

    # player "Because I think it would look pretty."
    player "Porque creo que se vería bonito."

# game/chapters/6_day.rpyc:2437
translate es chat2_day6_bbbf5b0d:

    # player "I just want to."
    player "Solo quiero hacerlo."

# game/chapters/6_day.rpyc:2439
translate es chat2_day6_2a267629:

    # GR "that kind of thing would suit you much more than me."
    GR "ese tipo de cosas te quedarían mucho mejor que a mí."

# game/chapters/6_day.rpyc:2442
translate es chat2_day6_a2b02f92:

    # player "Put some in my hair, then?"
    player "¿Poner algunas en mi cabello, entonces?"

# game/chapters/6_day.rpyc:2443
translate es chat2_day6_cec50510:

    # GR "that sounds much more appealing."
    GR "eso suena mucho más atractivo."

# game/chapters/6_day.rpyc:2444
translate es chat2_day6_5627ed03:

    # GR "i know the perfect place to get some flowers."
    GR "conozco el lugar perfecto para conseguir flores."

# game/chapters/6_day.rpyc:2445
translate es chat2_day6_83a9dfc6:

    # GR "i might visit again soon then."
    GR "quizá lo visite de nuevo pronto."

# game/chapters/6_day.rpyc:2448
translate es chat2_day6_944fb37f:

    # player "You're going to give that old lady a heart attack!"
    player "¡Vas a darle un infarto a esa viejita!"

# game/chapters/6_day.rpyc:2450
translate es chat2_day6_30f46302:

    # player "I am {i}so{/i} down for this."
    player "Estoy {i}totalmente{/i} de acuerdo con esto."

# game/chapters/6_day.rpyc:2453
translate es chat2_day6_4d0e71a2:

    # player "I could make you a flower crown."
    player "Podría hacerte una corona de flores."

# game/chapters/6_day.rpyc:2456
translate es chat2_day6_37c8df52:

    # player "I'll make one for myself as well."
    player "Haré una para mí también."

# game/chapters/6_day.rpyc:2459
translate es chat2_day6_8856f942:

    # player "And then we can match!"
    player "¡Y luego podemos hacerlo a juego!"

# game/chapters/6_day.rpyc:2460
translate es chat2_day6_b75a36e3:

    # GR "again, it would suit you."
    GR "de nuevo, te quedaría bien."

# game/chapters/6_day.rpyc:2461
translate es chat2_day6_ac96636f:

    # GR "it is hardly my style."
    GR "no es realmente mi estilo."

# game/chapters/6_day.rpyc:2464
translate es chat2_day6_4b021b7b:

    # player "What if I said pretty please?"
    player "¿Qué tal si digo por favorcito?"

# game/chapters/6_day.rpyc:2465
translate es chat2_day6_b2025bd2:

    # GR "i... would not be swayed so easily. obviously."
    GR "yo... no me dejaría convencer tan fácilmente. obviamente."

# game/chapters/6_day.rpyc:2468
translate es chat2_day6_f326c2c4:

    # player "Super mega doooooper pretty please?"
    player "¿Super mega hiper por favorcito?"

# game/chapters/6_day.rpyc:2469
translate es chat2_day6_38d25c5b:

    # GR "well, a super mega dooper pretty please is much more serious."
    GR "bueno, un super mega hiper por favorcito es mucho más serio."

# game/chapters/6_day.rpyc:2470
translate es chat2_day6_62d1cb20:

    # GR "i might consider it."
    GR "podría considerarlo."

# game/chapters/6_day.rpyc:2473
translate es chat2_day6_ae8c9bcd:

    # player "Only might?"
    player "¿Solo podría?"

# game/chapters/6_day.rpyc:2474
translate es chat2_day6_1169326b:

    # GR "correct. have some patience, mortal."
    GR "correcto. ten paciencia, mortal."

# game/chapters/6_day.rpyc:2480
translate es chat2_day6_998f96ed:

    # player "Wait a second..."
    player "Espera un segundo..."

# game/chapters/6_day.rpyc:2484
translate es chat2_day6_bb4a68c8:

    # player "You were {i}born{/i} with hair that long?"
    player "¿Naciste {i}con{/i} el cabello tan largo?"

# game/chapters/6_day.rpyc:2486
translate es chat2_day6_79a029da:

    # GR "what???"
    GR "¿¿¿qué???"

# game/chapters/6_day.rpyc:2490
translate es chat2_day6_cff62de8:

    # player "I can't imagine a baby with hair like yours."
    player "No puedo imaginar a un bebé con un cabello como el tuyo."

# game/chapters/6_day.rpyc:2492
translate es chat2_day6_feed72ff:

    # GR "you misunderstand."
    GR "malinterpretas."

# game/chapters/6_day.rpyc:2493
translate es chat2_day6_d34b79d7:

    # GR "i suppose i haven't ever really explained..."
    GR "supongo que nunca lo he explicado realmente..."

# game/chapters/6_day.rpyc:2494
translate es chat2_day6_c2ab6a2b:

    # GR "i was not 'born'. i was never a baby or a child."
    GR "No 'naci'. Nunca fui un bebé ni un niño."

# game/chapters/6_day.rpyc:2495
translate es chat2_day6_25050e3a:

    # GR "i was created solely for my purpose as a grim reaper. i have always looked the way i do now."
    GR "fui creado únicamente para mi propósito como parca. siempre he lucido como ahora."

# game/chapters/6_day.rpyc:2499
translate es chat2_day6_eaba0a47:

    # player "Oh."
    player "Oh."

# game/chapters/6_day.rpyc:2503
translate es chat2_day6_c7fbed37:

    # player "That's a little sad."
    player "Eso es un poco triste."

# game/chapters/6_day.rpyc:2505
translate es chat2_day6_f33e7adf:

    # GR "is it?"
    GR "¿lo es?"

# game/chapters/6_day.rpyc:2509
translate es chat2_day6_a9ed9eba:

    # player "You missed out on a lot of fun childhood things."
    player "Te perdiste muchas cosas divertidas de la infancia."

# game/chapters/6_day.rpyc:2511
translate es chat2_day6_547612b7:

    # GR "like? give me an example."
    GR "¿como? dame un ejemplo."

# game/chapters/6_day.rpyc:2515
translate es chat2_day6_e8a84815:

    # player "Waking up super early on a Saturday to watch cartoons!"
    player "¡Despertarse súper temprano un sábado para ver caricaturas!"

# game/chapters/6_day.rpyc:2517
translate es chat2_day6_dcac5684:

    # player "School book fairs!"
    player "¡Ferias de libros escolares!"

# game/chapters/6_day.rpyc:2519
translate es chat2_day6_523379cc:

    # player "Going suuuuper high on the swings for the first time!"
    player "¡Subir suuuper alto en los columpios por primera vez!"

# game/chapters/6_day.rpyc:2521
translate es chat2_day6_fbd066b5:

    # player "Cool Math Games, of course."
    player "Juegos de Matemáticas Geniales, por supuesto."

# game/chapters/6_day.rpyc:2523
translate es chat2_day6_42f32c3b:

    # GR "that doesn't sound particularly fun."
    GR "eso no suena particularmente divertido."

# game/chapters/6_day.rpyc:2527
translate es chat2_day6_bb5f8432:

    # player "I would have had fun growing up with you."
    player "Me habría divertido creciendo contigo."

# game/chapters/6_day.rpyc:2529
translate es chat2_day6_230dec51:

    # GR "...."
    GR "...."

# game/chapters/6_day.rpyc:2530
translate es chat2_day6_1cda0b10:

    # GR "there's... plenty of time, you know."
    GR "Hay... mucho tiempo, sabes."

# game/chapters/6_day.rpyc:2534
translate es chat2_day6_1eada887:

    # player "You want me to introduce you to what you missed out on?!"
    player "¡¿Quieres que te enseñe lo que te perdiste?!"

# game/chapters/6_day.rpyc:2536
translate es chat2_day6_e04ed935:

    # GR "maybe. perhaps it would be... somewhat fun."
    GR "quizá. tal vez sería... algo divertido."

# game/chapters/6_day.rpyc:2539
translate es chat2_day6_670fe91d:

    # player "But... what about before you were a reaper?"
    player "Pero... ¿qué pasa antes de ser una parca?"

# game/chapters/6_day.rpyc:2541
translate es chat2_day6_df2e84dc:

    # GR "there was not a before."
    GR "no hubo un antes."

# game/chapters/6_day.rpyc:2542
translate es chat2_day6_97e956fa:

    # GR "well... to be honest, i do not know what was before. it is classified, even from me."
    GR "bueno... para ser honesto, no sé qué hubo antes. es clasificado, incluso para mí."

# game/chapters/6_day.rpyc:2543
translate es chat2_day6_9b4646f8:

    # GR "all i know is that we were created somehow, then given our job."
    GR "todo lo que sé es que fuimos creados de alguna manera, y luego se nos dio nuestro trabajo."

# game/chapters/6_day.rpyc:2544
translate es chat2_day6_f909bc89:

    # GR "that is why i seem to 'live for my job'. i literally do."
    GR "por eso parece que 'vivo para mi trabajo'. literalmente lo hago."

# game/chapters/6_day.rpyc:2548
translate es chat2_day6_f72a69ee:

    # player "Could you have been human once?"
    player "¿Podrías haber sido humano alguna vez?"

# game/chapters/6_day.rpyc:2551
translate es chat2_day6_6cf55df0:

    # player "Maybe they wiped your memories!"
    player "¡Quizá borraron tus recuerdos!"

# game/chapters/6_day.rpyc:2553
translate es chat2_day6_840b57aa:

    # GR "i... could not guess."
    GR "yo... no podría adivinar."

# game/chapters/6_day.rpyc:2554
translate es chat2_day6_225107af:

    # GR "i suppose it's possible."
    GR "supongo que es posible."

# game/chapters/6_day.rpyc:2555
translate es chat2_day6_01bcb3da:

    # GR "i have a soul, so it came from somewhere. i am not totally artificially created. i think..."
    GR "tengo un alma, así que vino de algún lugar. no fui totalmente creado de manera artificial. creo..."

# game/chapters/6_day.rpyc:2559
translate es chat2_day6_9c9a3440:

    # player "So what happens if you want to quit?"
    player "Entonces, ¿qué pasa si quieres renunciar?"

# game/chapters/6_day.rpyc:2561
translate es chat2_day6_c30211c0_1:

    # GR "i..."
    GR "yo..."

# game/chapters/6_day.rpyc:2562
translate es chat2_day6_28399c9f:

    # GR "would probably be forcefully terminated."
    GR "probablemente sería despedido de manera forzosa."

# game/chapters/6_day.rpyc:2566
translate es chat2_day6_07f228da:

    # player "That doesn't sound healthy..."
    player "Eso no suena saludable..."

# game/chapters/6_day.rpyc:2568
translate es chat2_day6_60938b6f:

    # GR "no. i would say death is not healthy."
    GR "no. diría que la muerte no es saludable."

# game/chapters/6_day.rpyc:2573
translate es chat2_day6_c7a80d4e:

    # GR "anyway..."
    GR "de todos modos..."

# game/chapters/6_day.rpyc:2574
translate es chat2_day6_8ece4c83:

    # GR "speaking of hair and all that..."
    GR "hablando de cabello y todo eso..."

# game/chapters/6_day.rpyc:2575
translate es chat2_day6_a9de41cb:

    # GR "i am going to wash mine now."
    GR "voy a lavarme ahora."

# game/chapters/6_day.rpyc:2580
translate es chat2_day6_8217aca7:

    # player "Still need that cold shower, huh?"
    player "Todavía necesitas esa ducha fría, ¿eh?"

# game/chapters/6_day.rpyc:2582
translate es chat2_day6_76ab90c4:

    # GR "i will talk to you later sunshine."
    GR "hablaremos luego, solecito."

# game/chapters/6_day.rpyc:2583
translate es chat2_day6_0dcd10f9:

    # GR "thank you for answering my confession with 'how about a haircut', by the way."
    GR "gracias por responder a mi confesión con '¿qué tal un corte de cabello?', por cierto."

# game/chapters/6_day.rpyc:2587
translate es chat2_day6_3207b8d2:

    # player "Oh, yeah. Sorry."
    player "Oh, sí. Lo siento."

# game/chapters/6_day.rpyc:2589
translate es chat2_day6_15df8d8c:

    # player "Whoops..."
    player "Uups..."

# game/chapters/6_day.rpyc:2591
translate es chat2_day6_3eb49187:

    # GR "tomorrow, [playerfirstname!l]."
    GR "hasta mañana, [playerfirstname!l]."

# game/chapters/6_day.rpyc:2592
translate es chat2_day6_4d11ab1d:

    # GR "the last day of our bet. good night."
    GR "el último día de nuestra apuesta. buenas noches."

# game/chapters/6_day.rpyc:2595
translate es chat2_day6_f9a140eb:

    # player "Until tomorrow, Casper."
    player "Hasta mañana, Casper."


translate es strings:

    old "1. <I keep looking at the flowers.>"
    new "1. <Sigo mirando las flores.>"

    old "1. <Ah, I guess I should call you Casper.>"
    new "1. <Ah, supongo que debería llamarte Casper.>"

    old "1. <I just wanna thank you again.>"
    new "1. <Solo quería agradecerte otra vez.>"

    old "1. <The struggle?>"
    new "1. <¿El esfuerzo?>"

    old "1. <You don't have any florists near you?>"
    new "1. <¿No tienes floristerías cerca?>"

    old "1. <Then where {i}are{/i} they from?>"
    new "1. <Entonces, ¿de dónde {i}son{/i}?>"

    old "1. <You stole these from an old lady?!>"
    new "1. <¿¡Le robaste a una anciana?!>"

    old "1. <You're a little old lady thief.>"
    new "1. <Eres un ladrón de viejitas.>"

    old "1. <Who says you aren't?>"
    new "1. <¿Y quién dice que no?>"

    old "1. <Um... I'm not actually sure. Maybe?>"
    new "1. <Eh... No lo sé muy bien. ¿Tal vez?>"

    old "1. <Yeah, you really give gardener vibes.>"
    new "1. <Sí, das vibras de jardinero.>"

    old "1. <How did you get them, then?>"
    new "1. <Entonces, ¿cómo las conseguiste?>"

    old "1. <You stole from an old woman?!>"
    new "1. <¿¡Le robaste a una anciana?!>"

    old "1. <She chased you down?>"
    new "1. <¿Te persiguió?>"

    old "1. <I mean...>"
    new "1. <Quiero decir...>"

    old "1. <Haven't you seen my plant during our calls?>"
    new "1. <¿No has visto mi planta durante nuestras llamadas?>"

    old "1. <It's right near my bed.>"
    new "1. <Está justo al lado de mi cama.>"

    old "1. <Wow, Casper!>"
    new "1. <¡Wow, Casper!>"

    old "1. <Is that how you get around not being able to lie?>"
    new "1. <¿Así es como te las arreglas para no mentir?>"

    old "1. <Lots of 'maybe' and 'possibly'?>"
    new "1. <¿Con muchos 'tal vez' y 'posiblemente'?>"

    old "1. <Which are?>"
    new "1. <¿Como cuáles?>"

    old "1. <So what have you learned about me so far?>"
    new "1. <¿Y qué has aprendido de mí hasta ahora?>"

    old "1. <You wouldn't {i}lie{/i} about seeing my bed for research purposes, would you?>"
    new "1. <¿No {i}mentirías{/i} sobre mirar mi cama por motivos de investigación, verdad?>"

    old "1. <This is sounding less and less reaper related...>"
    new "1. <Esto suena cada vez menos relacionado con ser una parca...>"

    old "1. <And more and more like you have a thing for me.>"
    new "1. <Y más y más como si sintieras algo por mí.>"

    old "1. <With the way you talk about me?>"
    new "1. <¿Con la forma en que hablas de mí?>"

    old "1. <I think it's {i}you{/i} that thinks awfully highly of {i}me{/i}.>"
    new "1. <Creo que eres {i}tú{/i} quien piensa demasiado bien de {i}mí{/i}.>"

    old "1. <Sure it is.>"
    new "1. <Claro que sí.>"

    old "1. <...It's not looking very alive.>"
    new "1. <...No se ve muy viva.>"

    old "1. <I'm not holding out hopes for the flower's survival.>"
    new "1. <No tengo muchas esperanzas en la supervivencia de las flores.>"

    old "1. <What, in the next day before you're meant to take my soul?>"
    new "1. <¿Qué, mañana, antes de que tengas que llevarte mi alma?>"

    old "1. <Why would you do that for me?>"
    new "1. <¿Por qué harías eso por mí?>"

    old "1. <No... I suppose not.>"
    new "1. <No... supongo que no.>"

    old "1. <I've got something of a green thumb, luckily.>"
    new "1. <Tengo buena mano con las plantas, por suerte.>"

    old "1. <I've got a plant by my bed and it's growing nicely.>"
    new "1. <Tengo una planta junto a la cama y está creciendo bien.>"

    old "1. <Maybe I've got the magic touch.>"
    new "1. <Quizás tengo el toque mágico.>"

    old "1. <I feel like you're insinuating something here.>"
    new "1. <Siento que estás insinuando algo aquí.>"

    old "1. <I'm talking about the plant.>"
    new "1. <Estoy hablando de la planta.>"

    old "1. <Wowee, mister flirt over here.>"
    new "1. <Vayaaa, señor coqueto por aquí.>"

    old "1. <Shhh, you.>"
    new "1. <Shhh, tú.>"

    old "1. <Are you trying to tell me something?>"
    new "1. <¿Estás tratando de decirme algo?>"

    old "1. <So, I'm just wondering something.>"
    new "1. <Bueno, solo me preguntaba algo.>"

    old "1. <Are you... feeling okay today?>"
    new "1. <¿Te sientes.. bien hoy?>"

    old "1. <You're just acting very...>"
    new "1. <Solo estás actuando muy...>"

    old "1. <Well, yes.>"
    new "1. <Bueno, sí.>"

    old "1. <A custom...?>"
    new "1. <¿Una costumbre...?>"

    old "1. <So... I'm of significance to you?>"
    new "1. <Entonces... ¿soy importante para ti?>"

    old "1. <You've researched flirting methods?>"
    new "1. <¿Has investigado métodos de coqueteo?>"

    old "1. <You're cute. Cute and stupid.>"
    new "1. <Eres adorable. Lindo y tonto.>"

    old "1. <And what {i}would{/i} be the best result for you?>"
    new "1. <¿Y cuál {i}sería{/i} el mejor resultado para ti?>"

    old "1. <Uh huh. Sure. All business.>"
    new "1. <Uh huh. Claro. Pura profesionalidad.>"

    old "1. <Too bad you can't lie, huh.>"
    new "1. <Lástima que no puedas mentir, ¿eh?>"

    old "1. <And you are surprisingly very soft and cautious.>"
    new "1. <Y tú eres sorprendentemente muy delicado y cauteloso.>"

    old "1. <The more I get to know you, the less 'Grim Reaper' you seem.>"
    new "1. <Cuanto más te conozco, menos pareces una 'Parca'.>"

    old "1. <I think you're plenty.>"
    new "1. <Creo que eres más que suficiente.>"

    old "1. <I like talking with you and seeing new sides of you.>"
    new "1. <Me gusta hablar contigo y ver tus diferentes facetas.>"

    old "1. <Isn't it refreshing to just be you? You can just be Casper.>"
    new "1. <¿No es refrescante simplemente ser tú? Puedes ser solo Casper.>"

    old "1. <Me? Never.>"
    new "1. <¿Yo? Jamás.>"

    old "1. <That's you tooting your own horn.>"
    new "1. <Ese eres tú tocando tu propia trompeta.>"

    old "1. <Hey, I didn't say you were wrong.>"
    new "1. <Oye, no dije que estuvieras equivocado.>"

    old "1. <Such a big head, but such a little brain.>"
    new "1. <Una cabeza tan grande, pero un cerebro tan pequeño.>"

    old "1. <No one is {i}touching me{/i}.>"
    new "1. <Nadie me está {i}tocando{/i}.>"

    old "1. <Yet?>"
    new "1. <¿Aún?>"

    old "1. <Someone's confident!>"
    new "1. <¡Alguien está seguro de sí mismo!>"

    old "1. <O-oh.>"
    new "1. <O-oh.>"

    old "1. <Your notes are very in depth.>"
    new "1. <Tus notas son muy detalladas.>"

    old "1. <Where did you get them?>"
    new "1. <¿De dónde las sacaste?>"

    old "1. <Like a dummies guide to dating?>"
    new "1. <¿Como una guía para tontos sobre citas?>"

    old "1. <An IRL dating sim!>"
    new "1. <¡Un simulador de citas en la vida real!>"

    old "1. <A dating walkthrough?>"
    new "1. <¿Una guía de citas?>"

    old "1. <And what do you hope to get out of it?>"
    new "1. <¿Y qué esperas obtener con eso?>"

    old "1. <And I bet you STILL like me.>"
    new "1. <Y apuesto a que AÚN te gusto.>"

    old "1. <You know, that's really an answer itself.>"
    new "1. <Sabes, eso ya es una respuesta en sí misma.>"

    old "1. <But fine, keep your secrets.>"
    new "1. <Pero está bien, guarda tus secretos.>"

    old "1. <Thank you for noticing.>"
    new "1. <Gracias por notarlo.>"

    old "1. <Really? Wow, I never would have guessed.>"
    new "1. <¿En serio? Wow, nunca lo habría adivinado.>"

    old "1. <But lets not look past the fact you are actually researching this.>"
    new "1. <Pero no pasemos por alto el hecho de que en realidad estás investigando esto.>"

    old "1. <But it really is.>"
    new "1. <Pero sí lo es.>"

    old "1. <I've never known people to research how to flirt with someone.>"
    new "1. <Nunca había conocido a alguien que investigara cómo coquetear con otra persona.>"

    old "1. <No, you certainly are not.>"
    new "1. <No, ciertamente no lo eres.>"

    old "1. <But that is not the point I am making right now.>"
    new "1. <Pero ese no es el punto que estoy tratando de dar.>"

    old "1. <And the best results of your flirting would be...?>"
    new "1. <¿Y los mejores resultados de tu coqueteo serían...? >"

    old "1. <A date? Dating?>"
    new "1. <¿Una cita? ¿Salir conmigo?>"

    old "1. <Is that the result you want?>"
    new "1. <¿Ese es el resultado que quieres?>"

    old "1. <You like it that much, huh?>"
    new "1. <¿Te gusta tanto, huh?>"

    old "1. <I don't mind continuing it.>"
    new "1. <No me importa seguir con ello.>"

    old "1. <My little kitten.>"
    new "1. <Mi pequeño gatito.>"

    old "1. <Is that a good thing, though?>"
    new "1. <¿Eso es algo bueno, entonces?>"

    old "1. <Well, even if you were only flirting with me to get my soul...>"
    new "1. <Bueno, incluso si solo coqueteabas conmigo para conseguir mi alma...>"

    old "1. <Can't say I mind all that much.>"
    new "1. <No puedo decir que me moleste tanto.>"

    old "1. <Flirt away o7>"
    new "1. <Sigue coqueteando o7>"

    old "1. <It's a salute, doofus.>"
    new "1. <Es un saludo, tonto.>"

    old "1. <Truly groundbreaking stuff.>"
    new "1. <Verdaderamente revolucionario.>"

    old "1. <Won't you get in trouble?>"
    new "1. <¿No te meterás en problemas?>"

    old "1. <No no, for telling me classified information.>"
    new "1. <No no, por contarme información clasificada.>"

    old "1. <You said your name was highly classifed.>"
    new "1. <Dijiste que tu nombre era altamente clasificado.>"

    old "1. <Not for mortal ears, right?>"
    new "1. <¿Que no debía ser oído por oídos mortales, cierto?>"

    old "1. <Who taught you that word...>"
    new "1. <¿Quién te enseñó esa palabra...? >"

    old "1. <Please don't say those words ever again.>"
    new "1. <Por favor no vuelvas a decir esas palabras jamás.>"

    old "1. <But seriously, your name was actually classified?>"
    new "1. <Pero en serio, ¿tu nombre era realmente clasificado?>"

    old "1. <I doubt anyone will, anyway.>"
    new "1. <Dudo que alguien lo haga, de todos modos.>"

    old "1. <You're gonna have my soul by tomorrow, right?>"
    new "1. <Tendrás mi alma para mañana, ¿verdad?>"

    old "1. <Haha, you're so funny.>"
    new "1. <Jaja, eres muy gracioso.>"

    old "1. <Handsome and charming? I don't think so.>"
    new "1. <¿Apuesto y encantador? No lo creo.>"

    old "1. <How terrible it would be if a grim reaper were to suddenly show great interest in me!>"
    new "1. <¡Qué terrible sería si una parca mostrara de repente gran interés en mí!>"

    old "1. <Let's hope he doesn't bring me flowers and tell me how annoying I am.>"
    new "1. <Esperemos que no me traiga flores y me diga la molestia que soy.>"

    old "1. <You must've been rubbing off on me.>"
    new "1. <Debes de estar contagiándome.>"

    old "1. <A charming and good looking dork.>"
    new "1. <Un tonto encantador y apuesto.>"

    old "1. <The charming part could go either way though.>"
    new "1. <Aunque la parte de encantador podría ir en cualquier dirección.>"

    old "1. <And then he'd decide he can't be without me anyway.>"
    new "1. <Y luego decidiría que no puede estar sin mí de todos modos.>"

    old "1. <I think he likes to be kept on his toes, he'd have to keep me.>"
    new "1. <Creo que le gusta mantenerse alerta, tendría que quedarse conmigo.>"

    old "1. <Alright, what was it then?>"
    new "1. <De acuerdo, ¿cuál era?>"

    old "1. <Again? It's really a common thing for you reapers, huh?>"
    new "1. <¿Otra vez? Es algo bastante común entre las parcas, ¿huh?>"

    old "1. <Did you find out why?>"
    new "1. <¿Descubriste por qué?>"

    old "1. <Wait, is it serious?>"
    new "1. <Espera, ¿es grave?>"

    old "1. <Are you going to die?>"
    new "1. <¿Vas a morir?>"

    old "1. <Please don't tell me you're dying.>"
    new "1. <Por favor no me digas que te estás muriendo.>"

    old "1. <If that's what you're going to say, I'm not gonna answer.>"
    new "1. <Si eso es lo que vas a decir, no voy a contestar.>"

    old "1. <Is it curable?>"
    new "1. <¿Es curable?>"

    old "1. <Is it really bad?>"
    new "1. <¿Es muy mala?>"

    old "1. <If you plan to tell me you're dying... I'm not gonna answer, okay?>"
    new "1. <Si planeas decirme que te estás muriendo... no voy a contestar, ¿de acuerdo?>"

    old "1. <You don't think?!>"
    new "1. <¡¿No crees?!>"

    old "1. <Of course. I remember.>"
    new "1. <Por supuesto. Lo recuerdo.>"

    old "1. <You were fine.>"
    new "1. <Estabas bien.>"

    old "1. <Are you sure you should be telling me this?>"
    new "1. <¿Estás seguro de que deberías decirme esto?>"

    old "1. <You seem... very stressed about this.>"
    new "1. <Pareces... muy estresado por esto.>"

    old "1. <It's kinda scaring me...>"
    new "1. <Está empezando a asustarme...>"

    old "1. <Me? What exactly is because of me?>"
    new "1. <¿Yo? ¿Exactamente qué es por mí?>"

    old "1. <You caught me. I'm definitely causing it.>"
    new "1. <Me atrapaste. Definitivamente lo estoy causando.>"

    old "1. <What tasted like what?>"
    new "1. <¿Qué sabía a qué?>"

    old "1. <Alright. Well, be real here.>"
    new "1. <Está bien. Bueno, seamos sinceros.>"

    old "1. <You can't think I'm really {i}trying{/i} to make you sick, right?>"
    new "1. <No pensarás que de verdad {i}estoy intentando{/i} enfermarte, ¿verdad?>"

    old "1. <Are you trying to say I'm doing this on purpose?>"
    new "1. <¿Estás tratando de decir que hago esto a propósito?>"

    old "1. <I'm not really trying to make you sick.>"
    new "1. <No estoy tratando de enfermarte.>"

    old "1. <I'm not doing anything to make you sick, though.>"
    new "1. <Pero no estoy haciendo nada para enfermarte.>"

    old "1. <You're not making any sense right now.>"
    new "1. <No estás teniendo sentido ahora mismo.>"

    old "1. <So seeing me yesterday made you sick?>"
    new "1. <¿Así que verme ayer te enfermó?>"

    old "1. <Weird theory.>"
    new "1. <Teoría extraña.>"

    old "1. <Uh... yeah, totally.>"
    new "1. <Uh... sí, totalmente.>"

    old "1. <Casper... I literally have no clue what you're \ntalking about.>"
    new "1. <Casper... literalmente no tengo idea de qué estás \nhablando.>"

    old "1. <What are you talking about?>"
    new "1. <¿De qué estás hablando?>"

    old "1. <What? How?>"
    new "1. <¿Qué? ¿Cómo?>"

    old "1. <Of course.>"
    new "1. <Por supuesto.>"

    old "1. <Yeah, perfectly normal. What are you \ngetting at exactly?>"
    new "1. <Sí, perfectamente normal. ¿A qué quieres \nllegar exactamente?>"

    old "1. <I don't have a full soul?>"
    new "1. <¿No tengo un alma completa?>"

    old "1. <Is this going to, uh, affect the ferrying of my \nsoul to the afterlife thing?>"
    new "1. <¿Esto va a, eh, afectar el transporte de mi \nalma al más allá o algo así?>"

    old "1. <Would I be forgotten?>"
    new "1. <¿Me olvidarían?>"

    old "1. <How do I stop? What if I give it all away?!>"
    new "1. <¿Cómo lo detengo? ¡¿Y si la entrego toda?!>"

    old "1. <Oh, but if you don't take my soul by midnight \ntomorrow... I'll have yours too.>"
    new "1. <Oh, pero si no tomas mi alma antes de la medianoche \nde mañana... también tendré la tuya.>"

    old "1. <Then I can give away parts of your soul instead.>"
    new "1. <Entonces puedo regalar partes de tu alma en su lugar.>"

    old "1. <I'll just try not to wish too many things magically \nback to health...>"
    new "1. <Solo intentaré no desear mágicamente que demasiadas cosas \nse curen...>"

    old "1. <But if [pet_name] gets sick I will not hesitate.>"
    new "1. <Pero si [pet_name] se enferma, no dudaré.>"

    old "1. <But I kind of feel like I don't want you \nto be unwell, either.>"
    new "1. <Pero siento que tampoco quiero que tú \nestés mal.>"

    old "1. <If you start feeling {i}really{/i} bad I can try \nand help, maybe?>"
    new "1. <Si empiezas a sentirte {i}realmente{/i} mal, puedo intentar \nayudarte, ¿quizás?>"

    old "1. <I don't need to try and take it.>"
    new "1. <No necesito intentar robarla.>"

    old "1. <When I win the bet you have to {i}give{/i} it to me.>"
    new "1. <Cuando gane la apuesta tienes que {i}dármela{/i}.>"

    old "1. <I'll just wait for the reward to come my way.>"
    new "1. <Solo esperaré a que la recompensa venga hacia mí.>"

    old "1. <So make sure you tidy up any loose ends you have, \nsince you'll belong to me soon.>"
    new "1. <Así que asegúrate de resolver cualquier asunto pendiente, \nya que pronto me pertenecerás.>"

    old "1. <You want to take my soul soon anyway, right?>"
    new "1. <De todos modos, quieres tomar mi alma pronto, ¿verdad?>"

    old "1. <I might as well be of help beforehand.>"
    new "1. <Podría ser de ayuda antes de eso.>"

    old "1. <Can you teach me to control it?>"
    new "1. <¿Puedes enseñarme a controlarlo?>"

    old "1. <Oh.>"
    new "1. <Oh.>"

    old "1. <Well, I'll try to control it.>"
    new "1. <Bueno, intentaré controlarlo.>"

    old "1. <I'll think really hard about not overdoing it.>"
    new "1. <Pensaré muy bien en no exagerar.>"

    old "1. <Just let me try and help.>"
    new "1. <Solo déjame intentar ayudar.>"

    old "1. <Honestly, sometimes I forget.>"
    new "1. <Honestamente, a veces lo olvido.>"

    old "1. <Cease to be, yes.>"
    new "1. <Dejar de existir, sí.>"

    old "1. <I suppose I'll have to just do it carefully.>"
    new "1. <Supongo que tendré que hacerlo con cuidado.>"

    old "1. <Don't get me wrong, if [pet_name] gets sick I'll wish really hard.>"
    new "1. <No me malinterpretes, si [pet_name] se enferma desearé con todas mis fuerzas.>"

    old "1. <Okay, good.>"
    new "1. <De acuerdo, bien.>"

    old "1. <Then, next time you feel unbalanced...>"
    new "1. <Entonces, la próxima vez que te sientas desequilibrado...>"

    old "1. <You know. You're trying to take my soul \nand everything...>"
    new "1. <Ya sabes. Estás tratando de tomar mi alma \ny todo eso...>"

    old "1. <And if that doesn't happen, I'll accidentally give \naway my soul all by myself...>"
    new "1. <Y si eso no pasa, accidentalmente entregaré \nmi alma por mi cuenta...>"

    old "1. <If I'm not gonna be around long, I'd rather cross a few \nthings off my bucket list first.>"
    new "1. <Si no voy a estar por mucho tiempo, prefiero tachar algunas cosas \nde mi lista de deseos primero.>"

    old "1. <Yeah. I've always wanted to get married.>"
    new "1. <Sí. Siempre he querido casarme.>"

    old "1. <It's not nonsense. I'm totally serious.>"
    new "1. <No es una tontería. Lo digo completamente en serio.>"

    old "1. <One that doesn't get affected by the taint.>"
    new "1. <Una que no se ve afectada por la corrupción.>"

    old "1. <Reaper 2.0.>"
    new "1. <Parca 2.0.>"

    old "1. <Yeah, you can start bowing now.>"
    new "1. <Sí, puedes empezar a inclinarte ahora.>"

    old "1. <Maybe dark humor is how I cope with stuff.>"
    new "1. <Tal vez el humor negro sea mi forma de sobrellevar las cosas.>"

    old "1. <Very reaper-like of me, huh?>"
    new "1. <Muy propio de una parca ¿eh?>"

    old "1. <I dunno. You seem like a 'make jokes when bad \nthings happen' kind of guy.>"
    new "1. <No sé. Pareces del tipo que hace chistes cuando \npasan cosas malas.>"

    old "1. <But being serious for a moment...>"
    new "1. <Pero hablando en serio por un momento...>"

    old "1. <I can be serious when I want to, yes.>"
    new "1. <Puedo tomarme las cosas en serio cuando quiero, sí.>"

    old "1. <Uhh... how can I {i}not{/i} give away my entire soul?>"
    new "1. <Uhh... ¿cómo puedo {i}no{/i} entregar toda mi alma?>"

    old "1. <Hey, I've always been a trendsetter. Go me.>"
    new "1. <Oye, siempre he marcado tendencia. ¡Bien por mí!>"

    old "1. <So you won't even give me a tip?>"
    new "1. <¿Así que ni siquiera me darás un consejo?>"

    old "1. <Of course. [pet_name] is my number one priority.>"
    new "1. <Por supuesto. [pet_name] es mi prioridad número uno.>"

    old "1. <But I suppose you are pretty high up there.>"
    new "1. <Pero supongo que tú también estás bastante alto en la lista.>"

    old "1. <Somehow you're climbing fast up my \npriority ladder, Casper.>"
    new "1. <De alguna manera estás subiendo rápido en mi \nescalera de prioridades, Casper.>"

    old "1. <I was thinking your dumb personality.>"
    new "1. <Pensaba en tu tonta personalidad.>"

    old "1. <I love people I can tease.>"
    new "1. <Me encantan las personas a las que puedo molestar.>"

    old "1. <Casper!>"
    new "1. <¡Casper!>"

    old "1. <Have you ever heard of Casper the friendly ghost?>"
    new "1. <¿Alguna vez has oído hablar de Casper, el fantasma amigable?>"

    old "1. <You're excused. So, yes or no?>"
    new "1. <Estás disculpado. Entonces, ¿sí o no?>"

    old "1. <You kinda have the vibe going for you.>"
    new "1. <Tienes un poco esa vibra.>"

    old "1. <You have your friendly moments. \nSometimes. Occasionally.>"
    new "1. <Tienes tus momentos amables. \nA veces. De vez en cuando.>"

    old "1. <And I'm not certain you aren't a ghost. \nYou're awfully pale.>"
    new "1. <Y no estoy seguro de que no seas un fantasma. \nEres terriblemente pálido.>"

    old "1. <Definitely.>"
    new "1. <Definitivamente.>"

    old "1. <It's actually very freeing.>"
    new "1. <En realidad es muy liberador.>"

    old "1. <I've got a whole fantasy world up in my head. It's fun.>"
    new "1. <Tengo todo un mundo de fantasía en mi cabeza. Es divertido.>"

    old "1. <It's comforting to have somewhere I can retreat to.>"
    new "1. <Es reconfortante tener un lugar al que pueda retirarme.>"

    old "1. <I can imagine and create a world in \nwhatever way I please.>"
    new "1. <Puedo imaginar y crear un mundo \nde la manera que quiera.>"

    old "1. <Maybe it's a trait that comes with being a writer?>"
    new "1. <¿Tal vez es una característica que viene con escribir?>"

    old "1. <It's like a little escape from reality.>"
    new "1. <Es como un pequeño escape de la realidad.>"

    old "1. <Leave? No.>"
    new "1. <¿Irme? No.>"

    old "1. <I don't wish to {i}not{/i} be a part of this reality.>"
    new "1. <No deseo {i}no{/i} ser parte de esta realidad.>"

    old "1. <I just like imagining things and story building.>"
    new "1. <Solo me gusta imaginar cosas y crear historias.>"

    old "1. <Maybe I should write a book?>"
    new "1. <¿Tal vez debería escribir un libro?>"

    old "1. <I think up other places, other lives \nand situations I could be in.>"
    new "1. <Pienso en otros lugares, otras vidas \ny situaciones en las que podría estar.>"

    old "1. <A range of different me's. What could \nhave beens. What ifs.>"
    new "1. <Una variedad de diferentes yo. Lo que podría \nhaber sido. Los 'qué pasaría si'.>"

    old "1. <Is it strange?>"
    new "1. <¿Es raro?>"

    old "1. <Maybe?>"
    new "1. <¿Tal vez?>"

    old "1. <You know what, I probably am.>"
    new "1. <¿Sabes qué? Probablemente sí.>"

    old "1. <Thanks Casper.>"
    new "1. <Gracias, Casper.>"

    old "1. <For a 'Grim Reaper' who is supposed to \nbring death... you aren't so bad.>"
    new "1. <Para ser una 'Parca' que se supone \nque trae la muerte... no eres tan malo.>"

    old "1. <No, obviously not... but if I was.>"
    new "1. <No, obviamente no... pero si lo fuera.>"

    old "1. <Would I have been born edgy like you?>"
    new "1. <¿Habría nacido con esa actitud edgy como tú?>"

    old "1. <Or maybe I was forced to be a reaper?>"
    new "1. <¿O tal vez me obligaron a ser una parca?>"

    old "1. <Maybe I made a deal with a devil and he told me \nI had to be a reaper in order to live.>"
    new "1. <Quizás hice un trato con un demonio y me dijo \nque tenía que ser una parca para poder vivir.>"

    old "1. <No deals with devils yeah yeah, I got it.>"
    new "1. <Sin tratos con demonios, sí sí, lo entiendo.>"

    old "1. <What can I say, I thoroughly enjoy bulling you.>"
    new "1. <Qué puedo decir, disfruto completamente molestarte.>"

    old "1. <I like seeing you flustered. It makes me happy.>"
    new "1. <Me gusta verte nervioso. Me hace feliz.>"

    old "1. <Mmmhmm, just like that. Yep.>"
    new "1. <Mmmhmm, así mismo. Sí.>"

    old "1. <Thanks!>"
    new "1. <¡Gracias!>"

    old "1. <Don't you wanna know what I imagine about you \nwith this wild imagination of mine?>"
    new "1. <¿No quieres saber lo que imagino sobre ti \ncon esta loca imaginación mía?>"

    old "1. <Awww, poor Casper...>"
    new "1. <Awww, pobre Casper...>"

    old "1. <He's my little blushing maiden.>"
    new "1. <Es mi pequeña doncella sonrojada.>"

    old "1. <Suuure. You never blush, of course.>"
    new "1. <Siií, claro. Tú nunca te sonrojas, por supuesto.>"

    old "1. <{i}Bat your eyelashes at him.{/i}>"
    new "1. <{i}Pestañear coquetamente.{/i}>"

    old "1. <Are you suuuure you don't wanna know?>"
    new "1. <¿Estás seguuro de que no quieres saberlo?>"

    old "1. <You're missing out then, little reaper.>"
    new "1. <Te lo estás perdiendo entonces, parquita.>"

    old "1. <Have it your way.>"
    new "1. <Como quieras.>"

    old "1. <But you would have liiiiked it.>"
    new "1. <Pero te habría guuustado.>"

    old "1. <...{i}Try and still your imagination.{/i}>"
    new "1. <...{i}Intentar calmar tu imaginación.{/i}>"

    old "1. <...{i}Try harder.{/i}>"
    new "1. <...{i}Esforzarte más.{/i}>"

    old "1. <!!! {i}Try with all your might!{/i}>"
    new "1. <!!! {i}¡Inténtarlo con todas tus fuerzas!{/i}>"

    old "1. <!!! {i}Keep trying!{/i}>"
    new "1. <!!! {i}¡Seguir intentándolo!{/i}>"

    old "1. <{i}Just a... little more...!{/i}>"
    new "1. <{i}¡Solo un... poco más...!{/i}>"

    old "1. <You know what. It doesn't work.>"
    new "1. <¿Sabes qué? No funciona.>"

    old "1. <I can't do it.>"
    new "1. <No puedo hacerlo.>"

    old "1. <My imagination is simply too strong.>"
    new "1. <Mi imaginación es simplemente demasiado fuerte.>"

    old "1. <It cannot be controlled.>"
    new "1. <No puede ser controlada.>"

    old "1. <Worth a shot, no?>"
    new "1. <Valía la pena intentarlo, ¿no?>"

    old "1. <Unwind.>"
    new "1. <Relájate.>"

    old "1. <Let loose.>"
    new "1. <Déjate llevar.>"

    old "1. <Oh yeah? What do you do to unwind \nall by yourself, hmm?>"
    new "1. <¿Ah, sí? ¿Y qué haces para relajarte \ntú solo, hmm?>"

    old "1. <I didn't even say anything!>"
    new "1. <¡Ni siquiera dije nada!>"

    old "1. <You're the one imagining dirty things, \nI think. Naughty boy.>"
    new "1. <Eres tú quien está imaginando cosas sucias, \ncreo. Chico travieso.>"

    old "1. <That I am.>"
    new "1. <Así soy.>"

    old "1. <You don't mind, though.>"
    new "1. <Aunque no te molesta.>"

    old "1. <I'd even go as far as saying you enjoy it.>"
    new "1. <Incluso me atrevería a decir que lo disfrutas.>"

    old "1. <And you can't even lie about it.>"
    new "1. <Y ni siquiera puedes negarlo.>"

    old "1. <Poor Casper.>"
    new "1. <Pobre Casper.>"

    old "1. <My naughty little Casper.>"
    new "1. <Mi pequeño travieso Casper.>"

    old "1. <You can't get enough of me.>"
    new "1. <No puedes tener suficiente de mí.>"

    old "1. <I've got you wrapped around my finger now.>"
    new "1. <Ahora te tengo completamente bajo mi control.>"

    old "1. <We've come a long way, huh?>"
    new "1. <Hemos recorrido un largo camino, ¿eh?>"

    old "1. <You seem less edgy than when we first met.>"
    new "1. <Pareces menos intenso que cuando nos conocimos.>"

    old "1. <There it is!>"
    new "1. <¡Ahí está!>"

    old "1. <Still, you say stuff like that a lot less.>"
    new "1. <Aun así, ya no dices cosas como esas tan seguido.>"

    old "1. <Maybe it's because we're friends now?>"
    new "1. <¿Tal vez es porque ahora somos amigos?>"

    old "1. <Yep, don't care at all.>"
    new "1. <Sí, no me importa en lo absoluto.>"

    old "1. <Who needs friends?>"
    new "1. <¿Quién necesita amigos?>"

    old "1. <I certainly don't.>"
    new "1. <Yo definitivamente no.>"

    old "1. <For what, my not-friend Casper?>"
    new "1. <¿Para qué, mi no-amigo Casper?>"

    old "1. <It's fine, I have plenty of other friends.>"
    new "1. <Está bien, tengo muchos otros amigos.>"

    old "1. <That kinda hurts, you know.>"
    new "1. <Eso duele un poco, ¿sabes?>"

    old "1. <You didn't have to say it right to my face...>"
    new "1. <No tenías que decírmelo justo en la cara...>"

    old "1. <Uh... thanks, I guess?>"
    new "1. <Eh... gracias, supongo?>"

    old "1. <Tell me...>"
    new "1. <Dime...>"

    old "1. <If it's true, then I want to hear you say it.>"
    new "1. <Si es verdad, entonces quiero oírtelo decir.>"

    old "1. <Casper?>"
    new "1. <¿Casper?>"

    old "1. <Then say it.>"
    new "1. <Entonces, dilo.>"

    old "1. <To not want to be friends?>"
    new "1. <¿Que no quieres ser amigos?>"

    old "1. <What do you mean by too much?>"
    new "1. <¿Qué quieres decir con 'demasiado'? >"

    old "1. <Is there something you want to say to me, Casper?>"
    new "1. <¿Hay algo que quieras decirme, Casper?>"

    old "1. <Then go ahead.>"
    new "1. <Entonces, adelante.>"

    old "1. <Tell me how you feel about me.>"
    new "1. <Dime lo que sientes por mí.>"

    old "1. <Look me in the eyes and tell me the truth.>"
    new "1. <Mírame a los ojos y dime la verdad.>"

    old "1. <You... don't think like that anymore?>"
    new "1. <¿Ya... no piensas así?>"

    old "1. <So... why don't you?>"
    new "1. <Entonces... ¿por qué no?>"

    old "1. <You're not replaceable to me.>"
    new "1. <Para mí, no eres reemplazable.>"

    old "1. <Okay. What is it you want to tell me, then?>"
    new "1. <Bien. ¿Entonces qué es lo que quieres decirme?>"

    old "1. <Shit.>"
    new "1. <Mierda.>"

    old "1. <Take what you want, then.>"
    new "1. <Entonces toma lo que quieras.>"

    old "1. <From the start, you've always told me you \ntake what belongs to you.>"
    new "1. <Desde el principio, siempre dijiste que tomas \nlo que te pertenece.>"

    old "1. <Wow! You really said all that then left?!>"
    new "1. <¡Vaya! ¿De verdad dijiste todo eso y luego te fuiste?!>"

    old "1. <Come back!>"
    new "1. <¡Vuelve!>"

    old "1. <You don't need to be so shy!>"
    new "1. <¡No necesitas ser tan tímido!>"

    old "1. <Sounds like something a shy person would say.>"
    new "1. <Suena como algo que diría una persona tímida.>"

    old "1. <So you desire me?>"
    new "1. <¿Así que me deseas?>"

    old "1. <Weeeell, you do need a cold shower now...>"
    new "1. <Bueeeno, ahora sí que necesitas una ducha fría...>"

    old "1. <Glad I have that effect on you, hehe ;D>"
    new "1. <Me alegra causar ese efecto en ti, jeje ;D>"

    old "1. <It took you this long to admit what was obvious.>"
    new "1. <Te tomó todo este tiempo admitir lo que era obvio.>"

    old "1. <And you did it with cheeks that looked like tomatoes.>"
    new "1. <Y lo hiciste con las mejillas rojas como tomates.>"

    old "1. <By the way, since it's somewhat topical...>"
    new "1. <Por cierto, ya que el tema viene al caso...>"

    old "1. <Do you ever cut your hair?>"
    new "1. <¿Alguna vez te cortas el cabello?>"

    old "1. <No, I absolutely do!>"
    new "1. <¡No, me encanta!>"

    old "1. <I was just curious. It's very long! It must have taken a long time to grow.>"
    new "1. <Solo tenía curiosidad. ¡Es muy largo! Debió tomar mucho tiempo dejarlo crecer.>"

    old "1. <It really suits you.>"
    new "1. <Te queda muy bien.>"

    old "1. <The long hair is kinda iconic.>"
    new "1. <El cabello largo es algo icónico.>"

    old "1. <You'll just keep growing it, then?>"
    new "1. <¿Entonces seguirás dejándolo crecer?>"

    old "1. <But you just said...>"
    new "1. <Pero acabas de decir...>"

    old "1. <If someone attacked you with scissors, it wouldn't grow back?>"
    new "1. <Si alguien te atacara con unas tijeras, ¿no volvería a crecer?>"

    old "1. <As fun as it would be to see you with shorter hair, no.>"
    new "1. <Por más divertido que sería verte con el cabello corto, no.>"

    old "1. <I wouldn't do that to you.>"
    new "1. <No te haría eso.>"

    old "1. <That's just mean.>"
    new "1. <Eso sería cruel.>"

    old "1. <And I... quite like how you are right now.>"
    new "1. <Y yo... realmente me gustas tal como eres ahora.>"

    old "1. <Pretty long hair and an attitude.>"
    new "1. <Cabello largo y una actitud.>"

    old "1. <What more could a [girl] ask for?>"
    new "1. <¿Qué más podría pedir un[girl!t]?>"

    old "1. <Alright, they sound good too.>"
    new "1. <Bueno, suena bien también.>"

    old "1. <But I could also settle without.>"
    new "1. <Pero también podría conformarme sin eso.>"

    old "1. <As long as I get my grumpy yet charming reaper that is.>"
    new "1. <Mientras tenga a mi parca gruñona pero encantadora.>"

    old "1. <You forgot the grumpy part.>"
    new "1. <Olvidaste la parte gruñona.>"

    old "1. <So no haircuts for you.>"
    new "1. <Así que nada de cortes de cabello para ti.>"

    old "1. <I don't want one either though, just putting that out there.>"
    new "1. <Aunque tampoco quiero uno, solo lo aclaro.>"

    old "1. <I was just making sure you knew not to cut it for me!>"
    new "1. <¡Solo quería asegurarme de que supieras que no debes cortarlo por mí!>"

    old "1. <I've been thinking about getting it cut anyway.>"
    new "1. <He estado pensando en cortarlo de todas formas.>"

    old "1. <I feel like you'd be good at hairdressing too, for some reason.>"
    new "1. <Siento que serías bueno como peluquero también, por alguna razón.>"

    old "1. <I'm kidding, silly.>"
    new "1. <Estoy bromeando, tontito.>"

    old "1. <I wouldn't do that to anyone.>"
    new "1. <No le haría eso a nadie.>"

    old "1. <Noted.>"
    new "1. <Anotado.>"

    old "1. <How do you feel about hair dye?>"
    new "1. <¿Qué opinas sobre teñirse el cabello?>"

    old "1. <You feel {i}no{/i} about hair dye?>"
    new "1. <¿No tienes {i}ninguna{/i} opinión sobre teñirse el cabello?>"

    old "1. <I still think you'd rock the black hair...>"
    new "1. <Todavía creo que te verías genial con el cabello negro...>"

    old "1. <I think I kept the receipt...>"
    new "1. <Creo que guardé el recibo...>"

    old "1. <Just kidding. Hehe.>"
    new "1. <Es broma. Jeje.>"

    old "1. <Or haircuts!>"
    new "1. <¡O cortes de cabello!>"

    old "1. <Can I play with it, though?>"
    new "1. <¿Puedo jugar con él, entonces?>"

    old "1. <Put pretty braids in it?>"
    new "1. <¿Hacerte trenzas bonitas?>"

    old "1. <I think it would look nice.>"
    new "1. <Creo que se vería bonito.>"

    old "1. <Tell me when I can, then.>"
    new "1. <Entonces dime cuándo puedo.>"

    old "1. <You won't.>"
    new "1. <No lo harás.>"

    old "1. <I think you'd like the feeling of me playing with your hair.>"
    new "1. <Creo que te gustaría la sensación de que juegue con tu cabello.>"

    old "1. <But I do also think it would look nice.>"
    new "1. <Pero también creo que se vería bonito.>"

    old "1. <But mainly I want to touch :D>"
    new "1. <Pero principalmente quiero tocarte :D>"

    old "1. <Because I think it would look pretty.>"
    new "1. <Porque creo que se vería bonito.>"

    old "1. <Put some in my hair, then?>"
    new "1. <¿Poner algunas en mi cabello, entonces?>"

    old "1. <You're going to give that old lady a heart attack!>"
    new "1. <¡Vas a darle un infarto a esa viejita!>"

    old "1. <I'll make one for myself as well.>"
    new "1. <Haré una para mí también.>"

    old "1. <And then we can match!>"
    new "1. <¡Y luego podemos hacerlo a juego!>"

    old "1. <What if I said pretty please?>"
    new "1. <¿Qué tal si digo por favorcito?>"

    old "1. <Super mega doooooper pretty please?>"
    new "1. <¿Super mega hiper por favorcito?>"

    old "1. <Only might?>"
    new "1. <¿Solo podría?>"


    old "1. <You were {i}born{/i} with hair that long?>"
    new "1. <¿Naciste {i}con{/i} el cabello tan largo?>"

    old "1. <I can't imagine a baby with hair like yours.>"
    new "1. <No puedo imaginar a un bebé con un cabello como el tuyo.>"

    old "1. <That's a little sad.>"
    new "1. <Eso es un poco triste.>"

    old "1. <You missed out on a lot of fun childhood things.>"
    new "1. <Te perdiste muchas cosas divertidas de la infancia.>"

    old "1. <Waking up super early on a Saturday to watch cartoons!>"
    new "1. <¡Despertarse súper temprano un sábado para ver caricaturas!>"

    old "1. <I would have had fun growing up with you.>"
    new "1. <Me habría divertido creciendo contigo.>"

    old "1. <You want me to introduce you to what you missed out on?!>"
    new "1. <¡¿Quieres que te enseñe lo que te perdiste?!>"

    old "1. <Could you have been human once?>"
    new "1. <¿Podrías haber sido humano alguna vez?>"

    old "1. <Maybe they wiped your memories!>"
    new "1. <¡Quizá borraron tus recuerdos!>"

    old "1. <So what happens if you want to quit?>"
    new "1. <Entonces, ¿qué pasa si quieres renunciar?>"

    old "1. <That doesn't sound healthy...>"
    new "1. <Eso no suena saludable...>"

    old "1. <Still need that cold shower, huh?>"
    new "1. <Todavía necesitas esa ducha fría, ¿eh?>"

    old "1. <Oh, yeah. Sorry.>"
    new "1. <Oh, sí. Lo siento.>"

    old "1. <Until tomorrow, Casper.>"
    new "1. <Hasta mañana, Casper.>"



    old "2. <These flowers are beautiful, Grim.>"
    new "2. <Estas flores son hermosas, Parca.>"

    old "2. <I didn't think you had it in you.>"
    new "2. <No pensé que fueras capaz de hacerlo.>"

    old "2. <Okay, now I'm starting to worry.>"
    new "2. <Bien, ahora empiezo a preocuparme.>"

    old "2. <Hahahaha. Absolutely fantastic.>"
    new "2. <Jajajajaja. Absolutamente fantástico.>"

    old "2. <Legally, I think yes.>"
    new "2. <Legalmente, creo que sí.>"

    old "2. <Did you grow them yourself?>"
    new "2. <¿Las cultivaste tú mismo?>"

    old "2. <I bet you've never gardened in your life.>"
    new "2. <Apuesto a que nunca has hecho jardinería en tu vida.>"

    old "2. <And what research purposes would they be?> {font=gui/starthings.ttf}a{/font}"
    new "2. <¿Y cuáles serían esos fines de investigación?> {font=gui/starthings.ttf}a{/font}"


    old "2. <That's the nicest thing anyone's ever said about me.>"
    new "2. <Eso es lo más lindo que alguien ha dicho de mí.>"

    old "2. <...Thanks, Casper.>"
    new "2. <...Gracias, Casper.>"

    old "2. <I kinda like things having reasons, but fine.>"
    new "2. <Me gusta que las cosas tengan una razón, pero está bien.>"

    old "2. <I wasn't going to come out and say it but, yeah?>"
    new "2. <No iba a decirlo directamente, pero sí.>"

    old "2. <I've been flirting since the start.>"
    new "2. <He estado coqueteando desde el principio.>"

    old "2. <I feel touched!>"
    new "2. <¡Me ha tocado el corazón!>"

    old "2. <Very forward of you.>"
    new "2. <Muy directo de tu parte.>"

    old "2. <What a strange thing to call it.>"
    new "2. <Qué cosa tan extraña llamarlo así.>"

    old "2. <My babygirl.>"
    new "2. <Mi babygirl.>"

    old "2. <You saying things like that is just incorrect. Cease.>"
    new "2. <Decir cosas así simplemente no te queda. Basta.>"

    old "2. <Handsome? Maybe. Charming? I don't think so.>"
    new "2. <¿Apuesto? Tal vez. ¿Encantador? No lo creo.>"

    old "2. <Oh noooo, my guard's so down right now!>"
    new "2. <¡Oh nooo, mi guardia está tan baja ahora mismo!>"

    old "2. <It's almost like that's how you actually are.>"
    new "2. <Es casi como si así fueras realmente.>"

    old "2. <And then he will have to admit to himself how much he likes that.>"
    new "2. <Y entonces tendría que admitir cuánto le gusta eso.>"

    old "2. <I knew it...>"
    new "2. <Lo sabía...>"

    old "2. <Do you have some extra serious soul disease?>"
    new "2. <¿Tienes alguna enfermedad del alma súper grave?>"

    old "2. <You're not really inspiring confidence right now...!>"
    new "2. <¡No estás inspirando mucha confianza ahora mismo...!>"

    old "2. <Kinda hard to forget that day.>"
    new "2. <Difícil olvidar ese día.>"

    old "2. <What about it?>"
    new "2. <¿Qué pasa con eso?>"

    old "2. <At least we'd be suffering together!>"
    new "2. <¡Al menos sufriríamos juntos!>"

    old "2. <And now I feel stressed too!>"
    new "2. <¡Y ahora yo también me estoy estresando!>"

    old "2. <Yo.>"
    new "2. <Yo.>"

    old "2. <Bluntly is appreciated.>"
    new "2. <Aprecio la sinceridad.>"

    old "2. <What the...>"
    new "2. <¿Qué demonios...?>"

    old "2. <Don't you get that from {i}souls{/i}? I'm alive!>"
    new "2. <¿No obtienes eso de las {i}almas{/i}? ¡Sigo con vida!>"

    old "2. <What does that meaaaaan?>"
    new "2. <¿Qué quieeere deciiiir eso?>"

    old "2. <Kinda seems like a reach.>"
    new "2. <Eso suena un poco forzado.>"

    old "2. <No, I have no idea what you're even {i}saying{/i}.>"
    new "2. <No, no tengo ni idea de qué estás {i}hablando{/i}.>"

    old "2. <How would I even...>"
    new "2. <¿Cómo se supone que...?>"

    old "2. <Occasionally.>"
    new "2. <De vez en cuando.>"

    old "2. <Just like that, and I'm... nothing?>"
    new "2. <¿Así de simple, y soy... nada?>"

    old "2. <I don't mind. I'll take the sickness. The taint.>"
    new "2. <No me importa. Aceptaré la enfermedad. La corrupción.>"

    old "2. <You can't exactly stop me...>"
    new "2. <No puedes exactamente detenerme...>"

    old "2. <I didn't care about getting married before I met you.>"
    new "2. <No me importaba casarme antes de conocerte.>"

    old "2. <It is challenging for me, but I can if I try reaaaaal hard.>"
    new "2. <Me cuesta, pero puedo hacerlo si me esfuerzo muuuy fuerte.>"

    old "2. <Faaaaantastic.>"
    new "2. <Faaaaantástico.>"

    old "2. <Damn.>"
    new "2. <Maldición.>"


    old "2. <Sometimes, yeah.>"
    new "2. <A veces, sí.>"

    old "2. <Like... imagine if I was like you!> {font=gui/starthings.ttf}a{/font}"
    new "2. <Como... ¡imagina si fuera como tú!> {font=gui/starthings.ttf}a{/font}"

    old "2. <If it annoys you, it makes me want to do it more.>"
    new "2. <Si te molesta, me dan más ganas de hacerlo.>"

    old "2. <...{i}Give up.{/i}>"
    new "2. <...{i}Rendirse.{/i}>"

    old "2. <Honestly, no clue.>"
    new "2. <Sinceramente, ni idea.>"

    old "2. <Tell me more, won't you?>"
    new "2. <Cuéntame más, ¿quieres?>"

    old "2. <Ah.. I see.>"
    new "2. <Ah... ya veo.>"

    old "2. <It's not like you were my only friend or anything.>"
    new "2. <No es como si fueras mi único amigo ni nada.>"

    old "2. <Yes, and..?>"
    new "2. <Sí, ¿y...? >"

    old "2. <Keep going.> {font=gui/starthings.ttf}a{/font}"
    new "2. <Sigue.> {font=gui/starthings.ttf}a{/font}"

    old "2. <Then break them.>"
    new "2. <Entonces, rómpelas.>"

    old "2. <You liiiikeee meeee.>"
    new "2. <Te guuustooo.>"

    old "2. <I'd still call you shy.>"
    new "2. <Aun así diría que eres tímido.>"

    old "2. <I'm actually kinda obsessed with it.>"
    new "2. <De hecho estoy algo obsesionado con él.>"

    old "2. <I can't imagine you with shorter hair.>"
    new "2. <No puedo imaginarte con el cabello más corto.>"

    old "2. <Also, imagine the revenge you'd get on me...>"
    new "2. <Además, imagina la venganza que tendrías conmigo...>"

    old "2. <Hey, you can cut mine if you want.>"
    new "2. <Oye, puedes cortarme el mío si quieres.>"

    old "2. <I love spontaneous haircuts.>"
    new "2. <Me encantan los cortes de cabello espontáneos.>"

    old "2. <Ooooh, better watch your back Grim~>"
    new "2. <Ooooh, mejor cuídate las espaldas Parca~>"

    old "2. <Terrifying.>"
    new "2. <Aterrador.>"

    old "2. <I better return this hair dye, then...>"
    new "2. <Será mejor que devuelva este tinte para el cabello, entonces...>"

    old "2. <No hair dye! Got it!>"
    new "2. <¡Nada de tinte! ¡Entendido!>"

    old "2. <I'm using it as an excuse to touch you.>"
    new "2. <Estoy usando eso como excusa para tocarte.>"

    old "2. <Maybe put some flowers in it?>"
    new "2. <¿Quizá poner algunas flores?>"

    old "2. <I just want to.>"
    new "2. <Solo quiero hacerlo.>"

    old "2. <I am {i}so{/i} down for this.>"
    new "2. <Estoy {i}totalmente{/i} de acuerdo con esto.>"

    old "2. <I could make you a flower crown.>"
    new "2. <Podría hacerte una corona de flores.>"

    old "2. <School book fairs!>"
    new "2. <¡Ferias de libros escolares!>"

    old "2. <But... what about before you were a reaper?>"
    new "2. <Pero... ¿qué pasa antes de ser una parca?>"

    old "2. <Whoops...>"
    new "2. <Uups...>"

    old "3. <You really know how to sweep me off my feet.>"
    new "3. <Realmente sabes cómo dejarme sin aliento.>"

    old "3. <Do you like me then, Casper?> {font=gui/starthings.ttf}a{/font}"
    new "3. <¿Entonces te gusto, Casper?> {font=gui/starthings.ttf}a{/font}"

    old "3. <You are a dork.>"
    new "3. <Eres un tonto.>"

    old "3. <Vaguely, yeah.>"
    new "3. <Vagamente, sí.>"

    old "3. <Tell me, maybe I can help.>"
    new "3. <Dime, tal vez pueda ayudarte.>"

    old "3. <Don't just say 'hey'! I'm freaking out here!>"
    new "3. <¡No digas solo 'hey'! ¡Estoy enloqueciendo aquí!>"

    old "3. <How would I...>"
    new "3. <¿Cómo se supone que...? >"

    old "3. <That's probably just a coinicidence.>"
    new "3. <Probablemente sea solo una coincidencia.>"

    old "3. <But... it couldn't have...>"
    new "3. <Pero... no puede ser...>"

    old "3. <For the things that matter, yes.>"
    new "3. <Para las cosas que importan, sí.>"

    old "3. <How about a shotgun wedding?>"
    new "3. <¿Qué tal una boda relámpago?>"

    old "3. <Marriage is whatever, but it might be fun to do.>"
    new "3. <Casarse da igual, pero podría ser divertido hacerlo.>"

    old "3. <I'll try and calm down then, since you asked so nicely.>"
    new "3. <Intentaré calmarme entonces, ya que lo pediste tan amablemente.>"

    old "3. <You don't?>"
    new "3. <¿No lo haces?>"

    old "3. <I never noticed.>"
    new "3. <Nunca me di cuenta.>"

    old "3. <Are you sure?>"
    new "3. <¿Estás seguro?>"

    old "3. <Going suuuuper high on the swings for the first time!>"
    new "3. <¡Subir suuuper alto en los columpios por primera vez!>"

    old "4. <If I let my guard down the reaper will steal me away~> {font=gui/starthings.ttf}a{/font}"
    new "4. <Si bajo la guardia, la parca me robará~> {font=gui/starthings.ttf}a{/font}"

    old "4. <Greetings and all that, but please start talking.>"
    new "4. <Saludos y todo eso, pero por favor empieza a hablar.>"

    old "4. <You only live once, right?>"
    new "4. <Solo se vive una vez, ¿no?>"

    old "4. <Maybe I'm a new class of reaper?> {font=gui/starthings.ttf}a{/font}"
    new "4. <¿Tal vez soy una nueva clase de parca?> {font=gui/starthings.ttf}a{/font}"

    old "4. <Maybe you should try letting your imagination \nrun wild for a change.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Quizás deberías dejar volar tu imaginación \npor una vez.> {font=gui/starthings.ttf}a{/font}"

    old "4. <I was kidding of course. About us being \nfriends. Totally.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Estaba bromeando, por supuesto. Sobre lo de \nque somos amigos. Totalmente.> {font=gui/starthings.ttf}a{/font}"

    old "4. <You like me?> {font=gui/starthings.ttf}a{/font}"
    new "4. <¿Entonces te gusto?> {font=gui/starthings.ttf}a{/font}"

    old "4. <You want me. You want me so bad.> {font=gui/starthings.ttf}a{/font}"
    new "4. <¿Así que me deseas? Me deseas tanto.> {font=gui/starthings.ttf}a{/font}"

    old "4. <Cool Math Games, of course.>"
    new "4. <Juegos de Matemáticas Geniales, por supuesto.>"

    old "the flowers suit you..."
    new "las flores te favorecen...."