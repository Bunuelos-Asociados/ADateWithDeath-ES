
# game/chapters/4_roomexplore.rpyc:217
translate es bed_hub4_c63951e0:

    # "Your comfortable bed."
    "Tu cómoda cama."

# game/chapters/4_roomexplore.rpyc:218
translate es bed_hub4_2e74d6ea:

    # "Though it's still a little early for sleeping, you can't help but feel a little tired."
    "Aunque todavía es un poco temprano para dormir, no puedes evitar sentir un poco de cansancio."

# game/chapters/4_roomexplore.rpyc:219
translate es bed_hub4_636d2ded:

    # "Your sleep last night was..."
    "Tu sueño anoche fue..."

# game/chapters/4_roomexplore.rpyc:223
translate es bed_hub4_3adb0565:

    # "You spent most of the night tossing and turning from the day's revelations."
    "Pasaste la mayor parte de la noche dando vueltas en la cama por las revelaciones del día."

# game/chapters/4_roomexplore.rpyc:224
translate es bed_hub4_351beb4d:

    # "As it turns out, the strange white haired Grim Reaper roleplayer you met is {i}actually{/i} the Grim Reaper."
    "Resulta que el extraño de pelo blanco roleplayer de la Parca que conociste es,{i}en realidad{/i}, la Parca."

# game/chapters/4_roomexplore.rpyc:225
translate es bed_hub4_92104afb:

    # "{i}Actually{/i} the Grim Reaper, and {i}actually{/i} after your soul."
    "{i}En realidad{/i} la Parca, y {i}en realidad{/i}que va tras tu alma."

# game/chapters/4_roomexplore.rpyc:226
translate es bed_hub4_ff245ef6:

    # "Somehow, the more surprising thing is that rather than be scared, you feel..."
    "De alguna manera, lo más sorprendente es que, en lugar de sentir miedo, sientes..."

# game/chapters/4_roomexplore.rpyc:229
translate es bed_hub4_beee0aeb:

    # "After all, who gets to meet an actual, real life Grim Reaper?"
    "Después de todo, ¿quién tiene la oportunidad de conocer a la mismísima La Parca en persona?"

# game/chapters/4_roomexplore.rpyc:230
translate es bed_hub4_9d43cbeb:

    # "You do!"
    "¡Tú!"

# game/chapters/4_roomexplore.rpyc:231
translate es bed_hub4_47016d5f:

    # "All the excitement from that reveal wore you out, and you slept through the night easily, dreaming of a man whose name you don't even know."
    "Toda la emoción de esa revelación te agotó, y dormiste toda la noche plácidamente, soñando con un hombre cuyo nombre ni siquiera conoces."

# game/chapters/4_roomexplore.rpyc:232
translate es bed_hub4_25df4a78:

    # "Somehow, you don't find it scary that he's after your soul. Instead you feel..."
    "De alguna manera, no te da miedo que él vaya tras tu alma. En cambio, sientes..."

# game/chapters/4_roomexplore.rpyc:235
translate es bed_hub4_000993e1:

    # "Sleep is an elusive thing at the best of times... and finding out the man you're talking to online is {i}actually{/i} the Grim Reaper is not the best of times."
    "Dormir es algo difícil de conseguir en el mejor de los casos... y descubrir que el hombre con el que estás hablando por Internet es {i}en realidad{/i} la Parca no es precisamente el mejor de los casos."

# game/chapters/4_roomexplore.rpyc:236
translate es bed_hub4_91753c3b:

    # "You didn't even get a wink of sleep. Instead, you examined your ceiling in great detail as you thought about the fact that you were actively being hunted for your soul."
    "Ni siquiera pudiste conciliar el sueño. En cambio, te quedaste mirando fijamente el techo mientras pensabas en el hecho de que te perseguían activamente para apoderarse de tu alma."

# game/chapters/4_roomexplore.rpyc:237
translate es bed_hub4_f11a95b5:

    # "Somehow, the Grim Reaper still didn't scare you. Talking to him was... enjoyable. You feel..."
    "De alguna manera, la Parca aún no te asustaba. Hablar con él era... agradable. Te sientes..."

# game/chapters/4_roomexplore.rpyc:241
translate es bed_hub4_39a19b21:

    # "You feel curious about this mysterious man. He's surrounded by puzzles and riddles - how could you not be curious?"
    "Sientes curiosidad por este hombre misterioso. Está rodeado de enigmas y acertijos, ¿cómo no vas a sentir curiosidad?"

# game/chapters/4_roomexplore.rpyc:242
translate es bed_hub4_da0677cc:

    # "You hope that if you keep talking to him, you'll get some answers to the many questions you have about this elusive Grim Reaper."
    "Esperas que si sigues hablando con él, obtendrás algunas respuestas a las muchas preguntas que tienes sobre esta escurridiza Parca."

# game/chapters/4_roomexplore.rpyc:245
translate es bed_hub4_e3e47662:

    # "You don't want to admit it, but you feel somewhat attracted to this man you know so little about."
    "No quieres admitirlo, pero te sientes algo atraída por este hombre del que sabes tan poco."

# game/chapters/4_roomexplore.rpyc:246
translate es bed_hub4_eb34a438:

    # "His attitude is awful, his personality is mediocre at best, but somehow he's become rather charming in your eyes."
    "Su actitud es horrible, su personalidad es mediocre en el mejor de los casos, pero de alguna manera se ha vuelto bastante encantador a tus ojos."

# game/chapters/4_roomexplore.rpyc:247
translate es bed_hub4_cce54bcb:

    # "You also like to tease him. A lot."
    "También te gusta burlarte de él. Mucho"

# game/chapters/4_roomexplore.rpyc:248
translate es bed_hub4_4a6ae7c2:

    # "You hope in the days to come, you'll learn more about him. You are somewhat concerned about what this budding spark may become, however."
    "Esperas que en los próximos días puedas saber más sobre él. Sin embargo, te preocupa un poco en qué puede convertirse esta chispa incipiente."

# game/chapters/4_roomexplore.rpyc:251
translate es bed_hub4_54b96c69:

    # "You're excited! Talking to him is so different and fun. He's not like anyone else you've ever met."
    "¡Sientes emoción! Hablar con él es muy diferente y divertido. No se parece a nadie que hayas conocido antes."

# game/chapters/4_roomexplore.rpyc:252
translate es bed_hub4_cb42e890:

    # "There's something about the extraordinary you've always enjoyed. You've always felt like there was something more to life that you hadn't yet discovered."
    "Hay algo sobre lo extraordinario que siempre te ha gustado. Siempre has sentido que había algo más en la vida que aún no habías descubierto."

# game/chapters/4_roomexplore.rpyc:253
translate es bed_hub4_f16ac61c:

    # "Perhaps you've found it now."
    "Quizás ahora lo hayas encontrado."

# game/chapters/4_roomexplore.rpyc:263
translate es door_hub4_eb6af445:

    # "You put your ear to the door, listening closely."
    "Pones la oreja en la puerta y escuchas atentamente."

# game/chapters/4_roomexplore.rpyc:264
translate es door_hub4_9ecf268a:

    # "You can hear something, but it seems muffled. You wonder if you'll be able to hear better from your window."
    "Puedes oír algo, pero parece amortiguado. Te preguntas si podrás oír mejor desde tu ventana."

# game/chapters/4_roomexplore.rpyc:270
translate es door_hub4_722f0a35:

    # "You push open your window. A cool, night time breeze blows inside."
    "Abres la ventana. Una brisa fresca nocturna entra en la habitación."

# game/chapters/4_roomexplore.rpyc:271
translate es door_hub4_5fae18ae:

    # "It feels nice."
    "Se siente agradable."

# game/chapters/4_roomexplore.rpyc:272
translate es door_hub4_0ca91273:

    # "You look up at the stars above and think for a moment that being alive truly is worth it."
    "Miras las estrellas en el cielo y piensas por un momento que realmente vale la pena estar vivo."

# game/chapters/4_roomexplore.rpyc:273
translate es door_hub4_16973246:

    # "Then you hear two voices from next door - one light and airy, and another deep and calm."
    "Luego escuchas dos voces de al lado: una ligera y aireada, y otra profunda y tranquila."

# game/chapters/4_roomexplore.rpyc:274
translate es door_hub4_e6b56933:

    # "Just like you, they seem to be watching the stars. You can't help but feel that under such a big sky, happening to be alive at the same time as people you care about is very special."
    "Al igual que tú, parecen estar mirando las estrellas. No puedes evitar sentir que bajo un cielo tan grande, que está vivo al mismo tiempo que las personas que te importan es muy especial."

# game/chapters/4_roomexplore.rpyc:275
translate es door_hub4_2a085af1:

    # "The light voice speaks first."
    "La voz ligera habla primero."

# game/chapters/4_roomexplore.rpyc:276
translate es door_hub4_21f6ee7a:

    # "'Isn't it just beautiful? That's why I decided to rent this apartment. The view is amazing during the day, but nothing beats the night sky.'"
    "'¿No es simplemente hermoso? Por eso decidí alquilar este apartamento. La vista es increíble durante el día, pero nada supera el cielo nocturno."

# game/chapters/4_roomexplore.rpyc:277
translate es door_hub4_7fe21b16:

    # "'You are... it is very beautiful.' the deeper voice answers, sounding somewhat absent minded."
    "'Lo eres ... es muy hermoso'. La voz más profunda responde, sonando algo ausente."

# game/chapters/4_roomexplore.rpyc:278
translate es door_hub4_03a0ef2e:

    # "'You've always loved the stars, haven't you?' the deep voice continues. 'Forever and ever, right?'"
    "'Siempre te han encantado las estrellas, ¿no?' La voz profunda continúa. 'Por siempre y para siempre, ¿verdad?'"

# game/chapters/4_roomexplore.rpyc:279
translate es door_hub4_8e4a5a04:

    # "The lighter voice pauses for a moment, '...Actually, yes. As long as I can remember.'"
    "La voz más ligera se detiene por un momento, '... en realidad, sí. Mientras tenga en cuenta."

# game/chapters/4_roomexplore.rpyc:280
translate es door_hub4_4ffe0e1a:

    # "'I thought so.'"
    "'Ya me lo imaginaba.'"

# game/chapters/4_roomexplore.rpyc:281
translate es door_hub4_cbf6bacf:

    # "'How could you guess?'"
    "'¿Cómo puedes adivinar?'"

# game/chapters/4_roomexplore.rpyc:282
translate es door_hub4_10ba9ad7:

    # "'To be honest, I'm a little embarrassed to say it...'"
    "'Para ser honesto, estoy un poco avergonzado de decirlo ...'"

# game/chapters/4_roomexplore.rpyc:283
translate es door_hub4_d0b17f29:

    # "'I feel like I see the universe in your eyes. Sorry, it sounds a little corny...'"
    "'Siento que veo el universo en tus ojos. Lo siento, suena un poco cursi ... '"

# game/chapters/4_roomexplore.rpyc:284
translate es door_hub4_0edfbc16:

    # "The two voices go quiet for a moment, and you feel like these two people you've never met are too busy looking into each other's eyes to say anything."
    "Las dos voces se callan por un momento, y sientes que estas dos personas que nunca has conocido están demasiado ocupadas mirando a los ojos para decir algo."

# game/chapters/4_roomexplore.rpyc:285
translate es door_hub4_0515424d:

    # "The deeper voice finally pipes up again."
    "La voz más profunda finalmente vuelve a subir."

# game/chapters/4_roomexplore.rpyc:286
translate es door_hub4_8116e649:

    # "'Do you believe in fate?'"
    "¿Crees en el destino?"

# game/chapters/4_roomexplore.rpyc:287
translate es door_hub4_27b932b0:

    # "The lighter voice answers, but seems much... smaller than usual."
    "La voz más ligera responde, pero parece mucho ... más pequeña de lo habitual."

# game/chapters/4_roomexplore.rpyc:288
translate es door_hub4_5fccdc99:

    # "'I'm... not sure.'"
    "'No estoy seguro.'"

# game/chapters/4_roomexplore.rpyc:289
translate es door_hub4_708b38ea:

    # "'I feel like you are someone I was always meant to meet.'"
    "\"Siento que eres alguien a quien siempre tuve la intención de conocer\"."

# game/chapters/4_roomexplore.rpyc:290
translate es door_hub4_3e543646:

    # "'But, I...' the voice, cool like the night sky above, cuts off."
    "'Pero, yo ...' La voz, fresca como el cielo nocturno de arriba, se corta."

# game/chapters/4_roomexplore.rpyc:291
translate es door_hub4_0958beee:

    # "'...I don't want to hurt you, and I'm afraid that the same fate that made us meet in the first place will make me cause you pain.'"
    "\"... no quiero lastimarte, y me temo que el mismo destino que nos hizo encontrar en primer lugar me hará causarle dolor\"."

# game/chapters/4_roomexplore.rpyc:292
translate es door_hub4_34ec7590:

    # "'Half of me wants to stay anyway, and the other half knows how selfish that sounds.'"
    "\"La mitad de mí quiere quedarme de todos modos, y la otra mitad sabe cuán egoísta suena\"."

# game/chapters/4_roomexplore.rpyc:293
translate es door_hub4_12bc8e0d:

    # "'Can't there be a third option?' the light voice adds on, barely a whisper."
    "'¿No puede haber una tercera opción?' La voz ligera se suma, apenas un susurro."

# game/chapters/4_roomexplore.rpyc:294
translate es door_hub4_64e1c86e:

    # "A sigh escapes into the night air."
    "Un suspiro escapa al aire nocturno."

# game/chapters/4_roomexplore.rpyc:295
translate es door_hub4_e86eb6c9:

    # "'I wish there was.'"
    "'Ojalá lo hubiera'."

# game/chapters/4_roomexplore.rpyc:296
translate es door_hub4_396e0781:

    # "'It's getting late. I had better head off.'"
    "'Se está haciendo tarde. Mejor me iré."

# game/chapters/4_roomexplore.rpyc:297
translate es door_hub4_9d5463fd:

    # "The voices slowly fade, and soon enough you hear your neighbor's door open then close."
    "Las voces se desvanecen lentamente, y muy pronto escuchas la puerta de tu vecino abrirse y luego cerrar."

# game/chapters/4_roomexplore.rpyc:298
translate es door_hub4_c542f4d0:

    # "That seems to be everything you'll hear for the night."
    "Eso parece ser todo lo que escucharás por la noche."

# game/chapters/4_roomexplore.rpyc:299
translate es door_hub4_4b736e1f:

    # "But it did get you thinking. About fate, and chance meetings, and the budding feelings within your chest."
    "Pero te hizo pensar. Sobre el destino y las reuniones casuales, y los sentimientos en ciernes dentro de su pecho."

# game/chapters/4_roomexplore.rpyc:313
translate es door_hub4_722f0a35_1:

    # "You push open your window. A cool, night time breeze blows inside."
    "Empujas su ventana. Una brisa fresca y nocturna sopla dentro."

# game/chapters/4_roomexplore.rpyc:314
translate es door_hub4_5fae18ae_1:

    # "It feels nice."
    "Se siente bien."

# game/chapters/4_roomexplore.rpyc:315
translate es door_hub4_0ca91273_1:

    # "You look up at the stars above and think for a moment that being alive truly is worth it."
    "Miras hacia las estrellas de arriba y piensas por un momento que estar vivo realmente vale la pena."

# game/chapters/4_roomexplore.rpyc:316
translate es door_hub4_16973246_1:

    # "Then you hear two voices from next door - one light and airy, and another deep and calm."
    "Entonces oyes dos voces procedentes de la habitación de al lado - una ligera y alegre, y otra grave y tranquila."

# game/chapters/4_roomexplore.rpyc:317
translate es door_hub4_e6b56933_1:

    # "Just like you, they seem to be watching the stars. You can't help but feel that under such a big sky, happening to be alive at the same time as people you care about is very special."
    "Al igual que tú, parecen estar contemplando las estrellas. No puedes evitar sentir que, bajo un cielo tan inmenso, el hecho de estar vivo al mismo tiempo que las personas que te importan es algo muy especial."

# game/chapters/4_roomexplore.rpyc:318
translate es door_hub4_2a085af1_1:

    # "The light voice speaks first."
    "La voz ligera habla primero."

# game/chapters/4_roomexplore.rpyc:319
translate es door_hub4_21f6ee7a_1:

    # "'Isn't it just beautiful? That's why I decided to rent this apartment. The view is amazing during the day, but nothing beats the night sky.'"
    "'¿No es precioso? Por eso decidí alquilar este departamento. Las vistas son increíbles durante el día, pero nada supera al cielo nocturno.'"

# game/chapters/4_roomexplore.rpyc:320
translate es door_hub4_7fe21b16_1:

    # "'You are... it is very beautiful.' the deeper voice answers, sounding somewhat absent minded."
    "'Tienes razón... es muy bonito', responde la voz más grave, con un tono algo distraído."

# game/chapters/4_roomexplore.rpyc:321
translate es door_hub4_03a0ef2e_1:

    # "'You've always loved the stars, haven't you?' the deep voice continues. 'Forever and ever, right?'"
    "'Siempre te han gustado las estrellas, ¿verdad?', continúa la voz grave. 'Desde siempre, ¿verdad?'"

# game/chapters/4_roomexplore.rpyc:322
translate es door_hub4_8e4a5a04_1:

    # "The lighter voice pauses for a moment, '...Actually, yes. As long as I can remember.'"
    "La voz más suave hace una pausa por un momento: '... En realidad, sí. Desde que tengo memoria.'"

# game/chapters/4_roomexplore.rpyc:323
translate es door_hub4_4ffe0e1a_1:

    # "'I thought so.'"
    "'Eso pensaba.'"

# game/chapters/4_roomexplore.rpyc:324
translate es door_hub4_cbf6bacf_1:

    # "'How could you guess?'"
    "'¿Cómo lo adivinaste?'"

# game/chapters/4_roomexplore.rpyc:325
translate es door_hub4_10ba9ad7_1:

    # "'To be honest, I'm a little embarrassed to say it...'"
    "'Honestamente, me da un poco de vergüenza decirlo...'"

# game/chapters/4_roomexplore.rpyc:326
translate es door_hub4_d0b17f29_1:

    # "'I feel like I see the universe in your eyes. Sorry, it sounds a little corny...'"
    "'Siento como si viera el universo en tus ojos. Lo siento, suena un poco cursi...'"

# game/chapters/4_roomexplore.rpyc:327
translate es door_hub4_0edfbc16_1:

    # "The two voices go quiet for a moment, and you feel like these two people you've never met are too busy looking into each other's eyes to say anything."
    "Las dos voces se callan por un momento y sientes que estas dos personas que nunca has conocido están demasiado ocupadas mirándose a los ojos como para decir nada."

# game/chapters/4_roomexplore.rpyc:328
translate es door_hub4_0515424d_1:

    # "The deeper voice finally pipes up again."
    "La voz más grave finalmente vuelve a hablar."

# game/chapters/4_roomexplore.rpyc:329
translate es door_hub4_8116e649_1:

    # "'Do you believe in fate?'"
    "¿Crees en el destino?"

# game/chapters/4_roomexplore.rpyc:330
translate es door_hub4_27b932b0_1:

    # "The lighter voice answers, but seems much... smaller than usual."
    "La voz más suave responde, pero parece mucho... más débil de lo habitual."

# game/chapters/4_roomexplore.rpyc:331
translate es door_hub4_5fccdc99_1:

    # "'I'm... not sure.'"
    "'No lo sé.'"

# game/chapters/4_roomexplore.rpyc:332
translate es door_hub4_708b38ea_1:

    # "'I feel like you are someone I was always meant to meet.'"
    "\"Siento que eres alguien a quien el destino quería que conociera\"."

# game/chapters/4_roomexplore.rpyc:333
translate es door_hub4_3e543646_1:

    # "'But, I...' the voice, cool like the night sky above, cuts off."
    "'Pero yo...', la voz, fría como el cielo nocturno, se interrumpe."

# game/chapters/4_roomexplore.rpyc:334
translate es door_hub4_0958beee_1:

    # "'...I don't want to hurt you, and I'm afraid that the same fate that made us meet in the first place will make me cause you pain.'"
    "\"...No quiero hacerte daño, y me da miedo que el mismo destino que nos ha hecho encontrarnos me lleve a causarte dolor\"."

# game/chapters/4_roomexplore.rpyc:335
translate es door_hub4_34ec7590_1:

    # "'Half of me wants to stay anyway, and the other half knows how selfish that sounds.'"
    "\"La mitad de mí quiere quedarse de todos modos, y la otra mitad sabe lo egoísta que suena eso\"."

# game/chapters/4_roomexplore.rpyc:336
translate es door_hub4_12bc8e0d_1:

    # "'Can't there be a third option?' the light voice adds on, barely a whisper."
    "'¿No puede haber una tercera opción?', añade la voz ligera, apenas un susurro."

# game/chapters/4_roomexplore.rpyc:337
translate es door_hub4_64e1c86e_1:

    # "A sigh escapes into the night air."
    "Un suspiro se escapa en el aire nocturno."

# game/chapters/4_roomexplore.rpyc:338
translate es door_hub4_e86eb6c9_1:

    # "'I wish there was.'"
    "'Ojalá la hubiera'."

# game/chapters/4_roomexplore.rpyc:339
translate es door_hub4_396e0781_1:

    # "'It's getting late. I had better head off.'"
    "'Se está haciendo tarde. Será mejor que me vaya.'"

# game/chapters/4_roomexplore.rpyc:340
translate es door_hub4_9d5463fd_1:

    # "The voices slowly fade, and soon enough you hear your neighbor's door open then close."
    "Las voces se desvanecen lentamente y, al poco tiempo, oyes cómo se abre y se cierra la puerta de tu vecino."

# game/chapters/4_roomexplore.rpyc:341
translate es door_hub4_c542f4d0_1:

    # "That seems to be everything you'll hear for the night."
    "Parece que eso es todo lo que oirás esta noche."

# game/chapters/4_roomexplore.rpyc:342
translate es door_hub4_4b736e1f_1:

    # "But it did get you thinking. About fate, and chance meetings, and the budding feelings within your chest."
    "Pero te ha hecho pensar. Sobre el destino, los encuentros fortuitos y los sentimientos que brotan en tu pecho."

# game/chapters/4_roomexplore.rpyc:354
translate es door_hub4_aa9c4dbc:

    # "The apartment and hallway beyond is silent."
    "El apartamento y el pasillo están en silencio"

# game/chapters/4_roomexplore.rpyc:355
translate es door_hub4_60e3b598:

    # "You'll have to wait until tomorrow to hear more about your peculiar neighbors."
    "Tendrás que esperar hasta mañana para saber más sobre tus peculiares vecinos."

# game/chapters/4_roomexplore.rpyc:369
translate es snake_hub4_08ed904d:

    # "[pet_name] is hanging out on your bed at the moment."
    "[pet_name] está pasando el rato en tu cama en este momento."

# game/chapters/4_roomexplore.rpyc:370
translate es snake_hub4_6c976065:

    # "As you sit down next to [pet_her2], you think a little bit on your shared history."
    "Mientras te sientas junto a [pet_she!t], piensas un poco en su historia compartida."

# game/chapters/4_roomexplore.rpyc:371
translate es snake_hub4_6b0c7405:

    # "Just how did you come up with [pet_her] name, again?"
    "¿Cómo se te ocurrió el nombre de [pet_she!t], otra vez?"

# game/chapters/4_roomexplore.rpyc:377
translate es snake_hub4_6f27dc4e:

    # "What best way to memorialize your favorite character but in pet form?"
    "¿Qué mejor manera de conmemorar a tu personaje favorito que en forma de mascota?"

# game/chapters/4_roomexplore.rpyc:378
translate es snake_hub4_918b0e4c:

    # "You love both [pet_name]'s dearly."
    "Quieres mucho a [pet_name], tu mascota y personaje favorito."

# game/chapters/4_roomexplore.rpyc:382
translate es snake_hub4_157b1c09:

    # "Sure, it's not very original, but it gets the job done."
    "Claro, no es muy original, pero cumple su función."

# game/chapters/4_roomexplore.rpyc:383
translate es snake_hub4_1218ce43:

    # "You can't think of [pet_name] being called anything other than [pet_name]."
    "No puedes imaginar que [pet_name] se llame de otra manera que no sea [pet_name]."

# game/chapters/4_roomexplore.rpyc:387
translate es snake_hub4_bb04072f:

    # "You didn't have any particular naming plan for [pet_her2]."
    "No tenías ningún plan concreto para ponerle nombre a [pet_she!t]."

# game/chapters/4_roomexplore.rpyc:388
translate es snake_hub4_48ce966d:

    # "As soon as you saw [pet_her2], you knew the right name."
    "En el momento en que cruzaste mirada con [pet_she!t], sabías el nombre correcto."

# game/chapters/4_roomexplore.rpyc:392
translate es snake_hub4_e96bb619:

    # "You planned out [pet_her]'s name seven months in advance."
    "Planeaste el nombre de [pet_she!t] con siete meses de anticipación."

# game/chapters/4_roomexplore.rpyc:393
translate es snake_hub4_c856f278:

    # "You always have been good at being prepared."
    "Siempre se te ha dado bien prepararte."

# game/chapters/4_roomexplore.rpyc:399
translate es snake_hub4_0a92517d:

    # "You spend the better part of the night cleaning out [pet_name]'s enclosure."
    "Pasas la mayor parte de la noche limpiando el recinto de [pet_name]."

# game/chapters/4_roomexplore.rpyc:400
translate es snake_hub4_73cd42e1:

    # "You remove all of the bowls, accessories and bedding first, cleaning them as you go, then wash out the enclosure with hot, soapy water."
    "Primero retiras todos los tazones, accesorios y mantas, limpiándolos a medida que avanzas, luego lavas el recinto con agua caliente y jabonosa."

# game/chapters/4_roomexplore.rpyc:401
translate es snake_hub4_bf05b7bb:

    # "It's a bit of work, but you're pretty used to it, seeing at you do a big clean once a week."
    "Es un poco de trabajo, pero ya te has acostumbrado, ya que haces una limpieza a fondo una vez a la semana."

# game/chapters/4_roomexplore.rpyc:402
translate es snake_hub4_44d3a933:

    # "No one said having a pet snake was easy."
    "Nadie dijo que tener una serpiente de mascota fuera fácil."

# game/chapters/4_roomexplore.rpyc:414
translate es bingus_hub4_08ed904d:

    # "[pet_name] is hanging out on your bed at the moment."
    "[pet_name] está pasando el rato en tu cama en este momento."

# game/chapters/4_roomexplore.rpyc:415
translate es bingus_hub4_6c976065:

    # "As you sit down next to [pet_her2], you think a little bit on your shared history."
    "Mientras te sientas junto a [pet_she!t], piensas un poco en su historia compartida."

# game/chapters/4_roomexplore.rpyc:416
translate es bingus_hub4_6b0c7405:

    # "Just how did you come up with [pet_her] name, again?"
    "¿Cómo se te ocurrió el nombre de [pet_she!t], otra vez?"

# game/chapters/4_roomexplore.rpyc:422
translate es bingus_hub4_6f27dc4e:

    # "What best way to memorialize your favorite character but in pet form?"
    "¿Qué mejor manera de conmemorar a tu personaje favorito que en forma de mascota?"

# game/chapters/4_roomexplore.rpyc:423
translate es bingus_hub4_918b0e4c:

    # "You love both [pet_name]'s dearly."
    "Quieres mucho a [pet_name], tu mascota y personaje favorito."

# game/chapters/4_roomexplore.rpyc:427
translate es bingus_hub4_157b1c09:

    # "Sure, it's not very original, but it gets the job done."
    "Claro, no es muy original, pero cumple su función."

# game/chapters/4_roomexplore.rpyc:428
translate es bingus_hub4_1218ce43:

    # "You can't think of [pet_name] being called anything other than [pet_name]."
    "No puedes imaginar que [pet_name] se llame de otra manera que no sea [pet_name]."

# game/chapters/4_roomexplore.rpyc:432
translate es bingus_hub4_bb04072f:

    # "You didn't have any particular naming plan for [pet_her2]."
    "No tenías ningún plan concreto para ponerle nombre a [pet_she!t]."

# game/chapters/4_roomexplore.rpyc:433
translate es bingus_hub4_48ce966d:

    # "As soon as you saw [pet_her2], you knew the right name."
    "En el momento en que cruzaste mirada con [pet_she!t], sabías el nombre correcto."

# game/chapters/4_roomexplore.rpyc:437
translate es bingus_hub4_e96bb619:

    # "You planned out [pet_her]'s name seven months in advance."
    "Planeaste el nombre de [pet_she!t] con siete meses de anticipación."

# game/chapters/4_roomexplore.rpyc:438
translate es bingus_hub4_c856f278:

    # "You always have been good at being prepared."
    "Siempre se te ha dado bien prepararte."

# game/chapters/4_roomexplore.rpyc:443
translate es bingus_hub4_f3086971:

    # "One of the first things you learned about Sphynxes was that they are particuarly grubby pets."
    "Una de las primeras cosas que aprendiste sobre los gatos Sphynx es que son mascotas especialmente sucias."

# game/chapters/4_roomexplore.rpyc:444
translate es bingus_hub4_a09fef10:

    # "Especially in the summer."
    "Especialmente en el verano."

# game/chapters/4_roomexplore.rpyc:445
translate es bingus_hub4_dd1d3b4e:

    # "You go about cleaning [pet_name]'s ears, between [pet_her] toes, and wiping down [pet_her] skin."
    "Limpias las orejas de [pet_name], entre los dedos de las patas y le limpias la piel."

# game/chapters/4_roomexplore.rpyc:446
translate es bingus_hub4_856e6bd8:

    # "[pet_name] has occassional baths, too, but for today a little maintenance is enough."
    "[pet_name] ] también se baña de vez en cuando, pero por hoy basta con un poco de mantenimiento."

# game/chapters/4_roomexplore.rpyc:447
translate es bingus_hub4_6360d0cb:

    # "[pet_name] purrs the whole time - [pet_she]'s always enjoyed being groomed."
    "[pet_name] ronronea todo el tiempo - [pet_she!t] siempre le gustó que le peinaran."

# game/chapters/4_roomexplore.rpyc:459
translate es bunny_hub4_08ed904d:

    # "[pet_name] is hanging out on your bed at the moment."
    "[pet_name] está pasando el rato en tu cama en este momento."

# game/chapters/4_roomexplore.rpyc:460
translate es bunny_hub4_6c976065:

    # "As you sit down next to [pet_her2], you think a little bit on your shared history."
    "Mientras te sientas junto a [pet_she!t], piensas un poco en su historia compartida."

# game/chapters/4_roomexplore.rpyc:461
translate es bunny_hub4_6b0c7405:

    # "Just how did you come up with [pet_her] name, again?"
    "¿Cómo se te ocurrió el nombre de [pet_she!t], otra vez?"

# game/chapters/4_roomexplore.rpyc:467
translate es bunny_hub4_6f27dc4e:

    # "What best way to memorialize your favorite character but in pet form?"
    "¿Qué mejor manera de conmemorar a tu personaje favorito que en forma de mascota?"

# game/chapters/4_roomexplore.rpyc:468
translate es bunny_hub4_918b0e4c:

    # "You love both [pet_name]'s dearly."
    "Quieres mucho a [pet_name], tu mascota y personaje favorito."

# game/chapters/4_roomexplore.rpyc:472
translate es bunny_hub4_157b1c09:

    # "Sure, it's not very original, but it gets the job done."
    "Claro, no es muy original, pero cumple su función."

# game/chapters/4_roomexplore.rpyc:473
translate es bunny_hub4_1218ce43:

    # "You can't think of [pet_name] being called anything other than [pet_name]."
    "No puedes imaginar que [pet_name] se llame de otra manera que no sea [pet_name]."

# game/chapters/4_roomexplore.rpyc:477
translate es bunny_hub4_bb04072f:

    # "You didn't have any particular naming plan for [pet_her2]."
    "No tenías ningún plan concreto para ponerle nombre a [pet_she!t]."

# game/chapters/4_roomexplore.rpyc:478
translate es bunny_hub4_48ce966d:

    # "As soon as you saw [pet_her2], you knew the right name."
    "En el momento en que cruzaste mirada con [pet_she!t], sabías el nombre correcto."

# game/chapters/4_roomexplore.rpyc:482
translate es bunny_hub4_e96bb619:

    # "You planned out [pet_her]'s name seven months in advance."
    "Planeaste el nombre de [pet_she!t] con siete meses de anticipación."

# game/chapters/4_roomexplore.rpyc:483
translate es bunny_hub4_c856f278:

    # "You always have been good at being prepared."
    "Siempre se te ha dado bien prepararte."

# game/chapters/4_roomexplore.rpyc:488
translate es bunny_hub4_f5f5d976:

    # "You place a small towel across your lap and put [pet_name] on top of it."
    "Colocas una toalla pequeña sobre tu regazo y pones a [pet_name] encima."

# game/chapters/4_roomexplore.rpyc:489
translate es bunny_hub4_1ed0bc2f:

    # "With your handy soft bristle brush, you spend some time combing and grooming [pet_name]."
    "Con tu práctico cepillo de cerdas suaves, dedicas un tiempo a peinar y acicalar a [pet_name]."

# game/chapters/4_roomexplore.rpyc:490
translate es bunny_hub4_46996560:

    # "You're always very gentle and careful, and [pet_name] enjoys it a lot."
    "Siempre eres muy amable y prudente, y [pet_name] lo disfruta mucho."

# game/chapters/4_roomexplore.rpyc:491
translate es bunny_hub4_9809d23d:

    # "You give [pet_her2] a pat behind the ears when you're done."
    "Le das una caricia detrás de las orejas a [pet_she!t] cuando terminas."

# game/chapters/4_roomexplore.rpyc:503
translate es cat_hub4_08ed904d:

    # "[pet_name] is hanging out on your bed at the moment."
    "[pet_name] está pasando el rato en tu cama en este momento."

# game/chapters/4_roomexplore.rpyc:504
translate es cat_hub4_6c976065:

    # "As you sit down next to [pet_her2], you think a little bit on your shared history."
    "Mientras te sientas junto a [pet_she!t], piensas un poco en su historia compartida."

# game/chapters/4_roomexplore.rpyc:505
translate es cat_hub4_6b0c7405:

    # "Just how did you come up with [pet_her] name, again?"
    "¿Cómo se te ocurrió el nombre de [pet_she!t], otra vez?"

# game/chapters/4_roomexplore.rpyc:511
translate es cat_hub4_6f27dc4e:

    # "What best way to memorialize your favorite character but in pet form?"
    "¿Qué mejor manera de conmemorar a tu personaje favorito que en forma de mascota?"

# game/chapters/4_roomexplore.rpyc:512
translate es cat_hub4_918b0e4c:

    # "You love both [pet_name]'s dearly."
    "Quieres mucho a [pet_name], tu mascota y personaje favorito."

# game/chapters/4_roomexplore.rpyc:516
translate es cat_hub4_157b1c09:

    # "Sure, it's not very original, but it gets the job done."
    "Claro, no es muy original, pero cumple su función."

# game/chapters/4_roomexplore.rpyc:517
translate es cat_hub4_1218ce43:

    # "You can't think of [pet_name] being called anything other than [pet_name]."
    "No puedes imaginar que [pet_name] se llame de otra manera que no sea [pet_name]."

# game/chapters/4_roomexplore.rpyc:521
translate es cat_hub4_bb04072f:

    # "You didn't have any particular naming plan for [pet_her2]."
    "No tenías ningún plan concreto para ponerle nombre a [pet_she!t]."

# game/chapters/4_roomexplore.rpyc:522
translate es cat_hub4_48ce966d:

    # "As soon as you saw [pet_her2], you knew the right name."
    "En el momento en que cruzaste mirada con [pet_she!t], sabías el nombre correcto."

# game/chapters/4_roomexplore.rpyc:526
translate es cat_hub4_e96bb619:

    # "You planned out [pet_her]'s name seven months in advance."
    "Planeaste el nombre de [pet_she!t] con siete meses de anticipación."

# game/chapters/4_roomexplore.rpyc:527
translate es cat_hub4_c856f278:

    # "You always have been good at being prepared."
    "Siempre se te ha dado bien prepararte."

# game/chapters/4_roomexplore.rpyc:532
translate es cat_hub4_cb6a4193:

    # "[pet_name] is looking particularly relaxed right now, and you know that's the best time to strike."
    "[pet_name] se ve particularmente relax en este momento, y sabes que ese es el mejor momento para atacar."

# game/chapters/4_roomexplore.rpyc:533
translate es cat_hub4_b39645bb:

    # "Calmly, you sit next to [pet_her2] on the bed and pull out a rubber brush."
    "Con calma, te sientas junto a [pet_she!t] en la cama y sacas un cepillo de goma."

# game/chapters/4_roomexplore.rpyc:534
translate es cat_hub4_4ebadd13:

    # "Luckily, [pet_name] enjoys being brushed, and happily sleeps through the grooming session."
    "Afortunadamente, [pet_name] disfruta el cepillado, y duerme felizmente durante toda la sesión de aseo."

# game/chapters/4_roomexplore.rpyc:535
translate es cat_hub4_c3a804c1:

    # "What [pet_she] enjoys less is having [pet_her] nails clipped, but you manage to get through them all."
    "Lo que [pet_she!t] disfruta menos es que le sus corten uñas, pero te las arreglas para terminarlas todas."

# game/chapters/4_roomexplore.rpyc:536
translate es cat_hub4_93d71a1a:

    # "You give [pet_name] a little treat at the end of it."
    "Das a [pet_name] un pequeño regalo al final."

# game/chapters/4_roomexplore.rpyc:548
translate es dog_hub4_08ed904d:

    # "[pet_name] is hanging out on your bed at the moment."
    "[pet_name] está pasando el rato en tu cama en este momento."

# game/chapters/4_roomexplore.rpyc:549
translate es dog_hub4_6c976065:

    # "As you sit down next to [pet_her2], you think a little bit on your shared history."
    "Mientras te sientas junto a [pet_she!t], piensas un poco en su historia compartida."

# game/chapters/4_roomexplore.rpyc:550
translate es dog_hub4_6b0c7405:

    # "Just how did you come up with [pet_her] name, again?"
    "¿Cómo se te ocurrió el nombre de [pet_she!t], otra vez?"

# game/chapters/4_roomexplore.rpyc:556
translate es dog_hub4_6f27dc4e:

    # "What best way to memorialize your favorite character but in pet form?"
    "¿Qué mejor manera de conmemorar a tu personaje favorito que en forma de mascota?"

# game/chapters/4_roomexplore.rpyc:557
translate es dog_hub4_918b0e4c:

    # "You love both [pet_name]'s dearly."
    "Quieres mucho a [pet_name], tu mascota y personaje favorito."

# game/chapters/4_roomexplore.rpyc:561
translate es dog_hub4_157b1c09:

    # "Sure, it's not very original, but it gets the job done."
    "Claro, no es muy original, pero cumple su función."

# game/chapters/4_roomexplore.rpyc:562
translate es dog_hub4_1218ce43:

    # "You can't think of [pet_name] being called anything other than [pet_name]."
    "No puedes imaginar que [pet_name] se llame de otra manera que no sea [pet_name]."

# game/chapters/4_roomexplore.rpyc:566
translate es dog_hub4_bb04072f:

    # "You didn't have any particular naming plan for [pet_her2]."
    "No tenías ningún plan concreto para ponerle nombre a [pet_she!t]."

# game/chapters/4_roomexplore.rpyc:567
translate es dog_hub4_48ce966d:

    # "As soon as you saw [pet_her2], you knew the right name."
    "En el momento en que cruzaste mirada con [pet_she!t], sabías el nombre correcto."

# game/chapters/4_roomexplore.rpyc:571
translate es dog_hub4_e96bb619:

    # "You planned out [pet_her]'s name seven months in advance."
    "Planeaste el nombre de [pet_she!t] con siete meses de anticipación."

# game/chapters/4_roomexplore.rpyc:572
translate es dog_hub4_c856f278:

    # "You always have been good at being prepared."
    "Siempre se te ha dado bien prepararte."

# game/chapters/4_roomexplore.rpyc:577
translate es dog_hub4_520960c8:

    # "You lead [pet_name] to your bathroom and quickly get to giving [pet_her2] a scrub down."
    "Llevas a [pet_name] a tu baño y rápidamente te pones a darle un buen baño."

# game/chapters/4_roomexplore.rpyc:578
translate es dog_hub4_9c002b11:

    # "Luckily, [pet_name] LOVES bathes, and honestly would stay in there all day if [pet_she] could."
    "Afortunadamente, [pet_name] AMA los baños, y honestamente se quedaría allí todo el día si [pet_she!t] pudiera."

# game/chapters/4_roomexplore.rpyc:579
translate es dog_hub4_895918eb:

    # "After the bath, you spend a little time brushing [pet_name] - another favorite activity."
    "Después del baño, pasas un poco de tiempo cepillando a [pet_name] - otra actividad favorita."

# game/chapters/4_roomexplore.rpyc:593
translate es hamster_hub4_08ed904d:

    # "[pet_name] is hanging out on your bed at the moment."
    "[pet_name] está pasando el rato en tu cama en este momento."

# game/chapters/4_roomexplore.rpyc:594
translate es hamster_hub4_6c976065:

    # "As you sit down next to [pet_her2], you think a little bit on your shared history."
    "Mientras te sientas junto a [pet_she!t], piensas un poco en su historia compartida."

# game/chapters/4_roomexplore.rpyc:595
translate es hamster_hub4_6b0c7405:

    # "Just how did you come up with [pet_her] name, again?"
    "¿Cómo se te ocurrió el nombre de [pet_she!t], otra vez?"

# game/chapters/4_roomexplore.rpyc:601
translate es hamster_hub4_6f27dc4e:

    # "What best way to memorialize your favorite character but in pet form?"
    "¿Qué mejor manera de conmemorar a tu personaje favorito que en forma de mascota?"

# game/chapters/4_roomexplore.rpyc:602
translate es hamster_hub4_918b0e4c:

    # "You love both [pet_name]'s dearly."
    "Quieres mucho a [pet_name], tu mascota y personaje favorito."

# game/chapters/4_roomexplore.rpyc:606
translate es hamster_hub4_157b1c09:

    # "Sure, it's not very original, but it gets the job done."
    "Claro, no es muy original, pero cumple su función."

# game/chapters/4_roomexplore.rpyc:607
translate es hamster_hub4_1218ce43:

    # "You can't think of [pet_name] being called anything other than [pet_name]."
    "No puedes imaginar que [pet_name] se llame de otra manera que no sea [pet_name]."

# game/chapters/4_roomexplore.rpyc:611
translate es hamster_hub4_bb04072f:

    # "You didn't have any particular naming plan for [pet_her2]."
    "No tenías ningún plan concreto para ponerle nombre a [pet_she!t]."

# game/chapters/4_roomexplore.rpyc:612
translate es hamster_hub4_48ce966d:

    # "As soon as you saw [pet_her2], you knew the right name."
    "En el momento en que cruzaste mirada con [pet_she!t], sabías el nombre correcto."

# game/chapters/4_roomexplore.rpyc:616
translate es hamster_hub4_e96bb619:

    # "You planned out [pet_her]'s name seven months in advance."
    "Planeaste el nombre de [pet_she!t] con siete meses de anticipación."

# game/chapters/4_roomexplore.rpyc:617
translate es hamster_hub4_c856f278:

    # "You always have been good at being prepared."
    "Siempre se te ha dado bien prepararte."

# game/chapters/4_roomexplore.rpyc:624
translate es hamster_hub4_0a92517d:

    # "You spend the better part of the night cleaning out [pet_name]'s enclosure."
    "Pasas la mayor parte de la noche limpiando el recinto de [pet_name]."

# game/chapters/4_roomexplore.rpyc:625
translate es hamster_hub4_73cd42e1:

    # "You remove all of the bowls, accessories and bedding first, cleaning them as you go, then wash out the enclosure with hot, soapy water."
    "Primero retiras todos los tazones, accesorios y mantas, limpiándolos a medida que avanzas, luego lavas el recinto con agua caliente y jabonosa."

# game/chapters/4_roomexplore.rpyc:626
translate es hamster_hub4_4dce3086:

    # "It's a bit of work, but you're pretty used to it."
    "Es un poco de trabajo, pero ya tienes bastante práctica."

# game/chapters/4_roomexplore.rpyc:627
translate es hamster_hub4_54c8936f:

    # "You also find it quite enjoyable to set up your hamster's enclosure again - there's something fun about it!"
    "También te resulta muy divertido volver a montar la jaula de tu hámster - ¡hay algo divertido al respecto!"

# game/chapters/4_roomexplore.rpyc:646
translate es plant_hub4_c1229c6a:

    # "You give your little sprout a big drink of water."
    "Le das a tu pequeño retoño un buen trago de agua."

# game/chapters/4_roomexplore.rpyc:647
translate es plant_hub4_c5de961c:

    # "Though you don't speak sprout, it seems to say thank you."
    "Aunque no hablas idioma retoño, parece decirte gracias."

# game/chapters/4_roomexplore.rpyc:649
translate es plant_hub4_518e64fd:

    # "Your little sprout has grown some leaves!"
    "¡Tu pequeño retoño ha sacado algunas hojas!"

# game/chapters/4_roomexplore.rpyc:650
translate es plant_hub4_8036dce1:

    # "You can't help but feel proud as you give it a big drink of water."
    "No puedes evitar sentir orgullo mientras le das un gran trago de agua."

# game/chapters/4_roomexplore.rpyc:652
translate es plant_hub4_adaac543:

    # "Even more leaves have appeared now!"
    "¡Aún más hojas han aparecido ahora!"

# game/chapters/4_roomexplore.rpyc:653
translate es plant_hub4_a4970463:

    # "You water it generously and feel excited that, this time, you didn't kill your plant instantly."
    "Lo riegas generosamente y sientes emoción porque, esta vez, no mataste tu planta al instante."

# game/chapters/4_roomexplore.rpyc:655
translate es plant_hub4_2087a70f:

    # "Your little plant is growing healthily!"
    "¡Tu pequeña planta está creciendo saludablemente!"

# game/chapters/4_roomexplore.rpyc:656
translate es plant_hub4_80d209cf:

    # "You give it a big drink of water, excited about its growth."
    "Le das un buen trago de agua, con entusiasmo por su crecimiento."

# game/chapters/4_roomexplore.rpyc:671
translate es plant_hub4_1c953138:

    # "Looking at the soil, you're sure more watering is needed."
    "Al observar el suelo, está claro que se necesita más riego."

# game/chapters/4_roomexplore.rpyc:672
translate es plant_hub4_e3142f64:

    # "I mean, you're no soil expert, but you're certain it shouldn't be dry. At all."
    "Quiero decir, no eres ningún experto en suelos, pero tienes seguridad de que no debería estar seco. En absoluto"

# game/chapters/4_roomexplore.rpyc:673
translate es plant_hub4_b01394aa:

    # "It should be at least a little moist, right?"
    "Debería estar al menos un poco húmedo, ¿verdad?"

# game/chapters/4_roomexplore.rpyc:686
translate es plant_hub4_9447ddf1:

    # "No, a little moist isn't enough."
    "No, un poco húmedo no es suficiente."

# game/chapters/4_roomexplore.rpyc:687
translate es plant_hub4_cf8752e1:

    # "This plant of yours should be in a swamp."
    "Esta planta tuya debe estar en un pantano."

# game/chapters/4_roomexplore.rpyc:688
translate es plant_hub4_f5489103:

    # "Nothing else will do. Nothing else is good enough."
    "Nada más servirá. Nada más es lo suficientemente bueno."

# game/chapters/4_roomexplore.rpyc:689
translate es plant_hub4_fadd62a1:

    # "You water, and water, then water some more."
    "Riegas y riegas, luego riegas un poco más."

# game/chapters/4_roomexplore.rpyc:690
translate es plant_hub4_06dbebee:

    # "It's still not enough."
    "Todavía no es suficiente."

# game/chapters/4_roomexplore.rpyc:692
translate es plant_hub4_a4ceddef:

    # "You only manage to catch yourself when you see your pet staring at you."
    "Solo te das cuenta cuando ves que tu mascota te está mirando fijamente."

# game/chapters/4_roomexplore.rpyc:695
translate es plant_hub4_84fb17ec:

    # "You only manage to catch yourself when you see [pet_name] staring at you."
    "Solo logras darte cuenta cuando ves que [pet_name] te está mirando fijamente."

# game/chapters/4_roomexplore.rpyc:697
translate es plant_hub4_fc0dba82:

    # "Whoops."
    "Uuups."

translate es strings:

    old "1. Shallow, at most."
    new "1. Superficial, como mucho."

    old "1. Curious."
    new "1. Curiosidad"

    old "1. You named [pet_her2] after your favorite character."
    new "1. Le pusiste a [pet_she!t] el nombre de tu personaje favorito."

    old "2. The best you've had in years."
    new "2. Lo mejor que has tenido en años"

    old "2. Attracted?"
    new "2. ¿Atracción?"

    old "2. Leave them alone."
    new "2. Déjarlos en paz."

    old "2. You looked up a list of '100 best animal names'."
    new "2. Buscaste una lista de 'los 100 mejores nombres de animales'."

    old "3. Sleep? What's sleep?"
    new "3. ¿Dormir? ¿Qué es dormir?"

    old "3. Excited."
    new "3. Emoción."

    old "3. It came to you on a whim."
    new "3. Se te ocurrió de repente."

    old "4. You thought about it for ages."
    new "4. Lo pensaste durante mucho tiempo."

    old "Clean out [pet_name]'s enclosure."
    new "Limpiar el recinto de [pet_name]."

    old "Groom [pet_name]."
    new "Asear a [pet_name]."

    old "{i}Rovari{/i}"
    new "{i}Rovari{/i}"

    old "You are akin to the moon, and the stars, and the oceans,"
    new "Eres como la luna, las estrellas y los océanos,"

    old "Boundless and free, shining and deep."
    new "Infinita y libre, brillante y profunda."

    old "You illuminate the darkness and cradle the light,"
    new "Iluminas la oscuridad y acunas la luz,"

    old "You rise and fall and follow your own path through the night."
    new "Te elevas y caes, siguiendo tu propio camino a través de la noche."

    old "With a bottomless heart, you help those in need,"
    new "Con un corazón sin fondo, ayudas a quienes lo necesitan,"

    old "Even when such actions may cause you to bleed."
    new "Incluso cuando esas acciones pueden hacerte sangrar."

    old "So shine brightly, and embrace the unknown,"
    new "Así que brilla con fuerza y abraza lo desconocido,"

    old "For in that magic, you find your own."
    new "Porque en esa magia, encuentras la tuya propia."
