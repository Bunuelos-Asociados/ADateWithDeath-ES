
# game/chapters/1_day.rpyc:36
translate es day1_start_c614cc05:

    # GR "Foolish Mortal, You Shall Evade Me No More!"
    GR "¡Estúpido Mortal, Ya No Me Eludirás Más!"

# game/chapters/1_day.rpyc:37
translate es day1_start_1b087129:

    # GR "I Have Had Enough Of You Fiddling Around In Your Room And Ignoring Me."
    GR "¡Ya He Tenido Suficiente De Que Andes Jugando En Tu Habitación E Ignorándome!"

# game/chapters/1_day.rpyc:38
translate es day1_start_91ccecbe:

    # GR "I Have Come To Reap Your Soul."
    GR "He Venido A Segarte El Alma."

# game/chapters/1_day.rpyc:39
translate es day1_start_67bdcd6b:

    # GR "That Is Far More Important."
    GR "Eso Es Mucho Más Importante."

# game/chapters/1_day.rpyc:40
translate es day1_start_4447c314:

    # GR "Hand It Over Willingly, For I Am Not Here To Play Games."
    GR "Entrégala De Buena Voluntad, Porque No Estoy Aquí Para Jugar."

# game/chapters/1_day.rpyc:41
translate es day1_start_55656cbf:

    # GR "Answer Me At Once!"
    GR "¡Respóndeme Ahora!"

# game/chapters/1_day.rpyc:42
translate es day1_start_4ec1e4b0:

    # GR "...Hello?"
    GR "...¿Hola?"

# game/chapters/1_day.rpyc:43
translate es day1_start_aae5c74e:

    # GR "I See You Wish To Ignore My Demands! Foolish."
    GR "¡Veo Que Deseas Ignorar Mis Exigencias! Idiota."

# game/chapters/1_day.rpyc:44
translate es day1_start_12023737:

    # GR "Incredibly Foolish."
    GR "Increíblemente Idiota."

# game/chapters/1_day.rpyc:45
translate es day1_start_a2195401:

    # GR "Please Respond."
    GR "Por Favor, Responde."

# game/chapters/1_day.rpyc:46
translate es day1_start_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpyc:47
translate es day1_start_c4694050:

    # GR "Does It Not Work After All?"
    GR "¿No Funciona Después De Todo?"

# game/chapters/1_day.rpyc:48
translate es day1_start_d160e261:

    # GR "Well, This Is Quite Embarrassing..."
    GR "Bueno, Esto Es Bastante Vergonzoso..."

# game/chapters/1_day.rpyc:49
translate es day1_start_9324da6b:

    # GR "Testing. Testing 123. Hello? Testing."
    GR "Probando. Probando 123. ¿Hola? Probando."

# game/chapters/1_day.rpyc:50
translate es day1_start_6b7fe2f9:

    # GR "Fuck Me."
    GR "Que Me Jodan."

# game/chapters/1_day.rpyc:53
translate es day1_start_2d44b69f:

    # player "Is that an offer?"
    player "¿Eso es una oferta?"

# game/chapters/1_day.rpyc:54
translate es day1_start_2463ef52:

    # GR "An Offer? An Offer For What?"
    GR "¿Una oferta? ¿Una oferta para qué?"

# game/chapters/1_day.rpyc:57
translate es day1_start_bcd19cdc:

    # player "Uh... if you don't get it, don't worry about it."
    player "Eh... si no lo pillas, no te preocupes."

# game/chapters/1_day.rpyc:58
translate es day1_start_a46c17da:

    # GR "Tell Me At Once!"
    GR "¡Dime De Una Vez!"

# game/chapters/1_day.rpyc:61
translate es day1_start_817aed81:

    # player "An offer for what you said—"
    player "Una oferta por lo que dijiste—"

# game/chapters/1_day.rpyc:64
translate es day1_start_4e9f1c53:

    # player "You know what, nevermind."
    player "¿Sabes qué? Olvídalo."

# game/chapters/1_day.rpyc:65
translate es day1_start_0013230d:

    # GR "No, That Is Not How This Works."
    GR "No, Así No Funciona Esto."

# game/chapters/1_day.rpyc:66
translate es day1_start_eb761f1b:

    # GR "You Cannot Tease Something Then Not Explain What It Means."
    GR "No Puedes Provocar Algo Y Luego No Explicar Qué Significa."

# game/chapters/1_day.rpyc:70
translate es day1_start_9a54bb21:

    # player "Or what?"
    player "¿O qué?"

# game/chapters/1_day.rpyc:71
translate es day1_start_ce076eea:

    # GR "Or... Or..."
    GR "O... O..."

# game/chapters/1_day.rpyc:72
translate es day1_start_af2cca0b:

    # GR "Or I Shall Take Your Soul At Once!"
    GR "¡O Te Arrebataré El Alma De Una Vez!"

# game/chapters/1_day.rpyc:75
translate es day1_start_57f0fb30:

    # player "Isn't that what you threatened me with anyway?"
    player "¿No es eso lo que me amenazaste de todas formas?"

# game/chapters/1_day.rpyc:79
translate es day1_start_9629808c:

    # player "What is this app...?"
    player "¿Qué es esta aplicación...?"

# game/chapters/1_day.rpyc:80
translate es day1_start_2e352636:

    # GR "A Means For Discussing Our Business."
    GR "Un Medio Para Discutir Nuestro Asunto."

# game/chapters/1_day.rpyc:82
translate es day1_start_5010927b:

    # GR "I Created It Myself."
    GR "La Creé Yo Mismo."

# game/chapters/1_day.rpyc:83
translate es day1_start_d497d532:

    # GR "Appreciate The Lengths I Had To Go To For You."
    GR "Aprecia Las Medidas A Las Que Tuve Que Llegar Por Ti."

# game/chapters/1_day.rpyc:86
translate es day1_start_2aa27b3b:

    # player "For... me?"
    player "¿Por... mí?"

# game/chapters/1_day.rpyc:89
translate es day1_start_ac33080e:

    # player "Kinda creepy, ngl..."
    player "Un poco espeluznante, no lo voy a negar..."

# game/chapters/1_day.rpyc:90
translate es day1_start_708d8bf6:

    # GR "Creepy? It Is Not Creepy."
    GR "¿Espeluznante? No Es Espeluznante."

# game/chapters/1_day.rpyc:91
translate es day1_start_70c5a546:

    # GR "Since When Is Going To Some Degree Of Effort Creepy?"
    GR "¿Desde Cuándo Ir A Cierto Grado De Esfuerzo Es Espeluznante?"

# game/chapters/1_day.rpyc:94
translate es day1_start_542c96df:

    # player "Since you installed it on my computer illegally."
    player "Desde que la instalaste en mi ordenador ilegalmente."

# game/chapters/1_day.rpyc:95
translate es day1_start_ec573932:

    # GR "That Is Of Little Consequence."
    GR "Eso Es De Poca Consecuencia."

# game/chapters/1_day.rpyc:96
translate es day1_start_21733e74:

    # GR "Mortal Laws Mean Little To Me."
    GR "Las Leyes Mortales Significan Poco Para Mí."

# game/chapters/1_day.rpyc:100
translate es day1_start_9ebcae9c:

    # player "Well, I guess that does sound like a lot of effort."
    player "Bueno, supongo que eso sí parece mucho esfuerzo."

# game/chapters/1_day.rpyc:103
translate es day1_start_01a2933e:

    # player "Nice job."
    player "Buen trabajo."

# game/chapters/1_day.rpyc:104
translate es day1_start_2c51ffa0:

    # GR "Oh."
    GR "Oh."

# game/chapters/1_day.rpyc:105
translate es day1_start_5e5a7ee8:

    # GR "Thanks."
    GR "Gracias."

# game/chapters/1_day.rpyc:106
translate es day1_start_1dcaa4de:

    # GR "I Didn't Think You Would Appreciate It, Honestly."
    GR "No Pensé Que Lo Apreciarías, Honestamente."

# game/chapters/1_day.rpyc:109
translate es day1_start_e2716c3b:

    # player "But still..."
    player "Pero aún así..."

# game/chapters/1_day.rpyc:114
translate es day1_start_6d768dfd:

    # player "Uh... hello to you, too."
    player "Eh... hola para ti también."

# game/chapters/1_day.rpyc:117
translate es day1_start_63c111a9:

    # player "That was one hell of an introduction."
    player "Esa fue una introducción impactante."

# game/chapters/1_day.rpyc:118
translate es day1_start_5125efe5:

    # GR "About Time You Made Your Way Here. You Have Kept Me Waiting Long Enough."
    GR "Ya Era Hora De Que Llegaras Aquí. Me Has Hecho Esperar Lo Suficiente."

# game/chapters/1_day.rpyc:121
translate es day1_start_f6c68f17:

    # player "Er, what?"
    player "Eh, ¿qué?"

# game/chapters/1_day.rpyc:124
translate es day1_start_4a577e07:

    # player "I don't even know you."
    player "Ni siquiera te conozco."

# game/chapters/1_day.rpyc:125
translate es day1_start_c9369ce4:

    # GR "Are My Words Not Simple Enough For You?"
    GR "¿No Son Mis Palabras Lo Suficientemente Simples Para Ti?"

# game/chapters/1_day.rpyc:126
translate es day1_start_0c2fdd0f:

    # GR "I Have Waited Far Too Long. Far Too Long."
    GR "He Esperado Demasiado Tiempo. Demasiado Tiempo."

# game/chapters/1_day.rpyc:129
translate es day1_start_917ca64f:

    # player "Right...."
    player "Bien...."

# game/chapters/1_day.rpyc:130
translate es day1_start_91d6ace1:

    # GR "Yes, It Is Right."
    GR "Sí, Está Bien."

# game/chapters/1_day.rpyc:131
translate es day1_start_a2648958:

    # GR "Everything I Say Is Always Correct."
    GR "Todo Lo Que Digo Siempre Es Correcto."

# game/chapters/1_day.rpyc:135
translate es day1_start_a40a7902:

    # player "I mean, it was like... five minutes."
    player "Quiero decir, fue como... cinco minutos."

# game/chapters/1_day.rpyc:136
translate es day1_start_7c2f90ac:

    # GR "Five Minutes Too Long!"
    GR "¡Cinco Minutos Demasiado Largos!"

# game/chapters/1_day.rpyc:137
translate es day1_start_557adcae:

    # GR "I Am A Busy Man. A Very Busy Man."
    GR "Soy Un Hombre Ocupado. Un Hombre Muy Ocupado."

# game/chapters/1_day.rpyc:140
translate es day1_start_e03da0f5:

    # player "Well, don't let me take up your precious time!"
    player "Bueno, ¡no me hagas quitarte tu precioso tiempo!"

# game/chapters/1_day.rpyc:143
translate es day1_start_b7d57d74:

    # player "Off you go!"
    player "¡Vete!"

# game/chapters/1_day.rpyc:144
translate es day1_start_230dec51:

    # GR "...."
    GR "...."

# game/chapters/1_day.rpyc:145
translate es day1_start_ff242f17:

    # GR "No."
    GR "No."

# game/chapters/1_day.rpyc:146
translate es day1_start_38aea315:

    # GR "I Cannot Go Until My Job Here Is Fulfilled."
    GR "No Puedo Irme Hasta Que Mi Trabajo Aquí Esté Cumplido."

# game/chapters/1_day.rpyc:150
translate es day1_start_0a0f3fd0:

    # player "You shouldn't have blown up my notifications."
    player "No deberías haber reventado mis notificaciones."

# game/chapters/1_day.rpyc:153
translate es day1_start_aaaafc64:

    # player "That makes me want to ignore you."
    player "Eso me da ganas de ignorarte."

# game/chapters/1_day.rpyc:154
translate es day1_start_fb3dcf92:

    # GR "Then You Should Have Replied Faster."
    GR "Entonces Deberías Haber Respondido Más Rápido."

# game/chapters/1_day.rpyc:157
translate es day1_start_dde0acba:

    # player "Too bad. You were too eager."
    player "Qué pena. Te precipitaste demasiado."

# game/chapters/1_day.rpyc:158
translate es day1_start_71abf724:

    # GR "That Makes No Sense."
    GR "Eso No Tiene Sentido."

# game/chapters/1_day.rpyc:159
translate es day1_start_33d94d44:

    # GR "Why Are Mortals So Confusing?"
    GR "¿Por Qué Son Tan Confusos Los Mortales?"

# game/chapters/1_day.rpyc:160
translate es day1_start_bad0eec8:

    # GR "You Play These Games I Do Not Understand."
    GR "Juegas A Esos Juegos Que Yo No Entiendo."

# game/chapters/1_day.rpyc:163
translate es day1_start_123e2a10:

    # player "There's unspoken rules to texting people."
    player "Hay reglas no escritas para enviarle mensajes a la gente."

# game/chapters/1_day.rpyc:166
translate es day1_start_21c18686:

    # player "Or in this case, messaging them through suspicious apps."
    player "O, en este caso, para enviarles mensajes a través de apps sospechosas."

# game/chapters/1_day.rpyc:167
translate es day1_start_4d770ae6:

    # GR "Well, Can You Please Speak Them?"
    GR "Bueno, ¿Puedes Por Favor Decírlas?"

# game/chapters/1_day.rpyc:170
translate es day1_start_93666768:

    # player "Nope."
    player "Nop."

# game/chapters/1_day.rpyc:171
translate es day1_start_9b1f8a4f:

    # GR "You Are Being Unfair."
    GR "Estás Siendo Injusto."

# game/chapters/1_day.rpyc:173
translate es day1_start_e4a6b9d8:

    # player "Don't spam and don't get mad if you don't get an instant response, mostly."
    player "No hagas spam y no te enfades si no obtienes una respuesta instantánea, mayormente."

# game/chapters/1_day.rpyc:174
translate es day1_start_2c0ce039:

    # GR "I'm Going To Choose To Ignore Those Foolish Rules."
    GR "Voy A Elegir Ignorar Esas Reglas Tontas."

# game/chapters/1_day.rpyc:175
translate es day1_start_38c63bb6:

    # GR "Whoever Made Them Should Be Ashamed."
    GR "Quien Las Haya Creado Debería Sentirse Avergonzado."

# game/chapters/1_day.rpyc:178
translate es day1_start_8f651b1e:

    # player "Sure... anyway..."
    player "Claro... en fin..."

# game/chapters/1_day.rpyc:188
translate es reinstall_1_6b99a6f0:

    # GR "Now That Is Just Plain Rude."
    GR "Eso Ya Es Simplemente Grosero."

# game/chapters/1_day.rpyc:189
translate es reinstall_1_740afe40:

    # GR "The Utter Disrespect... Mortals These Days..."
    GR "El Desprecio Absoluto... Los Mortales Hoy En Día..."

# game/chapters/1_day.rpyc:198
translate es reinstall_2_7928190e:

    # GR "Wait!"
    GR "¡Espera!"

# game/chapters/1_day.rpyc:199
translate es reinstall_2_28c74d24:

    # GR "Do Not Delete It Any More! You Will Cause Serious Damage. And I Will Also Be Very Sad..."
    GR "¡No Lo Borres Más! Causarás Daños Serios. Y Yo También Estaré Muy Triste..."

# game/chapters/1_day.rpyc:208
translate es reinstall_3_049884f8:

    # GR "Please. Stop Deleting My App!"
    GR "Por Favor. ¡Deja De Borrar Mi App!"

# game/chapters/1_day.rpyc:211
translate es reinstall_3_69375c1f:

    # player "Your order total is $641.30."
    player "El total de su pedido es $641.30."

# game/chapters/1_day.rpyc:214
translate es reinstall_3_ca2cb026:

    # player "To finalize your order, please hit 1."
    player "Para finalizar su pedido, por favor presione 1."

# game/chapters/1_day.rpyc:217
translate es reinstall_3_4668d49e:

    # player "To cancel your order, please hit 2."
    player "Para cancelar su pedido, por favor presione 2."

# game/chapters/1_day.rpyc:218
translate es reinstall_3_7360268c:

    # GR "What... I Ordered No Such Thing!"
    GR "¿Qué...! No He Pedido Tal Cosa!"

# game/chapters/1_day.rpyc:219
translate es reinstall_3_65ff3087:

    # GR "2. 2!"
    GR "¡2. 2!"

# game/chapters/1_day.rpyc:222
translate es reinstall_3_9b731788:

    # player "Thank you for your purchase. Your order is now being finalized."
    player "Gracias por su compra. Su pedido ahora está siendo finalizado."

# game/chapters/1_day.rpyc:223
translate es reinstall_3_e93f5105:

    # GR "No! I Have Not Clicked That Response, You Stupid Machine!"
    GR "¡No! ¡No He Pulsado Esa Respuesta, Estúpida Máquina!"

# game/chapters/1_day.rpyc:226
translate es reinstall_3_f6b157a9:

    # player "To order again, please select YES."
    player "Para realizar un nuevo pedido, por favor seleccione SI."

# game/chapters/1_day.rpyc:227
translate es reinstall_3_978e41a1:

    # GR "Why Is There Only One Option?!"
    GR "¿Por Qué Solo Hay Una Opción?!"

# game/chapters/1_day.rpyc:228
translate es reinstall_3_5adf8d3a:

    # GR "No. No, I Do Not Want To Order Again!"
    GR "¡No. No Quiero Pedir De Nuevo!"

# game/chapters/1_day.rpyc:231
translate es reinstall_3_f6b157a9_1:

    # player "To order again, please select YES."
    player "Para realizar un nuevo pedido, por favor seleccione SI."

# game/chapters/1_day.rpyc:232
translate es reinstall_3_c8467448:

    # GR "No, Thank You. I Refuse."
    GR "No, Gracias. Me Niego."

# game/chapters/1_day.rpyc:235
translate es reinstall_3_f6b157a9_2:

    # player "To order again, please select YES."
    player "Para realizar un nuevo pedido, por favor seleccione SI."

# game/chapters/1_day.rpyc:236
translate es reinstall_3_9937af4f:

    # GR "Yes."
    GR "Si."

# game/chapters/1_day.rpyc:239
translate es reinstall_3_48bb00db:

    # player "Thank you for your order. Your account has been charged a total of $3491.60."
    player "Gracias por su pedido. Su cuenta ha sido cargada con un total de $3491.60."

# game/chapters/1_day.rpyc:240
translate es reinstall_3_dee96f95:

    # GR "Holy Fuck."
    GR "Maldita sea."

# game/chapters/1_day.rpyc:241
translate es reinstall_3_ff242f17:

    # GR "No."
    GR "No."

# game/chapters/1_day.rpyc:242
translate es reinstall_3_64607f72:

    # GR "Please, No!"
    GR "Por Favor, ¡No!"

# game/chapters/1_day.rpyc:245
translate es reinstall_3_778b7e57:

    # player "Idiot."
    player "Idiota."

# game/chapters/1_day.rpyc:247
translate es reinstall_3_60078eb9:

    # player "You're a moron."
    player "Eres un imbécil."

# game/chapters/1_day.rpyc:249
translate es reinstall_3_241afdf4:

    # GR "Mortal!"
    GR "¡Mortal!"

# game/chapters/1_day.rpyc:250
translate es reinstall_3_11d483d2:

    # GR "How Dare You Fool Me In Such A Manner... How Unbecoming Of One Such As Me..."
    GR "Cómo Te Atreves A Engañarme De Tal Manera... Qué Poco Propio De Alguien Como Yo..."

# game/chapters/1_day.rpyc:254
translate es reinstall_3_2679f73b:

    # player "It's not my fault you're so easily fooled."
    player "No es mi culpa que te dejes engañar tan fácilmente."

# game/chapters/1_day.rpyc:260
translate es day1_afterfirstchoice_ad41d889:

    # player "Seriously, is this a virus or something...?"
    player "En serio, ¿esto es un virus o algo...?"

# game/chapters/1_day.rpyc:261
translate es day1_afterfirstchoice_1326653e:

    # GR "A Virus? No, Do Not Be Absurd."
    GR "¿Un Virus? No, Que Absurdo."

# game/chapters/1_day.rpyc:262
translate es day1_afterfirstchoice_c0b9df2f:

    # GR "This Is An Application That I Have Created."
    GR "Esta Es Una Aplicación Que He Creado."

# game/chapters/1_day.rpyc:264
translate es day1_afterfirstchoice_4fe91091:

    # GR "Like I Already Told You."
    GR "Como Ya Te Lo Dije."

# game/chapters/1_day.rpyc:265
translate es day1_afterfirstchoice_a0107c4d:

    # GR "Please Pay More Attention."
    GR "Por Favor, Presta Más Atención."

# game/chapters/1_day.rpyc:268
translate es day1_afterfirstchoice_82b4ab40:

    # player "Okay, but..."
    player "Bueno, pero..."

# game/chapters/1_day.rpyc:273
translate es day1_afterfirstchoice_c237b9ba:

    # player "...?"
    player "...?"

# game/chapters/1_day.rpyc:276
translate es day1_afterfirstchoice_32e17079:

    # player "For...?"
    player "¿Para...?"

# game/chapters/1_day.rpyc:277
translate es day1_afterfirstchoice_b43e5c33:

    # GR "Messaging You."
    GR "¿Enviarte mensajes?"

# game/chapters/1_day.rpyc:280
translate es day1_afterfirstchoice_2920d744:

    # player "Why?"
    player "¿Por qué?"

# game/chapters/1_day.rpyc:283
translate es day1_afterfirstchoice_abd9bf45:

    # player "I don't even know who you are."
    player "Ni siquiera sé quién eres."

# game/chapters/1_day.rpyc:286
translate es day1_afterfirstchoice_be6b41ba:

    # player "It's a little strange to message a random [girl] out of nowhere."
    player "Es un poco raro escribirle a un[girl!t] al azar de la nada."

# game/chapters/1_day.rpyc:287
translate es day1_afterfirstchoice_a4144670:

    # GR "Random? There Is No Element Of 'Randomness' At Play Here."
    GR "¿Al Azar? No Hay Ningún Elemento De 'Aleatoriedad' En Juego Aquí."

# game/chapters/1_day.rpyc:288
translate es day1_afterfirstchoice_a7983f34:

    # GR "You Are Not Some 'Random' [Girl]. You Are A Very Specific [Girl]."
    GR "Tú No Eres Alguien 'Al Azar'. Eres Un[Girl!t] Muy Especial"

# game/chapters/1_day.rpyc:291
translate es day1_afterfirstchoice_c46595ec:

    # player "Okay, getting creepier."
    player "Vale, esto se pone más raro."

# game/chapters/1_day.rpyc:294
translate es day1_afterfirstchoice_1ad5758e:

    # player "Do I know you from somewhere, then?"
    player "¿Te conozco de algún lado, entonces?"

# game/chapters/1_day.rpyc:297
translate es day1_afterfirstchoice_decdfd5d:

    # player "Wait, are you a bot?"
    player "Espera, ¿eres un bot?"

# game/chapters/1_day.rpyc:298
translate es day1_afterfirstchoice_19f0567e:

    # GR "A What?"
    GR "¿Un Qué?"

# game/chapters/1_day.rpyc:301
translate es day1_afterfirstchoice_044cc49f:

    # player "You know. A bot."
    player "Ya sabes. Un bot."

# game/chapters/1_day.rpyc:304
translate es day1_afterfirstchoice_f90c139b:

    # player "Beep beep."
    player "Bip bip."

# game/chapters/1_day.rpyc:305
translate es day1_afterfirstchoice_d4a6823c:

    # GR "A Robot?"
    GR "¿Un Robot?"

# game/chapters/1_day.rpyc:306
translate es day1_afterfirstchoice_1dbae1d4:

    # GR "Don't Be Absurd."
    GR "Que Absurdo."

# game/chapters/1_day.rpyc:307
translate es day1_afterfirstchoice_1faf8eab:

    # GR "Robots Anywhere Near My Level Of Charisma, Charm And Good Looks Are Not Possible."
    GR "Robots Cerca De Mi Nivel De Carisma, Encanto Y Buena Apariencia No Son Posibles."

# game/chapters/1_day.rpyc:310
translate es day1_afterfirstchoice_959233b3:

    # player "Sounds like something a bot would say."
    player "Suena como algo que diría un bot."

# game/chapters/1_day.rpyc:311
translate es day1_afterfirstchoice_9849172b:

    # GR "I Am Not A Robot!"
    GR "¡No Soy Un Robot!"

# game/chapters/1_day.rpyc:314
translate es day1_afterfirstchoice_580d4153:

    # player "Robot say huh?"
    player "¿El Robot dice eh?"

# game/chapters/1_day.rpyc:315
translate es day1_afterfirstchoice_ce06d0b6:

    # GR "Huh?"
    GR "¿Eh?"

# game/chapters/1_day.rpyc:318
translate es day1_afterfirstchoice_81aa9d54:

    # player "Gotcha."
    player "Te Atrapé."

# game/chapters/1_day.rpyc:319
translate es day1_afterfirstchoice_230dec51:

    # GR "...."
    GR "...."

# game/chapters/1_day.rpyc:320
translate es day1_afterfirstchoice_cb8ce665:

    # GR "I Have Not Come Here To Play Your Games, Mortal."
    GR "No He Venido Aquí Para Jugar Tus Juegos, Mortal."

# game/chapters/1_day.rpyc:323
translate es day1_afterfirstchoice_63730f27:

    # player "Why are you here then?"
    player "¿Entonces por qué estás aquí?"

# game/chapters/1_day.rpyc:326
translate es day1_afterfirstchoice_064e0e51:

    # GR "I Told You, I Have Come To Reap Your Soul!"
    GR "Te Lo Dije, ¡He Venido A Segar Tu Alma!"

# game/chapters/1_day.rpyc:330
translate es day1_afterfirstchoice_735ff648:

    # player "Yeah, you said that once or twice..."
    player "Sí, eso lo dijiste una o dos veces..."

# game/chapters/1_day.rpyc:333
translate es day1_afterfirstchoice_1f233525:

    # player "Is this a call for help?"
    player "¿Es esto una llamada de ayuda?"

# game/chapters/1_day.rpyc:335
translate es day1_afterfirstchoice_45c35ef6:

    # player "I'm actually starting to feel sorry for you..."
    player "De verdad que estoy empezando a sentir lástima por ti..."

# game/chapters/1_day.rpyc:338
translate es day1_afterfirstchoice_56967313:

    # player "Wait, what did you come here for?"
    player "Espera, ¿para qué viniste aquí?"

# game/chapters/1_day.rpyc:339
translate es day1_afterfirstchoice_6d91d452:

    # GR "To... To Reap Your Soul!"
    GR "¡Para... Para Segar Tu Alma!"

# game/chapters/1_day.rpyc:342
translate es day1_afterfirstchoice_4b0a89fa:

    # player "Sorry, one more time? You're cutting out."
    player "Perdón, ¿otra vez? Se corta la señal."

# game/chapters/1_day.rpyc:343
translate es day1_afterfirstchoice_fd4fcff0:

    # GR "I Said To Reap Your Soul!"
    GR "¡Dije Que Venía A Segar Tu Alma!"

# game/chapters/1_day.rpyc:346
translate es day1_afterfirstchoice_2cc2d9d3:

    # player "Man, really bad reception here."
    player "Hombre, la recepción aquí es realmente mala."

# game/chapters/1_day.rpyc:349
translate es day1_afterfirstchoice_a6db9b1c:

    # player "Can't make out what you're saying at all."
    player "No entiendo nada de lo que dices."

# game/chapters/1_day.rpyc:353
translate es day1_afterfirstchoice_14a8f01b:

    # GR "Do Not Belittle Me!"
    GR "¡No Me Subestimes!"

# game/chapters/1_day.rpyc:354
translate es day1_afterfirstchoice_af8202be:

    # GR "I Am Coming For What Is Owed To Me, That Is All."
    GR "Vengo Por Lo Que Se Me Debe, Eso Es Todo."

# game/chapters/1_day.rpyc:355
translate es day1_afterfirstchoice_7274de47:

    # GR "It Would Do You Well To Not Get In My Way."
    GR "Te Convendría No Ponerte En Mi Camino."

# game/chapters/1_day.rpyc:358
translate es day1_afterfirstchoice_4f0ac427:

    # player "Are you trying to threaten me or something?"
    player "¿Intentas amenazarme o algo?"

# game/chapters/1_day.rpyc:359
translate es day1_afterfirstchoice_713c064d:

    # GR "Do You Feel Threatened By Me?"
    GR "¿Te Sientes Amenazado Por Mí?"

# game/chapters/1_day.rpyc:360
translate es day1_afterfirstchoice_06788dab:

    # GR "If So, Then I Am Doing My Job Correctly. This Bodes Well."
    GR "Si Es Así, Entonces Estoy Haciendo Bien Mi Trabajo. Es Una Buena Señal."

# game/chapters/1_day.rpyc:363
translate es day1_afterfirstchoice_16f2c812:

    # player "I don't owe you anything."
    player "No te debo nada."

# game/chapters/1_day.rpyc:364
translate es day1_afterfirstchoice_75ccc57e:

    # GR "You Do. You Just Do Not Know It."
    GR "Sí Lo Haces. Simplemente No Lo Sabes."

# game/chapters/1_day.rpyc:365
translate es day1_afterfirstchoice_0ae0aac1:

    # GR "It Is My Job To Know It For You."
    GR "Es Mi Trabajo Saberlo Por Ti."

# game/chapters/1_day.rpyc:366
translate es day1_afterfirstchoice_ba55d7c6:

    # GR "There Is No Need To Be Afraid. It Is A Natural Process."
    GR "No Hay Necesidad De Temer. Es Un Proceso Natural."

# game/chapters/1_day.rpyc:370
translate es day1_afterfirstchoice_61b4f8fe:

    # player "Uh, and this job is...?"
    player "Eh, ¿y este trabajo es...?"

# game/chapters/1_day.rpyc:371
translate es day1_afterfirstchoice_6f3d4279:

    # GR "Thank You For Finally Asking."
    GR "Gracias Por Finalmente Preguntar."

# game/chapters/1_day.rpyc:372
translate es day1_afterfirstchoice_fef248cf:

    # GR "Beg Me To Tell You."
    GR "Suplícame Que Te Lo Cuente."

# game/chapters/1_day.rpyc:375
translate es day1_afterfirstchoice_c1736e0b:

    # player "I don't care that much..."
    player "No me importa tanto..."

# game/chapters/1_day.rpyc:376
translate es day1_afterfirstchoice_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpyc:377
translate es day1_afterfirstchoice_fbfdf365:

    # GR "Really?"
    GR "¿De Verdad?"

# game/chapters/1_day.rpyc:378
translate es day1_afterfirstchoice_0e8e60bf:

    # GR "Oh..."
    GR "Oh..."

# game/chapters/1_day.rpyc:381
translate es day1_afterfirstchoice_a40e5258:

    # player "...Fine, please tell me."
    player "...Está bien, por favor dime."

# game/chapters/1_day.rpyc:384
translate es day1_afterfirstchoice_eb67bac3:

    # player "Now I feel bad. You can tell me."
    player "Ahora me siento mal. Puedes decírmelo."

# game/chapters/1_day.rpyc:387
translate es day1_afterfirstchoice_8fa378d0:

    # player "Pretty please?"
    player "¿Por favorcito?"

# game/chapters/1_day.rpyc:388
translate es day1_afterfirstchoice_7772a27d_1:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpyc:389
translate es day1_afterfirstchoice_fc20dd93:

    # GR "To Be Honest, I Wasn't Expecting You To Actually..."
    GR "Para Ser Honesto, No Esperaba Que Realmente..."

# game/chapters/1_day.rpyc:390
translate es day1_afterfirstchoice_8e2543be:

    # GR "Ahem."
    GR "Ejem."

# game/chapters/1_day.rpyc:394
translate es day1_afterfirstchoice_a689c120:

    # player "Yeah, I'm terrified."
    player "Sí, tengo mucho miedo."

# game/chapters/1_day.rpyc:395
translate es day1_afterfirstchoice_da91a2a4:

    # GR "Really? Hah! Good. Your Instincts Serve You Well."
    GR "¿De Verdad? ¡Ja! Bien. Tus Instintos Te Sirven Bien."

# game/chapters/1_day.rpyc:398
translate es day1_afterfirstchoice_3b69f14e:

    # player "Nah, not really. I'm just messing with you."
    player "Nah, no realmente. Solo te estoy tomando el pelo."

# game/chapters/1_day.rpyc:400
translate es day1_afterfirstchoice_815b6f08:

    # player "Yep. Really really scared atm."
    player "Síp. Realmente tengo mucho miedo en este momento."

# game/chapters/1_day.rpyc:403
translate es day1_afterfirstchoice_bd1732d3:

    # player ":D"
    player ":D"

# game/chapters/1_day.rpyc:405
translate es day1_afterfirstchoice_45430097:

    # player ":3"
    player ":3"

# game/chapters/1_day.rpyc:407
translate es day1_afterfirstchoice_7772a27d_2:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpyc:408
translate es day1_afterfirstchoice_df7bd05e:

    # GR "You Will Not Mess With Me Any Longer When You Find Out My True Form."
    GR "Ya No Te Burlarás De Mí Cuando Descubras Mi Verdadera Forma."

# game/chapters/1_day.rpyc:409
translate es day1_afterfirstchoice_4573c435:

    # GR "You Will Cower In Fear. You Will Beg Me To Release You."
    GR "Te Encogerás De Miedo. Me Suplicarás Que Te Libere."

# game/chapters/1_day.rpyc:412
translate es day1_afterfirstchoice_4b4bad2f:

    # player "Uh huh. Sure I will."
    player "Eh ajá. Seguro que sí."

# game/chapters/1_day.rpyc:415
translate es day1_afterfirstchoice_02fae16c:

    # player "And this true form is...?"
    player "¿Y esa verdadera forma es...?"

# game/chapters/1_day.rpyc:418
translate es day1_afterfirstchoice_30e047df:

    # GR "I Am The Grim Reaper, And I Have Come To Claim Your Soul."
    GR "Soy La Parca, Y He Venido A Reclamar Tu Alma."

# game/chapters/1_day.rpyc:421
translate es day1_afterfirstchoice_f8495abb:

    # player "Right."
    player "Cierto."

# game/chapters/1_day.rpyc:424
translate es day1_afterfirstchoice_6544652c:

    # player "Riiiight."
    player "Cieeeerto."

# game/chapters/1_day.rpyc:427
translate es day1_afterfirstchoice_f622fe25:

    # player "Riiiiiiiiiight."
    player "Cieeeeeeeeeerto."

# game/chapters/1_day.rpyc:431
translate es day1_afterfirstchoice_b0604f14:

    # player "Cool."
    player "Genial."

# game/chapters/1_day.rpyc:434
translate es day1_afterfirstchoice_710759d4:

    # player "Very normal."
    player "Muy normal."

# game/chapters/1_day.rpyc:437
translate es day1_afterfirstchoice_652e6662:

    # player "Totally reasonable thing to say to someone."
    player "Algo totalmente razonable para decirle a alguien."

# game/chapters/1_day.rpyc:438
translate es day1_afterfirstchoice_2a86e101:

    # GR "You Make It Sound Unreasonable."
    GR "Haces Que Suene Irrazonable."

# game/chapters/1_day.rpyc:439
translate es day1_afterfirstchoice_a5b65982:

    # GR "Why?"
    GR "¿Por Qué?"

# game/chapters/1_day.rpyc:442
translate es day1_afterfirstchoice_e70a0812:

    # player "Um."
    player "Um."

# game/chapters/1_day.rpyc:445
translate es day1_afterfirstchoice_d03ac851:

    # player "Maybe because it is?"
    player "¿Quizás porque lo es?"

# game/chapters/1_day.rpyc:448
translate es day1_afterfirstchoice_505fe973:

    # player "I don't give my soul to just anyone, you know."
    player "No entrego mi alma a cualquiera, ¿Sabes?"

# game/chapters/1_day.rpyc:449
translate es day1_afterfirstchoice_9fe7d46a:

    # GR "Fortunately, I Am Not Just Anyone."
    GR "Afortunadamente, No Soy Cualquiera."

# game/chapters/1_day.rpyc:450
translate es day1_afterfirstchoice_399e8990:

    # GR "I Am The Grim Reaper."
    GR "Soy La Parca."

# game/chapters/1_day.rpyc:451
translate es day1_afterfirstchoice_74158f33:

    # GR "Pulling The Soul From Your Body And Leaving You An Empty Husk Is Literally In My Job Description."
    GR "Arrancar El Alma De Tu Cuerpo Y Dejarte Un Cascarón Vacío Es Literal Mi Descripción De Trabajo."

# game/chapters/1_day.rpyc:454
translate es day1_afterfirstchoice_27390844:

    # player "I had that in my job description once, too."
    player "Yo también tuve eso en mi descripción de trabajo una vez."

# game/chapters/1_day.rpyc:455
translate es day1_afterfirstchoice_fbfdf365_1:

    # GR "Really?"
    GR "¿De Verdad?"

# game/chapters/1_day.rpyc:456
translate es day1_afterfirstchoice_0ab50158:

    # GR "You Were A Grim Reaper?"
    GR "¿Fuiste La Parca?"

# game/chapters/1_day.rpyc:459
translate es day1_afterfirstchoice_b74020bd:

    # player "No, I just worked retail."
    player "No, Yo solo trabajaba en comercio minorista."

# game/chapters/1_day.rpyc:460
translate es day1_afterfirstchoice_2c51ffa0:

    # GR "Oh."
    GR "Oh."

# game/chapters/1_day.rpyc:461
translate es day1_afterfirstchoice_662bc54d:

    # GR "I Hadn't Realized Mortals Also Dealt In Souls."
    GR "No Me Había Dado Cuenta De Que Los Mortales También Tratan Con Almas."

# game/chapters/1_day.rpyc:462
translate es day1_afterfirstchoice_ce4cae60:

    # GR "But That Is Beside The Point."
    GR "Pero Eso Es Irrelevante."

# game/chapters/1_day.rpyc:463
translate es day1_afterfirstchoice_fe5f39f8:

    # GR "Your Soul."
    GR "Tu Alma."

# game/chapters/1_day.rpyc:466
translate es day1_afterfirstchoice_c0afbf2b:

    # player "ngl not the weirdest scam someone's tried on me."
    player "No voy a mentir, no es la estafa más rara que alguien me haya intentado hacer."

# game/chapters/1_day.rpyc:469
translate es day1_afterfirstchoice_1cc1421c:

    # player "There was this one time when I got a message from a 'time-traveling astronaut'."
    player "Hubo una vez en que recibí un mensaje de un 'Astronauta viajero del Tiempo'."

# game/chapters/1_day.rpyc:472
translate es day1_afterfirstchoice_ee1a2c16:

    # player "Said I had to wire them money to preserve the space-time continuum."
    player "Decía que tenía que transferirles dinero para preservar el continuo espacio-tiempo."

# game/chapters/1_day.rpyc:474
translate es day1_afterfirstchoice_0e5914a0:

    # GR "Uh... Did You Send Them Money?"
    GR "Eh... ¿Les Enviaste Dinero?"

# game/chapters/1_day.rpyc:475
translate es day1_afterfirstchoice_c00f17d0:

    # GR "That Sounds Important..."
    GR "Eso Suena Importante..."

# game/chapters/1_day.rpyc:478
translate es day1_afterfirstchoice_59e64330:

    # player "Somehow I'm not surprised that you would fall for that."
    player "De alguna manera no me sorprende que hayas caído en eso."

# game/chapters/1_day.rpyc:479
translate es day1_afterfirstchoice_7dccc9fe:

    # GR "What? It Was A Lie?"
    GR "¿Qué? ¿Era Una Mentira?"

# game/chapters/1_day.rpyc:482
translate es day1_afterfirstchoice_e7564ac0:

    # player "Well, I hope it was..."
    player "Bueno, Eso espero..."

# game/chapters/1_day.rpyc:483
translate es day1_afterfirstchoice_e69eb3a7:

    # GR "Now You're Making Me Worry. Time Is Not Something To Mess With."
    GR "Ahora Me Estás Haciendo Preocupar. El Tiempo No Es Algo Con Lo Que Se Deba Jugar."

# game/chapters/1_day.rpyc:486
translate es day1_afterfirstchoice_53cffdf2:

    # player "I'll keep that in mind."
    player "Lo tendré en cuenta."

# game/chapters/1_day.rpyc:487
translate es day1_afterfirstchoice_6d708bc8:

    # GR "Good. Even A Mortal Must Realize That Playing With Time Rarely Leads To Happy Results."
    GR "Bien. Incluso Un Mortal Debe Darse Cuenta De Que Jugar Con El Tiempo Rara Vez Conduce A Resultados Felices."

# game/chapters/1_day.rpyc:488
translate es day1_afterfirstchoice_067b5ec4:

    # GR "But, You're Trying To Distract Me, Aren't You?"
    GR "Pero, Estás Intentando Distraerme, ¿Verdad?"

# game/chapters/1_day.rpyc:489
translate es day1_afterfirstchoice_83533abf:

    # GR "Your Soul, Now."
    GR "Tu Alma, Ahora."

# game/chapters/1_day.rpyc:491
translate es day1_afterfirstchoice_1ecbfcbc:

    # player "You're kind of babygirl coded."
    player "Tienes un aire de Babygirl."

# game/chapters/1_day.rpyc:492
translate es day1_afterfirstchoice_eed7aeef:

    # GR "What? What Does That... What?"
    GR "¿Qué? ¿Qué Significa Eso... Qué?"

# game/chapters/1_day.rpyc:493
translate es day1_afterfirstchoice_c9d052b2:

    # GR "Stop Trying To Distract Me From The Matter At Hand!"
    GR "¡Deja De Intentar Distraerme Del Asunto En Mano!"

# game/chapters/1_day.rpyc:494
translate es day1_afterfirstchoice_fe5f39f8_1:

    # GR "Your Soul."
    GR "Tu Alma."

# game/chapters/1_day.rpyc:496
translate es day1_afterfirstchoice_b3e59447:

    # GR "You Will Hand It Over?"
    GR "¿La Entregarás?"

# game/chapters/1_day.rpyc:499
translate es day1_afterfirstchoice_77b4784a:

    # player "I have to ask, is this a roleplay?"
    player "Tengo una pregunta, ¿Esto es un roleplay?"

# game/chapters/1_day.rpyc:500
translate es day1_afterfirstchoice_103605ad:

    # GR "A 'Roleplay'? What Is A 'Roleplay'?"
    GR "¿Un 'Roleplay'? ¿Qué Es Un 'Roleplay'?"

# game/chapters/1_day.rpyc:503
translate es day1_afterfirstchoice_5f4ffbb2:

    # player "Like, you're pretending to be the grim reaper..."
    player "Como si estuvieras fingiendo ser la parca..."

# game/chapters/1_day.rpyc:506
translate es day1_afterfirstchoice_568fcef3:

    # player "And you want me to be..."
    player "Y quieres que yo sea..."

# game/chapters/1_day.rpyc:509
translate es day1_afterfirstchoice_55ba2e8f:

    # player "Your enemies-to-lovers sweetheart?"
    player "¿Tu pareja de 'enemies-to-lovers'?"

# game/chapters/1_day.rpyc:511
translate es day1_afterfirstchoice_8756a3a3:

    # player "A pizza delivery [woman]."
    player "Un[woman!t] que Reparte Pizzas."

# game/chapters/1_day.rpyc:513
translate es day1_afterfirstchoice_352ba6a5:

    # player "Your mortal enemy. Mwhahahaha."
    player "Tu enemigo mortal. Mwhahahaha."

# game/chapters/1_day.rpyc:514
translate es day1_afterfirstchoice_d7eadc64:

    # GR "What? No. I Am The Grim Reaper. This Is No Game Of Make Believe."
    GR "¿Qué? No. Soy La Parca. Esto No Es Un Juego De Ficción."

# game/chapters/1_day.rpyc:515
translate es day1_afterfirstchoice_e9dc5df8:

    # GR "This Is A Matter Of Utmost Seriousness."
    GR "Esto Es Un Asunto De La Máxima Seriedad."

# game/chapters/1_day.rpyc:518
translate es day1_afterfirstchoice_d9d06db6:

    # player "That's a shame."
    player "Qué lástima."

# game/chapters/1_day.rpyc:521
translate es day1_afterfirstchoice_d4916534:

    # player "I used to be one hell of a roleplayer, back in the day."
    player "Solía ser una máquina del roleplay, en mis tiempos."

# game/chapters/1_day.rpyc:522
translate es day1_afterfirstchoice_47edd3fa:

    # GR "I'm Sure You Were..."
    GR "Seguro Que Lo Fuiste..."

# game/chapters/1_day.rpyc:525
translate es day1_afterfirstchoice_47dbf850:

    # player "It's a little hard to take you seriously."
    player "Es un poco difícil tomarte en serio."

# game/chapters/1_day.rpyc:526
translate es day1_afterfirstchoice_a5b65982_1:

    # GR "Why?"
    GR "¿Por Qué?"

# game/chapters/1_day.rpyc:529
translate es day1_afterfirstchoice_b2438c3c:

    # player "Maybe because you're literally a stranger on the internet?"
    player "Quizá porque literalmente eres un desconocido de internet?"

# game/chapters/1_day.rpyc:530
translate es day1_afterfirstchoice_493ae1f1:

    # GR "Everyone Is A Stranger Before You Meet Them."
    GR "Todos Son Desconocidos Antes De Que Los Conozcas."

# game/chapters/1_day.rpyc:533
translate es day1_afterfirstchoice_51c29c4b:

    # player "But most people don't claim to be a mythological creature."
    player "Pero la mayoría de la gente no afirma ser una criatura mitológica."

# game/chapters/1_day.rpyc:534
translate es day1_afterfirstchoice_57c3340b:

    # GR "Because They Are Not. I Am."
    GR "Porque Ellos No Lo Son. Yo Lo Soy."

# game/chapters/1_day.rpyc:539
translate es day1_afterfirstchoice_ba7fafde:

    # player "Are you... okay?"
    player "¿Estás... bien?"

# game/chapters/1_day.rpyc:540
translate es day1_afterfirstchoice_ec0f9d4b:

    # GR "Okay? Why Do You Want To Know My Condition?"
    GR "¿Bien? ¿Por Qué Quieres Saber Sobre Mi Estado?"

# game/chapters/1_day.rpyc:543
translate es day1_afterfirstchoice_f651aa8c:

    # player "Well, you're spouting all of this nonsense."
    player "Bueno, estás diciendo todas estas tonterías."

# game/chapters/1_day.rpyc:546
translate es day1_afterfirstchoice_26d99d1a:

    # player "I thought it might be a call for help...?"
    player "Pensé que podría ser un llamado de auxilio...?"

# game/chapters/1_day.rpyc:547
translate es day1_afterfirstchoice_fd47c6ed:

    # GR "You Can Help Me By Giving Up Your Soul Already."
    GR "Puedes Ayudarme Entregando Ya Tu Alma."

# game/chapters/1_day.rpyc:551
translate es day1_afterfirstchoice_9511dbed:

    # player "Mmm, not really a fan..."
    player "Mmm, no soy muy fan..."

# game/chapters/1_day.rpyc:552
translate es day1_afterfirstchoice_992d6061:

    # GR "What? That Doesn't Matter. All That Matters Is That You Give It Over."
    GR "¿Qué? Eso No Importa. Lo Único Que Importa Es Que La Entregues."

# game/chapters/1_day.rpyc:555
translate es day1_afterfirstchoice_4ad10f17:

    # player "And if I said no?"
    player "¿Y si digo que no?"

# game/chapters/1_day.rpyc:556
translate es day1_afterfirstchoice_631eb0e5:

    # GR "I Would Laugh At One Who Would Defy Me So Openly."
    GR "Me Reiría De Alguien Que Me Desafiara Tan Abiertamente."

# game/chapters/1_day.rpyc:559
translate es day1_afterfirstchoice_78c5fdf3:

    # player "Being laughed at, or losing my soul..."
    player "Que se rían de mí o perder mi alma..."

# game/chapters/1_day.rpyc:562
translate es day1_afterfirstchoice_cda30e23:

    # player "Tough decision."
    player "Difícil decisión."

# game/chapters/1_day.rpyc:565
translate es day1_afterfirstchoice_e7002d63:

    # player "You know..."
    player "Sabes..."

# game/chapters/1_day.rpyc:570
translate es day1_afterfirstchoice_f5e66196:

    # player "Is this one of those scams?"
    player "¿Es esta una de esas estafas?"

# game/chapters/1_day.rpyc:571
translate es day1_afterfirstchoice_4f0c1452:

    # GR "...Scams?"
    GR "...¿Estafas?"

# game/chapters/1_day.rpyc:573
translate es day1_afterfirstchoice_44b375ff:

    # GR "Are We Really Back To Talking About Scams Again?"
    GR "¿De Verdad Volvemos A Hablar De Estafas Otra Vez?"

# game/chapters/1_day.rpyc:574
translate es day1_afterfirstchoice_9b3fa767:

    # GR "I'm Not A Time-Traveling Astronaut. I Am Simply A Grim Reaper With A Job."
    GR "No Soy Un Astronauta Que Viaja En El Tiempo. Simplemente Soy Una Parca Con Un Trabajo."

# game/chapters/1_day.rpyc:575
translate es day1_afterfirstchoice_2893e221:

    # GR "Go On, Then. Tell Me What My 'Scam' Is."
    GR "Venga, Entonces. Dime Cuál Es Mi 'Estafa'."

# game/chapters/1_day.rpyc:578
translate es day1_afterfirstchoice_f456c163:

    # player "{i}You owe $5000 in taxes... payment taken in gift cards.{/i}"
    player "{i}Debes $5000 en impuestos... pago aceptado en tarjetas de regalo.{/i}"

# game/chapters/1_day.rpyc:579
translate es day1_afterfirstchoice_99a09e69:

    # GR "I Owe You Nothing. I Pay My Taxes."
    GR "No Te Debo Nada. Pago Mis Impuestos."

# game/chapters/1_day.rpyc:582
translate es day1_afterfirstchoice_990d0494:

    # player "No, dumbo, that's the scam."
    player "No, idiota, esa es la estafa."

# game/chapters/1_day.rpyc:583
translate es day1_afterfirstchoice_31c4b3ec:

    # GR "So You're A Scammer Now?"
    GR "¿Así Que Ahora Eres Un Estafador?"

# game/chapters/1_day.rpyc:586
translate es day1_afterfirstchoice_189f1d4b:

    # player "If I was, I'd be rich off you alone."
    player "Si lo fuera, tendría millones solo contigo."

# game/chapters/1_day.rpyc:587
translate es day1_afterfirstchoice_69b49e8c:

    # GR "You Could Not Scam Me That Easily."
    GR "No Podrías Estafarme Tan Fácilmente."

# game/chapters/1_day.rpyc:590
translate es day1_afterfirstchoice_48a0b670:

    # player "But I was serious about your taxes."
    player "Pero hablaba en serio sobre tus impuestos."

# game/chapters/1_day.rpyc:593
translate es day1_afterfirstchoice_6f742096:

    # player "The tax agency sent me."
    player "La agencia tributaria me envió."

# game/chapters/1_day.rpyc:596
translate es day1_afterfirstchoice_51ca90e3:

    # player "Send me your cc number and the three whacky numbers on the back, quick."
    player "Envíame tu número de tarjeta de crédito Y los tres números raros de atrás, rápido."

# game/chapters/1_day.rpyc:599
translate es day1_afterfirstchoice_9bbafef8:

    # player "Or you're going to prison, buddy."
    player "O vas a ir a la cárcel, amigo."

# game/chapters/1_day.rpyc:600
translate es day1_afterfirstchoice_b7c0240b:

    # GR "Wait, Are You Serious Right Now?"
    GR "Espera, ¿Hablas En Serio Ahora?"

# game/chapters/1_day.rpyc:603
translate es day1_afterfirstchoice_f6d2f879:

    # player "Dead serious."
    player "Completamente en serio."

# game/chapters/1_day.rpyc:604
translate es day1_afterfirstchoice_58e934a1:

    # GR "Shit."
    GR "Mierda."

# game/chapters/1_day.rpyc:605
translate es day1_afterfirstchoice_f4dec5ab:

    # GR "Okay. It's One-Five-Four-Nine..."
    GR "Está Bien. Es Uno-Cinco-Cuatro-Nueve..."

# game/chapters/1_day.rpyc:608
translate es day1_afterfirstchoice_b23a4a23:

    # player "WOAH..."
    player "WOAH..."

# game/chapters/1_day.rpyc:611
translate es day1_afterfirstchoice_cd14baf9:

    # player "Okay I don't actually want your details."
    player "Vale, en realidad no quiero tus datos."

# game/chapters/1_day.rpyc:614
translate es day1_afterfirstchoice_e6033ac4:

    # player "I was joking."
    player "Estaba bromeando."

# game/chapters/1_day.rpyc:618
translate es day1_afterfirstchoice_e5c1ff04:

    # player "No, I'm messing with you again."
    player "No, te estoy tomando el pelo otra vez."

# game/chapters/1_day.rpyc:619
translate es day1_afterfirstchoice_2c51ffa0_1:

    # GR "Oh."
    GR "Oh."

# game/chapters/1_day.rpyc:622
translate es day1_afterfirstchoice_d770e46b:

    # player "But you believed me, didn't you?"
    player "Pero me creíste, ¿no?"

# game/chapters/1_day.rpyc:623
translate es day1_afterfirstchoice_c9841cb5:

    # GR "Nope. I Did Not, Not In The Slightest."
    GR "Nop. No Lo Hice, Ni En Lo Más Mínimo."

# game/chapters/1_day.rpyc:626
translate es day1_afterfirstchoice_97e824f3:

    # player "Look, as fun as messing with you is..."
    player "Mira, por muy divertido que sea molestarte..."

# game/chapters/1_day.rpyc:633
translate es day1_afterfirstchoice_9ee47d17:

    # player "Of course, it's all yours!"
    player "¡Por supuesto, es todo tuya!"

# game/chapters/1_day.rpyc:634
translate es day1_afterfirstchoice_d60ca591:

    # GR "Finally! "
    GR "¡Por Fin!"

# game/chapters/1_day.rpyc:635
translate es day1_afterfirstchoice_dc1b7dce:

    # GR "I Have Waited Long Enough."
    GR "He Esperado Lo Suficiente."

# game/chapters/1_day.rpyc:636
translate es day1_afterfirstchoice_389a516e:

    # GR "Honestly, I Should Have Contacted You Sooner If It Was Going To Be This Easy."
    GR "Honestamente, Debería Haberte Contactado Antes Si Iba A Ser Tan Fácil."

# game/chapters/1_day.rpyc:639
translate es day1_afterfirstchoice_6a0c6ec9:

    # player "Should I post it via mail?"
    player "¿Debería enviarla por correo?"

# game/chapters/1_day.rpyc:640
translate es day1_afterfirstchoice_44f4ac4e:

    # GR "What? You Cannot Send A Soul In The Post!"
    GR "¿Qué? ¡No Puedes Enviar Un Alma Por Correo!"

# game/chapters/1_day.rpyc:644
translate es day1_afterfirstchoice_9631ba19:

    # player "Trust me, you can."
    player "Créeme, sí se puede."

# game/chapters/1_day.rpyc:645
translate es day1_afterfirstchoice_28414721:

    # GR "You Cannot!"
    GR "¡No Puedes!"

# game/chapters/1_day.rpyc:646
translate es day1_afterfirstchoice_e8b39989:

    # GR "How Would You Even Know?"
    GR "¿Cómo Lo Sabrías?"

# game/chapters/1_day.rpyc:649
translate es day1_afterfirstchoice_eb9d7318:

    # player "I send souls all the time."
    player "Envío almas todo el tiempo."

# game/chapters/1_day.rpyc:650
translate es day1_afterfirstchoice_f15f8f95:

    # GR "Well... Okay."
    GR "Bueno... Está Bien."

# game/chapters/1_day.rpyc:651
translate es day1_afterfirstchoice_23f67256:

    # GR "I Am Unsure If Mortal Post Services Can Reach Me, However."
    GR "Sin Embargo, No Estoy Seguro Si Los Servicios Postales Mortales Pueden Alcanzarme."

# game/chapters/1_day.rpyc:655
translate es day1_afterfirstchoice_8215467d:

    # player "You'll just have to wait and see."
    player "Tendrás que esperar y ver."

# game/chapters/1_day.rpyc:656
translate es day1_afterfirstchoice_230dec51_1:

    # GR "...."
    GR "...."

# game/chapters/1_day.rpyc:657
translate es day1_afterfirstchoice_25b01499:

    # GR "I Believe You Are Attempting To Trick Me."
    GR "Creo Que Estás Intentando Engañarme."

# game/chapters/1_day.rpyc:661
translate es day1_afterfirstchoice_58fa5b66:

    # player "What gave me away?"
    player "¿Qué me delató?"

# game/chapters/1_day.rpyc:662
translate es day1_afterfirstchoice_17e02691:

    # GR "So It IS A Trick!"
    GR "¡Así Que SÍ Es Un Truco!"

# game/chapters/1_day.rpyc:665
translate es day1_afterfirstchoice_7a1c0710:

    # player "Honestly..."
    player "Honestamente..."

# game/chapters/1_day.rpyc:669
translate es day1_afterfirstchoice_7885e49f:

    # player "I'll email it to you. What's your email?"
    player "Te lo enviaré por correo electrónico. ¿Cuál es tu correo?"

# game/chapters/1_day.rpyc:670
translate es day1_afterfirstchoice_beaa032a:

    # GR "Huh? Souls Cannot Be Transferred Digitally."
    GR "¿Eh? Las Almas No Pueden Ser Transferidas Digitalmente."

# game/chapters/1_day.rpyc:674
translate es day1_afterfirstchoice_3491c1eb:

    # player "Are you sure about that?"
    player "¿Estás seguro de eso?"

# game/chapters/1_day.rpyc:675
translate es day1_afterfirstchoice_286edd35:

    # GR "Yes, I Am Certain."
    GR "Sí, Estoy Seguro."

# game/chapters/1_day.rpyc:678
translate es day1_afterfirstchoice_4cf203e4:

    # player "But have you ever tried?"
    player "¿Pero alguna vez lo intentaste?"

# game/chapters/1_day.rpyc:679
translate es day1_afterfirstchoice_5714f8c4:

    # GR "Well, No..."
    GR "Pues No..."

# game/chapters/1_day.rpyc:680
translate es day1_afterfirstchoice_fd29a9e9:

    # GR "Fine. My Electronic Mail Address Is TheGrimReaper123abc@reaper.org"
    GR "Está Bien. Mi Dirección De Correo Electrónico Es TheGrimReaper123abc@reaper.org"

# game/chapters/1_day.rpyc:683
translate es day1_afterfirstchoice_da3d0b34:

    # player "Pffffft...."
    player "Pffffft...."

# game/chapters/1_day.rpyc:684
translate es day1_afterfirstchoice_d7e42504:

    # GR "What? What Is So Funny?"
    GR "¿Qué? ¿Qué Tiene De Gracioso?"

# game/chapters/1_day.rpyc:687
translate es day1_afterfirstchoice_ff95e3fc:

    # player "Your email..."
    player "Tu correo..."

# game/chapters/1_day.rpyc:688
translate es day1_afterfirstchoice_17033cd4:

    # GR "It Is A Normal 'Email'."
    GR "Es Un 'Correo' Normal."

# game/chapters/1_day.rpyc:691
translate es day1_afterfirstchoice_aa75ffb7:

    # player "Sure..."
    player "Claro..."

# game/chapters/1_day.rpyc:695
translate es day1_afterfirstchoice_73fdde63:

    # player "Okay, I just emailed my soul over."
    player "Bien, acabo de enviar mi alma por correo."

# game/chapters/1_day.rpyc:696
translate es day1_afterfirstchoice_258aee4f:

    # GR "I Do Not See It In My Inbox."
    GR "No La Veo En Mi Bandeja De Entrada."

# game/chapters/1_day.rpyc:699
translate es day1_afterfirstchoice_03dcb181:

    # player "Maybe you're having internet issues."
    player "Quizás tengas problemas de Internet."

# game/chapters/1_day.rpyc:703
translate es day1_afterfirstchoice_d88378dd:

    # player "Restart your computer?"
    player "¿Reiniciaste tu ordenador?"

# game/chapters/1_day.rpyc:704
translate es day1_afterfirstchoice_1a6c2434:

    # GR "If I Was Having Internet Issues, Then Why Can I Still Message You?"
    GR "Si Tuviera Problemas De Internet, ¿Por Qué Podría Seguir Enviándote Mensajes?"

# game/chapters/1_day.rpyc:705
translate es day1_afterfirstchoice_25b01499_1:

    # GR "I Believe You Are Attempting To Trick Me."
    GR "Creo Que Estás Intentando Engañarme."

# game/chapters/1_day.rpyc:709
translate es day1_afterfirstchoice_58fa5b66_1:

    # player "What gave me away?"
    player "¿Qué me delató?"

# game/chapters/1_day.rpyc:710
translate es day1_afterfirstchoice_17e02691_1:

    # GR "So It IS A Trick!"
    GR "¡Así Que SÍ Es Un Truco!"

# game/chapters/1_day.rpyc:713
translate es day1_afterfirstchoice_7a1c0710_1:

    # player "Honestly..."
    player "Honestamente..."

# game/chapters/1_day.rpyc:719
translate es day1_afterfirstchoice_f971498c:

    # player "I don't usually respond to spam messages like this."
    player "Normalmente no respondo a mensajes de spam como este."

# game/chapters/1_day.rpyc:722
translate es day1_afterfirstchoice_683514f2:

    # player "Now I'm thinking I should?"
    player "¿Ahora pienso que debería hacerlo?"

# game/chapters/1_day.rpyc:725
translate es day1_afterfirstchoice_3a5a8d0f:

    # player "Anyway, do you seriously think you're the 'grim reaper'?"
    player "De todos modos, ¿De verdad te crees 'La Parca'?"

# game/chapters/1_day.rpyc:726
translate es day1_afterfirstchoice_1ab8e8a9:

    # GR "Excuse Me?"
    GR "¿Perdón?"

# game/chapters/1_day.rpyc:729
translate es day1_afterfirstchoice_00f33488:

    # player "It's funny, at least...?"
    player "¿Es gracioso, al menos...?"

# game/chapters/1_day.rpyc:732
translate es day1_afterfirstchoice_71a6b5a3:

    # player "You've made me laugh, so that's nice."
    player "Me has hecho reír, así que está bien."

# game/chapters/1_day.rpyc:733
translate es day1_afterfirstchoice_fc74651a:

    # GR "I Am Not Trying To Make You Laugh..."
    GR "No Intento Hacerte Reír..."

# game/chapters/1_day.rpyc:736
translate es day1_afterfirstchoice_ed32a176:

    # player "You should try being less funny then, lol"
    player "Entonces deberías intentar ser menos gracioso, lol"

# game/chapters/1_day.rpyc:737
translate es day1_afterfirstchoice_e5374b5d:

    # GR "What About Me Is Funny?"
    GR "¿Qué Tiene De Gracioso Sobre Mí?"

# game/chapters/1_day.rpyc:740
translate es day1_afterfirstchoice_480bc117:

    # player "Pretty much everything."
    player "Prácticamente todo."

# game/chapters/1_day.rpyc:743
translate es day1_afterfirstchoice_27eee40c:

    # player "Mister 'Grim Reaper' (lol)"
    player "Señor 'Parca' (lol)"

# game/chapters/1_day.rpyc:744
translate es day1_afterfirstchoice_7772a27d_3:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpyc:747
translate es day1_afterfirstchoice_144b60bf:

    # player "It's kinda... cringe."
    player "Es algo... cringe."

# game/chapters/1_day.rpyc:748
translate es day1_afterfirstchoice_2a81301f:

    # GR "Cringe...?"
    GR "¿Cringe...?"

# game/chapters/1_day.rpyc:749
translate es day1_afterfirstchoice_9f9672c6:

    # GR "I Do Not Even Know What That Means."
    GR "Ni Siquiera Sé Qué Significa Eso."

# game/chapters/1_day.rpyc:750
translate es day1_afterfirstchoice_596bef9f:

    # GR "Does It Mean 'Cool'? 'Amazing'?"
    GR "¿Significa 'Genial'? ¿'Increíble'?"

# game/chapters/1_day.rpyc:753
translate es day1_afterfirstchoice_6f8872d7:

    # player "No... embarrassing, and annoying."
    player "No... vergonzoso y molesto."

# game/chapters/1_day.rpyc:754
translate es day1_afterfirstchoice_cc21bd84:

    # GR "!!!"
    GR "!!!"

# game/chapters/1_day.rpyc:755
translate es day1_afterfirstchoice_7f11309b:

    # GR "Annoying? The Annoying One Is You!"
    GR "¿Molesto? ¡La Molestia Eres Tú!"

# game/chapters/1_day.rpyc:756
translate es day1_afterfirstchoice_af0d42a4:

    # GR "Well, I Do Not Mind If You See Me That Way."
    GR "Bueno, No Me Importa Que Me Veas Así."

# game/chapters/1_day.rpyc:757
translate es day1_afterfirstchoice_0b027599:

    # GR "Your Opinion Of Me Has Little Bearing."
    GR "Tu Opinión Sobre Mí Tiene Poca Relevancia."

# game/chapters/1_day.rpyc:759
translate es day1_afterfirstchoice_717b27af:

    # player "Er... yes, that's what it means."
    player "Erm... sí, eso significa."

# game/chapters/1_day.rpyc:760
translate es day1_afterfirstchoice_02a9656a:

    # GR "Oh. Thanks, Then."
    GR "Oh. Gracias, Entonces."

# game/chapters/1_day.rpyc:763
translate es day1_afterfirstchoice_afff8718:

    # player "But who just installs a program on someones computer like that?"
    player "¿Pero quién instala un programa en la computadora de alguien así como así?"

# game/chapters/1_day.rpyc:766
translate es day1_afterfirstchoice_3ea80c91:

    # player "Are you that desperate for attention?"
    player "¿Tan desesperado estás por llamar la atención?"

# game/chapters/1_day.rpyc:769
translate es day1_afterfirstchoice_40657a45:

    # player "It makes me feel sad for you."
    player "Me da pena por ti."

# game/chapters/1_day.rpyc:770
translate es day1_afterfirstchoice_21c33e1c:

    # GR "...Your Brain Truly Is Tiny."
    GR "...Tu Cerebro Realmente Es Diminuto."

# game/chapters/1_day.rpyc:771
translate es day1_afterfirstchoice_7e794ff8:

    # GR "Small And Completely Smooth."
    GR "Pequeño Y Completamente Liso."

# game/chapters/1_day.rpyc:772
translate es day1_afterfirstchoice_769b627b:

    # GR "This Is My Job. You Are A Difficult Task, Nothing More."
    GR "Este Es Mi Trabajo. Eres Una Tarea Difícil, Nada Más."

# game/chapters/1_day.rpyc:776
translate es day1_afterfirstchoice_a6549763:

    # player "Dude..."
    player "Amigo..."

# game/chapters/1_day.rpyc:779
translate es day1_afterfirstchoice_e2b222f8:

    # player "You're the one harrassing me."
    player "Tú eres el que me está acosando."

# game/chapters/1_day.rpyc:782
translate es day1_afterfirstchoice_16141bad:

    # player "Nobody is forcing you to be here."
    player "Nadie te obliga a estar aquí."

# game/chapters/1_day.rpyc:783
translate es day1_afterfirstchoice_3b508ccf:

    # GR "I Have Little Choice In The Matter, There are Issues That Must Be Resolved."
    GR "Tengo Poca Elección En El Asunto, Hay Asuntos Que Deben Ser Resueltos."

# game/chapters/1_day.rpyc:784
translate es day1_afterfirstchoice_b8f234d6:

    # GR "So Until You Stop This Ridiculous Charade, I Will Be Here."
    GR "Así Que Hasta Que No Detengas Esta Ridícula Farsa, Estaré Aquí."

# game/chapters/1_day.rpyc:787
translate es day1_afterfirstchoice_0dad0745:

    # player "Forever?"
    player "¿Para Siempre?"

# game/chapters/1_day.rpyc:788
translate es day1_afterfirstchoice_d65f78b8:

    # GR "If That's What It Takes."
    GR "Si Eso Es Lo Que Se Necesita."

# game/chapters/1_day.rpyc:791
translate es day1_afterfirstchoice_7db48f30:

    # player "Forever and ever?"
    player "¿Siempre y para siempre?"

# game/chapters/1_day.rpyc:792
translate es day1_afterfirstchoice_86d56fc8:

    # GR "I Already Said Yes."
    GR "Ya Dije Que Sí."

# game/chapters/1_day.rpyc:795
translate es day1_afterfirstchoice_d781f2c3:

    # player "You know I can just leave this chat whenever I want, right?"
    player "Sabes que puedo salir de este chat cuando quiera, ¿verdad?"

# game/chapters/1_day.rpyc:798
translate es day1_afterfirstchoice_2939677b:

    # player "Then you'd be sitting in chat all alone."
    player "Entonces estarías chateando completamente solo."

# game/chapters/1_day.rpyc:801
translate es day1_afterfirstchoice_27eee40c_1:

    # player "Mister 'Grim Reaper' (lol)"
    player "Señor 'Parca' (lol)"

# game/chapters/1_day.rpyc:804
translate es day1_afterfirstchoice_0d26ac90:

    # player "It's a little cute..."
    player "Es un poco lindo..."

# game/chapters/1_day.rpyc:805
translate es day1_afterfirstchoice_016cb970:

    # GR "C... Cute...?!"
    GR "¿L... Lindo...?"

# game/chapters/1_day.rpyc:808
translate es day1_afterfirstchoice_d898dab5:

    # player "Yeah. In a weird way."
    player "Sí. De una forma rara."

# game/chapters/1_day.rpyc:812
translate es day1_afterfirstchoice_3728832e:

    # player "You're totally delusional, but it's kinda sweet."
    player "Estás totalmente delirando, pero es algo tierno."

# game/chapters/1_day.rpyc:813
translate es day1_afterfirstchoice_96fa627b:

    # GR "Why Won't You Take Me Seriously?"
    GR "¿Por Qué No Me Tomas En Serio?"

# game/chapters/1_day.rpyc:817
translate es day1_afterfirstchoice_9ffe0490:

    # player "Well, it could be that you keep saying things like..."
    player "Bueno, podría ser que sigas diciendo cosas como..."

# game/chapters/1_day.rpyc:820
translate es day1_afterfirstchoice_d72ce11a:

    # player "I Have Come To Eat Your Soul!"
    player "¡He Venido A Devorar Tu Alma!"

# game/chapters/1_day.rpyc:822
translate es day1_afterfirstchoice_80fa48fd:

    # player "I Am So Edgy And Dark!"
    player "¡Soy Tan Edgy Y Tenebroso!"

# game/chapters/1_day.rpyc:824
translate es day1_afterfirstchoice_049a5c43:

    # player "I Am Darkness Incarnate!"
    player "¡Soy La Oscuridad Encarnada!"

# game/chapters/1_day.rpyc:826
translate es day1_afterfirstchoice_1dae217b:

    # GR "I... I Never Said That...!"
    GR "¡Y... Yo Nunca Dije Eso...!"

# game/chapters/1_day.rpyc:830
translate es day1_afterfirstchoice_111fcb5b:

    # player "You did."
    player "Lo hiciste."

# game/chapters/1_day.rpyc:831
translate es day1_afterfirstchoice_3a473189:

    # GR "I Did Not!"
    GR "¡Yo No Lo Hice!"

# game/chapters/1_day.rpyc:832
translate es day1_afterfirstchoice_b51be2e9:

    # GR "You Have No Proof!"
    GR "¡No Tienes Pruebas!"

# game/chapters/1_day.rpyc:839
translate es day1_afterfirstchoice_0526e426:

    # player "Neither do you, little mister grim reaper."
    player "Tú tampoco, señorito Parca."

# game/chapters/1_day.rpyc:842
translate es day1_afterfirstchoice_6a226e02:

    # player "Wait, {b}I'M{/b} the Grim Reaper..."
    player "Espera, {b}YO SOY{/b} La Parca..."

# game/chapters/1_day.rpyc:843
translate es day1_afterfirstchoice_a3edffcb:

    # GR "Um... No You Aren't."
    GR "Em... No Lo Eres."

# game/chapters/1_day.rpyc:846
translate es day1_afterfirstchoice_f218ae39:

    # player "Are you trying to steal my job?"
    player "¿Estás tratando de robarme mi trabajo?"

# game/chapters/1_day.rpyc:849
translate es day1_afterfirstchoice_d182f31b:

    # player "That is super {i}not{/i} cool."
    player "Es súper {i}no{/i} cool."

# game/chapters/1_day.rpyc:850
translate es day1_afterfirstchoice_28898917:

    # GR "You Are Not A Grim Reaper!"
    GR "¡No Eres Una Parca!"

# game/chapters/1_day.rpyc:853
translate es day1_afterfirstchoice_c37279db:

    # player "I Am The Grim Reaper!"
    player "¡Yo Soy La Parca!"

# game/chapters/1_day.rpyc:854
translate es day1_afterfirstchoice_2d8b5be4:

    # GR "You Are Not!"
    GR "¡Tú No Eres!"

# game/chapters/1_day.rpyc:855
translate es day1_afterfirstchoice_e228c045:

    # GR "I Know Each And Every Grim Reaper In This Plane And Beyond."
    GR "Conozco A Cada Parca En Este Plano Y Más Allá."

# game/chapters/1_day.rpyc:856
translate es day1_afterfirstchoice_e06514fd:

    # GR "You Are Not One Of Them!"
    GR "¡Tú No Eres Uno De Ellos!"

# game/chapters/1_day.rpyc:860
translate es day1_afterfirstchoice_20392fd7:

    # player "No, You Are Not!"
    player "¡No, Tú No Eres!"

# game/chapters/1_day.rpyc:861
translate es day1_afterfirstchoice_f3b1f875:

    # GR "......"
    GR "......"

# game/chapters/1_day.rpyc:862
translate es day1_afterfirstchoice_41289f45:

    # GR "Okay."
    GR "Está Bien."

# game/chapters/1_day.rpyc:863
translate es day1_afterfirstchoice_8f63e698:

    # GR "If You Are Truly A Grim Reaper, Then Tell Me The First Rule Of Taking A Soul."
    GR "Si Realmente Eres Una Parca, Entonces Dime La Primera Regla De Tomar Un Alma."

# game/chapters/1_day.rpyc:867
translate es day1_afterfirstchoice_223c305b:

    # player "The 1st rule of Grim Reaper club - don't talk about Grim Reaper club."
    player "La primera regla del club de Las parcas — no hablar del club de Las Parcas."

# game/chapters/1_day.rpyc:869
translate es day1_afterfirstchoice_724640b7:

    # player "Make sure they didn't leave the oven on."
    player "Asegúrate de que no hayan dejado el horno encendido."

# game/chapters/1_day.rpyc:871
translate es day1_afterfirstchoice_ab295699:

    # player "If they win in rock paper scissors, they get a free pass."
    player "Si ganan en piedra, papel o tijera, obtienen un pase gratuito."

# game/chapters/1_day.rpyc:873
translate es day1_afterfirstchoice_91cfd2b3:

    # GR "No, No, No!"
    GR "¡No, No, No!"

# game/chapters/1_day.rpyc:874
translate es day1_afterfirstchoice_567e8c43:

    # GR "You Have Absolutely No Clue!"
    GR "¡No Tienes Absolutamente Ninguna Pista!"

# game/chapters/1_day.rpyc:875
translate es day1_afterfirstchoice_8ad3ddce:

    # GR "The First Rule Is: Ensure A Peaceful Passage."
    GR "La Primera Regla Es: Asegurar Un Tránsito Pacífico."

# game/chapters/1_day.rpyc:876
translate es day1_afterfirstchoice_9f28cdf7:

    # GR "No Unnecessary Suffering Or Fear Should Accompany The Transition."
    GR "No Debe Acompañar La Transición Ningún Sufrimiento O Miedo Innecesario."

# game/chapters/1_day.rpyc:880
translate es day1_afterfirstchoice_93513e90:

    # player "How reasonable of you."
    player "Qué razonable de tu parte."

# game/chapters/1_day.rpyc:883
translate es day1_afterfirstchoice_43ac18a9:

    # player "That's boring. Cause a little pain, why don't you?"
    player "Eso es aburrido. Causa un poco de dolor, ¿por qué no?"

# game/chapters/1_day.rpyc:887
translate es day1_afterfirstchoice_8f56b631:

    # player "You're a funny little 'grim reaper' lol"
    player "Eres una 'Parquita' divertida, lol"

# game/chapters/1_day.rpyc:891
translate es day1_afterfirstchoice_eee101f4:

    # GR "You... You Mock My Title Now?!"
    GR "¿Tú... Te Mofas De Mi Título Ahora?!"

# game/chapters/1_day.rpyc:895
translate es day1_afterfirstchoice_0e832a4c:

    # player "It's, well... a little embarrassing."
    player "Es, bueno... un poco vergonzoso."

# game/chapters/1_day.rpyc:897
translate es day1_afterfirstchoice_01bade75:

    # player "Is there anyone who wouldn't?"
    player "¿Hay alguien que no lo haría?"

# game/chapters/1_day.rpyc:899
translate es day1_afterfirstchoice_bc1f7f69:

    # player "It's less mocking, more... light teasing."
    player "Es menos burlón, más... una broma ligera."

# game/chapters/1_day.rpyc:901
translate es day1_afterfirstchoice_96c8cc18:

    # player "Yeah, sorry."
    player "Sí, lo siento."

# game/chapters/1_day.rpyc:904
translate es day1_afterfirstchoice_f6d98ad8:

    # player "Wait, wait, wait, quick question."
    player "Espera, espera, espera, pregunta rápida."

# game/chapters/1_day.rpyc:907
translate es day1_afterfirstchoice_5192d67b:

    # player "Do you walk around being like '{i}I AM DEATH{/i}'? in real life, too?"
    player "¿Acaso caminas por ahí diciendo '{i}YO SOY LA MUERTE{/i}'? ¿En la vida real también?"

# game/chapters/1_day.rpyc:908
translate es day1_afterfirstchoice_4c380e69:

    # GR "What...?"
    GR "¿Qué...?"

# game/chapters/1_day.rpyc:911
translate es day1_afterfirstchoice_96a2bde7:

    # player "'{i}Bow down to me...! Your soul is mine...!{/i}'"
    player "'{i}Inclínate ante mí...! ¡Tu alma es mía...!{/i}'"

# game/chapters/1_day.rpyc:913
translate es day1_afterfirstchoice_b2b4acdf:

    # player "'{i}I am the Grim Reaper! Death and darkness!{/i}'"
    player "'{i}¡Soy La Parca! ¡Muerte y oscuridad!{/i}'"

# game/chapters/1_day.rpyc:916
translate es day1_afterfirstchoice_950a76e8:

    # player "You do, don't you?"
    player "¿Lo haces, verdad?"

# game/chapters/1_day.rpyc:917
translate es day1_afterfirstchoice_7772a27d_4:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpyc:920
translate es day1_afterfirstchoice_97051f90:

    # player "Stunned silence?"
    player "¿Silencio absoluto?"

# game/chapters/1_day.rpyc:921
translate es day1_afterfirstchoice_7772a27d_5:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpyc:924
translate es day1_afterfirstchoice_a3034a9c:

    # player "Is your hair as dark as night? Do you hide behind long bangs?"
    player "¿Tu cabello es tan oscuro como la noche? ¿Te escondes detrás de un flequillo largo?"

# game/chapters/1_day.rpyc:926
translate es day1_afterfirstchoice_c0253e00:

    # player "You give off 'dresses in all black' vibes."
    player "Das la vibra de 'se viste todo de negro'."

# game/chapters/1_day.rpyc:929
translate es day1_afterfirstchoice_61faefca:

    # player "I can relate to that, at least."
    player "Al menos, puedo identificarme con eso."

# game/chapters/1_day.rpyc:931
translate es day1_afterfirstchoice_f29a0155:

    # player "Not my thing, but you do you, buddy."
    player "No es lo mío, pero tú haz lo que quieras, amigo."

# game/chapters/1_day.rpyc:934
translate es day1_afterfirstchoice_7faa6bcf:

    # player "I think I can imagine you completely."
    player "Creo que puedo imaginarte perfectamente."

# game/chapters/1_day.rpyc:937
translate es day1_afterfirstchoice_a115179a:

    # player "It's a funny thought... hehe."
    player "Es una idea divertida... jeje."

# game/chapters/1_day.rpyc:939
translate es day1_afterfirstchoice_c7b1042b:

    # player "If only we could meet to confirm my suspicions."
    player "Ojalá pudiéramos vernos para confirmar mis sospechas."

# game/chapters/1_day.rpyc:942
translate es day1_afterfirstchoice_f6627dc0:

    # GR "You... You..."
    GR "Tú... Tú..."

# game/chapters/1_day.rpyc:943
translate es day1_afterfirstchoice_da1e5321:

    # GR "I Will Not Be Mocked By A Mortal...!"
    GR "¡No Seré Burlado Por Un Mortal...!"

# game/chapters/1_day.rpyc:946
translate es day1_afterfirstchoice_10d28b01:

    # player "'{i}Give me your soul! Your soul is mine for the harvesting!{/i}'"
    player "'{i}¡Dame tu alma! ¡Tu alma es mía para cosecharla!{/i}'"

# game/chapters/1_day.rpyc:949
translate es day1_afterfirstchoice_5fc173bd:

    # player "'{i}It will be a three course meal!{/i}'."
    player "'{i}¡Será una comida de tres platos!{/i}'"

# game/chapters/1_day.rpyc:950
translate es day1_afterfirstchoice_5e2588e9:

    # GR "You... You...!"
    GR "Tú... Tú...!"

# game/chapters/1_day.rpyc:953
translate es day1_afterfirstchoice_d97f4de4:

    # player "Did I hurt the scammer's feelings?"
    player "¿Hice daño a tus sentimientos de estafador?"

# game/chapters/1_day.rpyc:954
translate es day1_afterfirstchoice_7718795e:

    # GR "When Did I Scam You...? "
    GR "¿Cuándo Te Estafé...?"

# game/chapters/1_day.rpyc:955
translate es day1_afterfirstchoice_700bb465:

    # GR "Why Do You Keep Calling Me A Scammer....?"
    GR "¿Por Qué Sigues Llamándome Estafador....?"

# game/chapters/1_day.rpyc:956
translate es day1_afterfirstchoice_ff6f1cb2:

    # GR "You're Giving Me A Complex Over Here..."
    GR "Me Estás Creando Un Complejo Aquí..."

# game/chapters/1_day.rpyc:959
translate es day1_afterfirstchoice_7e69006b:

    # player "Have I hurt your little dead heart?"
    player "¿Le he hecho daño a tu corazoncito muerto?"

# game/chapters/1_day.rpyc:960
translate es day1_afterfirstchoice_d532596c:

    # GR "What Makes You Assume I Am Dead?"
    GR "¿Qué Te Lleva A Suponer Que Estoy Muerto?"

# game/chapters/1_day.rpyc:963
translate es day1_afterfirstchoice_50d81008:

    # player "The grim reaper is like..."
    player "La parca es como..."

# game/chapters/1_day.rpyc:967
translate es day1_afterfirstchoice_eb24cb23:

    # player "A skeleton, right?"
    player "Un esqueleto, ¿no?"

# game/chapters/1_day.rpyc:969
translate es day1_afterfirstchoice_6f912713:

    # player "Dead, right?"
    player "Muerto, ¿verdad?"

# game/chapters/1_day.rpyc:971
translate es day1_afterfirstchoice_5eb272b8:

    # GR "Another Foolish Assumption."
    GR "Otra Suposición Necia."

# game/chapters/1_day.rpyc:972
translate es day1_afterfirstchoice_fe792b1c:

    # GR "Know This."
    GR "Sepa Esto."

# game/chapters/1_day.rpyc:973
translate es day1_afterfirstchoice_56052453:

    # GR "I Shall Make It As Painful As I Can For You."
    GR "Haré Que Sea Tan Doloroso Como Pueda Para Ti."

# game/chapters/1_day.rpyc:974
translate es day1_afterfirstchoice_294093b9:

    # GR "Your Disrespect Has Been Noted."
    GR "Tu Falta De Respeto Ha Sido Anotada."

# game/chapters/1_day.rpyc:978
translate es day1_afterfirstchoice_100463e7:

    # player "Hey..."
    player "Oye..."

# game/chapters/1_day.rpyc:981
translate es day1_afterfirstchoice_6e6c9f4c:

    # player "Since reaping souls is your job and all, I have a question."
    player "Ya que tu trabajo consiste en cosechar almas, tengo una pregunta."

# game/chapters/1_day.rpyc:984
translate es day1_afterfirstchoice_ad5b5e53:

    # player "Do you..."
    player "¿Tú..."

# game/chapters/1_day.rpyc:987
translate es day1_afterfirstchoice_fbacb205:

    # player "Make a killing? :)"
    player "Ganas mucho dinero? :)"

# game/chapters/1_day.rpyc:988
translate es day1_afterfirstchoice_73410440:

    # GR "I Hate You. I Hate You So Much."
    GR "Te Odio. Te Odio Tanto."

# game/chapters/1_day.rpyc:989
translate es day1_afterfirstchoice_94c53a90:

    # GR "Stupid Mortal. "
    GR "Estúpido Mortal."

# game/chapters/1_day.rpyc:990
translate es day1_afterfirstchoice_cb46c63f:

    # GR "You Would Quiver Under My Gaze Before I Granted You Death."
    GR "Temblarías Bajo Mi Mirada Antes De Que Te Concediera La Muerte."

# game/chapters/1_day.rpyc:993
translate es day1_afterfirstchoice_4931e5f0:

    # player "I'm quivering just thinking about it."
    player "Estoy temblando solo de pensarlo."

# game/chapters/1_day.rpyc:996
translate es day1_afterfirstchoice_c16351ac:

    # player "Not in a weird way."
    player "No de una manera extraña."

# game/chapters/1_day.rpyc:999
translate es day1_afterfirstchoice_39d501a2:

    # player "Using the word 'quiver' was certainly a choice."
    player "Usar la palabra 'temblar' fue sin duda una elección deliberada."

# game/chapters/1_day.rpyc:1002
translate es day1_afterfirstchoice_a2ede373:

    # GR "I Would Like To See You Try To Insult Me To My Face!"
    GR "¡Me Gustaría Verte Intentar Insultarme A La Cara!"

# game/chapters/1_day.rpyc:1006
translate es day1_afterfirstchoice_ac3b3355:

    # player "Fine."
    player "Está bien."

# game/chapters/1_day.rpyc:1009
translate es day1_afterfirstchoice_079539a6:

    # player "Video call me, then."
    player "Hazme una videollamada, entonces."

# game/chapters/1_day.rpyc:1012
translate es day1_afterfirstchoice_0403cc8c:

    # player "Unless the little '{i}weaper{/i}' is too scared?"
    player "¿A menos que la '{i}parquita{/i}' tenga demasiado miedo?"

# game/chapters/1_day.rpyc:1013
translate es day1_afterfirstchoice_cc21bd84_1:

    # GR "!!!"
    GR "!!!"

# game/chapters/1_day.rpyc:1014
translate es day1_afterfirstchoice_5ce11c6d:

    # GR "I Am Never 'Scared'!"
    GR "¡Nunca Estoy 'Asustado'!"

# game/chapters/1_day.rpyc:1017
translate es day1_afterfirstchoice_9261d0ff:

    # player "You do type like that, though."
    player "Es que escribes así."

# game/chapters/1_day.rpyc:1018
translate es day1_afterfirstchoice_e9ab6f59:

    # GR "How So?"
    GR "¿De Qué Manera?"

# game/chapters/1_day.rpyc:1021
translate es day1_afterfirstchoice_9e50f511:

    # player "It's all kind of... edgy."
    player "Es todo como... edgy."

# game/chapters/1_day.rpyc:1024
translate es day1_afterfirstchoice_9bbc7309:

    # player "Every single thing you say."
    player "Cada una de tus palabras."

# game/chapters/1_day.rpyc:1025
translate es day1_afterfirstchoice_c798cc2d:

    # GR "I Am Not Edgy. I Am Death."
    GR "No Soy Edgy. Soy La Muerte."

# game/chapters/1_day.rpyc:1028
translate es day1_afterfirstchoice_e8a190d6:

    # player "See!"
    player "¡Mira!"

# game/chapters/1_day.rpyc:1030
translate es day1_afterfirstchoice_5ebd81f9:

    # player "You're just proving my point."
    player "Solo estás confirmando mi punto."

# game/chapters/1_day.rpyc:1033
translate es day1_afterfirstchoice_8a48bc20:

    # player "This is not how you pick up people, you know."
    player "Así no es como se seduce a la gente, ¿sabes?"

# game/chapters/1_day.rpyc:1034
translate es day1_afterfirstchoice_248749d0:

    # GR "I Am Picking Up Nobody!"
    GR "¡No Estoy Coqueteando Con Nadie!"

# game/chapters/1_day.rpyc:1037
translate es day1_afterfirstchoice_fab8dd6d:

    # player "Exactly."
    player "Exacto."

# game/chapters/1_day.rpyc:1039
translate es day1_afterfirstchoice_cd62d4de:

    # player "The fact that you admitted it..."
    player "El hecho de lo hayas admitido..."

# game/chapters/1_day.rpyc:1040
translate es day1_afterfirstchoice_ac0f5412:

    # GR "The Only Thing I Wish to Pick Up Is Your Soul."
    GR "Lo Único Que Deseo Recoger Es Tu Alma."

# game/chapters/1_day.rpyc:1043
translate es day1_afterfirstchoice_ba592091:

    # player "I dunno... I'm kinda attached to it."
    player "No sé... Le tengo cierto cariño."

# game/chapters/1_day.rpyc:1046
translate es day1_afterfirstchoice_771d01cd:

    # player "Can't you take someone else's?"
    player "¿No puedes tomar la de otra persona?"

# game/chapters/1_day.rpyc:1049
translate es day1_afterfirstchoice_a8a44847:

    # player "Sorry, I'm gonna have to pass."
    player "Lo siento, voy a tener que pasar."

# game/chapters/1_day.rpyc:1050
translate es day1_afterfirstchoice_ee6f35b3:

    # GR "Passing Is Not An Option."
    GR "Pasar No Es Una Opción."

# game/chapters/1_day.rpyc:1053
translate es day1_afterfirstchoice_b586dc49:

    # player "What are you going to do about it?"
    player "¿Qué vas a hacer al respecto?"

# game/chapters/1_day.rpyc:1054
translate es day1_afterfirstchoice_7772a27d_6:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpyc:1055
translate es day1_afterfirstchoice_cc331cd9:

    # GR "It Seems You Aren't Understanding Exactly What's At Stake Here."
    GR "Parece Que No Estás Entendiendo Exactamente Lo Que Está En Juego Aquí."

# game/chapters/1_day.rpyc:1056
translate es day1_afterfirstchoice_86a416fc:

    # GR "Answer This At Once."
    GR "Responde A Esto Ahora Mismo."

# game/chapters/1_day.rpyc:1090
translate es call1_day1_2c346477:

    # GRC "Well?"
    GRC "¿Bueno?"

# game/chapters/1_day.rpyc:1093
translate es call1_day1_1b0379f8:

    # GRC "Anything to say for yourself?"
    GRC "¿Tienes algo que decir en tu defensa?"

# game/chapters/1_day.rpyc:1103
translate es call1_day1_99b5930d:

    # GRC "I am anything but 'scared' of facing a mortal such as yourself."
    GRC "No estoy en absoluto 'asustado' de enfrentarme a un mortal como tú."

# game/chapters/1_day.rpyc:1111
translate es call1_day1_3243f032:

    # GRC "A lovely face, yet such a dirty mouth."
    GRC "Una cara bonita, pero una boca tan sucia."

# game/chapters/1_day.rpyc:1114
translate es call1_day1_df7c292d:

    # GRC "Not only that, either. It seems you're all bark and no bite."
    GRC "Y no solo eso. Parece que ladras pero no muerdes."

# game/chapters/1_day.rpyc:1118
translate es call1_day1_85510b7d:

    # GRC "You're speechless."
    GRC "Te has quedado sin palabras."

# game/chapters/1_day.rpyc:1119
translate es call1_day1_52dbfbf9:

    # GRC "With a reaction like that, it seems my beauty has instantly captured you."
    GRC "Con una reacción como esa, parece que mi belleza te ha cautivado al instante."

# game/chapters/1_day.rpyc:1121
translate es call1_day1_aecd1113:

    # GRC "A fair reaction, I must admit. Mortals regularly desire that which they cannot have."
    GRC "Una reacción razonable, debo admitir. Los mortales suelen desear aquello que no pueden tener."

# game/chapters/1_day.rpyc:1125
translate es call1_day1_49675e11:

    # GRC "I don't remember saying that."
    GRC "No recuerdo haber dicho eso"

# game/chapters/1_day.rpyc:1129
translate es call1_day1_71d06dfb:

    # GRC "Unlikely. Take one look at yourself."
    GRC "Lo dudo. Mírate un poco."

# game/chapters/1_day.rpyc:1136
translate es call1_day1_f578e64e:

    # GRC "Hah."
    GRC "Ja."

# game/chapters/1_day.rpyc:1151
translate es call1_day1_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:1155
translate es call1_day1_1bf24ed6:

    # GRC "I seem to have taken your breath away."
    GRC "Parece que te he dejado sin aliento."

# game/chapters/1_day.rpyc:1157
translate es call1_day1_42ba0254:

    # GRC "That much can be expected, I suppose."
    GRC "Es lo que se puede esperar, supongo."

# game/chapters/1_day.rpyc:1158
translate es call1_day1_9eef5e15:

    # GRC "I have often been called irresistible by your kind."
    GRC "A menudo tu gente me ha llamado irresistible."

# game/chapters/1_day.rpyc:1160
translate es call1_day1_b21d53cf:

    # GRC "Before their souls are taken, of course."
    GRC "Antes de que les quite el alma, por supuesto."

# game/chapters/1_day.rpyc:1165
translate es call1_day1_b91ce0f9:

    # GRC "Oh, they talk? How quaint."
    GRC "Oh, ¿hablan? Qué curioso."

# game/chapters/1_day.rpyc:1167
translate es call1_day1_42ad7dee:

    # GRC "And what {i}did{/i} you expect?"
    GRC "¿Y qué {i}esperabas{/i}?"

# game/chapters/1_day.rpyc:1180
translate es call1_day1_2f7744af:

    # GRC "Shadows and darkness... do you take me for a creature out of a fairytale?"
    GRC "Sombras y oscuridad... ¿me tomas por un personaje de cuento de hadas?"

# game/chapters/1_day.rpyc:1186
translate es call1_day1_d7ae7e2b:

    # GRC "Yes?"
    GRC "¿Sí?"

# game/chapters/1_day.rpyc:1193
translate es call1_day1_eeb77df2:

    # GRC "Excuse me?"
    GRC "¿Perdón?"

# game/chapters/1_day.rpyc:1194
translate es call1_day1_a73d403c:

    # GRC "Cute is {i}not{/i} a word I would use to describe myself."
    GRC "Lindo {i}no{/i} es una palabra que utilizaría para describirme."

# game/chapters/1_day.rpyc:1195
translate es call1_day1_a78c30c7:

    # GRC "Kittens are cute. Puppies are cute."
    GRC "Los gatitos son lindos. Los cachorros son lindos."

# game/chapters/1_day.rpyc:1196
translate es call1_day1_0d635938:

    # GRC "I am {i}not{/i} cute."
    GRC "Yo {i}no{/i} soy lindo."

# game/chapters/1_day.rpyc:1200
translate es call1_day1_6b17f8aa:

    # GRC "Devilishly handsome. Immaculate. Gorgeous."
    GRC "Diabólicamente guapo. Inmaculado. Precioso."

# game/chapters/1_day.rpyc:1202
translate es call1_day1_04cc0178:

    # GRC "Simply use your eyes and you'll see for yourself."
    GRC "Simplemente usa tus ojos y lo verás por ti mismo."

# game/chapters/1_day.rpyc:1205
translate es call1_day1_70363630:

    # GRC "Obviously."
    GRC "Obviamente."

# game/chapters/1_day.rpyc:1213
translate es call1_day1_12b2a619:

    # GRC "Why would I waste my time doing that?"
    GRC "¿Por qué iba a perder el tiempo haciendo eso?"

# game/chapters/1_day.rpyc:1216
translate es call1_day1_5620369d:

    # GRC "Of course. Don't apply human logic to that which you don't understand."
    GRC "Por supuesto. No apliques la lógica humana a aquello que no entiendes."

# game/chapters/1_day.rpyc:1218
translate es call1_day1_30922fc5:

    # GRC "Or can you not help yourself? Perhaps your eyes cannot leave me."
    GRC "¿O no puedes evitarlo? Quizás tus ojos no pueden apartarse de mí."

# game/chapters/1_day.rpyc:1222
translate es call1_day1_89489d40:

    # GRC "I... am not cute!"
    GRC "¡Yo... no soy lindo!"

# game/chapters/1_day.rpyc:1225
translate es call1_day1_11da517e:

    # GRC "You are incorrect."
    GRC "Estás equivocado."

# game/chapters/1_day.rpyc:1230
translate es call1_day1_6fbe03f4:

    # GRC "No."
    GRC "No."

# game/chapters/1_day.rpyc:1233
translate es call1_day1_143e5704:

    # GRC "I never promised I would be fun."
    GRC "Nunca prometí que sería divertido."

# game/chapters/1_day.rpyc:1237
translate es call1_day1_f6f191bc:

    # GRC "As I said, you probably cannot help it."
    GRC "Como dije, probablemente no puedas evitarlo."

# game/chapters/1_day.rpyc:1247
translate es call1_day1_eeb77df2_1:

    # GRC "Excuse me?"
    GRC "¿Perdón?"

# game/chapters/1_day.rpyc:1251
translate es call1_day1_10fae8c3:

    # GRC "Mortal."
    GRC "Mortal."

# game/chapters/1_day.rpyc:1252
translate es call1_day1_382c29f1:

    # GRC "'Your' little reaper?"
    GRC "¿'Tu' parquita?"

# game/chapters/1_day.rpyc:1253
translate es call1_day1_8f3c9513:

    # GRC "Death belongs to no one, and everyone."
    GRC "La muerte no pertenece a nadie, y es de todos."

# game/chapters/1_day.rpyc:1264
translate es call1_day1_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:1265
translate es call1_day1_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/1_day.rpyc:1267
translate es call1_day1_24970499:

    # GRC "Ahem."
    GRC "Ejem."

# game/chapters/1_day.rpyc:1279
translate es call1_day1_eeb77df2_2:

    # GRC "Excuse me?"
    GRC "¿Perdón?"

# game/chapters/1_day.rpyc:1286
translate es call1_day1_8370d0dc:

    # GRC "As if a mortal could comprehend something as advanced as an aura."
    GRC "As if a mortal could comprehend something as advanced as an aura."

# game/chapters/1_day.rpyc:1287
translate es call1_day1_0719d3a8:

    # GRC "You're interesting, {i}human{/i}."
    GRC "Eres un {i}humano{/i} interesante"

# game/chapters/1_day.rpyc:1288
translate es call1_day1_a82fa2c2:

    # GRC "Interesting, but completely and utterly incorrect."
    GRC "Interesante, pero total y absolutamente incorrecto."

# game/chapters/1_day.rpyc:1292
translate es call1_day1_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:1293
translate es call1_day1_4fd5f215:

    # GRC "Stop saying that..."
    GRC "Deja de decir eso..."

# game/chapters/1_day.rpyc:1294
translate es call1_day1_abfdd9c4:

    # GRC "Anyway. Even if I was human, my aura would not be lacking."
    GRC "De todos modos, aunque fuera humano, mi aura no sería deficiente."

# game/chapters/1_day.rpyc:1298
translate es call1_day1_d88c721c:

    # GRC "Admit what?"
    GRC "¿Admitir qué?"

# game/chapters/1_day.rpyc:1316
translate es call1_day1_008afe10_3:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:1318
translate es call1_day1_d19378d9:

    # GRC "How many times do I have to tell yo—"
    GRC "¿Cuántas veces tengo que decirte—"

# game/chapters/1_day.rpyc:1331
translate es call1_day1_0a2c4bf7:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/1_day.rpyc:1340
translate es call1_day1_85901163:

    # GRC "I'm simply surprised that you could be so naive."
    GRC "Simplemente me sorprende que puedas ser tan ingenuo."

# game/chapters/1_day.rpyc:1342
translate es call1_day1_9ce19477:

    # GRC "I am the Grim Reaper, in charge of ferrying souls to their rightful afterlife."
    GRC "Soy La Parca, encargado de trasladar las almas al más allá que les corresponde."

# game/chapters/1_day.rpyc:1361
translate es call1_day1_be201dba:

    # GRC "You are truly insufferable."
    GRC "Eres realmente insufrible."

# game/chapters/1_day.rpyc:1363
translate es call1_day1_97b2df1d:

    # GRC "I am here for the sole purpose of harvesting your soul."
    GRC "Estoy aquí con el único propósito de cosechar tu alma."

# game/chapters/1_day.rpyc:1364
translate es call1_day1_9c2020df:

    # GRC "Your opinion on the matter hardly matters to me."
    GRC "Tu opinión sobre el tema me importa muy poco."

# game/chapters/1_day.rpyc:1365
translate es call1_day1_e3d9ae04:

    # GRC "Think what you want about me and my role."
    GRC "Piensa lo que quieras sobre mí y mi función."

# game/chapters/1_day.rpyc:1366
translate es call1_day1_f4a3fecc:

    # GRC "It changes nothing."
    GRC "No cambia nada."

# game/chapters/1_day.rpyc:1378
translate es call1_day1_008afe10_4:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:1379
translate es call1_day1_9cafa0c7:

    # GRC "Desperate times call for desperate measures."
    GRC "Momentos desesperados requieren medidas desesperadas."

# game/chapters/1_day.rpyc:1397
translate es call1_day1_0673ce9a:

    # GRC "Romantic? I suppose it is."
    GRC "¿Romántico? Supongo que sí."

# game/chapters/1_day.rpyc:1400
translate es call1_day1_94722f37:

    # GRC "I would say there is something inherently romantic about death."
    GRC "Yo diría que hay algo intrínsecamente romántico en la muerte."

# game/chapters/1_day.rpyc:1410
translate es call1_day1_1bdfbe01:

    # GRC "Don't look at me like that."
    GRC "No me mires así."

# game/chapters/1_day.rpyc:1417
translate es call1_day1_346d4a1d:

    # GRC "It's not like I chose this fate for you."
    GRC "No es que yo haya elegido este destino para ti."

# game/chapters/1_day.rpyc:1420
translate es call1_day1_137b3463:

    # GRC "I'm just here to do the dirty work. Unfortunately."
    GRC "Solo estoy aquí para hacer el trabajo sucio. Por desgracia."

# game/chapters/1_day.rpyc:1421
translate es call1_day1_3df0ee5b:

    # GRC "Don't shoot the messenger, and all that."
    GRC "No culpes al mensajero, y todo eso."

# game/chapters/1_day.rpyc:1427
translate es call1_day1_3be9a8ab:

    # GRC "What...?"
    GRC "¿Qué...?"

# game/chapters/1_day.rpyc:1428
translate es call1_day1_fd8760e1:

    # GRC "There is nothing to 'give up'."
    GRC "No hay nada que 'renunciar'."

# game/chapters/1_day.rpyc:1429
translate es call1_day1_e4692631:

    # GRC "If anyone has something to give up, it is you."
    GRC "Si alguien tiene algo que renunciar, ese eres tú."

# game/chapters/1_day.rpyc:1430
translate es call1_day1_c08d1f06:

    # GRC "You need to work on your ability to listen, I believe."
    GRC "Creo que necesitas trabajar tu capacidad para escuchar."

# game/chapters/1_day.rpyc:1433
translate es call1_day1_d25edd0d:

    # GRC "I've been completely honest with you about what I want."
    GRC "He sido completamente honesto contigo sobre lo que quiero."

# game/chapters/1_day.rpyc:1434
translate es call1_day1_b07a0ba3:

    # GRC "You just refuse to listen."
    GRC "Simplemente te niegas a escuchar."

# game/chapters/1_day.rpyc:1435
translate es call1_day1_3d46595c:

    # GRC "Perhaps listening is a skill you could work on in the afterlife."
    GRC "Quizás escuchar sea una habilidad en la que podrías trabajar en la otra vida."

# game/chapters/1_day.rpyc:1445
translate es call1_day1_008afe10_5:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:1449
translate es call1_day1_3b8e33af:

    # GRC "It would be unnecessary."
    GRC "Sería innecesario."

# game/chapters/1_day.rpyc:1453
translate es call1_day1_10bdcfdc:

    # GRC "It seems you do have some common sense \nburied in that head of yours."
    GRC "Parece que sí tienes algo de sentido común \nescondido en esa cabeza tuya."

# game/chapters/1_day.rpyc:1467
translate es call1_day1_6a5fc456:

    # GRC "Dear Lord, why did I get forced to deal with this one..."
    GRC "Querido Señor, ¿por qué me obligaron a lidiar con esto?"

# game/chapters/1_day.rpyc:1471
translate es call1_day1_6d2e0c42:

    # GRC "I have been one hundred percent truthful to you."
    GRC "He sido cien por ciento sincero contigo."

# game/chapters/1_day.rpyc:1480
translate es call1_day1_1942b5e4:

    # GRC "Sarcasm! Here I thought that was above your \nmortal mind."
    GRC "¡Sarcasmo! Y yo que pensaba que eso estaba por \nencima de tu mente mortal."

# game/chapters/1_day.rpyc:1482
translate es call1_day1_144fbf78:

    # GRC "Well done. I'm so impressed."
    GRC "Bien hecho. Estoy muy impresionado."

# game/chapters/1_day.rpyc:1485
translate es call1_day1_040d2302:

    # GRC "Really? How did you notice?"
    GRC "¿En serio? ¿Cómo te diste cuenta?"

# game/chapters/1_day.rpyc:1486
translate es call1_day1_e14a0f29:

    # GRC "You are truly infuriating, did you know that?"
    GRC "Eres realmente irritante, ¿lo sabías?"

# game/chapters/1_day.rpyc:1490
translate es call1_day1_372cfe9d:

    # GRC "It was not a compliment. Not even slightly."
    GRC "No era un cumplido. Ni siquiera un poco."

# game/chapters/1_day.rpyc:1497
translate es call1_day1_008afe10_6:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:1498
translate es call1_day1_4b920f92:

    # GRC "How did I get lumped in with someone so annoying..."
    GRC "¿Cómo terminé con alguien tan molesto...?"

# game/chapters/1_day.rpyc:1502
translate es call1_day1_9810cdfa:

    # GRC "Bedroom eyes? Is that what you call that?"
    GRC "¿Ojos seductores? ¿Así es como lo llaman?"

# game/chapters/1_day.rpyc:1504
translate es call1_day1_97274eff:

    # GRC "Stop wiggling your eyebrows."
    GRC "Deja de mover las cejas."

# game/chapters/1_day.rpyc:1505
translate es call1_day1_a2e936bd:

    # GRC "You're just embarrassing yourself. I don't see how those are supposed to be bedroom eyes."
    GRC "Solo estás haciendo el ridículo. No veo cómo se supone que esa es una mirada seductora."

# game/chapters/1_day.rpyc:1514
translate es call1_day1_990cc387:

    # GRC "Heh."
    GRC "Je."

# game/chapters/1_day.rpyc:1521
translate es call1_day1_9d56cd5b:

    # GRC "You longingly gaze into your death? A soul after my own heart, it seems."
    GRC "¿Contemplas con anhelo tu muerte? Un alma afín a la mía, al parecer."

# game/chapters/1_day.rpyc:1526
translate es call1_day1_ea99ec02:

    # GRC "Is that what that was supposed to be?"
    GRC "¿Era eso lo que se suponía que debía ser?"

# game/chapters/1_day.rpyc:1530
translate es call1_day1_6a21dccb:

    # GRC "Haaaa..."
    GRC "Haaaa..."

# game/chapters/1_day.rpyc:1532
translate es call1_day1_f44d9a82:

    # GRC "What did I do wrong in my past life to get stuck with you?"
    GRC "¿Qué hice mal en mi vida pasada para quedarme atrapado contigo?"

# game/chapters/1_day.rpyc:1537
translate es call1_day1_f2376f40:

    # GRC "You were supposed to."
    GRC "Se suponía que debías hacerlo."

# game/chapters/1_day.rpyc:1541
translate es call1_day1_f51c4738:

    # GRC "I didn't whisper it, did I?"
    GRC "No lo susurré, ¿verdad?"

# game/chapters/1_day.rpyc:1558
translate es call1_day1_9238e1d9:

    # GRC "What is {i}weird ass{/i} about my typing?"
    GRC "¿Qué tiene de {i}raro{/i} mi forma de escribir?"

# game/chapters/1_day.rpyc:1562
translate es call1_day1_938b1a85:

    # GRC "Explain yourself."
    GRC "Explícate."

# game/chapters/1_day.rpyc:1569
translate es call1_day1_0808f84a:

    # GRC "Yes, I know what capital letters are. I am not brainless, like yourself."
    GRC "Sí, sé lo que son las letras mayúsculas. No soy tonto, como tú."

# game/chapters/1_day.rpyc:1570
translate es call1_day1_59505b78:

    # GRC "I was using them, was I not?"
    GRC "Las estaba usando, ¿no?"

# game/chapters/1_day.rpyc:1577
translate es call1_day1_3be8bce7:

    # GRC "What are you talking about, mortal?"
    GRC "¿De qué estás hablando, mortal?"

# game/chapters/1_day.rpyc:1584
translate es call1_day1_008afe10_7:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:1588
translate es call1_day1_ae7b5860:

    # GRC "What in the nine circles of hell is a homestuck?"
    GRC "Por todos los demonios, ¿qué es un homestuck?"

# game/chapters/1_day.rpyc:1595
translate es call1_day1_b2ff9d9b:

    # GRC "What is it? I demand an answer."
    GRC "¿Qué es eso? Exijo una respuesta."

# game/chapters/1_day.rpyc:1602
translate es call1_day1_0f4cb13c:

    # GRC "What about my typing is so confusing to you?"
    GRC "¿Qué tiene mi forma de escribir que te confunde tanto?"

# game/chapters/1_day.rpyc:1609
translate es call1_day1_0c480906:

    # GRC "Is that not common?"
    GRC "¿No es eso común?"

# game/chapters/1_day.rpyc:1616
translate es call1_day1_ffd43f9f:

    # GRC "You mean to tell me..."
    GRC "Quieres decirme..."

# game/chapters/1_day.rpyc:1623
translate es call1_day1_e9261f9c:

    # GRC "...I do not type correctly..."
    GRC "...Que no escribo correctamente...."

# game/chapters/1_day.rpyc:1637
translate es call1_day1_8b295c59:

    # GRC "How embarrassing..."
    GRC "Qué vergonzoso..."

# game/chapters/1_day.rpyc:1639
translate es call1_day1_e9261f9c_1:

    # GRC "...I do not type correctly..."
    GRC "...No escribo bien..."

# game/chapters/1_day.rpyc:1657
translate es chat2_day1_e65f67ea:

    # player "What? What did you hang up for?"
    player "¿Qué? ¿Por qué colgaste?"

# game/chapters/1_day.rpyc:1660
translate es chat2_day1_864e88dc:

    # player "Hello?"
    player "¿Hola?"

# game/chapters/1_day.rpyc:1662
translate es chat2_day1_f2b91653:

    # player "Little reaper?"
    player "¿Parquita?"

# game/chapters/1_day.rpyc:1665
translate es chat2_day1_dfb65ca6:

    # player "Come on, I was finally having fun."
    player "Vamos, por fin me estaba divirtiendo."

# game/chapters/1_day.rpyc:1666
translate es chat2_day1_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpyc:1669
translate es chat2_day1_79edb30e:

    # player "Why'd you leave the call?"
    player "¿Por qué colgaste la llamada?"

# game/chapters/1_day.rpyc:1670
translate es chat2_day1_f51cd733:

    # GR "there is no particular reason."
    GR "no hay ninguna razón en particular."

# game/chapters/1_day.rpyc:1671
translate es chat2_day1_884d288e:

    # GR "none whatsoever."
    GR "ninguna en absoluto."

# game/chapters/1_day.rpyc:1674
translate es chat2_day1_f47f0c8b:

    # player "Um... I'm not trying to make fun of you or anything, but..."
    player "Um... No estoy tratando de burlarme de ti ni nada, pero..."

# game/chapters/1_day.rpyc:1677
translate es chat2_day1_fa420041:

    # player "It's still not right (lol)..."
    player "Sigue sin estar bien (lol)..."

# game/chapters/1_day.rpyc:1678
translate es chat2_day1_7772a27d_1:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpyc:1679
translate es chat2_day1_7772a27d_2:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpyc:1681
translate es chat2_day1_8a4f36a0:

    # player "That's wrong, too..."
    player "Eso también está mal..."

# game/chapters/1_day.rpyc:1682
translate es chat2_day1_7772a27d_3:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpyc:1683
translate es chat2_day1_7772a27d_4:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpyc:1686
translate es chat2_day1_5b8d36a4:

    # player "I guess I'll go, then."
    player "Supongo que me iré, entonces."

# game/chapters/1_day.rpyc:1688
translate es chat2_day1_315e1a38:

    # player "Well if you have nothing to say..."
    player "Bueno, si no tienes nada que decir..."

# game/chapters/1_day.rpyc:1691
translate es chat2_day1_209ae5db:

    # player "Guess I'll head to bed."
    player "Creo que me voy a la cama."

# game/chapters/1_day.rpyc:1693
translate es chat2_day1_3fcaecaf:

    # player "Don't Wanna Chat With Me Anymore, Little Reaper?"
    player "¿Ya No Quieres Charlar Conmigo, Parquita?"

# game/chapters/1_day.rpyc:1694
translate es chat2_day1_383a19ee:

    # GR "i have no clue why you're typing like that."
    GR "no tengo ni idea de por qué escribes así."

# game/chapters/1_day.rpyc:1695
translate es chat2_day1_775963c1:

    # GR "it is obviously incorrect."
    GR "obviamente es incorrecto."

# game/chapters/1_day.rpyc:1696
translate es chat2_day1_70f76c7e:

    # GR "who would type with so many capital letters? absurd."
    GR "¿quién escribiría con tantas letras mayúsculas? es absurdo."

# game/chapters/1_day.rpyc:1697
translate es chat2_day1_215eda05:

    # GR "you should be embarrassed."
    GR "deberías sentir vergüenza."

# game/chapters/1_day.rpyc:1698
translate es chat2_day1_0b16bee0:

    # GR "ahem."
    GR "ejém."

# game/chapters/1_day.rpyc:1726
translate es call2_day1_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:1750
translate es call2_day1_a6295b63:

    # GRC "I... am not 'little'."
    GRC "Yo... no soy 'pequeño'."

# game/chapters/1_day.rpyc:1751
translate es call2_day1_f3da69c8:

    # GRC "No part of me is!"
    GRC "¡Ninguna parte de mí lo es!"

# game/chapters/1_day.rpyc:1756
translate es call2_day1_0bac6bac:

    # GRC "......."
    GRC "......."

# game/chapters/1_day.rpyc:1764
translate es call2_day1_0f3a0c34:

    # GRC "Shut up..."
    GRC "Cállate..."

# game/chapters/1_day.rpyc:1766
translate es call2_day1_8cf301cb:

    # GRC "The way I type is unimportant to the matter at hand."
    GRC "La forma en la que escribo no es relevante para el tema que nos ocupa."

# game/chapters/1_day.rpyc:1767
translate es call2_day1_9e51cc19:

    # GRC "Just hand over the soul so we can be done with this."
    GRC "Solo entrega tu alma para que podamos terminar con esto."

# game/chapters/1_day.rpyc:1771
translate es call2_day1_0f2bae23:

    # GRC "No, mortal."
    GRC "No, mortal."

# game/chapters/1_day.rpyc:1773
translate es call2_day1_1efebc26:

    # GRC "There is no moving on until the deed is done."
    GRC "No se puede seguir adelante mientras no se haga lo que hay que hacer."

# game/chapters/1_day.rpyc:1800
translate es call2_day1_625791f5:

    # GRC "Do I look like a myth to you?"
    GRC "¿Parezco un mito para ti?"

# game/chapters/1_day.rpyc:1811
translate es call2_day1_793bf1ae:

    # GRC "And I'm telling you, I'm quite literally—"
    GRC "Y te lo digo, soy literalmente—"

# game/chapters/1_day.rpyc:1828
translate es call2_day1_d274607d:

    # GRC "A bet?"
    GRC "¿Una apuesta?"

# game/chapters/1_day.rpyc:1831
translate es call2_day1_f2abe32e:

    # GRC "You have my attention."
    GRC "Tienes mi atención."

# game/chapters/1_day.rpyc:1840
translate es call2_day1_dc34c302:

    # GRC "Continue."
    GRC "Continúa."

# game/chapters/1_day.rpyc:1847
translate es call2_day1_804c1377:

    # GRC "Correct. I have taken many souls."
    GRC "Correcto. He tomado muchas almas."

# game/chapters/1_day.rpyc:1851
translate es call2_day1_d7b7a711:

    # GRC "Oh? Intriguing."
    GRC "¿Oh? Intrigante."

# game/chapters/1_day.rpyc:1878
translate es call2_day1_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:1891
translate es call2_day1_282f4779:

    # GRC "And take it I shall."
    GRC "Y la tomaré."

# game/chapters/1_day.rpyc:1910
translate es call2_day1_6890af83:

    # GRC "A week? You shouldn't underestimate me."
    GRC "¿Una semana? No deberías subestimarme."

# game/chapters/1_day.rpyc:1912
translate es call2_day1_c3cb5ac3:

    # GRC "I need only a day. An hour."
    GRC "Solo necesito un día. Una hora."

# game/chapters/1_day.rpyc:1927
translate es call2_day1_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:1928
translate es call2_day1_25eec6b4:

    # GRC "Fine."
    GRC "Está bien."

# game/chapters/1_day.rpyc:1930
translate es call2_day1_68caee4c:

    # GRC "A week it shall be."
    GRC "Será una semana."

# game/chapters/1_day.rpyc:1931
translate es call2_day1_4bf74016:

    # GRC "I am honor bound by my very soul to accept the outcome of such a deal."
    GRC "Me siento obligado por mi honor y mi alma a aceptar el resultado de tal acuerdo."

# game/chapters/1_day.rpyc:1938
translate es call2_day1_6853ac46:

    # GRC "That remains to be seen."
    GRC "Eso está por verse."

# game/chapters/1_day.rpyc:1945
translate es call2_day1_e9acf97b:

    # GRC "What do you ask for?"
    GRC "¿Qué pides?"

# game/chapters/1_day.rpyc:1953
translate es call2_day1_da27a049:

    # GRC "My... soul?"
    GRC "¿Mi... alma?"

# game/chapters/1_day.rpyc:1954
translate es call2_day1_8a9d8e97:

    # GRC "I suppose... that makes it fair."
    GRC "Supongo... que eso lo hace justo."

# game/chapters/1_day.rpyc:1955
translate es call2_day1_6a0293cc:

    # GRC "I hadn't expected that anyone would ever come after my own soul, I must admit."
    GRC "Debo admitir que nunca pensé que alguien vendría a por mi alma."

# game/chapters/1_day.rpyc:1961
translate es call2_day1_d0db0967:

    # GRC "My... what?"
    GRC "¿Mi... qué?"

# game/chapters/1_day.rpyc:1962
translate es call2_day1_f383e2a2:

    # GRC "Why in the hells would you want that?"
    GRC "¿Por qué demonios ibas a querer eso?"

# game/chapters/1_day.rpyc:1966
translate es call2_day1_e47cd8b0:

    # GRC "Er, yes."
    GRC "Eh, sí."

# game/chapters/1_day.rpyc:1970
translate es call2_day1_d9c46b02:

    # GRC "Um... yes, I guess so...?"
    GRC "Um... sí, supongo que sí...?"

# game/chapters/1_day.rpyc:1987
translate es call2_day1_3a37b31e:

    # GRC "That... seems fair."
    GRC "Eso... parece justo."

# game/chapters/1_day.rpyc:1993
translate es call2_day1_f578e64e:

    # GRC "Hah."
    GRC "Ja."

# game/chapters/1_day.rpyc:1994
translate es call2_day1_e96d36a8:

    # GRC "Mortal, I am scared of nothing."
    GRC "Mortal, No le temo a nada."

# game/chapters/1_day.rpyc:2001
translate es call2_day1_008afe10_3:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:2003
translate es call2_day1_53f67e0c:

    # GRC "Ahem!"
    GRC "¡Ejém!"

# game/chapters/1_day.rpyc:2005
translate es call2_day1_47d3e691:

    # GRC "I agree to your deal."
    GRC "Acepto tu trato."

# game/chapters/1_day.rpyc:2006
translate es call2_day1_4eab4017:

    # GRC "If I cannot take your soul in the next week, then my soul shall belong to you."
    GRC "Si no puedo tomar tu alma en la próxima semana, entonces mi alma te pertenecerá."

# game/chapters/1_day.rpyc:2013
translate es call2_day1_43fe0693:

    # GRC "...Out of interest, what do you plan to do with it...?"
    GRC "...Por curiosidad, ¿qué piensas hacer ella...?"

# game/chapters/1_day.rpyc:2020
translate es call2_day1_a07ae720:

    # GRC "Eat it?!"
    GRC "¿Comértela?!"

# game/chapters/1_day.rpyc:2027
translate es call2_day1_19908011:

    # GRC "That is a {i}cat{/i} you are thinking of."
    GRC "Eso es un {i}gato{/i} en lo que estás pensando."

# game/chapters/1_day.rpyc:2031
translate es call2_day1_7dd3bdba:

    # GRC "Why do humans make such ridiculous assumptions?"
    GRC "¿Por qué los humanos hacen suposiciones tan ridículas?"

# game/chapters/1_day.rpyc:2041
translate es call2_day1_008afe10_4:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:2042
translate es call2_day1_dff64f19:

    # GRC "{i}You{/i} cannot even see a soul, let alone turn one into some kind of..."
    GRC "{i}Tú{/i} ni siquiera puedes ver un alma, y mucho menos convertirla en una especie de..."

# game/chapters/1_day.rpyc:2044
translate es call2_day1_7182bc03:

    # GRC "Soul smoothie."
    GRC "Batido de almas."

# game/chapters/1_day.rpyc:2045
translate es call2_day1_a52808cf:

    # GRC "I shouldn't have bothered asking you, honestly."
    GRC "Sinceramente, no debería haberte molestado en preguntarte."

# game/chapters/1_day.rpyc:2047
translate es call2_day1_07f23401:

    # GRC "I feel like that's on me."
    GRC "Siento que eso es culpa mía."

# game/chapters/1_day.rpyc:2055
translate es call2_day1_7572788b:

    # GRC "What nonsense are you spouting now?"
    GRC "¿Qué tonterías estás diciendo ahora?"

# game/chapters/1_day.rpyc:2059
translate es call2_day1_c732b942:

    # GRC "I heard what you said."
    GRC "Oí lo que dijiste."

# game/chapters/1_day.rpyc:2061
translate es call2_day1_7d556020:

    # GRC "I was honestly hoping I heard you wrong."
    GRC "Sinceramente, esperaba haberte escuchado mal."

# game/chapters/1_day.rpyc:2065
translate es call2_day1_2243608f:

    # GRC "Putting aside the fact that what you said is impossible..."
    GRC "Dejando de lado el hecho de que lo que dices es imposible..."

# game/chapters/1_day.rpyc:2067
translate es call2_day1_b39aca54:

    # GRC "I am {i}not{/i} ready to be a father."
    GRC "No estoy {i}listo{/i} para ser padre."

# game/chapters/1_day.rpyc:2074
translate es call2_day1_e8a6b4ce:

    # GRC "We absolutely will not be doing that."
    GRC "De ninguna manera lo haremos."

# game/chapters/1_day.rpyc:2076
translate es call2_day1_4d91f639:

    # GRC "It is of little concern, seeing as you will soon be yielding your soul to me."
    GRC "No importa, ya que pronto me entregarás tu alma."

# game/chapters/1_day.rpyc:2083
translate es call2_day1_b0775fc2:

    # GRC "For some reason that is just as strange."
    GRC "Por alguna razón que es igual de extraño."

# game/chapters/1_day.rpyc:2087
translate es call2_day1_8a4d38cc:

    # GRC "I suppose it's of little consequence."
    GRC "Supongo que no tiene mucha importancia."

# game/chapters/1_day.rpyc:2089
translate es call2_day1_a7dd6d6a:

    # GRC "You won't be getting it."
    GRC "No la vas a obtener."

# game/chapters/1_day.rpyc:2092
translate es call2_day1_9462be29:

    # GRC "Are you really that dim?"
    GRC "¿De verdad eres tan torpe?"

# game/chapters/1_day.rpyc:2094
translate es call2_day1_cca579cd:

    # GRC "Of course I do. You have no hope."
    GRC "Claro que sí. No tienes ninguna esperanza."

# game/chapters/1_day.rpyc:2096
translate es call2_day1_44eedd45:

    # GRC "Perhaps you should save us all some time and give up already."
    GRC "Quizás deberías ahorrarnos tiempo a todos y rendirte ya."

# game/chapters/1_day.rpyc:2107
translate es call2_day1_c86a5b29:

    # GRC "Keep telling yourself that, mortal."
    GRC "Sigue diciéndote eso, mortal."

# game/chapters/1_day.rpyc:2109
translate es call2_day1_8001ee91:

    # GRC "Your soul will be my ultimate prize."
    GRC "Tu alma será mi mayor premio."

# game/chapters/1_day.rpyc:2110
translate es call2_day1_a13b939f:

    # GRC "It will yield itself to me, and it will be beautiful."
    GRC "Se rendirá ante mí y será hermoso."

# game/chapters/1_day.rpyc:2114
translate es call2_day1_937991e6:

    # GRC "Taking a soul is never morbid."
    GRC "Tomar un alma nunca es morboso."

# game/chapters/1_day.rpyc:2124
translate es call2_day1_07ab7154:

    # GRC "...What?"
    GRC "...¿Qué?"

# game/chapters/1_day.rpyc:2135
translate es call2_day1_0e8fbc1b:

    # GRC "It's not a date!"
    GRC "¡No es una cita!"

# game/chapters/1_day.rpyc:2142
translate es call2_day1_6028f2d1:

    # GRC "I never lose."
    GRC "Nunca pierdo."

# game/chapters/1_day.rpyc:2153
translate es call2_day1_389380ee:

    # GRC "So, the human has a sadistic streak."
    GRC "Así que el humano tiene una faceta sádica.."

# game/chapters/1_day.rpyc:2161
translate es call2_day1_a1b92933:

    # GRC "You really know how to get under my skin."
    GRC "Realmente sabes cómo sacarme de quicio."

# game/chapters/1_day.rpyc:2165
translate es call2_day1_91330efa:

    # GRC "Ugh..."
    GRC "Ugh..."

# game/chapters/1_day.rpyc:2169
translate es call2_day1_92077c20:

    # GRC "Just... stop talking, please."
    GRC "Solo... deja de hablar, por favor."

# game/chapters/1_day.rpyc:2171
translate es call2_day1_b9e66a0d:

    # GRC "Your voice is beginning to grate me."
    GRC "Tu voz está empezando a molestarme."

# game/chapters/1_day.rpyc:2185
translate es call2_day1_008afe10_5:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:2187
translate es call2_day1_e48115d3:

    # GRC "You are the bane of my existence."
    GRC "Eres la pesadilla de mi vida."

# game/chapters/1_day.rpyc:2191
translate es call2_day1_4bd7a111:

    # GRC "You are... nothing special whatsoever!"
    GRC "¡No eres... nada especial en absoluto!"

# game/chapters/1_day.rpyc:2195
translate es call2_day1_ac37972a:

    # GRC "We will not."
    GRC "No lo haremos."

# game/chapters/1_day.rpyc:2199
translate es call2_day1_85fe5a7f:

    # GRC "Stop twisting my words to suit yourself, mortal."
    GRC "Deja de tergiversar mis palabras para que te convengan, mortal."

# game/chapters/1_day.rpyc:2203
translate es call2_day1_6716afc7:

    # GRC "How did it come to this..."
    GRC "¿Cómo llegó a esto..."

# game/chapters/1_day.rpyc:2213
translate es call2_day1_64d5125b:

    # GRC "This would have taken much less time if you had done as you were told."
    GRC "Esto habría llevado mucho menos tiempo si hubieras hecho lo que se te dijo."

# game/chapters/1_day.rpyc:2217
translate es call2_day1_32f44438:

    # GRC "Yes."
    GRC "Sí."

# game/chapters/1_day.rpyc:2221
translate es call2_day1_f24fdf68:

    # GRC "Well, perhaps you should."
    GRC "Bueno, quizás deberías."

# game/chapters/1_day.rpyc:2224
translate es call2_day1_b4ce3d52:

    # GRC "Somehow I doubt that."
    GRC "De alguna manera lo dudo."

# game/chapters/1_day.rpyc:2225
translate es call2_day1_1e5beb9b:

    # GRC "Next time, be a little more cooperative."
    GRC "La próxima vez, sé tan amable de cooperar un poco más."

# game/chapters/1_day.rpyc:2231
translate es call2_day1_b261ab05:

    # GRC "And if I asked you to hand over your soul again...?"
    GRC "¿Y si te pidiera que me entregaras tu alma otra vez...?"

# game/chapters/1_day.rpyc:2242
translate es call2_day1_c3dd6370:

    # GRC "Is this more of your so-called flirting?"
    GRC "¿Es esto más de tu supuesto coqueteo?"

# game/chapters/1_day.rpyc:2243
translate es call2_day1_083562fa:

    # GRC "It is lacking."
    GRC "Es insuficiente."

# game/chapters/1_day.rpyc:2247
translate es call2_day1_b7094880:

    # GRC "Mortal, you know nothing about me."
    GRC "Mortal, no sabes nada sobre mí."

# game/chapters/1_day.rpyc:2248
translate es call2_day1_119c12db:

    # GRC "And it shall stay that way."
    GRC "Y así seguirá siendo."

# game/chapters/1_day.rpyc:2256
translate es call2_day1_40b57ed9:

    # GRC "I {i}am{/i} the reaper. And that is all you will find out."
    GRC "Yo {i}soy{/i} la parca. Y eso es todo lo que sabrás."

# game/chapters/1_day.rpyc:2260
translate es call2_day1_0c459089:

    # GRC "No we will not."
    GRC "No, no lo haremos."

# game/chapters/1_day.rpyc:2264
translate es call2_day1_f6e68b39:

    # GRC "Of course I would, that's what I just told you."
    GRC "Por supuesto que sí, eso es lo que acabo de decirte."

# game/chapters/1_day.rpyc:2270
translate es call2_day1_3c1fd32e:

    # GRC "What is there to be confused about?"
    GRC "¿Qué tiene de confuso?"

# game/chapters/1_day.rpyc:2272
translate es call2_day1_ae5c1d5c:

    # GRC "Oh. Right."
    GRC "Oh. Cierto."

# game/chapters/1_day.rpyc:2273
translate es call2_day1_ec3c55be:

    # GRC "I see your mind has wandered into mortal fantasies."
    GRC "Veo que tu mente se ha perdido en fantasías mortales."

# game/chapters/1_day.rpyc:2280
translate es call2_day1_cdbc37f5:

    # GRC "I'm simply stating it would make my job easier."
    GRC "Simplemente digo que me facilitaría el trabajo."

# game/chapters/1_day.rpyc:2287
translate es call2_day1_ccf8442b:

    # GRC "Dealing with you certainly isn't."
    GRC "Tratar contigo ciertamente no lo es."

# game/chapters/1_day.rpyc:2291
translate es call2_day1_758b546f:

    # GRC "I disagree."
    GRC "No estoy de acuerdo."

# game/chapters/1_day.rpyc:2295
translate es call2_day1_b65da2d2:

    # GRC "I very strongly disagree."
    GRC "Estoy muy en desacuerdo."

# game/chapters/1_day.rpyc:2299
translate es call2_day1_3eb0aeda:

    # GRC "I'm disagreeing so hard that I could win some \nkind of award for the most someone has ever disagreed with a statement."
    GRC "Estoy tan en desacuerdo que podría ganar algún \ntipo de premio al mayor desacuerdo jamás expresado con respecto a una afirmación."

# game/chapters/1_day.rpyc:2309
translate es call2_day1_a01d3d13:

    # GRC "Absolutely not."
    GRC "Absolutamente no."

# game/chapters/1_day.rpyc:2313
translate es call2_day1_f4e2e0dd:

    # GRC "Somehow I knew you would respond like that."
    GRC "De alguna manera sabía que responderías así."

# game/chapters/1_day.rpyc:2314
translate es call2_day1_7a7dc1c8:

    # GRC "You really are ever so difficult."
    GRC "Eres realmente muy difícil."

# game/chapters/1_day.rpyc:2319
translate es call2_day1_f21effae:

    # GRC "Or you could refrain from being so... troublesome."
    GRC "O podrías dejar de crear tantos... problemas."

# game/chapters/1_day.rpyc:2322
translate es call2_day1_8007eaa2:

    # GRC "My job is never easy."
    GRC "Mi trabajo nunca es fácil."

# game/chapters/1_day.rpyc:2324
translate es call2_day1_ebc82d37:

    # GRC "Though it is also not usually this difficult."
    GRC "Aunque tampoco suele ser tan difícil como esto."

# game/chapters/1_day.rpyc:2328
translate es call2_day1_a6be069a:

    # GRC "Don't flatter yourself."
    GRC "No te hagas ilusiones."

# game/chapters/1_day.rpyc:2329
translate es call2_day1_d590c85c:

    # GRC "Being difficult does not make you important."
    GRC "Ser difícil no te hace importante."

# game/chapters/1_day.rpyc:2333
translate es call2_day1_6d74b146:

    # GRC "Special? You? That remains to be seen."
    GRC "¿Especial? ¿Tú? Eso aún está por verse."

# game/chapters/1_day.rpyc:2334
translate es call2_day1_900c7156:

    # GRC "At the moment you are just a pain in my side."
    GRC "En este momento solo eres un dolor de cabeza para mí."

# game/chapters/1_day.rpyc:2339
translate es call2_day1_008afe10_6:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:2340
translate es call2_day1_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/1_day.rpyc:2347
translate es call2_day1_b637bcf9:

    # GRC "Preposterous."
    GRC "¡Absurdo!"

# game/chapters/1_day.rpyc:2351
translate es call2_day1_0a2c4bf7:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/1_day.rpyc:2352
translate es call2_day1_f0503631:

    # GRC "I... I definitely am not agreeing!"
    GRC "¡Yo... definitivamente no estoy de acuerdo!"

# game/chapters/1_day.rpyc:2355
translate es call2_day1_e650137a:

    # GRC "What makes you think I want someone to boss me around?"
    GRC "¿Qué te hace pensar que quiero que alguien me dé órdenes?"

# game/chapters/1_day.rpyc:2359
translate es call2_day1_87a7d50d:

    # GRC "Lost... puppy vibes?"
    GRC "¿Vibras de cachorro perdido?"

# game/chapters/1_day.rpyc:2360
translate es call2_day1_1a2b5d27:

    # GRC "How so?"
    GRC "¿Cómo así?"

# game/chapters/1_day.rpyc:2374
translate es call2_day1_0c2759da:

    # GRC "The... the WHAT?"
    GRC "¿El... el QUÉ?"

# game/chapters/1_day.rpyc:2375
translate es call2_day1_65122790_1:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/1_day.rpyc:2376
translate es call2_day1_9b7d4b85:

    # GRC "I am... a Grim Reaper. A GRIM REAPER."
    GRC "Soy... Una Parca. UNA PARCA."

# game/chapters/1_day.rpyc:2378
translate es call2_day1_a607ee7b:

    # GRC "What about that makes me submissive?!"
    GRC "¿¡Qué tiene eso que me hace sumiso?!"

# game/chapters/1_day.rpyc:2379
translate es call2_day1_dd112d3b:

    # GRC "I am literally domineering! It is in my job description!"
    GRC "¡Soy literalmente dominante! ¡Está en la descripción de mi trabajo!"

# game/chapters/1_day.rpyc:2390
translate es call2_day1_0b084266:

    # GRC "And what if I don't do what you tell me to do?"
    GRC "¿Y si no hago lo que me dices que haga?"

# game/chapters/1_day.rpyc:2404
translate es call2_day1_55bdc250:

    # GRC "......"
    GRC "......"

# game/chapters/1_day.rpyc:2409
translate es call2_day1_403d04be:

    # GRC "You know what?"
    GRC "¿Sabes qué?"

# game/chapters/1_day.rpyc:2410
translate es call2_day1_4e502785:

    # GRC "Mortal, you are dismissed."
    GRC "Mortal, puedes retirarte."

# game/chapters/1_day.rpyc:2419
translate es call2_day1_a52dcb2a:

    # GRC "Do you not understand the word?"
    GRC "¿No entiendes la palabra?"

# game/chapters/1_day.rpyc:2420
translate es call2_day1_4508fa37:

    # GRC "You can go. Please."
    GRC "Puedes irte. Por favor."

# game/chapters/1_day.rpyc:2424
translate es call2_day1_356f27bd:

    # GRC "Yes, I usually have that effect on people."
    GRC "Sí, suelo causar ese efecto en la gente."

# game/chapters/1_day.rpyc:2426
translate es call2_day1_e987ea49:

    # GRC "But it is time for you to get your due rest."
    GRC "Pero es hora de que te tomes el descanso que te mereces."

# game/chapters/1_day.rpyc:2429
translate es call2_day1_cc50bc1a:

    # GRC "Then we could sit here all night chatting."
    GRC "Entonces podríamos quedarnos aquí toda la noche charlando."

# game/chapters/1_day.rpyc:2430
translate es call2_day1_68a9f86f:

    # GRC "I'm sure you would enjoy that."
    GRC "Estoy seguro de que lo disfrutarías."

# game/chapters/1_day.rpyc:2433
translate es call2_day1_43baa420:

    # GRC "Good. It is time for you to rest."
    GRC "Bien. Es hora de que descanses."

# game/chapters/1_day.rpyc:2439
translate es call2_day1_4ac61850:

    # GRC "You'll need your rest, else our competition won't be as fun."
    GRC "Necesitarás descansar, de lo contrario nuestra competencia no será tan divertida."

# game/chapters/1_day.rpyc:2443
translate es call2_day1_008afe10_7:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpyc:2447
translate es call2_day1_f79678dc:

    # GRC "Sleep well, [playerfirstname]."
    GRC "Duerme bien, [playerfirstname]."

# game/chapters/1_day.rpyc:2469
translate es chat3_day1_755c70f2:

    # player "Hey, wait a second..."
    player "Oye, espera un segundo..."

# game/chapters/1_day.rpyc:2472
translate es chat3_day1_ebb4b119:

    # player "How did you know my name?"
    player "¿Cómo supiste mi nombre?"

# game/chapters/1_day.rpyc:2473
translate es chat3_day1_1e97ab72:

    # GR "how indeed."
    GR "cómo, de hecho."

# game/chapters/1_day.rpyc:2476
translate es chat3_day1_c2d7dd9c:

    # player "I never told you!"
    player "¡Nunca te lo dije!"

# game/chapters/1_day.rpyc:2477
translate es chat3_day1_5d7104e6:

    # GR "wow, i wonder how exactly i could have known, then."
    GR "wow, me pregunto cómo exactamente podría haberlo sabido, entonces."

# game/chapters/1_day.rpyc:2478
translate es chat3_day1_2114d1c4:

    # GR "it's not like i have a big list sitting in front of me with your name circled at the bottom."
    GR "no es que tenga una gran lista delante de mí con tu nombre marcado con un círculo al final."

# game/chapters/1_day.rpyc:2481
translate es chat3_day1_54eadd4a:

    # player "Aw, you circled it?"
    player "Aw, ¿lo marcaste con un círculo?"

# game/chapters/1_day.rpyc:2482
translate es chat3_day1_5124b3f0:

    # GR "good. night."
    GR "buenas. noches."

# game/chapters/1_day.rpyc:2485
translate es chat3_day1_725cd3d2:

    # player "Night!"
    player "¡Buenas noches!"

# game/chapters/1_day.rpyc:2488
translate es chat3_day1_104f4b19:

    # player "Sleep well, grimmy :)"
    player "Duerme bien, Parquita :)"

# game/chapters/1_day.rpyc:2491
translate es chat3_day1_7a684a72:

    # player "Oh, wait, can I change my username?"
    player "Oh, espera, ¿puedo cambiar mi nombre de usuario?"

# game/chapters/1_day.rpyc:2492
translate es chat3_day1_9fd9a76d:

    # GR "why?"
    GR "¿por qué?"

# game/chapters/1_day.rpyc:2495
translate es chat3_day1_bbbf5b0d:

    # player "I just want to."
    player "Solo quiero."

# game/chapters/1_day.rpyc:2496
translate es chat3_day1_ed39b66e:

    # GR "hm. yes, i suppose you can."
    GR "hm. sí, supongo que puedes."

# game/chapters/1_day.rpyc:2499
translate es chat3_day1_8d438dd7:

    # player "Wow, easier to convince than I expected."
    player "Wow, más fácil de convencer de lo que esperaba."

# game/chapters/1_day.rpyc:2500
translate es chat3_day1_2773bb6d:

    # GR "did you want me to say no or something...?"
    GR "¿querías que dijera que no o algo...?"

# game/chapters/1_day.rpyc:2503
translate es chat3_day1_a81bb0d1:

    # player "This one is kinda lame."
    player "Este es un poco patético."

# game/chapters/1_day.rpyc:2504
translate es chat3_day1_3b2dd9f7:

    # GR "lame? it is not lame."
    GR "¿patético? no es patético."

# game/chapters/1_day.rpyc:2505
translate es chat3_day1_cbee77fc:

    # GR "it represents how many souls i claimed before yours."
    GR "representa cuántas almas reclamé antes que la tuya."

# game/chapters/1_day.rpyc:2506
translate es chat3_day1_5f29e88a:

    # GR "it is a badge of honor."
    GR "es una insignia de honor."

# game/chapters/1_day.rpyc:2509
translate es chat3_day1_8bfe1463:

    # player "But can I change it or not?"
    player "¿Pero puedo cambiarlo o no?"

# game/chapters/1_day.rpyc:2510
translate es chat3_day1_55690088:

    # GR "...fine."
    GR "...está bien."

# game/chapters/1_day.rpyc:2513
translate es chat3_day1_d671ed7e:

    # player "What about my picture?"
    player "¿Y mi foto?"

# game/chapters/1_day.rpyc:2514
translate es chat3_day1_f1cf95b6:

    # GR "you're a needy little thing, aren't you?"
    GR "eres una cosita necesitada, ¿no?"

# game/chapters/1_day.rpyc:2517
translate es chat3_day1_8f517da0:

    # player "Just for you ;)"
    player "Solo por ti ;)."

# game/chapters/1_day.rpyc:2518
translate es chat3_day1_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpyc:2519
translate es chat3_day1_600c02d1:

    # GR "...fine. i have turned on the feature for you."
    GR "...está bien. he activado la función para ti."

# game/chapters/1_day.rpyc:2522
translate es chat3_day1_e62511d6:

    # player "Aren't these basic messaging app features?"
    player "¿No son esas las funciones básicas de una aplicación de mensajería?"

# game/chapters/1_day.rpyc:2523
translate es chat3_day1_3f7ad2f6:

    # GR "oh."
    GR "oh."

# game/chapters/1_day.rpyc:2524
translate es chat3_day1_39581029:

    # GR "then yes, of course you can."
    GR "entonces sí, por supuesto que puedes."

# game/chapters/1_day.rpyc:2525
translate es chat3_day1_d2e7cd19:

    # GR "obviously. this program lacks in absolutely no ways."
    GR "obviamente. a este programa no le falta nada."

# game/chapters/1_day.rpyc:2534
translate es chat4_day1_f13f595c:

    # player "Thanks grimmy. Night night!"
    player "Gracias Parquita. ¡Buenas noches!"

# game/chapters/1_day.rpyc:2536
translate es chat4_day1_425ac1e8:

    # GR "you can click your little picture to change it whenever now."
    GR "puedes hacer clic en tu foto para cambiarla cuando quieras."

# game/chapters/1_day.rpyc:2537
translate es chat4_day1_3e685698:

    # GR "yes, i work that quickly. you may be impressed."
    GR "sí, trabajo así de rápido. Quizás te sorprenda."

# game/chapters/1_day.rpyc:2538
translate es chat4_day1_216bd8ec:

    # GR "enjoy."
    GR "disfruta."

# game/chapters/1_day.rpyc:2542
translate es chat4_day1_8a01d354:

    # GR "night."
    GR "noche."

translate es strings:

    old "1. <Is that an offer?>"
    new "1. <¿Eso es una oferta?>"

    old "1. <Uh... if you don't get it, don't worry about it.>"
    new "1. <Eh... si no lo pillas, no te preocupes.>"

    old "1. <You know what, nevermind.>"
    new "1. <¿Sabes qué? Olvídalo.>"

    old "1. <Or what?>"
    new "1. <¿O qué?>"

    old "1. <Isn't that what you threatened me with anyway?>"
    new "1. <¿No es eso lo que me amenazaste de todas formas?>"

    old "1. <For... me?>"
    new "1. <¿Por... mí?>"

    old "1. <Kinda creepy, ngl...>"
    new "1. <Un poco espeluznante, no lo voy a negar...>"

    old "1. <Since you installed it on my computer illegally.>"
    new "1. <Desde que la instalaste en mi ordenador ilegalmente.>"

    old "1. <Nice job.>"
    new "1. <Buen trabajo.>"

    old "1. <But still...>"
    new "1. <Pero aún así...>"

    old "1. <That was one hell of an introduction.>"
    new "1. <Esa fue una introducción impactante.>"

    old "1. <Er, what?>"
    new "1. <Eh, ¿qué?>"

    old "1. <I don't even know you.>"
    new "1. <Ni siquiera te conozco.>"

    old "1. <Right....>"
    new "1. <Bien....>"

    old "1. <Well, don't let me take up your precious time!>"
    new "1. <Bueno, ¡no me hagas quitarte tu precioso tiempo!>"

    old "1. <Off you go!>"
    new "1. <¡Vete!>"

    old "1. <That makes me want to ignore you.>"
    new "1. <Eso me da ganas de ignorarte.>"

    old "1. <Too bad. You were too eager.>"
    new "1. <Qué pena. Te precipitaste demasiado.>"

    old "1. <There's unspoken rules to texting people.>"
    new "1. <Hay reglas no escritas para enviarle mensajes a la gente.>"

    old "1. <Or in this case, messaging them through suspicious apps.>"
    new "1. <O, en este caso, para enviarles mensajes a través de aplicaciones sospechosas.>"

    old "1. <Nope.>"
    new "1. <Nop.>"

    old "1. <Sure... anyway...>"
    new "1. <Claro... en fin...>"

    old "1. <{i}Delete the app... again.{/i}>"
    new "1. <{i}Eliminar la aplicación... otra vez.{/i}>"

    old "1. <{i}Delete. The. App.{/i}>"
    new "1. <{i}Eliminar. La. Aplicación.{/i}>"

    old "1. <Your order total is $641.30.>"
    new "1. <El total de su pedido es $641.30.>"

    old "1. <To finalize your order, please hit 1.>"
    new "1. <Para finalizar su pedido, por favor presione 1.>"

    old "1. <To cancel your order, please hit 2.>"
    new "1. <Para cancelar su pedido, por favor presione 2.>"

    old "1. <Thank you for your purchase. Your order is now being finalized.>"
    new "1. <Gracias por su compra. Su pedido ahora está siendo finalizado.>"

    old "1. <To order again, please select YES.>"
    new "1. <Para realizar un nuevo pedido, por favor seleccione SI.>"

    old "1. <Thank you for your order. Your account has been charged a total of $3491.60.>"
    new "1. <Gracias por su pedido. Su cuenta ha sido cargada con un total de $3491.60.>"

    old "1. <Idiot.>"
    new "1. <Idiota.>"

    old "1. <It's not my fault you're so easily fooled.>"
    new "1. <No es mi culpa que te dejes engañar tan fácilmente.>"

    old "1. <Seriously, is this a virus or something...?>"
    new "1. <En serio, ¿esto es un virus o algo...?>"

    old "1. <Okay, but...>"
    new "1. <Bueno, pero...>"

    old "1. <For...?>"
    new "1. <¿Para...?>"

    old "1. <Why?>"
    new "1. <¿Por qué?>"

    old "1. <I don't even know who you are.>"
    new "1. <Ni siquiera sé quién eres.>"

    old "1. <It's a little strange to message a random [girl] out of nowhere.>"
    new "1. <Es un poco raro escribirle a un[girl!t]  al azar de la nada.>"

    old "1. <Okay, getting creepier.>"
    new "1. <Vale, esto se pone más raro.>"

    old "1. <Do I know you from somewhere, then?>"
    new "1. <¿Te conozco de algún lado, entonces?>"

    old "1. <You know. A bot.>"
    new "1. <Espera, ¿eres un bot?>"

    old "1. <Beep beep.>"
    new "1. <Bip bip.>"

    old "1. <Sounds like something a bot would say.>"
    new "1. <Suena como algo que diría un bot.>"

    old "1. <Robot say huh?>"
    new "1. <¿El Robot dice eh?>"

    old "1. <Gotcha.>"
    new "1. <Te Atrapé.>"

    old "1. <Why are you here then?>"
    new "1. <¿Entonces por qué estás aquí?>"

    old "1. <Yeah, you said that once or twice...>"
    new "1. <Sí, eso lo dijiste una o dos veces...>"

    old "1. <Is this a call for help?>"
    new "1. <¿Es esto una llamada de ayuda?>"

    old "1. <Sorry, one more time? You're cutting out.>"
    new "1. <Perdón, ¿otra vez? Se corta la señal.>"

    old "1. <Man, really bad reception here.>"
    new "1. <Hombre, la recepción aquí es realmente mala.>"

    old "1. <Can't make out what you're saying at all.>"
    new "1. <No entiendo nada de lo que dices.>"

    old "1. <Are you trying to threaten me or something?>"
    new "1. <¿Intentas amenazarme o algo?>"

    old "1. <Uh, and this job is...?>"
    new "1. <Eh, ¿y este trabajo es...?>"

    old "1. <I don't care that much...>"
    new "1. <No me importa tanto...>"

    old "1. <...Fine, please tell me.>"
    new "1. <...Está bien, por favor dime.>"

    old "1. <Nah, not really. I'm just messing with you.>"
    new "1. <Nah, no realmente. Solo te estoy tomando el pelo.>"


    old "1. <Uh huh. Sure I will.>"
    new "1. <Eh ajá. Seguro que sí.>"

    old "1. <And this true form is...?>"
    new "1. <¿Y esa verdadera forma es...?>"

    old "1. <Right.>"
    new "1. <Cierto.>"

    old "1. <Cool.>"
    new "1. <Genial.>"

    old "1. <Totally reasonable thing to say to someone.>"
    new "1. <Algo totalmente razonable para decirle a alguien.>"



    old "1. <Maybe because it is?>"
    new "1. <¿Quizás porque lo es?>"

    old "1. <I don't give my soul to just anyone, you know.>"
    new "1. <No entrego mi alma a cualquiera, ¿Sabes?>"

    old "1. <I had that in my job description once, too.>"
    new "1. <Yo también tuve eso en mi descripción de trabajo una vez.>"

    old "1. <No, I just worked retail.>"
    new "1. <No, Yo solo trabajaba en comercio minorista.>"

    old "1. <There was this one time when I got a message from a 'time-traveling astronaut'.>"
    new "1. <Hubo una vez en que recibí un mensaje de un 'Astronauta viajero del Tiempo'.>"

    old "1. <Said I had to wire them money to preserve the space-time continuum.>"
    new "1. <Decía que tenía que transferirles dinero para preservar el continuo espacio-tiempo.>"

    old "1. <Somehow I'm not surprised that you would fall for that.>"
    new "1. <De alguna manera no me sorprende que hayas caído en eso.>"

    old "1. <Well, I hope it was...>"
    new "1. <Bueno, Eso espero...>"

    old "1. <I'll keep that in mind.>"
    new "1. <Lo tendré en cuenta.>"

    old "1. <I have to ask, is this a roleplay?>"
    new "1. <Tengo una pregunta, ¿Esto es un roleplay?>"

    old "1. <Like, you're pretending to be the grim reaper...>"
    new "1. <Como si estuvieras fingiendo ser la parca...>"

    old "1. <And you want me to be...>"
    new "1. <Y quieres que yo sea...>"

    old "1. <Your enemies-to-lovers sweetheart?>"
    new "1. <¿Tu pareja de 'enemies-to-lovers'?>"

    old "1. <That's a shame.>"
    new "1. <Qué lástima.>"

    old "1. <I used to be one hell of a roleplayer, back in the day.>"
    new "1. <Solía ser una máquina del roleplay, en mis tiempos.>"

    old "1. <Maybe because you're literally a stranger on the internet?>"
    new "1. <Quizá porque literalmente eres un desconocido de internet?>"

    old "1. <But most people don't claim to be a mythological creature.>"
    new "1. <Pero la mayoría de la gente no afirma ser una criatura mitológica.>"

    old "1. <Well, you're spouting all of this nonsense.>"
    new "1. <Bueno, estás diciendo todas estas tonterías.>"

    old "1. <I thought it might be a call for help...?>"
    new "1. <Pensé que podría ser un llamado de auxilio...?>"

    old "1. <Mmm, not really a fan...>"
    new "1. <Mmm, no soy muy fan...>"

    old "1. <And if I said no?>"
    new "1. <¿Y si digo que no?>"

    old "1. <Being laughed at, or losing my soul...>"
    new "1. <Que se rían de mí o perder mi alma...>"

    old "1. <Tough decision.>"
    new "1. <Difícil decisión>"

    old "1. <You know...>"
    new "1. <Sabes...>"

    old "1. <{i}You owe $5000 in taxes... payment taken in gift cards.{/i}>"
    new "1. <{i}Debes $5000 en impuestos... pago aceptado en tarjetas de regalo.{/i}>"

    old "1. <No, dumbo, that's the scam.>"
    new "1. <No, idiota, esa es la estafa.>"

    old "1. <If I was, I'd be rich off you alone.>"
    new "1. <Si lo fuera, tendría millones solo contigo.>"

    old "1. <But I was serious about your taxes.>"
    new "1. <Pero hablaba en serio sobre tus impuestos.>"

    old "1. <The tax agency sent me.>"
    new "1. <La agencia tributaria me envió.>"

    old "1. <Send me your cc number and the three whacky numbers on the back, quick.>"
    new "1. <Envíame tu número de tarjeta de crédito Y los tres números raros de atrás, rápido.>"

    old "1. <Or you're going to prison, buddy.>"
    new "1. <O vas a ir a la cárcel, amigo.>"

    old "1. <Dead serious.>"
    new "1. <Completamente en serio.>"

    old "1. <WOAH...>"
    new "1. <WOAH...>"

    old "1. <Okay I don't actually want your details.>"
    new "1. <Vale, en realidad no quiero tus datos.>"

    old "1. <I was joking.>"
    new "1. <Estaba bromeando.>"

    old "1. <But you believed me, didn't you?>"
    new "1. <No, te estoy tomando el pelo otra vez.>"

    old "1. <Look, as fun as messing with you is...>"
    new "1. <Mira, por muy divertido que sea molestarte...>"

    old "1. <Should I post it via mail?>"
    new "1. <¿Debería enviarlo por correo?>"

    old "1. <Trust me, you can.>"
    new "1. <Créeme, sí se puede>"

    old "1. <I send souls all the time.>"
    new "1. <Envío almas todo el tiempo.>"

    old "1. <You'll just have to wait and see.>"
    new "1. <Tendrás que esperar y ver.>"

    old "1. <What gave me away?>"
    new "1. <¿Qué me delató?>"


    old "1. <Are you sure about that?>"
    new "1. <¿Estás seguro de eso?>"

    old "1. <But have you ever tried?>"
    new "1. <¿Pero alguna vez lo intentaste?>"

    old "1. <Pffffft....>"
    new "1. <Pffffft....>"

    old "1. <Your email...>"
    new "1. <Tu correo...>"

    old "1. <Sure...>"
    new "1. <Claro...>"

    old "1. <Okay, I just emailed my soul over.>"
    new "1. <Bien, acabo de enviar mi alma por correo.>"

    old "1. <Maybe you're having internet issues.>"
    new "1. <Quizás tengas problemas de Internet.>"

    old "1. <Restart your computer?>"
    new "1. <¿Reiniciaste tu ordenador?>"

    old "1. <Honestly...>"
    new "1. <Honestamente...>"

    old "1. <I don't usually respond to spam messages like this.>"
    new "1. <Normalmente no respondo a mensajes de spam como este.>"

    old "1. <Now I'm thinking I should?>"
    new "1. <¿Ahora pienso que debería hacerlo?>"

    old "1. <Anyway, do you seriously think you're the 'grim reaper'?>"
    new "1. <De todos modos, ¿De verdad te crees 'La Parca'?>"

    old "1. <It's funny, at least...?>"
    new "1. <¿Es gracioso, al menos...?>"

    old "1. <You've made me laugh, so that's nice.>"
    new "1. <Me has hecho reír, así que está bien.>"

    old "1. <You should try being less funny then, lol>"
    new "1. <Entonces deberías intentar ser menos gracioso, lol>"

    old "1. <Pretty much everything.>"
    new "1. <Prácticamente todo.>"

    old "1. <No... embarrassing, and annoying.>"
    new "1. <No... vergonzoso y molesto.>"

    old "1. <But who just installs a program on someones computer like that?>"
    new "1. <¿Pero quién instala un programa en la computadora de alguien así como así?>"

    old "1. <Are you that desperate for attention?>"
    new "1. <¿Tan desesperado estás por llamar la atención?>"

    old "1. <It makes me feel sad for you.>"
    new "1. <Me da pena por ti.>"

    old "1. <Dude...>"
    new "1. <Amigo...>"

    old "1. <You're the one harrassing me.>"
    new "1. <Tú eres el que me está acosando.>"

    old "1. <Nobody is forcing you to be here.>"
    new "1. <Nadie te obliga a estar aquí.>"

    old "1. <Forever?>"
    new "1. <¿Para Siempre?>"

    old "1. <Forever and ever?>"
    new "1. <¿Siempre y para siempre?>"

    old "1. <You know I can just leave this chat whenever I want, right?>"
    new "1. <Sabes que puedo salir de este chat cuando quiera, ¿verdad?>"

    old "1. <Then you'd be sitting in chat all alone.>"
    new "1. <Entonces estarías chateando completamente solo.>"

    old "1. <Mister 'Grim Reaper' (lol)>"
    new "1. <Señor 'Parca' (lol)>"

    old "1. <Yeah. In a weird way.>"
    new "1. <Sí. De una forma rara.>"

    old "1. <Well, it could be that you keep saying things like...>"
    new "1. <Bueno, podría ser que sigas diciendo cosas como...>"

    old "1. <I Have Come To Eat Your Soul!>"
    new "1. <¡He Venido A Devorar Tu Alma!>"

    old "1. <You did.>"
    new "1. <Lo hiciste.>"

    old "1. <{i}Delete Chatlog{/i}>"
    new "1. <{i}Eliminar historial de chat{/i}>"

    old "1. <Neither do you, little mister grim reaper.>"
    new "1. <Tú tampoco, señorito Parca>"

    old "1. <Are you trying to steal my job?>"
    new "1. <¿Estás tratando de robarme mi trabajo?>"

    old "1. <That is super {i}not{/i} cool.>"
    new "1. <Es súper {i}no{/i} cool.>"

    old "1. <I Am The Grim Reaper!>"
    new "1. <¡Yo Soy La Parca!>"

    old "1. <No, You Are Not!>"
    new "1. <¡No, Tú No Eres!>"

    old "1. <The 1st rule of Grim Reaper club - don't talk about Grim Reaper club.>"
    new "1. <La primera regla del club de Las parcas — no hablar del club de Las Parcas>"

    old "1. <How reasonable of you.>"
    new "1. <Qué razonable de tu parte.>"

    old "1. <You're a funny little 'grim reaper' lol>"
    new "1. <Eres una 'Parquita' divertida, lol>"

    old "1. <It's, well... a little embarrassing.>"
    new "1. <Es, bueno... un poco vergonzoso.>"

    old "1. <Wait, wait, wait, quick question.>"
    new "1. <Espera, espera, espera, pregunta rápida.>"

    old "1. <Do you walk around being like '{i}I AM DEATH{/i}'? in real life, too?>"
    new "1. <¿Acaso caminas por ahí diciendo '{i}YO SOY LA MUERTE{/i}'? ¿En la vida real también?>"

    old "1. <'{i}Bow down to me...! Your soul is mine...!{/i}'>"
    new "1. <'{i}Inclínate ante mí...! ¡Tu alma es mía...!{/i}'>"

    old "1. <You do, don't you?>"
    new "1. <¿Lo haces, verdad?>"

    old "1. <Stunned silence?>"
    new "1. <¿Silencio absoluto?>"

    old "1. <Is your hair as dark as night? Do you hide behind long bangs?>"
    new "1. <¿Tu cabello es tan oscuro como la noche? ¿Te escondes detrás de un flequillo largo?>"

    old "1. <I can relate to that, at least.>"
    new "1. <Al menos, puedo identificarme con eso.>"

    old "1. <I think I can imagine you completely.>"
    new "1. <Creo que puedo imaginarte perfectamente.>"

    old "1. <It's a funny thought... hehe.>"
    new "1. <Es una idea divertida... jeje.>"

    old "1. <'{i}Give me your soul! Your soul is mine for the harvesting!{/i}'>"
    new "1. <'{i}¡Dame tu alma! ¡Tu alma es mía para cosecharla!{/i}'>"

    old "1. <'{i}It will be a three course meal!{/i}'.>"
    new "1. <'{i}¡Será una comida de tres platos!{/i}'>"

    old "1. <Did I hurt the scammer's feelings?>"
    new "1. <¿Hice daño a tus sentimientos de estafador?>"

    old "1. <Have I hurt your little dead heart?>"
    new "1. <¿Le he hecho daño a tu corazoncito muerto?>"

    old "1. <The grim reaper is like...>"
    new "1. <La parca es como...>"

    old "1. <A skeleton, right?>"
    new "1. <Un esqueleto, ¿no?>"

    old "1. <Hey...>"
    new "1. <Oye...>"

    old "1. <Since reaping souls is your job and all, I have a question.>"
    new "1. <Ya que tu trabajo consiste en cosechar almas, tengo una pregunta.>"

    old "1. <Do you...>"
    new "1. <¿Tú...>"

    old "1. <Make a killing? :)>"
    new "1. <Ganas mucho dinero? :)>"

    old "1. <I'm quivering just thinking about it.>"
    new "1. <Estoy temblando solo de pensarlo.>"

    old "1. <Not in a weird way.>"
    new "1. <No de una manera extraña.>"

    old "1. <Fine.>"
    new "1. <Está bien.>"

    old "1. <Video call me, then.>"
    new "1. <Hazme una videollamada, entonces.>"

    old "1. <Unless the little '{i}weaper{/i}' is too scared?>"
    new "1. <¿A menos que la '{i}parquita{/i}' tenga demasiado miedo?>"

    old "1. <It's all kind of... edgy.>"
    new "1. <Es todo como... edgy.>"

    old "1. <Every single thing you say.>"
    new "1. <Cada una de tus palabras.>"

    old "1. <See!>"
    new "1. <¡Mira!>"

    old "1. <This is not how you pick up people, you know.>"
    new "1. <Así no es como se seduce a la gente, ¿sabes?>"

    old "1. <Exactly.>"
    new "1. <Exacto.>"

    old "1. <I dunno... I'm kinda attached to it.>"
    new "1. <No sé... Le tengo cierto cariño.>"

    old "1. <Sorry, I'm gonna have to pass.>"
    new "1. <Lo siento, voy a tener que pasar.>"

    old "1. <What are you going to do about it?>"
    new "1. <¿Qué vas a hacer al respecto?>"

    old "1. <Oh shit.>"
    new "1. <Oh, mierda.>"

    old "1. <Who said I had no bite?>"
    new "1. <¿Quién dijo que no mordía?>"

    old "1. <You're the one that said I had a lovely face.>"
    new "1. <Tú eres quien dijo que tenía una cara preciosa.>"

    old "1. <You did!>"
    new "1. <¡Lo hiciste!>"

    old "1. <Oh, I just did.>"
    new "1. <Ah, ya lo hice.>"

    old "1. <Yep, still hot.>"
    new "1. <Síp, sigue siendo sexy.>"

    old "1. <But you really don't look at all like I pictured.>"
    new "1. <Pero realmente no te pareces en nada a lo que \nme imaginaba.>"

    old "1. <Your hair is... as white as snow.>"
    new "1. <Tu cabello es... tan blanco como la nieve.>"

    old "1. <It doesn't exactly scream '{i}I am the reaper, \ngive me your soul{/i}'.>"
    new "1. <No es que grite precisamente '{i}Soy la muerte, \ndame tu alma{/i}'.>"

    old "1. <Shadows?>"
    new "1. <¿Sombras?>"

    old "1. <Darkness?>"
    new "1. <¿Oscuridad?>"

    old "1. <Evilness?>"
    new "1. <¿Maldad?>"

    old "1. <That sorta thing, I suppose.>"
    new "1. <Algo así, supongo.>"

    old "1. <Well, no, cause...>"
    new "1. <Bueno, no, porque...>"

    old "1. <How do I say this...>"
    new "1. <Cómo decirlo...>"

    old "1. <No? What word would you use then?>"
    new "1. <¿No? ¿Qué palabra usarías entonces?>"

    old "1. <Someone seems to be very sure of himself.>"
    new "1. <Alguien parece estar muy seguro de sí mismo.>"

    old "1. <I {i}really{/i} was picturing jet black hair, though.>"
    new "1. <Sin embargo, {i}realmente{/i} me imaginaba un \ncabello negro azabache.>"

    old "1. <Is it usually black? Do you bleach it or something?>"
    new "1. <¿Normalmente es negro? ¿Lo blanqueas o algo así?>"

    old "1. <So that's all... natural?>"
    new "1. <¿Entonces todo eso es... natural?>"

    old "1. <Well, you are cute!>"
    new "1. <¡Vaya, qué lindo eres!>"

    old "1. <I think you're plenty cute.>"
    new "1. <Creo que eres muy lindo.>"

    old "1. <Move over and I'll look at your room instead.>"
    new "1. <Hazte a un lado y veré tu habitación.>"

    old "1. <You're no fun.>"
    new "1. <No eres nada divertido.>"

    old "1. <Then I'll just have to sit here and inspect you.>"
    new "1. <Entonces tendré que sentarme aquí y inspeccionarte.>"

    old "1. <Well, you aren't exactly {i}reaper{/i} like, are you?>"
    new "1. <Bueno, no eres exactamente como {i}la Parca{/i}, ¿verdad?>"

    old "1. <Let me rephrase.>"
    new "1. <Déjame reformularlo.>"

    old "1. <You don't look like a grim reaper, at all.>"
    new "1. <No pareces la parca, en absoluto.>"

    old "1. <Which means...>"
    new "1. <Lo que significa...>"

    old "1. <You belong to me too, right?>"
    new "1. <Tú también me perteneces, ¿verdad?>"

    old "1. <I don't mind sharing.>"
    new "1. <No me importa compartir.>"

    old "1. <No need to be flustered.>"
    new "1. <No hay que ponerse nervioso.>"


    old "1. <You don't really have an aura of death \nsurrounding you.>"
    new "1. <En realidad no tienes aura de la muerte \na tu alrededor.>"

    old "1. <Your {i}deathly{/i} aura, so to speak, is lacking.>"
    new "1. <Te falta tu aura {i}macabra{/i}, por así decirlo.>"

    old "1. <I feel like that's something a {i}reaper{/i} would have.>"
    new "1. <Siento que eso es algo que tendría {i}la Parca{/i}.>"

    old "1. <Thanks, my little Reaper.>"
    new "1. <Gracias, mi Parquita>"

    old "1. <So, you admit it?>"
    new "1. <¿Entonces lo admites?>"

    old "1. <You...>"
    new "1. <Tú...>"

    old "1. <Are just a normal dude.>"
    new "1. <Eres un tipo normal.>"

    old "1. <That you're the grim reaper?>"
    new "1. <¿Que eres la Parca?>"

    old "1. <The thing is... I don't believe you.>"
    new "1. <El caso es que... no te creo.>"

    old "1. <Why are you acting so surprised?>"
    new "1. <¿Por qué te sorprendes tanto?>"

    old "1. <Of course I'm not gonna believe you.>"
    new "1. <Claro que no te voy a creer.>"


    old "1. <Are you trying to make me laugh?>"
    new "1. <¿Estás tratando de hacerme reír?>"

    old "1. <I'm not really interested in being whisked off \ninto the afterlife, or whatever you're offering.>"
    new "1. <No me interesa mucho que me lleven al más allá, \no lo que sea que estés ofreciendo.>"

    old "1. <Nor am I interested in entertaining your \nstrange fantasy.>"
    new "1. <Tampoco me interesa entretener tu \nextraña fantasía.>"

    old "1. <Hypothetically speaking...>"
    new "1. <Hipotéticamente hablando...>"

    old "1. <Aren't people meant to be, ya know, dead...>"
    new "1. <¿No se supone que las personas deben estar, \nya sabes, muertas...?>"

    old "1. <For the reaper to come after them?>"
    new "1. <¿Para que la muerte venga a buscarlos?>"

    old "1. <Right. Okay. Makes total sense.>"
    new "1. <Claro. De acuerdo. Tiene mucho sentido.>"

    old "1. <Nothing sweeps a [girl] off [her2] feet more than... \n'{i}Hi, I just met you, but I need you to die for me{/i}'>"
    new "1. <Nada enamora más a un[girl!t] que... '{i}Hola, acabo \nde conocerte, pero necesito que mueras por mí{/i}'>"

    old "1. <Very romantic and normal.>"
    new "1. <Muy romántico y normal.>"

    old "1. <I was joking!>"
    new "1. <¡Estaba bromeando!>"

    old "1. <Even if that were true...>"
    new "1. <Aunque eso fuera cierto...>"

    old "1. <You're not making the best first impression here.>"
    new "1. <No estás causando la mejor primera impresión aquí.>"

    old "1. <I'm giving you this {i}look{/i} because you are full of shit.>"
    new "1. <Te estoy dando esta {i}mirada{/i} porque eres un mentiroso.>"

    old "1. <Give it up already.>"
    new "1. <Ya rindete.>"

    old "1. <Look, other than being {i}death{/i} or whatever, \ndo you have any other personality traits?>"
    new "1. <Mira, aparte de ser la {i}muerte{/i} o lo que sea, \n¿tienes algún otro rasgo de personalidad?>"

    old "1. <You should work on that.>"
    new "1. <Deberías trabajar en eso.>"

    old "1. <'{i}The only thing necessary for me is claiming \nthe souls of the damned!{/i}'>"
    new "1. <{i}¡Lo único que necesito es reclamar las almas de \nlos condenados!{/i}>"

    old "1. <And it seems you are severely lacking in it.>"
    new "1. <Y parece que te falta mucho.>"

    old "1. <I feel kinda bad for you.>"
    new "1. <Me das un poco de pena.>"

    old "1. <Of course you have.>"
    new "1. <Por supuesto que sí.>"

    old "1. <Yes, the man video calling me is definitely \nthe grim reaper here to take my soul. For sure.>"
    new "1. <Sí, el hombre que me llama por videollamada es sin duda \nla Parca, que ha venido a llevarse mi alma. Seguro.>"

    old "1. <It seems you know a thing or two \nabout sarcasm as well.>"
    new "1. <Parece que tú también sabes un par de cosas \nsobre el sarcasmo.>"

    old "1. <Thank you.>"
    new "1. <Gracias.>"

    old "1. <You really are so sweet.>"
    new "1. <Realmente eres muy amable.>"

    old "1. <Are you serious? Can't you see my longing gaze?>"
    new "1. <¿En serio? ¿No ves mi mirada anhelante?>"

    old "1. <Did you just scoff at me...>"
    new "1. <Te acabas de burlar de mí...?>"

    old "1. <That is {i}not{/i} where I thought this was going...>"
    new "1. <Eso {i}no{/i} es lo que pensaba que iba a pasar...>"

    old "1. <I don't plan to die any time soon, sorry.>"
    new "1. <No pienso morir pronto, lo siento.>"

    old "1. <I heard that!>"
    new "1. <¡Lo escuché!>"

    old "1. <Whatever.>"
    new "1. <Da igual.>"

    old "1. <More like I'm stuck with you, anyway.>"
    new "1. <Más bien me tocó quedarme contigo, de todos modos.>"

    old "1. <You and your weird ass typing.>"
    new "1. <Tú y tu extraña forma de escribir.>"

    old "1. <Why do you type like that, anyway?>"
    new "1. <¿Por qué escribes así, eh?>"

    old "1. <Wait, it's not on purpose?>"
    new "1. <Espera, ¿no es a propósito?>"

    old "1. <The capital letters.>"
    new "1. <Las letras mayúsculas.>"

    old "1. <Yeah... that's the thing.>"
    new "1. <Sí... esa es la cuestión.>"

    old "1. <You use them too often. Way too often.>"
    new "1. <Las usas demasiado. Muchas veces.>"

    old "1. <You were using them on every single word.>"
    new "1. <Las usabas en cada palabra.>"

    old "1. <You're really not supposed to do that.>"
    new "1. <En realidad, no deberías hacer eso.>"

    old "1. <Oh, you really don't know?>"
    new "1. <¿En serio no lo sabes?>"

    old "1. <The all-knowing Grim Reaper has \nnever heard of homestuck?>"
    new "1. <¿El omnisciente Grim Reaper \nnunca ha oído hablar de Homestuck?>"

    old "1. <No, no, if you don't know, it's way funnier.>"
    new "1. <No, no, si no lo sabes, es mucho más divertido.>"

    old "1. <Why do you type like that, though?>"
    new "1. <¿Por qué escribes así?>"

    old "1. <The weird capitalization.>"
    new "1. <El extraño uso de las mayúsculas.>"

    old "1. <Like, on every single word?>"
    new "1. <¿Como en cada palabra?>"

    old "1. <Not at all.>"
    new "1. <En absoluto.>"

    old "1. <I thought you were doing it as part \nof the weird reaper get up.>"
    new "1. <Pensé que lo hacías como parte \ndel extraño atuendo de la Parca.>"

    old "1. <That's exactly what I'm telling you.>"
    new "1. <Eso es exactamente lo que te estoy diciendo.>"

    old "1. <What? What did you hang up for?>"
    new "1. <¿Qué? ¿Por qué colgaste?>"

    old "1. <Hello?>"
    new "1. <¿Hola?>"

    old "1. <Come on, I was finally having fun.>"
    new "1. <Vamos, por fin me estaba divirtiendo.>"

    old "1. <Why'd you leave the call?>"
    new "1. <¿Por qué colgaste la llamada?>"

    old "1. <Um... I'm not trying to make fun of you or anything, but...>"
    new "1. <Um... No estoy tratando de burlarme de ti ni nada, pero...>"

    old "1. <It's still not right (lol)...>"
    new "1. <Sigue sin estar bien (lol)...>"

    old "1. <I guess I'll go, then.>"
    new "1. <Supongo que me iré, entonces.>"

    old "1. <Guess I'll head to bed.>"
    new "1. <Creo que me voy a la cama.>"

    old "1. <Are you... embarrassed?>"
    new "1. <¿Estás... avergonzado?>"

    old "1. <Okay, that's kinda cute.>"
    new "1. <Vale, eso es bastante lindo.>"

    old "1. <I'm gonna take a screenshot.>"
    new "1. <Voy a hacer una captura de pantalla.>"

    old "1. <So, if what you claim is true...>"
    new "1. <Entonces, si lo que dices es cierto...>"

    old "1. <Then you should have no problem taking \na soul, right?>"
    new "1. <Entonces no deberías tener ningún problema \nen llevarte un alma, ¿verdad?>"

    old "1. <I'll allow you a free pass to my soul.>"
    new "1. <Te daré libre acceso a mi alma.>"

    old "1. <If you can take it...>"
    new "1. <Si puedes soportarlo...>"

    old "1. <I'll allow it.>"
    new "1. <Lo permitiré.>"

    old "1. <I won't even fight you for it.>"
    new "1. <Ni siquiera voy a pelear contigo por eso.>"

    old "1. <No fight.>"
    new "1. <Sin pelea.>"

    old "1. <I'll present it to you on a silver platter.>"
    new "1. <Te la serviré en bandeja de plata.>"

    old "1. <Just a little one. I promise.>"
    new "1. <Solo un poquito. Lo prometo.>"

    old "1. <What you claim to be doesn't exist, so of \ncourse you can't take it.>"
    new "1. <Lo que dices que eres no existe, así que, \npor supuesto, no puedes aceptarlo.>"

    old "1. <But I... 'admire' your dedication to your role.>"
    new "1. <Pero yo... 'admiro' tu dedicación a tu trabajo.>"

    old "1. <So, I'll humor you, and you can try.>"
    new "1. <Bueno, te haré el favor y puedes intentarlo.>"

    old "1. <We will see about that.>"
    new "1. <Ya lo veremos.>"

    old "1. <I'll give you a week.>"
    new "1. <Te daré una semana.>"

    old "1. <That should be no problem for the grim reaper, no?>"
    new "1. <Eso no debería ser ningún problema para la Parca, ¿no?>"

    old "1. <Oh?>"
    new "1. <¿Oh?>"

    old "1. <If you only need a day, why did you \nbother with all this?>"
    new "1. <Si solo necesitas un día, ¿por qué te \nhas molestado en todo esto?>"

    old "1. <Are you perhaps... struggling?>"
    new "1. <¿Acaso estás... pasándola mal?>"

    old "1. <And I am... uh...>"
    new "1. <Y yo soy... eh...>"

    old "1. <Not honor bound but you can trust me.>"
    new "1. <No estoy obligado por honor, pero puedes confiar en mí.>"

    old "1. <But...>"
    new "1. <Pero...>"

    old "1. <If you can't...>"
    new "1. <Si no puedes..>"

    old "1. <Your soul.>"
    new "1. <Tu alma.>"

    old "1. <Do you own the house you're in?>"
    new "1. <¿Eres dueño de la casa en la que vives?>"

    old "1. <So you've got a secure job, your own place, \nand you're handsome...>"
    new "1. <Así que tienes un trabajo seguro, tu propia casa \ny eres guapo...>"

    old "1. <Husband material, I think.>"
    new "1. <Creo que eres un buen candidato para esposo.>"

    old "1. <I'm kidding.>"
    new "1. <Estoy bromeando.>"

    old "1. <How about your soul, instead?>"
    new "1. <¿Y qué hay de tu alma?>"

    old "1. <Then it's an even bet.>"
    new "1. <Entonces es una apuesta segura.>"

    old "1. <Scared?>"
    new "1. <¿Asustado?>"

    old "1. <Except for typing incorrectly.>"
    new "1. <Excepto por escribir incorrectamente.>"

    old "1. <Eat it, probably.>"
    new "1. <Comérmela. Probablemente.>"

    old "1. <I wonder how nutritious it is...?>"
    new "1. <Me pregunto qué tan nutritivo será...>"

    old "1. <Will I get an extra eight lives?>"
    new "1. <¿Tendré ocho vidas extra?>"

    old "1. <Meow.>"
    new "1. <Miau.>"

    old "1. <If I consume a bunch of souls, will I live forever?>"
    new "1. <Si consumo un montón de almas, ¿viviré para siempre?>"

    old "1. <Would I be like a god?>"
    new "1. <¿Sería como un dios?>"

    old "1. <Or maybe a demon? That seems cooler than a god.>"
    new "1. <¿O tal vez un demonio? Eso parece más \ninteresante que un dios.>"

    old "1. <You know, a soul baby.>"
    new "1. <Ya sabes, un bebé alma.>"

    old "1. <What's the issue then?>"
    new "1. <¿Cuál es el problema entonces?>"

    old "1. <Guess I'll just hold onto the soul for now, then.>"
    new "1. <Supongo que por ahora me quedaré con el alma.>"

    old "1. <We can revisit the soul baby thing later.>"
    new "1. <Podemos volver a hablar del tema del \nbebé alma más tarde.>"

    old "1. <Fine, if not a soul baby...>"
    new "1. <Está bien, si no es un bebé alma...>"

    old "1. <I guess I'll make a necklace out of it or something...>"
    new "1. <Supongo que haré un collar con eso o algo así...>"

    old "1. <You don't know that!>"
    new "1. <¡Eso no lo sabes!>"

    old "1. <Hah. You wish it was that easy.>"
    new "1. <Ja. Ojalá fuera tan fácil.>"

    old "1. <I'll win for sure.>"
    new "1. <Ganaré seguro.>"

    old "1. <Uh. That's kinda morbid.>"
    new "1. <Uh. Eso es un poco macabro.>"

    old "1. <So...>"
    new "1. <Entonces...>"

    old "1. <Say you do win...>"
    new "1. <Digamos que ganas...>"

    old "1. <Will we make a special date of it?>"
    new "1. <¿Haremos una cita especial?>"

    old "1. <Well, if it's going to be beautiful...>"
    new "1. <Bueno, si va a ser bonita...>"

    old "1. <We could start the night with a movie...>"
    new "1. <Podríamos empezar la noche con una película...>"

    old "1. <Some wine...>"
    new "1. <Un poco de vino...>"

    old "1. <Damn, that's a shame.>"
    new "1. <Vaya, qué pena.>"

    old "1. <There's a first time for everything, I suppose!>"
    new "1. <¡Supongo que siempre hay una primera vez para todo!>"

    old "1. <I guess I'll be your first.>"
    new "1. <Supongo que seré tu primera.>"

    old "1. <This is gonna be fun.>"
    new "1. <Esto va a ser divertido.>"

    old "1. <Wouldn't a reaper also be sadistic?>"
    new "1. <¿No serías una parca también sádica?>"

    old "1. <Kinda hypocritical, no?>"
    new "1. <Un poco hipócrita, ¿no?>"

    old "1. <Happy to hear it.>"
    new "1. <Me alegra saberlo.>"

    old "1. <My poor little reaper. It must be awful.>"
    new "1. <Mi pobre parquita. Debe de ser horrible.>"

    old "1. <Stop talking?>"
    new "1. <¿Dejar de hablar?>"

    old "1. <I'd like to draw your attention to that fact \nthat {i}you{/i} called {i}me{/i}.>"
    new "1. <Me gustaría señalar el hecho de \nque {i}tú{/i} me llamaste {i}a mí{/i}.>"

    old "1. <{i}You{/i} messaged {i}me{/i}.>"
    new "1. <{i}Tú{/i} me enviaste un mensaje {i}a mí{/i}.>"

    old "1. <Seems pointless if you don't WANT me to talk to you.>"
    new "1. <Parece inútil si no QUIERES que te hable.>"

    old "1. <I must be reaaaaal important to you, huh?>"
    new "1. <Debo ser taaaaan importante para ti, ¿eh?>"

    old "1. <Mmhm. We'll see.>"
    new "1. <Mmhm. Ya veremos.>"

    old "1. <So you admit there is a 'we'.>"
    new "1. <Así que admites que existe un 'nosotros'.>"

    old "1. <But it's so fun!>"
    new "1. <¡Pero es tan divertido!>"

    old "1. <Anyway, as fun as this is...>"
    new "1. <De todos modos, por muy divertido que sea esto...>"

    old "1. <It's getting kinda late.>"
    new "1. <Se está haciendo tarde.>"

    old "1. <We can't all waste our time messaging \nrandom people on the internet.>"
    new "1. <No podemos perder el tiempo enviando mensajes \na personas al azar en Internet.>"

    old "1. <Done as I was told?>"
    new "1. <¿Hice lo que me dijiste?>"

    old "1. <I don't usually follow orders from strangers.>"
    new "1. <Normalmente no sigo las órdenes de desconocidos.>"

    old "1. <My, you're very forward, aren't you?>"
    new "1. <Vaya, eres muy atrevido, ¿no?>"

    old "1. <What are you going to order me to do next?>"
    new "1. <¿Qué me vas a ordenar que haga ahora?>"

    old "1. <I'm sure you can come up with something \nmore interesting to ask for.>"
    new "1. <Seguro que se te ocurre algo más interesante \nque pedir.>"

    old "1. <Guess I'll just store away 'the grim reaper likes \nto order people around' for a later time.>"
    new "1. <Supongo que guardaré 'a la parca le gusta dar órdenes \na la gente' para más adelante.>"

    old "1. <I know you're a self proclaimed {i}grim reaper{/i}.>"
    new "1. <Sé que te autoproclamas {i}la Parca{/i}.>"

    old "1. <Doesn't that count?>"
    new "1. <¿Eso no cuenta?>"

    old "1. <We'll see about that.>"
    new "1. <Ya lo veremos.>"


    old "1. <I'd argue that this is {i}your{/i} fantasy.>"
    new "1. <Yo diría que esa es {i}tu{/i} fantasía.>"

    old "1. <You were the one who brought up \nme following your 'orders'.>"
    new "1. <Fuiste tú quien me animó a seguir \ntus 'órdenes'.>"

    old "1. <Sadly not everything is easy in life.>"
    new "1. <Por desgracia, no todo es fácil en la vida.>"

    old "1. <Or death, in this case.>"
    new "1. <O la muerte, en este caso.>"

    old "1. <You like talking to me.>"
    new "1. <Te gusta hablar conmigo.>"

    old "1. <I know you do.>"
    new "1. <Sé que te gusta.>"

    old "1. <You like it so much.>"
    new "1. <Te gusta mucho.>"

    old "1. <Maybe it's like...>"
    new "1. <Quizás sea como...>"

    old "1. <So many negatives added together \nit's become a positive.>"
    new "1. <Tantos aspectos negativos sumados que \nse han convertido en algo positivo.>"

    old "1. <So you actually agree.>"
    new "1. <Entonces, en realidad estás de acuerdo.>"

    old "1. <It's part of my charm, you'll have to get \nused to it.>"
    new "1. <Es parte de mi encanto, tendrás que \nacostumbrarte.>"

    old "1. <That would make your job too easy.>"
    new "1. <Eso haría que tu trabajo fuera demasiado fácil.>"

    old "1. <Stop it, you're making me feel important.>"
    new "1. <Ya basta, me estás haciendo sentir importante.>"

    old "1. <Oh? No arguments?>"
    new "1. <¿Ah, sí? ¿Sin objeciones?>"

    old "1. <Perhaps you'd like that after all?>"
    new "1. <¿Quizás te gustaría eso después de todo?>"

    old "1. <Again with the lack of disagreement.>"
    new "1. <Una vez más, sin desacuerdos.>"

    old "1. <Lo que sea que te ayude a dormir por las noches, mi parquita.>"
    new "1. <>"

    old "1. <You kind of give 'lost puppy' vibes.>"
    new "1. <Das una especie de vibra de cachorro perdido.>"

    old "1. <I think it's the little pout you get sometimes.>"
    new "1. <Creo que es ese pequeño puchero que haces a veces.>"

    old "1. <It makes me both want to bully you and look after you.>"
    new "1. <Me dan ganas tanto de intimidarte como de cuidarte.>"

    old "1. <It's cute when you act all tough like that.>"
    new "1. <Es lindo cuando te haces el rudo así.>"

    old "1. <Especially when your cheeks are pink.>"
    new "1. <Especialmente cuando tus mejillas están rosadas.>"

    old "1. <Then you'll be in troooouble.>"
    new "1. <Entonces estarás en problemas.>"

    old "1. <You might get disciplined.>"
    new "1. <Es posible que te castiguen.>"

    old "1. <But maybe you'd like that.>"
    new "1. <Pero tal vez eso te gustaría.>"

    old "1. <Dismissed...?>"
    new "1. <¿Se terminó...?>"

    old "1. <Aw, but I was having so much fun.>"
    new "1. <Aw, pero me estaba divirtiendo tanto.>"

    old "1. <Okay, I've changed my mind.>"
    new "1. <Vale, he cambiado de opinión.>"

    old "1. <Woah, you're acting like you care.>"
    new "1. <Woah, actúas como si te importara>"

    old "1. <You can just say 'sleep well', you know.>"
    new "1. <Puedes decir simplemente 'que duermas bien', \nya sabes.>"

    old "1. <G'night, little reaper.>"
    new "1. <Buenas noches, parquita.>"

    old "1. <Hey, wait a second...>"
    new "1. <Oye, espera un momento...>"

    old "1. <How did you know my name?>"
    new "1. <¿Cómo supiste mi nombre?>"

    old "1. <I never told you!>"
    new "1. <¡Nunca te lo dije!>"

    old "1. <Aw, you circled it?>"
    new "1. <Aw, ¿lo marcaste con un círculo?>"

    old "1. <Night!>"
    new "1. <¡Buenas noches!>"

    old "1. <Sleep well, grimmy :)>"
    new "1. <Duerme bien, Parquita :)>"

    old "1. <Oh, wait, can I change my username?>"
    new "1. <Oh, espera, ¿puedo cambiar mi nombre de usuario?>"

    old "1. <I just want to.>"
    new "1. <Solo quiero.>"

    old "1. <Wow, easier to convince than I expected.>"
    new "1. <Wow, más fácil de convencer de lo que esperaba.>"

    old "1. <But can I change it or not?>"
    new "1. <¿Pero puedo cambiarlo o no?>"

    old "1. <What about my picture?>"
    new "1. <¿Y mi foto?>"

    old "1. <Just for you ;)>"
    new "1. <Solo para ti ;)>"

    old "1. <Thanks grimmy. Night night!>"
    new "1. <Gracias Parquita. ¡Buenas noches!>"


    old "1. <I thought we were moving past the whole soul thing...>"
    new "1. <Pensé que ya habíamos dejado atrás lo de las almas...>"

    old "1. <You said that once or twice already.>"
    new "1. <Ya lo dijiste una o dos veces.>"

    old "1. <And like I said, I don't believe you.>"
    new "<Y como dije, no te creo.>"

    old "1. <I mean, it's been fun messing with you, but...>"
    new "1. <Quiero decir, ha sido divertido fastidiarte, pero...>"

    old "1. <The 'Grim Reaper' isn't real.>"
    new "1. <La 'Parca' no es real.>"

    old "1. <It's a myth.>"
    new "1. <Es un mito.>"

    old "1. <No, you look like a very pretty stranger.>"
    new "1. <No, pareces un desconocido muy lindo.>"

    old "1. <But the grim reaper isn't real.>"
    new "1. <Pero la parca no es real.>"

    old "1. <Yeah, okay, okay. I get it.>"
    new "1. <Sí, está bien, está bien. Lo entiendo.>"

    old "1. <I feel like we'll keep going in circles at this rate, so...>"
    new "1. <Siento que seguiremos dando vueltas a este ritmo, \nasí que...>"

    old "1. <How about a bet?>"
    new "1. <¿Qué tal una apuesta?>"

    old "1. <Or maybe more like a deal.>"
    new "1. <O quizás más bien un trato.>"


    old "2. <An offer for what you said—>"
    new "2. <Una oferta por lo que dijiste—>"

    old "2. <What is this app...?>"
    new "2. <¿Qué es esta aplicación...?>"

    old "2. <Well, I guess that does sound like a lot of effort.>"
    new "2. <Bueno, supongo que eso sí parece mucho esfuerzo.>"

    old "2. <I mean, it was like... five minutes.>"
    new "2. <Quiero decir, fue como... cinco minutos.>"

    old "2. <You shouldn't have blown up my notifications.>"
    new "2. <No deberías haber reventado mis notificaciones.>"

    old "2. <Don't spam and don't get mad if you don't get an instant response, mostly.>"
    new "2. <No hagas spam y no te enfades si no obtienes una respuesta instantánea, mayormente.>"

    old "2. <You're a moron.>"
    new "2. <Eres un imbécil.>"

    old "2. <Wait, are you a bot?>"
    new "2. <Espera, ¿eres un bot?>"

    old "2. <I'm actually starting to feel sorry for you...>"
    new "2. <De verdad que estoy empezando a sentir lástima por ti...>"

    old "2. <Wait, what did you come here for?>"
    new "2. <Espera, ¿para qué viniste aquí?>"

    old "2. <I don't owe you anything.>"
    new "2. <No te debo nada.>"

    old "2. <Now I feel bad. You can tell me.>"
    new "2. <Ahora me siento mal. Puedes decírmelo.>"

    old "2. <Pretty please?>"
    new "2. <¿Por favorcito?>"

    old "2. <Yeah, I'm terrified.>"
    new "2. <Sí, tengo mucho miedo.>"

    old "2. <Yep. Really really scared atm.>"
    new "2. <Síp. Realmente tengo mucho miedo en este momento.>"

    old "2. <Riiiight.>"
    new "2. <Cieeeerto.>"

    old "2. <Very normal.>"
    new "2. <Muy normal.>"

    old "2. <ngl not the weirdest scam someone's tried on me.>"
    new "2. <No voy a mentir, no es la estafa más rara que alguien me haya intentado hacer.>"

    old "2. <You're kind of babygirl coded.>"
    new "2. <Tienes un aire de Babygirl.>"

    old "2. <A pizza delivery [woman].>"
    new "2. <Un[woman!t] que Reparte Pizzas.>"

    old "2. <It's a little hard to take you seriously.>"
    new "2. <Es un poco difícil tomarte en serio.>"

    old "2. <Are you... okay?>"
    new "2. <¿Estás... bien?>"

    old "2. <No, I'm messing with you again.>"
    new "2. <No, te estoy tomando el pelo otra vez.>"

    old "2. <I'll email it to you. What's your email?>"
    new "2. <Te lo enviaré por correo electrónico. ¿Cuál es tu correo?>"

    old "2. <It's kinda... cringe.>"
    new "2. <Es algo... cringe.>"

    old "2. <Er... yes, that's what it means.>"
    new "2. <Erm... sí, eso significa.>"

    old "2. <You're totally delusional, but it's kinda sweet.>"
    new "2. <Estás totalmente delirando, pero es algo tierno.>"

    old "2. <I Am So Edgy And Dark!>"
    new "2. <¡Soy Tan Edgy Y Tenebroso!>"

    old "2. <Make sure they didn't leave the oven on.>"
    new "2. <Asegúrate de que no hayan dejado el horno encendido.>"

    old "2. <That's boring. Cause a little pain, why don't you?>"
    new "2. <Eso es aburrido. Causa un poco de dolor, ¿por qué no?>"

    old "2. <Is there anyone who wouldn't?>"
    new "2. <¿Hay alguien que no lo haría?>"

    old "2. <'{i}I am the Grim Reaper! Death and darkness!{/i}'>"
    new "2. <'{i}¡Soy La Parca! ¡Muerte y oscuridad!{/i}'>"

    old "2. <You give off 'dresses in all black' vibes.>"
    new "2. <Das la vibra de 'se viste todo de negro'.>"

    old "2. <Not my thing, but you do you, buddy.>"
    new "2. <No es lo mío, pero tú haz lo que quieras, amigo.>"

    old "2. <If only we could meet to confirm my suspicions.>"
    new "2. <Ojalá pudiéramos vernos para confirmar mis sospechas.>"

    old "2. <Dead, right?>"
    new "2. <Muerto, ¿verdad?>"

    old "2. <Using the word 'quiver' was certainly a choice.>"
    new "2. <Usar la palabra 'temblar' fue sin duda una elección deliberada.>"

    old "2. <You do type like that, though.>"
    new "2. <Es que escribes así.>"

    old "2. <You're just proving my point.>"
    new "2. <Solo estás confirmando mi punto.>"

    old "2. <The fact that you admitted it...>"
    new "2. <El hecho de lo hayas admitido...>"

    old "2. <Can't you take someone else's?>"
    new "2. <¿No puedes tomar la de otra persona?>"


    old "2. <There's not much else to look at.>"
    new "2. <No hay mucho más que ver.>"

    old "2. <You keep saying that, but it's not true.>"
    new "2. <Sigues diciendo eso, pero no es cierto.>"

    old "2. <Okay, no need for that face.>"
    new "2. <Vale, no hace falta que pongas esa cara.>"

    old "2. <You're still saying it, really?>"
    new "2. <¿Todavía sigues diciendo eso, en serio?>"

    old "2. <I really can't tell if you're being serious or not.>"
    new "2. <Realmente no sé si lo dices en serio o no.>"

    old "2. <Just a quick question...>"
    new "2. <Solo una pregunta rápida...>"

    old "2. <Thanks for the explanation.>"
    new "2. <Gracias por la explicación.>"

    old "2. <At this point, I'm just really curious what you \nactually want.>"
    new "2. <En este momento, tengo mucha curiosidad por saber\n qué es lo que realmente quieres.>"

    old "2. <Let me guess, your social life consists of \ncounting the sand grains in an hourglass, right?>"
    new "2. <Déjame adivinar, tu vida social consiste en \ncontar los granos de arena de un reloj de arena, ¿verdad?>"

    old "2. <Unlike some.>"
    new "2. <A diferencia de algunos.>"

    old "2. <If I knocked on your head, I'd hear an echo, I bet.>"
    new "2. <Si te diera un golpe en la cabeza, seguro que oiría un eco.>"

    old "2. <You mean this one? Where I look at you \nlike you've lost your mind?>"
    new "2. <¿Te refieres a esta? ¿En la que te miro \ncomo si hubieras perdido la cabeza?>"

    old "2. <Who wouldn't believe a stranger on the internet?>"
    new "2. <¿Quién no creería a un desconocido en Internet?>"

    old "2. <You know how to make a [girl] smile.>"
    new "2. <Sabes cómo hacer sonreír a un[girl!t].>"

    old "2. <Come on...>"
    new "2. <Vamos...>"

    old "2. <Here I was trying to flirt...>"
    new "2. <Aquí estaba yo tratando de coquetear...>"

    old "2. <You're one of those things. A homestuck.>"
    new "2. <Tú eres una de esas cosas. Un homestuck.>"

    old "2. <Not correctly at all.>"
    new "2. <No es correcto en absoluto.>"

    old "2. <Little reaper?>"
    new "2. <¿Parquita?>"

    old "2. <That's wrong, too...>"
    new "2. <Eso también está mal...>"

    old "2. <Well if you have nothing to say...>"
    new "2. <Bueno, si no tienes nada que decir...>"

    old "2. <This is definitely not giving 'grim reaper'.>"
    new "2. <Esto definitivamente no da una imagen de 'la parca'.>"

    old "2. <You're blushing so hard right now.>"
    new "2. <Te estás sonrojando mucho en este momento.>"

    old "2. <You do actually look cute right now.>"
    new "2. <De verdad que ahora mismo te ves lindo.>"

    old "2. <Too bad. It's my soul.>"
    new "2. <Qué lástima. Es mi alma.>"

    old "2. <This has been amusing, but...>"
    new "2. <Ha sido divertido, pero...>"

    old "2. <Honestly, you do a little.>"
    new "2. <Honestamente, tú también un poco.>"

    old "2. <I'll hand it over, happily.>"
    new "2. <Te la entregaré con mucho gusto.>"

    old "2. <I'm glad you're confident.>"
    new "2. <Me alegra que tengas confianza en ti mismo.>"

    old "2. <Then why are we both here?>"
    new "2. <Entonces, ¿por qué estamos aquí los dos?>"

    old "2. <Your hand in marriage.>"
    new "2. <Tu mano en matrimonio.>"

    old "2. <We could mix our souls and make some \nkind of... soul baby.>"
    new "2. <Podríamos mezclar nuestras almas y crear \nuna especie de... bebé alma.>"

    old "2. <I don't lose.>"
    new "2. <Yo no pierdo.>"

    old "2. <People usually do what {i}I{/i} tell them to do.>"
    new "2. <La gente suele hacer lo que {i}yo{/i} les pido que hagan.>"

    old "2. <No chance, sorry.>"
    new "2. <No hay manera, lo siento.>"

    old "2. <You do seem like the type to enjoy bossing \npeople around.>"
    new "2. <Pareces de los que disfrutan mandando a los \ndemás.>"

    old "2. <You admit it so readily...>"
    new "2. <Lo admites tan fácilmente...>"

    old "2. <I guess I'm that special.>"
    new "2. <Supongo que soy así de especial.>"

    old "2. <You seem like the submissive type.>"
    new "2. <Pareces del tipo sumiso.>"

    old "2. <What if I say no?>"
    new "2. <¿Y si digo que no?"

    old "2. <This one is kinda lame.>"
    new "2. <Este es un poco patético.>"

    old "2. <Aren't these basic messaging app features?>"
    new "2. <¿No son esas las funciones básicas de una aplicación de mensajería?>"

    old "3. <Uh... hello to you, too.>"
    new "3. <Eh... hola para ti también.>"

    old "3. <Riiiiiiiiiight.>"
    new "3. <Cieeeeeeeeeerto.>"

    old "3. <Your mortal enemy. Mwhahahaha.>"
    new "3. <Tu enemigo mortal. Mwhahahaha.>"

    old "3. <Is this one of those scams?>"
    new "3. <¿Es esta una de esas estafas?>"

    old "3. <It's a little cute...>"
    new "3. <Es un poco lindo...>"

    old "3. <I Am Darkness Incarnate!>"
    new "3. <¡Soy La Oscuridad Encarnada!>"

    old "3. <If they win in rock paper scissors, they get a free pass.>"
    new "3. <Si ganan en piedra, papel o tijera, obtienen un pase gratuito.>"

    old "3. <It's less mocking, more... light teasing.>"
    new "3. <Es menos burlón, más... una broma ligera.>"

    old "3. <Well... you certainly are cuter than I expected.>"
    new "3. <Bueno... sin duda eres más lindo de lo que esperaba.>"

    old "3. <Great. Now I completely understand.>"
    new "3. <Genial. Ahora lo entiendo perfectamente.>"

    old "3. <Oh, these are my bedroom eyes.>"
    new "3. <Oh, estos son mis ojos seductores.>"

    old "3. <Don't Wanna Chat With Me Anymore, Little Reaper?> {font=gui/starthings.ttf}a{/font}"
    new "3. <¿Ya No Quieres Charlar Conmigo, Parquita?> {font=gui/starthings.ttf}a{/font}"
    
    old "3. <No need to overreact.>"
    new "3. <No hay necesidad de exagerar.>"

    old "3. <I'll let you, and I'll only put up a {i}small{/i} fight.>"
    new "3. <Te dejaré hacerlo, y solo opondré una {i}pequeña{/i} resistencia.>"

    old "3. <I haven't decided yet.>"
    new "3. <Aún no lo he decidido.>"

    old "3. <I'll pass, actually.>"
    new "3. <De hecho, paso.>"

    old "3. <There's something attractive about telling a \nhandsome man what to do.>"
    new "3. <Hay algo atractivo en decirle a un hombre guapo \nlo que tiene que hacer.>"

    old "4. <{i}Delete the app.{/i}> {font=gui/starthings.ttf}a{/font}"
    new "4. <{i}Eliminar la aplicación.{/i}> {font=gui/starthings.ttf}a{/font}>"

    old "4. <Of course, it's all yours!> {font=gui/starthings.ttf}a{/font}"
    new "4. <¡Por supuesto, es todo tuya!> {font=gui/starthings.ttf}a{/font}>"

    old "4. <Wait, {b}I'M{/b} the Grim Reaper...> {font=gui/starthings.ttf}a{/font}"
    new "4. <Espera, {b}YO SOY{/b} La Parca...> {font=gui/starthings.ttf}a{/font}"

    old "4. <Yeah, sorry.>"
    new "4. <Sí, lo siento.>"

    old "4. <Hello, my little Reaper.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Hola, mi parquita.> {font=gui/starthings.ttf}a{/font}"

    old "4. <Well, isn't that just lovely.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Bueno, eso es encantador.> {font=gui/starthings.ttf}a{/font}"

    old "4. <There he is! My little reaper.> {font=gui/starthings.ttf}a{/font}"
    new "4. <¡Ahí está! Mi parquita.> {font=gui/starthings.ttf}a{/font}"

    old "4. <Which, obviously, you won't be able to do...> {font=gui/starthings.ttf}a{/font}"
    new "4. <Lo cual, obviamente, no podrás hacer...> {font=gui/starthings.ttf}a{/font}"

    old "4. <Sounds like you know I'm going to win.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Parece que sabes que voy a ganar.> {font=gui/starthings.ttf}a{/font}"

    old "4. <Maybe you should follow my orders, little reaper.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Quizás deberías seguir mis órdenes, parquita.> {font=gui/starthings.ttf}a{/font}"





