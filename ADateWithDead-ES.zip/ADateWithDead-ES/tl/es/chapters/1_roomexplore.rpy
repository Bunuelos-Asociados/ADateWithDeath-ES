
# game/chapters/1_roomexplore.rpyc:366
translate es bed_hub_c63951e0:

    # "Your comfortable bed."
    "Tu cómoda cama."

# game/chapters/1_roomexplore.rpyc:367
translate es bed_hub_b2f03db4:

    # "It's seen you through many a night's sleep."
    "Te ha acompañado en muchas noches de sueño."

# game/chapters/1_roomexplore.rpyc:368
translate es bed_hub_dee7ea0f:

    # "You're not that tired yet, though."
    "Aunque aún no sientes cansancio."

# game/chapters/1_roomexplore.rpyc:369
translate es bed_hub_d1033f6b:

    # "You can't help but recall the day you bought this bed. It was your first piece of furniture you bought for yourself."
    "No puedes evitar recordar el día en que compraste esta cama. Fue el primer mueble que compraste para ti."

# game/chapters/1_roomexplore.rpyc:370
translate es bed_hub_7e2fefba:

    # "Not only was it too big to fit up the narrow stairwell, you got it wedged halfway up."
    "No solo era demasiado grande para caber por la estrecha escalera, sino que además se atascó a mitad de camino."

# game/chapters/1_roomexplore.rpyc:371
translate es bed_hub_18b39559:

    # "You thought you were going to have to sleep there from now on."
    "Pensaste que ibas a tener que dormir ahí desde entonces."

# game/chapters/1_roomexplore.rpyc:372
translate es bed_hub_eeaffff0:

    # "But eventually it came free... and then you stepped on a loose floorboard and nearly plummeted down a few flights of stairs."
    "Pero al final lograste liberarla... y luego pisaste una tabla suelta del suelo y casi caes por varios tramos de escaleras."

# game/chapters/1_roomexplore.rpyc:373
translate es bed_hub_fc0dba82:

    # "Whoops."
    "Uups."

# game/chapters/1_roomexplore.rpyc:374
translate es bed_hub_a4a91e09:

    # "It's certainly an experience you'll never forget, at least?"
    "Al menos, sin duda es una experiencia que nunca olvidarás, ¿no?"

# game/chapters/1_roomexplore.rpyc:383
translate es door_hub_48c0cf48:

    # "The door leads out to the hallway beyond."
    "La puerta conduce al pasillo de afuera."

# game/chapters/1_roomexplore.rpyc:384
translate es door_hub_2f8038fc:

    # "Your apartment is on the fifth floor of a downtown apartment building."
    "Tu apartamento está en el quinto piso de un edificio en el centro de la ciudad."

# game/chapters/1_roomexplore.rpyc:385
translate es door_hub_3b5cdc2a:

    # "There's nowhere you want to go at the moment, but you overhear some talking on the other side in the hall beyond."
    "No hay ningún lugar al que quieras ir por el momento, pero alcanzas a oír voces en el pasillo."

# game/chapters/1_roomexplore.rpyc:386
translate es door_hub_66779503:

    # "You don't know your neighbors very well yet. Perhaps now is a good time to learn more about them?"
    "Todavía no conoces muy bien a tus vecinos. ¿Quizás ahora sea un buen momento para saber más de ellos?"

# game/chapters/1_roomexplore.rpyc:391
translate es door_hub_2e0d72de:

    # "You put your ear to the door, straining through the wood to hear the words being spoken beyond."
    "Pones la oreja en la puerta, esforzándote por escuchar las palabras a través de la madera."

# game/chapters/1_roomexplore.rpyc:392
translate es door_hub_0bcc5762:

    # "You hear the sound of someone knocking, then a door opening."
    "Oyes el sonido de alguien tocando, luego una puerta que se abre."

# game/chapters/1_roomexplore.rpyc:393
translate es door_hub_ac92ea3f:

    # "'Sorry to disturb you—I just moved in down the hall, and I had a package meant for you delivered to my apartment.' A deep, rich voice floats through the door."
    "'Perdón por molestarte—me acabo de mudar al fondo del pasillo, y me entregaron en mi apartamento un paquete que era para ti.' Una voz profunda y grave flota a través de la puerta."

# game/chapters/1_roomexplore.rpyc:394
translate es door_hub_1ba052a2:

    # "'Oh my gosh—I thought the package got lost! I really can't thank you enough.' The other voice responds, light and somewhat airy."
    "'¡Dios mío—pensé que el paquete se había perdido! De verdad no sé cómo agradecerte lo suficiente.' Responde la otra voz, ligera y un tanto aireada."

# game/chapters/1_roomexplore.rpyc:395
translate es door_hub_a09ab777:

    # "'Well, it gave me a chance to introduce myself to you, so I'd call it good luck on my part. Here, all yours.'"
    " 'Bueno, me dio la oportunidad de presentarme, así que lo tomaré como buena suerte de mi parte. Aquí, es todo tuyo.'"

# game/chapters/1_roomexplore.rpyc:396
translate es door_hub_6b1453a2:

    # "'Thanks again... um...' The voice trails off."
    "'Gracias otra vez... em...' La voz se desvanece."

# game/chapters/1_roomexplore.rpyc:397
translate es door_hub_550e9d0e:

    # "'Oh! My apologies, my name is—' The voice is muffled for a moment as the elevator dings, and you miss the next few words. '—your humble servant.'"
    "'¡Ah! Mis disculpas, mi nombre es—' La voz se amortigua un momento cuando suena el elevador, y pierdes las siguientes palabras. '—tu humilde servidor'."

# game/chapters/1_roomexplore.rpyc:398
translate es door_hub_39a677a4:

    # "The second voice laughs. 'I feel like I owe you something for having to bring that heavy box all the way over here.'"
    "La segunda voz ríe. 'Siento que te debo algo por haberte hecho traer esa caja tan pesada hasta aquí'."

# game/chapters/1_roomexplore.rpyc:399
translate es door_hub_69c5a11a:

    # "'I would hardly call one flight of stairs 'all the way over', but I wouldn't turn down a coffee?' The deeper voice replies."
    "'Yo no llamaría ‘hasta aquí’ a un solo piso de escaleras, pero no rechazaría un café'. Responde la voz más profunda."

# game/chapters/1_roomexplore.rpyc:400
translate es door_hub_1d4c2e51:

    # "'Oh! How about... tomorrow?'"
    "'¡Oh! ¿Qué tal... mañana?'"

# game/chapters/1_roomexplore.rpyc:401
translate es door_hub_0a4e4798:

    # "'It's a date. I mean, not really, but... see you tomorrow.'"
    "'Es una cita. Digo, no realmente, pero... nos vemos mañana'."

# game/chapters/1_roomexplore.rpyc:402
translate es door_hub_b5790fa3:

    # "'See you!'"
    "'¡Nos vemos!'"

# game/chapters/1_roomexplore.rpyc:403
translate es door_hub_b62821ce:

    # "You hear the door close and the sound of footsteps walking away from the door, and then silence."
    "Oyes que la puerta se cierra y pasos que se alejan por el pasillo, y luego silencio."

# game/chapters/1_roomexplore.rpyc:404
translate es door_hub_a12d64cc:

    # "...Before you hear the sound of pottery falling then shattering onto the ground."
    "...Hasta que escuchas el sonido de cerámica cayendo y rompiéndose contra el suelo."

# game/chapters/1_roomexplore.rpyc:405
translate es door_hub_02098a34:

    # "The door opens again."
    "La puerta se abre de nuevo."

# game/chapters/1_roomexplore.rpyc:406
translate es door_hub_e3cf6106:

    # "The deep voice speaks first 'I, uh... didn't see your plant there. Coffee's on me?'"
    "La voz profunda habla primero. 'Yo, eh... no vi tu planta ahí. ¿El café corre por mi cuenta?'"

# game/chapters/1_roomexplore.rpyc:407
translate es door_hub_310fcedd:

    # "You hear the second voice giggle, then speak. 'It's alright, I've been meaning to get a new pot for ages.'"
    "Escuchas la segunda voz reír, luego hablar. 'Está bien, tenía pensado comprar una maceta nueva desde hace tiempo.'"

# game/chapters/1_roomexplore.rpyc:408
translate es door_hub_7a07a6dc:

    # "'Let me at least help cleaning it up.'"
    "'Al menos déjame ayudarte a limpiarlo.'"

# game/chapters/1_roomexplore.rpyc:409
translate es door_hub_0123fc97:

    # "'It's really no trouble—'"
    "'De verdad, no es problema—'"

# game/chapters/1_roomexplore.rpyc:410
translate es door_hub_3f8cd6df:

    # "'I insist. I was the clumsy one.'"
    "'Insisto. Yo fui el torpe.'"

# game/chapters/1_roomexplore.rpyc:411
translate es door_hub_547c15a9:

    # "'...Alright. Let me get the broom.'"
    "'…Está bien. Voy por la escoba.'"

# game/chapters/1_roomexplore.rpyc:412
translate es door_hub_0ba6f623:

    # "The voices become muffled, then silent. That seems to be all the information you'll get for the day."
    "Las voces se vuelven apagadas, luego silenciosas. Parece que eso es toda la información que obtendrás por hoy."

# game/chapters/1_roomexplore.rpyc:424
translate es door_hub_2e0d72de_1:

    # "You put your ear to the door, straining through the wood to hear the words being spoken beyond."
    "Pones la oreja en la puerta, esforzándote por escuchar las palabras a través de la madera."

# game/chapters/1_roomexplore.rpyc:425
translate es door_hub_0bcc5762_1:

    # "You hear the sound of someone knocking, then a door opening."
    "Oyes el sonido de alguien tocando, luego una puerta que se abre."

# game/chapters/1_roomexplore.rpyc:426
translate es door_hub_ac92ea3f_1:

    # "'Sorry to disturb you—I just moved in down the hall, and I had a package meant for you delivered to my apartment.' A deep, rich voice floats through the door."
    "'Perdón por molestarte—me acabo de mudar al fondo del pasillo, y me entregaron en mi apartamento un paquete que era para ti'. Una voz profunda y grave flota a través de la puerta."

# game/chapters/1_roomexplore.rpyc:427
translate es door_hub_1ba052a2_1:

    # "'Oh my gosh—I thought the package got lost! I really can't thank you enough.' The other voice responds, light and somewhat airy."
    "'¡Dios mío—pensé que el paquete se había perdido! De verdad no sé cómo agradecerte lo suficiente'. Responde la otra voz, ligera y un tanto aireada."

# game/chapters/1_roomexplore.rpyc:428
translate es door_hub_a09ab777_1:

    # "'Well, it gave me a chance to introduce myself to you, so I'd call it good luck on my part. Here, all yours.'"
    "'Bueno, me dio la oportunidad de presentarme, así que lo tomaré como buena suerte de mi parte. Aquí, es todo tuyo'."

# game/chapters/1_roomexplore.rpyc:429
translate es door_hub_6b1453a2_1:

    # "'Thanks again... um...' The voice trails off."
    "'Gracias otra vez... em...' La voz se desvanece."

# game/chapters/1_roomexplore.rpyc:430
translate es door_hub_550e9d0e_1:

    # "'Oh! My apologies, my name is—' The voice is muffled for a moment as the elevator dings, and you miss the next few words. '—your humble servant.'"
    "'¡Ah! Mis disculpas, mi nombre es—' La voz se amortigua un momento cuando suena el elevador, y pierdes las siguientes palabras. '—tu humilde servidor'."

# game/chapters/1_roomexplore.rpyc:431
translate es door_hub_39a677a4_1:

    # "The second voice laughs. 'I feel like I owe you something for having to bring that heavy box all the way over here.'"
    "La segunda voz ríe. 'Siento que te debo algo por haberte hecho traer esa caja tan pesada hasta aquí'."

# game/chapters/1_roomexplore.rpyc:432
translate es door_hub_69c5a11a_1:

    # "'I would hardly call one flight of stairs 'all the way over', but I wouldn't turn down a coffee?' The deeper voice replies."
    "'Yo no llamaría ‘hasta aquí’ a un solo piso de escaleras, pero no rechazaría un café'. Responde la voz más profunda."

# game/chapters/1_roomexplore.rpyc:433
translate es door_hub_1d4c2e51_1:

    # "'Oh! How about... tomorrow?'"
    "'¡Oh! ¿Qué tal... mañana?'"

# game/chapters/1_roomexplore.rpyc:434
translate es door_hub_0a4e4798_1:

    # "'It's a date. I mean, not really, but... see you tomorrow.'"
    "'Es una cita. Digo, no realmente, pero... nos vemos mañana'."

# game/chapters/1_roomexplore.rpyc:435
translate es door_hub_b5790fa3_1:

    # "'See you!'"
    "'¡Nos vemos!'"

# game/chapters/1_roomexplore.rpyc:436
translate es door_hub_b62821ce_1:

    # "You hear the door close and the sound of footsteps walking away from the door, and then silence."
    "Oyes que la puerta se cierra y pasos que se alejan por el pasillo, y luego silencio."

# game/chapters/1_roomexplore.rpyc:437
translate es door_hub_a12d64cc_1:

    # "...Before you hear the sound of pottery falling then shattering onto the ground."
    "...Hasta que escuchas el sonido de cerámica cayendo y rompiéndose contra el suelo."

# game/chapters/1_roomexplore.rpyc:438
translate es door_hub_02098a34_1:

    # "The door opens again."
    "La puerta se abre de nuevo."

# game/chapters/1_roomexplore.rpyc:439
translate es door_hub_e3cf6106_1:

    # "The deep voice speaks first 'I, uh... didn't see your plant there. Coffee's on me?'"
    "La voz profunda habla primero. 'Yo, eh... no vi tu planta ahí. ¿El café corre por mi cuenta?'"

# game/chapters/1_roomexplore.rpyc:440
translate es door_hub_310fcedd_1:

    # "You hear the second voice giggle, then speak. 'It's alright, I've been meaning to get a new pot for ages.'"
    "Escuchas la segunda voz reír, luego hablar. 'Está bien, tenía pensado comprar una maceta nueva desde hace tiempo.'"

# game/chapters/1_roomexplore.rpyc:441
translate es door_hub_7a07a6dc_1:

    # "'Let me at least help cleaning it up.'"
    "'Al menos déjame ayudarte a limpiarlo.'"

# game/chapters/1_roomexplore.rpyc:442
translate es door_hub_0123fc97_1:

    # "'It's really no trouble—'"
    "'De verdad, no es problema—'"

# game/chapters/1_roomexplore.rpyc:443
translate es door_hub_3f8cd6df_1:

    # "'I insist. I was the clumsy one.'"
    "'Insisto. Yo fui el torpe.'"

# game/chapters/1_roomexplore.rpyc:444
translate es door_hub_547c15a9_1:

    # "'...Alright. Let me get the broom.'"
    "'…Está bien. Voy por la escoba.'"

# game/chapters/1_roomexplore.rpyc:445
translate es door_hub_0ba6f623_1:

    # "The voices become muffled, then silent. That seems to be all the information you'll get for the day."
    "Las voces se vuelven apagadas, luego silenciosas. Parece que eso es toda la información que obtendrás por hoy."

# game/chapters/1_roomexplore.rpyc:454
translate es door_hub_2f1c9994:

    # "You listen at the door again: but all is quiet now."
    "Escuchas en la puerta de nuevo: pero ahora todo está en silencio."

# game/chapters/1_roomexplore.rpyc:455
translate es door_hub_7198b0b8:

    # "Perhaps you'll overhear more tomorrow?"
    "¿Quizás escuches más mañana?"

# game/chapters/1_roomexplore.rpyc:473
translate es snake_hub_404f3926:

    # "[pet_name] is napping on your bed."
    "[pet_name] está durmiendo la siesta en tu cama."

# game/chapters/1_roomexplore.rpyc:474
translate es snake_hub_5968bb4c:

    # "[pet_She!t] doesn't seem to want to go back into [pet_her] enclosure."
    "[pet_She!t] no parece querer volver a su recinto."

# game/chapters/1_roomexplore.rpyc:475
translate es snake_hub_93f6de20:

    # "You leave [pet_her2] be for now."
    "Dejas a [pet_her2] en paz por ahora."

# game/chapters/1_roomexplore.rpyc:482
translate es snake_hub_d70c8654:

    # "You leave a little kiss against [pet_name]'s snoot."
    "Dejas un pequeño beso en el hocico de [pet_name]."

# game/chapters/1_roomexplore.rpyc:483
translate es snake_hub_6f43f348:

    # "[pet_She!t] rubs [pet_her] little head against you."
    "[pet_She!t] frota su pequeña cabeza contra ti."

# game/chapters/1_roomexplore.rpyc:497
translate es bingus_hub_7da77281:

    # "[pet_name] is sitting on your bed regally."
    "[pet_name] está en tu cama con porte real."

# game/chapters/1_roomexplore.rpyc:498
translate es bingus_hub_9ade7f8b:

    # "For a moment you're unsure if you own [pet_name], or if [pet_name] owns you."
    "Por un momento, cuesta saber si [pet_name] te pertenece, o si le perteneces a [pet_name]."

# game/chapters/1_roomexplore.rpyc:499
translate es bingus_hub_132e369c:

    # "But of course, it's obvious to you. [pet_name] merely allows your existence."
    "Pero por supuesto, para ti es obvio. [pet_name] simplemente permite tu existencia."

# game/chapters/1_roomexplore.rpyc:504
translate es bingus_hub_435690d7:

    # "You pet [pet_name]."
    "Acaricias a [pet_name]."

# game/chapters/1_roomexplore.rpyc:505
translate es bingus_hub_b92c3a57:

    # "[pet_Her] skin is velvet to the touch."
    "La piel de [pet_Her] es aterciopelada al tacto."

# game/chapters/1_roomexplore.rpyc:506
translate es bingus_hub_4de66689:

    # "[pet_She!t] purrs in response as you give [pet_her2] a scritch under the chin."
    "[pet_She!t] ronronea en respuesta mientras le rascas un poco debajo de la barbilla."

# game/chapters/1_roomexplore.rpyc:521
translate es bunny_hub_b750ff85:

    # "[pet_name] is currently zooming around your bed, playing with toys you bought recently."
    "[pet_name] está dando vueltas por tu cama, jugando con juguetes que compraste recientemente."

# game/chapters/1_roomexplore.rpyc:522
translate es bunny_hub_ebd22173:

    # "[pet_name] slows down for no-bunny."
    "[pet_name] no se detiene por nadie."

# game/chapters/1_roomexplore.rpyc:527
translate es bunny_hub_3779c4eb:

    # "You give [pet_name] a few pieces of leafy greens, and [pet_She!t] chews on them hungrily."
    "Le das a [pet_name] unas cuantas hojas verdes, y [pet_She!t] las mastica con hambre."

# game/chapters/1_roomexplore.rpyc:528
translate es bunny_hub_7a1a813a:

    # "Your stomach rumbles, and for a moment you wish you were a bunny, simple running around on a bed and eating greens."
    "Tu estómago ruge, y por un momento desearías ser un conejo, simplemente corriendo por la cama y comiendo hojas verdes."

# game/chapters/1_roomexplore.rpyc:542
translate es cat_hub_d953f12f:

    # "[pet_name] is fast asleep in the sun."
    "[pet_name] está durmiendo profundamente en el sol."

# game/chapters/1_roomexplore.rpyc:543
translate es cat_hub_b33fec15:

    # "You gently stroke down [pet_name]'s back, not wanting to disturb [pet_her2]."
    "Acaricias suavemente la espalda de [pet_name], sin querer importunar."

# game/chapters/1_roomexplore.rpyc:544
translate es cat_hub_e7304e73:

    # "[pet_She!t]'s so fluffy and soft."
    "[pet_She!t] es tan suave."

# game/chapters/1_roomexplore.rpyc:549
translate es cat_hub_8942db52:

    # "You gently poke at [pet_name]'s toebeans."
    "Pinchas suavemente las almohadillas de [pet_name]."

# game/chapters/1_roomexplore.rpyc:550
translate es cat_hub_8917cd5c:

    # "They're squishy beneath your fingertips."
    "Son blanditas bajo tus dedos."

# game/chapters/1_roomexplore.rpyc:551
translate es cat_hub_c04c2936:

    # "You're thankful [pet_name] is the rare kind of cat who likes belly rubs and toebean poking."
    "Agradeces que [pet_name] sea esa rara clase de gato al que le gustan los masajes de panza y que le aprieten las almohadillas."

# game/chapters/1_roomexplore.rpyc:565
translate es dog_hub_02ee5665:

    # "[pet_name] is resting on your bed, tongue wagging."
    "[pet_name] está descansando en tu cama, con la lengua fuera."

# game/chapters/1_roomexplore.rpyc:566
translate es dog_hub_e3c67bbb:

    # "You give them a belly rub. [pet_She!t] loves belly rubs."
    "Le das un masaje en la barriga. A [pet_she!t] le encantan los masajes en la barriga."

# game/chapters/1_roomexplore.rpyc:567
translate es dog_hub_c4e03d70:

    # "What a good [pet_girl]."
    "Qué buen[pet_girl!t]."

# game/chapters/1_roomexplore.rpyc:572
translate es dog_hub_c7a21c75:

    # "You give [pet_name] a little treat. [pet_She!t] gobbles it up easily."
    "Le das a [pet_name] una pequeña golosina. [pet_She!t] la devora fácilmente."

# game/chapters/1_roomexplore.rpyc:573
translate es dog_hub_3c60cfee:

    # "Who's a good [pet_girl]? You're a good [pet_girl]!"
    "¿Quién es mi buen[pet_girl!t]? ¡Tú eres mi buen[pet_girl!t]!"

# game/chapters/1_roomexplore.rpyc:588
translate es hamster_hub_1b479ac6:

    # "[pet_name] is running around on your bed."
    "[pet_name] está corriendo alrededor de tu cama."

# game/chapters/1_roomexplore.rpyc:589
translate es hamster_hub_4dddd35e:

    # "You spent a lot of time hamster-proofing your apartment, so you don't mind [pet_name] having free reign of the place occasionally."
    "Pasaste mucho tiempo adaptando tu apartamento para hámsteres, así que no te importa que [pet_name] tenga libertad por el lugar de vez en cuando."

# game/chapters/1_roomexplore.rpyc:590
translate es hamster_hub_670a2307:

    # "You smile at [pet_name], then give [pet_her2] a little scritch on the head."
    "Sonríes a [pet_name], luego le das a [pet_her2!t] una pequeña caricia en la cabeza."

# game/chapters/1_roomexplore.rpyc:595
translate es hamster_hub_e0610401:

    # "You quickly cut up a slice of apple and give it to [pet_name]."
    "Cortas rápidamente una rebanada de manzana y se la das a [pet_name]."

# game/chapters/1_roomexplore.rpyc:596
translate es hamster_hub_e8bd748a:

    # "[pet_She!t] snacks on the treat hungrily."
    "[pet_She!t] come la golosina con hambre."

# game/chapters/1_roomexplore.rpyc:597
translate es hamster_hub_769a4bea:

    # "You smile. Apple has always been [pet_her] favorite snack."
    "Sonríes. La manzana siempre ha sido el snack favorito de [pet_her]."

# game/chapters/1_roomexplore.rpyc:615
translate es plant_hub_df5ee1ca:

    # "You give your sprout a hearty drink."
    "Le das a tu retoño un buen trago de agua."

# game/chapters/1_roomexplore.rpyc:616
translate es plant_hub_fe670acc:

    # "You swear you almost hear it saying thank you."
    "Jurarías que casi lo escuchas decir gracias."

# game/chapters/1_roomexplore.rpyc:628
translate es plant_hub_996a6523:

    # "You decide it still looks thirsty."
    "Decides que aún parece tener sed."

# game/chapters/1_roomexplore.rpyc:629
translate es plant_hub_140fd76b:

    # "Water starts to pool on top of the soil."
    "El agua empieza a acumularse sobre la tierra."

# game/chapters/1_roomexplore.rpyc:639
translate es plant_hub_c2b8e22c:

    # "You decide you've made plenty of bad decisions in your life - what's one more?"
    "Decides que ya has tomado muchas malas decisiones en tu vida, ¿qué es una más?"

# game/chapters/1_roomexplore.rpyc:642
translate es plant_hub_ec01dea4:

    # "Water starts overflowing from the edges of the pot as you continue to pour more in."
    "El agua empieza a desbordarse por los bordes de la maceta mientras sigues echando más."

# game/chapters/1_roomexplore.rpyc:643
translate es plant_hub_2133bcde:

    # "It flows all over the floor."
    "Se escurre por todo el suelo."

# game/chapters/1_roomexplore.rpyc:644
translate es plant_hub_51ebf01e:

    # "Fantastic, you think."
    "Fantástico, piensas."

# game/chapters/1_roomexplore.rpyc:645
translate es plant_hub_58344ac4:

    # "You are your own worst enemy."
    "Eres tu peor enemigo."

# game/chapters/1_roomexplore.rpyc:733
translate es desk_hub_b2210f18:

    # "Your trusty laptop."
    "Tu confiable portátil."

# game/chapters/1_roomexplore.rpyc:734
translate es desk_hub_f2affa1b:

    # "It was your first purchase for yourself after you moved out."
    "Fue tu primera compra después de mudarte."

# game/chapters/1_roomexplore.rpyc:735
translate es desk_hub_31426c18:

    # "Remembering how you saved to be able to afford the one you wanted brings a smile to your face."
    "Recordar cómo ahorraste para poder permitirte el que querías dibuja una sonrisa en tu rostro."

# game/chapters/1_roomexplore.rpyc:738
translate es desk_hub_b2210f18_1:

    # "Your trusty laptop."
    "Tu confiable portátil."

# game/chapters/1_roomexplore.rpyc:739
translate es desk_hub_f2affa1b_1:

    # "It was your first purchase for yourself after you moved out."
    "Fue tu primera compra después de mudarte."

# game/chapters/1_roomexplore.rpyc:740
translate es desk_hub_31426c18_1:

    # "Remembering how you saved to be able to afford the one you wanted brings a smile to your face."
    "Recordar cómo ahorraste para poder permitirte el que querías dibuja una sonrisa en tu rostro."

# game/chapters/1_roomexplore.rpyc:746
translate es desk_hub_66549397:

    # "That's it, you think. You are going to commit a very bad act to this laptop of yours."
    "Eso es todo, piensas. Vas a cometer un acto muy malo con este portátil tuyo."

# game/chapters/1_roomexplore.rpyc:747
translate es desk_hub_98709d7f:

    # "You've halfway opened your window when you come to your senses and close the app once more."
    "Tienes la ventana abierta a medias cuando vuelves en sí y cierras la aplicación una vez más."

# game/chapters/1_roomexplore.rpyc:748
translate es desk_hub_75d4c771:

    # "You quickly delete it from your desktop, and empty your trashcan."
    "La eliminas rápidamente del escritorio y vacías la papelera."

# game/chapters/1_roomexplore.rpyc:749
translate es desk_hub_58376d71:

    # "But two moments later, it reappears exactly where it was before, and opens again."
    "Pero dos segundos después, reaparece exactamente donde estaba antes, y se abre de nuevo."

# game/chapters/1_roomexplore.rpyc:750
translate es desk_hub_59438d56:

    # "You think about the sketchy sites you've been on, but even that is hard to concentrate on past the constant dinging."
    "Piensas en los sitios dudosos en los que has estado, pero incluso eso es difícil de concentrar más allá del constante ding."

# game/chapters/1_roomexplore.rpyc:751
translate es desk_hub_18abafc1:

    # "You attempt to delete it again, but it won't delete anymore."
    "Intentas borrarla otra vez, pero ya no se puede borrar."

# game/chapters/1_roomexplore.rpyc:756
translate es desk_hub_733f21a5:

    # "Nothing happens."
    "No pasa nada."

# game/chapters/1_roomexplore.rpyc:759
translate es desk_hub_d1c9262e:

    # "Nothing continues to happen."
    "Nada continúa pasando."

# game/chapters/1_roomexplore.rpyc:765
translate es desk_hub_1ded2928:

    # "Nope, you think. Not today."
    "Nope, piensas. Hoy no."

# game/chapters/1_roomexplore.rpyc:766
translate es desk_hub_44523497:

    # "You keep staring at it."
    "Sigues mirándola fijamente."

# game/chapters/1_roomexplore.rpyc:767
translate es desk_hub_5f9b772e:

    # "...."
    "...."

# game/chapters/1_roomexplore.rpyc:768
translate es desk_hub_d1ddaffa:

    # "........"
    "........"

# game/chapters/1_roomexplore.rpyc:769
translate es desk_hub_7413fd7d:

    # "The dinging begins to drive you insane."
    "El ding comienza a volverte loco."

# game/chapters/1_roomexplore.rpyc:770
translate es desk_hub_f6bc19b7:

    # "You attempt to shut the computer down, but even that isn't working."
    "Intentas apagar el ordenador, pero ni eso funciona."

# game/chapters/1_roomexplore.rpyc:773
translate es desk_hub_d9a2f93a:

    # "It seems to be a strange chatroom."
    "Parece ser una sala de chat extraña."

# game/chapters/1_roomexplore.rpyc:778
translate es desk_hub_397e2b78:

    # "You click on the app, finally taking a good look at it."
    "Haces clic en la app, finalmente mirándola bien."

# game/chapters/1_roomexplore.rpyc:779
translate es desk_hub_b7a04f90:

    # "It's some kind of chatroom. It looks somewhat retro."
    "Es una especie de sala de chat. Tiene un aspecto algo retro."

# game/chapters/1_roomexplore.rpyc:797
translate es desk_forced_16e7e189:

    # "A ding comes from your laptop."
    "Un ding sale de tu portátil."

# game/chapters/1_roomexplore.rpyc:798
translate es desk_forced_1cdf5c49:

    # "You take a look at what you expected to be an email..."
    "Echas un vistazo a lo que esperabas que fuera un correo..."

# game/chapters/1_roomexplore.rpyc:799
translate es desk_forced_fb9e7a99:

    # "Instead, you find yourself face to face with a strange app you've never seen before."
    "En su lugar, te encuentras cara a cara con una extraña aplicación que nunca habías visto antes."

# game/chapters/1_roomexplore.rpyc:800
translate es desk_forced_6d5e2a31:

    # "You look at it for a moment, before hitting the 'x' in the corner of the program."
    "La miras por un momento, antes de darle a la 'x' en la esquina del programa."

# game/chapters/1_roomexplore.rpyc:818
translate es desk_forced_2dd45ee4:

    # "A second ding echoes through the room."
    "Un segundo ding resuena por la habitación."

# game/chapters/1_roomexplore.rpyc:819
translate es desk_forced_6173fb06:

    # "Worried, you look back to your laptop's screen."
    "Con preocupación miras de nuevo la pantalla del portátil."

# game/chapters/1_roomexplore.rpyc:820
translate es desk_forced_5bc5655f:

    # "The app is once again open and flashing on your hotbar."
    "La app está abierta otra vez y parpadea en tu barra de tareas."

# game/chapters/1_roomexplore.rpyc:821
translate es desk_forced_728e7b48:

    # "You wonder for a moment if you'd somehow picked up some malware."
    "Por un momento te preguntas si de alguna forma has cogido algún malware."

# game/chapters/1_roomexplore.rpyc:839
translate es desk_forced_b6ee5a82:

    # "The dings are coming much more frequently now. Someone - or something - wants your attention."
    "Los dings vienen ahora mucho más frecuentemente. Alguien —o algo— quiere tu atención."

# game/chapters/1_roomexplore.rpyc:840
translate es desk_forced_f6bd783d:

    # "You're not worried now - you're angry."
    "Ya no te estás preocupando —te estás enfadando."

# game/chapters/1_roomexplore.rpyc:841
translate es desk_forced_a8490a60:

    # "The dinging is starting to annoy you."
    "El ding empieza a molestarte."

# game/chapters/1_roomexplore.rpyc:842
translate es desk_forced_e7b2f0f6:

    # "For a moment, you contemplate throwing your laptop out of the window, but calm before you possibly commit a crime by dropping a laptop from the fifth story of a building and knocking someone out."
    "Por un momento, contemplas tirar el portátil por la ventana, pero te calmas antes de posiblemente cometer un crimen al lanzar un portátil desde el quinto piso y dejar a alguien inconsciente."

# game/chapters/1_roomexplore.rpyc:858
translate es desk_forced_f0b94484:

    # "The dinging is constant. You don't know how much longer you can put up with the sound."
    "El ding es constante. No sabes cuánto tiempo más podrás soportar el sonido."

# game/chapters/1_roomexplore.rpyc:859
translate es desk_forced_a0af7c6b:

    # "Perhaps it's time to check what's going on here..."
    "Quizás sea hora de mirar qué está pasando aquí..."

translate es strings:

    old "ma'am"
    new "señora"

    old "mister"
    new "señor"

    old "Your Bed"
    new "Tu Cama"
    
    old "Door"
    new "Puerta"

    old "Your Plant"
    new "Tu Planta"

    old "Renovate & Appearance"
    new "Renovación & Apariencia"

    old "Your Laptop"
    new "Tu Laptop"

    old "Bookshelf"
    new "Estantería"

    old "Change Music"
    new "Cambiar Música"

    old "Your Pet"
    new "Tu Mascota"


    old "Name your pet:"
    new "Nombra a tu mascota:"

    old "Gender:"
    new "Género:"

    #Libro
    old "{i}The Wanderer{/i}"
    new "{i}El vagabundo{/i}"
    
    old "The world was empty."
    new "El mundo estaba vacío."

    old "Life was gone."
    new "La vida se había ido."

    old "The soul whisperer wandered, now and forever."
    new "El susurrador de almas vagaba, ahora y por siempre."

    old "For an eternity, their footsteps echoed through empty streets and desolate ruins."
    new "Por una eternidad, sus pasos resonaban entre calles vacías y ruinas desoladas."

    old "Not even a soul remained to guide to their final resting place."
    new "Ni siquiera quedaba un alma a la cual guiar hacia su lugar de descanso final."

    old "And so, the soul whisperer was alone."
    new "Y así, el susurrador de almas estaba solo."

    old "Such was their fate. The fate of one bound to both life and death, without possessing either."
    new "Tal era su destino. El destino de alguien atado tanto a la vida como a la muerte, sin poseer ninguna de las dos."

    old "They walked through a crumbling city, looking in on the remains of a civilization lost to time. Had it been a hundred years, or a thousand? Seconds merged into minutes, hours into days, months into years…"
    new "Caminaba por una ciudad en ruinas, observando los restos de una civilización perdida en el tiempo. ¿Habían pasado cien años, o mil? Los segundos se fundían en minutos, las horas en días, los meses en años…"

    old "And for once, they wondered when their wandering would come to an end. Their soul was bound to the very world, fated to walk it until the very land itself ceased to exist."
    new "Y por una vez, se preguntó cuándo acabaría su andar. Su alma estaba ligada al mismo mundo, condenada a recorrerlo hasta que la propia tierra dejara de existir."

    old "Something caught their eye."
    new "Algo llamó su atención."

    old "A soul unlike any other. As black as night, with a thousand silvery stars glittering and flowing like a river within its dark folds."
    new "Un alma como ninguna otra. Tan negra como la noche, con mil estrellas plateadas brillando y fluyendo como un río dentro de sus pliegues oscuros."

    old "The soul whisperer approached it, and in turn it sang them a song."
    new "El susurrador de almas se le acercó, y a su vez esta le cantó una canción."

    old "A voiceless song filled with wonder and awe. For a moment, the soul whisperer was lost in the rhythm of the universe, caught up in the symphony of the cosmos."
    new "Una canción sin voz, llena de maravilla y asombro. Por un instante, el susurrador de almas se perdió en el ritmo del universo, atrapado en la sinfonía del cosmos."

    old "But soon enough, the song came to an end, and the soul whisperer finally felt something they didn’t know was possible."
    new "Pero pronto, la canción llegó a su fin, y el susurrador de almas sintió algo que no sabía que era posible."

    old "Fear."
    new "Miedo."

    old "Fear of the loneliness that came with guiding the world’s final soul to their resting place."
    new "Miedo a la soledad que venía con guiar al alma final del mundo hasta su lugar de descanso."

    old "It only took a moment for the soul to disappear, leaving behind a sea of glittering stars in the wanderer’s wake."
    new "Solo tomó un instante para que el alma desapareciera, dejando atrás un mar de estrellas brillantes en el rastro del vagabundo."

    old "But the soul whisperer remained, an eternal wanderer, forever seeking the lost souls of the world that were already long gone."
    new "Pero el susurrador de almas permanecía, un vagabundo eterno, siempre buscando las almas perdidas del mundo que ya hacía mucho tiempo se habían ido."


    old "1. Eavesdrop... just a little bit."
    new "1. Escuchar a escondidas... solo un poquito."

    old "2. Leave the door alone."
    new "2. Alejarte de la puerta."

    old "Check on [pet_name]."
    new "Echar un vistazo a [pet_name]."

    old "Kiss [pet_name]."
    new "Besar a [pet_name]."

    old "Pet [pet_name]."
    new "Acariciar a [pet_name]."

    old "Give [pet_name] some greens."
    new "Dar verduras a [pet_name]."

    old "Touch [pet_name]'s toebeans."
    new "Tocar las patitas de [pet_name]."

    old "Give [pet_name] a treat."
    new "Dar una golosina a [pet_name]." 

    old "Give [pet_name] a snack."
    new "Dar un snack a [pet_name]."

    old "Water your plant."
    new "Regar tu planta."
    
    old "Don't water it."
    new "No regarla."

    old "Water it some more."
    new "Regarla un poco más."

    old "Don't water it more."
    new "No regarla más."

    old "Water it some more... again."
    new "Regar un poco más... otra vez."

    old "Don't water it more. Seriously."
    new "No regarla más. En serio."

    old "No more watering."
    new "No más agua."
    
    old "Pick a new book to read."
    new "Elegir un nuevo libro para leer."

    old "Read a book again."
    new "Volver a leer un libro."

    old "Nevermind."
    new "No importa."

    old "Update Appearance."
    new "Cambiar Apariencia."

    old "Renovate Room."
    new "Renovar habitación."

    old "Update Bio."
    new "Actualizar biografía."

    old "1. Try again."
    new "1. Inténtalo de nuevo."

    old "1. Try again... but angrier."
    new "1. Inténtalo de nuevo... pero con más enojo."
    
    old "1. Great, guess I've got a virus..."
    new "1. Genial, supongo que tengo un virus..."

    old "1. Stare the app down."
    new "1. Mirar fijamente la aplicación."

    old "1. Click on the app."
    new "1. Hacer clic en la aplicación."

    old "2. Click on the app."
    new "2. Hacer clic en la aplicación."

    old "1. I guess I'll just ignore it for now..."
    new "1. Creo que por ahora lo ignoraré..."

    old "2. I'll deal with it later..."
    new "2. Me ocuparé de eso más tarde..."

    old "1. Delete the app."
    new "1. Eliminar la aplicación."

    old "2. Ignore it."
    new "2. Ignórala."

