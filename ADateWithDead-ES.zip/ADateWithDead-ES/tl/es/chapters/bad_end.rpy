
# game/chapters/bad_end.rpyc:16
translate es badend_start_9b66546a:

    # center_text "You once again spent the day mostly at home, but..."
    center_text "Una vez más pasaste el día mayormente en casa, pero..."

# game/chapters/bad_end.rpyc:17
translate es badend_start_592b60ec:

    # center_text "Since you woke up, you've been feeling a little strange."
    center_text "Desde que despertaste, te has sentido un poco extraño."

# game/chapters/bad_end.rpyc:18
translate es badend_start_4abb1dce:

    # center_text "Off-balance, perhaps."
    center_text "Fuera de equilibrio, quizá."

# game/chapters/bad_end.rpyc:19
translate es badend_start_8ace40da:

    # center_text "Not only that, but [pet_name] was also acting a bit off. A little sluggish."
    center_text "Y no solo eso, [pet_name] también estaba actuando raro. Un poco torpe."

# game/chapters/bad_end.rpyc:20
translate es badend_start_78fe50ea:

    # center_text "You had a quick trip to the vet, but they found nothing wrong with [pet_her2]."
    center_text "Hiciste una visita rápida al veterinario, pero no encontraron nada malo en [pet_she!t]."

# game/chapters/bad_end.rpyc:21
translate es badend_start_372bbfaa:

    # center_text "So, you've stayed by [pet_name]'s side, trying your best to will [pet_her2] to good health."
    center_text "Así que te has quedado al lado de [pet_name], haciendo tu mejor esfuerzo para desearle buena salud a [pet_she!t]."

# game/chapters/bad_end.rpyc:59
translate es day7_start_badend_fc4f3f0e:

    # player "Not to alarm you or anything, but I think something's... wrong."
    player "No quiero alarmarte ni nada, pero creo que algo está... mal."

# game/chapters/bad_end.rpyc:62
translate es day7_start_badend_3704a528:

    # player "Um..."
    player "Um..."

# game/chapters/bad_end.rpyc:65
translate es day7_start_badend_6891127e:

    # player "I'm starting to freak out a bit..."
    player "Estoy empezando a asustarme un poco..."

# game/chapters/bad_end.rpyc:68
translate es day7_start_badend_97a9d6f5:

    # player "My plant just... died."
    player "Mi planta simplemente... murió."

# game/chapters/bad_end.rpyc:69
translate es day7_start_badend_70c3d462:

    # GR "your plant? did you not water it?"
    GR "¿tu planta? ¿no la regaste?"

# game/chapters/bad_end.rpyc:72
translate es day7_start_badend_c5e75e2b:

    # player "Of course I did."
    player "Por supuesto que sí."

# game/chapters/bad_end.rpyc:76
translate es day7_start_badend_3af3ab6b:

    # player "It was fine yesterday."
    player "Ayer estaba bien."

# game/chapters/bad_end.rpyc:79
translate es day7_start_badend_d29a2450:

    # player "Why would it suddenly shrivel up overnight?"
    player "¿Por qué de repente se marchitaría de la noche a la mañana?"

# game/chapters/bad_end.rpyc:81
translate es day7_start_badend_3f1be4aa:

    # GR "perhaps too much water? i do not know much about keeping plants."
    GR "¿quizá demasiada agua? no sé mucho sobre cuidar plantas."

# game/chapters/bad_end.rpyc:84
translate es day7_start_badend_1ca5a80a:

    # player "And [pet_name] is sick again."
    player "Y [pet_name] se enfermo otra vez."

# game/chapters/bad_end.rpyc:85
translate es day7_start_badend_8ede3c01:

    # GR "what?"
    GR "¿qué?"

# game/chapters/bad_end.rpyc:86
translate es day7_start_badend_7c2d79f2:

    # GR "are you unwell too?"
    GR "¿tú también te sientes mal?"

# game/chapters/bad_end.rpyc:89
translate es day7_start_badend_828c4437:

    # player "I think I'm alright?"
    player "Creo que estoy bien."

# game/chapters/bad_end.rpyc:91
translate es day7_start_badend_22e1a291:

    # player "No, I'm totally fine..."
    player "No, estoy totalmente bien..."

# game/chapters/bad_end.rpyc:94
translate es day7_start_badend_cae94362:

    # player "Just stressed about [pet_name]."
    player "Solo con estrés por lo de [pet_name]."

# game/chapters/bad_end.rpyc:96
translate es day7_start_badend_9d36256c:

    # GR "not that i think you should use your 'talent' so much, but have you tried...?"
    GR "no es que crea que deberías usar tanto tu 'talento', pero ¿has intentado...?"

# game/chapters/bad_end.rpyc:99
translate es day7_start_badend_fc3b5e7e:

    # player "Of course I have. I've been trying all morning."
    player "Por supuesto que sí. He estado intentándolo toda la mañana."

# game/chapters/bad_end.rpyc:101
translate es day7_start_badend_ee4f773f:

    # player "It's all I've done today."
    player "Es todo lo que he hecho hoy."

# game/chapters/bad_end.rpyc:104
translate es day7_start_badend_d3fc1410:

    # player "And it's not working."
    player "Y no está funcionando."

# game/chapters/bad_end.rpyc:107
translate es day7_start_badend_56ecd767:

    # player "Are you positive I can really... heal things like that?"
    player "¿Estás seguro de que realmente puedo... sanar cosas así?"

# game/chapters/bad_end.rpyc:108
translate es day7_start_badend_db9c2be2:

    # GR "i felt it sunshine, i'm pretty sure."
    GR "lo sentí, solecito, estoy bastante seguro."

# game/chapters/bad_end.rpyc:109
translate es day7_start_badend_7d131b5f:

    # GR "i am correct 99 percent of the time, after all."
    GR "al fin y al cabo, tengo razón el 99 por ciento del tiempo."

# game/chapters/bad_end.rpyc:112
translate es day7_start_badend_fa758fc3:

    # player "And you? How do {i}you{/i} feel?"
    player "¿Y tú? ¿Cómo te sientes {i}tú{/i}?"

# game/chapters/bad_end.rpyc:113
translate es day7_start_badend_ad6c7f8d:

    # GR "fine."
    GR "bien."

# game/chapters/bad_end.rpyc:114
translate es day7_start_badend_af99844c:

    # GR "well, my body is fine. my mind has taken a beating from lack of sleep last night..."
    GR "bueno, mi cuerpo está bien. mi mente ha recibido una paliza por la falta de sueño anoche..."

# game/chapters/bad_end.rpyc:117
translate es day7_start_badend_95eae8c9:

    # player "[pet_She] doesn't even want to eat [pet_her] favorite treats."
    player "[pet_She!t] ni siquiera quiere comer sus golosinas favoritas."

# game/chapters/bad_end.rpyc:118
translate es day7_start_badend_a7d2a095:

    # GR "hmm. perhaps there is some limit to the amount of your soul you can give away in a short period of time."
    GR "hmm. tal vez haya un límite en la cantidad de tu alma que puedes entregar en un corto período de tiempo."

# game/chapters/bad_end.rpyc:121
translate es day7_start_badend_b37e2154:

    # player "Well... if you say so."
    player "Bueno... si tú lo dices."

# game/chapters/bad_end.rpyc:124
translate es day7_start_badend_210514d3:

    # player "I hope you're right."
    player "Espero que tengas razón."

# game/chapters/bad_end.rpyc:127
translate es day7_start_badend_55d8a27a:

    # player "I'll... try again later."
    player "Intentaré de nuevo más tarde."

# game/chapters/bad_end.rpyc:128
translate es day7_start_badend_59560e6f:

    # GR "you might just need to replenish some energy."
    GR "quizá solo necesites reponer algo de energía."

# game/chapters/bad_end.rpyc:129
translate es day7_start_badend_bacf4da5:

    # GR "have you eaten?"
    GR "¿has comido?"

# game/chapters/bad_end.rpyc:132
translate es day7_start_badend_c969faaf:

    # player "Yes, of course I have."
    player "Sí, por supuesto que sí."

# game/chapters/bad_end.rpyc:135
translate es day7_start_badend_2bd0e441:

    # player "But I did forget to grab a drink."
    player "Pero olvidé tomar algo de beber."

# game/chapters/bad_end.rpyc:136
translate es day7_start_badend_a50e9834:

    # GR "go. drink some water. it will do you good."
    GR "ve. bebe un poco de agua. te hará bien."

# game/chapters/bad_end.rpyc:139
translate es day7_start_badend_c0c4c6af:

    # player "Right now?"
    player "¿Ahora mismo?"

# game/chapters/bad_end.rpyc:140
translate es day7_start_badend_1097ad3b:

    # GR "yes, right now. go on."
    GR "sí, ahora mismo. anda."

# game/chapters/bad_end.rpyc:143
translate es day7_start_badend_09f03f38:

    # player "Yes boss... I'll brb."
    player "Sí, jefe... ya vuelvo."

# game/chapters/bad_end.rpyc:145
translate es day7_start_badend_01b0c35d:

    # player "Not yet, no."
    player "Aún no, no."

# game/chapters/bad_end.rpyc:148
translate es day7_start_badend_83b16343:

    # player "I'll get something soon though."
    player "Pero conseguiré algo pronto."

# game/chapters/bad_end.rpyc:151
translate es day7_start_badend_23fdd22e:

    # player "I'm getting a bit hungry now that you mention it."
    player "Me está dando un poco de hambre ahora que lo mencionas."

# game/chapters/bad_end.rpyc:152
translate es day7_start_badend_0e2e4ce6:

    # GR "then eat. it is not good to ignore your body."
    GR "entonces come. no es bueno ignorar tu cuerpo."

# game/chapters/bad_end.rpyc:155
translate es day7_start_badend_9d2cf585:

    # player "But I'm talking with you."
    player "Pero estoy hablando contigo."

# game/chapters/bad_end.rpyc:156
translate es day7_start_badend_fd471719:

    # GR "which you can do after you have eaten."
    GR "lo cual puedes hacer después de haber comido."

# game/chapters/bad_end.rpyc:157
translate es day7_start_badend_36119ac7:

    # GR "and had a drink of water. go on."
    GR "y de haber tomado agua. anda."

# game/chapters/bad_end.rpyc:160
translate es day7_start_badend_60c79953:

    # player "Yeah okay. I'm on it."
    player "Sí, está bien. Ya voy."

# game/chapters/bad_end.rpyc:163
translate es day7_start_badend_540d0a6c:

    # player "Alright bossy boots."
    player "Está bien, mandon."

# game/chapters/bad_end.rpyc:166
translate es day7_start_badend_e1579e34:

    # player "What a worrywart you've turned out to be."
    player "Qué preocupon resultaste ser."

# game/chapters/bad_end.rpyc:167
translate es day7_start_badend_e3726825:

    # GR "wait, what did you just call me..."
    GR "espera, ¿cómo me acabas de llamar...?"

# game/chapters/bad_end.rpyc:171
translate es day7_start_badend_78825d93:

    # player "Bossy boots."
    player "Mandon."

# game/chapters/bad_end.rpyc:172
translate es day7_start_badend_5cff57dd:

    # GR "...i meant the other thing. bossy, i can accept."
    GR "...me refería a lo otro. lo de 'mandona' lo acepto."

# game/chapters/bad_end.rpyc:176
translate es day7_start_badend_b6d0bfb1:

    # player "A worrywart."
    player "Preocupon."

# game/chapters/bad_end.rpyc:178
translate es day7_start_badend_76f1d525:

    # GR "what the... that makes me sound like some fussing housewife."
    GR "¿qué demonios...? eso me hace sonar como una ama de casa histérica."

# game/chapters/bad_end.rpyc:181
translate es day7_start_badend_65db04cd:

    # player "Ha."
    player "Ja."

# game/chapters/bad_end.rpyc:184
translate es day7_start_badend_313285f3:

    # player "You kinda are. BRB."
    player "Un poco lo eres. Ya vuelvo."

# game/chapters/bad_end.rpyc:187
translate es day7_start_badend_25b2ab8a:

    # player "Oops... no. I forgot."
    player "Ups... no. Lo olvidé."

# game/chapters/bad_end.rpyc:190
translate es day7_start_badend_818585bb:

    # player "I guess I was too distracted with everything going on today..."
    player "Supongo que estaba demasiado distraído con todo lo que pasa hoy..."

# game/chapters/bad_end.rpyc:193
translate es day7_start_badend_d236b2b6:

    # player "I will soon."
    player "Lo haré pronto."

# game/chapters/bad_end.rpyc:194
translate es day7_start_badend_768dc623:

    # GR "soon is not good enough."
    GR "pronto no es suficiente."

# game/chapters/bad_end.rpyc:195
translate es day7_start_badend_5f0d8b93:

    # GR "do you often forget to eat?"
    GR "¿olvidas comer a menudo?"

# game/chapters/bad_end.rpyc:198
translate es day7_start_badend_c778c7fd:

    # player "Yeah, all the time."
    player "Sí, todo el tiempo."

# game/chapters/bad_end.rpyc:199
translate es day7_start_badend_755dd737:

    # GR "i shall remind you then."
    GR "entonces te recordaré."

# game/chapters/bad_end.rpyc:200
translate es day7_start_badend_dd307926:

    # GR "go get something now."
    GR "ve a buscar algo ahora."

# game/chapters/bad_end.rpyc:203
translate es day7_start_badend_889cc230:

    # player "What? I'm fine."
    player "¿Qué? Estoy bien."

# game/chapters/bad_end.rpyc:204
translate es day7_start_badend_5906af53:

    # GR "shoo. it is food time, mortal."
    GR "fuera. es hora de comer, mortal."

# game/chapters/bad_end.rpyc:205
translate es day7_start_badend_dd973f1c:

    # GR "come back when you've eaten."
    GR "vuelve cuando hayas comido."

# game/chapters/bad_end.rpyc:209
translate es day7_start_badend_876680f1:

    # player "So demanding..."
    player "Tan exigente..."

# game/chapters/bad_end.rpyc:212
translate es day7_start_badend_dc850466:

    # player "Fine. I'll be right back!"
    player "Bien. ¡Ya vuelvo!"

# game/chapters/bad_end.rpyc:215
translate es day7_start_badend_196b3fcd:

    # player "Nah. I think I'm just stressed out."
    player "Nah. Creo que solo tengo estrés."

# game/chapters/bad_end.rpyc:218
translate es day7_start_badend_cf61fb1b:

    # player "I'll grab something now."
    player "Iré a buscar algo ahora."

# game/chapters/bad_end.rpyc:220
translate es day7_start_badend_5f5a5df7:

    # GR "good little mortal."
    GR "buen mortal."

# game/chapters/bad_end.rpyc:223
translate es day7_start_badend_20a0d775:

    # player "I'll be right back!"
    player "¡Ya vuelvo!"

# game/chapters/bad_end.rpyc:237
translate es day7_start_badend_aed80d74:

    # "You step away from your computer and head to your kitchen for a quick snack and some water."
    "Te alejas de tu computadora y vas a la cocina por un bocadillo rápido y algo de agua."

# game/chapters/bad_end.rpyc:238
translate es day7_start_badend_5579689f:

    # "Though they make your stomach feel slightly less empty, you now notice something else."
    "Aunque hacen que tu estómago se sienta un poco menos vacío, ahora notas otra cosa."

# game/chapters/bad_end.rpyc:239
translate es day7_start_badend_9def2203:

    # "A strange darkness in the corners of your vision... was that there before?"
    "Una extraña oscuridad en los bordes de tu visión... ¿estaba ahí antes?"

# game/chapters/bad_end.rpyc:240
translate es day7_start_badend_ea11c52d:

    # "You shake your head and go back to [pet_name]. [pet_She] is still looking a little bit sickly."
    "Sacudes la cabeza y vuelves con [pet_name]. [pet_She!t] todavía parece un poco débil."

# game/chapters/bad_end.rpyc:241
translate es day7_start_badend_6eed09cb:

    # "You kneel down in front of [pet_her2] and concentrate as hard as you can - concentrate on your wish."
    "Te arrodillas frente a [pet_she!t] y te concentras con todas tus fuerzas, concentrándote en tu deseo."

# game/chapters/bad_end.rpyc:242
translate es day7_start_badend_7f31ca5b:

    # "Your head throbs a little, but nothing else happens."
    "Tu cabeza late un poco, pero no pasa nada más."

# game/chapters/bad_end.rpyc:243
translate es day7_start_badend_ec690227:

    # "So you try again. And again. And one more time, for good measure."
    "Así que lo intentas de nuevo. Y otra vez. Y una vez más, por si acaso."

# game/chapters/bad_end.rpyc:244
translate es day7_start_badend_90cedd77:

    # "You feel slightly faint, but nothing else is obviously changing."
    "Sientes un poco de mareo, pero nada parece cambiar visiblemente."

# game/chapters/bad_end.rpyc:245
translate es day7_start_badend_9078101a:

    # "With a sigh, you go back to your computer."
    "Con un suspiro, vuelves a tu computadora."

# game/chapters/bad_end.rpyc:273
translate es day7_start_badend_78ae02db:

    # player "I'm back, are you happy now?"
    player "He vuelto, ¿feliz ahora?"

# game/chapters/bad_end.rpyc:274
translate es day7_start_badend_e6d167b4:

    # GR "to be honest, yes i am happier if you are eating properly."
    GR "para ser honesto, sí soy más feliz si estás comiendo bien."

# game/chapters/bad_end.rpyc:275
translate es day7_start_badend_946b4443:

    # GR "it is a stupid thing to be happy about when i have to kill you and take your soul, but that is... unimportant."
    GR "es una tontería alegrarse porque tengo que matarte y tomar tu alma, pero eso es... irrelevante."

# game/chapters/bad_end.rpyc:278
translate es day7_start_badend_c498bcf3:

    # player "I tried to help [pet_name] again, too."
    player "También intenté ayudar a [pet_name] otra vez."

# game/chapters/bad_end.rpyc:280
translate es day7_start_badend_5d758716:

    # GR "you tried again? that quickly?!"
    GR "¿intentaste de nuevo? ¿tan pronto?"

# game/chapters/bad_end.rpyc:283
translate es day7_start_badend_c5e75e2b_1:

    # player "Of course I did."
    player "Por supuesto que sí."

# game/chapters/bad_end.rpyc:286
translate es day7_start_badend_89acbb49:

    # player "I told you I'll always try hard for [pet_her2]"
    player "Te dije que siempre haría mi mejor esfuerzo por [pet_she!t]."

# game/chapters/bad_end.rpyc:287
translate es day7_start_badend_d1e891c1:

    # GR "answer this immediately."
    GR "responde esto de inmediato."

# game/chapters/bad_end.rpyc:321
translate es call1_daybadend_437abfb9:

    # GRC "You are seriously the biggest idiot I know."
    GRC "Eres seriamente el mayor idiota que conozco."

# game/chapters/bad_end.rpyc:324
translate es call1_daybadend_b07ce025:

    # GRC "Okay. Yes, I suppose it is rude. But you know what?"
    GRC "Está bien. Sí, Supongo que es grosero. Pero ¿sabes qué?"

# game/chapters/bad_end.rpyc:325
translate es call1_daybadend_c4d4f270:

    # GRC "It is also true."
    GRC "También es verdad."

# game/chapters/bad_end.rpyc:328
translate es call1_daybadend_1ba0f88a:

    # GRC "At least give yourself some time..."
    GRC "Al menos date algo de tiempo..."

# game/chapters/bad_end.rpyc:336
translate es call1_daybadend_6dd87f95:

    # GRC "Makes you sick?"
    GRC "¿Te enferma?"

# game/chapters/bad_end.rpyc:337
translate es call1_daybadend_050fcf84:

    # GRC "If you give all your soul away, you won't be sick."
    GRC "Si entregas toda tu alma, no te enfermarás."

# game/chapters/bad_end.rpyc:340
translate es call1_daybadend_f3130d22:

    # GRC "You'll be gone."
    GRC "Desaparecerás."

# game/chapters/bad_end.rpyc:342
translate es call1_daybadend_4e0180b7:

    # GRC "Not even dead. Just... gone."
    GRC "Ni siquiera muriendo. Simplemente... desapareciendo."

# game/chapters/bad_end.rpyc:347
translate es call1_daybadend_24308b39:

    # GRC "You've gotta be more careful."
    GRC "Tienes que tener más cuidado."

# game/chapters/bad_end.rpyc:355
translate es call1_daybadend_d4b53a19:

    # GRC "If there is anyone you should be sorry to, it should be yourself."
    GRC "Si hay alguien a quien deberías pedirle perdón, es a ti."

# game/chapters/bad_end.rpyc:357
translate es call1_daybadend_47952b8e:

    # GRC "Are you sure you're feeling well?"
    GRC "¿Estás bien de verdad?"

# game/chapters/bad_end.rpyc:363
translate es call1_daybadend_78950dc1:

    # GRC "...Sunshine?"
    GRC "¿...Solecito?"

# game/chapters/bad_end.rpyc:372
translate es call1_daybadend_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/bad_end.rpyc:374
translate es call1_daybadend_0e06ec48:

    # GRC "Close your eyes."
    GRC "Cierra los ojos."

# game/chapters/bad_end.rpyc:375
translate es call1_daybadend_54914837:

    # GRC "You still have part of my soul within you, for better or worse."
    GRC "Aún tienes parte de mi alma dentro de ti, para bien o para mal."

# game/chapters/bad_end.rpyc:376
translate es call1_daybadend_6e95738f:

    # GRC "I will use it to check your soul more closely."
    GRC "La usaré para examinar tu alma más de cerca."

# game/chapters/bad_end.rpyc:384
translate es call1_daybadend_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/bad_end.rpyc:385
translate es call1_daybadend_068bddd6:

    # GRC "This... can't be right..."
    GRC "Esto... no puede ser verdad..."

# game/chapters/bad_end.rpyc:391
translate es call1_daybadend_2d0e002a:

    # GRC "Stay still and keep your eyes shut. I'm concentrating."
    GRC "No te muevas y mantén los ojos cerrados. Estoy concentrándome."

# game/chapters/bad_end.rpyc:392
translate es call1_daybadend_55bdc250:

    # GRC "......"
    GRC "......"

# game/chapters/bad_end.rpyc:393
translate es call1_daybadend_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/bad_end.rpyc:394
translate es call1_daybadend_e699174f:

    # GRC "Open up."
    GRC "Abre los ojos."

# game/chapters/bad_end.rpyc:408
translate es call1_daybadend_87c6dc70:

    # GRC "How many times did you try to heal your pet?"
    GRC "¿Cuántas veces intentaste sanar a tu mascota?"

# game/chapters/bad_end.rpyc:414
translate es call1_daybadend_9467829c:

    # GRC "....."
    GRC "....."

# game/chapters/bad_end.rpyc:415
translate es call1_daybadend_29f7e139:

    # GRC "I would say something was changing, because now your soul is barely a flicker."
    GRC "Diría que algo estaba cambiando, porque ahora tu alma apenas brilla."

# game/chapters/bad_end.rpyc:424
translate es call1_daybadend_f26ff6d4:

    # GRC "It could if you were doing it constantly, all day."
    GRC "Podría pasar si lo hicieras constantemente, todo el día."

# game/chapters/bad_end.rpyc:425
translate es call1_daybadend_ff3aa4a6:

    # GRC "Mortal, stay there. I will make my way to your abode this instant."
    GRC "Mortal, quédate ahí. Iré a tu morada en este instante."

# game/chapters/bad_end.rpyc:432
translate es call1_daybadend_70aaad38:

    # GRC "It is an urgent matter."
    GRC "Es un asunto urgente."

# game/chapters/bad_end.rpyc:444
translate es call1_daybadend_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/bad_end.rpyc:445
translate es call1_daybadend_65c01572:

    # GRC "Hang in there, okay?"
    GRC "Aguanta, ¿sí?"

# game/chapters/bad_end.rpyc:467
translate es chat2_daybadend_b9c60c4c:

    # "{i}You once again stand up from your desk, but this time you feel much more shaky on your feet.{/i}"
    "{i}Una vez más te levantas de tu escritorio, pero esta vez te sientes mucho más inestable sobre tus pies.{/i}"

# game/chapters/bad_end.rpyc:468
translate es chat2_daybadend_4d462333:

    # "{i}Your vision is going in and out of focus...{/i}"
    "{i}Tu visión va y viene, desenfocada...{/i}"

# game/chapters/bad_end.rpyc:469
translate es chat2_daybadend_0f95e53d:

    # "{i}Something isn't right. Now, you're sure of that.{/i}"
    "{i}Algo no está bien. Ahora estás seguro de eso.{/i}"

# game/chapters/bad_end.rpyc:470
translate es chat2_daybadend_47a0a03d:

    # "{i}However, turning to look at [pet_name]... [pet_she]'s perked right up.{/i}"
    "{i}Sin embargo, al girarte para mirar a [pet_name]... [pet_she!t] se animó de inmediato.{/i}"

# game/chapters/bad_end.rpyc:471
translate es chat2_daybadend_11a2f5bc:

    # "{i}'Ah,' you think. 'Everything is okay now.'{/i}"
    "{i}'Ah', piensas. 'Todo está bien ahora.'{/i}"

# game/chapters/bad_end.rpyc:472
translate es chat2_daybadend_6f0a0332:

    # "{i}You sit down on the edge of your bed.{/i}"
    "{i}Te sientas al borde de la cama.{/i}"

# game/chapters/bad_end.rpyc:473
translate es chat2_daybadend_c07a31f7:

    # "{i}And you wait.{/i}"
    "{i}Y esperas.{/i}"

# game/chapters/bad_end.rpyc:474
translate es chat2_daybadend_cd886038:

    # "{i}It doesn't take long for your window to be pulled open.{/i}"
    "{i}No pasa mucho tiempo antes de que tu ventana se abra de golpe.{/i}"

# game/chapters/bad_end.rpyc:496
translate es chat2_daybadend_b1599809:

    # GRC "Sunshine!"
    GRC "¡Solecito!"

# game/chapters/bad_end.rpyc:497
translate es chat2_daybadend_09ce10e5:

    # "{i}You hear his voice. You see him standing in your room.{/i}"
    "{i}Escuchas su voz. Lo ves de pie en tu habitación.{/i}"

# game/chapters/bad_end.rpyc:498
translate es chat2_daybadend_27b5d404:

    # "{i}Why does that seem so natural?{/i}"
    "{i}¿Por qué eso te parece tan natural?{/i}"

# game/chapters/bad_end.rpyc:499
translate es chat2_daybadend_ef7b3a7b:

    # "{i}Your vision is blurry and you feel faint.{/i}"
    "{i}Tu visión está borrosa y te sientes débil.{/i}"

# game/chapters/bad_end.rpyc:500
translate es chat2_daybadend_a4ae37dc:

    # "{i}You try to get to your feet, but stumble.{/i}"
    "{i}Intentas ponerte de pie, pero tropiezas.{/i}"

# game/chapters/bad_end.rpyc:501
translate es chat2_daybadend_5e010af2:

    # "{i}Casper catches you.{/i}"
    "{i}Casper te atrapa.{/i}"

# game/chapters/bad_end.rpyc:506
translate es chat2_daybadend_a17a50dc:

    # GRC "Hey!"
    GRC "¡Hey!"

# game/chapters/bad_end.rpyc:507
translate es chat2_daybadend_20222fcc:

    # GRC "Nine hells, this is worse than I thought..."
    GRC "Nueve infiernos, esto está peor de lo que pensaba..."

# game/chapters/bad_end.rpyc:508
translate es chat2_daybadend_931eae65:

    # GRC "Come on, everything's going to be alright. Lets get you sitting down, okay?"
    GRC "Vamos, todo va a estar bien. Vamos a sentarte, ¿sí?"

# game/chapters/bad_end.rpyc:515
translate es chat2_daybadend_04c207dd:

    # GRC "Don't start spouting nonsense now. It's time for you to rest."
    GRC "No empieces a decir tonterías ahora. Es hora de que descanses."

# game/chapters/bad_end.rpyc:525
translate es chat2_daybadend_36b769e2:

    # GRC "I win?"
    GRC "¿Gané?"

# game/chapters/bad_end.rpyc:531
translate es chat2_daybadend_8da23161:

    # GRC "...."
    GRC "...."

# game/chapters/bad_end.rpyc:546
translate es chat2_daybadend_9ecac4e5:

    # GRC "Don't... don't be absurd."
    GRC "No... no digas tonterías."

# game/chapters/bad_end.rpyc:547
translate es chat2_daybadend_8bf0801b:

    # GRC "I lost. Your soul is yours. You can take mine."
    GRC "Perdí. Tu alma es tuya. Puedes tomar la mía."

# game/chapters/bad_end.rpyc:562
translate es chat2_daybadend_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/bad_end.rpyc:563
translate es chat2_daybadend_30e2e461:

    # GRC "Sunshine, I can't..."
    GRC "Solecito, no puedo..."

# game/chapters/bad_end.rpyc:564
translate es chat2_daybadend_f39c2034:

    # GRC "I told you... I told you yesterday, I..."
    GRC "Te lo dije... te lo dije ayer, yo..."

# game/chapters/bad_end.rpyc:565
translate es chat2_daybadend_649555b4:

    # GRC "Have come to... care for you too much. I couldn't..."
    GRC "He llegado a... preocuparme demasiado por ti. No podría..."

# game/chapters/bad_end.rpyc:571
translate es chat2_daybadend_0bac6bac:

    # GRC "......."
    GRC "......."

# game/chapters/bad_end.rpyc:572
translate es chat2_daybadend_4ee55eb5:

    # GRC "This isn't fair."
    GRC "Esto no es justo."

# game/chapters/bad_end.rpyc:579
translate es chat2_daybadend_8da23161_1:

    # GRC "...."
    GRC "...."

# game/chapters/bad_end.rpyc:580
translate es chat2_daybadend_dae51e15:

    # GRC "I... I'll take you to the best afterlife. I promise."
    GRC "Yo... te llevaré al mejor más allá. Lo prometo."

# game/chapters/bad_end.rpyc:581
translate es chat2_daybadend_5639426c:

    # GRC "You'll never want for anything."
    GRC "Nunca te faltará nada."

# game/chapters/bad_end.rpyc:583
translate es chat2_daybadend_b52a11ac:

    # "{i}The room is spinning now. Words are difficult to hear.{/i}"
    "{i}La habitación gira ahora. Las palabras son difíciles de oír.{/i}"

# game/chapters/bad_end.rpyc:584
translate es chat2_daybadend_12d2f3be:

    # "{i}'So this is what dying feels like,' you think. 'At least [pet_name] is okay...'{/i}"
    "{i}'Así que esto es lo que se siente morir', piensas. 'Al menos [pet_name] está bien...'{/i}"

# game/chapters/bad_end.rpyc:591
translate es chat2_daybadend_25f43cbc:

    # GRC "Of... of course..."
    GRC "Por... por supuesto..."

# game/chapters/bad_end.rpyc:614
translate es badend_afterending_8fdfd7c2:

    # "A lone reapers sits in his bedroom."
    "Una parca solitaria se sienta en su habitación."

# game/chapters/bad_end.rpyc:615
translate es badend_afterending_71d4f8b8:

    # "He holds Azrael close as tears run down his cheeks."
    "Sostiene a Azrael entre sus brazos mientras las lágrimas corren por sus mejillas."

# game/chapters/bad_end.rpyc:616
translate es badend_afterending_36115f5a:

    # "Casper never knew what love felt like until he met [playerfirstname]."
    "Casper nunca supo lo que era el amor hasta que conoció a [playerfirstname]."

# game/chapters/bad_end.rpyc:617
translate es badend_afterending_203f06d3:

    # "Their souls had connected in a way he thought he'd never feel again."
    "Sus almas se habían conectado de una forma que él creyó que nunca volvería a sentir."

# game/chapters/bad_end.rpyc:618
translate es badend_afterending_6a1ef054:

    # "And now [playerfirstname] was gone."
    "Y ahora [playerfirstname] se había ido."

# game/chapters/bad_end.rpyc:619
translate es badend_afterending_3a882024:

    # "And Casper was alone."
    "Y Casper estaba solo."

# game/chapters/bad_end.rpyc:620
translate es badend_afterending_70acb8bb:

    # "Suddenly, he felt there wasn't much fairness in death."
    "De repente, sintió que no había mucha justicia en la muerte."

# game/chapters/bad_end.rpyc:621
translate es badend_afterending_9ee2add3:

    # "If death was fair, why would he feel like this?"
    "Si la muerte fuera justa, ¿por qué se sentiría así?"

# game/chapters/bad_end.rpyc:623
translate es badend_afterending_f8bb615a:

    # "He'd accomplished what he'd set out to do. His peers congratulated him."
    "Había logrado lo que se había propuesto. Sus compañeros lo felicitaron."

# game/chapters/bad_end.rpyc:624
translate es badend_afterending_3d9baaae:

    # "And he'd never felt so empty."
    "Y nunca se había sentido tan vacío."

# game/chapters/bad_end.rpyc:625
translate es badend_afterending_0567d861:

    # GRC "'I miss you, Sunshine.' he sniffles."
    GRC "'Te extraño, Solecito', solloza."

# game/chapters/bad_end.rpyc:626
translate es badend_afterending_06421382:

    # "But no one answers him."
    "Pero nadie le responde."

# game/chapters/bad_end.rpyc:627
translate es badend_afterending_b1b58181:

    # "And so Casper goes on living, alone, thinking on the memory of the mortal who he was supposed to hate, but couldn't help but love."
    "Y así Casper sigue viviendo, solo, pensando en el recuerdo del mortal al que se suponía debía odiar, pero que no pudo evitar amar."

# game/chapters/bad_end.rpyc:632
translate es badend_afterending_b9d9bb36:

    # "Such is the life of a Grim Reaper."
    "Así es la vida de una Parca."

translate es strings:

    old "1. <Not to alarm you or anything, but I think something's... wrong.>"
    new "1. <No quiero alarmarte ni nada, pero creo que algo está... mal.>"

    old "1. <Um...>"
    new "1. <Um...>"

    old "1. <My plant just... died.>"
    new "1. <Mi planta simplemente... murió.>"

    old "1. <Of course I did.>"
    new "1. <Por supuesto que sí.>"

    old "1. <It was fine yesterday.>"
    new "1. <Ayer estaba bien.>"

    old "1. <Why would it suddenly shrivel up overnight?>"
    new "1. <¿Por qué de repente se marchitaría de la noche a la mañana?>"

    old "1. <And [pet_name] is sick again.>"
    new "1. <Y [pet_name] se enfermó otra vez.>"

    old "1. <I think I'm alright?>"
    new "1. <Creo que estoy bien.>"

    old "1. <Just stressed about [pet_name].>"
    new "1. <Solo con estrés por lo de [pet_name].>"

    old "1. <Of course I have. I've been trying all morning.>"
    new "1. <Por supuesto que sí. He estado intentándolo toda la mañana.>"

    old "1. <And it's not working.>"
    new "1. <Y no está funcionando.>"

    old "1. <Are you positive I can really... heal things like that?>"
    new "1. <¿Estás seguro de que realmente puedo... sanar cosas así?>"

    old "1. <And you? How do {i}you{/i} feel?>"
    new "1. <¿Y tú? ¿Cómo te sientes {i}tú{/i}?>"

    old "1. <[pet_She] doesn't even want to eat [pet_her] favorite treats.>"
    new "1. <[pet_She!t] ni siquiera quiere comer sus golosinas favoritas.>"

    old "1. <Well... if you say so.>"
    new "1. <Bueno... si tú lo dices.>"

    old "1. <I hope you're right.>"
    new "1. <Espero que tengas razón.>"

    old "1. <I'll... try again later.>"
    new "1. <Intentaré de nuevo más tarde.>"

    old "1. <Yes, of course I have.>"
    new "1. <Sí, por supuesto que sí.>"

    old "1. <But I did forget to grab a drink.>"
    new "1. <Pero olvidé tomar algo de beber.>"

    old "1. <Yes boss... I'll brb.>"
    new "1. <Sí, jefe... ya vuelvo.>"

    old "1. <I'll get something soon though.>"
    new "1. <Pero conseguiré algo pronto.>"

    old "1. <I'm getting a bit hungry now that you mention it.>"
    new "1. <Me está dando un poco de hambre ahora que lo mencionas.>"

    old "1. <But I'm talking with you.>"
    new "1. <Pero estoy hablando contigo.>"

    old "1. <Yeah okay. I'm on it.>"
    new "1. <Sí, está bien. Ya voy.>"

    old "1. <What a worrywart you've turned out to be.>"
    new "1. <Qué preocupon resultaste ser.>"

    old "1. <Bossy boots.>"
    new "1. <Mandón.>"

    old "1. <A worrywart.>"
    new "1. <Preocupon.>"

    old "1. <Ha.>"
    new "1. <Ja.>"

    old "1. <You kinda are. BRB.>"
    new "1. <Un poco lo eres. Ya vuelvo.>"
    old "1. <I guess I was too distracted with everything going on today...>"
    new "1. <Supongo que estaba demasiado distraído con todo lo que pasa hoy...>"

    old "1. <I will soon.>"
    new "1. <Lo haré pronto.>"

    old "1. <Yeah, all the time.>"
    new "1. <Sí, todo el tiempo.>"

    old "1. <What? I'm fine.>"
    new "1. <¿Qué? Estoy bien.>"

    old "1. <So demanding...>"
    new "1. <Tan exigente...>"

    old "1. <Fine. I'll be right back!>"
    new "1. <Bien. ¡Ya vuelvo!>"

    old "1. <I'll grab something now.>"
    new "1. <Iré a buscar algo ahora.>"

    old "1. <I'm back, are you happy now?>"
    new "1. <He vuelto, ¿feliz ahora?>"

    old "1. <I tried to help [pet_name] again, too.>"
    new "1. <También intenté ayudar a [pet_name] otra vez.>"

    old "1. <I told you I'll always try hard for [pet_her2]>"
    new "1. <Te dije que siempre haría mi mejor esfuerzo por [pet_she!t].>"

    old "1. <Wow, that's a little rude.>"
    new "1. <Vaya, eso fue un poco grosero.>"

    old "1. <But what if there isn't much time?>"
    new "1. <¿Pero qué pasa si no queda mucho tiempo?>"

    old "1. <I don't care if it makes me sick.>"
    new "1. <No me importa si me enferma.>"

    old "1. <...I know.>"
    new "1. <...Lo sé.>"

    old "1. <Sorry, Casper.>"
    new "1. <Lo siento, Casper.>"

    old "1. <I actually... feel kind of dizzy.>"
    new "1. <En realidad... siento algo de mareo.>"

    old "1. <What's wrong?>"
    new "1. <¿Qué pasa?>"

    old "1. <What's the diagnosis, doc?>"
    new "1. <¿Cuál es el diagnóstico, doc?>"

    old "1. <I've been trying all day, but nothing changed.>"
    new "1. <He estado intentándolo todo el día, pero nada cambió.>"

    old "1. <What? No, that can't be right.>"
    new "1. <¿Qué? No, eso no puede ser.>"

    old "1. <It couldn't be all used up that quickly!>"
    new "1. <¡No pudo agotarse tan rápido!>"

    old "1. <It can't be that bad, right?>"
    new "1. <No puede ser tan malo, ¿cierto?>"

    old "1. <...Right?>"
    new "1. <...¿Cierto?>"

    old "1. <Hey Grim?>"
    new "1. <¿Oye, Parca?>"

    old "1. <You win.>"
    new "1. <Ganas tú.>"

    old "1. <My soul's gonna disappear, isn't it?>"
    new "1. <Mi alma va a desaparecer, ¿verdad?>"

    old "1. <I don't want to disappear.>"
    new "1. <No quiero desaparecer.>"

    old "1. <So, you win.>"
    new "1. <Así que, ganas tú.>"

    old "1. <You won the bet. You can take my soul.>"
    new "1. <Ganaste la apuesta. Puedes llevarte mi alma.>"

    old "1. <Is my soul going to disappear?>"
    new "1. <¿Mi alma va a desaparecer?>"

    old "1. <You can't lie.>"
    new "1. <No puedes mentir.>"

    old "1. <Please?>"
    new "1. <¿Por favor?>"

    old "1. <Life isn't fair, Casper. The only fairness is in death... right?>"
    new "1. <La vida no es justa, Casper. La única justicia está en la muerte... ¿cierto?>"

    old "1. <Take care of [pet_name], okay?>"
    new "1. <Cuida de [pet_name], ¿sí?>"

    old "1. <And, Casper?>"
    new "1. <Y, Casper?>"

    old "1. <I think I really like you too.>"
    new "1. <Creo que tú también me gustas de verdad.>"

    old "2. <I'm starting to freak out a bit...>"
    new "2. <Estoy empezando a asustarme un poco...>"

    old "2. <No, I'm totally fine...>"
    new "2. <No, estoy totalmente bien...>"

    old "2. <It's all I've done today.>"
    new "2. <Es todo lo que he hecho hoy>"

    old "2. <Not yet, no.>"
    new "2. <Aún no, no.>"

    old "2. <Alright bossy boots.>"
    new "2. <Está bien, mandon.>"

    old "2. <Nah. I think I'm just stressed out.>"
    new "2. <Nah. Creo que solo tengo estrés.>"

    old "2. <What else was I supposed to do?!>"
    new "2. <¡¿Qué más se suponía que debía hacer?!>"

    old "2. <That's a little sudden...>"
    new "2. <Eso fue un poco repentino...>"

    old "3. <Oops... no. I forgot.>"
    new "3. <Ups... no. Lo olvidé.>"

    old "you have my heart."
    new "tienes mi corazón."

