
# game/chapters/7_roomexplore.rpyc:214
translate es bed_hub7_9ba07fd9:

    # "The dawn of the final day... or something."
    "El amanecer del último día... o algo así."

# game/chapters/7_roomexplore.rpyc:215
translate es bed_hub7_f3ecab0e:

    # "You don't particularly feel like you're going to die today."
    "No sientes especialmente que vayas a morir hoy."

# game/chapters/7_roomexplore.rpyc:216
translate es bed_hub7_9a72db9b:

    # "Something about the Grim Reaper you've come to know feels too... soft for things to end like that."
    "Hay algo en la Parca que has llegado a conocer que te parece demasiado... suave como para que todo termine así."

# game/chapters/7_roomexplore.rpyc:217
translate es bed_hub7_627e6eb5:

    # "Perhaps you can celebrate your win early?"
    "¿Quizás puedas celebrar tu victoria antes de tiempo?"

# game/chapters/7_roomexplore.rpyc:218
translate es bed_hub7_4936c776:

    # "You could..."
    "Podrías..."

# game/chapters/7_roomexplore.rpyc:223
translate es bed_hub7_637c89f0:

    # "Yes! A whole party just to celebrate living."
    "¡Sí! Una fiesta completa solo para celebrar la vida.."

# game/chapters/7_roomexplore.rpyc:226
translate es bed_hub7_23e32432:

    # "Everyone needs a little treat sometimes, right?"
    "Todo el mundo necesita darse un capricho de vez en cuando, ¿no?"

# game/chapters/7_roomexplore.rpyc:229
translate es bed_hub7_6eea3c32:

    # "Maybe even two. Who's going to stop you?"
    "Quizás incluso dos. ¿Quién te lo va a impedir?"

# game/chapters/7_roomexplore.rpyc:232
translate es bed_hub7_af372622:

    # "You might even invite your little reaper friend."
    "Incluso podrías invitar a tu pequeño amigo parca."

# game/chapters/7_roomexplore.rpyc:235
translate es bed_hub7_e0bc646e:

    # "But for now, you decide not to celebrate too early - there'll be plenty of time for that in the future."
    "Pero por ahora, decides no celebrar demasiado pronto - habrá tiempo de sobra para eso en el futuro."

# game/chapters/7_roomexplore.rpyc:246
translate es door_hub7_b878add3:

    # "You hear something in the hallway beyond."
    "Oyes algo en el pasillo al otro lado."

# game/chapters/7_roomexplore.rpyc:253
translate es door_hub7_c977c122:

    # "You hear a door open, and feet moving against a wooden floor."
    "Oyes cómo se abre una puerta y unos pasos sobre un piso de madera."

# game/chapters/7_roomexplore.rpyc:254
translate es door_hub7_3f9c3447:

    # "Two people - your neighbors?"
    "¿Son dos personas - tus vecinos?"

# game/chapters/7_roomexplore.rpyc:255
translate es door_hub7_2fef7956:

    # "Your breath grows silent as you listen carefully."
    "Contienes la respiración mientras escuchas con atención."

# game/chapters/7_roomexplore.rpyc:256
translate es door_hub7_b1cfc305:

    # "'You came' the light voice starts after a few moment of quiet."
    "'Has venido' dice la voz suave tras unos instantes de silencio."

# game/chapters/7_roomexplore.rpyc:257
translate es door_hub7_305da658:

    # "'Of course I did. You invited me' the deeper voice answers."
    "'Por supuesto que he venido. Tú me has invitado' responde la voz más grave."

# game/chapters/7_roomexplore.rpyc:258
translate es door_hub7_13874df2:

    # "'I'm... sorry for running away like that. It was immature of me...'"
    "'Siento haber huido así. Fue una tontería por mi parte...'"

# game/chapters/7_roomexplore.rpyc:259
translate es door_hub7_be025594:

    # "Then quiet again."
    "Luego, vuelve el silencio."

# game/chapters/7_roomexplore.rpyc:260
translate es door_hub7_79f60596:

    # "You imagine both people are struggling for words - the right words."
    "Imaginas que ambos están buscando las palabras adecuadas."

# game/chapters/7_roomexplore.rpyc:261
translate es door_hub7_c532361c:

    # "The lighter voice speaks up again."
    "La voz más suave vuelve a hablar"

# game/chapters/7_roomexplore.rpyc:262
translate es door_hub7_c22c4449:

    # "'Why do you always seem so sad when you look at me?'"
    "'¿Por qué siempre pareces tan triste cuando me miras?'"

# game/chapters/7_roomexplore.rpyc:263
translate es door_hub7_7d572ef2:

    # "It was a question neither of them likely expected to be asked."
    "Era una pregunta que probablemente ninguno de los dos esperaba que se hiciera.."

# game/chapters/7_roomexplore.rpyc:264
translate es door_hub7_27f88332:

    # "'Because...'"
    "'Porque...'"

# game/chapters/7_roomexplore.rpyc:265
translate es door_hub7_c293808e:

    # "'I've lost you so many times... and I'm waiting to lose you again.'"
    "'Te he perdido tantas veces... y estoy esperando perderte de nuevo'."

# game/chapters/7_roomexplore.rpyc:266
translate es door_hub7_3ea5df15:

    # "Quiet. So quiet you could hear a pin drop."
    "Silencio. Un silencio tan profundo que se podía oír caer un alfiler."

# game/chapters/7_roomexplore.rpyc:267
translate es door_hub7_b7e61d5e:

    # "Time flowed onwards through this quiet, winding its way between the pair."
    "El tiempo transcurría en silencio, fluyendo entre ambos."

# game/chapters/7_roomexplore.rpyc:268
translate es door_hub7_7f779b55:

    # "'What... do you mean?'"
    "'¿Qué... quieres decir?'"

# game/chapters/7_roomexplore.rpyc:269
translate es door_hub7_5ec0c6e4:

    # "A laugh - but not a humorous one. A self-mocking one."
    "Una risa - pero no divertida. Una risa autocrítica"

# game/chapters/7_roomexplore.rpyc:270
translate es door_hub7_891a4758:

    # "'You might not believe me, but hear me out anyway, okay?'"
    "'Puede que no me creas, pero escúchame de todos modos, ¿de acuerdo?'"

# game/chapters/7_roomexplore.rpyc:271
translate es door_hub7_1b6f822f:

    # "'...We didn't meet by chance,' they start."
    "'...No nos conocimos por casualidad' comienza."

# game/chapters/7_roomexplore.rpyc:272
translate es door_hub7_2640037a:

    # "'I was sent here to meet you. Like I've met you dozens of times in the past.'"
    "Me enviaron aquí para conocerte. Como si te hubiera conocido docenas de veces en el pasado."

# game/chapters/7_roomexplore.rpyc:273
translate es door_hub7_a3e3f842:

    # "'Sent here? Why?' there's genuine confusion in their voice. They don't sound scared, just... confused."
    "'¿Enviado aquí? ¿Por qué?' hay verdadera confusión en su voz. No suena asustado, solo... confundido."

# game/chapters/7_roomexplore.rpyc:274
translate es door_hub7_10476352:

    # "'I was sent here to take your soul, because I am... a Grim Reaper.'"
    "'Me enviaron aquí para llevarme tu alma, porque soy...una Parca.'"

# game/chapters/7_roomexplore.rpyc:275
translate es door_hub7_31b92461:

    # "The silence this time is so loud you almost have to cover your ears."
    "El silencio esta vez es tan ensordecedor que casi tienes que taparte los oídos."

# game/chapters/7_roomexplore.rpyc:276
translate es door_hub7_244c5c89:

    # "Tension hangs in the air."
    "La tensión flota en el aire."

# game/chapters/7_roomexplore.rpyc:277
translate es door_hub7_177b2ea2:

    # "'You and I met a long time ago, in a different lifetime, and I... refused to take your soul then.'"
    "'Nos conocimos hace mucho tiempo, en otra vida, y yo... me negué a llevarme tu alma'."

# game/chapters/7_roomexplore.rpyc:278
translate es door_hub7_85e8a3aa:

    # "'Ever since, in every lifetime, I have... been sent to you as punishment.'"
    "'Desde entonces, en cada vida, me han enviado a ti como castigo.'"

# game/chapters/7_roomexplore.rpyc:279
translate es door_hub7_cea3b071:

    # "'And in every lifetime, I've loved you.'"
    "'Y en cada vida, te he amado.'"

# game/chapters/7_roomexplore.rpyc:280
translate es door_hub7_5595cf1f:

    # "'You...' the light voice cracks, 'are you... telling the truth?'"
    "'Tú...', la voz suave se quiebra, '¿estás... diciendo la verdad?'"

# game/chapters/7_roomexplore.rpyc:281
translate es door_hub7_14f1f0a2:

    # "The sound of movement. You can see it in your mind, as they touch hands."
    "El sonido del movimiento. Puedes verlo en tu mente, cuando se tocan las manos."

# game/chapters/7_roomexplore.rpyc:282
translate es door_hub7_f28d905e:

    # "'I wouldn't lie to you. Feel my warmth, hear my heartbeat... have I ever felt familiar to you?'"
    "'No te mentiría. Siente mi calor, escucha los latidos de mi corazón... ¿Alguna vez te he resultado familiar?'"

# game/chapters/7_roomexplore.rpyc:283
translate es door_hub7_9cf1c6da:

    # "The rustling of cloth. A hand over a heart."
    "El susurro de la tela. Una mano sobre el corazón."

# game/chapters/7_roomexplore.rpyc:284
translate es door_hub7_91a1bda9:

    # "'...I've felt nostalgic ever since we met.' the light voice whispers."
    "'...He sentido nostalgia desde que nos conocimos', susurra la voz suave."

# game/chapters/7_roomexplore.rpyc:285
translate es door_hub7_209be59a:

    # "A deep voice continues."
    "Una voz grave continúa."

# game/chapters/7_roomexplore.rpyc:286
translate es door_hub7_2d20177b:

    # "'I didn't want to hurt you. I still don't. I want to keep you safe. The best way to keep you safe is... if I'm far away from you.'"
    "'No quería hacerte daño. Sigo sin quererlo. Quiero mantenerte a salvo. La mejor manera de mantenerte a salvo es... estar lejos de ti.'"

# game/chapters/7_roomexplore.rpyc:287
translate es door_hub7_93697ebb:

    # "'What would happen to you?'"
    "'¿Qué te pasaría?'"

# game/chapters/7_roomexplore.rpyc:288
translate es door_hub7_348f8bf2:

    # "'...You don't need to worry about me.'"
    "'...No tienes que preocuparte por mí.'"

# game/chapters/7_roomexplore.rpyc:289
translate es door_hub7_58d93d36:

    # "'...Why don't we run away together?'"
    "'...¿Por qué no huimos juntos?'"

# game/chapters/7_roomexplore.rpyc:290
translate es door_hub7_f33086e8:

    # "'What?'"
    "'¿Qué?'"

# game/chapters/7_roomexplore.rpyc:291
translate es door_hub7_b7177f5a:

    # "There's genuine confusion in them. Their voice, which is usually so low and cool, picks up."
    "Hay una confusión genuina en su voz. Su voz, que suele ser tan baja y fría, se eleva."

# game/chapters/7_roomexplore.rpyc:292
translate es door_hub7_f89081b9:

    # "'I think I've been dreaming about you. For years. I don't want to lose you just when I've found you.' the airy voice adds."
    "'Creo que he estado soñando contigo. Durante años. No quiero perderte justo cuando te he encontrado.' añade la voz suave."

# game/chapters/7_roomexplore.rpyc:293
translate es door_hub7_6fcfe9d1:

    # "'Are you... serious?' the deep voice responds, filled with surprise."
    "'¿Hablas... en serio?', responde la voz grave, llena de sorpresa."

# game/chapters/7_roomexplore.rpyc:294
translate es door_hub7_9dccc1fc:

    # "'I am.' the lighter voice repeats, a note of determination weaving through their words. "
    "'Sí', repite la voz más suave, con un tono de determinación entre sus palabras."

# game/chapters/7_roomexplore.rpyc:295
translate es door_hub7_dda321bb:

    # "'Stay with me.'"
    "'Quédate conmigo.'"

# game/chapters/7_roomexplore.rpyc:296
translate es door_hub7_245827d4:

    # "The deep voice, once calm and composed, now carries a trace of vulnerability. 'I never thought... I never imagined you'd want me to stay.'"
    "La voz grave, antes tranquila y serena, ahora transmite un atisbo de vulnerabilidad. 'Nunca pensé... Nunca imaginé que quisieras que me quedara.'"

# game/chapters/7_roomexplore.rpyc:297
translate es door_hub7_5a6a5c42:

    # "You can feel it even from here - a fragile hope. A possibility."
    "Se puede sentir incluso desde aquí - una frágil esperanza. Una posibilidad."

# game/chapters/7_roomexplore.rpyc:298
translate es door_hub7_08439034:

    # "A pause - a suspended moment in which the weight of a thousand lifetimes seems to hang in the balance."
    "Una pausa - un momento suspendido en el que el peso de mil vidas parece estar en juego."

# game/chapters/7_roomexplore.rpyc:299
translate es door_hub7_21adce2d:

    # "And then, the deep voice responds, 'If you'd have me, I'd stay by your side forever.'"
    "Y entonces, la voz grave responde, 'Si me aceptas, me quedaré a tu lado para siempre.'"

# game/chapters/7_roomexplore.rpyc:300
translate es door_hub7_6998a72a:

    # "You hear footsteps, then a door closing."
    "Oyes pasos y luego una puerta que se cierra."

# game/chapters/7_roomexplore.rpyc:301
translate es door_hub7_8fba9551:

    # "And then, silence."
    "Y luego, silencio."

# game/chapters/7_roomexplore.rpyc:302
translate es door_hub7_f1c7d38a:

    # "The mystery of your neighbors seems to come to a close, and you step back from the door filled with wonder and confusion."
    "El misterio de tus vecinos parece llegar a su fin, y te alejas de la puerta lleno de asombro y confusión."

# game/chapters/7_roomexplore.rpyc:303
translate es door_hub7_accad361:

    # "Two people in the very same apartment with their own Grim Reapers? What are the chances?"
    "¿Dos personas en el mismo edificio con su propia Parca? ¿Qué probabilidades hay?"

# game/chapters/7_roomexplore.rpyc:304
translate es door_hub7_3b1344a0:

    # "One in a million, you assume."
    "Una entre un millón, supones."

# game/chapters/7_roomexplore.rpyc:305
translate es door_hub7_fc572854:

    # "Though you're the only person, probably, in the entire world who would believe what just happened, you can't help but feel happy."
    "Aunque probablemente seas la única persona en todo el mundo que creería lo que acaba de pasar, no puedes evitar sentirte feliz."

# game/chapters/7_roomexplore.rpyc:306
translate es door_hub7_58f362e7:

    # "Love is an infectious thing."
    "El amor es algo contagioso."

# game/chapters/7_roomexplore.rpyc:307
translate es door_hub7_4752e78e:

    # "You pray for a moment that the two, whoever they are, whatever they look like, have a happy future ahead of them."
    "Rezas por un momento para que los dos, sean quienes sean, tengan un futuro feliz por delante."

# game/chapters/7_roomexplore.rpyc:312
translate es door_hub7_05d20ce8:

    # "And you think about your own Grim Reaper... the one who has captured your heart, as well."
    "Y piensas en tu propia Parca... la que también ha capturado tu corazón."

# game/chapters/7_roomexplore.rpyc:329
translate es door_hub7_c977c122_1:

    # "You hear a door open, and feet moving against a wooden floor."
    "Oyes cómo se abre una puerta y unos pasos sobre un piso de madera."

# game/chapters/7_roomexplore.rpyc:330
translate es door_hub7_3f9c3447_1:

    # "Two people - your neighbors?"
    "¿Son dos personas - tus vecinos?"

# game/chapters/7_roomexplore.rpyc:331
translate es door_hub7_2fef7956_1:

    # "Your breath grows silent as you listen carefully."
    "Contienes la respiración mientras escuchas con atención."

# game/chapters/7_roomexplore.rpyc:332
translate es door_hub7_b1cfc305_1:

    # "'You came' the light voice starts after a few moment of quiet."
    "'Has venido' dice la voz suave tras unos instantes de silencio."

# game/chapters/7_roomexplore.rpyc:333
translate es door_hub7_305da658_1:

    # "'Of course I did. You invited me' the deeper voice answers."
    "'Por supuesto que he venido. Tú me has invitado' responde la voz más grave."

# game/chapters/7_roomexplore.rpyc:334
translate es door_hub7_13874df2_1:

    # "'I'm... sorry for running away like that. It was immature of me...'"
    "'Siento haber huido así. Fue una tontería por mi parte...'"

# game/chapters/7_roomexplore.rpyc:335
translate es door_hub7_be025594_1:

    # "Then quiet again."
    "Luego, vuelve el silencio."

# game/chapters/7_roomexplore.rpyc:336
translate es door_hub7_79f60596_1:

    # "You imagine both people are struggling for words - the right words."
    "Imaginas que ambos están buscando las palabras adecuadas."

# game/chapters/7_roomexplore.rpyc:337
translate es door_hub7_c532361c_1:

    # "The lighter voice speaks up again."
    "La voz más suave vuelve a hablar."

# game/chapters/7_roomexplore.rpyc:338
translate es door_hub7_c22c4449_1:

    # "'Why do you always seem so sad when you look at me?'"
    "'¿Por qué siempre pareces tan triste cuando me miras?'"

# game/chapters/7_roomexplore.rpyc:339
translate es door_hub7_7d572ef2_1:

    # "It was a question neither of them likely expected to be asked."
    "Era una pregunta que probablemente ninguno de los dos esperaba que se hiciera."

# game/chapters/7_roomexplore.rpyc:340
translate es door_hub7_27f88332_1:

    # "'Because...'"
    "'Porque...'"

# game/chapters/7_roomexplore.rpyc:341
translate es door_hub7_c293808e_1:

    # "'I've lost you so many times... and I'm waiting to lose you again.'"
    "'Te he perdido tantas veces... y estoy esperando perderte de nuevo'."

# game/chapters/7_roomexplore.rpyc:342
translate es door_hub7_3ea5df15_1:

    # "Quiet. So quiet you could hear a pin drop."
    "Silencio. Un silencio tan profundo que se podía oír caer un alfiler."

# game/chapters/7_roomexplore.rpyc:343
translate es door_hub7_b7e61d5e_1:

    # "Time flowed onwards through this quiet, winding its way between the pair."
    "El tiempo transcurría en silencio, fluyendo entre ambos."

# game/chapters/7_roomexplore.rpyc:344
translate es door_hub7_7f779b55_1:

    # "'What... do you mean?'"
    "'¿Qué... quieres decir?'"

# game/chapters/7_roomexplore.rpyc:345
translate es door_hub7_5ec0c6e4_1:

    # "A laugh - but not a humorous one. A self-mocking one."
    "Una risa - pero no divertida. Una risa autocrítica"

# game/chapters/7_roomexplore.rpyc:346
translate es door_hub7_891a4758_1:

    # "'You might not believe me, but hear me out anyway, okay?'"
    "'Puede que no me creas, pero escúchame de todos modos, ¿de acuerdo?'"

# game/chapters/7_roomexplore.rpyc:347
translate es door_hub7_1b6f822f_1:

    # "'...We didn't meet by chance,' they start."
    "'...No nos conocimos por casualidad' comienza."

# game/chapters/7_roomexplore.rpyc:348
translate es door_hub7_2640037a_1:

    # "'I was sent here to meet you. Like I've met you dozens of times in the past.'"
    "'Me enviaron aquí para conocerte. Como si te hubiera conocido docenas de veces en el pasado.'"

# game/chapters/7_roomexplore.rpyc:349
translate es door_hub7_a3e3f842_1:

    # "'Sent here? Why?' there's genuine confusion in their voice. They don't sound scared, just... confused."
    "'¿Enviado aquí? ¿Por qué?' hay verdadera confusión en su voz. No suena asustado, solo... confundido."

# game/chapters/7_roomexplore.rpyc:350
translate es door_hub7_10476352_1:

    # "'I was sent here to take your soul, because I am... a Grim Reaper.'"
    "'Me enviaron aquí para llevarme tu alma, porque soy...una Parca.'"

# game/chapters/7_roomexplore.rpyc:351
translate es door_hub7_31b92461_1:

    # "The silence this time is so loud you almost have to cover your ears."
    "El silencio esta vez es tan ensordecedor que casi tienes que taparte los oídos."

# game/chapters/7_roomexplore.rpyc:352
translate es door_hub7_244c5c89_1:

    # "Tension hangs in the air."
    "La tensión flota en el aire."

# game/chapters/7_roomexplore.rpyc:353
translate es door_hub7_177b2ea2_1:

    # "'You and I met a long time ago, in a different lifetime, and I... refused to take your soul then.'"
    "'Nos conocimos hace mucho tiempo, en otra vida, y yo... me negué a llevarme tu alma.'"

# game/chapters/7_roomexplore.rpyc:354
translate es door_hub7_85e8a3aa_1:

    # "'Ever since, in every lifetime, I have... been sent to you as punishment.'"
    "'Desde entonces, en cada vida, me han enviado a ti como castigo.'"

# game/chapters/7_roomexplore.rpyc:355
translate es door_hub7_cea3b071_1:

    # "'And in every lifetime, I've loved you.'"
    "'Y en cada vida, te he amado.'"

# game/chapters/7_roomexplore.rpyc:356
translate es door_hub7_5595cf1f_1:

    # "'You...' the light voice cracks, 'are you... telling the truth?'"
    "'Tú...', la voz suave se quiebra, '¿estás... diciendo la verdad?'"

# game/chapters/7_roomexplore.rpyc:357
translate es door_hub7_14f1f0a2_1:

    # "The sound of movement. You can see it in your mind, as they touch hands."
    "El sonido del movimiento. Puedes verlo en tu mente, cuando se tocan las manos."

# game/chapters/7_roomexplore.rpyc:358
translate es door_hub7_f28d905e_1:

    # "'I wouldn't lie to you. Feel my warmth, hear my heartbeat... have I ever felt familiar to you?'"
    "'No te mentiría. Siente mi calor, escucha los latidos de mi corazón... ¿Alguna vez te he resultado familiar?'"

# game/chapters/7_roomexplore.rpyc:359
translate es door_hub7_9cf1c6da_1:

    # "The rustling of cloth. A hand over a heart."
    "El susurro de la tela. Una mano sobre el corazón."

# game/chapters/7_roomexplore.rpyc:360
translate es door_hub7_91a1bda9_1:

    # "'...I've felt nostalgic ever since we met.' the light voice whispers."
    "'...He sentido nostalgia desde que nos conocimos', susurra la voz suave."

# game/chapters/7_roomexplore.rpyc:361
translate es door_hub7_209be59a_1:

    # "A deep voice continues."
    "Una voz grave continúa."

# game/chapters/7_roomexplore.rpyc:362
translate es door_hub7_2d20177b_1:

    # "'I didn't want to hurt you. I still don't. I want to keep you safe. The best way to keep you safe is... if I'm far away from you.'"
    "'No quería hacerte daño. Sigo sin quererlo. Quiero mantenerte a salvo. La mejor manera de mantenerte a salvo es... estar lejos de ti.'"

# game/chapters/7_roomexplore.rpyc:363
translate es door_hub7_93697ebb_1:

    # "'What would happen to you?'"
    "'¿Qué te pasaría a ti?'"

# game/chapters/7_roomexplore.rpyc:364
translate es door_hub7_348f8bf2_1:

    # "'...You don't need to worry about me.'"
    "'...No tienes que preocuparte por mí.'"

# game/chapters/7_roomexplore.rpyc:365
translate es door_hub7_58d93d36_1:

    # "'...Why don't we run away together?'"
    "'...¿Por qué no huimos juntos?'"

# game/chapters/7_roomexplore.rpyc:366
translate es door_hub7_f33086e8_1:

    # "'What?'"
    "'¿Qué?'"

# game/chapters/7_roomexplore.rpyc:367
translate es door_hub7_b7177f5a_1:

    # "There's genuine confusion in them. Their voice, which is usually so low and cool, picks up."
    "Hay una confusión genuina en su voz. Su voz, que suele ser tan baja y fría, se eleva."

# game/chapters/7_roomexplore.rpyc:368
translate es door_hub7_f89081b9_1:

    # "'I think I've been dreaming about you. For years. I don't want to lose you just when I've found you.' the airy voice adds."
    "'Creo que he estado soñando contigo. Durante años. No quiero perderte justo cuando te he encontrado.' añade la voz suave."

# game/chapters/7_roomexplore.rpyc:369
translate es door_hub7_6fcfe9d1_1:

    # "'Are you... serious?' the deep voice responds, filled with surprise."
    "'¿Hablas... en serio?', responde la voz grave, llena de sorpresa."

# game/chapters/7_roomexplore.rpyc:370
translate es door_hub7_9dccc1fc_1:

    # "'I am.' the lighter voice repeats, a note of determination weaving through their words. "
    "'Sí', repite la voz más suave, con un tono de determinación entre sus palabras."

# game/chapters/7_roomexplore.rpyc:371
translate es door_hub7_dda321bb_1:

    # "'Stay with me.'"
    "'Quédate conmigo.'"

# game/chapters/7_roomexplore.rpyc:372
translate es door_hub7_245827d4_1:

    # "The deep voice, once calm and composed, now carries a trace of vulnerability. 'I never thought... I never imagined you'd want me to stay.'"
    "La voz grave, antes tranquila y serena, ahora transmite un atisbo de vulnerabilidad. 'Nunca pensé... Nunca imaginé que quisieras que me quedara.'"

# game/chapters/7_roomexplore.rpyc:373
translate es door_hub7_5a6a5c42_1:

    # "You can feel it even from here - a fragile hope. A possibility."
    "Se puede sentir incluso desde aquí - una frágil esperanza. Una posibilidad."

# game/chapters/7_roomexplore.rpyc:374
translate es door_hub7_08439034_1:

    # "A pause - a suspended moment in which the weight of a thousand lifetimes seems to hang in the balance."
    "Una pausa - un momento suspendido en el que el peso de mil vidas parece estar en juego."

# game/chapters/7_roomexplore.rpyc:375
translate es door_hub7_21adce2d_1:

    # "And then, the deep voice responds, 'If you'd have me, I'd stay by your side forever.'"
    "Y entonces, la voz grave responde, 'Si me aceptas, me quedaré a tu lado para siempre.'"

# game/chapters/7_roomexplore.rpyc:376
translate es door_hub7_6998a72a_1:

    # "You hear footsteps, then a door closing."
    "Oyes pasos y luego una puerta que se cierra."

# game/chapters/7_roomexplore.rpyc:377
translate es door_hub7_8fba9551_1:

    # "And then, silence."
    "Y luego, silencio."

# game/chapters/7_roomexplore.rpyc:378
translate es door_hub7_f1c7d38a_1:

    # "The mystery of your neighbors seems to come to a close, and you step back from the door filled with wonder and confusion."
    "El misterio de tus vecinos parece llegar a su fin, y te alejas de la puerta lleno de asombro y confusión."

# game/chapters/7_roomexplore.rpyc:379
translate es door_hub7_accad361_1:

    # "Two people in the very same apartment with their own Grim Reapers? What are the chances?"
    "¿Dos personas en el mismo edificio con su propia Parca? ¿Qué probabilidades hay?"

# game/chapters/7_roomexplore.rpyc:380
translate es door_hub7_3b1344a0_1:

    # "One in a million, you assume."
    "Una entre un millón, supones."

# game/chapters/7_roomexplore.rpyc:381
translate es door_hub7_fc572854_1:

    # "Though you're the only person, probably, in the entire world who would believe what just happened, you can't help but feel happy."
    "Aunque probablemente seas la única persona en todo el mundo que creería lo que acaba de pasar, no puedes evitar sentirte feliz."

# game/chapters/7_roomexplore.rpyc:382
translate es door_hub7_58f362e7_1:

    # "Love is an infectious thing."
    "El amor es algo contagioso."

# game/chapters/7_roomexplore.rpyc:383
translate es door_hub7_4752e78e_1:

    # "You pray for a moment that the two, whoever they are, whatever they look like, have a happy future ahead of them."
    "Rezas por un momento para que los dos, sean quienes sean, tengan un futuro feliz por delante."

# game/chapters/7_roomexplore.rpyc:387
translate es door_hub7_05d20ce8_1:

    # "And you think about your own Grim Reaper... the one who has captured your heart, as well."
    "Y piensas en tu propia Parca... la que también ha capturado tu corazón."

# game/chapters/7_roomexplore.rpyc:400
translate es door_hub7_b82ac03c:

    # "The hallway beyond is silent now."
    "El pasillo más allá está en silencio ahora."

# game/chapters/7_roomexplore.rpyc:401
translate es door_hub7_3e9c4266:

    # "But that's okay."
    "Pero está bien."

# game/chapters/7_roomexplore.rpyc:406
translate es door_hub7_179bdf8a:

    # "The hallway beyond is quiet."
    "El pasillo más allá está en silencio."

# game/chapters/7_roomexplore.rpyc:407
translate es door_hub7_0c77ee5d:

    # "It seems you missed the ending to this story."
    "Parece que te perdiste el final de esta historia."

# game/chapters/7_roomexplore.rpyc:425
translate es snake_hub7_66fb5a74:

    # "[pet_name] is lazing around happily."
    "[pet_name] se está relajando felizmente."

# game/chapters/7_roomexplore.rpyc:426
translate es snake_hub7_d3841b0d:

    # "For some reason, you feel oddly nostalgic today, sitting next to [pet_name]."
    "Por alguna razón, hoy se siente extrañamente nostálgico, sentado junto a [pet_name]."

# game/chapters/7_roomexplore.rpyc:427
translate es snake_hub7_7e98b7b9:

    # "You're certain you'll win your bet, but you still give [pet_name] some extra love."
    "Tienes la certeza de que ganarás tu apuesta, pero aún así le das a [pet_name] un poco más de cariño."

# game/chapters/7_roomexplore.rpyc:428
translate es snake_hub7_e50d3ec8:

    # "Anything could happen, after all."
    "Cualquier cosa podría pasar, después de todo."

# game/chapters/7_roomexplore.rpyc:433
translate es snake_hub7_4fdd2058:

    # "You go on to tell [pet_name] how much you love [pet_her2] for fifteen minutes."
    "Le cuentas a [pet_name] lo mucho que le quieres durante quince minutos."

# game/chapters/7_roomexplore.rpyc:434
translate es snake_hub7_8adfc2c9:

    # "It's not enough. [pet_She] deserves even more!"
    "No es suficiente. ¡[pet_She!t] merece aún más!"

# game/chapters/7_roomexplore.rpyc:435
translate es snake_hub7_e10211bc:

    # "You get [pet_name] some treats, hang out together, and overall just enjoy each other's company this morning."
    "Le das a [pet_name] algunas golosinas, pasan el tiempo y, en general, disfrutan de la compañía mutua esta mañana."

# game/chapters/7_roomexplore.rpyc:436
translate es snake_hub7_e0852936:

    # "You love [pet_name] so much, words cannot even come close to describing how you feel."
    "Quieres tanto a [pet_name] que las palabras no bastan para describir lo que sientes."

# game/chapters/7_roomexplore.rpyc:437
translate es snake_hub7_6496bf3f:

    # "And in return, you feel immense trust from [pet_name] as [pet_her] tongue flickers out towards you."
    "Y a cambio, sientes una inmensa confianza por parte de [pet_name] cuando [pet_she!t] te lame con su lengua."

# game/chapters/7_roomexplore.rpyc:449
translate es bingus_hub7_66fb5a74:

    # "[pet_name] is lazing around happily."
    "[pet_name] se está relajando felizmente."

# game/chapters/7_roomexplore.rpyc:450
translate es bingus_hub7_d3841b0d:

    # "For some reason, you feel oddly nostalgic today, sitting next to [pet_name]."
    "Por alguna razón, hoy se siente extrañamente nostálgico, sentado junto a [pet_name]."

# game/chapters/7_roomexplore.rpyc:451
translate es bingus_hub7_7e98b7b9:

    # "You're certain you'll win your bet, but you still give [pet_name] some extra love."
    "Tienes la certeza de que ganarás tu apuesta, pero aún así le das a [pet_name] un poco más de cariño."

# game/chapters/7_roomexplore.rpyc:452
translate es bingus_hub7_e50d3ec8:

    # "Anything could happen, after all."
    "Cualquier cosa podría pasar, después de todo."

# game/chapters/7_roomexplore.rpyc:457
translate es bingus_hub7_4fdd2058:

    # "You go on to tell [pet_name] how much you love [pet_her2] for fifteen minutes."
    "Le cuentas a [pet_name] lo mucho que le quieres durante quince minutos."

# game/chapters/7_roomexplore.rpyc:458
translate es bingus_hub7_8adfc2c9:

    # "It's not enough. [pet_She] deserves even more!"
    "No es suficiente. ¡[pet_She!t] merece aún más!"

# game/chapters/7_roomexplore.rpyc:459
translate es bingus_hub7_e10211bc:

    # "You get [pet_name] some treats, hang out together, and overall just enjoy each other's company this morning."
    "Le das a [pet_name] algunas golosinas, pasan el tiempo y, en general, disfrutan de la compañía mutua esta mañana."

# game/chapters/7_roomexplore.rpyc:460
translate es bingus_hub7_e0852936:

    # "You love [pet_name] so much, words cannot even come close to describing how you feel."
    "Quieres tanto a [pet_name] que las palabras no bastan para describir lo que sientes."

# game/chapters/7_roomexplore.rpyc:461
translate es bingus_hub7_a72838eb:

    # "And in return, you feel immense love from [pet_name] as [pet_she] rubs [pet_her] velvety head against you."
    "Y a cambio, sientes un amor inmenso por parte de [pet_name] cuando [pet_she!t] frota su cabeza aterciopelada contra ti."

# game/chapters/7_roomexplore.rpyc:473
translate es bunny_hub7_66fb5a74:

    # "[pet_name] is lazing around happily."
    "[pet_name] se está relajando felizmente."

# game/chapters/7_roomexplore.rpyc:474
translate es bunny_hub7_d3841b0d:

    # "For some reason, you feel oddly nostalgic today, sitting next to [pet_name]."
    "Por alguna razón, hoy se siente extrañamente nostálgico, sentado junto a [pet_name]."

# game/chapters/7_roomexplore.rpyc:475
translate es bunny_hub7_7e98b7b9:

    # "You're certain you'll win your bet, but you still give [pet_name] some extra love."
    "Tienes la certeza de que ganarás tu apuesta, pero aún así le das a [pet_name] un poco más de cariño."

# game/chapters/7_roomexplore.rpyc:476
translate es bunny_hub7_e50d3ec8:

    # "Anything could happen, after all."
    "Cualquier cosa podría pasar, después de todo."

# game/chapters/7_roomexplore.rpyc:481
translate es bunny_hub7_4fdd2058:

    # "You go on to tell [pet_name] how much you love [pet_her2] for fifteen minutes."
    "Le cuentas a [pet_name] lo mucho que le quieres durante quince minutos."

# game/chapters/7_roomexplore.rpyc:482
translate es bunny_hub7_8adfc2c9:

    # "It's not enough. [pet_She] deserves even more!"
    "No es suficiente. ¡[pet_She!t] merece aún más!"

# game/chapters/7_roomexplore.rpyc:483
translate es bunny_hub7_e10211bc:

    # "You get [pet_name] some treats, hang out together, and overall just enjoy each other's company this morning."
    "Le das a [pet_name] algunas golosinas, pasan el tiempo y, en general, disfrutan de la compañía mutua esta mañana."

# game/chapters/7_roomexplore.rpyc:484
translate es bunny_hub7_e0852936:

    # "You love [pet_name] so much, words cannot even come close to describing how you feel."
    "Quieres tanto a [pet_name] que las palabras no bastan para describir lo que sientes."

# game/chapters/7_roomexplore.rpyc:485
translate es bunny_hub7_0db6a096:

    # "And in return, you feel immense love from [pet_name] as [pet_she] nudges up against you."
    "Y a cambio, sientes un amor inmenso por parte de [pet_name] cuando [pet_she!t] se acurruca contra ti."

# game/chapters/7_roomexplore.rpyc:497
translate es cat_hub7_66fb5a74:

    # "[pet_name] is lazing around happily."
    "[pet_name] se está relajando felizmente."

# game/chapters/7_roomexplore.rpyc:498
translate es cat_hub7_d3841b0d:

    # "For some reason, you feel oddly nostalgic today, sitting next to [pet_name]."
    "Por alguna razón, hoy se siente extrañamente nostálgico, sentado junto a [pet_name]."

# game/chapters/7_roomexplore.rpyc:499
translate es cat_hub7_7e98b7b9:

    # "You're certain you'll win your bet, but you still give [pet_name] some extra love."
    "Tienes la certeza de que ganarás tu apuesta, pero aún así le das a [pet_name] un poco más de cariño."

# game/chapters/7_roomexplore.rpyc:500
translate es cat_hub7_e50d3ec8:

    # "Anything could happen, after all."
    "Cualquier cosa podría pasar, después de todo."

# game/chapters/7_roomexplore.rpyc:505
translate es cat_hub7_4fdd2058:

    # "You go on to tell [pet_name] how much you love [pet_her2] for fifteen minutes."
    "Le cuentas a [pet_name] lo mucho que le quieres durante quince minutos."

# game/chapters/7_roomexplore.rpyc:506
translate es cat_hub7_8adfc2c9:

    # "It's not enough. [pet_She] deserves even more!"
    "No es suficiente. ¡[pet_She!t] merece aún más!"

# game/chapters/7_roomexplore.rpyc:507
translate es cat_hub7_e10211bc:

    # "You get [pet_name] some treats, hang out together, and overall just enjoy each other's company this morning."
    "Le das a [pet_name] algunas golosinas, pasan el tiempo y, en general, disfrutan de la compañía mutua esta mañana."

# game/chapters/7_roomexplore.rpyc:508
translate es cat_hub7_e0852936:

    # "You love [pet_name] so much, words cannot even come close to describing how you feel."
    "Quieres tanto a [pet_name] que las palabras no bastan para describir lo que sientes."

# game/chapters/7_roomexplore.rpyc:509
translate es cat_hub7_c22d7706:

    # "And in return, you feel immense love from [pet_name] as [pet_she] purrs and sits on your lap."
    "Y a cambio, sientes un amor inmenso por parte de [pet_name] cuando [pet_she!t] ronronea y se sienta en tu regazo."

# game/chapters/7_roomexplore.rpyc:521
translate es dog_hub7_66fb5a74:

    # "[pet_name] is lazing around happily."
    "[pet_name] está relajando felizmente."

# game/chapters/7_roomexplore.rpyc:522
translate es dog_hub7_d3841b0d:

    # "For some reason, you feel oddly nostalgic today, sitting next to [pet_name]."
    "Por alguna razón, hoy se siente extrañamente nostálgico, sentado junto a [pet_name]."

# game/chapters/7_roomexplore.rpyc:523
translate es dog_hub7_7e98b7b9:

    # "You're certain you'll win your bet, but you still give [pet_name] some extra love."
    "Tienes la certeza de que ganarás tu apuesta, pero aún así le das a [pet_name] un poco más de cariño."

# game/chapters/7_roomexplore.rpyc:524
translate es dog_hub7_e50d3ec8:

    # "Anything could happen, after all."
    "Cualquier cosa podría pasar, después de todo."

# game/chapters/7_roomexplore.rpyc:529
translate es dog_hub7_4fdd2058:

    # "You go on to tell [pet_name] how much you love [pet_her2] for fifteen minutes."
    "Le cuentas a [pet_name] lo mucho que le quieres durante quince minutos."

# game/chapters/7_roomexplore.rpyc:530
translate es dog_hub7_8adfc2c9:

    # "It's not enough. [pet_She] deserves even more!"
    "No es suficiente. ¡[pet_She!t] merece aún más!"

# game/chapters/7_roomexplore.rpyc:531
translate es dog_hub7_e10211bc:

    # "You get [pet_name] some treats, hang out together, and overall just enjoy each other's company this morning."
    "Le das a [pet_name] algunas golosinas, pasan el tiempo y, en general, disfrutan de la compañía mutua esta mañana."

# game/chapters/7_roomexplore.rpyc:532
translate es dog_hub7_e0852936:

    # "You love [pet_name] so much, words cannot even come close to describing how you feel."
    "Quieres tanto a [pet_name] que las palabras no bastan para describir lo que sientes."

# game/chapters/7_roomexplore.rpyc:533
translate es dog_hub7_34f967cd:

    # "And in return, you feel immense love from [pet_name] as [pet_she] wags [pet_her] tail."
    "Y a cambio, sientes un amor inmenso por parte de [pet_name] cuando [pet_she!t] mueve su cola."

# game/chapters/7_roomexplore.rpyc:545
translate es hamster_hub7_66fb5a74:

    # "[pet_name] is lazing around happily."
    "[pet_name] está relajando felizmente."

# game/chapters/7_roomexplore.rpyc:546
translate es hamster_hub7_d3841b0d:

    # "For some reason, you feel oddly nostalgic today, sitting next to [pet_name]."
    "Por alguna razón, hoy se siente extrañamente nostálgico, sentado junto a [pet_name]."

# game/chapters/7_roomexplore.rpyc:547
translate es hamster_hub7_7e98b7b9:

    # "You're certain you'll win your bet, but you still give [pet_name] some extra love."
    "Tienes la certeza de que ganarás tu apuesta, pero aún así le das a [pet_name] un poco más de cariño."

# game/chapters/7_roomexplore.rpyc:548
translate es hamster_hub7_e50d3ec8:

    # "Anything could happen, after all."
    "Cualquier cosa podría pasar, después de todo."

# game/chapters/7_roomexplore.rpyc:553
translate es hamster_hub7_4fdd2058:

    # "You go on to tell [pet_name] how much you love [pet_her2] for fifteen minutes."
    "Le cuentas a [pet_name] lo mucho que le quieres durante quince minutos."

# game/chapters/7_roomexplore.rpyc:554
translate es hamster_hub7_8adfc2c9:

    # "It's not enough. [pet_She] deserves even more!"
    "No es suficiente. ¡[pet_She!t] merece aún más!"

# game/chapters/7_roomexplore.rpyc:555
translate es hamster_hub7_e10211bc:

    # "You get [pet_name] some treats, hang out together, and overall just enjoy each other's company this morning."
    "Le das a [pet_name] algunas golosinas, pasan el tiempo y, en general, disfrutan de la compañía mutua esta mañana."

# game/chapters/7_roomexplore.rpyc:556
translate es hamster_hub7_e0852936:

    # "You love [pet_name] so much, words cannot even come close to describing how you feel."
    "Quieres tanto a [pet_name] que las palabras no bastan para describir lo que sientes."

# game/chapters/7_roomexplore.rpyc:557
translate es hamster_hub7_bac643c8:

    # "And in return, you feel immense love from [pet_name] as [pet_she] nibbles [pet_her] snacks in your hand."
    "Y a cambio, sientes un amor inmenso por parte de [pet_name] mientras [pet_she!t] mordisquea sus bocadillos en tu mano."

# game/chapters/7_roomexplore.rpyc:577
translate es plant_hub7_c1229c6a:

    # "You give your little sprout a big drink of water."
    "Le das a tu pequeño retoño un buen trago de agua."

# game/chapters/7_roomexplore.rpyc:578
translate es plant_hub7_c5de961c:

    # "Though you don't speak sprout, it seems to say thank you."
    "Aunque no hablas idioma retoño, parece decirte gracias."

# game/chapters/7_roomexplore.rpyc:580
translate es plant_hub7_518e64fd:

    # "Your little sprout has grown some leaves!"
    "¡Tu pequeño retoño ha desarrollado algunas hojas!"

# game/chapters/7_roomexplore.rpyc:581
translate es plant_hub7_8036dce1:

    # "You can't help but feel proud as you give it a big drink of water."
    "No puedes evitar sentir orgullo mientras le das un gran trago de agua."

# game/chapters/7_roomexplore.rpyc:583
translate es plant_hub7_adaac543:

    # "Even more leaves have appeared now!"
    "¡Aún más hojas han aparecido ahora!"

# game/chapters/7_roomexplore.rpyc:584
translate es plant_hub7_a4970463:

    # "You water it generously and feel excited that, this time, you didn't kill your plant instantly."
    "Lo riegas generosamente y sientes emoción porque, esta vez, no mataste tu planta al instante."

# game/chapters/7_roomexplore.rpyc:586
translate es plant_hub7_2087a70f:

    # "Your little plant is growing healthily!"
    "¡Tu pequeña planta está creciendo saludablemente!"

# game/chapters/7_roomexplore.rpyc:587
translate es plant_hub7_80d209cf:

    # "You give it a big drink of water, excited about its growth."
    "Le das un buen trago de agua, con entusiasmo por su crecimiento."

# game/chapters/7_roomexplore.rpyc:589
translate es plant_hub7_41affa3b:

    # "Your little plant has sprouted some buds!"
    "¡Tu pequeña planta ha brotado algunos capullos!"

# game/chapters/7_roomexplore.rpyc:590
translate es plant_hub7_75fbf720:

    # "You almost tear up when you notice them. They're so cute - you can't wait to see what the flowers will look like."
    "Casi lloras cuando los notas. Son tan lindos, no puedes esperar a ver cómo se verán las flores."

# game/chapters/7_roomexplore.rpyc:592
translate es plant_hub7_33ab5804:

    # "The buds on your little plant seem to be doing well!"
    "¡Los capullos en tu pequeña planta parecen estar bien!"

# game/chapters/7_roomexplore.rpyc:593
translate es plant_hub7_8b2d7914:

    # "You can't believe how healthy it is... though after what Casper told you, you're starting to understand why..."
    "No te imaginas lo saludable que es... aunque después de lo que te contó Casper, empiezas a entender por qué..."

# game/chapters/7_roomexplore.rpyc:595
translate es plant_hub7_3a8cf5f3:

    # "Your little sprout has grown up happily and healthily all because of you, and today..."
    "Tu pequeño retoño ha crecido feliz y sano gracias a ti, y hoy..."

# game/chapters/7_roomexplore.rpyc:602
translate es plant_hub7_3542ab9b:

    # "It rewards you with four beautiful flowers!"
    "¡Te recompensa con cuatro hermosas flores!"

# game/chapters/7_roomexplore.rpyc:603
translate es plant_hub7_c9e73e13:

    # "You water your plant and feel a sense of accomplishment."
    "Riegas tu planta y sientes una sensación de logro."

# game/chapters/7_roomexplore.rpyc:617
translate es plant_hub7_de44b0ea:

    # "A little more water never hurts, right?"
    "Un poco más de agua nunca duele, ¿verdad?"

# game/chapters/7_roomexplore.rpyc:618
translate es plant_hub7_f763544f:

    # "Except for when it does..."
    "Excepto cuando si viene mal..."

# game/chapters/7_roomexplore.rpyc:632
translate es plant_hub7_efba4e08:

    # "You have never known moderation."
    "Nunca has conocido la moderación."

# game/chapters/7_roomexplore.rpyc:633
translate es plant_hub7_30894904:

    # "To you, life is a game. A challenge."
    "Para ti, la vida es un juego. Un desafío."

# game/chapters/7_roomexplore.rpyc:634
translate es plant_hub7_7f54f47c:

    # "One that you intend to win."
    "Uno que pretendes ganar."

# game/chapters/7_roomexplore.rpyc:635
translate es plant_hub7_2a9efc21:

    # "And the first step to winning is overwatering your plant."
    "Y el primer paso para ganar es regar en exceso tu planta."

# game/chapters/7_roomexplore.rpyc:636
translate es plant_hub7_73b256d7:

    # "Obviously."
    "Obviamente."

translate es strings:

    old "1. Throw a party!"
    new "¡Organizar una fiesta!"

    old "2. Go on a shopping spree!"
    new "¡Ir de compras sin control!"

    old "3. Eat a WHOLE chocolate cake."
    new "Comer un pastel de chocolate entero."

    old "4. Go out for a nice meal"
    new "Salir a disfrutar de una buena comida"

    old "Tell [pet_name] you love [pet_her2]."
    new "Dile a [pet_name] que le amas."

    old "{i}My Favorite Quote{/i}"
    new "{i}Mi cita favorita{/i}"

    old "[[{i}You flip to the end of your favorite childhood book. Resting against the page is a quote that's stuck with you.{/i}]"
    new "[[{i}Pasas a la última página de tu libro favorito de la infancia. Sobre la hoja descansa una cita que siempre has recordado.{/i}]]"

    old "If there's one thing you retain from your journey, I hope it is this: enjoy your life.  Appreciate the small moments. Love with your entire heart."
    new "Si hay algo que deseo que conserves de tu viaje, es esto: disfruta de tu vida. Aprecia los pequeños momentos. Ama con todo tu corazón."

    old "Not every moment has to be epic; a life filled with great deeds is also filled with great exhaustion."
    new "No todos los momentos tienen que ser épicos; una vida llena de grandes hazañas también está llena de gran cansancio."

    old "The smallest, most average moments can contain extraordinary beauty if you pay attention."
    new "Los momentos más pequeños y ordinarios pueden contener una belleza extraordinaria si prestas atención."

    old "We spend so much time hoping for rest, for the moment when we can relax. But true peace comes not at the end, but in the middle. It will take effort to experience these small joys and stop merely hoping for big ones."
    new "Pasamos tanto tiempo esperando descansar, esperando el momento en que podamos relajarnos. Pero la verdadera paz no llega al final, sino en el camino. Se necesita esfuerzo para disfrutar de esas pequeñas alegrías y dejar de esperar solo las grandes."

    old "So, dear reader, this if my gift to you: live every moment like it's your last, and don't forget how damn lucky you are that you will get more."
    new "Así que, querido lector, este es mi regalo para ti: vive cada momento como si fuera el último, y no olvides lo increíblemente afortunado que eres por tener más por venir."

