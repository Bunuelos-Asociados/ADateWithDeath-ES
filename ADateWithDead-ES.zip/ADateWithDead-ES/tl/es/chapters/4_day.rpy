
# game/chapters/4_day.rpyc:17
translate es day4_start_f85c704c:

    # center_text "Today was a very strange day for you."
    center_text "Hoy fue un día muy extraño para ti."

# game/chapters/4_day.rpyc:18
translate es day4_start_4968f894:

    # center_text "As it turns out, the Grim Reaper is real."
    center_text "Resulta que la Parca es real."

# game/chapters/4_day.rpyc:19
translate es day4_start_d7176d30:

    # center_text "Real, and video calling you like it's nothing."
    center_text "Real, y te llama por videollamada como si nada."

# game/chapters/4_day.rpyc:20
translate es day4_start_3361e923:

    # center_text "You spend the majority of the day at work unable to be productive. How could you be, after such a revelation?"
    center_text "Pasas la mayor parte del día en el trabajo sin poder rendir. ¿Cómo podrías hacerlo, después de tal revelación?"

# game/chapters/4_day.rpyc:21
translate es day4_start_6ade9068:

    # center_text "As you get back to your apartment, you're feeling a little pent up with energy, and you decide to take the steps rather than the elevator."
    center_text "Al regresar a tu departamento, te sientes algo rebosante de energía y decides subir por las escaleras en lugar de tomar el elevador."

# game/chapters/4_day.rpyc:22
translate es day4_start_7f3540ef:

    # center_text "Just as you reach your floor, you hear a loud bang. A few people come out from their apartments to find out what happened."
    center_text "Justo cuando llegas a tu piso, escuchas una fuerte explosión. Algunas personas salen de sus apartamentos para descubrir qué sucedió."

# game/chapters/4_day.rpyc:23
translate es day4_start_51347ad5:

    # center_text "You later learn that the elevator had a malfunctioning cable, and it snapped, plummeting multiple floors down."
    center_text "Más tarde te enteras de que el elevador tenía un cable defectuoso, que se rompió y cayó varios pisos."

# game/chapters/4_day.rpyc:24
translate es day4_start_91b3f120:

    # center_text "Suddenly, you're very glad to have walked."
    center_text "De repente, estás muy feliz de haber caminado."

# game/chapters/4_day.rpyc:67
translate es day4_start2_30146a6d:

    # player "Got any leads?"
    player "¿Tienes alguna pista?"

# game/chapters/4_day.rpyc:69
translate es day4_start2_f337c475:

    # player "Any news, Grim?"
    player "¿Alguna noticia, Parca?"

# game/chapters/4_day.rpyc:71
translate es day4_start2_f926ed5f:

    # player "How's it going for my favorite Grim Reaper?"
    player "¿Cómo le va a mi Parca favorita?"

# game/chapters/4_day.rpyc:75
translate es day4_start2_8e38d596:

    # player "Any news?"
    player "¿Alguna novedad?"

# game/chapters/4_day.rpyc:80
translate es day4_start2_06a83b2c:

    # player "I'll take that as a no, then."
    player "Lo tomaré como un no, entonces."

# game/chapters/4_day.rpyc:83
translate es day4_start2_37879293:

    # player "Unless it's a yes, and you're just ignoring me..."
    player "A menos que sea un sí y simplemente me estés ignorando..."

# game/chapters/4_day.rpyc:86
translate es day4_start2_268c4191:

    # player "You wouldn't do that, right?"
    player "No harías eso, ¿verdad?"

# game/chapters/4_day.rpyc:87
translate es day4_start2_d2d7dd34:

    # GR "i said i might {i}perhaps{/i} tell you."
    GR "dije que {i}quizá{/i} te lo contaría."

# game/chapters/4_day.rpyc:90
translate es day4_start2_5444bde1:

    # player "Ah! The man of the hour!"
    player "¡Ah! ¡El hombre del momento!"

# game/chapters/4_day.rpyc:92
translate es day4_start2_8055a907:

    # player "There you are!"
    player "¡Ahí estás!"

# game/chapters/4_day.rpyc:94
translate es day4_start2_141253bd:

    # GR "i really am always on your mind, aren't i?"
    GR "realmente siempre estoy en tu mente, ¿verdad?"

# game/chapters/4_day.rpyc:98
translate es day4_start2_52044a21:

    # player "In this instance, yes. Always is a little much.."
    player "En este caso, sí. Siempre es un poco exagerado..."

# game/chapters/4_day.rpyc:99
translate es day4_start2_01dcf3f1:

    # GR "i'm a little concerned with the amount of time you spend fantasizing about death."
    GR "me preocupa un poco el tiempo que pasas fantaseando con la muerte."

# game/chapters/4_day.rpyc:101
translate es day4_start2_bb9d883f:

    # player "Yeah, I think about you a lot. What about it?"
    player "Sí, pienso mucho en ti. ¿Y qué?"

# game/chapters/4_day.rpyc:102
translate es day4_start2_01dcf3f1_1:

    # GR "i'm a little concerned with the amount of time you spend fantasizing about death."
    GR "me preocupa un poco el tiempo que pasas fantaseando con la muerte."

# game/chapters/4_day.rpyc:104
translate es day4_start2_f2d9d59d:

    # player "You'd like it if you were, wouldn't you?"
    player "Te gustaría que fuera así, ¿verdad?"

# game/chapters/4_day.rpyc:105
translate es day4_start2_94db30d3:

    # GR "i'd be more concerned with the amount of time you spend fantasizing about death."
    GR "me preocuparía más el tiempo que pasas fantaseando con la muerte."

# game/chapters/4_day.rpyc:110
translate es day4_start2_05f273a9:

    # player "There's an interesting thought."
    player "Es una idea interesante."

# game/chapters/4_day.rpyc:113
translate es day4_start2_711a19b8:

    # player "Is the Grim Reaper {i}literally{/i} death?"
    player "¿Es la Parca {i}literalmente{/i} la muerte?"

# game/chapters/4_day.rpyc:114
translate es day4_start2_14d5e83b:

    # GR "i bring death. i represent death. i quite like death."
    GR "yo traigo la muerte. yo represento la muerte. me gusta bastante la muerte."

# game/chapters/4_day.rpyc:117
translate es day4_start2_09fc2aa5:

    # player "But is that the same thing?"
    player "Pero, ¿es lo mismo?"

# game/chapters/4_day.rpyc:118
translate es day4_start2_c6cbea0e:

    # GR "see it as you will. whether i am literally death or not is up to interpretation."
    GR "tómalo como quieras. si soy literalmente la muerte o no, depende de cómo lo interpretes."

# game/chapters/4_day.rpyc:122
translate es day4_start2_e958922d:

    # player "You seem a little too lively to be called death incarnate."
    player "Pareces demasiado animado como para ser la encarnación de la muerte."

# game/chapters/4_day.rpyc:124
translate es day4_start2_efea0978:

    # player "I like the idea of you being literal death."
    player "Me gusta la idea de que seas literalmente la muerte."

# game/chapters/4_day.rpyc:128
translate es day4_start2_72badd0e:

    # player "But, either way, we're getting off topic here."
    player "Pero, en cualquier caso, nos estamos desviando del tema."

# game/chapters/4_day.rpyc:132
translate es day4_start2_a10517fe:

    # player "Maybe you're not a very good Grim Reaper after all..."
    player "Quizás no seas tan buena Parca después de todo..."

# game/chapters/4_day.rpyc:135
translate es day4_start2_e9bf8bd5:

    # player "Is there someone more important I could speak to?"
    player "¿Hay alguien más importante con quien pueda hablar?"

# game/chapters/4_day.rpyc:138
translate es day4_start2_ae85f852:

    # player "Your manager?"
    player "¿Tu jefe?"

# game/chapters/4_day.rpyc:141
translate es day4_start2_864a0157:

    # player "Might be faster than waiting for you to hit the books."
    player "Podría ser más rápido que esperar a que te pongas a estudiar."

# game/chapters/4_day.rpyc:142
translate es day4_start2_5125381a:

    # GR "excuse me?"
    GR "¿perdón?"

# game/chapters/4_day.rpyc:143
translate es day4_start2_8d92790d:

    # GR "i explicitly remember saying {i}'perhaps'{/i} i would tell you."
    GR "recuerdo explícitamente haber dicho que {i}'quizás'{/i} te lo diría."

# game/chapters/4_day.rpyc:144
translate es day4_start2_be309ec4:

    # GR "do you seriously think me too stupid to work this out alone?"
    GR "¿de verdad crees que soy tan tonto como para resolver esto por mi cuenta?"

# game/chapters/4_day.rpyc:147
translate es day4_start2_1ec20b4e:

    # player "Do I think you're stupid? Well..."
    player "¿Que si creo que eres tonto? Bueno..."

# game/chapters/4_day.rpyc:149
translate es day4_start2_9df1e598:

    # player "Oh, this is awkward..."
    player "Oh, qué incómodo..."

# game/chapters/4_day.rpyc:152
translate es day4_start2_e9d8c55e:

    # player "Are you sure you want me to answer that?"
    player "¿Estás seguro de que quieres que te responda a eso?"

# game/chapters/4_day.rpyc:153
translate es day4_start2_2d26c99a:

    # GR "the less you talk, the better."
    GR "cuanto menos hables, mejor."

# game/chapters/4_day.rpyc:154
translate es day4_start2_c368f9e2:

    # GR "so no. keep your mouth shut."
    GR "así que no. mantén la boca cerrada."

# game/chapters/4_day.rpyc:157
translate es day4_start2_5c2bcf9f:

    # player "Yes sir :)"
    player "Sí, señor :)"

# game/chapters/4_day.rpyc:159
translate es day4_start2_0d5472e7:

    # player "Never >:D"
    player "Nunca >:D"

# game/chapters/4_day.rpyc:162
translate es day4_start2_afb06c06:

    # player "I would like to point out that I am, in fact, communicating with you via text."
    player "Me gustaría señalar que, de hecho, me estoy comunicando contigo por mensaje de texto."

# game/chapters/4_day.rpyc:165
translate es day4_start2_c876a673:

    # player "My mouth is indeed shut! :)"
    player "¡Mi boca está cerrada! :)"

# game/chapters/4_day.rpyc:166
translate es day4_start2_6d42b7a6:

    # GR "why are you like this?"
    GR "¿por qué eres así?"

# game/chapters/4_day.rpyc:169
translate es day4_start2_810986f7:

    # player "Like what, exactly - [pretty], smart, [beautiful]?"
    player "¿Como qué, exactamente - [pretty!t], inteligente, [beautiful!t]?"

# game/chapters/4_day.rpyc:170
translate es day4_start2_af26c7ef:

    # GR "none of those were what i was going to say, no."
    GR "ninguna de esas cosas era lo que iba a decir, no."

# game/chapters/4_day.rpyc:173
translate es day4_start2_490940a8:

    # player "But you {i}do{/i} think I am those things, riiiiight?"
    player "Pero tú {i}sí{/i} piensas que soy esas cosas, ¿veeeerdad?"

# game/chapters/4_day.rpyc:174
translate es day4_start2_4007586c:

    # GR "sigh."
    GR "suspiro."

# game/chapters/4_day.rpyc:177
translate es day4_start2_e415d69d:

    # player "...Did you actually just type '{i}sigh{/i}'. So dramatic..."
    player "¿De verdad acabas de escribir '{i}suspiro{/i}'? Qué dramático..."

# game/chapters/4_day.rpyc:178
translate es day4_start2_9216f977:

    # GR "so what if i did."
    GR "¿y qué si lo hice?"

# game/chapters/4_day.rpyc:179
translate es day4_start2_ec5a4cf1:

    # GR "you are making me sigh, so i will write sigh."
    GR "tú me estás haciendo suspirar, así que voy a escribir suspiro."

# game/chapters/4_day.rpyc:183
translate es day4_start2_70a4c570:

    # player "Would you say 'sigh' out loud, too?"
    player "¿También dirías 'suspiro' en voz alta?"

# game/chapters/4_day.rpyc:184
translate es day4_start2_2419e3bf:

    # GR "if the situation called for it, yes."
    GR "si la situación lo requiriera, sí."

# game/chapters/4_day.rpyc:188
translate es day4_start2_ae8a62a7:

    # player "God you're stupid."
    player "Dios, eres estúpido."

# game/chapters/4_day.rpyc:189
translate es day4_start2_004530a4:

    # GR "i am not."
    GR "no lo soy."

# game/chapters/4_day.rpyc:190
translate es day4_start2_fbb427f9:

    # GR "i will have you know that my IQ is quite high."
    GR "quiero que sepas que mi IQ es bastante alto."

# game/chapters/4_day.rpyc:194
translate es day4_start2_5a61af2b:

    # player "Sure it is."
    player "Claro que sí."

# game/chapters/4_day.rpyc:197
translate es day4_start2_3b9ab139:

    # player "I love you. You are the dumbest person I've ever met."
    player "Te amo. Eres la persona más tonta que he conocido."

# game/chapters/4_day.rpyc:198
translate es day4_start2_f98488b7:

    # GR "huh???????"
    GR "¿¿¿¿¿¿¿eh???????"

# game/chapters/4_day.rpyc:199
translate es day4_start2_b8599844:

    # GR "what do you mean love?!"
    GR "¡¿qué quieres decir con amor?!"

# game/chapters/4_day.rpyc:203
translate es day4_start2_145467a6:

    # player "Not literally, doofus."
    player "No literalmente, tonto."

# game/chapters/4_day.rpyc:204
translate es day4_start2_3f7ad2f6:

    # GR "oh."
    GR "oh."

# game/chapters/4_day.rpyc:205
translate es day4_start2_b448885a:

    # GR "humans are confusing..."
    GR "los humanos son confusos..."

# game/chapters/4_day.rpyc:208
translate es day4_start2_62884ce2:

    # player "I mean I love you."
    player "Quiero decir, te amo."

# game/chapters/4_day.rpyc:212
translate es day4_start2_7ca2454b:

    # player "I love bullying you, after all."
    player "Me encanta molestarte, después de todo."

# game/chapters/4_day.rpyc:213
translate es day4_start2_703264c4:

    # GR "ah..."
    GR "ah..."

# game/chapters/4_day.rpyc:214
translate es day4_start2_c8db4404:

    # GR "you mean like that."
    GR "te refieres a eso."

# game/chapters/4_day.rpyc:215
translate es day4_start2_a3948957:

    # GR "right."
    GR "bien."

# game/chapters/4_day.rpyc:218
translate es day4_start2_03ffd7ca:

    # player "Take it how you will ;)"
    player "Tómalo como quieras ;)"

# game/chapters/4_day.rpyc:219
translate es day4_start2_79a029da:

    # GR "what???"
    GR "¿¿¿qué???"

# game/chapters/4_day.rpyc:220
translate es day4_start2_f3dc019c:

    # GR "how am i meant to take it?!"
    GR "¡¿cómo debo tomarlo?!"

# game/chapters/4_day.rpyc:221
translate es day4_start2_0991a7c3:

    # GR "mortal, you make no sense! you never make any sense!"
    GR "¡mortal, no tienes sentido! ¡nunca tienes sentido!"

# game/chapters/4_day.rpyc:222
translate es day4_start2_b1b254c7:

    # GR "i swear on the oaths of the grim reapers that i will never understand you."
    GR "juro por los juramentos de los sombríos Reapers que nunca te entenderé."

# game/chapters/4_day.rpyc:226
translate es day4_start2_e6548006:

    # player "Good, I like being mysterious."
    player "Bien, me gusta mantener el misterio."

# game/chapters/4_day.rpyc:230
translate es day4_start2_a3b5ec96:

    # player "Anyway, we're getting off topic here."
    player "De todos modos, nos estamos desviando del tema."

# game/chapters/4_day.rpyc:234
translate es day4_start2_8c51f093:

    # player "Too busy to talk to me, huh..."
    player "Demasiado ocupado para hablar conmigo, eh..."

# game/chapters/4_day.rpyc:237
translate es day4_start2_7d00ea88:

    # player "I can be a patient person..."
    player "Puedo ser una persona paciente..."

# game/chapters/4_day.rpyc:240
translate es day4_start2_8ec7e10e:

    # player "But I'm reeeaaally curious..."
    player "Pero tengo muchaaaaa curiosidad..."

# game/chapters/4_day.rpyc:241
translate es day4_start2_86b7e2ab:

    # GR "you? patient? hilarious, mortal."
    GR "¿tú? ¿paciente? muy gracioso, mortal."

# game/chapters/4_day.rpyc:242
translate es day4_start2_f597cec1:

    # GR "i bet you have been sitting there waiting for me all day."
    GR "apuesto a que has estado ahí de pie esperándome todo el día."

# game/chapters/4_day.rpyc:245
translate es day4_start2_8a6f059d:

    # player "I do work, you know... but yeah, kinda."
    player "Yo trabajo, ya sabes... pero sí, más o menos."

# game/chapters/4_day.rpyc:248
translate es day4_start2_04b9fe25:

    # player "I'd say that {i}is{/i} me being extremely patient, anyway."
    player "Yo diría que {i}eso{/i} es ser extremadamente paciente, en cualquier caso."

# game/chapters/4_day.rpyc:249
translate es day4_start2_01dedc76:

    # GR "not patient enough to not send 5 messages, nagging me."
    GR "no lo suficiente como para no enviarme 5 mensajes regañándome."

# game/chapters/4_day.rpyc:252
translate es day4_start2_4840d7a4:

    # player "Oh please, that's hardly nagging."
    player "Por favor, eso no se puede considerar regañar."

# game/chapters/4_day.rpyc:254
translate es day4_start2_a5a2e384:

    # player "You call that nagging?"
    player "¿A eso le llamas regañar?"

# game/chapters/4_day.rpyc:257
translate es day4_start2_a17e025c:

    # player "If you want me to nag you, I can."
    player "Si quieres que te regañe, puedo hacerlo."

# game/chapters/4_day.rpyc:258
translate es day4_start2_60eccc71:

    # GR "do not. please."
    GR "no. por favor."

# game/chapters/4_day.rpyc:259
translate es day4_start2_6b3866ec:

    # GR "the less you say, the happier i'll be."
    GR "cuanto menos digas, más feliz seré."

# game/chapters/4_day.rpyc:262
translate es day4_start2_c983dc06:

    # player "Well, that's rude."
    player "Bueno, eso fue grosero."

# game/chapters/4_day.rpyc:266
translate es day4_start2_2a2e1ec5:

    # player "Rude reaper."
    player "Parca Grosera."

# game/chapters/4_day.rpyc:267
translate es day4_start2_b671c7bf:

    # GR "your opinion of me matters little."
    GR "tu opinión sobre mí importa poco."

# game/chapters/4_day.rpyc:271
translate es day4_start2_533a9717:

    # player "No?"
    player "¿No?"

# game/chapters/4_day.rpyc:272
translate es day4_start2_5d364529:

    # GR "no."
    GR "no."

# game/chapters/4_day.rpyc:274
translate es day4_start2_481c64ac:

    # player "Oh really?"
    player "¿Ah, de verdad?"

# game/chapters/4_day.rpyc:275
translate es day4_start2_df464156:

    # GR "yes, really."
    GR "sí, de verdad."

# game/chapters/4_day.rpyc:279
translate es day4_start2_bb4fb2d4:

    # player "I'm sure you'll change your mind soon enough."
    player "Seguro que pronto cambiarás de opinión."

# game/chapters/4_day.rpyc:280
translate es day4_start2_eb94f192:

    # GR "unlikely. extremely unlikely. i'd say the chances are around 0.01 percent."
    GR "improbable. extremadamente improbable. yo diría que las posibilidades son de alrededor del 0.01 por ciento."

# game/chapters/4_day.rpyc:283
translate es day4_start2_45203b58:

    # player "Even if you {i}are{/i} rude, I still think you're..."
    player "Aunque {i}seas{/i} grosero, sigo pensando que eres..."

# game/chapters/4_day.rpyc:286
translate es day4_start2_9d4cd115:

    # player "Cute!"
    player "¡Lindo!"

# game/chapters/4_day.rpyc:289
translate es day4_start2_7b17d8ba:

    # player "Very adorable!"
    player "¡Muy adorable!"

# game/chapters/4_day.rpyc:292
translate es day4_start2_e5c9d720:

    # player "A sweetie!"
    player "¡Una dulzura!"

# game/chapters/4_day.rpyc:294
translate es day4_start2_79a029da_1:

    # GR "what???"
    GR "¿¿¿qué???"

# game/chapters/4_day.rpyc:295
translate es day4_start2_9290285f:

    # GR "and i... i think you are wasting my time!"
    GR "¡y yo... creo que me estás haciendo perder el tiempo!"

# game/chapters/4_day.rpyc:299
translate es day4_start2_f040a236:

    # player "Doesn't death have all the time in the world?"
    player "¿Acaso la muerte no tiene todo el tiempo del mundo?"

# game/chapters/4_day.rpyc:300
translate es day4_start2_1301234f:

    # GR "no. my schedule is in fact very full up."
    GR "no. mi horario está muy lleno."

# game/chapters/4_day.rpyc:301
translate es day4_start2_a41d466d:

    # GR "you are cutting into my very important beauty sleep time."
    GR "estás interrumpiendo mi importantísimo sueño reparador."

# game/chapters/4_day.rpyc:305
translate es day4_start2_1f0a9182:

    # player "If you're so busy, then we should just talk about the elephant in the room."
    player "Si estás tan ocupado, entonces deberíamos hablar del elefante en la habitación."

# game/chapters/4_day.rpyc:310
translate es day4_start2_f2a03a1a:

    # player "We both know that's not true."
    player "Los dos sabemos que eso no es cierto."

# game/chapters/4_day.rpyc:311
translate es day4_start2_6d7d34ee:

    # GR "i don't know what you're talking about."
    GR "no sé de qué estás hablando."

# game/chapters/4_day.rpyc:315
translate es day4_start2_3c32871c:

    # player "You love talking to me."
    player "Te encanta hablar conmigo."

# game/chapters/4_day.rpyc:316
translate es day4_start2_e202442e:

    # GR "i... think you are grossly overestimating my feelings on the matter."
    GR "yo... creo que estás sobreestimando enormemente mis sentimientos al respecto."

# game/chapters/4_day.rpyc:320
translate es day4_start2_26598c1a:

    # player "Sounds like a roundabout way of agreeing with me."
    player "Parece una forma indirecta de darme la razón."

# game/chapters/4_day.rpyc:321
translate es day4_start2_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:325
translate es day4_start2_d5403c05:

    # player "You always say I'm sitting around waiting to talk to you..."
    player "Siempre dices que estoy esperando para hablar contigo..."

# game/chapters/4_day.rpyc:329
translate es day4_start2_bfe92544:

    # player "But I bet that's what you do!"
    player "¡Pero apuesto a que eso es lo que haces tu!"

# game/chapters/4_day.rpyc:330
translate es day4_start2_98963fe4:

    # GR "do you think i'm not busy enough, you know, doing my job?"
    GR "¿crees que no estoy lo suficientemente ocupado haciendo mi trabajo?"

# game/chapters/4_day.rpyc:334
translate es day4_start2_93edb4a6:

    # player "Yeah, pretty much."
    player "Sí, más o menos."

# game/chapters/4_day.rpyc:336
translate es day4_start2_be777e5f:

    # player "Do you even do any work?"
    player "¿Incluso trabajas?"

# game/chapters/4_day.rpyc:340
translate es day4_start2_16bcac2b:

    # player "I mean, I feel like you're not even {i}trying{/i} to take my soul."
    player "Es decir, siento que ni siquiera estás {i}intentando{/i} robarme el alma."

# game/chapters/4_day.rpyc:341
translate es day4_start2_f978e9b3:

    # GR "i'm trying my hardest........"
    GR "estoy haciendo todo lo posible........"

# game/chapters/4_day.rpyc:342
translate es day4_start2_0a1df944:

    # GR "you're making me cry."
    GR "me estás haciendo llorar."

# game/chapters/4_day.rpyc:345
translate es day4_start2_17a0b6db:

    # player "Aww, poor Grim."
    player "Aww, pobre Parca."

# game/chapters/4_day.rpyc:346
translate es day4_start2_d9860edd:

    # GR "yes, pity me. pity me greatly."
    GR "sí, compadéceme. compadéceme mucho."

# game/chapters/4_day.rpyc:347
translate es day4_start2_8a551002:

    # GR "then stop CHEATING and let me take your soul already!!!!"
    GR "¡¡¡¡entonces deja de HACER TRAMPAS y déjame llevarte el alma de una vez!!!!"

# game/chapters/4_day.rpyc:350
translate es day4_start2_6e9a0200:

    # player "Does pookie need a lil cuddle?"
    player "¿Pookie necesita un poquito de cariño?"

# game/chapters/4_day.rpyc:351
translate es day4_start2_3cb24fcc:

    # GR "'pookie', whatever that means, needs a lil soul, actually."
    GR "'pookie', sea lo que sea que signifique eso, necesita un poquito de alma, en realidad."

# game/chapters/4_day.rpyc:352
translate es day4_start2_78e4243e:

    # GR "is that asking for so much???"
    GR "¿¿¿es pedir demasiado???"

# game/chapters/4_day.rpyc:355
translate es day4_start2_3072eb5b:

    # player "Try harder :D"
    player "Esfuérzate más :D"

# game/chapters/4_day.rpyc:356
translate es day4_start2_230dec51:

    # GR "...."
    GR "...."

# game/chapters/4_day.rpyc:357
translate es day4_start2_5d501fe3:

    # GR "just... give it to me... please..."
    GR "solo... dámela... por favor..."

# game/chapters/4_day.rpyc:361
translate es day4_start2_46ef2b39:

    # player "Sorry, I'm a little attached to it."
    player "Lo siento, le tengo un poco de cariño."

# game/chapters/4_day.rpyc:364
translate es day4_start2_5ef2de11:

    # player "More importantly, you were going to tell me about it."
    player "Lo más importante es que ibas a contármelo."

# game/chapters/4_day.rpyc:367
translate es day4_start2_c90f3ab0:

    # player "If I don't ask, I bet you won't tell me."
    player "Si no te lo pregunto, seguro que no me lo dirás."

# game/chapters/4_day.rpyc:371
translate es day4_start2_daccb21c:

    # player "Don't you think it's only fair I know?"
    player "¿No crees que es justo que lo sepa?"

# game/chapters/4_day.rpyc:372
translate es day4_start2_ae28c633:

    # GR "sunshine, i have something to introduce you to."
    GR "solecito, tengo algo que mostrarte."

# game/chapters/4_day.rpyc:375
translate es day4_start2_05cf1b99:

    # player "???"
    player "???"

# game/chapters/4_day.rpyc:376
translate es day4_start2_dba34acb:

    # GR "it's called..."
    GR "se llama..."

# game/chapters/4_day.rpyc:377
translate es day4_start2_9cac1a15:

    # GR "patience."
    GR "paciencia."

# game/chapters/4_day.rpyc:380
translate es day4_start2_fa297d66:

    # player "I know about patience already..."
    player "Ya sé sobre la paciencia..."

# game/chapters/4_day.rpyc:381
translate es day4_start2_f6c5374a:

    # GR "i implore you to practice it, then."
    GR "te imploro que la practiques, entonces."

# game/chapters/4_day.rpyc:382
translate es day4_start2_24ba3017:

    # GR "practice it until you are a master. the master of patience."
    GR "practíca hasta que la domines. domina el arte de la paciencia."

# game/chapters/4_day.rpyc:385
translate es day4_start2_2b9127ed:

    # player "Pfft. You wish."
    player "Pfft. Ya te gustaría."

# game/chapters/4_day.rpyc:387
translate es day4_start2_ebb45f03:

    # player "I don't waaant to."
    player "No quieroooo."

# game/chapters/4_day.rpyc:390
translate es day4_start2_50bf492b:

    # player "I know you'd be lonely if I left you alone for too long."
    player "Sé que te sentirías solo si te dejara solo durante mucho tiempo."

# game/chapters/4_day.rpyc:391
translate es day4_start2_84376be6:

    # GR "ha. ha, ha, ha."
    GR "ja. ja, ja, ja."

# game/chapters/4_day.rpyc:392
translate es day4_start2_e22148ed:

    # GR "you are very funny."
    GR "Eres tan bromista."

# game/chapters/4_day.rpyc:393
translate es day4_start2_f68d7350:

    # GR "so hilarious, in fact, i cannot stop laughing."
    GR "tan hilarante, de hecho, que no puedo dejar de reírme."

# game/chapters/4_day.rpyc:394
translate es day4_start2_8204d121:

    # GR "i am laughing so hard my stomach is hurting. oh, please, make it stop."
    GR "me estoy riendo tanto que me duele el estómago. por favor, haz que pare."

# game/chapters/4_day.rpyc:397
translate es day4_start2_80805ce3:

    # player "Really?"
    player "¿En serio?"

# game/chapters/4_day.rpyc:398
translate es day4_start2_5d364529_1:

    # GR "no."
    GR "no."

# game/chapters/4_day.rpyc:401
translate es day4_start2_1945626c:

    # player "You suck. Do you have any answers or not, Grimmy?"
    player "Eres un inútil. ¿Tienes alguna respuesta o no, Parquita?"

# game/chapters/4_day.rpyc:402
translate es day4_start2_c51b9832:

    # GR "grimmy..."
    GR "parquita..."

# game/chapters/4_day.rpyc:403
translate es day4_start2_b265eb74:

    # GR "that is not a good nickname. it sounds dirty."
    GR "ese no es un buen apodo. suena sucio."

# game/chapters/4_day.rpyc:406
translate es day4_start2_94be07ce:

    # player "I thought it had a nice ring to it."
    player "Pensé que sonaba bien."

# game/chapters/4_day.rpyc:409
translate es day4_start2_9f84d98f:

    # player "Dirty name for a dirty boy."
    player "Nombre sucio para un chico sucio."

# game/chapters/4_day.rpyc:410
translate es day4_start2_43223aba:

    # GR "excuse me...?"
    GR "¿disculpa...?"

# game/chapters/4_day.rpyc:413
translate es day4_start2_749647c3:

    # player ":)"
    player ":)"

# game/chapters/4_day.rpyc:415
translate es day4_start2_4e06c83b:

    # GR "grimmy... grubby... grotty. they all sound bad."
    GR "sucio... mugriento... asqueroso. Todos suenan mal."

# game/chapters/4_day.rpyc:416
translate es day4_start2_79d8b970:

    # GR "like dirtiness."
    GR "como la suciedad."

# game/chapters/4_day.rpyc:417
translate es day4_start2_c037cdc5:

    # GR "i'll have you know i clean regularly."
    GR "te informo que limpio con regularidad."

# game/chapters/4_day.rpyc:420
translate es day4_start2_fbcf116c:

    # player "Thanks for letting me know."
    player "Gracias por avisarme."

# game/chapters/4_day.rpyc:423
translate es day4_start2_b817411b:

    # player "Here I was wondering about your bathing habits, after all."
    player "Al final, me estaba preguntando cuáles eran tus hábitos de baño."

# game/chapters/4_day.rpyc:424
translate es day4_start2_f4f7de37:

    # GR "oh, i bet you were. can't help yourself, after all."
    GR "oh, seguro que sí. al fin y al cabo, no puedes evitarlo."

# game/chapters/4_day.rpyc:427
translate es day4_start2_03ef095a:

    # player "I have an important question for you."
    player "Tengo una pregunta importante para ti."

# game/chapters/4_day.rpyc:428
translate es day4_start2_32460917:

    # GR "can i refuse to answer?"
    GR "¿puedo negarme a responder?"

# game/chapters/4_day.rpyc:431
translate es day4_start2_27464a03:

    # player "Do you prefer to shower at night, or in the morning?"
    player "¿Prefieres ducharte por la noche o por la mañana?"

# game/chapters/4_day.rpyc:432
translate es day4_start2_0da8dcd6:

    # GR "what the..."
    GR "¿Qué demo...?"

# game/chapters/4_day.rpyc:433
translate es day4_start2_ae42d440:

    # GR "night or day means very little where i am, mortal."
    GR "la noche o el día no significan nada donde estoy, mortal."

# game/chapters/4_day.rpyc:434
translate es day4_start2_f293213f:

    # GR "why would it matter anyway? what difference does it make?"
    GR "¿por qué importaría de todos modos? ¿qué diferencia hace?"

# game/chapters/4_day.rpyc:437
translate es day4_start2_287c86ab:

    # player "Okay. If you lived somewhere that wasn't superhell..."
    player "De acuerdo. Si vivieras en un lugar que no fuera el inframundo..."

# game/chapters/4_day.rpyc:440
translate es day4_start2_b6954af4:

    # player "Would you pick night or day?"
    player "¿Escogerías noche o día?"

# game/chapters/4_day.rpyc:441
translate es day4_start2_ce52da68:

    # GR "i see no point in answering. it would make no difference."
    GR "no veo sentido en responder. no cambiaría nada."

# game/chapters/4_day.rpyc:444
translate es day4_start2_9ec35dd4:

    # player "Night or daaaaay?"
    player "¿Noche o díaaaaaaa?"

# game/chapters/4_day.rpyc:447
translate es day4_start2_5b003123:

    # player "Come on, I'm curious."
    player "Vamos, tengo curiosidad."

# game/chapters/4_day.rpyc:449
translate es day4_start2_8b85f75e:

    # GR "night, if i had to pick. you should know i'm no fan of the day."
    GR "noche, si tuviera que elegir. debes saber que no soy muy fan del día."

# game/chapters/4_day.rpyc:452
translate es day4_start2_96216795:

    # player "Me too!"
    player "¡Yo también!"

# game/chapters/4_day.rpyc:455
translate es day4_start2_23284bef:

    # player "We kinda clash... I guess we could always shower together instead."
    player "Nosotros coincidimos... Supongo que siempre podríamos ducharnos juntos en su lugar."

# game/chapters/4_day.rpyc:456
translate es day4_start2_d427a6e1:

    # GR "wha—"
    GR "QUÉ—"

# game/chapters/4_day.rpyc:457
translate es day4_start2_6ccc0f41:

    # GR "what are you {i}saying{/i}..."
    GR "qué estás {i}diciendo{/i}..."

# game/chapters/4_day.rpyc:458
translate es day4_start2_89b032ff:

    # GR "why would—why would you even {i}want{/i} to do that? with me?? huh???"
    GR "¿por qué—por qué {i}ibas a querer{/i} hacer eso? ¿¿conmigo?? ¿¿¿eh???"

# game/chapters/4_day.rpyc:461
translate es day4_start2_b6cf3a13:

    # player "To save water, of course."
    player "Para ahorrar agua, por supuesto."

# game/chapters/4_day.rpyc:464
translate es day4_start2_3e7fb2d5:

    # player "What other reason would there be?"
    player "¿Qué otra razón habría?"

# game/chapters/4_day.rpyc:467
translate es day4_start2_41892cc7:

    # player ";)"
    player ";)"

# game/chapters/4_day.rpyc:468
translate es day4_start2_7c9d0cc1:

    # GR "don't send those winking emoticons at me."
    GR "no me envíes esos emoticonos guiñando el ojo."

# game/chapters/4_day.rpyc:471
translate es day4_start2_43a07bc7:

    # player "We could share a bath under the stars before you take my soul."
    player "Podríamos compartir un baño bajo las estrellas antes de que te lleves mi alma."

# game/chapters/4_day.rpyc:474
translate es day4_start2_70d585ae:

    # player "A little night time shower to wash away my soul's impurities."
    player "Una pequeña ducha nocturna para limpiar las impurezas de mi alma."

# game/chapters/4_day.rpyc:477
translate es day4_start2_3d7e3f6f:

    # player "I'm looking forward to it."
    player "Estoy deseando que llegue."

# game/chapters/4_day.rpyc:478
translate es day4_start2_a3e57d17:

    # GR "you really just say anything you want to..."
    GR "Realmente solo dices lo que quieres..."

# game/chapters/4_day.rpyc:481
translate es day4_start2_b96575c6:

    # player "Mornings only for me."
    player "Mañanas solo para mí."

# game/chapters/4_day.rpyc:484
translate es day4_start2_6be313a3:

    # player "We shouldn't clash then. That's good!"
    player "Entonces no deberíamos coincidir. ¡Qué bien!"

# game/chapters/4_day.rpyc:487
translate es day4_start2_3794a3b9:

    # player "It's a little sad not to share sometimes, though."
    player "Aunque a veces es un poco triste no compartirlo."

# game/chapters/4_day.rpyc:490
translate es day4_start2_89d3fd50:

    # player "I don't mind showering in the evenings, I guess."
    player "Supongo que no me importa ducharme por las tardes."

# game/chapters/4_day.rpyc:491
translate es day4_start2_d427a6e1_1:

    # GR "wha—"
    GR "qué—"

# game/chapters/4_day.rpyc:492
translate es day4_start2_87264043:

    # GR "i don't care when you choose to shower in the slightest."
    GR "no me importa en absoluto cuándo decidas ducharte."

# game/chapters/4_day.rpyc:495
translate es day4_start2_e0c8af12:

    # player "I was just saying we could shower together."
    player "Solo decía que podíamos ducharnos juntos."

# game/chapters/4_day.rpyc:498
translate es day4_start2_b6cf3a13_1:

    # player "To save water, of course."
    player "Para ahorrar agua, por supuesto."

# game/chapters/4_day.rpyc:499
translate es day4_start2_1d4809a9:

    # GR "huh?!?!?!"
    GR "¡¿¡¿¡¿eh?!?!?!"

# game/chapters/4_day.rpyc:500
translate es day4_start2_76f6200b:

    # GR "why... what............."
    GR "por qué ... que............."

# game/chapters/4_day.rpyc:503
translate es day4_start2_41892cc7_1:

    # player ";)"
    player ";)"

# game/chapters/4_day.rpyc:504
translate es day4_start2_7c9d0cc1_1:

    # GR "don't send those winking emoticons at me."
    GR "no me envíes esos emoticonos guiñando el ojo."

# game/chapters/4_day.rpyc:507
translate es day4_start2_93130377:

    # player ";))))"
    player ";))))"

# game/chapters/4_day.rpyc:508
translate es day4_start2_7772a27d_1:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:509
translate es day4_start2_9ad9865a:

    # GR "why are you... who made you like this????"
    GR "por qué eres así... ¿¿¿¿quién te hizo así????"

# game/chapters/4_day.rpyc:512
translate es day4_start2_bff65367:

    # player "Like what, Grim?"
    player "¿Como qué, Parca?"

# game/chapters/4_day.rpyc:515
translate es day4_start2_5e94d22b:

    # player "You don't wanna shower with me?"
    player "¿No quieres ducharte conmigo?"

# game/chapters/4_day.rpyc:516
translate es day4_start2_bb5dc436:

    # GR "i.. i.."
    GR "yo.. yo.."

# game/chapters/4_day.rpyc:519
translate es day4_start2_fa693546:

    # player "I could wash your hair for you."
    player "Podría lavarte el cabello."

# game/chapters/4_day.rpyc:520
translate es day4_start2_47497da5:

    # GR "..................."
    GR "..................."

# game/chapters/4_day.rpyc:523
translate es day4_start2_7843d403:

    # player "I can't see your face, but I just know you're blushing hard."
    player "No puedo ver tu cara, pero solo sé que te estás sonrojando."

# game/chapters/4_day.rpyc:526
translate es day4_start2_bad82551:

    # player "Red right up to your ears."
    player "Rojo hasta las orejas."

# game/chapters/4_day.rpyc:527
translate es day4_start2_cc21bd84:

    # GR "!!!"
    GR "!!!"

# game/chapters/4_day.rpyc:530
translate es day4_start2_4658bf5c:

    # player "Hehehehe. I'm just kidding ;)"
    player "Jejejeje. Estoy bromeando ;)"

# game/chapters/4_day.rpyc:533
translate es day4_start2_4e2570e0:

    # player "Don't tell me you actually want to do it?"
    player "¿No me digas que realmente quieres hacerlo?"

# game/chapters/4_day.rpyc:534
translate es day4_start2_95151b2c:

    # GR "....."
    GR "....."

# game/chapters/4_day.rpyc:535
translate es day4_start2_16bc10f6:

    # GR "i didn't say... that...."
    GR "no dije... eso...."

# game/chapters/4_day.rpyc:538
translate es day4_start2_6576df75:

    # player "So you do?"
    player "¿Entonces sí?"

# game/chapters/4_day.rpyc:541
translate es day4_start2_49c4cfcf:

    # player "You're a naughty boy, hehe"
    player "Eres un chico travieso, jeje"

# game/chapters/4_day.rpyc:544
translate es day4_start2_169ef37c:

    # player "Tsk tsk, cheeky Grim."
    player "Tsk tsk, Parca descarada."

# game/chapters/4_day.rpyc:547
translate es day4_start2_fba69a75:

    # player "How indecent..."
    player "Qué indecente..."

# game/chapters/4_day.rpyc:549
translate es day4_start2_02c5c1f3:

    # GR "aaa... aa..."
    GR "aaa... aa..."

# game/chapters/4_day.rpyc:550
translate es day4_start2_137233e6:

    # GR "you are... just.... ugh!"
    GR "eres... solo... ¡ugh!"

# game/chapters/4_day.rpyc:553
translate es day4_start2_d8825641:

    # player "Hmmm?"
    player "¿Mmmm?"

# game/chapters/4_day.rpyc:556
translate es day4_start2_0b5bc78d:

    # player "You're the one making a big deal out of it."
    player "Eres tú quien le está dando tanta importancia."

# game/chapters/4_day.rpyc:559
translate es day4_start2_a23d5324:

    # player "My little reaper... growing up so fast..."
    player "Mi parquita... creciendo tan rápido..."

# game/chapters/4_day.rpyc:562
translate es day4_start2_00e19db8:

    # player "I do like a guy who knows what he wants, though."
    player "Sin embargo, me gustan los hombres que saben lo que quieren."

# game/chapters/4_day.rpyc:564
translate es day4_start2_be146feb:

    # GR "this is not what i signed up for when i took this contract..."
    GR "esto no es lo que yo esperaba cuando firmé este contrato..."

# game/chapters/4_day.rpyc:565
translate es day4_start2_07bbfa0c:

    # GR "you are especially aggravating today..."
    GR "hoy estás especialmente irritante..."

# game/chapters/4_day.rpyc:569
translate es day4_start2_5ebeafae:

    # player "I'm always like this."
    player "Siempre soy así."

# game/chapters/4_day.rpyc:572
translate es day4_start2_92636543:

    # player "I just feel like messing with you."
    player "Solo tengo ganas de molestarte."

# game/chapters/4_day.rpyc:574
translate es day4_start2_d0264a47:

    # GR "you will face a punishment worse than death if you keep... teasing me like that."
    GR "te enfrentarás a un castigo peor que la muerte si sigues... burlándote de mí así."

# game/chapters/4_day.rpyc:578
translate es day4_start2_0493bf86:

    # player "Oh?"
    player "¿Oh?"

# game/chapters/4_day.rpyc:579
translate es day4_start2_e9656f04:

    # GR "..............."
    GR "..............."

# game/chapters/4_day.rpyc:582
translate es day4_start2_aae00bad:

    # player "Poor Grim. So easily flustered."
    player "Pobre Parca. Se altera con tanta facilidad."

# game/chapters/4_day.rpyc:583
translate es day4_start2_a48b7842:

    # GR "ughhhhh."
    GR "ughhhhh."

# game/chapters/4_day.rpyc:584
translate es day4_start2_f25035c9:

    # GR "stop talking. immediately. or i'll take your soul right now."
    GR "deja de hablar. inmediatamente. o tomaré tu alma ahora mismo."

# game/chapters/4_day.rpyc:587
translate es day4_start2_2e3e5247:

    # player "You're the one who won't tell me what I want to know."
    player "Tú eres el que no me dice lo que quiero saber."

# game/chapters/4_day.rpyc:590
translate es day4_start2_cc4717bc:

    # player "This is {i}your{/i} punishment."
    player "Este es {i}tu{/i} castigo."

# game/chapters/4_day.rpyc:593
translate es day4_start2_4b9e2ca8:

    # player "So, unless you have something to tell me..."
    player "Entonces, a menos que tengas algo que decirme..."

# game/chapters/4_day.rpyc:596
translate es day4_start2_21cf1849:

    # player "I'll continue with your punishment!"
    player "¡Continuaré con tu castigo!"

# game/chapters/4_day.rpyc:598
translate es day4_start2_314468dc:

    # GR "nine hells..."
    GR "nueve infiernos..."

# game/chapters/4_day.rpyc:599
translate es day4_start2_ad6c7f8d:

    # GR "fine."
    GR "bien."

# game/chapters/4_day.rpyc:600
translate es day4_start2_a3c268a0:

    # GR "i'll tell you."
    GR "te lo diré."

# game/chapters/4_day.rpyc:604
translate es day4_start2_5f6bf18a:

    # player "There we go!"
    player "¡Ahí vamos!"

# game/chapters/4_day.rpyc:607
translate es day4_start2_f26aa82b:

    # player "So?"
    player "¿Entonces?"

# game/chapters/4_day.rpyc:608
translate es day4_start2_b9db3f12:

    # GR "you are so very demanding."
    GR "eres muy exigente."

# game/chapters/4_day.rpyc:609
translate es day4_start2_ae9cd1a6:

    # GR "to make a long story short..."
    GR "para resumir una larga historia..."

# game/chapters/4_day.rpyc:610
translate es day4_start2_624e8cdc:

    # GR "there is 110 percent something wrong with you."
    GR "hay algo que no está bien en ti, al 110 por ciento."

# game/chapters/4_day.rpyc:613
translate es day4_start2_64d723d8:

    # player "Well, obviously."
    player "Bueno, obviamente."

# game/chapters/4_day.rpyc:614
translate es day4_start2_7772a27d_2:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:615
translate es day4_start2_8e224496:

    # GR "i am glad you realize."
    GR "me alegra que te das cuenta."

# game/chapters/4_day.rpyc:616
translate es day4_start2_fd398c93:

    # GR "but i don't mean with your... personality, or whatever."
    GR "pero no me refiero a tu... personalidad, o lo que sea."

# game/chapters/4_day.rpyc:619
translate es day4_start2_20461dbf:

    # player "So what do you mean then?"
    player "Entonces, ¿a qué te refieres entonces?"

# game/chapters/4_day.rpyc:622
translate es day4_start2_114b23d8:

    # player "Am I secretly an immortal? Am I a Grim Reaper too?"
    player "¿Soy secretamente inmortal? ¿Soy una Parca también?"

# game/chapters/4_day.rpyc:623
translate es day4_start2_ec83fcff:

    # GR "of course not."
    GR "Por supuesto que no."

# game/chapters/4_day.rpyc:624
translate es day4_start2_79f236f3:

    # GR "use your brain. you are human..."
    GR "usa tu cerebro. eres un ser humano..."

# game/chapters/4_day.rpyc:625
translate es day4_start2_fdc3297c:

    # GR "i swear, the things you say get stupider and stupider every day."
    GR "te lo juro, cada día dices cosas más estúpidas."

# game/chapters/4_day.rpyc:628
translate es day4_start2_f9ff3820:

    # player "You seem to be having a hard time taking my soul, right?"
    player "Parece que estás teniendo dificultades para tomar mi alma, ¿verdad?"

# game/chapters/4_day.rpyc:631
translate es day4_start2_5283a71b:

    # player "Maybe my immortality stops you!"
    player "¡Quizás mi inmortalidad te detiene!"

# game/chapters/4_day.rpyc:632
translate es day4_start2_5677fe45:

    # GR "do you ever stop spouting nonsense?"
    GR "¿alguna vez dejas de decir tonterías?"

# game/chapters/4_day.rpyc:633
translate es day4_start2_c247906b:

    # GR "mortals are not immortal. it is not possible."
    GR "los mortales no son inmortales. No es posible."

# game/chapters/4_day.rpyc:634
translate es day4_start2_76bb4d20:

    # GR "if you were immortal, you wouldn't be mortal, and you're obviously mortal."
    GR "si fueras inmortal, no serías mortal y obviamente eres mortal."

# game/chapters/4_day.rpyc:637
translate es day4_start2_c3eae2d9:

    # player "I thought that was a good hypothesis."
    player "Pensé que era una buena hipótesis."

# game/chapters/4_day.rpyc:640
translate es day4_start2_64f7517a:

    # player "Wow, you just came out and said it."
    player "Wow, lo acabas de decir sin rodeos."

# game/chapters/4_day.rpyc:641
translate es day4_start2_d20d3b33:

    # GR "you wanted to know."
    GR "querías saberlo."

# game/chapters/4_day.rpyc:642
translate es day4_start2_18569252:

    # GR "so i told you. simple as that."
    GR "entonces te lo dije. así de simple."

# game/chapters/4_day.rpyc:645
translate es day4_start2_6427ffaf:

    # player "You could say it a little more nicely..."
    player "Podrías decirlo de una manera un poco más amable..."

# game/chapters/4_day.rpyc:646
translate es day4_start2_8a604d2b:

    # GR "how else would i tell you?"
    GR "¿de qué otra manera te lo diría?"

# game/chapters/4_day.rpyc:647
translate es day4_start2_8f6e45af:

    # GR "there is literally something wrong with you."
    GR "literalmente hay algo mal contigo."

# game/chapters/4_day.rpyc:648
translate es day4_start2_a24f11c8:

    # GR "you are abnormal. an abnormal mortal."
    GR "eres anormal. un mortal anormal."

# game/chapters/4_day.rpyc:651
translate es day4_start2_03775ec8:

    # player "..."
    player "..."

# game/chapters/4_day.rpyc:652
translate es day4_start2_7772a27d_3:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:655
translate es day4_start2_59f1b286:

    # player "The bully becomes the bullied..."
    player "El bully se convierte en el acosado..."

# game/chapters/4_day.rpyc:656
translate es day4_start2_d6a3b77a:

    # GR "sometimes, in life, it is just better to say things how they are."
    GR "a veces, en la vida, es mejor decir las cosas tal y como son."

# game/chapters/4_day.rpyc:659
translate es day4_start2_84fdb22e:

    # player "Don't you mean '{i}in death{/i}'?"
    player "¿No querrás decir '{i}en la muerte{/i}'?"

# game/chapters/4_day.rpyc:662
translate es day4_start2_a656bdd5:

    # player "Since when are you a spokesperson on living?"
    player "¿Desde cuándo eres vocero de la vida?"

# game/chapters/4_day.rpyc:663
translate es day4_start2_e5e831ef:

    # GR "you are still living, are you not?"
    GR "aún sigues vivo, ¿no es así?"

# game/chapters/4_day.rpyc:666
translate es day4_start2_2b2b4ba8:

    # player "I really hope so."
    player "Realmente lo espero."

# game/chapters/4_day.rpyc:669
translate es day4_start2_4375cc91:

    # player "Or maybe I'm a flesh eating zombie on my way to munch you."
    player "O tal vez soy un zombi devorador de carne que va a por ti para devorarte."

# game/chapters/4_day.rpyc:670
translate es day4_start2_7772a27d_4:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:671
translate es day4_start2_c5220199:

    # GR "{i}that{/i} is where your brain goes?"
    GR "¿{i}ahí{/i} es donde va tu cerebro?"

# game/chapters/4_day.rpyc:672
translate es day4_start2_39fc136b:

    # GR "we are having a serious discussion here."
    GR "estamos teniendo una discusión seria aquí."

# game/chapters/4_day.rpyc:676
translate es day4_start2_c7f5a7d9:

    # player "Mmmmm braaaains..."
    player "Mmmmm ceeeerebros..."

# game/chapters/4_day.rpyc:677
translate es day4_start2_f8985643:

    # GR "you have the humor of a child."
    GR "tienes el humor de un niño."

# game/chapters/4_day.rpyc:680
translate es day4_start2_577b60d3:

    # player "It was just a thought!"
    player "¡Solo era una idea!"

# game/chapters/4_day.rpyc:681
translate es day4_start2_51bec76d:

    # GR "well maybe stop having them, then."
    GR "bueno, pues quizá deberías dejar de tenerlas."

# game/chapters/4_day.rpyc:682
translate es day4_start2_dc6b309a:

    # GR "i'm sure you are further damaging what little remains of your brain tissue..."
    GR "estoy seguro de que estás dañando aún más lo poco que te queda de tejido cerebral..."

# game/chapters/4_day.rpyc:685
translate es day4_start2_cbc7db75:

    # player "You don't think I'm some mutant superhuman, do you?"
    player "¿No creerás que soy algún tipo de superhumano mutante, verdad?"

# game/chapters/4_day.rpyc:686
translate es day4_start2_7e6c4e6a:

    # GR "i absolutely do not."
    GR "por supuesto que no."

# game/chapters/4_day.rpyc:689
translate es day4_start2_b467a8cc:

    # player "Phew..."
    player "Uf..."

# game/chapters/4_day.rpyc:692
translate es day4_start2_d11671c7:

    # player "There is not!"
    player "¡No lo es!"

# game/chapters/4_day.rpyc:693
translate es day4_start2_c427fd8f:

    # GR "there is."
    GR "sí lo es."

# game/chapters/4_day.rpyc:696
translate es day4_start2_d096e396:

    # player "You'll find that if either of us has something wrong with them, it's you."
    player "Te darás cuenta de que si alguno de los dos tiene algún problema, ese eres tú."

# game/chapters/4_day.rpyc:697
translate es day4_start2_1febb025:

    # GR "ha."
    GR "ha."

# game/chapters/4_day.rpyc:700
translate es day4_start2_8a006e98:

    # GR "i thought we talked about this yesterday."
    GR "pensé que ya habíamos hablado de esto ayer."

# game/chapters/4_day.rpyc:701
translate es day4_start2_02b5da23:

    # GR "i am without flaw."
    GR "no tengo ningún defecto."

# game/chapters/4_day.rpyc:704
translate es day4_start2_96b40fca:

    # player "And I told you, everyone has flaws."
    player "Y te dije que todo el mundo tiene defectos."

# game/chapters/4_day.rpyc:705
translate es day4_start2_e0273caf:

    # GR "not me."
    GR "yo no."

# game/chapters/4_day.rpyc:706
translate es day4_start2_036bfc70:

    # GR "i am, how the kids say, 'too cool for that'."
    GR "soy, como dicen los jóvenes, 'demasiado cool para eso'."

# game/chapters/4_day.rpyc:709
translate es day4_start2_757e3293:

    # player "You are so completely and utterly wrong it hurts."
    player "Estás tan completamente equivocado que duele."

# game/chapters/4_day.rpyc:711
translate es day4_start2_02b5da23_1:

    # GR "i am without flaw."
    GR "no tengo defectos."

# game/chapters/4_day.rpyc:714
translate es day4_start2_fe7147b0:

    # player "Grim, everyone has flaws."
    player "Parca, todos tienen defectos."

# game/chapters/4_day.rpyc:715
translate es day4_start2_6d79f60e:

    # GR "not me, unfortunately."
    GR "yo no, desafortunadamente."

# game/chapters/4_day.rpyc:717
translate es day4_start2_3f2079c4:

    # GR "there is something wrong with you, full stop."
    GR "hay algo que no está bien en ti, y punto."

# game/chapters/4_day.rpyc:718
translate es day4_start2_f856f0c8:

    # GR "i don't mean it as an insult... this time."
    GR "no lo digo como un insulto... esta vez."

# game/chapters/4_day.rpyc:722
translate es day4_start2_03775ec8_1:

    # player "..."
    player "..."

# game/chapters/4_day.rpyc:725
translate es day4_start2_3d59fbad:

    # player "Which is...?"
    player "¿Qué es...?"

# game/chapters/4_day.rpyc:726
translate es day4_start2_2cfbaea0:

    # GR "well..."
    GR "bueno..."

# game/chapters/4_day.rpyc:727
translate es day4_start2_a3ac1283:

    # GR "how do i put this lightly..."
    GR "¿cómo decirlo con delicadeza...?"

# game/chapters/4_day.rpyc:732
translate es day4_start2_355d35a3:

    # player "Are you being considerate of me right now Grim? :O"
    player "¿Estás siendo considerado conmigo ahora mismo, Parca? :O"

# game/chapters/4_day.rpyc:733
translate es day4_start2_7c682448:

    # GR "i am about to tell you bad news, so i was just trying to be 'nice'."
    GR "estoy a punto de darte malas noticias, así que solo intentaba ser 'amable'."

# game/chapters/4_day.rpyc:737
translate es day4_start2_909035e6:

    # player "Okay, now you're making me scared."
    player "Bien, ahora me estás dando miedo."

# game/chapters/4_day.rpyc:738
translate es day4_start2_0fe42d74:

    # GR "i was just thinking of how to say this in the least brutal fashion."
    GR "estaba pensando en cómo decir esto de la forma menos brutal posible."

# game/chapters/4_day.rpyc:741
translate es day4_start2_19dde411:

    # player "Grim being nice? What has the world come to..."
    player "¿Parca siendo amable? ¿A dónde ha llegado el mundo...?"

# game/chapters/4_day.rpyc:742
translate es day4_start2_533962e4:

    # GR "ok, maybe i shouldn't care about how you feel. my bad."
    GR "ok, quizá no debería preocuparme por cómo te sientes. culpa mía."

# game/chapters/4_day.rpyc:745
translate es day4_start2_66f3c639:

    # player "So it's {i}very{/i} bad news..."
    player "Entonces son {i}muy{/i} malas noticias..."

# game/chapters/4_day.rpyc:748
translate es day4_start2_a0ddac7e:

    # player "Am I dying?"
    player "¿Me estoy muriendo?"

# game/chapters/4_day.rpyc:751
translate es day4_start2_dae9bdc9:

    # player "Oh god... Grim, I'm too young to die..."
    player "Oh Dios ... Parca, soy demasiado joven para morir..."

# game/chapters/4_day.rpyc:752
translate es day4_start2_406c75f7:

    # GR "no, you aren't dying. if you were, that would be fantastic news."
    GR "no, no estás muriendo. si fuera así, sería una noticia fantástica."

# game/chapters/4_day.rpyc:755
translate es day4_start2_3102329f:

    # player "It's worse than dying?!"
    player "¡¿Es peor que morir?!"

# game/chapters/4_day.rpyc:756
translate es day4_start2_9bb5963c:

    # GR "what? just let me explain."
    GR "¿qué? déjame explicarte."

# game/chapters/4_day.rpyc:757
translate es day4_start2_761cc89e:

    # GR "there is something wrong with your soul, okay?"
    GR "hay algo mal en tu alma, ¿de acuerdo?"

# game/chapters/4_day.rpyc:760
translate es day4_start2_b7a12d86:

    # player "My... soul? Is it broken?"
    player "¿Mi... alma? ¿Está rota?"

# game/chapters/4_day.rpyc:761
translate es day4_start2_4229a73c:

    # GR "hm."
    GR "hm."

# game/chapters/4_day.rpyc:762
translate es day4_start2_a9046016:

    # GR "i wouldn't say broken, exactly."
    GR "no diría que rota exactamente."

# game/chapters/4_day.rpyc:765
translate es day4_start2_d7a7a3fc:

    # player "Well, what would you say, then?"
    player "Bueno, ¿qué dirías, entonces?"

# game/chapters/4_day.rpyc:768
translate es day4_start2_5a484e19:

    # player "Then what exactly {i}is{/i} wrong with it?"
    player "Entonces, ¿qué exactamente {i}está{/i} mal?"

# game/chapters/4_day.rpyc:770
translate es day4_start2_7772a27d_5:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:774
translate es day4_start2_91224d77:

    # player "Oi, Earthling to Grim!"
    player "¡Oye, Terrícola a Parca!"

# game/chapters/4_day.rpyc:777
translate es day4_start2_e385dddc:

    # player "Come onnnn... tell me..."
    player "Vamoooos... dime..."

# game/chapters/4_day.rpyc:780
translate es day4_start2_59d12e86:

    # player "Grim..."
    player "Parca..."

# game/chapters/4_day.rpyc:783
translate es day4_start2_e265393f:

    # player "Don't just stop talking now."
    player "No dejes de hablar ahora."

# game/chapters/4_day.rpyc:785
translate es day4_start2_8cd887cf:

    # GR "you're awfully pushy, aren't you? something is wrong. that's all i have to say to you."
    GR "eres muy insistente, ¿no? algo anda mal. eso es todo lo que tengo que decirte."

# game/chapters/4_day.rpyc:786
translate es day4_start2_5e331b74:

    # GR "i need more time to look into it further. then i may, or may not, tell you more."
    GR "necesito más tiempo para investigarlo más a fondo. entonces, tal vez te diga más, o tal vez no."

# game/chapters/4_day.rpyc:790
translate es day4_start2_ac6385c7:

    # player "And I'm meant to just go on with my normal life?"
    player "¿Y se supone que debo seguir con mi vida normal?"

# game/chapters/4_day.rpyc:791
translate es day4_start2_ca9fefbe:

    # GR "pretty much."
    GR "más o menos."

# game/chapters/4_day.rpyc:794
translate es day4_start2_8b4807a4:

    # player "{i}Pretty much{/i}?"
    player "¿{i}Más o menos{/i}?"

# game/chapters/4_day.rpyc:795
translate es day4_start2_ee496869:

    # GR "well, nothing has changed. it was like this before, whether you knew it or not."
    GR "bueno, nada ha cambiado. ya era así antes, lo supieras o no."

# game/chapters/4_day.rpyc:796
translate es day4_start2_97ec3df1:

    # GR "there's no reason to act differently now."
    GR "no hay razón para actuar de manera diferente ahora."

# game/chapters/4_day.rpyc:799
translate es day4_start2_9d7d81e1:

    # player "Well... I guess you have a point, but still..."
    player "Bueno... Supongo que tienes razón, pero aun así..."

# game/chapters/4_day.rpyc:800
translate es day4_start2_7b7b096c:

    # GR "obviously i have a point. everything i say has a point."
    GR "obviamente tengo razón. todo lo que digo tiene sentido."

# game/chapters/4_day.rpyc:803
translate es day4_start2_e37114fa:

    # player "But am I really okay to just keep going about my day to day life, like I know nothing?"
    player "¿Pero realmente está bien que siga con mi vida cotidiana como si nada?"

# game/chapters/4_day.rpyc:806
translate es day4_start2_9efc0934:

    # player "There's no risk... right?"
    player "No hay riesgo... ¿verdad?"

# game/chapters/4_day.rpyc:809
translate es day4_start2_68d0f845:

    # player "What if my soul combusts or something because I overwork myself?"
    player "¿Qué pasa si mi alma se quema o algo así por trabajar demasiado?"

# game/chapters/4_day.rpyc:811
translate es day4_start2_0ddec735:

    # GR "there is no point dwelling on it now."
    GR "no tiene sentido darle vueltas al asunto ahora."

# game/chapters/4_day.rpyc:815
translate es day4_start2_57f07a7a:

    # player "That doesn't answer my question!"
    player "¡Eso no responde mi pregunta!"

# game/chapters/4_day.rpyc:816
translate es day4_start2_dff89950:

    # GR "yes, go on with your usual activities."
    GR "sí, sigue con tus actividades habituales."

# game/chapters/4_day.rpyc:818
translate es day4_start2_e53a6345:

    # GR "go to work, cuddle [pet_name]."
    GR "ir a trabajar, abrazar a [pet_name]."

# game/chapters/4_day.rpyc:819
translate es day4_start2_76f31017:

    # GR "do whatever it is you actually do when you're not waiting for me."
    GR "haz lo que sea que hagas cuando no me estás esperando."

# game/chapters/4_day.rpyc:821
translate es day4_start2_d4bfd480:

    # GR "go to work, cuddle your pet."
    GR "ir a trabajar, abrazar a tu mascota."

# game/chapters/4_day.rpyc:822
translate es day4_start2_76f31017_1:

    # GR "do whatever it is you actually do when you're not waiting for me."
    GR "haz lo que sea que hagas cuando no me estás esperando."

# game/chapters/4_day.rpyc:827
translate es day4_start2_7e95c672:

    # player "[pet_name]!"
    player "¡[pet_name]!"

# game/chapters/4_day.rpyc:831
translate es day4_start2_172b4b7b:

    # player "Ah!"
    player "¡Ah!"

# game/chapters/4_day.rpyc:834
translate es day4_start2_0068c045:

    # player "For once you say something smart."
    player "Por una vez dices algo inteligente."

# game/chapters/4_day.rpyc:837
translate es day4_start2_d5603b42:

    # player "Cuddles do always make things better :)"
    player "Los abrazos siempre mejoran las cosas :)"

# game/chapters/4_day.rpyc:838
translate es day4_start2_8d1d3770:

    # GR "...okay."
    GR "...bueno."

# game/chapters/4_day.rpyc:841
translate es day4_start2_e9a092c0:

    # player "Jealous?"
    player "¿Celoso?"

# game/chapters/4_day.rpyc:842
translate es day4_start2_87c63c34:

    # GR "of that little thing?"
    GR "¿de esa pequeña cosa?"

# game/chapters/4_day.rpyc:843
translate es day4_start2_e701fbba:

    # GR "why would i be jealous of an animal?"
    GR "¿por qué estaría celoso de un animal?"

# game/chapters/4_day.rpyc:846
translate es day4_start2_7b0abfe9:

    # player "I bet you are."
    player "Apuesto a que lo estás."

# game/chapters/4_day.rpyc:850
translate es day4_start2_a1b541e5:

    # player "There's nothing to be ashamed of."
    player "No hay nada de qué avergonzarse."

# game/chapters/4_day.rpyc:851
translate es day4_start2_df361a34:

    # GR "you are so irritating."
    GR "eres tan irritante."

# game/chapters/4_day.rpyc:852
translate es day4_start2_acd93b2e:

    # GR "i am not jealous of your {i}little pet{/i}."
    GR "no estoy celoso de tu {i}pequeña mascota{/i}."

# game/chapters/4_day.rpyc:855
translate es day4_start2_64814645:

    # player "I can feel it radiating off of you."
    player "Puedo sentirlo irradiando de ti."

# game/chapters/4_day.rpyc:858
translate es day4_start2_5b5c98cf:

    # player "Even through the screen."
    player "Incluso a través de la pantalla."

# game/chapters/4_day.rpyc:859
translate es day4_start2_7772a27d_6:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:862
translate es day4_start2_d6c3ae7e:

    # player "There's nothing wrong with jealousy."
    player "No hay nada de malo en los celos."

# game/chapters/4_day.rpyc:865
translate es day4_start2_1687bae2:

    # player "Do you want a hug, too?"
    player "¿Quieres un abrazo también?"

# game/chapters/4_day.rpyc:866
translate es day4_start2_ce9aa3f1:

    # GR "i do not need a hug, no."
    GR "no necesito un abrazo, no."

# game/chapters/4_day.rpyc:869
translate es day4_start2_947046e5:

    # player "Are you suuure?"
    player "¿Estás seguuuro?"

# game/chapters/4_day.rpyc:870
translate es day4_start2_483474bf:

    # GR "i am completely sure i do not need a hug."
    GR "estoy completamente seguro de que no necesito un abrazo."

# game/chapters/4_day.rpyc:873
translate es day4_start2_903c0aec:

    # player "But you {i}want{/i} one, don't you?"
    player "Pero tú {i}quieres{/i} uno, ¿no?"

# game/chapters/4_day.rpyc:874
translate es day4_start2_379d9bbe:

    # GR "hugs are not needed, thank you."
    GR "no necesito abrazos, gracias."

# game/chapters/4_day.rpyc:877
translate es day4_start2_86db3c2f:

    # player "Sure thing! :)"
    player "¡Seguro! :)"

# game/chapters/4_day.rpyc:878
translate es day4_start2_7107e6a1:

    # GR "ok, i don't like that smiley face, nor the tone of your message."
    GR "ok, no me gusta esa carita sonriente, ni el tono de tu mensaje."

# game/chapters/4_day.rpyc:879
translate es day4_start2_e29da0e8:

    # GR "so i am going to move on from this idiotic conversation now."
    GR "así que voy a dejar esta conversación idiota."

# game/chapters/4_day.rpyc:882
translate es day4_start2_33a53431:

    # player "Great... I'm dying of broken soul disease..."
    player "Genial... Me estoy muriendo de la enfermedad del alma rota..."

# game/chapters/4_day.rpyc:883
translate es day4_start2_fa4dbad5:

    # GR "you aren't dying. i told you as much already."
    GR "no te estás muriendo. ya te lo he dicho."

# game/chapters/4_day.rpyc:884
translate es day4_start2_1b566b71:

    # GR "i think you should see a doctor about your memory issues, if anything."
    GR "creo que deberías consultar a un médico por tus problemas de memoria, si acaso."

# game/chapters/4_day.rpyc:885
translate es day4_start2_5b9f37b7:

    # GR "also, you don't have broken soul disease."
    GR "además, no tienes la enfermedad del alma rota."

# game/chapters/4_day.rpyc:886
translate es day4_start2_6df280a5:

    # GR "that's not even a thing. another ridiculous assumption from my ridiculous mortal."
    GR "eso ni siquiera existe. otra suposición ridícula de mi ridículo mortal."

# game/chapters/4_day.rpyc:890
translate es day4_start2_e810fb49:

    # player "YOUR mortal?"
    player "¿TU mortal?"

# game/chapters/4_day.rpyc:891
translate es day4_start2_f5e37126:

    # GR "it is correct. you are a mortal under my watch."
    GR "es correcto. eres un mortal bajo mi vigilancia."

# game/chapters/4_day.rpyc:894
translate es day4_start2_793e014d:

    # player "Aww, you make it sound kinda nice."
    player "Aww, lo haces sonar bastante bien."

# game/chapters/4_day.rpyc:897
translate es day4_start2_00c06270:

    # player "You're sweeping me off my feet here, Grimmy."
    player "Me estás dejando sin aliento, Parquita."

# game/chapters/4_day.rpyc:900
translate es day4_start2_f38d558b:

    # player "You're my guardian angel!"
    player "¡Eres mi ángel guardián!"

# game/chapters/4_day.rpyc:901
translate es day4_start2_4c098111:

    # GR "i can see how you would mistake me for an angel, yes."
    GR "puedo entender que me confundas con un ángel, sí."

# game/chapters/4_day.rpyc:902
translate es day4_start2_02a08474:

    # GR "but please don't forget i am planning your demise."
    GR "pero no olvides que estoy planeando tu desaparición."

# game/chapters/4_day.rpyc:905
translate es day4_start2_908a6e21:

    # player "A devil in disguise as an angel, it's a little poetic."
    player "Un demonio disfrazado de ángel, es un poco poético."

# game/chapters/4_day.rpyc:906
translate es day4_start2_38e71789:

    # GR "or a little stupid. i am neither an angel nor a devil."
    GR "o un poco estúpido. no soy ni un ángel ni un demonio."

# game/chapters/4_day.rpyc:907
translate es day4_start2_61520305:

    # GR "devils are not nearly as handsome as me."
    GR "los demonios no son tan guapos como yo."

# game/chapters/4_day.rpyc:908
translate es day4_start2_d8e79f64:

    # GR "and they smell."
    GR "y huelen mal."

# game/chapters/4_day.rpyc:911
translate es day4_start2_520dfe4c:

    # player "How do I know you don't smell?"
    player "¿Cómo sé que tú no hueles mal?"

# game/chapters/4_day.rpyc:912
translate es day4_start2_a4d5120a:

    # GR "i suppose you must take my word for it."
    GR "Supongo que tendrás que creerme."

# game/chapters/4_day.rpyc:915
translate es day4_start2_35d52350:

    # player "Orrrr... you could come prove it?"
    player "Oooo... ¿podrías venir a demostrarlo?"

# game/chapters/4_day.rpyc:916
translate es day4_start2_e788183a:

    # GR "oh, i will."
    GR "oh, lo haré."

# game/chapters/4_day.rpyc:917
translate es day4_start2_92286252:

    # GR "you will smell the scent of death itself soon enough, when i come for your life."
    GR "pronto olerás el aroma de la muerte misma, cuando venga a acabar con tu vida."

# game/chapters/4_day.rpyc:920
translate es day4_start2_7e6168b3:

    # player "Uh..."
    player "Uh..."

# game/chapters/4_day.rpyc:922
translate es day4_start2_3f2d8bdf:

    # player "You started off so well for a second there..."
    player "Por un momento, habías empezado muy bien..."

# game/chapters/4_day.rpyc:923
translate es day4_start2_b2766aa4:

    # GR "???"
    GR "???"

# game/chapters/4_day.rpyc:926
translate es day4_start2_dc3a1b5c:

    # player "NGL the 'scent of death' sounds like it'd smell kinda bad."
    player "Sinceramente, el 'aroma de la muerte' suena como si oliera bastante mal."

# game/chapters/4_day.rpyc:927
translate es day4_start2_611690b7:

    # GR "huh??"
    GR "¿¿huh??"

# game/chapters/4_day.rpyc:928
translate es day4_start2_b59c4e5a:

    # GR "how and why would it smell bad?"
    GR "¿cómo y por qué olería mal?"

# game/chapters/4_day.rpyc:931
translate es day4_start2_36f5768b:

    # player "It sounds... earthy and rotting."
    player "Suena ... terroso y podrido."

# game/chapters/4_day.rpyc:932
translate es day4_start2_05cc25a7:

    # GR "i do not smell earthy and rotting!"
    GR "¡no huelo a tierra ni a podrido!"

# game/chapters/4_day.rpyc:935
translate es day4_start2_bba6ed06:

    # player "It sounds.... sour and just entirely... unpleasant."
    player "Suena... agrio y totalmente... desagradable."

# game/chapters/4_day.rpyc:936
translate es day4_start2_ea3f418a:

    # GR "i'll have you know i do {i}not{/i} smell sour."
    GR "te informo que {i}no{/i} huelo agrio."

# game/chapters/4_day.rpyc:937
translate es day4_start2_d99fd19d:

    # GR "and i smell extremely pleasant."
    GR "y huelo muy bien."

# game/chapters/4_day.rpyc:938
translate es day4_start2_218bd72c:

    # GR "i smell so good you could drown in my scent."
    GR "huelo tan bien que podrías ahogarme en mi aroma."

# game/chapters/4_day.rpyc:941
translate es day4_start2_417edd1b:

    # player "If you smell that strongly, I suggest you bathe."
    player "Si hueles tan fuerte, te sugiero que te bañes."

# game/chapters/4_day.rpyc:944
translate es day4_start2_167b438b:

    # player "You should work on the description of your scent some more."
    player "Deberías mejorar un poco más la descripción de tu aroma."

# game/chapters/4_day.rpyc:947
translate es day4_start2_d4c23dc4:

    # player "ANYWAY!"
    player "¡DE TODOS MODOS!"

# game/chapters/4_day.rpyc:950
translate es day4_start2_3889760f:

    # player "This is all totally beside the point."
    player "Todo esto no viene al caso."

# game/chapters/4_day.rpyc:953
translate es day4_start2_0efd498b:

    # player "I'm freaking out about my broken soul disease here."
    player "Estoy enloqueciendo por mi enfermedad del alma rota."

# game/chapters/4_day.rpyc:954
translate es day4_start2_b3bba3cd:

    # GR "there is no need to freak out."
    GR "no hay necesidad de asustarse."

# game/chapters/4_day.rpyc:955
translate es day4_start2_a0f1902e:

    # GR "just go about your usual daily business."
    GR "simplemente sigue con tus actividades diarias habituales."

# game/chapters/4_day.rpyc:958
translate es day4_start2_f8f977a0:

    # player "Just go about my business..."
    player "Que solo siga con mis actividades..."

# game/chapters/4_day.rpyc:959
translate es day4_start2_b748c7da:

    # GR "that's what i said."
    GR "eso es lo que dije."

# game/chapters/4_day.rpyc:960
translate es day4_start2_35db9b1f:

    # GR "congratulations on your elementary level of reading."
    GR "felicidades por tu nivel básico de lectura."

# game/chapters/4_day.rpyc:963
translate es day4_start2_472d80e9:

    # player "Is that really safe?"
    player "¿Es realmente seguro?"

# game/chapters/4_day.rpyc:966
translate es day4_start2_233838d1:

    # player "What if I do something that puts my soul in danger?"
    player "¿Qué pasa si hago algo que ponga en peligro mi alma?"

# game/chapters/4_day.rpyc:967
translate es day4_start2_628b57f5:

    # GR "you didn't even know something was wrong with it until like two minutes ago."
    GR "ni siquiera sabías que algo andaba mal hasta hace dos minutos."

# game/chapters/4_day.rpyc:968
translate es day4_start2_6930b755:

    # GR "you have survived until now."
    GR "has sobrevivido hasta ahora."

# game/chapters/4_day.rpyc:969
translate es day4_start2_161fa6b0:

    # GR "i don't believe anything will happen if you keep acting as per usual."
    GR "no creo que pase nada si sigues actuando como siempre."

# game/chapters/4_day.rpyc:972
translate es day4_start2_cd71b707:

    # player "I suppose that makes sense..."
    player "Supongo que eso tiene sentido..."

# game/chapters/4_day.rpyc:973
translate es day4_start2_d5ec9bbe:

    # GR "obviously, i said it, after all."
    GR "obviamente, lo dije, después de todo."

# game/chapters/4_day.rpyc:976
translate es day4_start2_4073a4c7:

    # player "Your smug little attitude is annoying, but makes me a little less stressed, somehow."
    player "Tu actitud engreída es molesta, pero de alguna manera me hace sentir un poco menos de estrés."

# game/chapters/4_day.rpyc:977
translate es day4_start2_7772a27d_7:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:979
translate es day4_start2_de57fa46:

    # player "Eh, seeing as you don't think it's such a big deal, maybe it's not..."
    player "Eh, ya que no crees que sea para tanto, quizá no lo sea..."

# game/chapters/4_day.rpyc:982
translate es day4_start2_c578d4c6:

    # GR "to be honest, this is just proof that you should listen to me more often."
    GR "para ser sincero, esto solo demuestra que deberías escucharme más a menudo."

# game/chapters/4_day.rpyc:983
translate es day4_start2_3d0a59ce:

    # GR "i know best."
    GR "yo sé lo que es mejor."

# game/chapters/4_day.rpyc:986
translate es day4_start2_68b3c0d0:

    # player "Pfffffftttt...."
    player "Pfffffftttt...."

# game/chapters/4_day.rpyc:989
translate es day4_start2_b4b4942f:

    # player "Ha! What a load of crap!"
    player "¡Ja! ¡Qué tontería!"

# game/chapters/4_day.rpyc:992
translate es day4_start2_e2deba40:

    # player "You're capable of making jokes, Grim? :O"
    player "¿Eres capaz de hacer bromas, Parca? :O"

# game/chapters/4_day.rpyc:993
translate es day4_start2_7546b5db:

    # GR "of course i am capable of something as simple as a joke."
    GR "por supuesto que soy capaz de algo tan sencillo como una broma."

# game/chapters/4_day.rpyc:994
translate es day4_start2_8168033e:

    # GR "do you take me for a fool?"
    GR "¿me tomas por tonto?"

# game/chapters/4_day.rpyc:997
translate es day4_start2_9c687eda:

    # player "I'm not going to answer that."
    player "No voy a responder eso."

# game/chapters/4_day.rpyc:1001
translate es day4_start2_732c1145:

    # player "So you think you know what's best for me?"
    player "¿Así que crees que sabes lo que es mejor para mí?"

# game/chapters/4_day.rpyc:1002
translate es day4_start2_ebc9eb7a:

    # GR "yes."
    GR "sí."

# game/chapters/4_day.rpyc:1005
translate es day4_start2_1a472017:

    # player "The guy trying to kill me knows best for me. Uh huh. Right."
    player "El tipo que intenta matarme sabe lo que es mejor para mí. Uh huh. Claro."

# game/chapters/4_day.rpyc:1006
translate es day4_start2_c05f2af4:

    # GR "thank you for agreeing so readily."
    GR "gracias por aceptarlo tan fácilmente."

# game/chapters/4_day.rpyc:1009
translate es day4_start2_0304d8bb:

    # player "That wasn't me agreeing."
    player "Yo no estaba de acuerdo."

# game/chapters/4_day.rpyc:1010
translate es day4_start2_05f247bf:

    # GR "sounded like agreement to me."
    GR "a mí me pareció que sí."

# game/chapters/4_day.rpyc:1013
translate es day4_start2_56fa336f:

    # player "You're totally twisting the meaning of my words."
    player "Estás tergiversando totalmente el significado de mis palabras."

# game/chapters/4_day.rpyc:1014
translate es day4_start2_cd06ab27:

    # GR "you literally said '{i}the guy trying to kill me knows best for me. uh huh. right.{/i}', that is an agreement."
    GR "dijiste '{i}el tipo que intenta matarme sabe lo que es mejor para mí. Uh huh. Claro.{/i}', eso es estar de acuerdo."

# game/chapters/4_day.rpyc:1017
translate es day4_start2_9ef04a75:

    # player "Asshole."
    player "Estúpido."

# game/chapters/4_day.rpyc:1021
translate es day4_start2_9321dfc1:

    # player "You're so annoying."
    player "Eres tan molesto."

# game/chapters/4_day.rpyc:1024
translate es day4_start2_2da455f3:

    # player "Ughhhhh."
    player "Ughhhhh."

# game/chapters/4_day.rpyc:1027
translate es day4_start2_f2af7dcf:

    # player "You're such a handful."
    player "Eres tan difícil de manejar."

# game/chapters/4_day.rpyc:1029
translate es day4_start2_fb937206:

    # GR "thank you."
    GR "gracias."

# game/chapters/4_day.rpyc:1032
translate es day4_start2_3e95c5f3:

    # player "But what does it change for me?"
    player "¿Pero qué cambia eso para mí?"

# game/chapters/4_day.rpyc:1033
translate es day4_start2_2f76a5a7:

    # GR "well for now, nothing, i suppose."
    GR "bueno, por ahora, nada, supongo."

# game/chapters/4_day.rpyc:1036
translate es day4_start2_1be577bd:

    # player "'{i}You suppose{/i}'!"
    player "¡'{i}Supones{/i}'!"

# game/chapters/4_day.rpyc:1039
translate es day4_start2_acbb69e2:

    # player "What if I do something dangerous?"
    player "¿Qué pasa si hago algo peligroso?"

# game/chapters/4_day.rpyc:1042
translate es day4_start2_7728286f:

    # player "Couldn't I make it worse?"
    player "¿No podría empeorarlo?"

# game/chapters/4_day.rpyc:1043
translate es day4_start2_85278e0f:

    # GR "you want my honest opinion?"
    GR "¿quieres mi sincera opinión?"

# game/chapters/4_day.rpyc:1046
translate es day4_start2_a6498661:

    # player "...For some reason, yes."
    player "...Por alguna razón, sí."

# game/chapters/4_day.rpyc:1049
translate es day4_start2_3761b83b:

    # player "No. But I'm sure you'll give it to me anyway."
    player "No. Pero seguro que me la darás de todos modos."

# game/chapters/4_day.rpyc:1050
translate es day4_start2_feec4b51:

    # GR "correct."
    GR "correcto."

# game/chapters/4_day.rpyc:1052
translate es day4_start2_cfbf2a60:

    # GR "just go about your days as you normally would."
    GR "sigue con tu vida como lo harías normalmente."

# game/chapters/4_day.rpyc:1056
translate es day4_start2_03775ec8_2:

    # player "..."
    player "..."

# game/chapters/4_day.rpyc:1059
translate es day4_start2_69d43a17:

    # player "Easily said..."
    player "Es fácil decirlo..."

# game/chapters/4_day.rpyc:1060
translate es day4_start2_beeab46e:

    # GR "you weren't even aware there was an issue until a moment ago."
    GR "hasta hace un momento ni siquiera sabías que había un problema."

# game/chapters/4_day.rpyc:1061
translate es day4_start2_d73c101f:

    # GR "there is no reason for you to completely change how you're living your life now."
    GR "no hay razón para que cambies por completo tu forma de vida actual."

# game/chapters/4_day.rpyc:1062
translate es day4_start2_05b12956:

    # GR "if anything, {i}that{/i} is what will cause you damage."
    GR "en todo caso, {i}eso{/i} es lo que te causará daño."

# game/chapters/4_day.rpyc:1065
translate es day4_start2_26e888db:

    # player "...That does actually make some amount of sense."
    player "...En realidad, eso tiene cierto sentido."

# game/chapters/4_day.rpyc:1066
translate es day4_start2_e16f226c:

    # GR "obviously."
    GR "obviamente."

# game/chapters/4_day.rpyc:1067
translate es day4_start2_3bf963f2:

    # GR "it was something i said, after all, and my words are dripping with wisdom."
    GR "fue algo que dije, después de todo, y mis palabras rebosan sabiduría."

# game/chapters/4_day.rpyc:1068
translate es day4_start2_1ede0176:

    # GR "plus i am always correct. we both know that."
    GR "además, siempre tengo razón. ambos lo sabemos."

# game/chapters/4_day.rpyc:1071
translate es day4_start2_481c64ac_1:

    # player "Oh really?"
    player "¿Ah, de verdad?"

# game/chapters/4_day.rpyc:1074
translate es day4_start2_b4686b62:

    # player "176384 + 82736 / 746 * 54"
    player "176384 + 82736 / 746 * 54"

# game/chapters/4_day.rpyc:1075
translate es day4_start2_8ede3c01:

    # GR "what?"
    GR "¿qué?"

# game/chapters/4_day.rpyc:1078
translate es day4_start2_a50c5382:

    # player "You're always right, answer my math questions then."
    player "Siempre tienes razón, responde mis preguntas de matemáticas entonces."

# game/chapters/4_day.rpyc:1081
translate es day4_start2_68b11485:

    # player "No using a calculator."
    player "No usando una calculadora."

# game/chapters/4_day.rpyc:1082
translate es day4_start2_f824c568:

    # GR "182372.932976"
    GR "182372.932976"

# game/chapters/4_day.rpyc:1085
translate es day4_start2_bba4d883:

    # player "HUH???"
    player "¿¿¿EH???"

# game/chapters/4_day.rpyc:1086
translate es day4_start2_c8f0947a:

    # GR "that is the answer to your question."
    GR "esa es la respuesta a tu pregunta."

# game/chapters/4_day.rpyc:1089
translate es day4_start2_8cf6369c:

    # player "You cheated!"
    player "¡Hiciste trampa!"

# game/chapters/4_day.rpyc:1090
translate es day4_start2_8d286a39:

    # GR "i did not."
    GR "no es cierto."

# game/chapters/4_day.rpyc:1093
translate es day4_start2_9388825b:

    # player "You did!"
    player "¡Lo hiciste!"

# game/chapters/4_day.rpyc:1094
translate es day4_start2_80a36ae9:

    # GR "i don't even own a calculator."
    GR "ni siquiera tengo una calculadora."

# game/chapters/4_day.rpyc:1097
translate es day4_start2_ad956426:

    # player "You g**gled it!"
    player "¡Lo has g**gleado!"

# game/chapters/4_day.rpyc:1098
translate es day4_start2_ce12e96b:

    # GR "i absolutely did not."
    GR "por supuesto que no."

# game/chapters/4_day.rpyc:1099
translate es day4_start2_22c9224c:

    # GR "i am simply a math genius."
    GR "soy simplemente un genio matemático."

# game/chapters/4_day.rpyc:1100
translate es day4_start2_5aa1526f:

    # GR "just because you cannot solve it, does not mean i cannot. your intellect is obviously lacking."
    GR "el hecho de que tú no puedas resolverlo no significa que yo no pueda. es obvio que te falta inteligencia."

# game/chapters/4_day.rpyc:1103
translate es day4_start2_100463e7:

    # player "Hey..."
    player "Oye..."

# game/chapters/4_day.rpyc:1106
translate es day4_start2_de78e660:

    # player "Look, maybe you got that right, but..."
    player "Mira, tal vez lo hiciste bien, pero..."

# game/chapters/4_day.rpyc:1109
translate es day4_start2_5601f435:

    # player "You can't be right 100 percent of the time."
    player "No puedes tener razón el 100 por ciento del tiempo."

# game/chapters/4_day.rpyc:1110
translate es day4_start2_3a219a0a:

    # GR "why not?"
    GR "¿por qué no?"

# game/chapters/4_day.rpyc:1113
translate es day4_start2_ade982a9:

    # player "The probability of that is almost zero!"
    player "¡La probabilidad de eso es casi cero!"

# game/chapters/4_day.rpyc:1114
translate es day4_start2_23b80f5b:

    # GR "but not impossible, certainly not for one as talented as i."
    GR "pero no imposible, ciertamente no para alguien tan talentoso como yo."

# game/chapters/4_day.rpyc:1118
translate es day4_start2_5d3ffc1b:

    # player "All of that rubbish aside..."
    player "Dejando de lado todas esas tonterías..."

# game/chapters/4_day.rpyc:1121
translate es day4_start2_c3e9be91:

    # player "How you feeling today?"
    player "¿Cómo te sientes hoy?"

# game/chapters/4_day.rpyc:1122
translate es day4_start2_bef89cdb:

    # GR "do not concern yourself with my welfare."
    GR "no te preocupes por mi bienestar."

# game/chapters/4_day.rpyc:1125
translate es day4_start2_888ecc42:

    # player "Why not?"
    player "¿Por qué no?"

# game/chapters/4_day.rpyc:1127
translate es day4_start2_45706cae:

    # player "I'll do whatever I want."
    player "Haré lo que quiera."

# game/chapters/4_day.rpyc:1130
translate es day4_start2_dc705714:

    # player "Am I not allowed to feel worried?"
    player "¿No puedo preocuparme?"

# game/chapters/4_day.rpyc:1131
translate es day4_start2_25b11c2a:

    # GR "why bother feeling worried?"
    GR "¿por qué molestarse en sentirse preocupado?"

# game/chapters/4_day.rpyc:1134
translate es day4_start2_d8f9f394:

    # player "Why would I not?"
    player "¿Por qué no lo haría?"

# game/chapters/4_day.rpyc:1135
translate es day4_start2_6ab98206:

    # GR "because it is entirely unnecessary. think on something else instead."
    GR "porque es completamente innecesario. piense en otra cosa en su lugar."

# game/chapters/4_day.rpyc:1136
translate es day4_start2_b15ba6a8:

    # GR "perhaps you could think up a bucket list of things you would like to do before you perish."
    GR "quizás podrías pensar en una lista de cosas que te gustaría hacer antes de morir."

# game/chapters/4_day.rpyc:1137
translate es day4_start2_e5087afd:

    # GR "for what is rightfully mine will soon be in my possession."
    GR "porque lo que es mío por derecho pronto estará en mi poder."

# game/chapters/4_day.rpyc:1140
translate es day4_start2_0243df2c:

    # player "You're being edgy again."
    player "Estás siendo edgy de nuevo."

# game/chapters/4_day.rpyc:1141
translate es day4_start2_d2cd2fd6:

    # GR "i am simply being myself."
    GR "simplemente estoy siendo yo mismo."

# game/chapters/4_day.rpyc:1144
translate es day4_start2_dfb1a6ab:

    # player "Yeah, edgy."
    player "Sí, edgy."

# game/chapters/4_day.rpyc:1147
translate es day4_start2_1dbf92fe:

    # player "You've got three days left, not including today."
    player "Te quedan tres días, sin contar hoy."

# game/chapters/4_day.rpyc:1150
translate es day4_start2_f4116674:

    # player "Have you even been trying?"
    player "¿Lo has intentado siquiera?"

# game/chapters/4_day.rpyc:1151
translate es day4_start2_7772a27d_8:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:1152
translate es day4_start2_22fe7467:

    # GR "none of your business."
    GR "no es asunto tuyo."

# game/chapters/4_day.rpyc:1155
translate es day4_start2_c43d26b8:

    # player "I'd actually say it is."
    player "De hecho, diría que lo es."

# game/chapters/4_day.rpyc:1158
translate es day4_start2_ddbef5df:

    # player "Anyway, we can worry about my impending doom later."
    player "De todos modos, podemos preocuparnos por mi inminente perdición más tarde."

# game/chapters/4_day.rpyc:1159
translate es day4_start2_cd211937:

    # GR "it is a rather pressing issue, you know."
    GR "es un asunto bastante urgente, ya sabes."

# game/chapters/4_day.rpyc:1162
translate es day4_start2_37c0cf92:

    # player "As is your health."
    player "Como es tu salud."

# game/chapters/4_day.rpyc:1163
translate es day4_start2_2c145da8:

    # GR "...fine. if you're really that curious, i feel..."
    GR "...bien. si realmente tienes tanta curiosidad, me siento..."

# game/chapters/4_day.rpyc:1164
translate es day4_start2_083f7ee6:

    # GR "i am feeling just ..."
    GR "me siento simplemente..."

# game/chapters/4_day.rpyc:1167
translate es day4_start2_8491b1f0:

    # player "I'm just curious, I'm not actually worried."
    player "Solo tengo curiosidad, en realidad no me preocupa."

# game/chapters/4_day.rpyc:1168
translate es day4_start2_70fd34ab:

    # GR "right, of... course. that is the proper relationship between the hunter and his prey."
    GR "claro, por... supuesto. Esa es la relación adecuada entre el cazador y su presa."

# game/chapters/4_day.rpyc:1171
translate es day4_start2_03775ec8_3:

    # player "..."
    player "..."

# game/chapters/4_day.rpyc:1174
translate es day4_start2_2612dbf5:

    # player "Yup, totally don't care at all."
    player "Sep, no me importa en absoluto."

# game/chapters/4_day.rpyc:1175
translate es day4_start2_7772a27d_9:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:1178
translate es day4_start2_749647c3_1:

    # player ":)"
    player ":)"

# game/chapters/4_day.rpyc:1179
translate es day4_start2_946eb819:

    # GR "you know what, that isn't very nice."
    GR "sabes qué, eso no está bien."

# game/chapters/4_day.rpyc:1182
translate es day4_start2_b13da04a:

    # player "You just said it's how a proper relationship should be!"
    player "¡Acabas de decir que así es como debe ser una relación adecuada!"

# game/chapters/4_day.rpyc:1183
translate es day4_start2_7772a27d_10:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:1186
translate es day4_start2_3da7c9bd:

    # player ":("
    player ":("

# game/chapters/4_day.rpyc:1189
translate es day4_start2_c4a0808c:

    # player "Fine. I care a bit."
    player "Bien. Me importa un poco."

# game/chapters/4_day.rpyc:1190
translate es day4_start2_7772a27d_11:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:1191
translate es day4_start2_823ca811:

    # GR "then, if you're really that curious, i feel..."
    GR "entonces, si realmente tienes tanta curiosidad, creo que..."

# game/chapters/4_day.rpyc:1194
translate es day4_start2_7fe786d0:

    # player "...I'm kidding. I do kinda care."
    player "...Estoy bromeando. Me importa un poco."

# game/chapters/4_day.rpyc:1197
translate es day4_start2_adb76067:

    # player "So... are you back to normal, then?"
    player "Entonces... ¿ya estás de vuelta a la normalidad?"

# game/chapters/4_day.rpyc:1198
translate es day4_start2_90070961:

    # GR "i knew you cared about my welfare. you are a nosy and overly prying human, if nothing else."
    GR "sabía que te preocupabas por mi bienestar. eres una persona entrometida y curiosa, como mínimo."

# game/chapters/4_day.rpyc:1199
translate es day4_start2_7f1ef23a:

    # GR "always sticking your nose where it does not belong."
    GR "siempre metiendo las narices donde no te incumbe."

# game/chapters/4_day.rpyc:1202
translate es day4_start2_c64b010d:

    # player "OKAY you could leave it at 'caring and considerate'???"
    player "OKEY, ¿¿¿'Podrías dejarlo en persona 'atenta y considerada'???"

# game/chapters/4_day.rpyc:1203
translate es day4_start2_f4e475ec:

    # GR "a very invasive, stickybeak of a human, indeed."
    GR "Un humano muy invasivo, de hecho."

# game/chapters/4_day.rpyc:1204
translate es day4_start2_92d686e1:

    # GR "but since you are insatiably curious, i am feeling..."
    GR "pero como eres insaciablemente de curiosidad, me siento..."

# game/chapters/4_day.rpyc:1207
translate es day4_start2_c8e324d8:

    # player "I can nurse you back to health :D"
    player "Puedo cuidarte hasta que te recuperes :D"

# game/chapters/4_day.rpyc:1208
translate es day4_start2_52084b02:

    # GR "nurse me back to... don't be stupid."
    GR "cuidarme hasta que... no seas idiota."

# game/chapters/4_day.rpyc:1211
translate es day4_start2_fa072a7a:

    # player "That wasn't a no. You'd probably like it."
    player "Eso no fue un no. Probablemente te gustaría."

# game/chapters/4_day.rpyc:1214
translate es day4_start2_30aa75e4:

    # player "I could sit by your bedside and look after you."
    player "Podría sentarme junto a tu cama y cuidarte."

# game/chapters/4_day.rpyc:1215
translate es day4_start2_3f7dbeba:

    # GR "i... uh..."
    GR "yo... uh..."

# game/chapters/4_day.rpyc:1216
translate es day4_start2_d25e8aef:

    # GR "listen here..."
    GR "escucha..."

# game/chapters/4_day.rpyc:1217
translate es day4_start2_85b358ca:

    # GR "i can look after myself."
    GR "puedo cuidarme a mí mismo."

# game/chapters/4_day.rpyc:1220
translate es day4_start2_58f2f9b0:

    # player "I can't help but notice you didn't answer my question."
    player "No puedo evitar notar que no respondiste a mi pregunta."

# game/chapters/4_day.rpyc:1223
translate es day4_start2_fb4aea8e:

    # player "Which leads me to believe you would like it, actually."
    player "Lo que me lleva a creer que te gustaría, en realidad."

# game/chapters/4_day.rpyc:1226
translate es day4_start2_979a8957:

    # player "Perhaps a lot."
    player "Quizás mucho."

# game/chapters/4_day.rpyc:1227
translate es day4_start2_cc21bd84_1:

    # GR "!!!"
    GR "!!!"

# game/chapters/4_day.rpyc:1230
translate es day4_start2_bcbb8a8d:

    # player "No need to get overly excited."
    player "No hay necesidad de emocionarse demasiado."

# game/chapters/4_day.rpyc:1231
translate es day4_start2_22ce7d3d:

    # GR "why would i want that!?"
    GR "¡¿Por qué iba a querer eso?!"

# game/chapters/4_day.rpyc:1234
translate es day4_start2_483699bc:

    # player "Why? Because you like the idea of me doting on you, I guess."
    player "¿Por qué? Porque te gusta la idea de que te consienta, supongo."

# game/chapters/4_day.rpyc:1236
translate es day4_start2_a4014e86:

    # player "Because you are a babygirl and want me to dedicate all my time to you."
    player "Porque eres una babygirl y quieres que te dedique todo mi tiempo."

# game/chapters/4_day.rpyc:1237
translate es day4_start2_8d5abce0:

    # GR "i... i am doing fine. your assistance is not needed."
    GR "estoy... estoy bien. no necesito tu ayuda."

# game/chapters/4_day.rpyc:1238
translate es day4_start2_9f9917bd:

    # GR "there is no need to go to... unnecessary lengths..."
    GR "no hay necesidad de ir tan lejos..."

# game/chapters/4_day.rpyc:1241
translate es day4_start2_ab15d646:

    # player "The offer always stands :)"
    player "La oferta sigue en pie :)"

# game/chapters/4_day.rpyc:1244
translate es day4_start2_a7d764f7:

    # player "All you gotta do is ask me."
    player "Solo tienes que pedírmelo."

# game/chapters/4_day.rpyc:1245
translate es day4_start2_d7ec16a9:

    # GR "that will not happen."
    GR "eso no sucederá."

# game/chapters/4_day.rpyc:1246
translate es day4_start2_c30211c0:

    # GR "i..."
    GR "yo..."

# game/chapters/4_day.rpyc:1247
translate es day4_start2_6528caaa:

    # GR "nine hells, you are a confusing person."
    GR "nueve infiernos, eres una persona confusa."

# game/chapters/4_day.rpyc:1250
translate es day4_start2_bd1732d3:

    # player ":D"
    player ":D"

# game/chapters/4_day.rpyc:1253
translate es day4_start2_78411de2:

    # player "You're really cute, you know?"
    player "Eres realmente lindo, ¿sabes?"

# game/chapters/4_day.rpyc:1254
translate es day4_start2_6b35608d:

    # GR "how many times... i am not cute. i am not adorable."
    GR "por enésima vez... no soy lindo. no soy adorable."

# game/chapters/4_day.rpyc:1255
translate es day4_start2_8440797e:

    # GR "i am the literal figure of death itself and you should fear me."
    GR "soy, literalmente, la encarnación de la muerte misma, y deberías temerme."

# game/chapters/4_day.rpyc:1258
translate es day4_start2_da3b5b3b:

    # player "asdfghjkl."
    player "asdfghjkl."

# game/chapters/4_day.rpyc:1261
translate es day4_start2_dc8f1400:

    # player "You're blushing again, I bet."
    player "Te estás sonrojando de nuevo, apuesto."

# game/chapters/4_day.rpyc:1262
translate es day4_start2_d2817595:

    # GR "what."
    GR "qué."

# game/chapters/4_day.rpyc:1263
translate es day4_start2_0e4c93ef:

    # GR "what is that?"
    GR "¿qué es eso?"

# game/chapters/4_day.rpyc:1266
translate es day4_start2_9e706a1d:

    # player "What is what?"
    player "¿Qué es qué?"

# game/chapters/4_day.rpyc:1267
translate es day4_start2_b39e49a1:

    # GR "the random letters."
    GR "las letras aleatorias."

# game/chapters/4_day.rpyc:1270
translate es day4_start2_e5f3e021:

    # player "It's a keyboard smash."
    player "Es un golpe de teclado."

# game/chapters/4_day.rpyc:1271
translate es day4_start2_bb6ed376:

    # GR "why would you want to smash your keyboard?"
    GR "¿por qué desearías aplastar tu teclado?"

# game/chapters/4_day.rpyc:1274
translate es day4_start2_06b6a8aa:

    # player "No, stupid."
    player "No, estúpido."

# game/chapters/4_day.rpyc:1277
translate es day4_start2_e94fe32b:

    # player "You press keys on your keyboard to show that you're overcome with emotions."
    player "Presionas las teclas del teclado para mostrar que te embargan las emociones."

# game/chapters/4_day.rpyc:1280
translate es day4_start2_7a956181:

    # player "The amount and type of letter don't matter."
    player "La cantidad y el tipo de letras no importan."

# game/chapters/4_day.rpyc:1281
translate es day4_start2_2e782339:

    # GR "i see. it seems rather pointless."
    GR "ya veo. parece bastante inútil."

# game/chapters/4_day.rpyc:1284
translate es day4_start2_da66f61c:

    # player "It is."
    player "Lo es."

# game/chapters/4_day.rpyc:1287
translate es day4_start2_091a26cd:

    # player "Why don't you try?"
    player "¿Por qué no lo intentas?"

# game/chapters/4_day.rpyc:1288
translate es day4_start2_71940eba:

    # GR "p"
    GR "p"

# game/chapters/4_day.rpyc:1291
translate es day4_start2_faa0641e:

    # player "Huh?"
    player "¿Huh?"

# game/chapters/4_day.rpyc:1292
translate es day4_start2_6eeb4f45:

    # GR "that is my keyboard 'smash'."
    GR "este es mi 'golpe' de teclado."

# game/chapters/4_day.rpyc:1295
translate es day4_start2_b516d399:

    # player "Oh my god! Hahahaha!"
    player "¡Ay dios mío! ¡Jajajaja!"

# game/chapters/4_day.rpyc:1296
translate es day4_start2_0dccb036:

    # GR "what's so funny?"
    GR "¿qué es tan divertido?"

# game/chapters/4_day.rpyc:1299
translate es day4_start2_b8e73d70:

    # player "Why did you only do one letter?!"
    player "¡¿Por qué solo pusiste una letra?!"

# game/chapters/4_day.rpyc:1300
translate es day4_start2_03eb4eb3:

    # GR "you said the amount didn't matter."
    GR "dijiste que la cantidad no importaba."

# game/chapters/4_day.rpyc:1303
translate es day4_start2_57f1e8ea:

    # player "IT DOES IN THIS CASE."
    player "EN ESTE CASO, SÍ."

# game/chapters/4_day.rpyc:1304
translate es day4_start2_1799b0de:

    # GR "........."
    GR "........."

# game/chapters/4_day.rpyc:1307
translate es day4_start2_187cec5b:

    # player "Your mistakes are as cute as you."
    player "Tus errores son tan lindos como tú."

# game/chapters/4_day.rpyc:1308
translate es day4_start2_4d66b99e:

    # GR "stop talking to me. immediately."
    GR "deja de hablar conmigo. inmediatamente."

# game/chapters/4_day.rpyc:1311
translate es day4_start2_37bc4204:

    # player "Never."
    player "Nunca."

# game/chapters/4_day.rpyc:1312
translate es day4_start2_1fd99e1a:

    # GR "ugh."
    GR "ugh."

# game/chapters/4_day.rpyc:1313
translate es day4_start2_101414f3:

    # GR "for your information, by the way, i'm feeling..."
    GR "para tu información, por cierto, me siento..."

# game/chapters/4_day.rpyc:1317
translate es day4_start2_f1e5876c:

    # player "You're really timid sometimes."
    player "A veces eres realmente tímido."

# game/chapters/4_day.rpyc:1318
translate es day4_start2_5125381a_1:

    # GR "excuse me?"
    GR "¿disculpa?"

# game/chapters/4_day.rpyc:1321
translate es day4_start2_024d3f2d:

    # player "When you're shy, you act so timid."
    player "Cuando eres tímido, actúas con tanta timidez."

# game/chapters/4_day.rpyc:1324
translate es day4_start2_74045787:

    # player "It's not giving 'grim reaper' tbh."
    player "La verdad, no da una sensación de 'parca'."

# game/chapters/4_day.rpyc:1327
translate es day4_start2_0e2f3f4c:

    # player "It IS cute though."
    player "Sin embargo, ES lindo."

# game/chapters/4_day.rpyc:1328
translate es day4_start2_7726967c:

    # GR "you... you... you should mind your tongue in front of a person like me..."
    GR "tú... tú... deberías cuidar tu lengua frente a una persona como yo..."

# game/chapters/4_day.rpyc:1331
translate es day4_start2_aff2b5aa:

    # player "And miss out on your cute side? Nah."
    player "¿Y perderme tu lado adorable? Nah."

# game/chapters/4_day.rpyc:1334
translate es day4_start2_99b30b72:

    # player "Why would I ever do that?"
    player "¿Por qué haría yo eso?"

# game/chapters/4_day.rpyc:1337
translate es day4_start2_0bf0a83f:

    # player "I get such a kick out of your embarrassment, after all."
    player "Después de todo, me divierte mucho verte en una situación incómoda."

# game/chapters/4_day.rpyc:1338
translate es day4_start2_18809ddd:

    # GR "stop talking, lest i curse you myself."
    GR "deja de hablar, antes de que te maldiga yo mismo."

# game/chapters/4_day.rpyc:1341
translate es day4_start2_92803e47:

    # player "Wait, you can curse people?"
    player "Espera, ¿puedes maldecir a la gente?"

# game/chapters/4_day.rpyc:1342
translate es day4_start2_7772a27d_12:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:1345
translate es day4_start2_ef80e887:

    # player "That's not an answer!"
    player "¡Esa no es una respuesta!"

# game/chapters/4_day.rpyc:1346
translate es day4_start2_8aea6788:

    # GR "let's talk about something else."
    GR "hablemos de otra cosa."

# game/chapters/4_day.rpyc:1349
translate es day4_start2_94f967fe:

    # player "Nope. Tell me!"
    player "Nop. ¡Dime!"

# game/chapters/4_day.rpyc:1350
translate es day4_start2_0909f977:

    # GR "...i cannot curse people. there. are you happy?"
    GR "...no puedo maldecir a la gente. ya está. ¿estás feliz?"

# game/chapters/4_day.rpyc:1353
translate es day4_start2_eaba0a47:

    # player "Oh."
    player "Oh."

# game/chapters/4_day.rpyc:1356
translate es day4_start2_11b75391:

    # player "That's kinda lame. You could have pretended."
    player "Eso es un poco patético. Podrías haber fingido."

# game/chapters/4_day.rpyc:1357
translate es day4_start2_824b5c3e:

    # GR "i cannot lie, i cannot pretend."
    GR "no puedo mentir, no puedo fingir."

# game/chapters/4_day.rpyc:1360
translate es day4_start2_f8d66ff0:

    # player "You do keep saying that."
    player "Siempre dices lo mismo."

# game/chapters/4_day.rpyc:1361
translate es day4_start2_c28d934f:

    # GR "for good reason. like everything i say."
    GR "por una buena razón. como todo lo que digo."

# game/chapters/4_day.rpyc:1364
translate es day4_start2_c7d05982:

    # player "Okay then. Lets test it."
    player "Bien entonces. Vamos a probarlo."

# game/chapters/4_day.rpyc:1368
translate es day4_start2_9a271e10:

    # player "If you had to pick between drinking a cup full of...."
    player "Si tuvieras que elegir entre beber una taza llena de..."

# game/chapters/4_day.rpyc:1371
translate es day4_start2_861c4ed4:

    # player "Blended chillis or slightly off milk, which would you pick?"
    player "Chiles licuados o leche un poco pasada, ¿qué elegirías?"

# game/chapters/4_day.rpyc:1372
translate es day4_start2_7772a27d_13:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:1373
translate es day4_start2_a9f5804d:

    # GR "what kind of question is that?"
    GR "¿qué tipo de pregunta es esa?"

# game/chapters/4_day.rpyc:1374
translate es day4_start2_1f1ebf38:

    # GR "why do you want to know? why are both options terrible?"
    GR "¿por qué quieres saberlo? ¿por qué ambas opciones son terribles?"

# game/chapters/4_day.rpyc:1377
translate es day4_start2_d32a312e:

    # player "Well? What would you pick?"
    player "¿Bien? ¿Qué elegirías?"

# game/chapters/4_day.rpyc:1378
translate es day4_start2_5d364529_2:

    # GR "no."
    GR "no."

# game/chapters/4_day.rpyc:1379
translate es day4_start2_d3072853:

    # GR "neither."
    GR "ninguno de los dos."

# game/chapters/4_day.rpyc:1382
translate es day4_start2_425a3ab9:

    # player "That's not how this works!"
    player "¡No es así como funciona esto!"

# game/chapters/4_day.rpyc:1385
translate es day4_start2_f63be12b:

    # player "You have to pick one!"
    player "¡Tienes que elegir una!"

# game/chapters/4_day.rpyc:1386
translate es day4_start2_f6589691:

    # GR "i absolutely do not have to pick. both options are terrible. i would drink neither."
    GR "no tengo por qué elegir. las dos opciones son horribles. no bebería ninguna de las dos."

# game/chapters/4_day.rpyc:1389
translate es day4_start2_ef300f74:

    # player "I'd pick the chilli smoothie ;)"
    player "Yo elegiría el batido de chile ;)"

# game/chapters/4_day.rpyc:1390
translate es day4_start2_16dfcda2:

    # GR "you are daring, i will give you that."
    GR "tienes agallas, eso hay que reconocerlo."

# game/chapters/4_day.rpyc:1391
translate es day4_start2_911cd71d:

    # GR "but you are also an idiot."
    GR "pero también eres idiota."

# game/chapters/4_day.rpyc:1394
translate es day4_start2_bf2d58fb:

    # player "I'm strong. I'd go the milk."
    player "Soy fuerte. Yo elegiría la leche."

# game/chapters/4_day.rpyc:1395
translate es day4_start2_73f2bd6b:

    # GR "of course you would."
    GR "por supuesto que lo harías."

# game/chapters/4_day.rpyc:1396
translate es day4_start2_6b6bb9d9:

    # GR "the chillis would be terrible, but off milk..."
    GR "los chiles serían horribles, sin embargo, la leche..."

# game/chapters/4_day.rpyc:1397
translate es day4_start2_4881884d:

    # GR "i feel sick to my stomach just thinking about it."
    GR "Me da náuseas solo de pensarlo."

# game/chapters/4_day.rpyc:1398
translate es day4_start2_d771fdbf:

    # GR "yuck."
    GR "Puaj."

# game/chapters/4_day.rpyc:1401
translate es day4_start2_a6eb02d7:

    # player "So you really aren't going to pick one?"
    player "¿De verdad no vas a elegir uno?"

# game/chapters/4_day.rpyc:1402
translate es day4_start2_8abc9367:

    # GR "nope. i'm really not going to."
    GR "nop. realmente no voy a hacerlo."

# game/chapters/4_day.rpyc:1406
translate es day4_start2_80cfda34:

    # player "I suppose if you're unwell, either would make you feel worse."
    player "Supongo que si no te sientes bien, cualquiera de las dos cosas te haría sentir peor."

# game/chapters/4_day.rpyc:1409
translate es day4_start2_033151d4:

    # player "You never answered. Are you feeling better?"
    player "Nunca respondiste. ¿Te sientes mejor?"

# game/chapters/4_day.rpyc:1410
translate es day4_start2_03487944:

    # GR "i feel..."
    GR "me siento..."

# game/chapters/4_day.rpyc:1412
translate es day4_start2_81c0324b:

    # GR "great... actually..."
    GR "genial... en realidad..."

# game/chapters/4_day.rpyc:1413
translate es day4_start2_71b07389:

    # GR "which makes absolutely no sense. i have not rested, nor eaten, nor had a chance to meditate."
    GR "lo que no tiene ningún sentido. no he descansado, ni comido, ni tuve la oportunidad de meditar."

# game/chapters/4_day.rpyc:1414
translate es day4_start2_aeff4611:

    # GR "and i feel as good as new."
    GR "y me siento como nuevo."

# game/chapters/4_day.rpyc:1417
translate es day4_start2_aaa24f3c:

    # player "Well, sounds like good news to me."
    player "Bueno, me parece una buena noticia."

# game/chapters/4_day.rpyc:1418
translate es day4_start2_9a9342a2:

    # GR "it is confusing news. i do not like being confused."
    GR "es una noticia confusa. no me gusta estar confundido."

# game/chapters/4_day.rpyc:1419
translate es day4_start2_9ec6c5fb:

    # GR "i would prefer to feel unwell, and know why, than suddenly feel good and be left wondering how."
    GR "prefiero sentirme mal y saber por qué, que sentirme bien de repente y quedarme con la duda de cómo."

# game/chapters/4_day.rpyc:1422
translate es day4_start2_64ac9f2f:

    # player "Maybe my presence is healing for you <3"
    player "Quizás mi presencia te esté ayudando a sanar <3"

# game/chapters/4_day.rpyc:1423
translate es day4_start2_0d01acf4:

    # GR "if anything, your presence only hastens my tiredness."
    GR "en todo caso, tu presencia solo acelera mi cansancio."

# game/chapters/4_day.rpyc:1426
translate es day4_start2_7b5ff526:

    # player "Ouch."
    player "Auch."

# game/chapters/4_day.rpyc:1428
translate es day4_start2_1372e094:

    # player "Well, I suppose that's fair."
    player "Bueno, supongo que es justo."

# game/chapters/4_day.rpyc:1430
translate es day4_start2_f0568dff:

    # player "You do the same for me."
    player "Tú haces lo mismo por mí."

# game/chapters/4_day.rpyc:1432
translate es day4_start2_f2c73638:

    # player "You say that..."
    player "Dices eso..."

# game/chapters/4_day.rpyc:1435
translate es day4_start2_14428a2c:

    # player "But I know you don't mean it."
    player "Pero sé que no lo dices en serio."

# game/chapters/4_day.rpyc:1438
translate es day4_start2_8f4b4d95:

    # player "What made you unwell, anyway?"
    player "¿Qué te hizo sentir mal, de todos modos?"

# game/chapters/4_day.rpyc:1439
translate es day4_start2_7b2d2299:

    # GR "my soul was becoming unbalanced."
    GR "mi alma se estaba desequilibrando."

# game/chapters/4_day.rpyc:1442
translate es day4_start2_f79e3089:

    # player "A soul can do that?"
    player "¿Un alma puede hacer eso?"

# game/chapters/4_day.rpyc:1443
translate es day4_start2_13977b46:

    # GR "usually, no. but for a grim reaper, maintaining a balance is essential."
    GR "por lo general, no. pero para una parca, mantener el equilibrio es esencial."

# game/chapters/4_day.rpyc:1446
translate es day4_start2_2783206f:

    # player "What happens if you don't keep it balanced?"
    player "¿Qué pasa si no se mantiene el equilibrio?"

# game/chapters/4_day.rpyc:1447
translate es day4_start2_ba2ca8b4:

    # GR "you die."
    GR "mueres."

# game/chapters/4_day.rpyc:1450
translate es day4_start2_e8fb05bf:

    # player "A grim reaper can die?"
    player "¿Una parca puede morir?"

# game/chapters/4_day.rpyc:1451
translate es day4_start2_b76e168f:

    # GR "indeed. death comes to everyone, eventually."
    GR "en efecto. la muerte llega a todos, eventualmente."

# game/chapters/4_day.rpyc:1454
translate es day4_start2_90c3212a:

    # player "You're not immortal?"
    player "¿No eres inmortal?"

# game/chapters/4_day.rpyc:1456
translate es day4_start2_4f603fb1:

    # GR "i do not age, if that's what you're asking"
    GR "no envejezco, si es eso lo que estás preguntando."

# game/chapters/4_day.rpyc:1457
translate es day4_start2_bbbaf2d2:

    # GR "i cannot be killed under normal circumstances."
    GR "no puedo ser asesinado en circunstancias normales."

# game/chapters/4_day.rpyc:1458
translate es day4_start2_1f3e3ba5:

    # GR "but my soul can be corrupted with the taint or the light, and i will simply fade away."
    GR "pero mi alma puede corromperse con la oscuridad o con la luz, y simplemente me desvaneceré."

# game/chapters/4_day.rpyc:1461
translate es day4_start2_22af308d:

    # player "Wait, you're not already dead?"
    player "Espera, ¿no estás ya muerto?"

# game/chapters/4_day.rpyc:1462
translate es day4_start2_a49e8198:

    # GR "why would you assume im dead?"
    GR "¿por qué asumirías que estoy muerto?"

# game/chapters/4_day.rpyc:1465
translate es day4_start2_799f2220:

    # player "I just thought, since you represent death and stuff..."
    player "Solo pensé que, como representas a la muerte y esas cosas..."

# game/chapters/4_day.rpyc:1468
translate es day4_start2_3182bd94:

    # GR "the day we met you said that the grim reaper was a skeleton."
    GR "el día que nos conocimos dijiste que la Parca era un esqueleto."

# game/chapters/4_day.rpyc:1469
translate es day4_start2_57687c62:

    # GR "do i look like a skeleton?"
    GR "¿me veo como un esqueleto?"

# game/chapters/4_day.rpyc:1472
translate es day4_start2_ba104be0:

    # player "No..."
    player "No..."

# game/chapters/4_day.rpyc:1474
translate es day4_start2_04818bc5:

    # GR "if i did, then yes, you could say i was dead."
    GR "si así fuera, entonces sí, se podría decir que estoy muerto."

# game/chapters/4_day.rpyc:1475
translate es day4_start2_ba944754:

    # GR "but i do not, because i am alive."
    GR "pero no lo parezco, porque estoy vivo."

# game/chapters/4_day.rpyc:1476
translate es day4_start2_ae50dfc9:

    # GR "i believe, anyway."
    GR "al menos, eso creo."

# game/chapters/4_day.rpyc:1479
translate es day4_start2_2f9c8b53:

    # GR "my heart beats in my chest. i believe that is proof i am alive."
    GR "mi corazón late en mi pecho. creo que eso es prueba de que estoy vivo."

# game/chapters/4_day.rpyc:1482
translate es day4_start2_05a52271:

    # player "Plus the blood rushes to your face when you blush."
    player "Además, la sangre te sube a la cara cuando te sonrojas."

# game/chapters/4_day.rpyc:1485
translate es day4_start2_222ea172:

    # player "That's proof enough."
    player "Eso es prueba suficiente."

# game/chapters/4_day.rpyc:1487
translate es day4_start2_0badaf28:

    # GR "...ahem. so, yes, i am alive, but my soul can still be affected by the taint or the light."
    GR "...ejem. bueno, sí, estoy vivo, pero mi alma aún puede ser afectada por la oscuridad o la luz."

# game/chapters/4_day.rpyc:1490
translate es day4_start2_e667969f:

    # player "The taint?"
    player "¿La oscuridad?"

# game/chapters/4_day.rpyc:1493
translate es day4_start2_139f440f:

    # player "The light?"
    player "¿La luz?"

# game/chapters/4_day.rpyc:1494
translate es day4_start2_71ce80c1:

    # GR "you know too much already."
    GR "ya sabes demasiado."

# game/chapters/4_day.rpyc:1497
translate es day4_start2_ebf87441:

    # player "But you're just gonna take my soul anyway, right?"
    player "Pero vas a llevarte mi alma de todos modos, ¿verdad?"

# game/chapters/4_day.rpyc:1500
translate es day4_start2_f524ded1:

    # player "What does it matter if you tell me the truth?"
    player "¿Qué importa si me dices la verdad?"

# game/chapters/4_day.rpyc:1501
translate es day4_start2_7772a27d_14:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:1502
translate es day4_start2_f1572cc9:

    # GR "i... suppose. it may be somewhat nice to talk to someone about it."
    GR "yo... supongo. puede que sea agradable hablar con alguien sobre ello."

# game/chapters/4_day.rpyc:1505
translate es day4_start2_3de0276d:

    # player "I'm good at listening :)"
    player "Se me da bien escuchar :)"

# game/chapters/4_day.rpyc:1506
translate es day4_start2_a39d738f:

    # GR "also good at asking too many questions."
    GR "también se te da bien hacer demasiadas preguntas."

# game/chapters/4_day.rpyc:1507
translate es day4_start2_ad6c7f8d_1:

    # GR "fine."
    GR "bien."

# game/chapters/4_day.rpyc:1508
translate es day4_start2_da10ce9a:

    # GR "i must maintain a balance of light and dark in my own soul to continue my existence."
    GR "debo mantener un equilibrio entre luz y oscuridad en mi alma para continuar existiendo."

# game/chapters/4_day.rpyc:1509
translate es day4_start2_d806a83f:

    # GR "when i take a soul, i take on a part of its darkness."
    GR "Cuando tomo un alma, absorbo parte de su oscuridad."

# game/chapters/4_day.rpyc:1510
translate es day4_start2_832656ce:

    # GR "if their soul is difficult, it only worsens the effect on myself. this is the taint."
    GR "si su alma es difícil, solo empeora el efecto que tiene en mí. esa es la oscuridad."

# game/chapters/4_day.rpyc:1511
translate es day4_start2_b99f5ee9:

    # GR "when i spare someone, or spend too much time in the mortal realm, then my soul tips towards light."
    GR "cuando perdono a alguien o paso demasiado tiempo en el plano mortal, mi alma se inclina hacia la luz."

# game/chapters/4_day.rpyc:1512
translate es day4_start2_afb5a50e:

    # GR "in this case, a soul i took two days ago refused to move on to the afterlife, and it resulted in a struggle."
    GR "en este caso, un alma que recogí hace dos días se negó a pasar al más allá, lo que provocó una lucha."

# game/chapters/4_day.rpyc:1513
translate es day4_start2_2f3d87a7:

    # GR "the weight of that taint tilted my soul towards darkness."
    GR "el peso de esa mancha inclinó mi alma hacia la oscuridad."

# game/chapters/4_day.rpyc:1516
translate es day4_start2_a3bdee1e:

    # player "It sounds complicated."
    player "Suena complicado."

# game/chapters/4_day.rpyc:1518
translate es day4_start2_f76d0ca3:

    # player "I'm glad I don't have to do all of that to live."
    player "Me alegro de no tener que hacer todo eso para vivir."

# game/chapters/4_day.rpyc:1520
translate es day4_start2_64d89305:

    # GR "my continued survival is complicated, yes, but i have a handle on it."
    GR "mi supervivencia continua es complicada, sí, pero la tengo bajo control."

# game/chapters/4_day.rpyc:1521
translate es day4_start2_d057dd04:

    # GR "i have survived all of this time, after all."
    GR "después de todo, he sobrevivido todo este tiempo."

# game/chapters/4_day.rpyc:1525
translate es day4_start2_d87185ac:

    # player "I'm glad you're feeling better, then."
    player "Me alegro de que te sientas mejor, entonces."

# game/chapters/4_day.rpyc:1528
translate es day4_start2_89a16489:

    # player "At least you're okay now!"
    player "¡Al menos estás bien ahora!"

# game/chapters/4_day.rpyc:1530
translate es day4_start2_686d9468:

    # GR "my soul should not be balanced yet, but it is."
    GR "mi alma aún no debería estar en equilibrio, pero lo está."

# game/chapters/4_day.rpyc:1531
translate es day4_start2_fca7392e:

    # GR "ever since i linked our minds."
    GR "desde que vinculé nuestras mentes."

# game/chapters/4_day.rpyc:1534
translate es day4_start2_1955dd15:

    # player "I guess it was me after all :)"
    player "Supongo que fui yo después de todo :)"

# game/chapters/4_day.rpyc:1536
translate es day4_start2_e67f43df:

    # player "Fantastic work on my part."
    player "Fantástico trabajo de mi parte."

# game/chapters/4_day.rpyc:1538
translate es day4_start2_ba2304df:

    # player "Right, ever since we became one."
    player "Bien, desde que nos convertimos en uno."

# game/chapters/4_day.rpyc:1539
translate es day4_start2_be67a938:

    # GR "exactly."
    GR "exactamente."

# game/chapters/4_day.rpyc:1543
translate es day4_start2_4afbbede:

    # player "Wow. I didn't expect you to agree with me."
    player "Wow. No esperaba que estuvieras de acuerdo conmigo."

# game/chapters/4_day.rpyc:1544
translate es day4_start2_0669d89f:

    # GR "why would i not? for once, you said something reasonable."
    GR "¿por qué no lo haría? Por una vez, dijiste algo razonable."

# game/chapters/4_day.rpyc:1546
translate es day4_start2_bdc9548f:

    # GR "that is the truth. our minds combined, not fully, but enough."
    GR "esa es la verdad. nuestras mentes se unieron, no del todo, pero lo suficiente."

# game/chapters/4_day.rpyc:1547
translate es day4_start2_3fc9539e:

    # GR "you and i are connected now."
    GR "ahora tú y yo estamos conectados."

# game/chapters/4_day.rpyc:1551
translate es day4_start2_854142c7:

    # player "I can think of one or two other ways we could become one."
    player "Se me ocurren una o dos formas más en las que podríamos convertirnos en uno."

# game/chapters/4_day.rpyc:1552
translate es day4_start2_bcf22b7e:

    # GR "what would they be?"
    GR "¿cuáles serían?"

# game/chapters/4_day.rpyc:1556
translate es day4_start2_55f81d6b:

    # player "Oh, you actually wanna go there, huh."
    player "Oh, realmente quieres llegar a eso, huh"

# game/chapters/4_day.rpyc:1560
translate es day4_start2_5081c96d:

    # player "We could..."
    player "Podríamos..."

# game/chapters/4_day.rpyc:1564
translate es day4_start2_47428988:

    # player "Share clothes!"
    player "¡Compartir ropa!"

# game/chapters/4_day.rpyc:1565
translate es day4_start2_370b5205:

    # GR "share... clothes?"
    GR "¿compartir ...ropa?"

# game/chapters/4_day.rpyc:1566
translate es day4_start2_3a118496:

    # GR "you want to wear my clothes?"
    GR "¿quieres usar mi ropa?"

# game/chapters/4_day.rpyc:1570
translate es day4_start2_d5475f5e:

    # player "Honestly, yes."
    player "Honestamente, sí."

# game/chapters/4_day.rpyc:1571
translate es day4_start2_f4f29961:

    # GR "oh. well..."
    GR "oh. bueno..."

# game/chapters/4_day.rpyc:1572
translate es day4_start2_e7397ba9:

    # GR "i quite like yours, too."
    GR "también me gusta mucho la tuya."

# game/chapters/4_day.rpyc:1573
translate es day4_start2_b4f06109:

    # GR "if the situation occured where i had to wear them..."
    GR "si se diera el caso de que tuviera que ponérmela..."

# game/chapters/4_day.rpyc:1574
translate es day4_start2_831dfd19:

    # GR "i feel i could do it."
    GR "creo que podría hacerlo."

# game/chapters/4_day.rpyc:1575
translate es day4_start2_17b1d410:

    # GR "anyway. i cannot believe that the only reason i feel better is because of our link."
    GR "en fin. me cuesta creer que la razón por la que me siento mejor es por nuestro vínculo."

# game/chapters/4_day.rpyc:1578
translate es day4_start2_5ba30cc9:

    # player "They look cool, I can't lie."
    player "Se ve genial, lo admito."

# game/chapters/4_day.rpyc:1579
translate es day4_start2_d829e160:

    # GR "that would be because i am impossibly cool."
    GR "eso sería porque soy increíblemente genial."

# game/chapters/4_day.rpyc:1580
translate es day4_start2_29c81c1d:

    # GR "i fear if you wore the clothes, they would be much less cool. apologies."
    GR "me temo que si te pusieras esa ropa, no te quedaría tan bien. lo siento."

# game/chapters/4_day.rpyc:1581
translate es day4_start2_0814a22a:

    # GR "i believe the fantastic style comes from me directly."
    GR "creo que el estilo fantástico viene directamente de mí."

# game/chapters/4_day.rpyc:1582
translate es day4_start2_17b1d410_1:

    # GR "anyway. i cannot believe that the only reason i feel better is because of our link."
    GR "en fin. me cuesta creer que la razón por la que me siento mejor es por nuestro vínculo."

# game/chapters/4_day.rpyc:1585
translate es day4_start2_02676eb7:

    # player "Or we could just undress you-"
    player "O simplemente podríamos desvestirte-"

# game/chapters/4_day.rpyc:1586
translate es day4_start2_b45d4a1e:

    # GR "un... undress me?"
    GR "¿des... desvestirme?"

# game/chapters/4_day.rpyc:1587
translate es day4_start2_ffeae85c:

    # GR "why? then i would be cold. and naked."
    GR "¿por qué? entonces tendría frío. y estaría desnudo."

# game/chapters/4_day.rpyc:1588
translate es day4_start2_a6de612c:

    # GR "ah."
    GR "ah."

# game/chapters/4_day.rpyc:1589
translate es day4_start2_adfe8289:

    # GR "you mean to catch a glimpse of what is under my clothing."
    GR "quieres decir que deseas ver lo que hay debajo de mi ropa."

# game/chapters/4_day.rpyc:1590
translate es day4_start2_1ece5a4b:

    # GR "you are a very devious mortal."
    GR "eres un mortal muy retorcido."

# game/chapters/4_day.rpyc:1594
translate es day4_start2_ffedf631:

    # player "Maybe that is what I mean, maybe not ;)"
    player "Quizás eso es lo que quiero decir, quizás no ;)"

# game/chapters/4_day.rpyc:1595
translate es day4_start2_b4276293:

    # GR "hah..."
    GR "hah..."

# game/chapters/4_day.rpyc:1596
translate es day4_start2_48d9c6ea:

    # GR "well, it would be understandable, at least."
    GR "bueno, sería comprensible, al menos."

# game/chapters/4_day.rpyc:1597
translate es day4_start2_c48fc8c5:

    # GR "i have the body of a god. any who see it will perhaps die on the spot of envy."
    GR "tengo el cuerpo de un dios. quien que lo vea tal vez muera en el acto de envidia."

# game/chapters/4_day.rpyc:1601
translate es day4_start2_31975f5f:

    # player "That's one way to get my soul."
    player "Esa es una forma de conseguir mi alma."

# game/chapters/4_day.rpyc:1602
translate es day4_start2_f4a93908:

    # GR "if... if it has to come to that... so be it..."
    GR "si... si tiene que llegar a eso... que así sea..."

# game/chapters/4_day.rpyc:1603
translate es day4_start2_4e4044b0:

    # GR "but this is all beside the point. you cannot be the reason i suddenly feel better."
    GR "pero eso no viene al caso. tú no puedes ser la razón por la que me siento mejor."

# game/chapters/4_day.rpyc:1606
translate es day4_start2_846b0b10:

    # player "I bet you wouldn't mind a glimpse at me, either."
    player "Apuesto a que a ti tampoco te importaría mirarme."

# game/chapters/4_day.rpyc:1607
translate es day4_start2_f3b1f875:

    # GR "......"
    GR "......"

# game/chapters/4_day.rpyc:1608
translate es day4_start2_f9df28e2:

    # GR "i... legally do not have to answer that question and i have no clue what you're talking about."
    GR "yo... legalmente no tengo que responder a esa pregunta y no tengo ni idea de lo que estás hablando."

# game/chapters/4_day.rpyc:1609
translate es day4_start2_56d0174a:

    # GR "right. we were talking about me. souls, me, me being unwell."
    GR "cierto. estábamos hablando de mí. las almas, yo, mi malestar."

# game/chapters/4_day.rpyc:1610
translate es day4_start2_4ecc9032:

    # GR "not you being undressed in front of me. nope, never thought of that before."
    GR "no que te desnudes delante de mí. no, nunca se me había ocurrido eso antes."

# game/chapters/4_day.rpyc:1611
translate es day4_start2_235cb837:

    # GR "ahem. the... link we share... i doubt it is the reason i suddenly feel better."
    GR "ejem. el... vínculo que compartimos... dudo que sea la razón por la que me siento mejor."

# game/chapters/4_day.rpyc:1616
translate es day4_start2_da1b507b:

    # player "Hold hands ;)"
    player "Tomarnos de la mano ;)"

# game/chapters/4_day.rpyc:1617
translate es day4_start2_bc61142b:

    # GR "you wish to... hold my hand?"
    GR "¿quieres... tomarme de la mano?"

# game/chapters/4_day.rpyc:1618
translate es day4_start2_9df61a2f:

    # GR "i have never held hands with another person in my entire existence."
    GR "nunca en toda mi vida he tomado de la mano a otra persona."

# game/chapters/4_day.rpyc:1621
translate es day4_start2_c1737994:

    # player "We can take it nice and slow."
    player "Podemos tomárnoslo con calma."

# game/chapters/4_day.rpyc:1624
translate es day4_start2_85551f6c:

    # player "First I'll peel off your gloves, exposing the skin beneath."
    player "Primero te quitaré los guantes, dejando al descubierto la piel."

# game/chapters/4_day.rpyc:1627
translate es day4_start2_a1252e30:

    # player "I'll run my skin against yours, gently at first."
    player "Deslizaré mi piel contra la tuya, al principio con suavidad."

# game/chapters/4_day.rpyc:1631
translate es day4_start2_b9b40922:

    # player "Then clutch you tightly, using my thumb to rub you softly."
    player "Luego te sujetaré con fuerza y te acariciaré suavemente con el pulgar."

# game/chapters/4_day.rpyc:1632
translate es day4_start2_15bb51d3:

    # GR "this..."
    GR "esto..."

# game/chapters/4_day.rpyc:1633
translate es day4_start2_20908029:

    # GR "sounds almost..."
    GR "suena casi..."

# game/chapters/4_day.rpyc:1634
translate es day4_start2_5cf08565:

    # GR "more than hand holding..."
    GR "más que tomarse de las manos..."

# game/chapters/4_day.rpyc:1635
translate es day4_start2_41187a30:

    # GR "um."
    GR "um."

# game/chapters/4_day.rpyc:1636
translate es day4_start2_4b7989e9:

    # GR "not just anyone would get to do that, mortal."
    GR "no cualquiera podría hacer eso, mortal."

# game/chapters/4_day.rpyc:1637
translate es day4_start2_fa22a2c3:

    # GR "i have high standards. what makes you think you meet them?"
    GR "tengo estándares muy altos. ¿qué te hace pensar que los cumples?"

# game/chapters/4_day.rpyc:1641
translate es day4_start2_70d27be5:

    # player "Do I not?"
    player "¿Acaso no los cumplo?"

# game/chapters/4_day.rpyc:1642
translate es day4_start2_949f2162:

    # GR "......."
    GR "......."

# game/chapters/4_day.rpyc:1643
translate es day4_start2_980c7a7e:

    # GR ".............."
    GR ".............."

# game/chapters/4_day.rpyc:1644
translate es day4_start2_d9194bb6:

    # GR "you know, i was just thinking that i should go... uh... do some washing, or something."
    GR "Sabes, estaba pensando que debería irme... eh... a lavar la ropa o algo así."

# game/chapters/4_day.rpyc:1648
translate es day4_start2_14ee582a:

    # player "Running away, huh?"
    player "Huyendo, ¿eh?"

# game/chapters/4_day.rpyc:1651
translate es day4_start2_e94fe7e8:

    # player "I'd probably be better at holding hands than you, anyway. "
    player "Probablemente, se me daría mejor tomar manos que a ti, de todos modos. "

# game/chapters/4_day.rpyc:1653
translate es day4_start2_230dec51_1:

    # GR "...."
    GR "...."

# game/chapters/4_day.rpyc:1654
translate es day4_start2_ab8fb347:

    # GR "hah! i run away from nothing! i am the grim reaper!"
    GR "¡ja! ¡no huyo de nada! ¡soy la Parca!"

# game/chapters/4_day.rpyc:1655
translate es day4_start2_57fbcbbb:

    # GR "i will meet you head on."
    GR "te enfrentaré sin miedo."

# game/chapters/4_day.rpyc:1656
translate es day4_start2_adfbb2b3:

    # GR "fine. shall we ever meet, then perhaps i will hold your hand."
    GR "está bien. si alguna vez nos encontramos, tal vez te tome de la mano."

# game/chapters/4_day.rpyc:1657
translate es day4_start2_511a9de3:

    # GR "and i will show you that i'm the greatest hand holder in all the planes."
    GR "y te demostraré que soy el mejor tomador de manos de todos los niveles."

# game/chapters/4_day.rpyc:1658
translate es day4_start2_3223144a:

    # GR "but before that, i need to work out how i am suddenly better."
    GR "pero antes de eso, necesito averiguar por qué de repente me siento mejor."

# game/chapters/4_day.rpyc:1659
translate es day4_start2_20225f49:

    # GR "i doubt it is because of our connection."
    GR "dudo que sea por nuestra conexión."

# game/chapters/4_day.rpyc:1664
translate es day4_start2_c728c868:

    # player "I was trying to make you flustered, actually."
    player "En realidad, estaba tratando de ponerte nervioso."

# game/chapters/4_day.rpyc:1665
translate es day4_start2_edbbaf11:

    # GR "why would i..."
    GR "por qué iba yo a..."

# game/chapters/4_day.rpyc:1666
translate es day4_start2_3f7ad2f6_1:

    # GR "oh."
    GR "oh."

# game/chapters/4_day.rpyc:1667
translate es day4_start2_3c5a0c4c:

    # GR "we... have not become one like THAT."
    GR "nosotros... no nos hemos unido de ESA manera."

# game/chapters/4_day.rpyc:1671
translate es day4_start2_dc97478b:

    # player "Not yet, unfortunately."
    player "Todavía no, desafortunadamente."

# game/chapters/4_day.rpyc:1673
translate es day4_start2_7518af22:

    # player "You never know what will happen in the future."
    player "Nunca se sabe lo que sucederá en el futuro."

# game/chapters/4_day.rpyc:1675
translate es day4_start2_9492288e:

    # player "A shame, really."
    player "Una pena, de verdad."

# game/chapters/4_day.rpyc:1677
translate es day4_start2_97938765:

    # player "That's true."
    player "Eso es cierto."

# game/chapters/4_day.rpyc:1679
translate es day4_start2_d193ff8b:

    # GR "a... anyway... doing that together would make me... um.."
    GR "de... de todos modos... hacer eso juntos me haría sentir... um..."

# game/chapters/4_day.rpyc:1680
translate es day4_start2_752022e9:

    # GR "not better. i feel it would... throw me even more off balance..."
    GR "no mejor. siento que me desequilibraría aún más..."

# game/chapters/4_day.rpyc:1681
translate es day4_start2_1a45b7d7:

    # GR "THAT IS BESIDE THE POINT, HOWEVER."
    GR "PERO ESO NO VIENE AL CASO."

# game/chapters/4_day.rpyc:1682
translate es day4_start2_c6562311:

    # GR "the link we share cannot be the reason i feel better suddenly."
    GR "el vínculo que compartimos no puede ser la razón por la que me siento mejor."

# game/chapters/4_day.rpyc:1687
translate es day4_start2_4ecb5e1d:

    # GR "no. there must be another explanation, and i will find it."
    GR "no. debe haber otra explicación, y la encontraré."

# game/chapters/4_day.rpyc:1688
translate es day4_start2_f59ab4ad:

    # GR "later, though."
    GR "más tarde, eso sí."

# game/chapters/4_day.rpyc:1691
translate es day4_start2_2d46de8e:

    # player "By the way, I feel like I know the answer, but..."
    player "Por cierto, creo que sé la respuesta, pero..."

# game/chapters/4_day.rpyc:1693
translate es day4_start2_2c4283c6:

    # player "Actually, I had a question."
    player "De hecho, tenía una pregunta."

# game/chapters/4_day.rpyc:1696
translate es day4_start2_7785ea25:

    # player "Are you the reason such strange things keep happening to me every day?"
    player "¿Eres tú la razón por la que me siguen pasando cosas extrañas todos los días?"

# game/chapters/4_day.rpyc:1698
translate es day4_start2_9c3b0bb0:

    # GR "define strange."
    GR "define extraño."

# game/chapters/4_day.rpyc:1702
translate es day4_start2_3cbd8383:

    # player "Uh, where to begin..."
    player "Uh, por dónde empezar..."

# game/chapters/4_day.rpyc:1704
translate es day4_start2_ca5888f1:

    # player "There's a LOT."
    player "Hay MUCHAS cosas."

# game/chapters/4_day.rpyc:1707
translate es day4_start2_3bf21768:

    # player "Pianos falling from windows right in front of me?"
    player "¿Pianos cayendo por las ventanas justo delante de mí?"

# game/chapters/4_day.rpyc:1709
translate es day4_start2_10d94dc5:

    # player "Trains getting derailed?"
    player "¿Trenes descarrilándose?"

# game/chapters/4_day.rpyc:1711
translate es day4_start2_5948688d:

    # player "A fire at work?"
    player "¿Un incendio en el trabajo?"

# game/chapters/4_day.rpyc:1712
translate es day4_start2_e08d40f6:

    # GR "yes, that was me."
    GR "sí, ese era yo."

# game/chapters/4_day.rpyc:1715
translate es day4_start2_80333774:

    # player "Why...?"
    player "¿Por qué...?"

# game/chapters/4_day.rpyc:1717
translate es day4_start2_22b4d257:

    # GR "because i am trying to take your soul. you know this. i know you know this, so why play dumb?"
    GR "estoy tratando de robarte el alma. tú lo sabes. sé que lo sabes, así que ¿por qué finges ignorancia?"

# game/chapters/4_day.rpyc:1721
translate es day4_start2_02d8f7ee:

    # player "I just thought, you know..."
    player "Solo pensé, ya sabes..."

# game/chapters/4_day.rpyc:1724
translate es day4_start2_a1bacf3d:

    # player "A grim reaper would have a cooler way to take someone's soul."
    player "Una parca tendría una forma más fría de tomar el alma de alguien."

# game/chapters/4_day.rpyc:1726
translate es day4_start2_bf1d5ed7:

    # GR "i cannot simply take your soul before your human body dies. it is against the rules."
    GR "no puedo llevarme tu alma antes de que tu cuerpo humano muera. Va en contra de las reglas."

# game/chapters/4_day.rpyc:1727
translate es day4_start2_ec0a43f0:

    # GR "when it is your time, you will die, and then i will collect your soul from your dying body."
    GR "cuando llegue tu hora, morirás, y entonces yo recogeré tu alma de tu cuerpo moribundo."

# game/chapters/4_day.rpyc:1730
translate es day4_start2_4e6df062:

    # player "Then why try to kill me?"
    player "Entonces, ¿por qué intentar matarme?"

# game/chapters/4_day.rpyc:1733
translate es day4_start2_75f8ceac:

    # player "Why not wait for nature to take its course?"
    player "¿Por qué no esperar a que la naturaleza siga su curso?"

# game/chapters/4_day.rpyc:1734
translate es day4_start2_04269dbd:

    # GR "nature was meant to take its course with you years upon years ago."
    GR "la naturaleza debía seguir su curso contigo hace muchos años."

# game/chapters/4_day.rpyc:1735
translate es day4_start2_d4afbf8d:

    # GR "yet here you are."
    GR "sin embargo, aquí estás."

# game/chapters/4_day.rpyc:1738
translate es day4_start2_eaba0a47_1:

    # player "Oh."
    player "Oh."

# game/chapters/4_day.rpyc:1741
translate es day4_start2_464044b8:

    # player "So I'm supposed to be dead?"
    player "¿Entonces se supone que debía morir?"

# game/chapters/4_day.rpyc:1742
translate es day4_start2_ebc9eb7a_1:

    # GR "yes."
    GR "dí."

# game/chapters/4_day.rpyc:1745
translate es day4_start2_63df3777:

    # player "Says who?"
    player "¿Quién lo dice?"

# game/chapters/4_day.rpyc:1746
translate es day4_start2_a4d6cca6:

    # GR "says me, and the list i have with your name on it."
    GR "lo digo yo, y la lista que tengo con tu nombre en ella."

# game/chapters/4_day.rpyc:1749
translate es day4_start2_be109179:

    # player "Maybe it's someone else with the same name."
    player "Tal vez sea alguien más con el mismo nombre."

# game/chapters/4_day.rpyc:1750
translate es day4_start2_65a196f3:

    # GR "do you think we do not account for that?"
    GR "¿crees que no tenemos en cuenta eso?"

# game/chapters/4_day.rpyc:1753
translate es day4_start2_1760dd05:

    # player "I dunno."
    player "No se."

# game/chapters/4_day.rpyc:1755
translate es day4_start2_c0ee2943:

    # player "Knowing you, probably not."
    player "Conociéndote, probablemente no."

# game/chapters/4_day.rpyc:1758
translate es day4_start2_a96428dc:

    # player "It would just explain some things, wouldn't it?"
    player "Eso explicaría algunas cosas, ¿no?"

# game/chapters/4_day.rpyc:1759
translate es day4_start2_7772a27d_15:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:1760
translate es day4_start2_c0c04a9d:

    # GR "it would. "
    GR "lo haría."

# game/chapters/4_day.rpyc:1761
translate es day4_start2_8b7927d0:

    # GR "but it is not the case."
    GR "pero no es el caso."

# game/chapters/4_day.rpyc:1762
translate es day4_start2_dcb65984:

    # GR "you, [playerfirstname], are the person i desire above all else."
    GR "Tú, [playerfirstname], eres la persona que más deseo en el mundo."

# game/chapters/4_day.rpyc:1765
translate es day4_start2_ceadbdaf:

    # player "Desire?"
    player "¿Deseo?"

# game/chapters/4_day.rpyc:1766
translate es day4_start2_dd17e8ba:

    # GR "yes, i desire your soul."
    GR "sí, deseo tu alma."

# game/chapters/4_day.rpyc:1769
translate es day4_start2_0aa47e35:

    # player "Do you desire me in any other ways?"
    player "¿Me deseas de alguna otra manera?"

# game/chapters/4_day.rpyc:1770
translate es day4_start2_57f1038d:

    # GR "i desire your soul. i refuse to elaborate any further."
    GR "deseo tu alma. me niego a dar más detalles."

# game/chapters/4_day.rpyc:1773
translate es day4_start2_b93cbea5:

    # player "Is this a confession?"
    player "¿Eso es una confesión?"

# game/chapters/4_day.rpyc:1774
translate es day4_start2_c4d1ae26:

    # GR "it's a confession that i want your soul?"
    GR "¿es una confesión de que quiero tu alma?"

# game/chapters/4_day.rpyc:1775
translate es day4_start2_621aa064:

    # GR "further than that, i have no comment."
    GR "más allá de eso, no tengo comentarios."

# game/chapters/4_day.rpyc:1778
translate es day4_start2_f9eebe1d:

    # player "Does it have something to do with 'fate'?"
    player "¿Tiene algo que ver con el 'destino'?"

# game/chapters/4_day.rpyc:1779
translate es day4_start2_8a470577:

    # GR "yes. fate says you must die, and your continued existence goes against that."
    GR "sí. el destino dice que debes morir, y tu continua existencia va en contra de eso."

# game/chapters/4_day.rpyc:1782
translate es day4_start2_8078864a:

    # player "Well, maybe fate isn't so absolute, then."
    player "Bueno, tal vez el destino no sea tan absoluto, entonces."

# game/chapters/4_day.rpyc:1783
translate es day4_start2_80549845:

    # GR "you question the very foundations of this world."
    GR "cuestionas los fundamentos mismos de este mundo."

# game/chapters/4_day.rpyc:1786
translate es day4_start2_6d3bafcc:

    # player "I'm still here."
    player "Todavía estoy aquí."

# game/chapters/4_day.rpyc:1789
translate es day4_start2_9b78049b:

    # player "I'm alive."
    player "Sigo con vida."

# game/chapters/4_day.rpyc:1792
translate es day4_start2_e0fe0923:

    # player "If fate was absolute, I'd be dead right now."
    player "Si el destino fuera absoluto, ahora mismo estaría bajo tierra."

# game/chapters/4_day.rpyc:1793
translate es day4_start2_7772a27d_16:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:1794
translate es day4_start2_cd0359e0:

    # GR "what you say holds something to think about."
    GR "lo que dices da que pensar."

# game/chapters/4_day.rpyc:1797
translate es day4_start2_f06ddf2e:

    # player "Maybe we were supposed to meet."
    player "Quizás estábamos destinados a conocernos."

# game/chapters/4_day.rpyc:1798
translate es day4_start2_10850d35:

    # GR "supposed... to meet?"
    GR "¿destinados... a conocernos?"

# game/chapters/4_day.rpyc:1801
translate es day4_start2_b5c02a9b:

    # player "Yeah."
    player "Sí."

# game/chapters/4_day.rpyc:1804
translate es day4_start2_7a664050:

    # player "I was meant to die, and didn't."
    player "Estaba escrito que muriera, pero no fue así."

# game/chapters/4_day.rpyc:1807
translate es day4_start2_bc2dd1c0:

    # player "Thanks to that, we met."
    player ""

# game/chapters/4_day.rpyc:1810
translate es day4_start2_6f94abc6:

    # player "If anything is fate, perhaps that is."
    player "Si hay algo que sea destino, tal vez sea eso."

# game/chapters/4_day.rpyc:1811
translate es day4_start2_7772a27d_17:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:1812
translate es day4_start2_4d374817:

    # GR "if our fates were truly linked like that, you would only suffer."
    GR "si nuestros destinos estuvieran tan entrelazados, solo sufrirías."

# game/chapters/4_day.rpyc:1813
translate es day4_start2_f562874e:

    # GR "if i were you, i would pray that was not the case."
    GR "si fuera tú, rezaría para que no fuera así."

# game/chapters/4_day.rpyc:1816
translate es day4_start2_ef6eea8d:

    # player "Well, I'm happy to have met you."
    player "Bueno, estoy feliz de haberte conocido."

# game/chapters/4_day.rpyc:1819
translate es day4_start2_b8e63428:

    # player "Despite everything."
    player "A pesar de todo."

# game/chapters/4_day.rpyc:1820
translate es day4_start2_7820c210:

    # GR "...thanks."
    GR "...gracias."

# game/chapters/4_day.rpyc:1821
translate es day4_start2_c30211c0_1:

    # GR "i..."
    GR "yo..."

# game/chapters/4_day.rpyc:1822
translate es day4_start2_ee375810:

    # GR "nevermind. don't worry about it."
    GR "no importa. no te preocupes por eso."

# game/chapters/4_day.rpyc:1823
translate es day4_start2_4c85e693:

    # GR "you should just concentrate on the fact that i'm trying to kill you, okay?"
    GR "Deberías concentrarte en el hecho de que estoy tratando de matarte, ¿de acuerdo?"

# game/chapters/4_day.rpyc:1827
translate es day4_start2_e3d0561a:

    # player "So..."
    player "Entonces..."

# game/chapters/4_day.rpyc:1830
translate es day4_start2_6c245966:

    # player "You're really just trying to kill me in totally random ways."
    player "En realidad solo estás tratando de matarme de formas totalmente aleatorias."

# game/chapters/4_day.rpyc:1832
translate es day4_start2_ebc9eb7a_2:

    # GR "yes."
    GR "sí."

# game/chapters/4_day.rpyc:1836
translate es day4_start2_fb7756d7:

    # player "Is that how you usually do things?"
    player "¿Es así como sueles hacer las cosas?"

# game/chapters/4_day.rpyc:1838
translate es day4_start2_ec83fcff_1:

    # GR "of course not."
    GR "por supuesto que no."

# game/chapters/4_day.rpyc:1839
translate es day4_start2_22d01b32:

    # GR "like i said, nature usually takes its course."
    GR "como dije, la naturaleza generalmente toma su curso."

# game/chapters/4_day.rpyc:1840
translate es day4_start2_777158de:

    # GR "people die the way they are supposed to - the way they are destined to from the moment they are born."
    GR "las personas mueren, como se supone que deben morir, de la forma que están predestinadas desde que nacen."

# game/chapters/4_day.rpyc:1841
translate es day4_start2_38ae78e1:

    # GR "in your case, you need a bit of a push."
    GR "En tu caso, necesitas un pequeño empujón."

# game/chapters/4_day.rpyc:1844
translate es day4_start2_d7d8c022:

    # player "Has anyone else ever needed a bit of a push?"
    player "¿Alguien más ha necesitado alguna vez un pequeño empujón?"

# game/chapters/4_day.rpyc:1846
translate es day4_start2_5d364529_3:

    # GR "no."
    GR "no."

# game/chapters/4_day.rpyc:1847
translate es day4_start2_1379301d:

    # GR "it is just you."
    GR "solo tú."

# game/chapters/4_day.rpyc:1848
translate es day4_start2_cf0eb4a7:

    # GR "it has always been just you."
    GR "siempre has sido solo tú."

# game/chapters/4_day.rpyc:1852
translate es day4_start2_558b204a:

    # player "That almost sounds romantic."
    player "Eso casi suena romántico."

# game/chapters/4_day.rpyc:1853
translate es day4_start2_8fc08b05:

    # GR "in a way, i suppose it is."
    GR "en cierto modo, supongo que lo es."

# game/chapters/4_day.rpyc:1854
translate es day4_start2_ed6dd744:

    # GR "you are destined for me - i am the hunter, and you my prey."
    GR "estamos destinados -  yo soy el cazador y tú, mi presa."

# game/chapters/4_day.rpyc:1855
translate es day4_start2_8dcda06c:

    # GR "and we will be locked to one another until one of us wins."
    GR "y estaremos unidos el uno al otro hasta que uno de nosotros gane."

# game/chapters/4_day.rpyc:1856
translate es day4_start2_44961441:

    # GR "which will be me, of course."
    GR "que seré yo, por supuesto."

# game/chapters/4_day.rpyc:1858
translate es day4_start2_4610a5be:

    # player "I don't know how to feel about that..."
    player "No sé cómo sentirme al respecto..."

# game/chapters/4_day.rpyc:1859
translate es day4_start2_d1c45852:

    # GR "you are not the only person confused by our relationship."
    GR "no eres la única persona confundida por nuestra relación."

# game/chapters/4_day.rpyc:1860
translate es day4_start2_d9fae43f:

    # GR "it is unnatural. we are not two people meant to interact."
    GR "no es natural. no somos dos personas destinadas a interactuar."

# game/chapters/4_day.rpyc:1861
translate es day4_start2_32a41e0a:

    # GR "yet here we are."
    GR "sin embargo, aquí estamos."

# game/chapters/4_day.rpyc:1862
translate es day4_start2_a5ed9eb9:

    # GR "locked in a competition that i shall win."
    GR "encerrado en una competencia que voy a ganar."

# game/chapters/4_day.rpyc:1864
translate es day4_start2_c3b624ef:

    # player "Well, don't I feel special."
    player "Bueno, no me siento especial."

# game/chapters/4_day.rpyc:1865
translate es day4_start2_832758c0:

    # GR "you should."
    GR "deberíass."

# game/chapters/4_day.rpyc:1866
translate es day4_start2_6d3e2e08:

    # GR "you are the only human to capture my attention like so."
    GR "eres el único humano que ha captado mi atención de esta manera."

# game/chapters/4_day.rpyc:1869
translate es day4_start2_80805ce3_1:

    # player "Really?"
    player "¿En serio?"

# game/chapters/4_day.rpyc:1870
translate es day4_start2_ebc9eb7a_3:

    # GR "yes."
    GR "sí."

# game/chapters/4_day.rpyc:1871
translate es day4_start2_50aab093:

    # GR "you are a troublesome mortal, but you are special."
    GR "eres un mortal problemático, pero eres especial."

# game/chapters/4_day.rpyc:1872
translate es day4_start2_849a24b8:

    # GR "in ways neither of us understand..."
    GR "de maneras que ninguno de los dos entiende..."

# game/chapters/4_day.rpyc:1873
translate es day4_start2_31f91b36:

    # GR "but still, i will win this competition, and i will claim your soul."
    GR "pero aun así, ganaré esta competencia y reclamaré tu alma."

# game/chapters/4_day.rpyc:1874
translate es day4_start2_3ee9ee0d:

    # GR "even if it kills me in the process."
    GR "aunque me cueste la vida."

# game/chapters/4_day.rpyc:1875
translate es day4_start2_3ac10d2c:

    # GR "{image=grumpy}"
    GR "{image=grumpy}"

# game/chapters/4_day.rpyc:1879
translate es day4_start2_0877f0e7:

    # player "What the..."
    player "Qué demo..."

# game/chapters/4_day.rpyc:1881
translate es day4_start2_998f96ed:

    # player "Wait a second..."
    player "Espera un segundo..."

# game/chapters/4_day.rpyc:1884
translate es day4_start2_2199e280:

    # player "What is that?"
    player "¿Qué es eso?"

# game/chapters/4_day.rpyc:1885
translate es day4_start2_25be8cc6:

    # GR "it is me."
    GR "soy yo."

# game/chapters/4_day.rpyc:1888
translate es day4_start2_65238b4f:

    # player "Obviously! But where did it come from?"
    player "¡Obviamente! ¿Pero de dónde salió?"

# game/chapters/4_day.rpyc:1890
translate es day4_start2_9e7d115f:

    # player "And here I thought it was supposed to be me..."
    player "y yo que pensaba que se suponía que era yo..."

# game/chapters/4_day.rpyc:1894
translate es day4_start2_d4891b1b:

    # player "Obviously it's you! Where did it come from?"
    player "¡Obviamente eres tú! ¿De dónde salió?"

# game/chapters/4_day.rpyc:1896
translate es day4_start2_c316c753:

    # GR "i sent it."
    GR "lo envié."

# game/chapters/4_day.rpyc:1899
translate es day4_start2_2e8c7e70:

    # player "Did you... draw it yourself?"
    player "¿Lo dibujaste... tú mismo?"

# game/chapters/4_day.rpyc:1900
translate es day4_start2_631b8afb:

    # GR "what? do i look like i would have the time to draw?"
    GR "¿qué? ¿parece que tendría tiempo para dibujar?"

# game/chapters/4_day.rpyc:1903
translate es day4_start2_1c0dcdb3:

    # player "You have the time to message me."
    player "Tienes tiempo para enviarme mensajes."

# game/chapters/4_day.rpyc:1904
translate es day4_start2_4d850485:

    # GR "...that is a fair comment."
    GR "...es un comentario justo."

# game/chapters/4_day.rpyc:1905
translate es day4_start2_a2e5055a:

    # GR "no, i did not draw it. i... 'commissioned' a mortal artist."
    GR "no, yo no lo dibujé. yo... se lo 'comisioné' a un mortal artista."

# game/chapters/4_day.rpyc:1908
translate es day4_start2_612637b4:

    # player "You commissioned someone?"
    player "¿Lo encargaste a alguien?"

# game/chapters/4_day.rpyc:1909
translate es day4_start2_ebc9eb7a_4:

    # GR "yes."
    GR "sí."

# game/chapters/4_day.rpyc:1910
translate es day4_start2_b426e34d:

    # GR "do you see the likeness?"
    GR "¿ves el parecido?"

# game/chapters/4_day.rpyc:1913
translate es day4_start2_df60f2b4:

    # player "It's cute!"
    player "¡Es lindo!"

# game/chapters/4_day.rpyc:1914
translate es day4_start2_faf025c7:

    # GR "usually i would argue, however in this case, i believe cute is the right term."
    GR "Normalmente, diría que no, pero en este caso creo que lindo es el término adecuado."

# game/chapters/4_day.rpyc:1915
translate es day4_start2_ebcea0e2:

    # GR "it has compounded all of my handsomeness into a cute roundness."
    GR "logró resumir todo mi atractivo en una versión redondita."

# game/chapters/4_day.rpyc:1916
translate es day4_start2_4a4d7e3f:

    # GR "i tipped the artist, as they did a good job."
    GR "Le di propina al artista, ya que hizo un buen trabajo."

# game/chapters/4_day.rpyc:1918
translate es day4_start2_0c15523c:

    # player "It looks a little stupid."
    player "Se ve un poco tonto."

# game/chapters/4_day.rpyc:1921
translate es day4_start2_aaf6376e:

    # player "Like, it's really GOOD... but it's still your face."
    player "Es decir, está muy BIEN... pero sigue siendo tu cara."

# game/chapters/4_day.rpyc:1922
translate es day4_start2_d8954a14:

    # GR "what's that supposed to mean?"
    GR "¿qué se supone que significa eso?"

# game/chapters/4_day.rpyc:1925
translate es day4_start2_fc9af7ed:

    # player "I mean your face is a little stupid."
    player "Quiero decir que tu cara es un poco estúpida."

# game/chapters/4_day.rpyc:1926
translate es day4_start2_7772a27d_18:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:1927
translate es day4_start2_a8558ad0:

    # GR "this face is my pride and joy."
    GR "esta cara es mi orgullo y alegría."

# game/chapters/4_day.rpyc:1930
translate es day4_start2_d9181108:

    # player "Oh. Awkward..."
    player "Oh. Qué incómodo..."

# game/chapters/4_day.rpyc:1932
translate es day4_start2_1e17d1bc:

    # player "I want to squeeze its cheeks."
    player "Quiero apretar sus mejillas."

# game/chapters/4_day.rpyc:1935
translate es day4_start2_c0e8393b:

    # player "They're so round and cute!"
    player "¡Son tan redonditas y bonitas!"

# game/chapters/4_day.rpyc:1936
translate es day4_start2_011e95f0:

    # GR "hmph. tiny me wouldn't allow a mortal to squeeze his cheeks so easily."
    GR "hmph. el pequeño yo no permitiría que un mortal le apretara las mejillas."

# game/chapters/4_day.rpyc:1939
translate es day4_start2_366df32b:

    # player "What about normal sized you?"
    player "¿Y él de tamaño normal?"

# game/chapters/4_day.rpyc:1940
translate es day4_start2_218f9b3f:

    # GR "i... what makes you think i would accept that?"
    GR "yo... ¿qué te hace pensar que aceptaría eso?"

# game/chapters/4_day.rpyc:1943
translate es day4_start2_7ceb35d2:

    # player "You seem like the kind of guy who would like it."
    player "Pareces el tipo de persona a la que le gustaría eso."

# game/chapters/4_day.rpyc:1944
translate es day4_start2_b5c1b9e1:

    # GR "perhaps i would. from you? i cannot say."
    GR "quizás sí. ¿por ti? no sabría decirlo."

# game/chapters/4_day.rpyc:1947
translate es day4_start2_bb9015c6:

    # player "Anyway... you just sent a human a photo of yourself?"
    player "De todos modos... ¿acabas de enviarle una foto tuya a un humano?"

# game/chapters/4_day.rpyc:1949
translate es day4_start2_ca423172:

    # GR "how else would they capture my likeness?"
    GR "¿De qué otra manera podrían capturar mi imagen?"

# game/chapters/4_day.rpyc:1953
translate es day4_start2_481ddff6:

    # player "It's not against your grim reaper rules?"
    player "¿No va en contra de tus reglas de la Parca?"

# game/chapters/4_day.rpyc:1955
translate es day4_start2_1c6ce16a:

    # GR "whether it is or not does not matter."
    GR "da igual si lo es o no."

# game/chapters/4_day.rpyc:1958
translate es day4_start2_21742c99:

    # player "So it is."
    player "Así que lo es."

# game/chapters/4_day.rpyc:1960
translate es day4_start2_bfbf766e:

    # GR "...perhaps."
    GR "...tal vez."

# game/chapters/4_day.rpyc:1961
translate es day4_start2_9cfc94d7:

    # GR "however, bending the rules is sometimes necessary."
    GR "sin embargo, a veces es necesario saltarse las reglas."

# game/chapters/4_day.rpyc:1964
translate es day4_start2_b7f49ca1:

    # player "Are you bending the rules by talking to me?"
    player "¿Estás infringiendo las reglas al hablar conmigo?"

# game/chapters/4_day.rpyc:1965
translate es day4_start2_7772a27d_19:

    # GR "..."
    GR "..."

# game/chapters/4_day.rpyc:1966
translate es day4_start2_4ece116c:

    # GR "you are clever, [playerfirstname!l]. sometimes too clever."
    GR "eres inteligente, [playerfirstname!l]. a veces demasiado inteligente."

# game/chapters/4_day.rpyc:1967
translate es day4_start2_a58153e1:

    # GR "yes. i am forbidden from speaking to mortals, let alone one whose soul i seek."
    GR "sí. tengo prohibido hablar con los mortales, y mucho menos con aquel cuya alma busco."

# game/chapters/4_day.rpyc:1971
translate es day4_start2_0f15e30d:

    # player "Breaking all the rules for me then, huh?"
    player "¿Rompiendo todas las reglas por mí, eh?"

# game/chapters/4_day.rpyc:1973
translate es day4_start2_b2490fb2:

    # GR "for you? don't be ridiculous."
    GR "¿por ti? no digas tonterías."

# game/chapters/4_day.rpyc:1974
translate es day4_start2_e75564d1:

    # GR "i've broken them only for myself."
    GR "solo las he infringido para mí mismo."

# game/chapters/4_day.rpyc:1978
translate es day4_start2_44331dfa:

    # player "Wow, breaking my heart over here."
    player "Wow, me estás rompiendo el corazón."

# game/chapters/4_day.rpyc:1979
translate es day4_start2_a91e625a:

    # GR "good. you shouldn't fool yourself into believing things that simply cannot be true."
    GR "bien. no deberías engañarte creyendo cosas que simplemente no pueden ser ciertas."

# game/chapters/4_day.rpyc:1982
translate es day4_start2_4725caa4:

    # player "What if I tell on you?"
    player "¿Y si te delato?"

# game/chapters/4_day.rpyc:1983
translate es day4_start2_dc005941:

    # GR "tell who?"
    GR "¿a quién?"

# game/chapters/4_day.rpyc:1987
translate es day4_start2_6d012a45:

    # player "Your boss!"
    player "¡A tu jefe!"

# game/chapters/4_day.rpyc:1991
translate es day4_start2_6b0b6eae:

    # player "You have a boss, right?"
    player "Tienes un jefe, ¿verdad?"

# game/chapters/4_day.rpyc:1993
translate es day4_start2_3c0d3f50:

    # GR "and how would you get in contact with this hypothetical boss?"
    GR "¿y cómo te pondrías en contacto con este jefe hipotético?"

# game/chapters/4_day.rpyc:1997
translate es day4_start2_1b11c07a:

    # player "I could start by programming a strange app and installing it on their computer..."
    player "Podría empezar por programar una aplicación extraña e instalarla en su computadora..."

# game/chapters/4_day.rpyc:1999
translate es day4_start2_b83bf754:

    # GR "hah! you cannot even come up with your own plan!"
    GR "¡ja! ¡ni siquiera eres capaz de idear tu propio plan!"

# game/chapters/4_day.rpyc:2003
translate es day4_start2_979456ce:

    # player "I'm doing it rn."
    player "Lo estoy haciendo ahora mismo."

# game/chapters/4_day.rpyc:2006
translate es day4_start2_c37f8527:

    # player "It's installing."
    player "Se está instalando."

# game/chapters/4_day.rpyc:2008
translate es day4_start2_4feebc8f:

    # GR "hey, wait a second-"
    GR "oye, espera un segundo-"

# game/chapters/4_day.rpyc:2012
translate es day4_start2_9972da14:

    # player "Nearly done. Any second now..."
    player "Ya casi termino. En cualquier momento..."

# game/chapters/4_day.rpyc:2014
translate es day4_start2_7be28c75:

    # GR "wait, don't..."
    GR "espera, no..."

# game/chapters/4_day.rpyc:2015
translate es day4_start2_d4739def:

    # GR "think for a second about what you're doing!"
    GR "¡piensa por un segundo en lo que estás haciendo!"

# game/chapters/4_day.rpyc:2016
translate es day4_start2_3d818681:

    # GR "i... would be in immense trouble. forget getting fired, i'd just be killed!"
    GR "yo... sería un problema enorme. olvídate del despido, ¡simplemente me matarían!"

# game/chapters/4_day.rpyc:2020
translate es day4_start2_dbd8b791:

    # player "It's installed."
    player "Está instalada."

# game/chapters/4_day.rpyc:2023
translate es day4_start2_9a626a5c:

    # player "I'm starting to write them a message..."
    player "Estoy empezando a escribirles un mensaje..."

# game/chapters/4_day.rpyc:2025
translate es day4_start2_926762e3:

    # GR "wait!"
    GR "¡espera!"

# game/chapters/4_day.rpyc:2026
translate es day4_start2_64e89aff:

    # GR "p... please? i mean, i know im trying to have you die, but you wouldn't want ME to die, would you?"
    GR "¿por... por favor?. lo sé, estoy intentando que mueras, pero tú no quieres que YO muera, ¿verdad?"

# game/chapters/4_day.rpyc:2030
translate es day4_start2_1b98eb03:

    # player "Well..."
    player "Bueno..."

# game/chapters/4_day.rpyc:2034
translate es day4_start2_26ac2e74:

    # player "I suppose I could just uninstall it..."
    player "Supongo que podría desinstalarla..."

# game/chapters/4_day.rpyc:2035
translate es day4_start2_6572996a:

    # GR "thank GOD."
    GR "gracias a DIOS."

# game/chapters/4_day.rpyc:2038
translate es day4_start2_17b3670f:

    # player "For my little meowmeow, I guess I can stop..."
    player "Por mi pequeño miaumiau, supongo que puedo parar..."

# game/chapters/4_day.rpyc:2039
translate es day4_start2_804dd518:

    # GR "your little what...?"
    GR "tu pequeño que...?"

# game/chapters/4_day.rpyc:2040
translate es day4_start2_9a155274:

    # GR "you know what, fine. for this, i can be your little meowmeow(?)."
    GR "¿sabes qué? está bien. por esto, puedo ser tu pequeño miaumiau(?)."

# game/chapters/4_day.rpyc:2044
translate es day4_start2_cdf2f46b:

    # player "btw I never installed anything in the first place."
    player "Por cierto, nunca instalé nada en primer lugar."

# game/chapters/4_day.rpyc:2045
translate es day4_start2_f1783249:

    # GR "........what?"
    GR "........¿qué?"

# game/chapters/4_day.rpyc:2046
translate es day4_start2_1fd99e1a_1:

    # GR "ugh."
    GR "ugh."

# game/chapters/4_day.rpyc:2047
translate es day4_start2_0f05ff38:

    # GR "mortal, you will know true suffering one of these days."
    GR "mortal, algún día conocerás el verdadero sufrimiento"

# game/chapters/4_day.rpyc:2048
translate es day4_start2_cbc49cae:

    # GR "you will know how i feel."
    GR "sabrás cómo me siento."

# game/chapters/4_day.rpyc:2049
translate es day4_start2_c2dbd5c8:

    # GR "you will trick this reaper no longer..."
    GR "ya no engañarás más a esta parca..."

# game/chapters/4_day.rpyc:2052
translate es day4_start2_05802fc2:

    # player "But back to that cute little chibi..."
    player "Pero volvamos a ese pequeño y adorable chibi..."

# game/chapters/4_day.rpyc:2057
translate es day4_start2_8ea10288:

    # player "So you have that blushing emote..."
    player "Así que tienes ese emote de sonrojo..."

# game/chapters/4_day.rpyc:2060
translate es day4_start2_3195d932:

    # player "Is there any more?"
    player "¿Hay más?"

# game/chapters/4_day.rpyc:2062
translate es day4_start2_7db3583a:

    # GR "i have received a few, depicting a wide range of emotions."
    GR "he recibido algunos, que representan una amplia gama de emociones."

# game/chapters/4_day.rpyc:2066
translate es day4_start2_bb09ac9f:

    # player ":o"
    player ":o"

# game/chapters/4_day.rpyc:2069
translate es day4_start2_5419cace:

    # player "Did you pose when you took the photos?"
    player "¿Posaste cuando te sacaste las fotos?"

# game/chapters/4_day.rpyc:2071
translate es day4_start2_a9641317:

    # GR "naturally. how else would the mortal have been able to capture such beauty?"
    GR "naturalmente. ¿de qué otra forma habría podido ese mortal capturar tanta belleza?"

# game/chapters/4_day.rpyc:2075
translate es day4_start2_62780478:

    # player "OMG!"
    player "¡DIOS MÍO!"

# game/chapters/4_day.rpyc:2078
translate es day4_start2_40cb3cdd:

    # player "Then that means..."
    player "Entonces eso significa..."

# game/chapters/4_day.rpyc:2081
translate es day4_start2_05f1a043:

    # player "Oh, that's just hilarious."
    player "Oh, eso es muy gracioso."

# game/chapters/4_day.rpyc:2084
translate es day4_start2_4419fabf:

    # player "Then you actually... wow, this is making my day."
    player "Entonces, en realidad... wow, esto me está alegrando el día."

# game/chapters/4_day.rpyc:2087
translate es day4_start2_959bedac:

    # player "Fantastic."
    player "Fantástico."

# game/chapters/4_day.rpyc:2090
translate es day4_start2_3a062bb4:

    # player "They truly got your good side."
    player "Realmente captaron tu mejor lado."

# game/chapters/4_day.rpyc:2093
translate es day4_start2_bb0f0fa1:

    # player "But wait a second..."
    player "Pero espera un momento..."

# game/chapters/4_day.rpyc:2096
translate es day4_start2_edde59a2:

    # player "I'm almost jealous."
    player "Casi siento celos."

# game/chapters/4_day.rpyc:2099
translate es day4_start2_55e5a41f:

    # player "Do you have a folder of secret selfies you've taken somewhere, Grim?"
    player "¿Tienes una carpeta con selfies secretas que te has tomado en algún lugar, Parca?"

# game/chapters/4_day.rpyc:2100
translate es day4_start2_03a3b6cb:

    # GR "secret selfies..."
    GR "selfies secretas..."

# game/chapters/4_day.rpyc:2101
translate es day4_start2_5a136912:

    # GR "if by that you mean pictures of myself, then of course i do."
    GR "si te refieres a fotos mías, entonces sí, por supuesto."

# game/chapters/4_day.rpyc:2102
translate es day4_start2_d0b8aa07:

    # GR "i am quite charming, after all. very photogenic, as well."
    GR "después de todo, soy bastante encantador. y también muy fotogénico."

# game/chapters/4_day.rpyc:2105
translate es day4_start2_38df18c0:

    # player "Wait, seriously?"
    player "Espera, ¿en serio?"

# game/chapters/4_day.rpyc:2108
translate es day4_start2_69eb4117:

    # player "Hold on... you said you posed for them, right?"
    player "Espera... dijiste que posaste para esa persona, ¿verdad?"

# game/chapters/4_day.rpyc:2109
translate es day4_start2_c5eebdad:

    # GR "i literally just told you that i did."
    GR "literalmente te acabo de decir que lo hice."

# game/chapters/4_day.rpyc:2112
translate es day4_start2_ca6d099b:

    # player "Then that means you..."
    player "Entonces eso significa que..."

# game/chapters/4_day.rpyc:2115
translate es day4_start2_9edb757d:

    # player "Hehe."
    player "Jeje."

# game/chapters/4_day.rpyc:2116
translate es day4_start2_b2766aa4_1:

    # GR "???"
    GR "???"

# game/chapters/4_day.rpyc:2117
translate es day4_start2_8ede3c01_1:

    # GR "what?"
    GR "¿qué?"

# game/chapters/4_day.rpyc:2118
translate es day4_start2_d6d84808:

    # GR "what are you so excited about?"
    GR "¿qué te emociona tanto?"

# game/chapters/4_day.rpyc:2121
translate es day4_start2_5b29be12:

    # player "You pouted in the picture?"
    player "¿Hiciste pucheros en la foto?"

# game/chapters/4_day.rpyc:2124
translate es day4_start2_663f68a2:

    # player "You should have sent it to me!"
    player "¡Deberías habérmelo enviado!"

# game/chapters/4_day.rpyc:2126
translate es day4_start2_aa2ad077:

    # GR "... why would i send that to you?"
    GR "... ¿por qué te enviaría eso?"

# game/chapters/4_day.rpyc:2132
translate es day4_start2_339e34ed:

    # player "You do remember that I work as an artist full time right?"
    player "¿Recuerdas que trabajo como artista a tiempo completo, verdad?"

# game/chapters/4_day.rpyc:2135
translate es day4_start2_4520012e:

    # player "I could have drawn it for you. For free, even."
    player "Podría habértelo dibujado. Incluso gratis."

# game/chapters/4_day.rpyc:2138
translate es day4_start2_d9ffea63:

    # player "Definitely not trying to convince you not to take my soul here."
    player "No estoy tratando de convencerte de que no te lleves mi alma aquí."

# game/chapters/4_day.rpyc:2139
translate es day4_start2_7e215605:

    # GR "i would not ask that of you."
    GR "no te pediría eso."

# game/chapters/4_day.rpyc:2140
translate es day4_start2_a94b2f6e:

    # GR "even a mortal deserves to be paid for labor."
    GR "incluso un mortal merece que se le pague por su trabajo."

# game/chapters/4_day.rpyc:2143
translate es day4_start2_8c81f949:

    # player "Oh, that's surprising coming from you."
    player "Oh, eso es sorprendente viniendo de ti."

# game/chapters/4_day.rpyc:2146
translate es day4_start2_13d01b61:

    # player "Still, my talents are at your command :)"
    player "Aun así, mis talentos están a tu disposición :)"

# game/chapters/4_day.rpyc:2147
translate es day4_start2_62d1d9bc:

    # GR "i will keep it in mind for next time i need an artist."
    GR "lo tendré en cuenta para la próxima vez que necesite un artista."

# game/chapters/4_day.rpyc:2148
translate es day4_start2_d46103d5:

    # GR "if there is a next time in the few days you have left on this plane of existence."
    GR "si hay una próxima vez en los pocos días que te quedan en este plano de existencia."

# game/chapters/4_day.rpyc:2151
translate es day4_start2_79beaf49:

    # player "So, can I see the photo?"
    player "Entonces, ¿puedo ver la foto?"

# game/chapters/4_day.rpyc:2152
translate es day4_start2_9fd9a76d:

    # GR "why?"
    GR "¿por qué?"

# game/chapters/4_day.rpyc:2156
translate es day4_start2_ca5f2173:

    # player "Because I want to see it! "
    player "¡Porque quiero verla!"

# game/chapters/4_day.rpyc:2158
translate es day4_start2_0f9746f6:

    # player "Your little pouty blush... cute."
    player "Tu puchero y tus mejillas sonrojadas... qué lindo."

# game/chapters/4_day.rpyc:2160
translate es day4_start2_0a41d77e:

    # player "So I can add it to my collection ;)"
    player "Para poder añadirlo a mi colección ;)"

# game/chapters/4_day.rpyc:2163
translate es day4_start2_47336bf8:

    # player "Oh, you know what?"
    player "Oh, ¿sabes qué?"

# game/chapters/4_day.rpyc:2166
translate es day4_start2_71d1dabf:

    # player "Once again, I am proving to be an excellent problem solver."
    player "Una vez más, estoy demostrando ser excelente resolviendo problemas."

# game/chapters/4_day.rpyc:2169
translate es day4_start2_2ca0d562:

    # player "Make sure you pick up, okay?"
    player "Asegúrate de contestar, ¿de acuerdo?"

# game/chapters/4_day.rpyc:2201
translate es call1_day4_0abed86d:

    # GRC "You are getting rather demanding, mortal."
    GRC "te estás volviendo bastante exigente, mortal."

# game/chapters/4_day.rpyc:2218
translate es call1_day4_eeb77df2:

    # GRC "Excuse me?"
    GRC "¿Disculpa?"

# game/chapters/4_day.rpyc:2223
translate es call1_day4_6eed491a:

    # GRC "What? No."
    GRC "¿Qué? No."

# game/chapters/4_day.rpyc:2233
translate es call1_day4_a4eca026:

    # GRC "I will not."
    GRC "No lo haré."

# game/chapters/4_day.rpyc:2247
translate es call1_day4_7d9827ae:

    # GRC "You called me... for this? You called the literal Grim Reaper... to see him pout?"
    GRC "¿Me llamaste... para esto? ¿Llamaste a la mismísima Parca... para verla hacer pucheros?"

# game/chapters/4_day.rpyc:2265
translate es call1_day4_0ca48b94:

    # GRC "Will you now?"
    GRC "¿De verdad?"

# game/chapters/4_day.rpyc:2266
translate es call1_day4_74dbd1a6:

    # GRC "Go on, then."
    GRC "Adelante, entonces."

# game/chapters/4_day.rpyc:2274
translate es call1_day4_8da23161:

    # GRC "...."
    GRC "...."

# game/chapters/4_day.rpyc:2276
translate es call1_day4_9566222c:

    # GRC "Cute..."
    GRC "Qué adorable..."

# game/chapters/4_day.rpyc:2283
translate es call1_day4_e0372c17:

    # GRC "Maybe I said you're ugly."
    GRC "Quizás te dije que te ves mal."

# game/chapters/4_day.rpyc:2289
translate es call1_day4_e233ed40:

    # GRC "Did I? You must have heard incorrectly."
    GRC "¿Lo hice? Debes haber escuchado mal."

# game/chapters/4_day.rpyc:2290
translate es call1_day4_abefdf06:

    # GRC "Maybe try cleaning out your ears."
    GRC "Tal vez deberías limpiarte los oídos."

# game/chapters/4_day.rpyc:2302
translate es call1_day4_81cffa96:

    # GRC "What is that supposed to be?"
    GRC "¿Qué se supone que es eso?"

# game/chapters/4_day.rpyc:2303
translate es call1_day4_f96d78fa:

    # GRC "You look like you've been hit in the face with a bat."
    GRC "Parece que te hubieran golpeado en la cara con un bate."

# game/chapters/4_day.rpyc:2312
translate es call1_day4_eb2ad629:

    # GRC "I'm judging you. Stop pulling that face."
    GRC "Te estoy juzgando. Deja de poner esa cara."

# game/chapters/4_day.rpyc:2317
translate es call1_day4_e6f8b846:

    # GRC "Ugh."
    GRC "Ugh."

# game/chapters/4_day.rpyc:2326
translate es call1_day4_6fcd81b0:

    # GRC "What are you doing? Why is your face contorting like that?"
    GRC "¿Qué estás haciendo? ¿Por qué tienes esa cara tan rara?"

# game/chapters/4_day.rpyc:2327
translate es call1_day4_912c0c0c:

    # GRC "Stop it."
    GRC "Basta."

# game/chapters/4_day.rpyc:2337
translate es call1_day4_f726263c:

    # GRC "You're trying to be ME?"
    GRC "¿Estás tratando de ser YO?"

# game/chapters/4_day.rpyc:2342
translate es call1_day4_997a6b3e:

    # GRC "Hah!"
    GRC "¡Ja!"

# game/chapters/4_day.rpyc:2343
translate es call1_day4_3b44bcef:

    # GRC "Mortal, your attempts are futile."
    GRC "Mortal, tus intentos son inútiles."

# game/chapters/4_day.rpyc:2345
translate es call1_day4_eb84add0:

    # GRC "No one in existence can replicate me."
    GRC "Nadie en el mundo puede imitarme."

# game/chapters/4_day.rpyc:2354
translate es call1_day4_8da23161_1:

    # GRC "...."
    GRC "...."

# game/chapters/4_day.rpyc:2356
translate es call1_day4_f3102b23:

    # GRC "I'm... I'm too handsome, charismatic and smart for a mortal to imitate me."
    GRC "Soy... Soy demasiado guapo, carismático e inteligente para que un mortal me imite."

# game/chapters/4_day.rpyc:2364
translate es call1_day4_0a2b1fe2:

    # GRC "I do not sound like that."
    GRC "No sueno así."

# game/chapters/4_day.rpyc:2376
translate es call1_day4_4e624112:

    # GRC "This is a pointless waste of time."
    GRC "Esta es una pérdida de tiempo sin sentido."

# game/chapters/4_day.rpyc:2384
translate es call1_day4_749442c7:

    # GRC "This is so stupid."
    GRC "Esto es tan estúpido."

# game/chapters/4_day.rpyc:2389
translate es call1_day4_bd286ab7:

    # GRC "Ah!"
    GRC "!Ah!"

# game/chapters/4_day.rpyc:2396
translate es call1_day4_b39c0ac4:

    # GRC "...Don't worry about it."
    GRC "...No te preocupes por eso."

# game/chapters/4_day.rpyc:2398
translate es call1_day4_1e86795d:

    # GRC "...You are rather insistent, aren't you?"
    GRC "...Eres bastante insistente, ¿no?"

# game/chapters/4_day.rpyc:2402
translate es call1_day4_8a923e32:

    # GRC "Of all the things you could want... you choose... that?"
    GRC "De todas las cosas que podrías desear... ¿Eliges... eso?"

# game/chapters/4_day.rpyc:2410
translate es call1_day4_33eb2a6e:

    # GRC "Your so-"
    GRC "Tu al-"

# game/chapters/4_day.rpyc:2418
translate es call1_day4_67a5f5ed:

    # GRC "Well... hmm.."
    GRC "Bueno... mmm..."

# game/chapters/4_day.rpyc:2420
translate es call1_day4_eb8088ce:

    # GRC "A holiday, I suppose..."
    GRC "Unas vacaciones, supongo..."

# game/chapters/4_day.rpyc:2425
translate es call1_day4_0094e971:

    # GRC "That is what it is called, right? When a mortal takes a break from their work requirements."
    GRC "Se llama así, ¿verdad? Cuando un mortal se toma un descanso de sus obligaciones laborales."

# game/chapters/4_day.rpyc:2433
translate es call1_day4_7b1f78e4:

    # GRC "I have had days off to recover from being unbalanced."
    GRC "He tenido días libres para recuperarme del desequilibrio."

# game/chapters/4_day.rpyc:2435
translate es call1_day4_2a5b3446:

    # GRC "But never have I experienced time away from my duties for pure recreation."
    GRC "Pero nunca he tenido tiempo libre para dedicarme exclusivamente al ocio."

# game/chapters/4_day.rpyc:2444
translate es call1_day4_88f9d05a:

    # GRC "Persistence can be an admirable trait, but it won't save you from your inevitable fate."
    GRC "La persistencia puede ser una cualidad admirable, pero no te salvará de tu destino inevitable."

# game/chapters/4_day.rpyc:2448
translate es call1_day4_437be7c3:

    # GRC "You're bold, I'll give you that. Bold and stupid."
    GRC "Eres valiente, eso hay que reconocerlo. Valiente y idiota."

# game/chapters/4_day.rpyc:2450
translate es call1_day4_032399f2:

    # GRC "How often does that work for you?"
    GRC "¿Con qué frecuencia funciona eso para ti?"

# game/chapters/4_day.rpyc:2455
translate es call1_day4_d02454a7:

    # GRC "I'd love to know where this confidence comes from."
    GRC "Me encantaría saber de dónde viene esa confianza."

# game/chapters/4_day.rpyc:2459
translate es call1_day4_6c081349:

    # GRC "Hah! And what trade is that supposed to be?"
    GRC "¡Ja! ¿Y qué oficio se supone que es ese?"

# game/chapters/4_day.rpyc:2462
translate es call1_day4_8d58c6d1:

    # GRC "I suppose we both have our secrets, then. That seems only fair."
    GRC "Supongo que ambos tenemos nuestros secretos, entonces. Me parece justo."

# game/chapters/4_day.rpyc:2463
translate es call1_day4_811ac06d:

    # GRC "Mine are related to death and beyond, and yours are about confidence in making the Grim Reaper pout."
    GRC "Las mías están relacionadas con la muerte y el más allá, y las tuyas tratan sobre la confianza para hacer que la Parca haga pucheros."

# game/chapters/4_day.rpyc:2464
translate es call1_day4_c1be650f:

    # GRC "Seems about the same level of importance."
    GRC "Parece que tienen el mismo nivel de importancia."

# game/chapters/4_day.rpyc:2471
translate es call1_day4_bea0038d:

    # GRC "I was joking."
    GRC "Estaba bromeando."

# game/chapters/4_day.rpyc:2475
translate es call1_day4_459350d6:

    # GRC "I know, it's unlike me. I feel so guilty."
    GRC "Lo sé, no es propio de mí. Me siento muy culpable."

# game/chapters/4_day.rpyc:2480
translate es call1_day4_d8726b8d:

    # GRC "What can I say? What would someone like {i}me{/i} have to feel guilty about?"
    GRC "¿Qué puedo decir? ¿Por qué alguien como {i}yo{/i} tendría que sentirse culpable?"

# game/chapters/4_day.rpyc:2490
translate es call1_day4_15a43d79:

    # GRC "Hmmm."
    GRC "Mmmm."

# game/chapters/4_day.rpyc:2491
translate es call1_day4_02e77456:

    # GRC "Give me some examples."
    GRC "Dame algunos ejemplos."

# game/chapters/4_day.rpyc:2496
translate es call1_day4_77f5c90e:

    # GRC "That seems entirely reasonable."
    GRC "Eso parece completamente razonable."

# game/chapters/4_day.rpyc:2502
translate es call1_day4_6c5e3b9a:

    # GRC "In fact, I question why 'dinner' is needed at all."
    GRC "De hecho, me pregunto por qué es necesaria la 'cena'."

# game/chapters/4_day.rpyc:2504
translate es call1_day4_cb205b72:

    # GRC "Why not just sustain yourself on dessert?"
    GRC "¿Por qué no alimentarse solo de postres?"

# game/chapters/4_day.rpyc:2515
translate es call1_day4_c8731c32:

    # GRC "What's TokTik?"
    GRC "¿Qué es TokTik?"

# game/chapters/4_day.rpyc:2526
translate es call1_day4_c9915e1a:

    # GRC "Huh. What's the point?"
    GRC "Eh. ¿Cuál es el punto?"

# game/chapters/4_day.rpyc:2538
translate es call1_day4_3be9a8ab:

    # GRC "What...?"
    GRC "¿Qué...?"

# game/chapters/4_day.rpyc:2540
translate es call1_day4_a6205e06:

    # GRC "What kind of vile app do you spend your time on..."
    GRC "En qué tipo de aplicación tan desagradable pierdes el tiempo..."

# game/chapters/4_day.rpyc:2543
translate es call1_day4_822fc446:

    # GRC "Ah, I understand that."
    GRC "Ah, lo entiendo."

# game/chapters/4_day.rpyc:2545
translate es call1_day4_a469b0a4:

    # GRC "At Christmas time, there is a song I will listen to the entire month."
    GRC "En Navidad, hay una canción que escucho durante todo el mes."

# game/chapters/4_day.rpyc:2549
translate es call1_day4_a433780f:

    # GRC "Yes, and?"
    GRC "Si, ¿y?"

# game/chapters/4_day.rpyc:2560
translate es call1_day4_515c260d:

    # GRC "Learn to expect the unexpected, Sunshine."
    GRC "Aprende a esperar lo inesperado, Solecito."

# game/chapters/4_day.rpyc:2561
translate es call1_day4_89b92704:

    # GRC "It will make your short life much easier for you."
    GRC "Te facilitará mucho tu corta vida."

# game/chapters/4_day.rpyc:2565
translate es call1_day4_bd30cdf2:

    # GRC "Ah, an easy rabbit hole to fall down."
    GRC "Ah, una trampa fácil en la que caer."

# game/chapters/4_day.rpyc:2566
translate es call1_day4_c51bd6b8:

    # GRC "I myself have fallen victim to it on a few occassions."
    GRC "Yo mismo he sido víctima de ello en algunas ocasiones."

# game/chapters/4_day.rpyc:2572
translate es call1_day4_b03e6fa6:

    # GRC "Well, it doesn't happen too often."
    GRC "Bueno, no pasa muy seguido."

# game/chapters/4_day.rpyc:2573
translate es call1_day4_228d3703:

    # GRC "Work is always active. I have little time for relaxation."
    GRC "El trabajo siempre está activo. Tengo poco tiempo para relajarme."

# game/chapters/4_day.rpyc:2579
translate es call1_day4_aa2a6d44:

    # GRC "That is not relaxing."
    GRC "Eso no es relajante."

# game/chapters/4_day.rpyc:2584
translate es call1_day4_665b8cd3:

    # GRC "I suppose one could call it a guilty pleasure... mortal reality shows. They are quite the spectacle."
    GRC "Supongo que lo podria llamar un gusto culposo... los reality shows de los mortales. Son todo un espectáculo."

# game/chapters/4_day.rpyc:2588
translate es call1_day4_737c0273:

    # GRC "Mortals are oddly skilled at creating drama from nothing. My people are not like that."
    GRC "Los mortales tienen una extraña habilidad para crear drama de la nada. Mi gente no es así."

# game/chapters/4_day.rpyc:2592
translate es call1_day4_ea05abd2:

    # GRC "I know. My humor knows no bounds."
    GRC "Lo sé. Mi sentido del humor no tiene límites."

# game/chapters/4_day.rpyc:2597
translate es call1_day4_7242e609:

    # GRC "Perhaps you're confusing yourself with me. There is definitely one stupid person here, and it isn't me."
    GRC "Quizás te estás confundiendo conmigo. Definitivamente hay una persona estúpida aquí, y no soy yo."

# game/chapters/4_day.rpyc:2603
translate es call1_day4_2fadf373:

    # GRC "I've told you, I cannot lie."
    GRC "Te lo he dicho, no puedo mentir."

# game/chapters/4_day.rpyc:2611
translate es call1_day4_b48a73dd:

    # GRC "I cannot."
    GRC "No puedo."

# game/chapters/4_day.rpyc:2613
translate es call1_day4_5aafb0eb:

    # GRC "I am not able to. What part don't you understand?"
    GRC "No puedo. ¿Qué parte no entiendes?"

# game/chapters/4_day.rpyc:2619
translate es call1_day4_df6af600:

    # GRC "It is not magic, we are simply bound by our oath."
    GRC "No es magia, simplemente estamos obligados por nuestro juramento."

# game/chapters/4_day.rpyc:2620
translate es call1_day4_39e4e6c3:

    # GRC "I physically cannot speak a lie."
    GRC "Físicamente, no puedo decir mentiras."

# game/chapters/4_day.rpyc:2627
translate es call1_day4_bae11104:

    # GRC "Yes, like actually. How many times must I repeat myself?"
    GRC "Sí, en serio. ¿Cuántas veces tengo que repetirlo?"

# game/chapters/4_day.rpyc:2629
translate es call1_day4_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/4_day.rpyc:2634
translate es call1_day4_96a72140:

    # GRC "Don't smile like that..."
    GRC "No sonrías así..."

# game/chapters/4_day.rpyc:2653
translate es call1_day4_295408ea:

    # GRC "Er... you know, I can still refuse to answer your questions."
    GRC "Er... ya sabes, todavía puedo negarme a responder a tus preguntas."

# game/chapters/4_day.rpyc:2654
translate es call1_day4_b25f3de4:

    # GRC "My oath doesn't force me to speak. Only not to speak lies."
    GRC "Mi juramento no me obliga a hablar. Solo a no decir mentiras."

# game/chapters/4_day.rpyc:2662
translate es call1_day4_adb8cd50:

    # GRC "What, you want to play twenty questions now?"
    GRC "¿Qué, ahora quieres jugar a las veinte preguntas?"

# game/chapters/4_day.rpyc:2666
translate es call1_day4_6fbe03f4:

    # GRC "No."
    GRC "No."

# game/chapters/4_day.rpyc:2671
translate es call1_day4_6bc27ebd:

    # GRC "I... what? Why would you care...?!"
    GRC "¿Yo... qué? ¿¡Por qué te importaría!?"

# game/chapters/4_day.rpyc:2676
translate es call1_day4_ae02d01c:

    # GRC "...Let's talk about something else."
    GRC "...Hablemos de otra cosa."

# game/chapters/4_day.rpyc:2684
translate es call1_day4_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/4_day.rpyc:2687
translate es call1_day4_ba5007bc:

    # GRC "Well, he..."
    GRC "Bueno, él..."

# game/chapters/4_day.rpyc:2692
translate es call1_day4_242c814c:

    # GRC "{i}He's{/i} cute, so..."
    GRC "{i}Es{/i} lindo, así que..."

# game/chapters/4_day.rpyc:2700
translate es call1_day4_ce6c532d:

    # GRC "Get lost."
    GRC "Vete al diablo."

# game/chapters/4_day.rpyc:2703
translate es call1_day4_15873585:

    # GRC "Is it any of your business?"
    GRC "¿Es eso asunto tuyo?"

# game/chapters/4_day.rpyc:2712
translate es call1_day4_13266d51:

    # GRC "He is not a teddy. This utter disrespect towards Azrael will not be tolerated."
    GRC "No es un peluche. No se tolerará esta falta de respeto hacia Azrael."

# game/chapters/4_day.rpyc:2720
translate es call1_day4_570b9b75:

    # GRC "Very."
    GRC "En absoluto."

# game/chapters/4_day.rpyc:2726
translate es call1_day4_c1e6ab6a:

    # GRC "Of course. Pineapple was created by the gods to be placed on pizza."
    GRC "Por supuesto. La piña fue creada por los dioses para ponerla en la pizza."

# game/chapters/4_day.rpyc:2730
translate es call1_day4_8995ea6d:

    # GRC "If anything here is wrong, it's you."
    GRC "Si hay alguien equivocado aquí, ese eres tú."

# game/chapters/4_day.rpyc:2739
translate es call1_day4_e1a34e60:

    # GRC "Glad you recognize it."
    GRC "Me alegra que lo reconozcas."

# game/chapters/4_day.rpyc:2748
translate es call1_day4_0625d6f6:

    # GRC "I pass."
    GRC "Paso."

# game/chapters/4_day.rpyc:2758
translate es call1_day4_15df62cf:

    # GRC "...I said I pass. I refuse to play this infantile game any longer."
    GRC "...Dije que paso. Me niego a seguir jugando a este juego infantil."

# game/chapters/4_day.rpyc:2763
translate es call1_day4_30c74a20:

    # GRC "Oh, for the love of..."
    GRC "Ay, por el amor de..."

# game/chapters/4_day.rpyc:2768
translate es call1_day4_442bc391:

    # GRC "I... I didn't say that, did I?"
    GRC "Yo... yo no dije eso, ¿verdad?"

# game/chapters/4_day.rpyc:2776
translate es call1_day4_8001a641:

    # GRC "You are all I think about right now, mortal."
    GRC "Eres en lo único que pienso ahora mismo, mortal."

# game/chapters/4_day.rpyc:2778
translate es call1_day4_bafbfb46:

    # GRC "And it is... aggravating."
    GRC "Y es... irritante."

# game/chapters/4_day.rpyc:2786
translate es call1_day4_410fad34:

    # GRC "I ... do not think so."
    GRC "Yo... no lo creo."

# game/chapters/4_day.rpyc:2790
translate es call1_day4_a0f1a66f:

    # GRC "I have simply never lived a life, nor had the time, to consider something like that."
    GRC "Sinceramente, nunca he vivido una vida, ni he tenido tiempo, para considerar algo así."

# game/chapters/4_day.rpyc:2792
translate es call1_day4_d0a7f58e:

    # GRC "I am too busy, and..."
    GRC "Estoy muy ocupado y..."

# game/chapters/4_day.rpyc:2793
translate es call1_day4_578c5125:

    # GRC "Love and death don't tend to mix easily. I believe I've mentioned it somewhat before."
    GRC "El amor y la muerte no suelen combinarse fácilmente. Creo que ya lo he mencionado antes."

# game/chapters/4_day.rpyc:2798
translate es call1_day4_44c04449:

    # GRC "Fall in love? Why?"
    GRC "¿Enamorarse? ¿Por qué?"

# game/chapters/4_day.rpyc:2803
translate es call1_day4_54fe3d67:

    # GRC "Why do I need someone else to be happy?"
    GRC "¿Por qué necesito a otra persona para ser feliz?"

# game/chapters/4_day.rpyc:2814
translate es call1_day4_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/4_day.rpyc:2822
translate es call1_day4_476a9803:

    # GRC "Lonely, huh..."
    GRC "Solitario, huh..."

# game/chapters/4_day.rpyc:2824
translate es call1_day4_778b64f6:

    # GRC "You can think what you wish of me."
    GRC "Puedes pensar lo que quieras de mí."

# game/chapters/4_day.rpyc:2829
translate es call1_day4_687c7bf1:

    # GRC "You may take of it what you wish."
    GRC "Puedes tomarlo como quieras."

# game/chapters/4_day.rpyc:2837
translate es call1_day4_5489559f:

    # GRC "No. I have not been in love, and I would not kiss someone I did not love."
    GRC "No. Nunca he estado enamorado y no besaría a alguien a quien no amara."

# game/chapters/4_day.rpyc:2839
translate es call1_day4_cadd4609:

    # GRC "...Have you?"
    GRC "... ¿Y tú?"

# game/chapters/4_day.rpyc:2843
translate es call1_day4_d07bab82:

    # GRC "No, the other person that I'm chatting to. Of course I mean you, mortal."
    GRC "No, la otra persona con la que estoy chateando. Por supuesto que me refiero a ti, mortal."

# game/chapters/4_day.rpyc:2850
translate es call1_day4_fe6482a7:

    # GRC "You can just say yes, you know."
    GRC "Puedes decir que sí, ya sabes."

# game/chapters/4_day.rpyc:2852
translate es call1_day4_ad439b6e:

    # GRC "Interesting."
    GRC "Interesante."

# game/chapters/4_day.rpyc:2857
translate es call1_day4_8cc1da3a:

    # GRC "Nope, it's still my turn, [playerfirstname]."
    GRC "Nop, todavía es mi turno, [playerfirstname]."

# game/chapters/4_day.rpyc:2861
translate es call1_day4_5cc33b83:

    # GRC "It is."
    GRC "Así es."

# game/chapters/4_day.rpyc:2862
translate es call1_day4_7bfda738:

    # GRC "But if you get to play, so do I."
    GRC "Pero si tú puedes jugar, yo también."

# game/chapters/4_day.rpyc:2864
translate es call1_day4_56948926:

    # GRC "Are you afraid?"
    GRC "¿Tienes miedo?"

# game/chapters/4_day.rpyc:2868
translate es call1_day4_0b1d056e:

    # GRC "Of me."
    GRC "De mi."

# game/chapters/4_day.rpyc:2872
translate es call1_day4_008afe10_3:

    # GRC "..."
    GRC "..."

# game/chapters/4_day.rpyc:2874
translate es call1_day4_d90f5ada:

    # GRC "You should be."
    GRC "Deberías tenerlo."

# game/chapters/4_day.rpyc:2879
translate es call1_day4_62f87689:

    # GRC "You will change your mind when your soul becomes mine."
    GRC "Cambiarás de opinión cuando tu alma sea mía."

# game/chapters/4_day.rpyc:2893
translate es call1_day4_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/4_day.rpyc:2894
translate es call1_day4_40f069b8:

    # GRC "...You are full of life, [playerfirstname]. You would fill your life with plenty, I'm sure."
    GRC "...Estás rebosante de vida, [playerfirstname]. Estoy seguro de que llenarías tu vida de abundancia."

# game/chapters/4_day.rpyc:2897
translate es call1_day4_7ddfc8e0:

    # GRC "You're smart, then."
    GRC "Entonces eres inteligente."

# game/chapters/4_day.rpyc:2902
translate es call1_day4_1c92f65c:

    # GRC "Interested?"
    GRC "¿Interés?"

# game/chapters/4_day.rpyc:2910
translate es call1_day4_7176be62:

    # GRC "That much is obvious."
    GRC "Eso es obvio."

# game/chapters/4_day.rpyc:2918
translate es call1_day4_008afe10_4:

    # GRC "..."
    GRC "..."

# game/chapters/4_day.rpyc:2926
translate es call1_day4_01ba542f:

    # GRC "I told you, that information is classified."
    GRC "Te dije que esa información está clasificada."

# game/chapters/4_day.rpyc:2931
translate es call1_day4_7217201f:

    # GRC "Lying? No, mortal."
    GRC "¿Mintiendo? No, mortal."

# game/chapters/4_day.rpyc:2936
translate es call1_day4_a77ad7a4:

    # GRC "No. That would be risking my very position, and therefore, my life."
    GRC "No. Eso pondría en peligro mi puesto y, por lo tanto, mi vida."

# game/chapters/4_day.rpyc:2937
translate es call1_day4_df320663:

    # GRC "I believe it's my turn."
    GRC "Creo que es mi turno."

# game/chapters/4_day.rpyc:2942
translate es call1_day4_68ab24a1:

    # GRC "Have you felt anything... unusual today?"
    GRC "¿Has sentido algo... inusual hoy?"

# game/chapters/4_day.rpyc:2946
translate es call1_day4_11f1655d:

    # GRC "Just anything... off?"
    GRC "¿Algo... extraño?"

# game/chapters/4_day.rpyc:2951
translate es call1_day4_06decfcd:

    # GRC "........"
    GRC "........"

# game/chapters/4_day.rpyc:2959
translate es call1_day4_20333962:

    # GRC "What makes you think I've done something?"
    GRC "¿Qué te hace pensar que he hecho algo?"

# game/chapters/4_day.rpyc:2964
translate es call1_day4_5411d6d9:

    # GRC "Intentionally? No."
    GRC "¿Intencionalmente? No."

# game/chapters/4_day.rpyc:2975
translate es call1_day4_8f82578d:

    # GRC "You see, I... seem to have left a small portion of myself... tethered to you."
    GRC "Verás, yo... parece que he dejado una pequeña parte de mí... atada a ti."

# game/chapters/4_day.rpyc:2987
translate es call1_day4_066f2b35:

    # GRC "A part of my soul seems to have remained after what happened yesterday."
    GRC "Parece que una parte de mi alma se ha quedado atrás después de lo que pasó ayer."

# game/chapters/4_day.rpyc:3012
translate es call1_day4_9eef311c:

    # GRC "I did not intend to leave it behind..."
    GRC "No era mi intención dejarla atrás..."

# game/chapters/4_day.rpyc:3017
translate es call1_day4_07942606:

    # GRC "You... like it?"
    GRC "¿Te... gusta eso?"

# game/chapters/4_day.rpyc:3022
translate es call1_day4_2667b5a2:

    # GRC "Really?"
    GRC "¿En serio?"

# game/chapters/4_day.rpyc:3024
translate es call1_day4_2fa0d85c:

    # GRC "I had guessed it would displease you."
    GRC "Supuse que eso te disgustaría."

# game/chapters/4_day.rpyc:3029
translate es call1_day4_baf101e7:

    # GRC "I am quite concerned for your mental state, mortal."
    GRC "Me preocupa bastante tu estado mental, mortal."

# game/chapters/4_day.rpyc:3030
translate es call1_day4_1966a4b1:

    # GRC "Not many people would be pleased about a person they barely know attached to their body."
    GRC "A muy poca gente le gustaría tener adherida a su cuerpo a una persona a la que apenas conoce."

# game/chapters/4_day.rpyc:3035
translate es call1_day4_3d8c60d9:

    # GRC "Do not call me that."
    GRC "No me llames así."

# game/chapters/4_day.rpyc:3039
translate es call1_day4_33db2b6f:

    # GRC "I am not, in any sense of the word, little."
    GRC "No soy, en ningún sentido de la palabra, pequeño."

# game/chapters/4_day.rpyc:3047
translate es call1_day4_b1bdc806:

    # GRC "Hey...!"
    GRC "¡Ey...!"

# game/chapters/4_day.rpyc:3048
translate es call1_day4_a1e81427:

    # GRC "I... I didn't mean..."
    GRC "Yo... No quise decir..."

# game/chapters/4_day.rpyc:3050
translate es call1_day4_11c70a5e:

    # GRC "You... are shameless. Totally and completely shameless."
    GRC "Eres... una persona sin vergüenza. Total y completamente sin vergüenza."

# game/chapters/4_day.rpyc:3057
translate es call1_day4_008afe10_5:

    # GRC "..."
    GRC "..."

# game/chapters/4_day.rpyc:3062
translate es call1_day4_008afe10_6:

    # GRC "..."
    GRC "..."

# game/chapters/4_day.rpyc:3066
translate es call1_day4_0a2c4bf7:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/4_day.rpyc:3068
translate es call1_day4_deb78a43:

    # GRC "Don't wiggle your eyebrows at me..."
    GRC "No me muevas las cejas..."

# game/chapters/4_day.rpyc:3070
translate es call1_day4_a095992b:

    # GRC "And... stop staring at me like that..."
    GRC "Y... deja de mirarme así..."

# game/chapters/4_day.rpyc:3078
translate es call1_day4_008afe10_7:

    # GRC "..."
    GRC "..."

# game/chapters/4_day.rpyc:3082
translate es call1_day4_65f83073:

    # GRC "You... are very..."
    GRC "Tu... eres muy..."

# game/chapters/4_day.rpyc:3087
translate es call1_day4_bbc16154:

    # GRC "Insolent."
    GRC "Insolente."

# game/chapters/4_day.rpyc:3090
translate es call1_day4_0a2c4bf7_1:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/4_day.rpyc:3091
translate es call1_day4_6e1c0606:

    # GRC "You—"
    GRC "Tú-"

# game/chapters/4_day.rpyc:3092
translate es call1_day4_e1791aff:

    # GRC "Don't... "
    GRC "No... "

# game/chapters/4_day.rpyc:3093
translate es call1_day4_1b6b6a40:

    # GRC "I... I can't..."
    GRC "Yo... no puedo..."

# game/chapters/4_day.rpyc:3098
translate es call1_day4_b8d5f407:

    # GRC "...!"
    GRC "...!"

# game/chapters/4_day.rpyc:3105
translate es call1_day4_65f83073_1:

    # GRC "You... are very..."
    GRC "Tu... eres muy..."

# game/chapters/4_day.rpyc:3106
translate es call1_day4_59268016:

    # GRC "Cheeky."
    GRC "Impertinente."

# game/chapters/4_day.rpyc:3111
translate es call1_day4_d7f02dc9:

    # GRC "You shouldn't be!"
    GRC "¡No deberías serlo!"

# game/chapters/4_day.rpyc:3119
translate es call1_day4_62bde14d:

    # GRC "It would be unwise for me to collect it yet."
    GRC "No sería prudente por mi parte recogerla todavía."

# game/chapters/4_day.rpyc:3120
translate es call1_day4_fcef12ff:

    # GRC "The risk would be too great."
    GRC "El riesgo sería demasiado grande."

# game/chapters/4_day.rpyc:3122
translate es call1_day4_67dc38e1:

    # GRC "At this point it is too deeply embedded within your soul."
    GRC "En este momento está demasiado arraigado en tu alma."

# game/chapters/4_day.rpyc:3125
translate es call1_day4_17494ef8:

    # GRC "And considering what happened yesterday..."
    GRC "Y considerando lo que pasó ayer..."

# game/chapters/4_day.rpyc:3133
translate es call1_day4_8295d95c:

    # GRC "It was foolish."
    GRC "Fue una tontería."

# game/chapters/4_day.rpyc:3134
translate es call1_day4_c64ad5fa:

    # GRC "You should have trusted me."
    GRC "Deberías haber confiado en mí."

# game/chapters/4_day.rpyc:3139
translate es call1_day4_699373d1:

    # GRC "...You nearly lost yourself, Sunshine."
    GRC "...Casi pierdes el control, Solecito."

# game/chapters/4_day.rpyc:3140
translate es call1_day4_458c5b80:

    # GRC "I am surprised, however, that you managed to come back from that."
    GRC "Sin embargo, me sorprende que hayas logrado recuperarte de eso."

# game/chapters/4_day.rpyc:3142
translate es call1_day4_d2c05b9f:

    # GRC "Consider yourself extremely lucky."
    GRC "Considérate una persona muy afortunada."

# game/chapters/4_day.rpyc:3152
translate es call1_day4_89e8213d:

    # GRC "I know."
    GRC "Lo sé."

# game/chapters/4_day.rpyc:3153
translate es call1_day4_af5762f0:

    # GRC "I can see the guilt in your eyes."
    GRC "Puedo ver la culpa en tus ojos."

# game/chapters/4_day.rpyc:3161
translate es call1_day4_d6a2d13e:

    # GRC "...Good."
    GRC "...Bien."

# game/chapters/4_day.rpyc:3176
translate es call1_day4_0a2c4bf7_2:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/4_day.rpyc:3177
translate es call1_day4_ca12462d:

    # GRC "Absolutely not! Do not be absurd!"
    GRC "¡Por supuesto que no! ¡No digas tonterías!"

# game/chapters/4_day.rpyc:3181
translate es call1_day4_0269a621:

    # GRC "No!"
    GRC "¡No!"

# game/chapters/4_day.rpyc:3182
translate es call1_day4_2461d6be:

    # GRC "I am not some creep that watches people undress!"
    GRC "¡No soy un pervertido que observa a la gente desvestirse!"

# game/chapters/4_day.rpyc:3186
translate es call1_day4_0eaf9e65:

    # GRC "No. Why would I want to do that?"
    GRC "No. ¿Por qué habría de querer hacer eso?"

# game/chapters/4_day.rpyc:3190
translate es call1_day4_70363630:

    # GRC "Obviously."
    GRC "Obviamente."

# game/chapters/4_day.rpyc:3194
translate es call1_day4_a2082105:

    # GRC "Your... mindset really is something."
    GRC "Tu... forma de pensar es realmente increíble."

# game/chapters/4_day.rpyc:3196
translate es call1_day4_dfc30d45:

    # GRC "But no... I will not be... watching you."
    GRC "Pero no... No te estaré... observando."

# game/chapters/4_day.rpyc:3198
translate es call1_day4_84ef2978:

    # GRC "I can't use it to spy on you."
    GRC "No puedo usarlo para espiarte."

# game/chapters/4_day.rpyc:3221
translate es day4_12option_d74b6c6e:

    # GRC "I have absolutely not been spying on you."
    GRC "No te he estado espiando en absoluto."

# game/chapters/4_day.rpyc:3222
translate es day4_12option_f5a72818:

    # GRC "I already see far too much of you during my work hours."
    GRC "Ya te veo demasiado durante mis horas de trabajo."

# game/chapters/4_day.rpyc:3224
translate es day4_12option_c7e8f646:

    # GRC "Seeing you any more than that would be... too much."
    GRC "Verte más que eso sería... demasiado."

# game/chapters/4_day.rpyc:3228
translate es day4_12option_cc33c848:

    # GRC "I cannot. It is too risky."
    GRC "No puedo. Es demasiado arriesgado."

# game/chapters/4_day.rpyc:3232
translate es day4_12option_17494ef8:

    # GRC "And considering what happened yesterday..."
    GRC "Y teniendo en cuenta lo que pasó ayer..."

# game/chapters/4_day.rpyc:3240
translate es day4_12option_8295d95c:

    # GRC "It was foolish."
    GRC "Fue una tontería."

# game/chapters/4_day.rpyc:3241
translate es day4_12option_c64ad5fa:

    # GRC "You should have trusted me."
    GRC "Deberías haber confiado en mí."

# game/chapters/4_day.rpyc:3246
translate es day4_12option_699373d1:

    # GRC "...You nearly lost yourself, Sunshine."
    GRC "...Casi pierdes el control, Solecito."

# game/chapters/4_day.rpyc:3247
translate es day4_12option_458c5b80:

    # GRC "I am surprised, however, that you managed to come back from that."
    GRC "Sin embargo, me sorprende que hayas logrado recuperarte de eso."

# game/chapters/4_day.rpyc:3249
translate es day4_12option_d2c05b9f:

    # GRC "Consider yourself extremely lucky."
    GRC "Considérate una persona muy afortunada."

# game/chapters/4_day.rpyc:3259
translate es day4_12option_89e8213d:

    # GRC "I know."
    GRC "Lo sé."

# game/chapters/4_day.rpyc:3260
translate es day4_12option_af5762f0:

    # GRC "I can see the guilt in your eyes."
    GRC "Puedo ver la culpa en tus ojos."

# game/chapters/4_day.rpyc:3268
translate es day4_12option_d6a2d13e:

    # GRC "...Good."
    GRC "...Bien."

# game/chapters/4_day.rpyc:3274
translate es day4_12option_f3e5d8d5:

    # GRC "There won't be any spying."
    GRC "No habrá ningún tipo de espionaje."

# game/chapters/4_day.rpyc:3280
translate es day4_merge_bb1349b6:

    # GRC "That piece of my soul is far too small for something like that."
    GRC "Esa parte de mi alma es demasiado pequeña para algo así."

# game/chapters/4_day.rpyc:3286
translate es day4_merge_7139eff5:

    # GRC "Indeed it is. If another were to sense it on you, they would see I have already laid my claim."
    GRC "Así es. Si alguien más la percibiera en ti, vería que ya la he reclamado como mía."

# game/chapters/4_day.rpyc:3287
translate es day4_merge_3ad54cd5:

    # GRC "It is a mark against your soul—one that shows you were touched by death itself."
    GRC "Es una marca en tu alma, una que demuestra que has sido tocado por la muerte misma."

# game/chapters/4_day.rpyc:3288
translate es day4_merge_7ca85afa:

    # GRC "And it would be foolish to try and take something that belongs to someone else."
    GRC "Y sería una tontería intentar quitarle algo que le pertenece a otra persona."

# game/chapters/4_day.rpyc:3295
translate es day4_merge_833dd5db:

    # GRC "Your soul does."
    GRC "Tu alma sí."

# game/chapters/4_day.rpyc:3300
translate es day4_merge_1faa841d:

    # GRC "...Not for much longer."
    GRC "...No por mucho tiempo."

# game/chapters/4_day.rpyc:3304
translate es day4_merge_24a0fd43:

    # GRC "Yes, we will."
    GRC "Sí, lo veremos"

# game/chapters/4_day.rpyc:3308
translate es day4_merge_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/4_day.rpyc:3309
translate es day4_merge_c5664f82:

    # GRC "You mean to be indecent, but if you agree to being owned that easily know that to be owned by me means I'll own all of you."
    GRC "Tu intención es ser indecente, pero si aceptas ser mi propiedad tan fácilmente, debes saber que ser mi propiedad significa que seré dueño de todo tu ser."

# game/chapters/4_day.rpyc:3311
translate es day4_merge_ec683856:

    # GRC "And this includes your soul."
    GRC "Y eso incluye tu alma."

# game/chapters/4_day.rpyc:3312
translate es day4_merge_cd589faa:

    # GRC "So are you agreeing to hand it over after all, mortal?"
    GRC "¿Entonces estás de acuerdo en entregarla después de todo, mortal?"

# game/chapters/4_day.rpyc:3322
translate es day4_merge_be518a95:

    # GRC "...And why is that?"
    GRC "...¿Y por qué?"

# game/chapters/4_day.rpyc:3330
translate es day4_merge_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/4_day.rpyc:3335
translate es day4_merge_02a9e447:

    # GRC "Too bad."
    GRC "Qué pena."

# game/chapters/4_day.rpyc:3336
translate es day4_merge_da70b711:

    # GRC "I already have."
    GRC "Ya lo he hecho."

# game/chapters/4_day.rpyc:3343
translate es day4_merge_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/4_day.rpyc:3345
translate es day4_merge_7ec3a04b:

    # GRC "You speak the truth, yes."
    GRC "Dices la verdad, sí."

# game/chapters/4_day.rpyc:3346
translate es day4_merge_bf77a4d7:

    # GRC "But I am willing to risk that for you."
    GRC "Pero estoy dispuesto a arriesgarme por ti."

# game/chapters/4_day.rpyc:3364
translate es day4_merge_b3a164a3:

    # GRC "Death cannot be owned."
    GRC "La muerte no se puede poseer."

# game/chapters/4_day.rpyc:3379
translate es day4_merge_8f3ba53f:

    # GRC "You think you can control a reaper?"
    GRC "¿Crees que puedes controlar a una parca?"

# game/chapters/4_day.rpyc:3390
translate es day4_merge_008afe10_3:

    # GRC "..."
    GRC "..."

# game/chapters/4_day.rpyc:3391
translate es day4_merge_7a6f8e8d:

    # GRC "You are a very forward person."
    GRC "Eres una persona muy directa."

# game/chapters/4_day.rpyc:3392
translate es day4_merge_7ea02d3a:

    # GRC "It is... perhaps a blessing and a curse."
    GRC "Es... quizás una bendición y una maldición."

# game/chapters/4_day.rpyc:3394
translate es day4_merge_008afe10_4:

    # GRC "..."
    GRC "..."

# game/chapters/4_day.rpyc:3402
translate es day4_merge_6e8944f0:

    # GRC "Ha... honestly, being around you is very confusing."
    GRC "Ja... sinceramente, estar contigo es muy confuso."

# game/chapters/4_day.rpyc:3404
translate es day4_merge_621b08fb:

    # GRC "I do not know what I did wrong to deserve this fate."
    GRC "No sé qué hice mal para merecer este destino."

# game/chapters/4_day.rpyc:3415
translate es day4_merge_f8336e76:

    # GRC "Yes, well, that's all well and good, but you're..."
    GRC "Sí, bueno, todo eso está muy bien, pero tú estás..."

# game/chapters/4_day.rpyc:3417
translate es day4_merge_008afe10_5:

    # GRC "..."
    GRC "..."

# game/chapters/4_day.rpyc:3422
translate es day4_merge_e843c1f6:

    # GRC "You know what, I have something I need to do."
    GRC "¿Sabes qué? Tengo algo que hacer."

# game/chapters/4_day.rpyc:3427
translate es day4_merge_f75bebdc:

    # GRC "I can. I will."
    GRC "Puedo. Lo haré."

# game/chapters/4_day.rpyc:3428
translate es day4_merge_aeb28d95:

    # GRC "It's exactly what I plan to do."
    GRC "Es exactamente lo que pienso hacer."

# game/chapters/4_day.rpyc:3432
translate es day4_merge_15cc6396:

    # GRC "I am not scared."
    GRC "No tengo miedo."

# game/chapters/4_day.rpyc:3433
translate es day4_merge_52f5e8d1:

    # GRC "That was a poor attempt to frighten me."
    GRC "Ha sido un intento muy pobre de asustarme."

# game/chapters/4_day.rpyc:3447
translate es day4_merge_99a4c6ae:

    # GRC "Deal with it."
    GRC "Aguántate."

# game/chapters/4_day.rpyc:3451
translate es day4_merge_8baf5f41:

    # GRC "Good."
    GRC "Bien."

# game/chapters/4_day.rpyc:3452
translate es day4_merge_14cbb985:

    # GRC "Anyway..."
    GRC "De todos modos..."

# game/chapters/4_day.rpyc:3455
translate es day4_merge_746ae768:

    # GRC "You tease me, it is only fair."
    GRC "Me provocas, es justo."

# game/chapters/4_day.rpyc:3456
translate es day4_merge_d57a3926:

    # GRC "You, as mortals say, 'dish it, but cannot take it'."
    GRC "Tú, como dicen los mortales, 'lo dices, pero no lo aguantas'."

# game/chapters/4_day.rpyc:3457
translate es day4_merge_14cbb985_1:

    # GRC "Anyway..."
    GRC "De todos modos..."

# game/chapters/4_day.rpyc:3466
translate es day4_merge_1df5313d:

    # GRC "Goodnight, Sunshine."
    GRC "Buenas noches, Solecito."

translate es strings:

    old "1. <Got any leads?>"
    new "1. <¿Tienes alguna pista?>"

    old "1. <Any news?>"
    new "1. <¿Alguna novedad?>"

    old "1. <I'll take that as a no, then.>"
    new "1. <Lo tomaré como un no, entonces.>"

    old "1. <Unless it's a yes, and you're just ignoring me...>"
    new "1. <A menos que sea un sí y simplemente me estés ignorando...>"

    old "1. <You wouldn't do that, right?>"
    new "1. <No harías eso, ¿verdad?>"

    old "1. <Ah! The man of the hour!>"
    new "1. <¡Ah! ¡El hombre del momento!>"

    old "1. <In this instance, yes. Always is a little much..>"
    new "1. <En este caso, sí. Siempre es un poco exagerado...>"

    old "1. <There's an interesting thought.>"
    new "1. <Es una idea interesante.>"

    old "1. <Is the Grim Reaper {i}literally{/i} death?>"
    new "1. <¿Es la Parca {i}literalmente{/i} la muerte?>"

    old "1. <But is that the same thing?>"
    new "1. <Pero, ¿es lo mismo?>"

    old "1. <You seem a little too lively to be called death incarnate.>"
    new "1. <Pareces demasiado animado como para ser la encarnación de la muerte.>"

    old "1. <But, either way, we're getting off topic here.>"
    new "1. <Pero, en cualquier caso, nos estamos desviando del tema.>"

    old "1. <Is there someone more important I could speak to?>"
    new "1. <¿Hay alguien más importante con quien pueda hablar?>"

    old "1. <Your manager?>"
    new "1. <¿Tu jefe?>"

    old "1. <Might be faster than waiting for you to hit the books.>"
    new "1. <Podría ser más rápido que esperar a que te pongas a estudiar.>"

    old "1. <Do I think you're stupid? Well...>"
    new "1. <¿Que si creo que eres tonto? Bueno...>"

    old "1. <Are you sure you want me to answer that?>"
    new "1. <¿Estás seguro de que quieres que te responda a eso?>"

    old "1. <Yes sir :)>"
    new "1. <Sí, señor :)>"

    old "1. <I would like to point out that I am, in fact, communicating with you via text.>"
    new "1. <Me gustaría señalar que, de hecho, me estoy comunicando contigo por mensaje de texto.>"

    old "1. <My mouth is indeed shut! :)>"
    new "1. <¡Mi boca está cerrada! :)>"

    old "1. <Like what, exactly - [pretty], smart, [beautiful]?>"
    new "1. <¿Como qué, exactamente - [pretty!t], inteligente, [beautiful!t]?>"

    old "1. <But you {i}do{/i} think I am those things, riiiiight?>"
    new "1. <Pero tú {i}sí{/i} piensas que soy esas cosas, ¿veeeerdad?>"

    old "1. <...Did you actually just type 'sigh'. So dramatic...>"
    new "1. <¿De verdad acabas de escribir 'suspiro'? Qué dramático...>"

    old "1. <Would you say 'sigh' out loud, too?>"
    new "1. <¿También dirías 'suspiro' en voz alta?>"

    old "1. <God you're stupid.>"
    new "1. <Dios, eres estúpido.>"

    old "1. <Not literally, doofus.>"
    new "1. <No literalmente, tonto.>"

    old "1. <I love bullying you, after all.>"
    new "1. <Me encanta molestarte, después de todo.>"

    old "1. <Good, I like being mysterious.>"
    new "1. <Bien, me gusta mantener el misterio.>"

    old "1. <Anyway, we're getting off topic here.>"
    new "1. <De todos modos, nos estamos desviando del tema.>"

    old "1. <I can be a patient person...>"
    new "1. <Puedo ser una persona paciente...>"

    old "1. <But I'm reeeaaally curious...>"
    new "1. <Pero tengo muchaaaaa curiosidad...>"

    old "1. <I do work, you know... but yeah, kinda.>"
    new "1. <Yo trabajo, ya sabes... pero sí, más o menos.>"

    old "1. <I'd say that {i}is{/i} me being extremely patient, anyway.>"
    new "1. <Yo diría que {i}eso{/i} es ser extremadamente paciente, en cualquier caso.>"

    old "1. <Oh please, that's hardly nagging.>"
    new "1. <Por favor, eso no se puede considerar regañar.>"

    old "1. <If you want me to nag you, I can.>"
    new "1. <Si quieres que te regañe, puedo hacerlo.>"

    old "1. <Well, that's rude.>"
    new "1. <Bueno, eso fue grosero.>"

    old "1. <Rude reaper.>"
    new "1. <Parca Grosera.>"

    old "1. <I'm sure you'll change your mind soon enough.>"
    new "1. <Seguro que pronto cambiarás de opinión.>"

    old "1. <Even if you {i}are{/i} rude, I still think you're...>"
    new "1. <Aunque {i}seas{/i} grosero, sigo pensando que eres...>"

    old "1. <Cute!>"
    new "1. <¡Lindo!>"

    old "1. <Doesn't death have all the time in the world?>"
    new "1. <¿Acaso la muerte no tiene todo el tiempo del mundo?>"

    old "1. <If you're so busy, then we should just talk about the elephant in the room.>"
    new "1. <Si estás tan ocupado, entonces deberíamos hablar del elefante en la habitación.>"

    old "1. <You love talking to me.>"
    new "1. <Te encanta hablar conmigo.>"

    old "1. <Sounds like a roundabout way of agreeing with me.>"
    new "1. <Parece una forma indirecta de darme la razón.>"

    old "1. <You always say I'm sitting around waiting to talk to you...>"
    new "1. <Siempre dices que estoy esperando para hablar contigo...>"

    old "1. <But I bet that's what you do!>"
    new "1. <¡Pero apuesto a que eso es lo que haces tu!>"

    old "1. <Yeah, pretty much.>"
    new "1. <Sí, más o menos.>"

    old "1. <I mean, I feel like you're not even {i}trying{/i} to take my soul.>"
    new "1. <Es decir, siento que ni siquiera estás {i}intentando{/i} robarme el alma.>"

    old "1. <Aww, poor Grim.>"
    new "1. <Aww, pobre Parca.>"

    old "1. <Sorry, I'm a little attached to it.>"
    new "1. <Lo siento, le tengo un poco de cariño.>"

    old "1. <More importantly, you were going to tell me about it.>"
    new "1. <Lo más importante es que ibas a contármelo.>"

    old "1. <Don't you think it's only fair I know?>"
    new "1. <¿No crees que es justo que lo sepa?>"

    old "1. <I know about patience already...>"
    new "1. <Ya sé sobre la paciencia...>"

    old "1. <Pfft. You wish.>"
    new "1. <Pfft. Ya te gustaría.>"

    old "1. <I know you'd be lonely if I left you alone for too long.>"
    new "1. <Sé que te sentirías solo si te dejara solo durante mucho tiempo.>"

    old "1. <Really?>"
    new "1. <¿En serio?>"

    old "1. <You suck. Do you have any answers or not, Grimmy?>"
    new "1. <Eres un inútil. ¿Tienes alguna respuesta o no, Parquita?>"

    old "1. <I thought it had a nice ring to it.>"
    new "1. <Pensé que sonaba bien.>"

    old "1. <Thanks for letting me know.>"
    new "1. <Gracias por avisarme.>"

    old "1. <Here I was wondering about your bathing habits, after all.>"
    new "1. <Al final, me estaba preguntando cuáles eran tus hábitos de baño.>"

    old "1. <I have an important question for you.>"
    new "1. <Tengo una pregunta importante para ti.>"

    old "1. <Do you prefer to shower at night, or in the morning?>"
    new "1. <¿Prefieres ducharte por la noche o por la mañana?>"

    old "1. <Okay. If you lived somewhere that wasn't superhell...>"
    new "1. <De acuerdo. Si vivieras en un lugar que no fuera el inframundo...>"

    old "1. <Would you pick night or day?>"
    new "1. <¿Escogerías noche o día?>"

    old "1. <Night or daaaaay?>"
    new "1. <¿Noche o díaaaaaaa?>"

    old "1. <Me too!>"
    new "1. <¡Yo también!>"

    old "1. <We kinda clash... I guess we could always shower together instead.>"
    new "1. <Nosotros coincidimos... Supongo que siempre podríamos ducharnos juntos en su lugar.>"

    old "1. <To save water, of course.>"
    new "1. <Para ahorrar agua, por supuesto.>"

    old "1. <What other reason would there be?>"
    new "1. <¿Qué otra razón habría?>"

    old "1. <We could share a bath under the stars before you take my soul.>"
    new "1. <Podríamos compartir un baño bajo las estrellas antes de que te lleves mi alma.>"

    old "1. <I'm looking forward to it.>"
    new "1. <Estoy deseando que llegue.>"

    old "1. <We shouldn't clash then. That's good!>"
    new "1. <Entonces no deberíamos coincidir. ¡Qué bien!>"

    old "1. <It's a little sad not to share sometimes, though.>"
    new "1. <Aunque a veces es un poco triste no compartirlo.>"

    old "1. <I don't mind showering in the evenings, I guess.>"
    new "1. <Supongo que no me importa ducharme por las tardes.>"

    old "1. <I was just saying we could shower together.>"
    new "1. <Solo decía que podíamos ducharnos juntos.>"

    old "1. <Like what, Grim?>"
    new "1. <¿Como qué, Parca?>"

    old "1. <You don't wanna shower with me?>"
    new "1. <¿No quieres ducharte conmigo?>"

    old "1. <I could wash your hair for you.>"
    new "1. <Podría lavarte el cabello.>"

    old "1. <I can't see your face, but I just know you're blushing hard.>"
    new "1. <No puedo ver tu cara, pero solo sé que te estás sonrojando.>"

    old "1. <Red right up to your ears.>"
    new "1. <Rojo hasta las orejas.>"

    old "1. <Hehehehe. I'm just kidding ;)>"
    new "1. <Jejejeje. Estoy bromeando ;)>"

    old "1. <Don't tell me you actually want to do it?>"
    new "1. <¿No me digas que realmente quieres hacerlo?>"

    old "1. <So you do?>"
    new "1. <¿Entonces sí?>"

    old "1. <You're a naughty boy, hehe.>"
    new "1. <Eres un chico travieso, jeje>"

    old "1. <You're the one making a big deal out of it.>"
    new "1. <Eres tú quien le está dando tanta importancia.>"

    old "1. <My little reaper... growing up so fast...>"
    new "1. <Mi parquita... creciendo tan rápido...>"

    old "1. <I'm always like this.>"
    new "1. <Siempre soy así.>"

    old "1. <Poor Grim. So easily flustered.>"
    new "1. <Pobre Parca. Se altera con tanta facilidad.>"

    old "1. <You're the one who won't tell me what I want to know.>"
    new "1. <Tú eres el que no me dice lo que quiero saber.>"

    old "1. <This is {i}your{/i} punishment.>"
    new "1. <Este es {i}tu{/i} castigo.>"

    old "1. <So, unless you have something to tell me...>"
    new "1. <Entonces, a menos que tengas algo que decirme...>"

    old "1. <I'll continue with your punishment!>"
    new "1. <¡Continuaré con tu castigo!>"

    old "1. <There we go!>"
    new "1. <¡Ahí vamos!>"

    old "1. <Well, obviously.>"
    new "1. <Bueno, obviamente.>"

    old "1. <So what do you mean then?>"
    new "1. <Entonces, ¿a qué te refieres entonces?>"

    old "1. <Am I secretly an immortal? Am I a Grim Reaper too?>"
    new "1. <¿Soy secretamente inmortal? ¿Soy una Parca también?>"

    old "1. <You seem to be having a hard time taking my soul, right?>"
    new "1. <Parece que estás teniendo dificultades para tomar mi alma, ¿verdad?>"

    old "1. <Maybe my immortality stops you!>"
    new "1. <¡Quizás mi inmortalidad te detiene!>"

    old "1. <I thought that was a good hypothesis.>"
    new "1. <Pensé que era una buena hipótesis.>"

    old "1. <You could say it a little more nicely...>"
    new "1. <Podrías decirlo de una manera un poco más amable...>"

    old "1. <The bully becomes the bullied...>"
    new "1. <El bully se convierte en el acosado...>"

    old "1. <Don't you mean '{i}in death{/i}'?>"
    new "1. <¿No querrás decir '{i}en la muerte{/i}'?>"

    old "1. <Since when are you a spokesperson on living?>"
    new "1. <¿Desde cuándo eres vocero de la vida?>"

    old "1. <I really hope so.>"
    new "1. <Realmente lo espero.>"

    old "1. <Mmmmm braaaains...>"
    new "1. <Mmmmm ceeeerebros...>"

    old "1. <You don't think I'm some mutant superhuman, do you?>"
    new "1. <¿No creerás que soy algún tipo de superhumano mutante, verdad?>"

    old "1. <Phew...>"
    new "1. <Uf...>"

    old "1. <You'll find that if either of us has something wrong with them, it's you.>"
    new "1. <Te darás cuenta de que si alguno de los dos tiene algún problema, ese eres tú.>"

    old "1. <And I told you, everyone has flaws.>"
    new "1. <Y te dije que todo el mundo tiene defectos.>"

    old "1. <You are so completely and utterly wrong it hurts.>"
    new "1. <Estás tan completamente equivocado que duele.>"

    old "1. <Grim, everyone has flaws.>"
    new "1. <Parca, todos tienen defectos.>"

    old "1. <Which is...?>"
    new "1. <¿Qué es...?>"

    old "1. <Are you being considerate of me right now Grim? :O>"
    new "1. <¿Estás siendo considerado conmigo ahora mismo, Parca? :O>"

    old "1. <Okay, now you're making me scared.>"
    new "1. <Bien, ahora me estás dando miedo.>"

    old "1. <So it's {i}very{/i} bad news...>"
    new "1. <Entonces son {i}muy{/i} malas noticias...>"

    old "1. <Am I dying?>"
    new "1. <¿Me estoy muriendo?>"

    old "1. <Oh god... Grim, I'm too young to die...>"
    new "1. <Oh Dios ... Parca, soy demasiado joven para morir...>"

    old "1. <It's worse than dying?!>"
    new "1. <¡¿Es peor que morir?!>"

    old "1. <My... soul? Is it broken?>"
    new "1. <¿Mi... alma? ¿Está rota?>"

    old "1. <Well, what would you say, then?>"
    new "1. <Bueno, ¿qué dirías, entonces?>"

    old "1. <Oi, Earthling to Grim!>"
    new "1. <¡Oye, Terrícola a Parca!>"

    old "1. <And I'm meant to just go on with my normal life?>"
    new "1. <¿Y se supone que debo seguir con mi vida normal?>"

    old "1. <{i}Pretty much{/i}?>"
    new "1. <¿{i}Más o menos{/i}?>"

    old "1. <Well... I guess you have a point, but still...>"
    new "1. <Bueno... Supongo que tienes razón, pero aun así...>"

    old "1. <But am I really okay to just keep going about my day to day life, like I know nothing?>"
    new "1. <¿Pero realmente está bien que siga con mi vida cotidiana como si nada?>"

    old "1. <There's no risk... right?>"
    new "1. <No hay riesgo... ¿verdad?>"

    old "1. <That doesn't answer my question!>"
    new "1. <¡Eso no responde mi pregunta!>"

    old "1. <[pet_name]!>"
    new "1. <¡[pet_name]!>"

    old "1. <Ah!>"
    new "1. <¡Ah!>"

    old "1. <For once you say something smart.>"
    new "1. <Por una vez dices algo inteligente.>"

    old "1. <Cuddles do always make things better :)>"
    new "1. <Los abrazos siempre mejoran las cosas :)>"

    old "1. <I bet you are.>"
    new "1. <Apuesto a que lo estás.>"

    old "1. <There's nothing to be ashamed of.>"
    new "1. <No hay nada de qué avergonzarse.>"

    old "1. <Even through the screen.>"
    new "1. <Incluso a través de la pantalla.>"

    old "1. <There's nothing wrong with jealousy.>"
    new "1. <No hay nada de malo en los celos.>"

    old "1. <Do you want a hug, too?>"
    new "1. <¿Quieres un abrazo también?>"

    old "1. <Are you suuure?>"
    new "1. <¿Estás seguuuro?>"

    old "1. <Sure thing! :)>"
    new "1. <¡Seguro! :)>"

    old "1. <YOUR mortal?>"
    new "1. <¿TU mortal?>"

    old "1. <Aww, you make it sound kinda nice.>"
    new "1. <Aww, lo haces sonar bastante bien.>"

    old "1. <You're my guardian angel!>"
    new "1. <¡Eres mi ángel guardián!>"

    old "1. <A devil in disguise as an angel, it's a little poetic.>"
    new "1. <Un demonio disfrazado de ángel, es un poco poético.>"

    old "1. <How do I know you don't smell?>"
    new "1. <¿Cómo sé que tú no hueles mal?>"

    old "1. <Orrrr... you could come prove it?>"
    new "1. <Oooo... ¿podrías venir a demostrarlo?>"

    old "1. <NGL the 'scent of death' sounds like it'd smell kinda bad.>"
    new "1. <Sinceramente, el 'aroma de la muerte' suena como si oliera bastante mal.>"

    old "1. <It sounds... earthy and rotting.>"
    new "1. <Suena ... terroso y podrido.>"

    old "1. <If you smell that strongly, I suggest you bathe.>"
    new "1. <Si hueles tan fuerte, te sugiero que te bañes.>"

    old "1. <You should work on the description of your scent some more.>"
    new "1. <Deberías mejorar un poco más la descripción de tu aroma.>"

    old "1. <ANYWAY!>"
    new "1. <¡DE TODOS MODOS!>"

    old "1. <This is all totally beside the point.>"
    new "1. <Todo esto no viene al caso.>"

    old "1. <I'm freaking out about my broken soul disease here.>"
    new "1. <Estoy enloqueciendo por mi enfermedad del alma rota.>"

    old "1. <Just go about my business...>"
    new "1. <Que solo siga con mis actividades...>"

    old "1. <Is that really safe?>"
    new "1. <¿Es realmente seguro?>"

    old "1. <What if I do something that puts my soul in danger?>"
    new "1. <¿Qué pasa si hago algo que ponga en peligro mi alma?>"

    old "1. <I suppose that makes sense...>"
    new "1. <Supongo que eso tiene sentido...>"

    old "1. <Your smug little attitude is annoying, but makes me a little less stressed, somehow.>"
    new "1. <Tu actitud engreída es molesta, pero de alguna manera me hace sentir un poco menos de estrés.>"

    old "1. <I'm not going to answer that.>"
    new "1. <No voy a responder eso.>"

    old "1. <So you think you know what's best for me?>"
    new "1. <¿Así que crees que sabes lo que es mejor para mí?>"

    old "1. <The guy trying to kill me knows best for me. Uh huh. Right.>"
    new "1. <El tipo que intenta matarme sabe lo que es mejor para mí. Uh huh. Claro.>"

    old "1. <That wasn't me agreeing.>"
    new "1. <Yo no estaba de acuerdo.>"

    old "1. <You're totally twisting the meaning of my words.>"
    new "1. <Estás tergiversando totalmente el significado de mis palabras.>"

    old "1. <Asshole.>"
    new "1. <Estúpido.>"

    old "1. <You're so annoying.>"
    new "1. <Eres tan molesto.>"

    old "1. <You're such a handful.>"
    new "1. <Eres tan difícil de manejar.>"

    old "1. <'{i}You suppose{/i}'!>"
    new "1. <¡'{i}Supones{/i}'!>"

    old "1. <What if I do something dangerous?>"
    new "1. <¿Qué pasa si hago algo peligroso?>"

    old "1. <Couldn't I make it worse?>"
    new "1. <¿No podría empeorarlo?>"

    old "1. <...For some reason, yes.>"
    new "1. <...Por alguna razón, sí.>"

    old "1. <Easily said...>"
    new "1. <Es fácil decirlo...>"

    old "1. <...That does actually make some amount of sense.>"
    new "1. <...En realidad, eso tiene cierto sentido.>"

    old "1. <Oh really?>"
    new "1. <¿Ah, de verdad?>"

    old "1. <You're always right, answer my math questions then.>"
    new "1. <Siempre tienes razón, responde mis preguntas de matemáticas entonces.>"

    old "1. <No using a calculator.>"
    new "1. <No usando una calculadora.>"

    old "1. <HUH???>"
    new "1. <¿¿¿EH???>"

    old "1. <You cheated!>"
    new "1. <¡Hiciste trampa!>"

    old "1. <You g**gled it!>"
    new "1. <¡Lo has g**gleado!>"

    old "1. <Look, maybe you got that right, but...>"
    new "1. <Mira, tal vez lo hiciste bien, pero...>"

    old "1. <You can't be right 100 percent of the time.>"
    new "1. <No puedes tener razón el 100 por ciento del tiempo.>"

    old "1. <The probability of that is almost zero!>"
    new "1. <¡La probabilidad de eso es casi cero!>"

    old "1. <All of that rubbish aside...>"
    new "1. <Dejando de lado todas esas tonterías...>"

    old "1. <How you feeling today?>"
    new "1. <¿Cómo te sientes hoy?>"

    old "1. <Why not?>"
    new "1. <¿Por qué no?>"

    old "1. <Am I not allowed to feel worried?>"
    new "1. <¿No puedo preocuparme?>"

    old "1. <Why would I not?>"
    new "1. <¿Por qué no lo haría?>"

    old "1. <You're being edgy again.>"
    new "1. <Estás siendo edgy de nuevo.>"

    old "1. <Yeah, edgy.>"
    new "1. <Sí, edgy.>"

    old "1. <You've got three days left, not including today.>"
    new "1. <Te quedan tres días, sin contar hoy.>"

    old "1. <Have you even been trying?>"
    new "1. <¿Lo has intentado siquiera?>"

    old "1. <I'd actually say it is.>"
    new "1. <De hecho, diría que lo es.>"

    old "1. <Anyway, we can worry about my impending doom later.>"
    new "1. <De todos modos, podemos preocuparnos por mi inminente perdición más tarde.>"

    old "1. <As is your health.>"
    new "1. <Como es tu salud.>"

    old "1. <Yup, totally don't care at all.>"
    new "1. <Sep, no me importa en absoluto.>"

    old "1. <You just said it's how a proper relationship should be!>"
    new "1. <¡Acabas de decir que así es como debe ser una relación adecuada!>"

    old "1. <Fine. I care a bit.>"
    new "1. <Bien. Me importa un poco.>"

    old "1. <So... are you back to normal, then?>"
    new "1. <Entonces... ¿ya estás de vuelta a la normalidad?>"

    old "1. <OKAY you could leave it at 'caring and considerate'???>"
    new "1. <OKEY, ¿¿¿'Podrías dejarlo en persona 'atenta y considerada'???>"

    old "1. <That wasn't a no. You'd probably like it.>"
    new "1. <Eso no fue un no. Probablemente te gustaría.>"

    old "1. <I could sit by your bedside and look after you.>"
    new "1. <Podría sentarme junto a tu cama y cuidarte.>"

    old "1. <I can't help but notice you didn't answer my question.>"
    new "1. <No puedo evitar notar que no respondiste a mi pregunta.>"

    old "1. <Which leads me to believe you would like it, actually.>"
    new "1. <Lo que me lleva a creer que te gustaría, en realidad.>"

    old "1. <Perhaps a lot.>"
    new "1. <Quizás mucho.>"

    old "1. <No need to get overly excited.>"
    new "1. <No hay necesidad de emocionarse demasiado.>"

    old "1. <Why? Because you like the idea of me doting on you, I guess.>"
    new "1. <¿Por qué? Porque te gusta la idea de que te consienta, supongo.>"

    old "1. <The offer always stands :)>"
    new "1. <La oferta sigue en pie :)>"

    old "1. <All you gotta do is ask me.>"
    new "1. <Solo tienes que pedírmelo.>"

    old "1. <You're really cute, you know?>"
    new "1. <Eres realmente lindo, ¿sabes?>"

    old "1. <You're blushing again, I bet.>"
    new "1. <Te estás sonrojando de nuevo, apuesto.>"

    old "1. <What is what?>"
    new "1. <¿Qué es qué?>"

    old "1. <It's a keyboard smash.>"
    new "1. <Es un golpe de teclado.>"

    old "1. <No, stupid.>"
    new "1. <No, estúpido.>"

    old "1. <You press keys on your keyboard to show that you're overcome with emotions.>"
    new "1. <Presionas las teclas del teclado para mostrar que te embargan las emociones.>"

    old "1. <The amount and type of letter don't matter.>"
    new "1. <La cantidad y el tipo de letras no importan.>"

    old "1. <Why don't you try?>"
    new "1. <¿Por qué no lo intentas?>"

    old "1. <Huh?>"
    new "1. <¿Huh?>"

    old "1. <Oh my god! Hahahaha!>"
    new "1. <¡Ay dios mío! ¡Jajajaja!>"

    old "1. <Why did you only do one letter?!>"
    new "1. <¡¿Por qué solo pusiste una letra?!>"

    old "1. <IT DOES IN THIS CASE.>"
    new "1. <EN ESTE CASO, SÍ.>"

    old "1. <Your mistakes are as cute as you.>"
    new "1. <Tus errores son tan lindos como tú.>"

    old "1. <When you're shy, you act so timid.>"
    new "1. <A veces eres realmente tímido.>"

    old "1. <It's not giving 'grim reaper' tbh.>"
    new "1. <La verdad, no da una sensación de 'parca'.>"

    old "1. <It IS cute though.>"
    new "1. <Sin embargo, ES lindo.>"

    old "1. <And miss out on your cute side? Nah.>"
    new "1. <¿Y perderme tu lado adorable? Nah.>"

    old "1. <I get such a kick out of your embarrassment, after all.>"
    new "1. <Después de todo, me divierte mucho verte en una situación incómoda.>"

    old "1. <Wait, you can curse people?>"
    new "1. <Espera, ¿puedes maldecir a la gente?>"

    old "1. <That's not an answer!>"
    new "1. <¡Esa no es una respuesta!>"

    old "1. <Nope. Tell me!>"
    new "1. <Nop. ¡Dime!>"

    old "1. <That's kinda lame. You could have pretended.>"
    new "1. <Eso es un poco patético. Podrías haber fingido.>"

    old "1. <You do keep saying that.>"
    new "1. <Siempre dices lo mismo.>"

    old "1. <Okay then. Lets test it..>"
    new "1. <Bien entonces. Vamos a probarlo.>"

    old "1. <If you had to pick between drinking a cup full of...>"
    new "1. <Si tuvieras que elegir entre beber una taza llena de...>"

    old "1. <Blended chillis or slightly off milk, which would you pick?>"
    new "1. <Chiles licuados o leche un poco pasada, ¿qué elegirías?>"

    old "1. <Well? What would you pick?>"
    new "1. <¿Bien? ¿Qué elegirías?>"

    old "1. <That's not how this works!>"
    new "1. <¡No es así como funciona esto!>"

    old "1. <You have to pick one!>"
    new "1. <¡Tienes que elegir una!>"

    old "1. <I'd pick the chilli smoothie ;)>"
    new "1. <Yo elegiría el batido de chile ;)>"

    old "1. <So you really aren't going to pick one?>"
    new "1. <¿De verdad no vas a elegir uno?>"

    old "1. <I suppose if you're unwell, either would make you feel worse.>"
    new "1. <Supongo que si no te sientes bien, cualquiera de las dos cosas te haría sentir peor.>"

    old "1. <You never answered. Are you feeling better?>"
    new "1. <Nunca respondiste. ¿Te sientes mejor?>"

    old "1. <Well, sounds like good news to me.>"
    new "1. <Bueno, me parece una buena noticia.>"

    old "1. <Maybe my presence is healing for you <3>"
    new "1. <Quizás mi presencia te esté ayudando a sanar <3>"

    old "1. <Ouch.>"
    new "1. <Auch.>"

    old "1. <But I know you don't mean it.>"
    new "1. <Pero sé que no lo dices en serio.>"

    old "1. <What made you unwell, anyway?>"
    new "1. <¿Qué te hizo sentir mal, de todos modos?>"

    old "1. <A soul can do that?>"
    new "1. <¿Un alma puede hacer eso?>"

    old "1. <What happens if you don't keep it balanced?>"
    new "1. <¿Qué pasa si no se mantiene el equilibrio?>"

    old "1. <A grim reaper can die?>"
    new "1. <¿Una parca puede morir?>"

    old "1. <You're not immortal?>"
    new "1. <¿No eres inmortal?>"

    old "1. <I just thought, since you represent death and stuff...>"
    new "1. <Solo pensé que, como representas a la muerte y esas cosas...>"

    old "1. <Plus the blood rushes to your face when you blush.>"
    new "1. <Además, la sangre te sube a la cara cuando te sonrojas.>"

    old "1. <That's proof enough.>"
    new "1. <Eso es prueba suficiente.>"

    old "1. <The taint?>"
    new "1. <¿La oscuridad?>"

    old "1. <The light?>"
    new "1. <¿La luz?>"

    old "1. <But you're just gonna take my soul anyway, right?>"
    new "1. <Pero vas a llevarte mi alma de todos modos, ¿verdad?>"

    old "1. <What does it matter if you tell me the truth?>"
    new "1. <¿Qué importa si me dices la verdad?>"

    old "1. <I'm good at listening :)>"
    new "1. <Se me da bien escuchar :)>"

    old "1. <It sounds complicated.>"
    new "1. <Suena complicado.>"

    old "1. <I'm glad you're feeling better, then.>"
    new "1. <Me alegro de que te sientas mejor, entonces.>"

    old "1. <I guess it was me after all :)>"
    new "1. <Supongo que fui yo después de todo :)>"

    old "1. <Wow. I didn't expect you to agree with me.>"
    new "1. <Wow. No esperaba que estuvieras de acuerdo conmigo.>"

    old "1. <I can think of one or two other ways we could become one.>"
    new "1. <Se me ocurren una o dos formas más en las que podríamos convertirnos en uno.>"

    old "1. <Oh, you actually wanna go there, huh.>"
    new "1. <Oh, realmente quieres llegar a eso, huh>"

    old "1. <We could...>"
    new "1. <Podríamos...>"

    old "1. <Share clothes!>"
    new "1. <¡Compartir ropa!>"

    old "1. <Honestly, yes.>"
    new "1. <Honestamente, sí.>"

    old "1. <Maybe that is what I mean, maybe not ;)>"
    new "1. <Quizás eso es lo que quiero decir, quizás no ;)>"

    old "1. <That's one way to get my soul.>"
    new "1. <Esa es una forma de conseguir mi alma.>"

    old "1. <We can take it nice and slow.>"
    new "1. <Podemos tomárnoslo con calma.>"

    old "1. <First I'll peel off your gloves, exposing the skin beneath.>"
    new "1. <Primero te quitaré los guantes, dejando al descubierto la piel.>"

    old "1. <I'll run my skin against yours, gently at first.>"
    new "1. <Deslizaré mi piel contra la tuya, al principio con suavidad.>"

    old "1. <Then clutch you tightly, using my thumb to rub you softly.>"
    new "1. <Luego te sujetaré con fuerza y te acariciaré suavemente con el pulgar.>"

    old "1. <Do I not?>"
    new "1. <¿Acaso no los cumplo?>"

    old "1. <Running away, huh?>"
    new "1. <Huyendo, ¿eh?>"

    old "1. <I'd probably be better at holding hands than you, anyway. >"
    new "1. <Probablemente, se me daría mejor tomar manos que a ti, de todos modos. >"

    old "1. <Not yet, unfortunately.>"
    new "1. <Todavía no, desafortunadamente.>"

    old "1. <By the way, I feel like I know the answer, but...>"
    new "1. <Por cierto, creo que sé la respuesta, pero...>"

    old "1. <Are you the reason such strange things keep happening to me every day?>"
    new "1. <¿Eres tú la razón por la que me siguen pasando cosas extrañas todos los días?>"

    old "1. <Uh, where to begin...>"
    new "1. <Uh, por dónde empezar...>"

    old "1. <Pianos falling from windows right in front of me?>"
    new "1. <¿Pianos cayendo por las ventanas justo delante de mí?>"

    old "1. <Why...?>"
    new "1. <¿Por qué...?>"

    old "1. <I just thought, you know...>"
    new "1. <Solo pensé, ya sabes...>"

    old "1. <A grim reaper would have a cooler way to take someone's soul.>"
    new "1. <Una parca tendría una forma más fría de tomar el alma de alguien.>"

    old "1. <Then why try to kill me?>"
    new "1. <Entonces, ¿por qué intentar matarme?>"

    old "1. <Why not wait for nature to take its course?>"
    new "1. <¿Por qué no esperar a que la naturaleza siga su curso?>"

    old "1. <So I'm supposed to be dead?>"
    new "1. <¿Entonces se supone que debía morir?>"

    old "1. <Says who?>"
    new "1. <¿Quién lo dice?>"

    old "1. <Maybe it's someone else with the same name.>"
    new "1. <Tal vez sea alguien más con el mismo nombre.>"

    old "1. <I dunno.>"
    new "1. <No se.>"

    old "1. <It would just explain some things, wouldn't it?>"
    new "1. <Eso explicaría algunas cosas, ¿no?>"

    old "1. <Desire?>"
    new "1. <¿Deseo?>"

    old "1. <Do you desire me in any other ways?>"
    new "1. <¿Me deseas de alguna otra manera?>"

    old "1. <Well, maybe fate isn't so absolute, then.>"
    new "1. <Bueno, tal vez el destino no sea tan absoluto, entonces.>"

    old "1. <I'm still here.>"
    new "1. <Todavía estoy aquí.>"

    old "1. <I'm alive.>"
    new "1. <Sigo con vida.>"

    old "1. <If fate was absolute, I'd be dead right now.>"
    new "1. <Si el destino fuera absoluto, ahora mismo estaría bajo tierra.>"

    old "1. <I was meant to die, and didn't.>"
    new "1. <Estaba escrito que muriera, pero no fue así.>"

    old "1. <Thanks to that, we met.>"
    new "1. <Gracias a eso, nos conocimos.>"

    old "1. <If anything is fate, perhaps that is.>"
    new "1. <Si hay algo que sea destino, tal vez sea eso.>"

    old "1. <Well, I'm happy to have met you.>"
    new "1. <Bueno, estoy feliz de haberte conocido.>"

    old "1. <Despite everything.>"
    new "1. <A pesar de todo.>"

    old "1. <You're really just trying to kill me in totally random ways.>"
    new "1. <En realidad solo estás tratando de matarme de formas totalmente aleatorias.>"

    old "1. <Is that how you usually do things?>"
    new "1. <¿Es así como sueles hacer las cosas?>"

    old "1. <Has anyone else ever needed a bit of a push?>"
    new "1. <¿Alguien más ha necesitado alguna vez un pequeño empujón?>"

    old "1. <That almost sounds romantic.>"
    new "1. <Eso casi suena romántico.>"

    old "1. <What the...>"
    new "1. <Qué demo...>"

    old "1. <What is that?>"
    new "1. <¿Qué es eso?>"

    old "1. <Obviously! But where did it come from?>"
    new "1. <¡Obviamente! ¿Pero de dónde salió?>"

    old "1. <Obviously it's you! Where did it come from?>"
    new "1. <>"

    old "1. <Did you... draw it yourself?>"
    new "1. <¿Lo dibujaste... tú mismo?>"

    old "1. <You have the time to message me.>"
    new "1. <Tienes tiempo para enviarme mensajes.>"

    old "1. <You commissioned someone?>"
    new "1. <¿Lo encargaste a alguien?>"

    old "1. <It's cute!>"
    new "1. <¡Es lindo!>"

    old "1. <Like, it's really GOOD... but it's still your face.>"
    new "1. <Es decir, está muy BIEN... pero sigue siendo tu cara.>"

    old "1. <I mean your face is a little stupid.>"
    new "1. <Quiero decir que tu cara es un poco estúpida.>"

    old "1. <Oh. Awkward...>"
    new "1. <Oh. Qué incómodo...>"

    old "1. <They're so round and cute!>"
    new "1. <¡Son tan redonditas y bonitas!>"

    old "1. <What about normal sized you?>"
    new "1. <¿Y él de tamaño normal?>"

    old "1. <You seem like the kind of guy who would like it.>"
    new "1. <Pareces el tipo de persona a la que le gustaría eso.>"

    old "1. <Anyway... you just sent a human a photo of yourself?>"
    new "1. <De todos modos... ¿acabas de enviarle una foto tuya a un humano?>"

    old "1. <It's not against your grim reaper rules?>"
    new "1. <¿No va en contra de tus reglas de la Parca?>"

    old "1. <So it is.>"
    new "1. <Así que lo es.>"

    old "1. <Are you bending the rules by talking to me?>"
    new "1. <¿Estás infringiendo las reglas al hablar conmigo?>"

    old "1. <Breaking all the rules for me then, huh?>"
    new "1. <¿Rompiendo todas las reglas por mí, eh?>"

    old "1. <Wow, breaking my heart over here.>"
    new "1. <Wow, me estás rompiendo el corazón.>"

    old "1. <Your boss!>"
    new "1. <¡A tu jefe!>"

    old "1. <You have a boss, right?>"
    new "1. <Tienes un jefe, ¿verdad?>"

    old "1. <I could start by programming a strange app and installing it on their computer...>"
    new "1. <Podría empezar por programar una aplicación extraña e instalarla en su computadora...>"

    old "1. <I'm doing it rn.>"
    new "1. <Lo estoy haciendo ahora mismo.>"

    old "1. <It's installing.>"
    new "1. <Se está instalando.>"

    old "1. <Nearly done. Any second now...>"
    new "1. <Ya casi termino. En cualquier momento...>"

    old "1. <It's installed.>"
    new "1. <Está instalada.>"

    old "1. <I'm starting to write them a message...>"
    new "1. <Estoy empezando a escribirles un mensaje...>"

    old "1. <I suppose I could just uninstall it...>"
    new "1. <Supongo que podría desinstalarla...>"

    old "1. <btw I never installed anything in the first place.>"
    new "1. <Por cierto, nunca instalé nada en primer lugar.>"

    old "1. <So you have that blushing emote...>"
    new "1. <Así que tienes ese emote de sonrojo...>"

    old "1. <Is there any more?>"
    new "1. <¿Hay más?>"

    old "1. <Did you pose when you took the photos?>"
    new "1. <¿Posaste cuando te sacaste las fotos?>"

    old "1. <OMG!>"
    new "1. <¡DIOS MÍO!>"

    old "1. <Then that means...>"
    new "1. <Entonces eso significa...>"

    old "1. <Then you actually... wow, this is making my day.>"
    new "1. <Entonces, en realidad... wow, esto me está alegrando el día.>"

    old "1. <They truly got your good side.>"
    new "1. <Realmente captaron tu mejor lado.>"

    old "1. <But wait a second...>"
    new "1. <Pero espera un momento...>"

    old "1. <Do you have a folder of secret selfies you've taken somewhere, Grim?>"
    new "1. <¿Tienes una carpeta con selfies secretas que te has tomado en algún lugar, Parca?>"

    old "1. <Wait, seriously?>"
    new "1. <Espera, ¿en serio?>"

    old "1. <Hold on... you said you posed for them, right?>"
    new "1. <Espera... dijiste que posaste para esa persona, ¿verdad?>"

    old "1. <Then that means you...>"
    new "1. <Entonces eso significa que...>"

    old "1. <You pouted in the picture?>"
    new "1. <¿Hiciste pucheros en la foto?>"

    old "1. <You should have sent it to me!>"
    new "1. <¡Deberías habérmelo enviado!>"

    old "1. <You do remember that I work as an artist full time right?>"
    new "1. <¿Recuerdas que trabajo como artista a tiempo completo, verdad?>"

    old "1. <I could have drawn it for you. For free, even.>"
    new "1. <Podría habértelo dibujado. Incluso gratis.>"

    old "1. <Definitely not trying to convince you not to take my soul here.>"
    new "1. <No estoy tratando de convencerte de que no te lleves mi alma aquí.>"

    old "1. <Oh, that's surprising coming from you.>"
    new "1. <Oh, eso es sorprendente viniendo de ti.>"

    old "1. <Still, my talents are at your command :)>"
    new "1. <Aun así, mis talentos están a tu disposición :)>"

    old "1. <So, can I see the photo?>"
    new "1. <Entonces, ¿puedo ver la foto?>"

    old "1. <Because I want to see it! >"
    new "1. <¡Porque quiero verla!>"

    old "1. <Oh, you know what?>"
    new "1. <Oh, ¿sabes qué?>"

    old "1. <Once again, I am proving to be an excellent problem solver.>"
    new "1. <Una vez más, estoy demostrando ser excelente resolviendo problemas.>"

    old "1. <Make sure you pick up, okay?>"
    new "1. <Asegúrate de contestar, ¿de acuerdo?>"

    old "1. <Pout, please!>"
    new "1. <¡Haz un puchero, por favor!>"

    old "1. <Go on, pout already.>"
    new "1. <Vamos, haz pucheros ya.>"

    old "1. <Then send me the picture instead.>"
    new "1. <Entonces envíame la foto.>"

    old "1. <Come on. I wanna see you pout.>"
    new "1. <Vamos. Quiero verte haciendo pucheros.>"

    old "1. <The emoji is cute - maybe the real thing isn't...?>"
    new "1. <El emoji es adorable - ¿pero tal vez el real no lo sea...?>"

    old "1. <Too bad...>"
    new "1. <Qué pena...>"

    old "1. <Yes!>"
    new "1. <¡Si!>"

    old "1. <{i}Pout{/i}.>"
    new "1. <{i}Hacer pucheros{/i}.>"

    old "1. <What did you just say?>"
    new "1. <¿Qué acabas de decir?>"

    old "1. <You didn't! You said cute!>"
    new "1. <¡No lo hiciste! ¡Dijiste que era adorable!>"

    old "1. <You said cuuuute.>"
    new "1. <Dijiste adoooorable.>"

    old "1. <Go on. I pouted for you, pout for me.>"
    new "1. <Vamos. Yo hice un puchero por ti, haz un puchero por mí.>"

    old "1. <Maybe I was.>"
    new "1. <Quizás fue así>"

    old "1. <Don't judge.>"
    new "1. <No juzgues.>"

    old "1. <Come here and make me.>"
    new "1. <Ven aquí y hazme hacerlo.>"

    old "1. <It's your turn. Pout already.>"
    new "1. <Te toca. Hacer pucheros ya.>"

    old "1. <{i}Grrr. I'm the Grim Reaper. I like being in \nthe dark. I'm edgy.{/i}>"
    new "1. <{i}Grrr. Soy la Parca. Me gusta estar en la \noscuridad. Soy edgy.{/i}>"

    old "1. <{i}You shouldn't come near me. I am death.{/i}>"
    new "1. <{i}No deberías acercarte a mí. Soy la muerte.{/i}>"

    old "1. <{i}No one in existence can replicate me.{/i}>"
    new "1. <{i}Nadie en el mundo puede imitarme.{/i}>"

    old "1. <{i}I'm too handsome, charismatic and smart \nfor a mortal to imitate me.{/i}>"
    new "1. <{i}Soy demasiado guapo, carismático e inteligente \npara que un mortal pueda imitarme.{/i}>"

    old "1. <You really do.>"
    new "1. <Sí que lo haces.>"

    old "1. <If you pout, maybe I'll copy you after, too.>"
    new "1. <Si pones morros, quizá yo también te imite después.>"

    old "1. <I see I'll have to take this up a notch.>"
    new "1. <Veo que tendré que subir el nivel.>"

    old "1. <Commencing phase one of trying to embarrass Grim.>"
    new "1. <Comenzando la fase uno de intentar humillar a Parca>"

    old "1. <I said pout, not look surprised.>"
    new "1. <He dicho que hagas pucheros, no que pongas cara de sorpresa.>"

    old "1. <I'm always insistent about things I want.>"
    new "1. <Siempre soy insistente con las cosas que quiero.>"

    old "1. <Alright, no need to judge.>"
    new "1. <Está bien, no hay necesidad de juzgar.>"

    old "1. <What would you pick? If you could have anything.>"
    new "1. <¿Qué elegirías? Si pudieras tener cualquier cosa.>"

    old "1. <Something other than my soul.>"
    new "1. <Algo distinto a mi alma.>"

    old "1. <A holiday?>"
    new "1. <¿Unas vacaciones?>"

    old "1. <Wait... have you never been on a holiday?>"
    new "1. <Espera... ¿nunca has tenido vacaciones?>"

    old "1. <Don't lie to me. There's no way \nyou've never had a holiday!>"
    new "1. <<No me mientas. ¡No puede ser que \nnunca hayas tenido vacaciones!>"

    old "1. <That can't be true.>"
    new "1. <Eso no puede ser cierto.>"

    old "1. <I suppose not, but it {i}might{/i} help me to get you to pout.>"
    new "1. <Supongo que no, pero {i}podría{/i} ayudarme a verte hacer pucheros.>"

    old "1. <More often than you'd think.>"
    new "1. <Más veces de las que crees.>"

    old "1. <Trade secrets, you know how it is.>"
    new "1. <Secretos comerciales, ya sabes cómo es.>"

    old "1. <...A secret one.>"
    new "1. <... Uno secreto.>"

    old "1. <You're right, they seem similar.>"
    new "1. <Tienes razón, parecen similares.>"

    old "1. <No, you? Sarcasm?>"
    new "1. <No, ¿tú? ¿Sarcasmo?>"

    old "1. <You seem like the kind of person who never feels guilty.>"
    new "1. <Pareces el tipo de persona que nunca se siente culpable.>"

    old "1. <That's a good question.>"
    new "1. <Buena pregunta>"

    old "1. <Do you have any guilty pleasures, Grim?>"
    new "1. <¿Tienes algún gusto culposo, Parca?>"

    old "1. <Sometimes I eat dessert before dinner.>"
    new "1. <A veces como postre antes de la cena.>"

    old "1. <That's what I think, too!>"
    new "1. <¡Yo también lo creo!>"

    old "1. <Now you're speaking my language.>"
    new "1. <Ahora sí que hablas mi idioma.>"

    old "1. <It's an app for short videos.>"
    new "1. <Es una aplicación para vídeos cortos.>"

    old "1. <I make videos on there sometimes.>"
    new "1. <A veces hago vídeos allí.>"

    old "1. <Good question.>"
    new "1. <Buena pregunta.>"

    old "1. <I feel like you'd be pretty popular on there, Grim.>"
    new "1. <Creo que serías muy popular ahí, Parca.>"

    old "1. <All of the comments would be like 'does he whimper'?>"
    new "1. <Todos los comentarios serían del tipo '¿está lloriqueando?'>"

    old "1. <You like {i}Christmas{/i}?>"
    new "1. <¿Te gusta la {i}Navidad{/i}?>"

    old "1. <Somehow that seems... wrong.>"
    new "1. <De alguna manera, eso parece... incorrecto.>"

    old "1. <Somehow I can't imagine you lying in \nbed watching MewTube videos.>"
    new "1. <De alguna manera no te imagino tumbado en la cama viendo vídeos de MewTube.>"

    old "1. <Apart from when you're talking to me.>"
    new "1. <Excepto cuando estás hablando conmigo.>"

    old "1. <It's your turn now.>"
    new "1. <Ahora te toca a ti.>"

    old "1. <Reality shows? Seriously?>"
    new "1. <¿Reality shows? ¿En serio?>"

    old "1. <You're funny, Grim.>"
    new "1. <Eres gracioso, Parca.>"

    old "1. <And stupid.>"
    new "1. <Y estúpido.>"

    old "1. <Don't lie. You have to know how stupid \nyou sound sometimes.>"
    new "1. <<No mientas. Tienes que saber lo estúpido  \nque suenas a veces.>"

    old "1. <You cannot?>"
    new "1. <¿No puedes?>"

    old "1. <Or you will not?>"
    new "1. <¿O no quieres?>"

    old "1. <Is this some weird Grim Reaper magic thing?>"
    new "1. <¿Es algún tipo de magia extraña de las Parcas?>"

    old "1. <Woah, okay... like actually?>"
    new "1. <Woah, vale... ¿en serio?>"

    old "1. <Oh, this is the best.>"
    new "1. <Oh, esto es lo mejor.>"

    old "1. <Oh, I can think of pleeenty of fun things \nto do with this information...>"
    new "1. <Oh, se me ocurren un montón de cosas divertidas \nque hacer con esta información...>"

    old "1. <Where to start, where to start.>"
    new "1. <Por dónde empezar, por dónde empezar.>"

    old "1. <Do you believe in love at first sight?>"
    new "1. <¿Crees en el amor a primera vista?>"

    old "1. <So is that a yes or a no?>"
    new "1. <¿Eso es un sí o un no?>"

    old "1. <Do you cuddle Azrael in bed?>"
    new "1. <¿Abrazas a Azrael en la cama?>"

    old "1. <Do you cuddle Azrael while you're in bed? \nYes or no, Grim.>"
    new "1. <¿Abrazas a Azrael mientras estás en la cama? \nSí o no, Parca>"

    old "1. <You do!>"
    new "1. <¡Lo haces!>"

    old "1. <No answer is still an answer!>"
    new "1. <¡No responder también es una respuesta!>"

    old "1. <That's so cute.>"
    new "1. <Qué lindo.>"

    old "1. <Yes?>"
    new "1. <¿Sí?>"

    old "1. <No, but I {i}am{/i} enjoying it anyway.>"
    new "1. <No, pero {i}yo{/i} lo estoy disfrutando de todos modos.>"

    old "1. <Grim cuddling his little teddy...>"
    new "1. <Parca abrazando a su peluche...>"

    old "1. <Oh wow, you're completely serious.>"
    new "1. <Oh wow, lo dices completamente en serio.>"

    old "1. <So, pineapple on pizza?>"
    new "1. <Entonces, ¿piña en la pizza?>"

    old "1. <You're so wrong it hurts.>"
    new "1. <Estás tan equivocado que duele.>"

    old "1. <Okay, Mister Pineapple-on-Pizza.>"
    new "1. <De acuerdo, señor Pizza-con-Piña.>"

    old "1. <I knew you were a smart man.>"
    new "1. <Sabía que eras un hombre inteligente.>"

    old "1. <Hmmm, then...>"
    new "1. <Mmmm, entonces...>"

    old "1. <Do you think I'm [pretty]?>"
    new "1. <¿Crees que soy [pretty!t]?>"

    old "1. <You can't pass!>"
    new "1. <¡No puedes pasar!>"

    old "1. <Then, do you think I'm [beautiful]?>"
    new "1. <Entonces, ¿crees que soy [beautiful!t]?>"

    old "1. <So... no?>"
    new "1. <Entonces... ¿no?>"

    old "1. <Ha...! Got you.>"
    new "1. <¡Ja...! Te pillé.>"

    old "1. <Do you think about me often?>"
    new "1. <¿Piensas en mí a menudo?>"

    old "1. <Have you ever been... in love?>"
    new "1. <¿Alguna vez has estado... enamorado?>"

    old "1. <You don't think so?>"
    new "1. <¿No lo crees?>"

    old "1. <Do you wish you could?>"
    new "1. <¿Te gustaría poder hacerlo?>"

    old "1. <Hmm... for the happiness it brings?>"
    new "1. <Hmm... ¿Por la felicidad que aporta?>"

    old "1. <Well, you don't.>"
    new "1. <Bueno, no la necesitas.>"

    old "1. <Lots of people are happy alone, and that's okay too.>"
    new "1. <Mucha gente es feliz sola, y eso también está bien.>"

    old "1. <I just thought you seemed... lonely.>"
    new "1. <Solo pensé que parecías... solitario.>"

    old "1. <Hmm, neither a yes nor a no, I see.>"
    new "1. <Hmm, ni sí ni no, ya veo.>"

    old "1. <Alright, alright, then...>"
    new "1. <Está bien, está bien, entonces...>"

    old "1. <Okay, have you ever kissed anyone?>"
    new "1. <Okey, ¿alguna vez has besado a alguien?>"

    old "1. <I have.>"
    new "1. <Yo sí>"

    old "1. <Then, have you—>"
    new "1. <Entonces, has—>"

    old "1. <I thought this was an infantile game?>"
    new "1. <¿Pensaba que este era un juego infantil?>"

    old "1. <Afraid? Of what?>"
    new "1. <¿Miedo? ¿De qué?>"

    old "1. <No, why would I be?>"
    new "1. <No, ¿por qué iba a tenerlo?>"

    old "1. <Well, I'm not.>"
    new "1. <Bueno, pues no lo tengo.>"

    old "1. <To be honest, this has been fun.>"
    new "1. <A decir verdad, esto ha sido divertido.>"

    old "1. <Will I even have anything left to do in life after \nchatting with the literal Grim Reaper for a week?>"
    new "1. <¿Me quedará algo por hacer en la vida después de charlar con la mismísima Parca durante una semana?>"

    old "1. <Kinda the coolest thing that's ever happened to me.>"
    new "1. <Es lo más chido que me ha pasado nunca.>"

    old "1. <But I think I'm more interested than scared.>"
    new "1. <Pero creo que me interesa más que me darme miedo.>"

    old "1. <You're kinda an interesting person, Grim.>"
    new "1. <Eres una persona interesante, Parca>"

    old "1. <No, really.>"
    new "1. <No, en serio.>"

    old "1. <Despite everything, I'm glad we met.>"
    new "1. <A pesar de todo, me alegro de haberte conocido.>"

    old "1. <Anyway, it's my turn again.>"
    new "1. <De todos modos, me toca otra vez.>"

    old "1. <What's your name?  Your real name.>"
    new "1. <¿Cómo te llamas? Tu nombre real.>"

    old "1. <Really? I thought that you were...>"
    new "1. <¿En serio? Pensaba que tú eras...>"

    old "1. <So you won't tell me?>"
    new "1. <¿Entonces no me lo dirás?>"

    old "1. <Unusual? How so?>"
    new "1. <¿Inusual? ¿En qué sentido?>"

    old "1. <Okay, this is a little suspicious.>"
    new "1. <Okey, esto es un poco sospechoso.>"

    old "1. <What did you do?>"
    new "1. <¿Qué has hecho?>"

    old "1. <Well, have you?>"
    new "1. <Bueno, ¿lo has hecho?>"

    old "1. <You {i}{b}what{/b}{/i}...?>"
    new "1. <¿Qué tu {i}{b}qué{/b}{/i}...?>"

    old "1. <You did what now?!>"
    new "1. <¿Qué has hecho qué?>"

    old "1. <But what exactly do you mean?>"
    new "1. <¿Pero qué quieres decir exactamente?>"

    old "1. <Uh... how about you take it back?>"
    new "1. <<Eh... ¿qué tal si la recuperas?>"

    old "1. <Come back and get it!>"
    new "1. <¡Vuelve a por eso!>"

    old "1. <It's like I'm carrying a piece of you around everywhere.>"
    new "1. <Es como si llevara una parte de ti conmigo a todas partes.>"

    old "1. <I don't mind, I kind of like it!>"
    new "1. <No me importa, ¡me gusta!>"

    old "1. <Well, your hypothesis is wrong, cause \nI think it's pretty cool.>"
    new "1. <Bueno, tu hipótesis es errónea, porque \ncreo que es bastante genial.>"

    old "1. <Thanks, my little reaper.>"
    new "1. <Gracias, mi pequeña parquita.>"

    old "1. <Another interesting truth from the man himself.>"
    new "1. <Otra interesante verdad, de boca del mismísimo.>"

    old "1. <Not little at all. I'm keeping that tidbit in my head.>"
    new "1. <No es nada pequeño. Voy a guardar ese dato en mi cabeza.>"

    old "1. <{i}Stare him down.{/i}>"
    new "1. <{i}Mírarlo fijamente.{/i}>"

    old "1. <{i}Stare even harder.{/i}>"
    new "1. <{i}Mírarlo aún más fijamente.{/i}>"

    old "1. <{i}Stare and wiggle your eyebrows.{/i}>"
    new "1. <{i}Mírarlo y mover las cejas.{/i}>"

    old "1. <You don't like it?>"
    new "1. <¿No te gusta?>"

    old "1. <Ah! So you do like it?>"
    new "1. <¡Ah! ¿Entonces sí te gusta?>"

    old "1. <Ah, so you do like it.>"
    new "1. <Ah, entonces sí te gusta.>"

    old "1. <{i}Wink again.{/i}>"
    new "1. <{i}Guiñar el ojo otra vez.{/i}>"

    old "1. <Only for you.>"
    new "1. <Solo por ti.>"

    old "1. <So, I can actually keep it?>"
    new "1. <Entonces, ¿puedo quedármelo?>"

    old "1. <Your... soul fragment?>"
    new "1. <¿Tu... fragmento de alma?>"

    old "1. <Ah... yeah...>"
    new "1. <Ah... sí...>"

    old "1. <Sorry for, you know...>"
    new "1. <Lo siento, ya sabes...>"

    old "1. <I should have, yes.>"
    new "1. Debería haberlo hecho, sí.<>"

    old "1. <I do... I didn't realize...>"
    new "1. <Sí... No me di cuenta...>"

    old "1. <It won't happen again.>"
    new "1. <No volverá a pasar.>"

    old "1. <I'll listen next time.>"
    new "1. <Lo siento mucho...>"

    old "1. <I promise..>"
    new "1. <Lo prometo...>"

    old "1. <Then your leftover soul... thing...>"
    new "1. <Entonces tu alma sobrante... esa cosa...>"

    old "1. <Are you going to use it to spy on me?>"
    new "1. <¿Vas a usarla para espiarme?>"

    old "1. <Will you...>"
    new "1. <¿Vas a...>"

    old "1. <Watch me while I sleep?>"
    new "1. <¿Mirarme mientras duermo?>"

    old "1. <Good, that'd be pretty creepy.>"
    new "1. <Bien, eso sería bastante raro.>"

    old "1. <Don't you, like... need that...?>"
    new "1. <¿No crees que... la necesitas...?>"

    old "1. <Have you been spying on me?>"
    new "1. <¿Me has estado espiando?>"

    old "1. <Then take it back already!>"
    new "1. <¡Entonces retírala ya!>"

    old "1. <So I just live with you spying on me forever?>"
    new "1. <¿Así que voy a vivir contigo espiándome para siempre?>"

    old "1. <Well that's... certainly reassuring.>"
    new "1. <Bueno, eso es... ciertamente tranquilizador.>"

    old "1. <I wouldn't say I belong to you.>"
    new "1. <No diría que te pertenezco.>"

    old "1. <Really? I feel pretty alive right now.>"
    new "1. <¿En serio? Justo ahora me siento bastante con vida.>"

    old "1. <We'll see about that, won't we?>"
    new "1. <Ya lo veremos, ¿no?>"

    old "1. <I might pass again, sorry.>"
    new "1. <Quizás vuelva a pasar, lo siento.>"

    old "1. <To be honest, I don't mind the idea, though.>"
    new "1. <Sinceramente, no me molesta la idea.>"

    old "1. <If anyone was going to lay claim to me, \nI'd rather it be you.>"
    new "1. <Si alguien va a reclamarme, prefiero que seas tú.>"

    old "1. <I kinda like you, for some reason.>"
    new "1. <Por alguna razón, me caes bien.>"

    old "1. <You can't just lay claim on people without \nasking them first, Grimmy.>"
    new "1. <No puedes reclamar a la gente sin preguntarles \nprimero, Parquita.>"

    old "1. <What if one of your other reaper friends sees?>"
    new "1. <¿Y si alguno de tus otros amigos parca lo ve?>"

    old "1. <Won't that be bad news for you?>"
    new "1. <¿No sería eso malo para ti?>"

    old "1. <How romantic.>"
    new "1. <Qué romántico.>"

    old "1. <You exist to take souls, right?>"
    new "1. <Existes para llevarte almas, ¿verdad?>"

    old "1. <Mine in particular.>"
    new "1. <La mía en particular.>"

    old "1. <Kinda seems like I have a hold on you already.>"
    new "1. <Parece que ya te tengo en mis manos.>"

    old "1. <Sure, but you aren't death. You're you.>"
    new "1. <Claro, pero tú no eres la muerte. Tú eres tú.>"

    old "1. <You bring death and guide souls.>"
    new "1. <Tú traes la muerte y guías las almas.>"

    old "1. <You aren't death itself, in my opinion.>"
    new "1. <En mi opinión, no eres la muerte en sí.>"

    old "1. <So, I think I do have somewhat of a claim on you.>"
    new "1. <Entonces, creo que tengo cierto derecho sobre ti.>"

    old "1. <Do you want me to?>"
    new "1. <¿Quieres que lo haga?>"

    old "1. <I can't think of a better fate for you.>"
    new "1. <No se me ocurre un destino mejor para ti.>"

    old "1. <Both of us have kinda shitty fates, huh?>"
    new "1. <Los dos tenemos un destino bastante malo, ¿no?>"

    old "1. <We're two peas in a pod.>"
    new "1. <Somos como dos gotas de agua.>"

    old "1. <I'm what?>"
    new "1. <¿Qué soy?>"

    old "1. <You can't just leave without telling me \nwhat you were going to say!>"
    new "1. <¡No puedes irte sin decirme lo que ibas a decir!>"

    old "1. <Booo.>"
    new "1. <Buuu.>"

    old "1. <Huh? No, I didn't mean...>"
    new "1. <¿Eh? No, no quería decir...>"

    old "1. <You know what? Fine.>"
    new "1. <¿Sabes qué? Está bien.>"

    old "1. <I'll get you next time.>"
    new "1. <La próxima vez te atraparé.>"

    old "1. <I suppose I don't have much choice.>"
    new "1. <Supongo que no tengo otra opción.>"

    old "1. <Night Grim!>"
    new "1. <¡Buenas noches Parca!>"

    old "2. <Any news, Grim?>"
    new "2. <¿Alguna noticia, Parca?>"

    old "2. <There you are!>"
    new "2. <¡Ahí estás!>"

    old "2. <Yeah, I think about you a lot. What about it?>"
    new "2. <Sí, pienso mucho en ti. ¿Y qué?>"

    old "2. <I like the idea of you being literal death.>"
    new "2. <Me gusta la idea de que seas literalmente la muerte.>"

    old "2. <Maybe you're not a very good Grim Reaper after all...>"
    new "2. <Quizás no seas tan buena Parca después de todo...>"

    old "2. <Oh, this is awkward...>"
    new "2. <Oh, qué incómodo...>"

    old "2. <Never >:D>"
    new "2. <Nunca >:D>"

    old "2. <I love you. You are the dumbest person I've ever met.>"
    new "2. <Te amo. Eres la persona más tonta que he conocido.>"

    old "2. <I mean I love you.>"
    new "2. <Quiero decir, te amo.>"

    old "2. <Take it how you will ;)>"
    new "2. <Tómalo como quieras ;)>"

    old "2. <You call that nagging?>"
    new "2. <¿A eso le llamas regañar?>"

    old "2. <Oh really?>"
    new "2. <¿Ah, de verdad?>"

    old "2. <Very adorable!>"
    new "2. <¡Muy adorable!>"

    old "2. <We both know that's not true.>"
    new "2. <Los dos sabemos que eso no es cierto.>"

    old "2. <Do you even do any work?>"
    new "2. <¿Incluso trabajas?>"

    old "2. <Does pookie need a lil cuddle?>"
    new "2. <¿Pookie necesita un poquito de cariño?>"

    old "2. <I don't waaant to.>"
    new "2. <No quieroooo.>"

    old "2. <Dirty name for a dirty boy.>"
    new "2. <Nombre sucio para un chico sucio.>"

    old "2. <Come on, I'm curious.>"
    new "2. <Vamos, tengo curiosidad.>"

    old "2. <A little night time shower to wash away my soul's impurities.>"
    new "2. <Una pequeña ducha nocturna para limpiar las impurezas de mi alma.>"

    old "2. <Mornings only for me.>"
    new "2. <Mañanas solo para mí.>"

    old "2. <Tsk tsk, cheeky Grim.>"
    new "2. <Tsk tsk, Parca descarada.>"

    old "2. <I do like a guy who knows what he wants, though.>"
    new "2. <Sin embargo, me gustan los hombres que saben lo que quieren.>"

    old "2. <I just feel like messing with you.>"
    new "2. <Solo tengo ganas de molestarte.>"

    old "2. <Wow, you just came out and said it.>"
    new "2. <Wow, lo acabas de decir sin rodeos.>"

    old "2. <Or maybe I'm a flesh eating zombie on my way to munch you.>"
    new "2. <O tal vez soy un zombi devorador de carne que va a por ti para devorarte.>"

    old "2. <It was just a thought!>"
    new "2. <¡Solo era una idea!>"

    old "2. <Grim being nice? What has the world come to...>"
    new "2. <¿Parca siendo amable? ¿A dónde ha llegado el mundo...?>"

    old "2. <Then what exactly {i}is{/i} wrong with it?>"
    new "2. <Entonces, ¿qué exactamente {i}está{/i} mal?>"

    old "2. <Come onnnn... tell me...>"
    new "2. <Vamoooos... dime...>"

    old "2. <What if my soul combusts or something because I overwork myself?>"
    new "2. <¿Qué pasa si mi alma se quema o algo así por trabajar demasiado?>"

    old "2. <I can feel it radiating off of you.>"
    new "2. <Puedo sentirlo irradiando de ti.>"

    old "2. <But you {i}want{/i} one,  don't you?>"
    new "2. <Pero tú {i}quieres{/i} uno, ¿no?>"

    old "2. <Great... I'm dying of broken soul disease...>"
    new "2. <Genial... Me estoy muriendo de la enfermedad del alma rota...>"

    old "2. <You're sweeping me off my feet here, Grimmy.>"
    new "2. <Me estás dejando sin aliento, Parquita.>"

    old "2. <You started off so well for a second there...>"
    new "2. <Por un momento, habías empezado muy bien...>"

    old "2. <It sounds.... sour and just entirely... unpleasant.>"
    new "2. <Suena... agrio y totalmente... desagradable.>"

    old "2. <Eh, seeing as you don't think it's such a big deal, maybe it's not...>"
    new "2. <Eh, ya que no crees que sea para tanto, quizá no lo sea...>"

    old "2. <Ha! What a load of crap!>"
    new "2. <¡Ja! ¡Qué tontería!>"

    old "2. <No. But I'm sure you'll give it to me anyway.>"
    new "2. <No. Pero seguro que me la darás de todos modos.>"

    old "2. <I'll do whatever I want.>"
    new "2. <Haré lo que quiera.>"

    old "2. <I'm just curious, I'm not actually worried.>"
    new "2. <Solo tengo curiosidad, en realidad no me preocupa.>"

    old "2. <...I'm kidding. I do kinda care.>"
    new "2. <...Estoy bromeando. Me importa un poco.>"

    old "2. <Because you are a babygirl and want me to dedicate all my time to you.>"
    new "2. <Porque eres una babygirl y quieres que te dedique todo mi tiempo.>"

    old "2. <You're really timid sometimes.>"
    new "2. <A veces eres realmente tímido.>"

    old "2. <Why would I ever do that?>"
    new "2. <¿Por qué haría yo eso?>"

    old "2. <I'm strong. I'd go the milk.>"
    new "2. <Soy fuerte. Yo elegiría la leche.>"

    old "2. <Well, I suppose that's fair.>"
    new "2. <Bueno, supongo que es justo.>"

    old "2. <Wait, you're not already dead?>"
    new "2. <Espera, ¿no estás ya muerto?>"

    old "2. <I'm glad I don't have to do all of that to live.>"
    new "2. <Me alegro de no tener que hacer todo eso para vivir.>"

    old "2. <At least you're okay now!>"
    new "2. <¡Al menos estás bien ahora!>"

    old "2. <Fantastic work on my part.>"
    new "2. <Fantástico trabajo de mi parte.>"

    old "2. <They look cool, I can't lie.>"
    new "2. <Se ve genial, lo admito.>"

    old "2. <I bet you wouldn't mind a glimpse at me, either.>"
    new "2. <Apuesto a que a ti tampoco te importaría mirarme.>"

    old "2. <Hold hands ;)>"
    new "2. <Tomarnos de la mano ;)>"

    old "2. <I was trying to make you flustered, actually.>"
    new "2. <En realidad, estaba tratando de ponerte nervioso.>"

    old "2. <You never know what will happen in the future.>"
    new "2. <Nunca se sabe lo que sucederá en el futuro.>"

    old "2. <Actually, I had a question.>"
    new "2. <De hecho, tenía una pregunta.>"

    old "2. <There's a LOT.>"
    new "2. <Hay MUCHAS cosas.>"

    old "2. <Trains getting derailed?>"
    new "2. <¿Trenes descarrilándose?>"

    old "2. <Knowing you, probably not.>"
    new "2. <Conociéndote, probablemente no.>"

    old "2. <Is this a confession?>"
    new "2. <¿Eso es una confesión?>"

    old "2. <Does it have something to do with 'fate'?>"
    new "2. <¿Tiene algo que ver con el 'destino'?>"

    old "2. <I don't know how to feel about that...>"
    new "2. <No sé cómo sentirme al respecto...>"

    old "2. <Wait a second...>"
    new "2. <Espera un segundo...>"

    old "2. <And here I thought it was supposed to be me...>"
    new "2. <y yo que pensaba que se suponía que era yo...>"

    old "2. <It looks a little stupid.>"
    new "2. <Se ve un poco tonto.>"

    old "2. <What if I tell on you?> {font=gui/starthings.ttf}a{/font}"
    new "2. <¿Y si te delato?> {font=gui/starthings.ttf}a{/font}"

    old "2. <For my little meowmeow, I guess I can stop...>"
    new "2. <Por mi pequeño miaumiau, supongo que puedo parar...>"

    old "2. <But back to that cute little chibi...>"
    new "2. <Pero volvamos a ese pequeño y adorable chibi...>"

    old "2. <Oh, that's just hilarious.>"
    new "2. <Oh, eso es muy gracioso.>"

    old "2. <Your little pouty blush... cute.>"
    new "2. <Tu puchero y tus mejillas sonrojadas... qué lindo.>"

    old "2. <Start pouting, pretty boy.>"
    new "2. <Empieza a hacer pucheros, chico guapo.>"

    old "2. <Absolutely.>"
    new "2. <Por supuesto.>"

    old "2. <{i}Pull an ugly face{/i}.>"
    new "2. <{i}Poner una cara fea{/i}.>"

    old "2. <That's how you get what you want!> {font=gui/starthings.ttf}a{/font}"
    new "2. <¡Así es como consigues lo que quieres!>"

    old "2. <I think that much dessert might make me sick.>"
    new "2. <Creo que tanto postre me podría enfermar.>"

    old "2. <I scroll down TokTik too much.>"
    new "2. <Me paso demasiado tiempo navegando por TokTik.>"

    old "2. <I just watch the videos, though.>"
    new "2. <Sin embargo, solo veo los videos.>"

    old "2. <That is SO unlike you.>"
    new "2. <Eso NO es propio de ti.>"

    old "2. <This is going to be fun.>"
    new "2. <Esto va a ser divertido.>"

    old "2. <There's nothing wrong with that.>"
    new "2. <No hay nada de malo en eso.>"

    old "2. <Finally, someone that sees sense.>"
    new "2. <Por fin, alguien con sentido común.>"

    old "2. <I haven't, actually.>"
    new "2. <En realidad, no.>"

    old "2. <I think it would be stupid to not be a little scared.>"
    new "2. <Creo que sería una tontería no sentir un poco de miedo.>"

    old "2. <Pardon....?>"
    new "2. <¿Perdón...?>"

    old "2. <What the hell...>"
    new "2. <Qué demonios...>"

    old "2. <{i}Wink and stick your tongue out.{/i}>"
    new "2. <{i}Guiñar el ojo y sacar la lengua.{/i}>"

    old "2. <I really am sorry...>"
    new "2. <Lo siento mucho...>"

    old "2. <Watch me getting changed...?>"
    new "2. <¿Me ves mientras me cambio...?>"

    old "2. <I wouldn't mind if you did.>"
    new "2. <No me importaría si lo hicieras.>"

    old "2. <I don't mind being owned by you, Grimmy.>"
    new "2. <No me importa que seas mi dueño, Parquita.>"

    old "2. <This whole conversation is so silly.>"
    new "2. <Toda esta conversación es tan tonta.>"

    old "2. <We'll see, little reaper.>"
    new "2. <Ya veremos, pequeña parquita.>"

    old "2. <Laaame.>"
    new "2. <Abuuurrido.>"

    old "2. <Talk later, Grim!>"
    new "2. <¡Hablamos luego, Parca!>"

    old "3. <How's it going for my favorite Grim Reaper?> {font=gui/starthings.ttf}a{/font}"
    new "3. <>"

    old "3. <You'd like it if you were, wouldn't you?>"
    new "3. <>"

    old "3. <Too busy to talk to me, huh...>"
    new "3. <Demasiado ocupado para hablar conmigo, eh...>"

    old "3. <A sweetie!>"
    new "3. <¡Una dulzura!>"

    old "3. <Try harder :D>"
    new "3. <Esfuérzate más :D>"

    old "3. <How indecent...>"
    new "3. <Qué indecente...>"

    old "3. <There is not!>"
    new "3. <¡No lo es!>"

    old "3. <Grim...>"
    new "3. <Parca...>"

    old "3. <You're capable of making jokes, Grim? :O>"
    new "3. <¿Eres capaz de hacer bromas, Parca? :O>"

    old "3. <But what does it change for me?>"
    new "3. <¿Pero qué cambia eso para mí?>"

    old "3. <I can nurse you back to health :D> {font=gui/starthings.ttf}a{/font}"
    new "3. <Puedo cuidarte hasta que te recuperes :D> {font=gui/starthings.ttf}a{/font}"

    old "3. <You do the same for me.>"
    new "3. <Tú haces lo mismo por mí.>"

    old "3. <Right, ever since we became one.> {font=gui/starthings.ttf}a{/font}"
    new "3. <Bien, desde que nos convertimos en uno.> {font=gui/starthings.ttf}a{/font}"

    old "3. <Or we could just undress you->"
    new "3. <O simplemente podríamos desvestirte->"

    old "3. <A shame, really.>"
    new "3. <Una pena, de verdad.>"

    old "3. <A fire at work?>"
    new "3. <¿Un incendio en el trabajo?>"

    old "3. <Maybe we were supposed to meet.> {font=gui/starthings.ttf}a{/font}"
    new "3. <Quizás estábamos destinados a conocernos.> {font=gui/starthings.ttf}a{/font}"

    old "3. <Well, don't I feel special.>"
    new "3. <Bueno, no me siento especial.>"

    old "3. <I want to squeeze its cheeks.> {font=gui/starthings.ttf}a{/font}"
    new "3. <Quiero apretar sus mejillas.>"

    old "3. <Fantastic.>"
    new "3. <Fantástico.>"

    old "3. <So I can add it to my collection ;)>"
    new "3. <Para poder añadirlo a mi colección ;)>"

    old "3. <It's very important.>"
    new "3. <Es muy importante.>"

    old "3. <{i}Try to make a face like Grim{/i}.>"
    new "3. <{i}Intentar poner una cara como la de Parca{/i}>"

    old "3. <I listen to the same song on repeat for \nhours sometimes.>"
    new "3. <A veces escucho la misma canción en \nrepetición durante horas.>"

    old "3. <I can't imagine you in a Christmas hat.>"
    new "3. <No puedo imaginarte con un gorro de Navidad.>"

    old "3. <Little reaper, maybe you shouldn't \nhave told me that.> {font=gui/starthings.ttf}a{/font}"
    new "3. <Parquita, tal vez no debiste decirme eso.>"

    old "3. <Sorry Grim, I don't kiss and tell.>"
    new "3. <Lo siento, Parca, yo no beso y lo cuento.>"

    old "3. <That sounds a little... uh... suggestive.> {font=gui/starthings.ttf}a{/font}"
    new "3. <Eso suena un poco... eh... sugerente.> {font=gui/starthings.ttf}a{/font}"

    old "3. <Well, I guess you can leave it there.> {font=gui/starthings.ttf}a{/font}"
    new "3. <Bueno, supongo que puedes dejarla ahí.> {font=gui/starthings.ttf}a{/font}"

    old "3. <Watch me while I work?>"
    new "3. <¿Me observas mientras trabajo?>"

    old "3. <Maybe I've laid claim on {i}you{/i}, instead.> {font=gui/starthings.ttf}a{/font}"
    new "3. <Quizás, en cambio, haya reclamado mi derecho sobre {i}ti{/i}.> {font=gui/starthings.ttf}a{/font}"

    old "3. <Tease...>"
    new "3. <Provocador...>"

    old "3. <G'night, cutie.>"
    new "3. <Buenas noches, bombón.>"

    old "4. <If I don't ask, I bet you won't tell me.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Si no te lo pregunto, seguro que no me lo dirás.> {font=gui/starthings.ttf}a{/font}"

    old "4. <Don't just stop talking now.>"
    new "4. <No dejes de hablar ahora.>"

    old "4. <You say that...>"
    new "4. <Dices eso...>"

    old "4. <That's true.>"
    new "4. <Eso es cierto.>"

    old "4. <I'm almost jealous.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Casi siento celos.> {font=gui/starthings.ttf}a{/font}"

    old "4. <I'll pout for you, too!> {font=gui/starthings.ttf}a{/font}"
    new "4. <¡Yo también haré pucheros por ti!> {font=gui/starthings.ttf}a{/font}"

    old "4. <Three words. MewTube conspiracy videos.>"
    new "4. <Tres palabras. videos conspirativos de MewTube.>"

    old "azrael is the cutest."
    new "azrael es el más lindo."