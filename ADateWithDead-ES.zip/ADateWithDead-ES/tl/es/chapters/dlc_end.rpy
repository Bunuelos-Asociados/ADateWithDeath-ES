
# game/chapters/dlc_end.rpyc:21
translate es dlcend_start_ce6326d9:

    # center_text "You woke up early this morning feeling particularly well rested."
    center_text "Te has despertado temprano esta mañana con una sensación especial de descanso."

# game/chapters/dlc_end.rpyc:22
translate es dlcend_start_f9385cf7:

    # center_text "No one came for your soul in the night, which means..."
    center_text "Nadie vino por tu alma durante la noche, lo que significa que..."

# game/chapters/dlc_end.rpyc:23
translate es dlcend_start_b25b7a28:

    # center_text "Today is the final day of your bet!"
    center_text "¡Hoy es el día final de tu apuesta!"

# game/chapters/dlc_end.rpyc:24
translate es dlcend_start_3331b1c7:

    # center_text "You almost can't contain your excitement. After all, you seem to have this in the bag."
    center_text "Casi no puedes contener tu emoción. Después de todo, parece que esto ya está ganado."

# game/chapters/dlc_end.rpyc:25
translate es dlcend_start_9aea9fc5:

    # center_text "You decide not to go out anywhere today - safer to stay at home and ride out your win."
    center_text "Decides no salir a ningún lado hoy - es más seguro quedarte en casa y esperar tu victoria."

# game/chapters/dlc_end.rpyc:26
translate es dlcend_start_d6f1731b:

    # center_text "It's still early in the morning as you wait for the eventual message from your own personal Grim Reaper."
    center_text "Aún es temprano en la mañana mientras esperas el eventual mensaje de tu propio Parca personal."

# game/chapters/dlc_end.rpyc:61
translate es day7_start_DLCend_cd8b3d94:

    # GR "mortal. are you there?"
    GR "mortal. ¿estás ahí?"

# game/chapters/dlc_end.rpyc:62
translate es day7_start_DLCend_cf3393ea:

    # GR "i know you do not have work today. and that you have no plans."
    GR "sé que no tienes trabajo hoy. y que no tienes planes."

# game/chapters/dlc_end.rpyc:63
translate es day7_start_DLCend_a2d29268:

    # GR "do you ever have plans?"
    GR "¿alguna vez tienes planes?"

# game/chapters/dlc_end.rpyc:64
translate es day7_start_DLCend_dbe4ce9a:

    # GR "anyway, respond to my message."
    GR "de todos modos, responde mi mensaje."

# game/chapters/dlc_end.rpyc:68
translate es day7_start_DLCend_a79232c2:

    # player "For all you know, I could have loads of plans."
    player "Por lo que tú sabes, podría tener montones de planes."

# game/chapters/dlc_end.rpyc:70
translate es day7_start_DLCend_fb4bc934:

    # GR "do you?"
    GR "¿los tienes?"

# game/chapters/dlc_end.rpyc:74
translate es day7_start_DLCend_93666768:

    # player "Nope."
    player "Nop."

# game/chapters/dlc_end.rpyc:76
translate es day7_start_DLCend_bb63e097:

    # GR "good. it seems i am correct once again."
    GR "bien. parece que tengo razón una vez más."

# game/chapters/dlc_end.rpyc:77
translate es day7_start_DLCend_883acae5:

    # GR "which is fortunate, because... i have been thinking."
    GR "lo cual es afortunado, porque... he estado pensando."

# game/chapters/dlc_end.rpyc:81
translate es day7_start_DLCend_5da51fb2:

    # player "About the way you're gonna lose our bet today?"
    player "¿Sobre la forma en que vas a perder nuestra apuesta hoy?"

# game/chapters/dlc_end.rpyc:83
translate es day7_start_DLCend_f1f41847:

    # GR "about how to make us both winners."
    GR "sobre cómo hacer que ambos seamos ganadores."

# game/chapters/dlc_end.rpyc:87
translate es day7_start_DLCend_94264231:

    # player "That's loser talk."
    player "Eso suena a charla de perdedor."

# game/chapters/dlc_end.rpyc:89
translate es day7_start_DLCend_dd5abbea:

    # player "You can't beat me!"
    player "¡No puedes ganarme!"

# game/chapters/dlc_end.rpyc:91
translate es day7_start_DLCend_c1998cc5:

    # GR "shut up for a second."
    GR "cállate un segundo."

# game/chapters/dlc_end.rpyc:92
translate es day7_start_DLCend_056679dc:

    # GR "i have been thinking... all night, in fact. i got no sleep at all."
    GR "he estado pensando... toda la noche, de hecho. no dormí nada."

# game/chapters/dlc_end.rpyc:93
translate es day7_start_DLCend_a0a5562a:

    # GR "thinking, studying, poring over books..."
    GR "pensando, estudiando, revisando libros..."

# game/chapters/dlc_end.rpyc:97
translate es day7_start_DLCend_f5a210f6:

    # player "Many books in the Underworld, Casper?"
    player "¿Muchos libros en el Inframundo, Casper?"

# game/chapters/dlc_end.rpyc:99
translate es day7_start_DLCend_2921dee1:

    # GR "plenty. we also have a fantastic public library."
    GR "muchos. también tenemos una biblioteca pública fantástica."

# game/chapters/dlc_end.rpyc:103
translate es day7_start_DLCend_381c905b:

    # player "That somehow doesn't fit with what I was expecting."
    player "Eso no encaja exactamente con lo que esperaba."

# game/chapters/dlc_end.rpyc:105
translate es day7_start_DLCend_cfaef452:

    # GR "you are getting off track."
    GR "te estás desviando del tema."

# game/chapters/dlc_end.rpyc:106
translate es day7_start_DLCend_b93dc99e:

    # GR "as i said yesterday, your soul is incomplete because you keep giving parts of it away."
    GR "como dije ayer, tu alma está incompleta porque sigues entregando partes de ella."

# game/chapters/dlc_end.rpyc:107
translate es day7_start_DLCend_42f05f00:

    # GR "something that is... usually not possible for a mortal."
    GR "algo que... normalmente no es posible para un mortal."

# game/chapters/dlc_end.rpyc:108
translate es day7_start_DLCend_50e4392b:

    # GR "that answered some of my questions."
    GR "eso respondió algunas de mis preguntas."

# game/chapters/dlc_end.rpyc:109
translate es day7_start_DLCend_282b70e9:

    # GR "why your soul seemed to feel so strange, how you managed to take my soul sickness away..."
    GR "por qué tu alma parecía tan extraña, cómo lograste quitarme la enfermedad del alma..."

# game/chapters/dlc_end.rpyc:110
translate es day7_start_DLCend_f2471d4b:

    # GR "but it didn't answer enough. i have so many more questions."
    GR "pero no respondió lo suficiente. tengo muchas más preguntas."

# game/chapters/dlc_end.rpyc:111
translate es day7_start_DLCend_207ffc15:

    # GR "i found the answer."
    GR "encontré la respuesta."

# game/chapters/dlc_end.rpyc:115
translate es day7_start_DLCend_0f5f02ca:

    # player "!!!"
    player "!!!"

# game/chapters/dlc_end.rpyc:119
translate es day7_start_DLCend_ca2087c9:

    # player "Lay it on me, Casper!"
    player "¡Dímela, Casper!"

# game/chapters/dlc_end.rpyc:121
translate es day7_start_DLCend_026bf5ab:

    # GR "[playerfirstname!l], you embody life just as i embody death."
    GR "[playerfirstname!l], tú encarnas la vida, así como yo encarnó la muerte."

# game/chapters/dlc_end.rpyc:125
translate es day7_start_DLCend_c237b9ba:

    # player "...?"
    player "...?"

# game/chapters/dlc_end.rpyc:127
translate es day7_start_DLCend_46c9b84d:

    # GR "my research lead me to a rare trait that shows... maybe only every thousand or so years in a mortal."
    GR "mi investigación me llevó a un rasgo raro que aparece... quizá solo cada mil años o algo así en un mortal."

# game/chapters/dlc_end.rpyc:128
translate es day7_start_DLCend_c48cea89:

    # GR "you have the touch of life on your soul."
    GR "tienes el toque de la vida en tu alma."

# game/chapters/dlc_end.rpyc:129
translate es day7_start_DLCend_f676de59:

    # GR "you {i}are{/i} life, so to speak."
    GR "tú {i}eres{/i} vida, por así decirlo."

# game/chapters/dlc_end.rpyc:130
translate es day7_start_DLCend_a4b099f0:

    # GR "that is why i have not been able to take your soul."
    GR "por eso no he podido tomar tu alma."

# game/chapters/dlc_end.rpyc:131
translate es day7_start_DLCend_9a3ba732:

    # GR "that is how you avoid death without a thought."
    GR "así es como evitas la muerte sin pensarlo."

# game/chapters/dlc_end.rpyc:132
translate es day7_start_DLCend_5ebaedf1:

    # GR "that is why you can heal as you do."
    GR "por eso puedes sanar como lo haces."

# game/chapters/dlc_end.rpyc:133
translate es day7_start_DLCend_fac7ad14:

    # GR "you are special. you've always been special."
    GR "eres especial. siempre has sido especial."

# game/chapters/dlc_end.rpyc:137
translate es day7_start_DLCend_03775ec8:

    # player "..."
    player "..."

# game/chapters/dlc_end.rpyc:141
translate es day7_start_DLCend_5b23d895:

    # player "So I'm immortal now?"
    player "¿Así que ahora soy inmortal?"

# game/chapters/dlc_end.rpyc:143
translate es day7_start_DLCend_b0aec41a:

    # GR "i don't know. it's possible?"
    GR "no lo sé. ¿es posible?"

# game/chapters/dlc_end.rpyc:144
translate es day7_start_DLCend_31ade300:

    # GR "it would explain a lot."
    GR "eso explicaría muchas cosas."

# game/chapters/dlc_end.rpyc:145
translate es day7_start_DLCend_e1e3bc38:

    # GR "but that's... also beside the point."
    GR "pero eso... también es irrelevante."

# game/chapters/dlc_end.rpyc:146
translate es day7_start_DLCend_940b64c0:

    # GR "after i found this out, i kept thinking about our bet and my role in your demise."
    GR "después de descubrir esto, seguí pensando en nuestra apuesta y en mi papel en tu fallecimiento."

# game/chapters/dlc_end.rpyc:147
translate es day7_start_DLCend_5966cb2d:

    # GR "but what if it could be... different?"
    GR "¿pero y si pudiera ser... diferente?"

# game/chapters/dlc_end.rpyc:152
translate es day7_start_DLCend_d62015a5:

    # player "Not dying would be preferable."
    player "No morir sería preferible."

# game/chapters/dlc_end.rpyc:154
translate es day7_start_DLCend_2bfa1046:

    # GR "yes, well, that much is obvious."
    GR "sí, bueno, eso es obvio."

# game/chapters/dlc_end.rpyc:155
translate es day7_start_DLCend_524b1a2c:

    # GR "your abilities have... merit. and your soul is not that of an ordinary mortal."
    GR "tus habilidades tienen... mérito. y tu alma no es la de un mortal común."

# game/chapters/dlc_end.rpyc:156
translate es day7_start_DLCend_2475552b:

    # GR "so maybe... maybe it could work..."
    GR "así que tal vez... tal vez podría funcionar..."

# game/chapters/dlc_end.rpyc:157
translate es day7_start_DLCend_f1ba3880:

    # GR "i admit maybe it would actually be helpful."
    GR "admito que tal vez realmente sería útil."

# game/chapters/dlc_end.rpyc:158
translate es day7_start_DLCend_035d39dd:

    # GR "and that i... may enjoy your company."
    GR "y que yo... podría disfrutar de tu compañía."

# game/chapters/dlc_end.rpyc:159
translate es day7_start_DLCend_7156c38a:

    # GR "maybe doing it together would be quite nice, actually."
    GR "quizás hacerlo juntos sería bastante agradable, de hecho."

# game/chapters/dlc_end.rpyc:163
translate es day7_start_DLCend_067cec17:

    # player "You want to do {i}what{/i} together, exactly?"
    player "¿Quieres hacer {i}qué{/i} juntos, exactamente?"

# game/chapters/dlc_end.rpyc:166
translate es day7_start_DLCend_859a7f70:

    # player "What are you rambling about, little reaper?"
    player "¿Qué estás divagando, parquita?"

# game/chapters/dlc_end.rpyc:167
translate es day7_start_DLCend_f30f9a3a:

    # GR "have patience. i am getting to it."
    GR "ten paciencia. estoy llegando a eso."

# game/chapters/dlc_end.rpyc:171
translate es day7_start_DLCend_c279d763:

    # player "Me, patience? You're the one who's impatient here."
    player "¿Yo, paciencia? Aquí el impaciente eres tú."

# game/chapters/dlc_end.rpyc:173
translate es day7_start_DLCend_9053eaa7:

    # GR "you will find i can be patient when it suits me."
    GR "verás que puedo ser paciente cuando me conviene."

# game/chapters/dlc_end.rpyc:178
translate es day7_start_DLCend_59085f78:

    # player "Which is pretty much never."
    player "Lo cual es casi nunca."

# game/chapters/dlc_end.rpyc:182
translate es day7_start_DLCend_a74cbcfb:

    # player "I bet I could teach you a thing or two about patience."
    player "Apuesto a que podría enseñarte una o dos cosas sobre la paciencia."

# game/chapters/dlc_end.rpyc:184
translate es day7_start_DLCend_eeddffe2:

    # GR "i doubt there is much for you to teach me on any matter."
    GR "dudo que haya mucho que puedas enseñarme sobre cualquier tema."

# game/chapters/dlc_end.rpyc:188
translate es day7_start_DLCend_5788eb86:

    # player "Ha. You're funny, Grimmy."
    player "Ja. Eres gracioso, Parquita."

# game/chapters/dlc_end.rpyc:189
translate es day7_start_DLCend_4f5b9e5f:

    # GR "resorting to that ugly nickname, i see..."
    GR "recurriendo a ese feo apodo, ya veo..."

# game/chapters/dlc_end.rpyc:192
translate es day7_start_DLCend_ac86ff8d:

    # player "Wroooong."
    player "Incoooorrecto."

# game/chapters/dlc_end.rpyc:195
translate es day7_start_DLCend_618c4634:

    # player "There is always more to learn."
    player "Siempre hay algo nuevo que aprender."

# game/chapters/dlc_end.rpyc:196
translate es day7_start_DLCend_9af2b7c5:

    # GR "perhaps for you."
    GR "tal vez para ti."

# game/chapters/dlc_end.rpyc:200
translate es day7_start_DLCend_143c1b4c:

    # player "Pffffft..."
    player "Pffffft..."

# game/chapters/dlc_end.rpyc:201
translate es day7_start_DLCend_68dda5ef:

    # GR "...is this another keyboard smash of yours?"
    GR "¿...es otro de tus golpeteos de teclado?"

# game/chapters/dlc_end.rpyc:204
translate es day7_start_DLCend_edaaa9e6:

    # player "What? No."
    player "¿Qué? No."

# game/chapters/dlc_end.rpyc:207
translate es day7_start_DLCend_b2b7b9ec:

    # player "It's a 'pfffft' sound."
    player "Es un sonido de 'pfffft'."

# game/chapters/dlc_end.rpyc:210
translate es day7_start_DLCend_f905fce7:

    # player "Another thing I'm teaching you, I suppose."
    player "Otra cosa que te estoy enseñando, supongo."

# game/chapters/dlc_end.rpyc:213
translate es day7_start_DLCend_84427c7a:

    # player "I'm sure there's plenty I could teach you."
    player "Seguro que hay mucho que podría enseñarte."

# game/chapters/dlc_end.rpyc:216
translate es day7_start_DLCend_183616e9:

    # player "We'll do patience first. For obvious reasons."
    player "Empezaremos con la paciencia. Por razones obvias."

# game/chapters/dlc_end.rpyc:219
translate es day7_start_DLCend_778c53b1:

    # player "And then we can revisit your typing issues."
    player "Y luego podemos revisar tus problemas al escribir."

# game/chapters/dlc_end.rpyc:220
translate es day7_start_DLCend_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/dlc_end.rpyc:223
translate es day7_start_DLCend_1f7f0b3e:

    # player "You haven't capitalized anything you've typed since the first day we met."
    player "No has puesto mayúsculas en nada de lo que escribes desde el primer día que nos conocimos."

# game/chapters/dlc_end.rpyc:226
translate es day7_start_DLCend_36216dd4:

    # player "Are you still embarrassed?"
    player "¿Todavía estás avergonzado?"

# game/chapters/dlc_end.rpyc:227
translate es day7_start_DLCend_cd107817:

    # GR "One Such As Me Never Gets Embarrassed."
    GR "Alguien Como Yo Nunca Se Avergüenza."

# game/chapters/dlc_end.rpyc:230
translate es day7_start_DLCend_b482c48d:

    # player "Awww."
    player "Awww."

# game/chapters/dlc_end.rpyc:232
translate es day7_start_DLCend_05cd85b1:

    # GR "You Know What."
    GR "Sabes Qué."

# game/chapters/dlc_end.rpyc:233
translate es day7_start_DLCend_eb0a6e8d:

    # GR "I Take Back What I Was Saying Above."
    GR "Retiro Lo Que Estaba Diciendo Arriba."

# game/chapters/dlc_end.rpyc:234
translate es day7_start_DLCend_c7629e38:

    # GR "Maybe It Won't Work."
    GR "Tal Vez No Funcione."

# game/chapters/dlc_end.rpyc:235
translate es day7_start_DLCend_1b708dd8:

    # GR "Forget Workarounds. I Will Just Come Take Your Soul."
    GR "Olvida Los Rodeos. Iré A Tomar Tu Alma Directamente."

# game/chapters/dlc_end.rpyc:238
translate es day7_start_DLCend_b7b7e2e7:

    # player "Your Typing Is Making Me Laugh."
    player "Tu forma de escribir me está haciendo reír."

# game/chapters/dlc_end.rpyc:239
translate es day7_start_DLCend_80555b69:

    # GR "You Just Said I Don't Capitalize Anything."
    GR "Acabas De decir Que No Pongo Mayúsculas En Nada."

# game/chapters/dlc_end.rpyc:240
translate es day7_start_DLCend_3f639731:

    # GR "So I Am Just Showing You I Can."
    GR "Así Que Solo Te Estoy Mostrando Que Puedo Hacerlo."

# game/chapters/dlc_end.rpyc:243
translate es day7_start_DLCend_4d91bc8d:

    # player "Yeah I get it, you know where the caps button on your keyboard is."
    player "Sí, ya entiendo, sabes dónde está el botón de mayúsculas en tu teclado."

# game/chapters/dlc_end.rpyc:246
translate es day7_start_DLCend_ddcaf73e:

    # player "Just not how to use it correctly."
    player "Solo que no sabes usarlo correctamente."

# game/chapters/dlc_end.rpyc:247
translate es day7_start_DLCend_97b94c06:

    # GR "I can do it correctly."
    GR "Puedo usarlo correctamente."

# game/chapters/dlc_end.rpyc:248
translate es day7_start_DLCend_19d77412:

    # GR "I have just choosen not to."
    GR "Solo he elegido no hacerlo."

# game/chapters/dlc_end.rpyc:251
translate es day7_start_DLCend_a74b37c4:

    # player "Nope, that's even weirder coming from you!"
    player "¡Nop, eso suena aún más raro viniendo de ti!"

# game/chapters/dlc_end.rpyc:253
translate es day7_start_DLCend_45254149:

    # GR "Then I shall continue it."
    GR "Entonces continuaré."

# game/chapters/dlc_end.rpyc:257
translate es day7_start_DLCend_35490fa9:

    # player "You're so stubborn."
    player "Eres tan terco."

# game/chapters/dlc_end.rpyc:259
translate es day7_start_DLCend_5ec96e39:

    # GR "Thank you."
    GR "Gracias."

# game/chapters/dlc_end.rpyc:263
translate es day7_start_DLCend_ae9881a6:

    # player "But winding back here a little..."
    player "Pero volviendo un poco atrás..."

# game/chapters/dlc_end.rpyc:267
translate es day7_start_DLCend_ac6922a5:

    # player "What's this workaround?"
    player "¿Cuál es esa alternativa?"

# game/chapters/dlc_end.rpyc:269
translate es day7_start_DLCend_66832d47:

    # GR "Are you quite attached to your place in the mortal realm?"
    GR "¿Estás muy apegado a tu lugar en el reino mortal?"

# game/chapters/dlc_end.rpyc:273
translate es day7_start_DLCend_e2e28da3:

    # player "Ahhhh..."
    player "Ahhhh..."

# game/chapters/dlc_end.rpyc:276
translate es day7_start_DLCend_6ea09659:

    # player "Talk about a loaded question."
    player "Vaya pregunta trampa."

# game/chapters/dlc_end.rpyc:279
translate es day7_start_DLCend_10b753f5:

    # player "Well... not really."
    player "Bueno... no realmente."

# game/chapters/dlc_end.rpyc:280
translate es day7_start_DLCend_e3f2860f:

    # GR "An ideal answer for both of us."
    GR "Una respuesta ideal para ambos."

# game/chapters/dlc_end.rpyc:281
translate es day7_start_DLCend_2d58dfc4:

    # GR "Good. This may work out just fine."
    GR "Bien. Puede que esto funcione perfectamente."

# game/chapters/dlc_end.rpyc:284
translate es day7_start_DLCend_a0cecd1a:

    # player "You're being a little suspicious right now."
    player "Estás siendo un poco sospechoso ahora mismo."

# game/chapters/dlc_end.rpyc:287
translate es day7_start_DLCend_44ef408b:

    # player "What exactly do you mean by that?"
    player "¿A qué te refieres exactamente con eso?"

# game/chapters/dlc_end.rpyc:290
translate es day7_start_DLCend_9c608d0b:

    # player "Of course I am."
    player "Por supuesto que lo estoy."

# game/chapters/dlc_end.rpyc:293
translate es day7_start_DLCend_6b81d4db:

    # player "How could I not be?"
    player "¿Cómo no habría de estarlo?"

# game/chapters/dlc_end.rpyc:294
translate es day7_start_DLCend_b8735adb:

    # GR "Would there be a way to convince you to be..."
    GR "¿Habría alguna forma de convencerte de que..."

# game/chapters/dlc_end.rpyc:295
translate es day7_start_DLCend_97d73d23:

    # GR "A little less attached to it, maybe?"
    GR "le tengas menos apego a ese lugar, tal vez?"

# game/chapters/dlc_end.rpyc:298
translate es day7_start_DLCend_04682c99:

    # player "Depends, how convincing can you be?"
    player "Depende, ¿qué tan convincente puedes ser?"

# game/chapters/dlc_end.rpyc:301
translate es day7_start_DLCend_78a01b47:

    # player "I think I fall in the middle."
    player "Creo que estoy en un punto intermedio."

# game/chapters/dlc_end.rpyc:302
translate es day7_start_DLCend_8ff27366:

    # GR "I can work with that."
    GR "Puedo trabajar con eso."

# game/chapters/dlc_end.rpyc:303
translate es day7_start_DLCend_02c4b0f1:

    # GR "So if I were to ask you to be a little more... indifferent."
    GR "Entonces, si te pidiera que fueras un poco más... indiferente."

# game/chapters/dlc_end.rpyc:304
translate es day7_start_DLCend_475827db:

    # GR "Do you think that would be possible?"
    GR "¿Crees que sería posible?"

# game/chapters/dlc_end.rpyc:307
translate es day7_start_DLCend_6111c7ac:

    # player "Hmmm."
    player "Hmmm."

# game/chapters/dlc_end.rpyc:310
translate es day7_start_DLCend_1fda99b7:

    # player "You're being mighty suspicious at the moment."
    player "Estás siendo muy sospechoso en este momento."

# game/chapters/dlc_end.rpyc:312
translate es day7_start_DLCend_41ed6cfb:

    # GR "To be frank with you..."
    GR "Para serte franco..."

# game/chapters/dlc_end.rpyc:315
translate es day7_start_DLCend_1c765b19:

    # player "No, you're Casper."
    player "No, tú eres Casper."

# game/chapters/dlc_end.rpyc:316
translate es day7_start_DLCend_f3b1f875:

    # GR "......"
    GR "......"

# game/chapters/dlc_end.rpyc:317
translate es day7_start_DLCend_a09f9ddf:

    # GR "I think... taking your soul is a waste."
    GR "Creo... que tomar tu alma sería un desperdicio."

# game/chapters/dlc_end.rpyc:320
translate es day7_start_DLCend_35e7d369:

    # player "A waste?"
    player "¿Un desperdicio?"

# game/chapters/dlc_end.rpyc:323
translate es day7_start_DLCend_c2d74f20:

    # player "What do you mean?"
    player "¿Qué quieres decir?"

# game/chapters/dlc_end.rpyc:326
translate es day7_start_DLCend_86c49df4:

    # player "Won't you get in trouble for not taking it?"
    player "¿No te meterás en problemas por no tomarla?"

# game/chapters/dlc_end.rpyc:330
translate es day7_start_DLCend_1f8114ef:

    # player "Ah! So you {i}have{/i} given up!"
    player "¡Ah! ¡Así que {i}sí{/i} te has rendido!"

# game/chapters/dlc_end.rpyc:331
translate es day7_start_DLCend_d9ce1dcf:

    # GR "No. Just listen."
    GR "No. Solo escucha."

# game/chapters/dlc_end.rpyc:332
translate es day7_start_DLCend_15bb4d3d:

    # GR "Or well, read."
    GR "O bueno, lee."

# game/chapters/dlc_end.rpyc:336
translate es day7_start_DLCend_5525817f:

    # player "Does this have anything to do with the fact you're madly in love with me?"
    player "¿Tiene esto algo que ver con el hecho de que estás locamente enamorado de mí?"

# game/chapters/dlc_end.rpyc:338
translate es day7_start_DLCend_cc21bd84:

    # GR "!!!"
    GR "!!!"

# game/chapters/dlc_end.rpyc:339
translate es day7_start_DLCend_cb04af41:

    # GR "w... what are you talking about, mortal..."
    GR "q... qué estás diciendo, mortal..."

# game/chapters/dlc_end.rpyc:343
translate es day7_start_DLCend_1cc3613a:

    # player "You said it yesterday, right?"
    player "Lo dijiste ayer, ¿no?"

# game/chapters/dlc_end.rpyc:347
translate es day7_start_DLCend_869e463a:

    # player "You like me. You want to hate me, but you can't."
    player "Te gusto. Quieres odiarme, pero no puedes."

# game/chapters/dlc_end.rpyc:351
translate es day7_start_DLCend_1b97c256:

    # player "So you've been sitting there all night thinking of how to save me."
    player "Así que has estado sentado ahí toda la noche pensando en cómo salvarme."

# game/chapters/dlc_end.rpyc:353
translate es day7_start_DLCend_dc1b78ad:

    # GR "............."
    GR "............."

# game/chapters/dlc_end.rpyc:357
translate es day7_start_DLCend_533a9717:

    # player "No?"
    player "¿No?"

# game/chapters/dlc_end.rpyc:359
translate es day7_start_DLCend_aafe4c17:

    # GR "i... am perhaps a little... swayed by that..."
    GR "yo... quizá estoy un poco... influenciado por eso..."

# game/chapters/dlc_end.rpyc:363
translate es day7_start_DLCend_159fc660:

    # player "You're so embarrassed you went back to typing like that, huh?"
    player "Estás tan avergonzado que volviste a escribir así, ¿eh?"

# game/chapters/dlc_end.rpyc:364
translate es day7_start_DLCend_281646c9:

    # GR "ugh!"
    GR "¡ugh!"

# game/chapters/dlc_end.rpyc:365
translate es day7_start_DLCend_3ac10d2c:

    # GR "{image=grumpy}"
    GR "{image=grumpy}"

# game/chapters/dlc_end.rpyc:366
translate es day7_start_DLCend_b7be1d1f:

    # GR "do you want to hear about the loophole or not?!"
    GR "¿quieres o no oír sobre el vacio legal?!"

# game/chapters/dlc_end.rpyc:370
translate es day7_start_DLCend_800fb37c:

    # player "I'd love to."
    player "Me encantaría."

# game/chapters/dlc_end.rpyc:372
translate es day7_start_DLCend_5ea041ab:

    # player "Yeah, what's taking you so long?"
    player "Sí, ¿qué te está tomando tanto tiempo?"

# game/chapters/dlc_end.rpyc:374
translate es day7_start_DLCend_87a7091b:

    # GR "...it would allow you to keep what remains of your soul."
    GR "...te permitiría conservar lo que queda de tu alma."

# game/chapters/dlc_end.rpyc:377
translate es day7_start_DLCend_19056b92:

    # player "And that loophole involves me winning our bet?"
    player "¿Y ese vacio implica que yo gane nuestra apuesta?"

# game/chapters/dlc_end.rpyc:378
translate es day7_start_DLCend_34fc4f41:

    # GR "well, i said before it was like us both winning, but..."
    GR "bueno, dije antes que era como si ambos ganáramos, pero..."

# game/chapters/dlc_end.rpyc:379
translate es day7_start_DLCend_214a6f47:

    # GR "it's more like we'd both lose."
    GR "es más bien como si ambos perdiéramos."

# game/chapters/dlc_end.rpyc:380
translate es day7_start_DLCend_8e940ad2:

    # GR "you can keep your soul, and i'll keep mine."
    GR "tú puedes conservar tu alma, y yo conservaré la mía."

# game/chapters/dlc_end.rpyc:383
translate es day7_start_DLCend_9b0ad46a:

    # player "Damn. I was really hoping to get your soul."
    player "Maldición. Realmente esperaba conseguir tu alma."

# game/chapters/dlc_end.rpyc:386
translate es day7_start_DLCend_e8836e38:

    # player "I had so many plans..."
    player "Tenía tantos planes..."

# game/chapters/dlc_end.rpyc:387
translate es day7_start_DLCend_fd414063:

    # GR "that... is a terrifying thought."
    GR "eso... es un pensamiento aterrador."

# game/chapters/dlc_end.rpyc:390
translate es day7_start_DLCend_bd1732d3:

    # player ":D"
    player ":D"

# game/chapters/dlc_end.rpyc:394
translate es day7_start_DLCend_ca188a1b:

    # player "So, what's the loophole?"
    player "Entonces, ¿cuál es el vacio legal?"

# game/chapters/dlc_end.rpyc:395
translate es day7_start_DLCend_893381d1:

    # GR "do you remember when you allowed me into your head?"
    GR "¿recuerdas cuando me permitiste entrar en tu mente?"

# game/chapters/dlc_end.rpyc:398
translate es day7_start_DLCend_bac0247b:

    # player "It's not something that is easily forgotten, Grim."
    player "No es algo que se olvide fácilmente, Parca."

# game/chapters/dlc_end.rpyc:400
translate es day7_start_DLCend_6bd97f64:

    # player "Of course I do."
    player "Por supuesto que lo recuerdo."

# game/chapters/dlc_end.rpyc:401
translate es day7_start_DLCend_c2f8f7f0:

    # GR "i think it would work in a similar manner."
    GR "creo que funcionaría de una manera similar."

# game/chapters/dlc_end.rpyc:402
translate es day7_start_DLCend_1ead4aa1:

    # GR "i'll merge my conscious with yours again."
    GR "fusionaré mi conciencia con la tuya otra vez."

# game/chapters/dlc_end.rpyc:403
translate es day7_start_DLCend_dfba2528:

    # GR "it would be a similar process, but a different outcome."
    GR "sería un proceso similar, pero con un resultado diferente."

# game/chapters/dlc_end.rpyc:406
translate es day7_start_DLCend_e70a0812:

    # player "Um."
    player "Um."

# game/chapters/dlc_end.rpyc:409
translate es day7_start_DLCend_e23af2b1:

    # player "Can I just stop you for a second..."
    player "¿Puedo detenerte un segundo...?"

# game/chapters/dlc_end.rpyc:412
translate es day7_start_DLCend_a97ccc47:

    # player "What exactly are you planning to do?"
    player "¿Qué es exactamente lo que planeas hacer?"

# game/chapters/dlc_end.rpyc:414
translate es day7_start_DLCend_50b02868:

    # player "I'm getting a little bit confused."
    player "Me estas confundiendo un poco."

# game/chapters/dlc_end.rpyc:417
translate es day7_start_DLCend_79b539b7:

    # player "I don't mind going along with it, but..."
    player "No me molesta seguirte el juego, pero..."

# game/chapters/dlc_end.rpyc:419
translate es day7_start_DLCend_39ba0cf0:

    # player "I'm all for doing some crazy shit, but..."
    player "Estoy a favor de hacer locuras, pero..."

# game/chapters/dlc_end.rpyc:422
translate es day7_start_DLCend_48b2c882:

    # player "But I'd like to know what I'm agreeing to first."
    player "Pero me gustaría saber a qué estoy accediendo primero."

# game/chapters/dlc_end.rpyc:423
translate es day7_start_DLCend_988a7a25:

    # GR "it seems i was getting ahead of myself."
    GR "parece que me estaba adelantando."

# game/chapters/dlc_end.rpyc:424
translate es day7_start_DLCend_0b16bee0:

    # GR "ahem."
    GR "ejem."

# game/chapters/dlc_end.rpyc:453
translate es call1_daydlcend_2ba5529e:

    # GRC "Sunshine."
    GRC "Solecito."

# game/chapters/dlc_end.rpyc:460
translate es call1_daydlcend_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/dlc_end.rpyc:465
translate es call1_daydlcend_d390a80e:

    # GRC "...Shut up. I don't blush over something so... insignificant."
    GRC "...Cállate. No me sonrojo por algo tan... insignificante."

# game/chapters/dlc_end.rpyc:473
translate es call1_daydlcend_feaf2053:

    # GRC "You answered."
    GRC "Respondiste."

# game/chapters/dlc_end.rpyc:486
translate es call1_daydlcend_c7d7ed4f:

    # GRC "Back to my nickname, I see."
    GRC "Volviendo a mi apodo, ya veo."

# game/chapters/dlc_end.rpyc:494
translate es call1_daydlcend_a3dfa21d:

    # GRC "Yes, well, I... also... ahem... don't mind it..."
    GRC "Sí, bueno, yo... también... ejem... no me molesta..."

# game/chapters/dlc_end.rpyc:496
translate es call1_daydlcend_d3e40e22:

    # GRC "Troublesome little human."
    GRC "Pequeño humano problemático."

# game/chapters/dlc_end.rpyc:505
translate es call1_daydlcend_1e32c9b5:

    # GRC "I am not little."
    GRC "No soy pequeño."

# game/chapters/dlc_end.rpyc:510
translate es call1_daydlcend_45262ba5:

    # GRC "That's so much worse."
    GRC "Eso lo empeora aún más."

# game/chapters/dlc_end.rpyc:520
translate es call1_daydlcend_95e590f7:

    # GRC "Well."
    GRC "Bien."

# game/chapters/dlc_end.rpyc:522
translate es call1_daydlcend_6aee8012:

    # GRC "You seem to be quite adventurous for a human."
    GRC "Pareces bastante aventurero para ser humano."

# game/chapters/dlc_end.rpyc:523
translate es call1_daydlcend_0bb452cd:

    # GRC "Or at least quite... daring."
    GRC "O al menos bastante... audaz."

# game/chapters/dlc_end.rpyc:524
translate es call1_daydlcend_9b9cf870:

    # GRC "And definitely rather stupid."
    GRC "Y definitivamente algo idiota."

# game/chapters/dlc_end.rpyc:528
translate es call1_daydlcend_04810303:

    # GRC "It is true."
    GRC "Eso es cierto."

# game/chapters/dlc_end.rpyc:530
translate es call1_daydlcend_68a3e386:

    # GRC "But the point I'm trying to make is that... you want to keep your soul, right?"
    GRC "Pero el punto que intento hacer es que... quieres conservar tu alma, ¿verdad?"

# game/chapters/dlc_end.rpyc:538
translate es call1_daydlcend_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/dlc_end.rpyc:540
translate es call1_daydlcend_7894c74e:

    # GRC "And I'd like to keep mine."
    GRC "Y yo quisiera conservar la mía."

# game/chapters/dlc_end.rpyc:545
translate es call1_daydlcend_261d2025:

    # GRC "And you have managed to somehow take or lessen the effects of the soul sickness."
    GRC "Y de alguna manera has logrado tomar o reducir los efectos de la enfermedad del alma."

# game/chapters/dlc_end.rpyc:549
translate es call1_daydlcend_6fa5be38:

    # GRC "Indeed. You are... impressive in many ways."
    GRC "En efecto. Eres... impresionante en muchos sentidos."

# game/chapters/dlc_end.rpyc:553
translate es call1_daydlcend_f4b5016c:

    # GRC "The how does not matter."
    GRC "El cómo no importa."

# game/chapters/dlc_end.rpyc:555
translate es call1_daydlcend_2a485c78:

    # GRC "It's the fact that you {i}can{/i} at all."
    GRC "Importa el hecho de que {i}puedas{/i} hacerlo."

# game/chapters/dlc_end.rpyc:558
translate es call1_daydlcend_03be7145:

    # GRC "I wouldn't say I believe in miracles exactly."
    GRC "No diría que creo exactamente en los milagros."

# game/chapters/dlc_end.rpyc:560
translate es call1_daydlcend_ea317c8b:

    # GRC "But I'd say this comes pretty damn close."
    GRC "Pero diría que esto se acerca bastante."

# game/chapters/dlc_end.rpyc:562
translate es call1_daydlcend_73c984a7:

    # GRC "So maybe we could... help each other out."
    GRC "Así que tal vez podríamos... ayudarnos mutuamente."

# game/chapters/dlc_end.rpyc:570
translate es call1_daydlcend_a280de5a:

    # GRC "You."
    GRC "Tú."

# game/chapters/dlc_end.rpyc:572
translate es call1_daydlcend_1433f8d3:

    # GRC "You could... become like me."
    GRC "Podrías... volverte como yo."

# game/chapters/dlc_end.rpyc:587
translate es call1_daydlcend_b1278c78:

    # GRC "No, Sunshine."
    GRC "No, Solecito."

# game/chapters/dlc_end.rpyc:589
translate es call1_daydlcend_f3397240:

    # GRC "I make you like me."
    GRC "Yo te haré como yo."

# game/chapters/dlc_end.rpyc:591
translate es call1_daydlcend_00bf6969:

    # GRC "A... kind of reaper."
    GRC "Un... tipo de parca."

# game/chapters/dlc_end.rpyc:603
translate es call1_daydlcend_32f44438:

    # GRC "Yes."
    GRC "Sí."

# game/chapters/dlc_end.rpyc:608
translate es call1_daydlcend_33ab45f4:

    # GRC "Safe? No."
    GRC "¿Seguro? No."

# game/chapters/dlc_end.rpyc:609
translate es call1_daydlcend_b43d35dc:

    # GRC "But who knows how long your soul will h    old out."
    GRC "Pero quién sabe cuánto tiempo resistirá tu alma."

# game/chapters/dlc_end.rpyc:616
translate es call1_daydlcend_ede6aba2:

    # GRC "Just like that?"
    GRC "¿Así nada más?"

# game/chapters/dlc_end.rpyc:617
translate es call1_daydlcend_860aa2ba:

    # GRC "You don't want any details?"
    GRC "¿No quieres ningún detalle?"

# game/chapters/dlc_end.rpyc:621
translate es call1_daydlcend_bcafd48d:

    # GRC "You are very irresponsible."
    GRC "Eres muy irresponsable."

# game/chapters/dlc_end.rpyc:631
translate es call1_daydlcend_5040df4c:

    # GRC "Of course it's possible."
    GRC "Por supuesto que es posible."

# game/chapters/dlc_end.rpyc:635
translate es call1_daydlcend_db0b36db:

    # GRC "I was, yes."
    GRC "Lo era, sí."

# game/chapters/dlc_end.rpyc:636
translate es call1_daydlcend_75be4f96:

    # GRC "But I found a way. It's a secret I wasn't supposed to know, but that doesn't matter."
    GRC "Pero encontré una forma. Es un secreto que no se suponía que debía saber, pero eso no importa."

# game/chapters/dlc_end.rpyc:645
translate es call1_daydlcend_adf228b7:

    # GRC "I... do."
    GRC "Yo... sí."

# game/chapters/dlc_end.rpyc:646
translate es call1_daydlcend_0f326c89:

    # GRC "I think that skill of yours might be useful-"
    GRC "Creo que esa habilidad tuya podría ser útil..."

# game/chapters/dlc_end.rpyc:647
translate es call1_daydlcend_973f235b:

    # GRC "Would be useful. Definitely."
    GRC "Sería útil. Definitivamente."

# game/chapters/dlc_end.rpyc:648
translate es call1_daydlcend_02944864:

    # GRC "And it would allow you to keep your soul balanced more easily. You abilities wouldn't be a risk."
    GRC "Y te permitiría mantener tu alma equilibrada con mayor facilidad. Tus habilidades no serían un riesgo."

# game/chapters/dlc_end.rpyc:653
translate es call1_daydlcend_7176be62:

    # GRC "That much is obvious."
    GRC "Eso es obvio."

# game/chapters/dlc_end.rpyc:655
translate es call1_daydlcend_305b253d:

    # GRC "Why else would I be spending my time talking with you?"
    GRC "¿Por qué otra razón pasaría mi tiempo hablando contigo?"

# game/chapters/dlc_end.rpyc:663
translate es call1_daydlcend_7da8b1f8:

    # GRC "Yes but..."
    GRC "Sí, pero..."

# game/chapters/dlc_end.rpyc:665
translate es call1_daydlcend_63a1c257:

    # GRC "I could've done all this with much less ... talking."
    GRC "Podría haber hecho todo esto con mucho menos... charla."

# game/chapters/dlc_end.rpyc:666
translate es call1_daydlcend_7c323fa8:

    # GRC "Somehow without meaning to I've come to crave your company."
    GRC "De alguna manera, sin quererlo, he llegado a desear tu compañía."

# game/chapters/dlc_end.rpyc:668
translate es call1_daydlcend_b91cebc2:

    # GRC "Happy now?"
    GRC "¿Feliz ahora?"

# game/chapters/dlc_end.rpyc:670
translate es call1_daydlcend_72f05b53:

    # GRC "I want to... always have you around."
    GRC "Quiero... tenerte siempre cerca."

# game/chapters/dlc_end.rpyc:671
translate es call1_daydlcend_b0c4d38e:

    # GRC "But..."
    GRC "Pero..."

# game/chapters/dlc_end.rpyc:672
translate es call1_daydlcend_163f1261:

    # GRC "Perhaps that's just a one-sided wish."
    GRC "Quizá sea solo un deseo unilateral."

# game/chapters/dlc_end.rpyc:673
translate es call1_daydlcend_a364bf3e:

    # GRC "To... want to be by your side."
    GRC "Desear... estar a tu lado."

# game/chapters/dlc_end.rpyc:681
translate es call1_daydlcend_8da23161:

    # GRC "...."
    GRC "...."

# game/chapters/dlc_end.rpyc:682
translate es call1_daydlcend_adf228b7_1:

    # GRC "I... do."
    GRC "Yo... sí."

# game/chapters/dlc_end.rpyc:695
translate es call1_daydlcend_79204c43:

    # GRC "R... really?"
    GRC "¿E... en serio?"

# game/chapters/dlc_end.rpyc:704
translate es call1_daydlcend_cdb879c0:

    # GRC "Sunshine, I'd have you forever."
    GRC "Solecito, te tendría por siempre."

# game/chapters/dlc_end.rpyc:705
translate es call1_daydlcend_0ac95732:

    # GRC "Honestly, I feel like I fell into a trap with you."
    GRC "Honestamente, siento que caí en una trampa contigo."

# game/chapters/dlc_end.rpyc:706
translate es call1_daydlcend_014daa82:

    # GRC "How could I ever not have fallen in love?"
    GRC "¿Cómo podría no haberme enamorado?"

# game/chapters/dlc_end.rpyc:716
translate es call1_daydlcend_187b4dce:

    # GRC "Likeable? I am unsure. More like unhateable."
    GRC "¿Agradable? No estoy seguro. Más bien imposible de odiar."

# game/chapters/dlc_end.rpyc:730
translate es call1_daydlcend_bcf8ff34:

    # GRC "If only it could be that simple."
    GRC "Si tan solo fuera tan simple."

# game/chapters/dlc_end.rpyc:731
translate es call1_daydlcend_49e0c475:

    # GRC "But no, like I mentioned... we form the connection again."
    GRC "Pero no, como mencioné... formamos la conexión otra vez."

# game/chapters/dlc_end.rpyc:736
translate es call1_daydlcend_8b9bc112:

    # GRC "Then stop talking and let me explain."
    GRC "Entonces deja de hablar y déjame explicarte."

# game/chapters/dlc_end.rpyc:737
translate es call1_daydlcend_fd272bb9:

    # GRC "Once again, proving I am the more patient of the two."
    GRC "Una vez más, demostrando que soy el más paciente de los dos."

# game/chapters/dlc_end.rpyc:738
translate es call1_daydlcend_e93df12f:

    # GRC "Perhaps we can find some kind of online course for you to take."
    GRC "Tal vez podamos encontrar algún curso en línea para que tomes."

# game/chapters/dlc_end.rpyc:742
translate es call1_daydlcend_e977a5b2:

    # GRC "Sometimes."
    GRC "A veces."

# game/chapters/dlc_end.rpyc:746
translate es call1_daydlcend_0c428c5d:

    # GRC "...Sometimes ."
    GRC "...A veces."

# game/chapters/dlc_end.rpyc:753
translate es call1_daydlcend_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/dlc_end.rpyc:758
translate es call1_daydlcend_ec758a61:

    # GRC "Hah! It'll be a competition, then."
    GRC "¡Ja! Entonces será una competencia."

# game/chapters/dlc_end.rpyc:765
translate es call1_daydlcend_823eb642:

    # GRC "Ha. Ha. Ha. Very funny."
    GRC "Ja. Ja. Ja. Muy gracioso."

# game/chapters/dlc_end.rpyc:771
translate es call1_daydlcend_3cb29bfb:

    # GRC "More like a clown..."
    GRC "Más bien un payaso..."

# game/chapters/dlc_end.rpyc:774
translate es call1_daydlcend_34876c93:

    # GRC "Anyway... we form the connection."
    GRC "En fin... formamos la conexión."

# game/chapters/dlc_end.rpyc:775
translate es call1_daydlcend_74a1ec3b:

    # GRC "But the one difference is we do it while touching."
    GRC "Pero la única diferencia es que lo hacemos mientras nos tocamos."

# game/chapters/dlc_end.rpyc:780
translate es call1_daydlcend_d046c5ae:

    # GRC "That we do."
    GRC "Así es."

# game/chapters/dlc_end.rpyc:782
translate es call1_daydlcend_4c08a61e:

    # GRC "As long as you follow my instructions, it should be fine."
    GRC "Mientras sigas mis instrucciones, todo debería estar bien."

# game/chapters/dlc_end.rpyc:784
translate es call1_daydlcend_db81f61f:

    # GRC "You {i}can{/i} do as you're t    old, right Sunshine?"
    GRC "Puedes {i}hacer{/i} lo que se te dice, ¿verdad, Solecito?"

# game/chapters/dlc_end.rpyc:794
translate es call1_daydlcend_cc55c234:

    # GRC "Then... we're nearly ready."
    GRC "Entonces... casi estamos listos."

# game/chapters/dlc_end.rpyc:798
translate es call1_daydlcend_6ee36b20:

    # GRC "...We had a close call last time."
    GRC "...La última vez tuvimos un susto."

# game/chapters/dlc_end.rpyc:799
translate es call1_daydlcend_81f09796:

    # GRC "I'd just like to make sure you are fully certain beforehand."
    GRC "Solo quiero asegurarme de que lo tienes muy claro de antemano."

# game/chapters/dlc_end.rpyc:812
translate es call1_daydlcend_a220ad1a:

    # GRC "On a scale from one to ten, how certain are you?"
    GRC "En una escala del uno al diez, ¿qué tan claro lo tienes?"

# game/chapters/dlc_end.rpyc:813
translate es call1_daydlcend_49b0e8c7:

    # GRC "One being '{i}I am going to freak out{/i}' and ten being '{i}I've never felt chiller{/i}'."
    GRC "Uno siendo '{i}voy a entrar en pánico{/i}' y diez siendo '{i}nunca me he sentido tan en paz{/i}'."

# game/chapters/dlc_end.rpyc:817
translate es call1_daydlcend_11a0dcec:

    # GRC "I'm just making sure."
    GRC "Solo me estoy asegurando."

# game/chapters/dlc_end.rpyc:825
translate es call1_daydlcend_8baf5f41:

    # GRC "Good."
    GRC "Bien."

# game/chapters/dlc_end.rpyc:829
translate es call1_daydlcend_fcd6303e:

    # GRC "You survived last time, did you not?"
    GRC "Sobreviviste la última vez, ¿no?"

# game/chapters/dlc_end.rpyc:833
translate es call1_daydlcend_d0ed7d29:

    # GRC "Listen, Sunshine."
    GRC "Escucha, Solecito."

# game/chapters/dlc_end.rpyc:834
translate es call1_daydlcend_215fd259:

    # GRC "You don't have to go through with this if you don't want to."
    GRC "No tienes que hacerlo si no quieres."

# game/chapters/dlc_end.rpyc:842
translate es call1_daydlcend_586d0755:

    # GRC "Then believe in me, and I will believe in you."
    GRC "Entonces cree en mí, y yo creeré en ti."

# game/chapters/dlc_end.rpyc:847
translate es call1_daydlcend_13764499:

    # GRC "It will be fine."
    GRC "Todo estará bien."

# game/chapters/dlc_end.rpyc:848
translate es call1_daydlcend_b28df956:

    # GRC "You'll be fine."
    GRC "Tú estarás bien."

# game/chapters/dlc_end.rpyc:850
translate es call1_daydlcend_4178c111:

    # GRC "...And I, too, will be fine."
    GRC "...Y yo también estaré bien."

# game/chapters/dlc_end.rpyc:858
translate es call1_daydlcend_8baf5f41_1:

    # GRC "Good."
    GRC "Bien."

# game/chapters/dlc_end.rpyc:862
translate es call1_daydlcend_7014da99:

    # GRC "I'll be over momentarily."
    GRC "Estaré allí en un momento."

# game/chapters/dlc_end.rpyc:870
translate es call1_daydlcend_7d48643b:

    # GRC "Unless you're having second thoughts?"
    GRC "¿A menos que estés dudando?"

# game/chapters/dlc_end.rpyc:877
translate es call1_daydlcend_612180ea:

    # GRC "Again with the lack of patience."
    GRC "Otra vez con la falta de paciencia."

# game/chapters/dlc_end.rpyc:886
translate es call1_daydlcend_dbe4cb52:

    # GRC "Of course. I know you're a package deal."
    GRC "Por supuesto. Sé que tú y tus dudas vienen en paquete."

# game/chapters/dlc_end.rpyc:889
translate es call1_daydlcend_1b3a1194:

    # GRC "See you soon, my little human."
    GRC "Nos vemos pronto, mi humano."

# game/chapters/dlc_end.rpyc:915
translate es chat2_daydlcend_98a2b45a:

    # "The sun shines beautifully through your window."
    "El sol brilla hermosamente a través de tu ventana."

# game/chapters/dlc_end.rpyc:916
translate es chat2_daydlcend_5faafcb1:

    # "You feel the rays of it on your face, and can't help but feel that..."
    "Sientes sus rayos sobre tu rostro, y no puedes evitar sentir que..."

# game/chapters/dlc_end.rpyc:917
translate es chat2_daydlcend_bf78d61a:

    # "Today is a good day to be alive."
    "Hoy es un buen día para estar vivo."

# game/chapters/dlc_end.rpyc:918
translate es chat2_daydlcend_f6747f7b:

    # "It doesn't take him long."
    "No le toma mucho."

# game/chapters/dlc_end.rpyc:919
translate es chat2_daydlcend_26ed4fd7:

    # "You hear a knock at the door, and swing it open quickly."
    "Escuchas un golpe en la puerta y la abres rápidamente."

# game/chapters/dlc_end.rpyc:920
translate es chat2_daydlcend_08847dae:

    # "There you see the prettiest, sweetest, stupidest, dumbest man you have ever met."
    "Ahí ves al hombre más lindo, dulce, estúpido y tonto que has conocido."

# game/chapters/dlc_end.rpyc:926
translate es chat2_daydlcend_1d2aeb70:

    # GRC "You opened the door so quickly for me, Sunshine."
    GRC "Abriste la puerta tan rápido por mí, Solecito."

# game/chapters/dlc_end.rpyc:933
translate es chat2_daydlcend_e579a39c:

    # GRC "Are you ready then?"
    GRC "¿Entonces estás listo?"

# game/chapters/dlc_end.rpyc:944
translate es chat2_daydlcend_81ffd52e:

    # GRC "Why... does that matter?"
    GRC "¿Por qué... importa eso?"

# game/chapters/dlc_end.rpyc:950
translate es chat2_daydlcend_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/dlc_end.rpyc:952
translate es chat2_daydlcend_5983b13d:

    # GRC "I like you, Sunshine."
    GRC "Me gustas, Solecito."

# game/chapters/dlc_end.rpyc:953
translate es chat2_daydlcend_9ff18376:

    # GRC "I like you so much that 'like' is not a sufficient word."
    GRC "Me gustas tanto que 'gustar' no es una palabra suficiente."

# game/chapters/dlc_end.rpyc:954
translate es chat2_daydlcend_d10265db:

    # GRC "My heart... beats so loudly I feel it could explode."
    GRC "Mi corazón... late tan fuerte que siento que podría explotar."

# game/chapters/dlc_end.rpyc:955
translate es chat2_daydlcend_5567e330:

    # GRC "Because you're standing in front of me."
    GRC "Porque estás frente a mí."

# game/chapters/dlc_end.rpyc:956
translate es chat2_daydlcend_d84ddc51:

    # GRC "So close that I can... reach out and touch you."
    GRC "Tan cerca que puedo... extender la mano y tocarte."

# game/chapters/dlc_end.rpyc:957
translate es chat2_daydlcend_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/dlc_end.rpyc:958
translate es chat2_daydlcend_1c80ab2f:

    # GRC "For what it's worth, I think you've taken my soul after all."
    GRC "Por lo que vale, creo que al final te has llevado mi alma."

# game/chapters/dlc_end.rpyc:969
translate es chat2_daydlcend_ac1e8eab:

    # GRC "I try."
    GRC "Lo intento."

# game/chapters/dlc_end.rpyc:979
translate es chat2_daydlcend_7119ec11:

    # GRC "We {i}will{/i} actually have to work, you know,"
    GRC "De hecho, {i}tendremos{/i} que trabajar, ¿sabes?"

# game/chapters/dlc_end.rpyc:985
translate es chat2_daydlcend_e569e2a1:

    # GRC "I want to be stuck with you, Sunshine."
    GRC "Quiero quedarme contigo, Solecito."

# game/chapters/dlc_end.rpyc:986
translate es chat2_daydlcend_6039343d:

    # GRC "And yes, I am {i}very{/i} ready."
    GRC "Y sí, estoy {i}muy{/i} listo."

# game/chapters/dlc_end.rpyc:990
translate es chat2_daydlcend_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/dlc_end.rpyc:991
translate es chat2_daydlcend_8baf5f41:

    # GRC "Good."
    GRC "Bien."

# game/chapters/dlc_end.rpyc:993
translate es chat2_daydlcend_dffa079d:

    # GRC "Simply look into my eyes and take my hand."
    GRC "Simplemente mírame a los ojos y toma mi mano."

# game/chapters/dlc_end.rpyc:997
translate es chat2_daydlcend_9c9ca973:

    # GRC "For you, yes."
    GRC "Por ti, sí."

# game/chapters/dlc_end.rpyc:998
translate es chat2_daydlcend_843e8500:

    # GRC "I'll do the rest."
    GRC "Yo haré el resto."

# game/chapters/dlc_end.rpyc:999
translate es chat2_daydlcend_a899443c:

    # GRC "I will... tie our souls together. Bind them, almost, if that makes it easier for you to understand."
    GRC "Voy a... atar nuestras almas. Unirlas, casi, si eso te ayuda a entenderlo."

# game/chapters/dlc_end.rpyc:1005
translate es chat2_daydlcend_8045fcae:

    # GRC "You do?"
    GRC "¿De verdad?"

# game/chapters/dlc_end.rpyc:1012
translate es chat2_daydlcend_30c74a20:

    # GRC "Oh, for the love of..."
    GRC "Oh, por el amor de..."

# game/chapters/dlc_end.rpyc:1013
translate es chat2_daydlcend_1cf857fc:

    # GRC "NO."
    GRC "NO."

# game/chapters/dlc_end.rpyc:1025
translate es chat2_daydlcend_0827aaac:

    # GRC "In a way."
    GRC "En cierta forma."

# game/chapters/dlc_end.rpyc:1026
translate es chat2_daydlcend_e10cd885:

    # GRC "I am claiming a part of you, and you are claiming a part of me."
    GRC "Reclamo una parte de ti, y tú reclamas una parte de mí."

# game/chapters/dlc_end.rpyc:1028
translate es chat2_daydlcend_ae210410:

    # GRC "We will be linked for all of eternity."
    GRC "Estaremos unidos por toda la eternidad."

# game/chapters/dlc_end.rpyc:1034
translate es chat2_daydlcend_008afe10_3:

    # GRC "..."
    GRC "..."

# game/chapters/dlc_end.rpyc:1040
translate es chat2_daydlcend_1365e814:

    # GRC "Well... woof."
    GRC "Bueno... guau."

# game/chapters/dlc_end.rpyc:1043
translate es chat2_daydlcend_c1f5aebe:

    # GRC "...Shall we?"
    GRC "¿...Lo hacemos?"

# game/chapters/dlc_end.rpyc:1047
translate es chat2_daydlcend_466d7a4d:

    # GRC "You are... you feel so soft. Even through my gloves..."
    GRC "Eres... te sientes tan suave. Incluso a través de mis guantes..."

# game/chapters/dlc_end.rpyc:1051
translate es chat2_daydlcend_b8d5f407:

    # GRC "...!"
    GRC "...!"

# game/chapters/dlc_end.rpyc:1052
translate es chat2_daydlcend_9ff2215f:

    # GRC "When I'm around you, it seems I can't contain myself..."
    GRC "Cuando estoy cerca de ti, parece que no puedo contenerme..."

# game/chapters/dlc_end.rpyc:1053
translate es chat2_daydlcend_1f745793:

    # GRC "Look into my eyes, Sunshine."
    GRC "Mírame a los ojos, Solecito."

# game/chapters/dlc_end.rpyc:1057
translate es chat2_daydlcend_625c0e6b:

    # GRC "Just like that..."
    GRC "Así, justo así..."

# game/chapters/dlc_end.rpyc:1058
translate es chat2_daydlcend_24b9231b:

    # GRC "I'm glad it was you, by the way."
    GRC "Me alegra que hayas sido tú, por cierto."

# game/chapters/dlc_end.rpyc:1059
translate es chat2_daydlcend_f4c9603f:

    # GRC "I don't know if I ever t    old you."
    GRC "No sé si alguna vez te lo dije."

# game/chapters/dlc_end.rpyc:1060
translate es chat2_daydlcend_e33200b4:

    # GRC "You are..."
    GRC "Eres..."

# game/chapters/dlc_end.rpyc:1061
translate es chat2_daydlcend_8aa6221f:

    # GRC "Perfect to me."
    GRC "Perfección para mí."

# game/chapters/dlc_end.rpyc:1068
translate es chat2_daydlcend_bee31c46:

    # GRC "Who cares about the bet."
    GRC "¿A quién le importa la apuesta?"

# game/chapters/dlc_end.rpyc:1069
translate es chat2_daydlcend_42eff473:

    # GRC "When I'm by your side, I feel like I won anyway."
    GRC "Cuando estoy a tu lado, siento que ya gané de todos modos."

# game/chapters/dlc_end.rpyc:1073
translate es chat2_daydlcend_2098322e:

    # GRC "Then let's begin, my {i}little reaper{/i}."
    GRC "Entonces empecemos, mi {i}parquita{/i}."

translate es strings:

    old "1. <For all you know, I could have loads of plans.>"
    new "1. <Por lo que tú sabes, podría tener montones de planes.>"

    old "1. <About the way you're gonna lose our bet today?>"
    new "1. <¿Sobre la forma en que vas a perder nuestra apuesta hoy?>"

    old "1. <That's loser talk.>"
    new "1. <Eso suena a charla de perdedor.>"

    old "1. <Many books in the Underworld, Casper?>"
    new "1. <¿Muchos libros en el Inframundo, Casper?>"

    old "1. <That somehow doesn't fit with what I was expecting.>"
    new "1. <Eso no encaja exactamente con lo que esperaba.>"

    old "1. <Lay it on me, Casper!>"
    new "1. <¡Dímela, Casper!>"

    old "1. <Not dying would be preferable.>"
    new "1. <No morir sería preferible.>"

    old "1. <You want to do {i}what{/i} together, exactly?>"
    new "1. <¿Quieres hacer {i}qué{/i} juntos, exactamente?>"

    old "1. <Me, patience? You're the one who's impatient here.>"
    new "1. <¿Yo, paciencia? Aquí el impaciente eres tú.>"

    old "1. <Which is pretty much never.>"
    new "1. <Lo cual es casi nunca.>"

    old "1. <I bet I could teach you a thing or two about patience.>"
    new "1. <Apuesto a que podría enseñarte una o dos cosas sobre la paciencia.>"

    old "1. <Ha. You're funny, Grimmy.>"
    new "1. <Ja. Eres gracioso, Parquita.>"

    old "1. <There is always more to learn.>"
    new "1. <Siempre hay algo nuevo que aprender.>"

    old "1. <What? No.>"
    new "1. <¿Qué? No.>"

    old "1. <It's a 'pfffft' sound.>"
    new "1. <Es un sonido de 'pfffft'.>"

    old "1. <Another thing I'm teaching you, I suppose.>"
    new "1. <Otra cosa que te estoy enseñando, supongo.>"

    old "1. <I'm sure there's plenty I could teach you.>"
    new "1. <Seguro que hay mucho que podría enseñarte.>"

    old "1. <We'll do patience first. For obvious reasons.>"
    new "1. <Empezaremos con la paciencia. Por razones obvias.>"

    old "1. <And then we can revisit your typing issues.>"
    new "1. <Y luego podemos revisar tus problemas al escribir.>"

    old "1. <You haven't capitalized anything you've typed since the first day we met.>"
    new "1. <No has puesto mayúsculas en nada de lo que escribes desde el primer día que nos conocimos.>"

    old "1. <Are you still embarrassed?>"
    new "1. <¿Todavía estás avergonzado?>"

    old "1. <Your Typing Is Making Me Laugh.>"
    new "1. <Tu forma de escribir me está haciendo reír.>"

    old "1. <Yeah I get it, you know where the caps button on your keyboard is.>"
    new "1. <Sí, ya entiendo, sabes dónde está el botón de mayúsculas en tu teclado.>"

    old "1. <Just not how to use it correctly.>"
    new "1. <Solo que no sabes usarlo correctamente.>"

    old "1. <Nope, that's even weirder coming from you!>"
    new "1. <¡Nop, eso suena aún más raro viniendo de ti!>"

    old "1. <You're so stubborn.>"
    new "1. <Eres tan terco.>"

    old "1. <But winding back here a little...>"
    new "1. <Pero volviendo un poco atrás...>"

    old "1. <What's this workaround?>"
    new "1. <¿Cuál es esa alternativa?>"

    old "1. <Talk about a loaded question.>"
    new "1. <Vaya pregunta trampa.>"

    old "1. <Well... not really.>"
    new "1. <Bueno... no realmente.>"

    old "1. <You're being a little suspicious right now.>"
    new "1. <Estás siendo un poco sospechoso ahora mismo.>"

    old "1. <What exactly do you mean by that?>"
    new "1. <¿A qué te refieres exactamente con eso?>"

    old "1. <How could I not be?>"
    new "1. <¿Cómo no habría de estarlo?>"

    old "1. <Depends, how convincing can you be?>"
    new "1. <Depende, ¿qué tan convincente puedes ser?>"

    old "1. <You're being mighty suspicious at the moment.>"
    new "1. <Estás siendo muy sospechoso en este momento.>"

    old "1. <No, you're Casper.>"
    new "1. <No, tú eres Casper.>"

    old "1. <A waste?>"
    new "1. <¿Un desperdicio?>"

    old "1. <Won't you get in trouble for not taking it?>"
    new "1. <¿No te meterás en problemas por no tomarla?>"

    old "1. <Does this have anything to do with the fact you're madly in love with me?>"
    new "1. <¿Tiene esto algo que ver con el hecho de que estás locamente enamorado de mí?>"

    old "1. <You said it yesterday, right?>"
    new "1. <Lo dijiste ayer, ¿no?>"

    old "1. <You like me. You want to hate me, but you can't.>"
    new "1. <Te gusto. Quieres odiarme, pero no puedes.>"

    old "1. <So you've been sitting there all night thinking of how to save me.>"
    new "1. <Así que has estado sentado ahí toda la noche pensando en cómo salvarme.>"

    old "1. <You're so embarrassed you went back to typing like that, huh?>"
    new "1. <Estás tan avergonzado que volviste a escribir así, ¿eh?>"

    old "1. <I'd love to.>"
    new "1. <Me encantaría.>"

    old "1. <And that loophole involves me winning our bet?>"
    new "1. <¿Y ese vacío implica que yo gane nuestra apuesta?>"

    old "1. <Damn. I was really hoping to get your soul.>"
    new "1. <Maldición. Realmente esperaba conseguir tu alma.>"

    old "1. <I had so many plans...>"
    new "1. <Tenía tantos planes...>"

    old "1. <So, what's the loophole?>"
    new "1. <Entonces, ¿cuál es el vacío legal?>"

    old "1. <It's not something that is easily forgotten, Grim.>"
    new "1. <No es algo que se olvide fácilmente, Parca.>"

    old "1. <Um.>"
    new "1. <Um.>"

    old "1. <Can I just stop you for a second...>"
    new "1. <¿Puedo detenerte un segundo...? >"

    old "1. <What exactly are you planning to do?>"
    new "1. <¿Qué es exactamente lo que planeas hacer?>"

    old "1. <I don't mind going along with it, but...>"
    new "1. <No me molesta seguirte el juego, pero...>"

    old "1. <But I'd like to know what I'm agreeing to first.>"
    new "1. <Pero me gustaría saber a qué estoy accediendo primero.>"

    old "1. <Casper.>"
    new "1. <Casper.>"

    old "1. <The way you blush when I say your name is so cute.>"
    new "1. <La forma en que te sonrojas cuando digo tu nombre es tan tierna.>"

    old "1. <You don't really want me to shut up.>"
    new "1. <En el fondo no quieres que me calle.>"

    old "1. <Or you wouldn't have called.>"
    new "1. <O no me habrías llamado.>"

    old "1. <Talking to you is the highlight of my day.>"
    new "1. <Hablar contigo es lo mejor de mi día.>"

    old "1. <But we can flirt after you've explained yourself.>"
    new "1. <Pero podemos coquetear después de que te expliques.>"

    old "1. <It's endearing.>"
    new "1. <Es encantador.>"

    old "1. <I like it a lot.>"
    new "1. <Me gusta mucho.>"

    old "1. <I know it's easy for you to get distracted when I'm here, but...>"
    new "1. <Sé que es fácil para ti distraerte cuando estoy aquí, pero...>"

    old "1. <Start explaining.>"
    new "1. <Empieza a explicarte.>"

    old "1. <Big Reaper~>"
    new "1. <Gran Parca~>"

    old "1. <As fun as messing with you is, big boy...>"
    new "1. <Aunque divertirme contigo es entretenido, grandulón...>"

    old "1. <Could you explain what's going on?>"
    new "1. <¿Podrías explicar qué está pasando?>"

    old "1. <Wow. I'm going to ignore that last part.>"
    new "1. <Vaya. Voy a ignorar esa última parte.>"

    old "1. <I do, yes.>"
    new "1. <Sí, lo hago.>"

    old "1. <Shame.>"
    new "1. <Qué pena.>"

    old "1. <Just me being super talented.>"
    new "1. <Solo soy una persona con mucho talento.>"

    old "1. <I'm listening.>"
    new "1. <Te escucho.>"

    old "1. <Like you?>"
    new "1. <¿Como tú?>"

    old "1. <In... what way?>"
    new "1. <¿En... qué sentido?>"

    old "1. <Bad at typing?>"
    new "1. <¿Malo escribiendo?>"

    old "1. <WHAT?>"
    new "1. <¿QUÉ?>"

    old "1. <I'm sorry, did I hear you right?>"
    new "1. <Perdón, ¿escuché bien?>"

    old "1. <You want to make me, {i}me{/i} a reaper? Like you?>"
    new "1. <¿Quieres hacerme a mí, {i}a mí{/i}, una parca? ¿Como tú?>"

    old "1. <Is that... safe?>"
    new "1. <¿Eso es... seguro?>"

    old "1. <Sign me the hell up.>"
    new "1. <Apúntame de una vez.>"

    old "1. <Who needs details? I'm sure you'll fill me in later.>"
    new "1. <¿Quién necesita detalles? Seguro que luego me lo contarás todo..>"

    old "1. <It seems so.>"
    new "1. <Parece que sí.>"

    old "1. <But are you actually being serious right now?>"
    new "1. <¿Pero hablas en serio ahora?>"

    old "1. <Didn't you say you were a reaper from the start?>"
    new "1. <¿No dijiste que eras una parca desde el principio?>"

    old "1. <You... would want me to be like you?>"
    new "1. <¿Tú... quieres que sea como tú>"

    old "1. <You want to work together?>"
    new "1. <¿Quieres que trabajemos juntos?>"

    old "1. <Plus you just want my company, don't you?>"
    new "1. <Además, solo quieres mi compañía, ¿verdad?>"

    old "1. <For my soul, Casper.>"
    new "1. <Por mi alma, Casper.>"

    old "1. <That is how this whole thing started, remember?>"
    new "1. <Así empezó todo esto, ¿recuerdas?>"

    old "1. <Do you still feel the same way about me?>"
    new "1. <¿Aún sientes lo mismo por mí?>"

    old "1. <Good.>"
    new "1. <Bien.>"

    old "1. <Because I think I've liked you for a long time now.>"
    new "1. <Porque creo que me has gustado desde hace mucho tiempo.>"

    old "1. <If you'd have me, I'd go with you.>"
    new "1. <Si me aceptas, iría contigo.>"

    old "1. <I'm that likeable, huh?>"
    new "1. <¿Soy tan agradable, eh?>"

    old "1. <I'll take it.>"
    new "1. <Lo aceptaré.>"

    old "1. <Well then, how do you plan to do it?>"
    new "1. <Entonces, ¿cómo planeas hacerlo?>"

    old "1. <I assume it's not as easy as snapping your fingers \nand boom! You're a reaper.>"
    new "1. <Supongo que no es tan fácil como chasquear los dedos \ny ¡boom! ya eres una parca.>"

    old "1. <And then what? I don't understand how we \nget from point A to B.>"
    new "1. <¿Y luego qué? No entiendo cómo pasamos \ndel punto A al B.>"

    old "1. <I am plenty patient, thank you very much.>"
    new "1. <Soy bastante paciente, muchas gracias.>"

    old "1. <All the time!>"
    new "1. <¡Todo el tiempo!>"

    old "1. <You could do with some help yourself.>"
    new "1. <Tú también podrías usar un poco de ayuda.>"

    old "1. <I'd get a higher grade than you, for sure.>"
    new "1. <Sacaré mejor nota que tú, sin duda.>"

    old "1. <They probably won't want me back.>"
    new "1. <Probablemente no me quieran de vuelta.>"

    old "1. <Thank you. I'm a comedian.>"
    new "1. <Gracias. Soy comediante.>"

    old "1. <So, we do this in person?>"
    new "1. <Entonces, ¿hacemos esto en persona?>"

    old "1. <I'll be a good [girl] for you.>"
    new "1. <Seré buen[girl!t] por ti.>"

    old "1. <Just this one time~>"
    new "1. <Solo esta vez~>"

    old "1. <I understand.>"
    new "1. <Entiendo.>"

    old "1. <Thanks for checking on me, Casper.>"
    new "1. <Gracias por preocuparte por mí, Casper.>"

    old "1. <But I'm certain.>"
    new "1. <Pero lo tengo claro.>"

    old "1. <A ten.>"
    new "1. <Un diez.>"

    old "1. <I've done it once before and it was fine, I can do it again.>"
    new "1. <Ya lo he hecho antes y salió bien, puedo hacerlo otra vez.>"

    old "1. <...Just.>"
    new "1. <...Solo.>"

    old "1. <No, no... I do want to.>"
    new "1. <No, no... Sí quiero hacerlo.>"

    old "1. <I really want to.>"
    new "1. <De verdad quiero hacerlo.>"

    old "1. <I dont want anything bad to happen to you...>"
    new "1. <No quiero que te pase nada malo...>"

    old "1. <You're coming... right now?>"
    new "1. <¿Vienes... ahora mismo?>"

    old "1. <No. You can come now.>"
    new "1. <No. Puedes venir ahora.>"

    old "1. <Wait.>"
    new "1. <Espera.>"

    old "1. <[pet_name] can come, right?>"
    new "1. <[pet_name] puede venir, ¿verdad?>"

    old "1. <Hello to you as well, Casper.>"
    new "1. <Hola a ti también, Casper.>"

    old "1. <Not yet.>"
    new "1. <Aún no.>"

    old "1. <First I want to hear you say how much you like me to my face.>"
    new "1. <Primero quiero oírte decir en persona cuánto te gusto.>"

    old "1. <It just does.>"
    new "1. <Simplemente pasa.>"

    old "1. <Sometimes you're... oddly poetic.>"
    new "1. <A veces eres... extrañamente poético.>"

    old "1. <Now I'm ready.>"
    new "1. <Ahora tengo la certeza.>"

    old "1. <To... become a reaper. To be with you.>"
    new "1. <De... convertirme en una parca. Para estar contigo.>"

    old "1. <This is going to be so much fun.>"
    new "1. <Esto va a ser muy divertido.>"

    old "1. <I'm not afraid of a little hard work, Grim.>"
    new "1. <No le tengo miedo al trabajo duro, Parca.>"

    old "1. <I don't mind being stuck with you either.>"
    new "1. <Tampoco me molesta quedarme contigo.>"

    old "1. <It's as simple as that?>"
    new "1. <¿Así de simple?>"

    old "1. <Wait. I know what this is.>"
    new "1. <Espera. Sé lo que es esto.>"

    old "1. <It's soul baby time.>"
    new "1. <Es hora del bebé alma.>"

    old "1. <It's like you're claiming a bit of my soul.>"
    new "1. <Es como si reclamaras una parte de mi alma.>"

    old "1. <I'm putting a collar on you!>"
    new "1. <¡Te voy a poner un collar!>"

    old "1. <It would suit you.>"
    new "1. <Te quedaría bien.>"

    old "1. <{i}Reach out your hand.{/i}>"
    new "1. <{i}Extender tu mano.{/i}>"

    old "1. <Flirting at a time like this, huh?>"
    new "1. <¿Coqueteando en un momento como este, eh?>"

    old "1. <{i}Gaze into his eyes.{/i}>"
    new "1. <{i}Mirar fijamente a sus ojos.{/i}>"

    old "1. <I'm glad too.>"
    new "1. <Yo también me alegro.>"

    old "1. <I'm glad it was you who was assigned to me.>"
    new "1. <Me alegra que fueras tú quien me asignaron.>"

    old "1. <Me too.>"
    new "1. <Yo también.>"

    old "2. <You can't beat me!>"
    new "2. <¡No puedes ganarme!>"

    old "2. <What are you rambling about, little reaper?>"
    new "2. <¿Qué estás divagando, parquita?>"

    old "2. <Wroooong.>"
    new "2. <Incoooorrecto.>"

    old "2. <Of course I am.>"
    new "2. <Por supuesto que lo estoy.>"

    old "2. <Ah! So you {i}have{/i} given up!>"
    new "2. <¡Ah! ¡Así que {i}sí{/i} te has rendido!>"

    old "2. <Yeah, what's taking you so long?>"
    new "2. <Sí, ¿qué te está tomando tanto tiempo?>"

    old "2. <Of course I do.>"
    new "2. <Por supuesto que lo recuerdo.>"

    old "2. <I'm getting a little bit confused.>"
    new "2. <Me estás confundiendo un poco.>"

    old "2. <I'm all for doing some crazy shit, but...>"
    new "2. <Estoy a favor de hacer locuras, pero...>"

    old "2. <Grim.>"
    new "2. <Parca.>"

    old "2. <Isn't that obvious?>"
    new "2. <¿No es obvio?>"

    old "2. <Somehow... not that I fully understand it.>"
    new "2. <De alguna manera... aunque no lo entiendo del todo.>"

    old "2. <What do you propose?>"
    new "2. <¿Qué propones?>"

    old "2. <Incredibly annoying?>"
    new "2. <Eres tan terco.>"

    old "2. <Fuck yes.>"
    new "2. <Claro que sí.>"

    old "2. <Because I think I'm in love with you.>"
    new "2. <Porque creo que me he enamorado de ti.>"

    old "2. <As long as we take it together.>"
    new "2. <Mientras lo enfrentemos juntos.>"

    old "2. <Only because it's you.>"
    new "2. <Solo porque eres tú.>"

    old "2. <I suppose I am a little worried.>"
    new "2. <Supongo que me preocupa un poco.>"

    old "2. <No. I want this.>"
    new "2. <No. Quiero esto.>"

    old "2. <I {i}was{/i} expecting you.>"
    new "2. <Sí {i}te estaba{/i} esperando.>"

    old "2. <Ready to be stuck with me?>"
    new "2. <¿Listo para quedarte atrapado conmigo?>"

    old "3. <Pffffft...>"
    new "3. <Pffffft...>"

    old "3. <I think I fall in the middle.>"
    new "3. <Creo que estoy en un punto intermedio.>"

    old "3. <Little Reaper.>"
    new "3. <Parquita.>"

    old "3. <{i}What! No way!{/i}>"
    new "3. <{i}¡¿Qué! ¡De ninguna manera!{/i}>"

    old "3. <Oh? This is gonna be interesting.>"
    new "3. <¿Oh? Esto se pondrá interesante.>"

    old "3. <Kinda babygirl?>"
    new "3. <¿Algo así como babygirl?>"

    old "3. <Is that even possible?>"
    new "3. <¿Eso siquiera es posible?>"

    old "3. <I've already been kicked out of that one.>"
    new "3. <Ya me echaron de ese.>"

    old "3. <No. Hurry up.>"
    new "3. <No. Date prisa.>"
