
# game/chapters/5_day.rpyc:18
translate es day5_start_240607b8:

    # center_text "On your way home from work, you decide to stop in a local coffee shop for your favorite beverage."
    center_text "De camino a casa después del trabajo, decides parar en una cafetería local para tomar tu bebida favorita."

# game/chapters/5_day.rpyc:19
translate es day5_start_230572c4:

    # center_text "You decide against going to your usual store, and instead stop by one a little closer to your apartment."
    center_text "Decides no ir a tu tienda habitual y, en su lugar, paras en una que está un poco más cerca de tu apartamento."

# game/chapters/5_day.rpyc:20
translate es day5_start_36284aa4:

    # center_text "Except, when you enter... you find it totally empty!"
    center_text "Pero, cuando entras... ¡la encuentras completamente vacía!"

# game/chapters/5_day.rpyc:21
translate es day5_start_a2e62128:

    # center_text "Confused, you decide to leave... just in time for the building to erupt in flames."
    center_text "Con un poco de confusión, decides irte... justo a tiempo antes de que el edificio se llene de llamas."

# game/chapters/5_day.rpyc:22
translate es day5_start_8403be62:

    # center_text "When the fire trucks arrive, you learn that the building was evacuated over a leaky gas pipe... but they forgot to lock the door when they left."
    center_text "Cuando llegan los bomberos, te enteras de que el edificio fue evacuado por una fuga en una tubería de gas... pero se olvidaron de cerrar la puerta cuando se fueron."

# game/chapters/5_day.rpyc:23
translate es day5_start_e98378a1:

    # center_text "Whoops."
    center_text "Uuups."

# game/chapters/5_day.rpyc:24
translate es day5_start_962687c4:

    # center_text "They're amazed you got out unscathed... and also confused about how the fire started, seeing as no one was there."
    center_text "Están asombrados de que hayas salido sin heridas... y también confundidos sobre cómo se inició el incendio, ya que no había nadie allí."

# game/chapters/5_day.rpyc:25
translate es day5_start_be197c22:

    # center_text "Still, you're let go and you make your way back to your apartment, smiling to yourself."
    center_text "Aun así, te dejan ir y regresas a tu apartamento, sonriendo para tus adentros."

# game/chapters/5_day.rpyc:26
translate es day5_start_a3629302:

    # center_text "Though Grim is still after your soul, at least he doesn't let anyone else get caught in the crossfire."
    center_text "Aunque Parca sigue tras tu alma, al menos no deja que nadie más quede atrapado en el fuego cruzado."

# game/chapters/5_day.rpyc:66
translate es day5_start2_e370f955:

    # GR "mortal, i have had an important revelation."
    GR "mortal, he tenido una revelación importante."

# game/chapters/5_day.rpyc:67
translate es day5_start2_4fc835f7:

    # GR "and that is that i am unaware of certain... 'aspects' of your person."
    GR "y es que desconozco ciertos... 'aspectos' de tu persona."

# game/chapters/5_day.rpyc:68
translate es day5_start2_b699e6e9:

    # GR "it is imperative that you answer these immediately upon being seen."
    GR "es imprescindible que respondas a estas preguntas inmediatamente en cuanto las veas."

# game/chapters/5_day.rpyc:69
translate es day5_start2_76dd5bd8:

    # GR "1. your favorite mortal color."
    GR "1. tu mortal color favorito."

# game/chapters/5_day.rpyc:70
translate es day5_start2_a0322885:

    # GR "2. the season in which you favor most."
    GR "2. la estación del año que más te gusta."

# game/chapters/5_day.rpyc:71
translate es day5_start2_744ff228:

    # GR "3. what is your family status."
    GR "3. ¿cuál es tu situación familiar"

# game/chapters/5_day.rpyc:72
translate es day5_start2_fcdb1a61:

    # GR "4. names of any mortals who 'tickle your fancy'."
    GR "4. nombres de cualquier mortal 'que te guste'."

# game/chapters/5_day.rpyc:73
translate es day5_start2_0e45c414:

    # GR "5. left or right side of the bed."
    GR "5. ¿lado izquierdo o derecho de la cama?"

# game/chapters/5_day.rpyc:74
translate es day5_start2_fb937206:

    # GR "thank you."
    GR "gracias."

# game/chapters/5_day.rpyc:75
translate es day5_start2_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/5_day.rpyc:76
translate es day5_start2_1b5782b0:

    # GR "why have you taken so long to respond?"
    GR "¿por qué tardas tanto en responder?"

# game/chapters/5_day.rpyc:77
translate es day5_start2_941344c0:

    # GR "perhaps my approach was wrong? no, the problem cannot be me."
    GR "¿quizás mi enfoque fue incorrecto? no, el problemano puedo ser yo."

# game/chapters/5_day.rpyc:78
translate es day5_start2_5dcf937a:

    # GR "hmm."
    GR "hmm."

# game/chapters/5_day.rpyc:79
translate es day5_start2_7123336f:

    # GR "[playerfirstname!l], i request your presence."
    GR "[playerfirstname!l], solicito tu presencia."

# game/chapters/5_day.rpyc:80
translate es day5_start2_7772a27d_1:

    # GR "..."
    GR "..."

# game/chapters/5_day.rpyc:81
translate es day5_start2_80ff4898:

    # GR "hello?"
    GR "¿hola?"

# game/chapters/5_day.rpyc:84
translate es day5_start2_e8cd3b55:

    # player "Woah okay, wall of text."
    player "Woah okey, mucho texto."

# game/chapters/5_day.rpyc:86
translate es day5_start2_da3d2a91:

    # player "Desperate for my attention, are we?"
    player "Desesperado por mi atención, ¿verdad?"

# game/chapters/5_day.rpyc:88
translate es day5_start2_8e44acd2:

    # player "Aww, did you miss me?"
    player "Aww, ¿me extrañaste?"

# game/chapters/5_day.rpyc:90
translate es day5_start2_6357aff0:

    # player "Someone's interested in me."
    player "Alguien está interesado en mí."

# game/chapters/5_day.rpyc:93
translate es day5_start2_04faf33c:

    # player "Not that I'm surprised."
    player "No es que me sorprenda."

# game/chapters/5_day.rpyc:96
translate es day5_start2_7a2501ba:

    # player "Considering I'm so kind, and friendly, and caring."
    player "Teniendo en cuenta que soy tan gentil, amable y servicial."

# game/chapters/5_day.rpyc:99
translate es day5_start2_f9cca520:

    # player "Charismatic, too."
    player "Con carisma, también."

# game/chapters/5_day.rpyc:100
translate es day5_start2_485b1605:

    # GR "someone's tooting their own horn today huh."
    GR "alguien se está echando flores hoy huh."

# game/chapters/5_day.rpyc:104
translate es day5_start2_dffa52c4:

    # player "Someone's gotta toot it for me."
    player "Alguien tiene que hacerlo por mí."

# game/chapters/5_day.rpyc:106
translate es day5_start2_a7d0af42:

    # player "I was trying to embody your attitude."
    player "Estaba tratando de imitar tu actitud."

# game/chapters/5_day.rpyc:110
translate es day5_start2_d4946750:

    # player "Anyway, let me read all of this."
    player "De todos modos, déjame leer todo eso."

# game/chapters/5_day.rpyc:115
translate es day5_start2_2e99386b:

    # player "Are we playing 20 questions or something?"
    player "¿Estamos jugando a las 20 preguntas o algo así?"

# game/chapters/5_day.rpyc:117
translate es day5_start2_3f0ed6a0:

    # GR "20? don't be ridiculous. use your eyes and count."
    GR "¿20? no digas tonterías. usa tus ojos y cuenta."

# game/chapters/5_day.rpyc:118
translate es day5_start2_c41c590b:

    # GR "i asked 5."
    GR "pregunté 5."

# game/chapters/5_day.rpyc:121
translate es day5_start2_50431ec8:

    # player "Technically there are 8 questions there."
    player "Técnicamente hay 8 preguntas ahí."

# game/chapters/5_day.rpyc:123
translate es day5_start2_f7ace2b5:

    # GR "...just answer the first 5, mortal."
    GR "...solo responde las primeras 5, mortal."

# game/chapters/5_day.rpyc:126
translate es day5_start2_b48393ff:

    # player "Don't you want to know what took me so long?"
    player "¿No quieres saber por qué tardé tanto?"

# game/chapters/5_day.rpyc:129
translate es day5_start2_b4ad05ff:

    # player "Sorry to answer it, but yes your approach is wrong (as always)."
    player "Siento responderte, pero sí, tu enfoque es erróneo (como siempre)."

# game/chapters/5_day.rpyc:131
translate es day5_start2_d9c504e8:

    # GR "just answer the other questions."
    GR "solo responde las otras preguntas."

# game/chapters/5_day.rpyc:134
translate es day5_start2_63f32cbd:

    # player "Fine, I'll work down the list."
    player "Está bien, revisaré la lista."

# game/chapters/5_day.rpyc:137
translate es day5_start2_a63f3036:

    # player "My favorite 'mortal' color..."
    player "Mi 'mortal' color favorito..."

# game/chapters/5_day.rpyc:146
translate es day5_start2_6e527338:

    # player "Probably [day5_favoritecolor] then."
    player "Probablemente sea [day5_favoritecolor]."

# game/chapters/5_day.rpyc:147
translate es day5_start2_9f0741cf:

    # GR "okay, [day5_favoritecolor], got it."
    GR "de acuerdo, [day5_favoritecolor], lo tengo."

# game/chapters/5_day.rpyc:148
translate es day5_start2_0a97e1c9:

    # GR "a fine color."
    GR "un color fino."

# game/chapters/5_day.rpyc:150
translate es day5_start2_81c6efb4:

    # GR "which season?"
    GR "¿qué estación?"

# game/chapters/5_day.rpyc:154
translate es day5_start2_c8d9939a:

    # player "Summer."
    player "Verano."

# game/chapters/5_day.rpyc:157
translate es day5_start2_a9aa8e69:

    # player "I much prefer warmer weather."
    player "Prefiero mucho más el clima cálido."

# game/chapters/5_day.rpyc:160
translate es day5_start2_c2818b58:

    # player "The cold and I are {i}not{/i} friends."
    player "El frío y yo {i}no{/i} somos amigos."

# game/chapters/5_day.rpyc:161
translate es day5_start2_6a0f6b0d:

    # GR "you do not like the cold?"
    GR "¿no te gusta el frío?"

# game/chapters/5_day.rpyc:164
translate es day5_start2_c9cde2b5:

    # player "Not at all, do you?"
    player "En absoluto, ¿verdad?"

# game/chapters/5_day.rpyc:167
translate es day5_start2_c747d3da:

    # player "The cold is my greatest enemy."
    player "El frío es mi mayor enemigo."

# game/chapters/5_day.rpyc:170
translate es day5_start2_7908ed7d:

    # player "My nemesis, you could say."
    player "Mi némesis, se podría decir."

# game/chapters/5_day.rpyc:171
translate es day5_start2_64b4b6aa:

    # GR "you dislike it that much?"
    GR "¿te desagrada tanto?"

# game/chapters/5_day.rpyc:175
translate es day5_start2_a071397c:

    # player "Absolutely despise it. You?"
    player "Lo detesto por completo. ¿Y tú?"

# game/chapters/5_day.rpyc:177
translate es day5_start2_c092d7be:

    # GR "i don't particularily feel either way for it."
    GR "a mí no me produce ningún sentimiento especial."

# game/chapters/5_day.rpyc:181
translate es day5_start2_1783d358:

    # player "You're more into Fall or Spring then, maybe?"
    player "¿Entonces te gusta más el otoño o la primavera?"

# game/chapters/5_day.rpyc:183
translate es day5_start2_8d8539e4:

    # GR "i wouldn't say that either."
    GR "Tampoco diría eso."

# game/chapters/5_day.rpyc:187
translate es day5_start2_7797b89b:

    # player "The good thing about Summer is less clothes ;)"
    player "Lo bueno del verano es que se lleva menos ropa ;)"

# game/chapters/5_day.rpyc:191
translate es day5_start2_f1feca0a:

    # player "Since it's so hot, you wouldn't wanna get all sweaty."
    player "Como hace tanto calor, no te gustaría acabar sudando."

# game/chapters/5_day.rpyc:194
translate es day5_start2_a8c7d6b2:

    # player "You get me?"
    player "¿Me entiendes?"

# game/chapters/5_day.rpyc:196
translate es day5_start2_8e4db62b:

    # GR "are you asking me to undress?"
    GR "¿me estás pidiendo que me desnude?"

# game/chapters/5_day.rpyc:200
translate es day5_start2_e6d0ec1b:

    # player "I wouldn't say no to that."
    player "No diría que no a eso."

# game/chapters/5_day.rpyc:203
translate es day5_start2_4fb082fb:

    # player "I thought you'd never ask."
    player "Pensaba que nunca me lo pedirías."

# game/chapters/5_day.rpyc:204
translate es day5_start2_6a7c7150:

    # GR "it wasn't intended as an invitation..."
    GR "no pretendía que fuera una invitación..."

# game/chapters/5_day.rpyc:207
translate es day5_start2_c3acde20:

    # player "Hey, if you want to."
    player "Oye, si tú quieres."

# game/chapters/5_day.rpyc:210
translate es day5_start2_65a23dda:

    # player "God, please???"
    player "Dios, ¿¿¿por favor???"

# game/chapters/5_day.rpyc:211
translate es day5_start2_05b26124:

    # GR "you speak to me."
    GR "estas hablando conmigo."

# game/chapters/5_day.rpyc:212
translate es day5_start2_42e958bb:

    # GR "there is no need to call out for someone else."
    GR "no hay necesidad de llamar a otra persona."

# game/chapters/5_day.rpyc:215
translate es day5_start2_5d080e9c:

    # player "Would you prefer I call out for you?"
    player "¿Preferirías que te llame?"

# game/chapters/5_day.rpyc:216
translate es day5_start2_cf8b98b7:

    # GR "yes, actually."
    GR "sí, en realidad."

# game/chapters/5_day.rpyc:220
translate es day5_start2_9f96c710:

    # player "We'll see about that ;)"
    player "Ya lo veremos ;)"

# game/chapters/5_day.rpyc:223
translate es day5_start2_a7e74852:

    # player "Have you not seen yourself?"
    player "¿No te has visto?"

# game/chapters/5_day.rpyc:226
translate es day5_start2_9ff9bc9a:

    # player "You've definitely got abs, right?"
    player "Definitivamente tienes abdominales, ¿verdad?"

# game/chapters/5_day.rpyc:228
translate es day5_start2_8dc3254e:

    # GR "i do, yes."
    GR "sí, los tengo."

# game/chapters/5_day.rpyc:229
translate es day5_start2_f5093aae:

    # GR "but, hm..."
    GR "pero, hm..."

# game/chapters/5_day.rpyc:230
translate es day5_start2_e5e77cca:

    # GR "perhaps it is you who should be undressing for the summer."
    GR "quizás seas tú quien debería desvestirse en verano."

# game/chapters/5_day.rpyc:234
translate es day5_start2_6fce98f3:

    # player "Oh? Why?"
    player "¿Oh? ¿Por qué?"

# game/chapters/5_day.rpyc:236
translate es day5_start2_95151b2c:

    # GR "....."
    GR "....."

# game/chapters/5_day.rpyc:237
translate es day5_start2_7a969ccc:

    # GR "no reason."
    GR "por nada."

# game/chapters/5_day.rpyc:238
translate es day5_start2_b25448a2:

    # GR "forget it."
    GR "olvídalo."

# game/chapters/5_day.rpyc:239
translate es day5_start2_2f26fd1f:

    # GR "what's wrong with me today, ugh.."
    GR "qué me pasa hoy, ugh.."

# game/chapters/5_day.rpyc:242
translate es day5_start2_af976602:

    # player "Fall."
    player "Otoño."

# game/chapters/5_day.rpyc:245
translate es day5_start2_05b412a8:

    # player "Not too hot, not too cold."
    player "Ni muy caliente, ni muy frío."

# game/chapters/5_day.rpyc:248
translate es day5_start2_58cb7851:

    # player "And the ground looks very pretty with all of the leaves."
    player "Y el suelo se ve muy bonito con todas las hojas."

# game/chapters/5_day.rpyc:250
translate es day5_start2_70709ddb:

    # GR "you like a season most because of the leaves?"
    GR "¿te gusta más una estación por las hojas?"

# game/chapters/5_day.rpyc:254
translate es day5_start2_6d194429:

    # player "Yeah, I guess so. It's a comfortable season."
    player "Sí, supongo que sí. Es una estación agradable."

# game/chapters/5_day.rpyc:258
translate es day5_start2_e04edcfd:

    # player "Warm jumpers, hot chocolate and books :)"
    player "Suéteres cálidos, chocolate caliente y libros :)"

# game/chapters/5_day.rpyc:260
translate es day5_start2_c65327f3:

    # player "Pretty colors everywhere I look!"
    player "¡Bonitos colores en todas partes!"

# game/chapters/5_day.rpyc:264
translate es day5_start2_76261bbb:

    # player "You feel me?"
    player "¿Me entiendes?"

# game/chapters/5_day.rpyc:266
translate es day5_start2_4f6413c2:

    # GR "feel you... no, i can't say i do."
    GR "entenderte... no, no puedo decir que sí."

# game/chapters/5_day.rpyc:270
translate es day5_start2_6d357f11:

    # player "Why, do you want to?"
    player "¿Por qué, te gustaría?"

# game/chapters/5_day.rpyc:274
translate es day5_start2_aebf4aac:

    # player "I bet you thought of touching my hand or hugging me once or twice before."
    player "Apuesto a que has pensado en tocarme la mano o abrazarme alguna vez."

# game/chapters/5_day.rpyc:277
translate es day5_start2_d196797f:

    # player "I wouldn't mind."
    player "No me importaría."

# game/chapters/5_day.rpyc:280
translate es day5_start2_3eaa6061:

    # player "I don't usually like touching much, but with you..."
    player "Normalmente, no me gusta el contacto físico, pero contigo..."

# game/chapters/5_day.rpyc:283
translate es day5_start2_2d7d93d2:

    # player "I've thought about it a little."
    player "Lo he pensado un poco."

# game/chapters/5_day.rpyc:286
translate es day5_start2_3f3479df:

    # player "You'd have to ask veeeery nicely."
    player "Tendrías que pedírmelo muuuuy amablemente."

# game/chapters/5_day.rpyc:291
translate es day5_start2_8ff28fad:

    # GR "you... want my touch? the feel of my skin on yours?"
    GR "¿tu... quieres que te toque? ¿sentir mi piel sobre la tuya?"

# game/chapters/5_day.rpyc:295
translate es day5_start2_6d448039:

    # player "Um. Yeah."
    player "Um. Sí."

# game/chapters/5_day.rpyc:298
translate es day5_start2_5da71b34:

    # player "I crave it."
    player "Lo deseo con todas mis fuerzas."

# game/chapters/5_day.rpyc:301
translate es day5_start2_b2ea0240:

    # player "The touch of death... I wouldn't mind it."
    player "El toque de la muerte... no me importaría."

# game/chapters/5_day.rpyc:304
translate es day5_start2_6b9fbf1f:

    # player "If you were here right now, I'd ask you to."
    player "Si estuvieras aquí ahora mismo, te lo pediría."

# game/chapters/5_day.rpyc:308
translate es day5_start2_6e843540:

    # player "I might even say please."
    player "Incluso podría decir por favor."

# game/chapters/5_day.rpyc:310
translate es day5_start2_40924fd8:

    # GR "well, i... ahem... uh..."
    GR "bueno, yo... ejem... uh..."

# game/chapters/5_day.rpyc:311
translate es day5_start2_431c97f2:

    # GR "if you... if you were... right there, i mean..."
    GR "si tú... si tú estuvieras... aqui mismo, quiero decir..."

# game/chapters/5_day.rpyc:312
translate es day5_start2_76ae8eee:

    # GR "ugh, what am i saying..."
    GR "ugh, qué estoy diciendo..."

# game/chapters/5_day.rpyc:313
translate es day5_start2_1a045267:

    # GR "what's wrong with me today..."
    GR "Qué me pasa hoy..."

# game/chapters/5_day.rpyc:316
translate es day5_start2_cc8e3c1c:

    # player "Winter."
    player "Invierno."

# game/chapters/5_day.rpyc:319
translate es day5_start2_59df315a:

    # player "I like the cold weather."
    player "Me gusta el clima frío."

# game/chapters/5_day.rpyc:322
translate es day5_start2_4f174c27:

    # player "And winter fashion is really quite nice."
    player "Y la moda de invierno es realmente muy bonita."

# game/chapters/5_day.rpyc:325
translate es day5_start2_348286e1:

    # player "Plus it's great weather to snuggle in."
    player "Además, es un buen clima para abrasarse."

# game/chapters/5_day.rpyc:328
translate es day5_start2_7a7c2560:

    # player "You seem like you'd be good for snuggling."
    player "Pareces alguien con quien se puede estar bien abrazado."

# game/chapters/5_day.rpyc:330
translate es day5_start2_e5806580:

    # GR "i... would be good for snuggling?"
    GR "¿yo... sería bueno para abrazar?"

# game/chapters/5_day.rpyc:334
translate es day5_start2_0e1059e1:

    # player "Yeah, you down?"
    player "Sí, ¿te apuntas?"

# game/chapters/5_day.rpyc:337
translate es day5_start2_47518f40:

    # player "Skin to skin contact helps conserve heat, and all that."
    player "El contacto piel con piel ayuda a conservar el calor y todo eso."

# game/chapters/5_day.rpyc:340
translate es day5_start2_707ee979:

    # player "We should test it out. For science."
    player "Deberíamos probarlo. Por ciencia."

# game/chapters/5_day.rpyc:342
translate es day5_start2_135ca175:

    # GR "i... will leave science to more scientific men."
    GR "yo... dejaré la ciencia para hombres más científicos."

# game/chapters/5_day.rpyc:346
translate es day5_start2_efa38a2b:

    # player "Then how about just for fun?"
    player "Entonces, ¿qué tal solo por diversión?"

# game/chapters/5_day.rpyc:348
translate es day5_start2_306fd414:

    # GR "um. well."
    GR "umm. bueno."

# game/chapters/5_day.rpyc:349
translate es day5_start2_5170eab4:

    # GR "i, uh... then i would be, as you said, 'down'."
    GR "yo... entonces estaría, como tú has dicho, 'dispuesto'."

# game/chapters/5_day.rpyc:350
translate es day5_start2_8f295266:

    # GR "i.. have wondered... what it would be like to hold you... i mean, someone."
    GR "me he preguntado... cómo sería abrazarte... quiero decir, a alguien."

# game/chapters/5_day.rpyc:351
translate es day5_start2_866acbb8:

    # GR "what am i saying... ugh, nevermind."
    GR "qué estoy diciendo... ugh, no importa."

# game/chapters/5_day.rpyc:354
translate es day5_start2_d0c65d8c:

    # player "Spring."
    player "Primavera."

# game/chapters/5_day.rpyc:359
translate es day5_start2_197cd157:

    # player "Warmer weather, and all of those pretty flowers..."
    player "Clima más cálido y todas esas bonitas flores..."

# game/chapters/5_day.rpyc:363
translate es day5_start2_f45a8a4d:

    # player "It really is the best time of the year."
    player "Realmente es la mejor época del año."

# game/chapters/5_day.rpyc:366
translate es day5_start2_d6a22c1f:

    # player "I've always wanted to do a Spring photoshoot with flowers or something."
    player "Siempre quise hacer una sesión de fotos de primavera con flores o algo."

# game/chapters/5_day.rpyc:369
translate es day5_start2_36545c27:

    # player "If you wanted to, you could join me. You, me, and the flowers :)"
    player "Si quisieras, podrías unirte a mí. Tú, yo, y las flores :)"

# game/chapters/5_day.rpyc:371
translate es day5_start2_55cde8a8:

    # GR "what about clothing items? is there really nothing else?"
    GR "¿y qué hay de la ropa? ¿de verdad no hay nada más?"

# game/chapters/5_day.rpyc:375
translate es day5_start2_1a8dc9d5:

    # player "That's {i}not{/i} what I meant..."
    player "Eso {i}no{/i} es lo que quería decir..."

# game/chapters/5_day.rpyc:378
translate es day5_start2_56083f34:

    # player "But I'm down for being a little scandalous."
    player "Pero no me importa que sea un poco escandalosa."

# game/chapters/5_day.rpyc:380
translate es day5_start2_f4b38aa7:

    # player "You're adventurous today!"
    player "¡Hoy estás muy atrevido!"

# game/chapters/5_day.rpyc:382
translate es day5_start2_0da1fe6f:

    # player "Why not. That sounds fun."
    player "Porqué no. Suena divertido."

# game/chapters/5_day.rpyc:386
translate es day5_start2_0bf64b92:

    # player "How about I take the photos, and you pose?"
    player "¿Qué tal si yo hago las fotos y tú posas?"

# game/chapters/5_day.rpyc:390
translate es day5_start2_6d25e06e:

    # player "I feel like red flowers would look nice in your hair."
    player "Creo que unas flores rojas te quedarían muy bien en el cabello."

# game/chapters/5_day.rpyc:394
translate es day5_start2_9b7dd455:

    # player "And against your skin."
    player "Y contra tu piel."

# game/chapters/5_day.rpyc:396
translate es day5_start2_aa055eda:

    # GR "you plan to photograph {i}me{/i} naked?"
    GR "¿planeas {i}fotografiarme{/i} desnudo?"

# game/chapters/5_day.rpyc:397
translate es day5_start2_e9749f16:

    # GR "i thought it would be pictures of you."
    GR "pensé que serían fotos tuyas."

# game/chapters/5_day.rpyc:401
translate es day5_start2_ec563484:

    # player "Why, do you want me to?"
    player "¿Por qué, quieres que lo haga?"

# game/chapters/5_day.rpyc:403
translate es day5_start2_d4cfe320:

    # GR "um..."
    GR "um..."

# game/chapters/5_day.rpyc:404
translate es day5_start2_47b81562:

    # GR "i... would be lying if i said no. and i cannot lie, as you know."
    GR "yo... mentiría si dijera que no. Y no puedo mentir, como bien sabes."

# game/chapters/5_day.rpyc:405
translate es day5_start2_019b7a7a:

    # GR "so what i mean to say is that..."
    GR "lo que quiero decir es que..."

# game/chapters/5_day.rpyc:406
translate es day5_start2_a659b66d:

    # GR "yes... or, well, perhaps... um..."
    GR "sí... o, bueno, tal vez... eh..."

# game/chapters/5_day.rpyc:407
translate es day5_start2_609de987:

    # GR "ugh, what's wrong with me..."
    GR "ugh, qué me pasa..."

# game/chapters/5_day.rpyc:411
translate es day5_start2_aa290c4f:

    # player "I'm actually a little lost for words."
    player "La verdad es que no sé qué decir."

# game/chapters/5_day.rpyc:414
translate es day5_start2_05a386d9:

    # player "You're... very forward today."
    player "Hoy estás... muy atrevido."

# game/chapters/5_day.rpyc:417
translate es day5_start2_8b25e423:

    # player "Not that I mind! Like at all!"
    player "¡No es que me importe! ¡En absoluto!"

# game/chapters/5_day.rpyc:421
translate es day5_start2_98e64b02:

    # player "In fact, I quite like it."
    player "De hecho, me gusta bastante."

# game/chapters/5_day.rpyc:424
translate es day5_start2_637fe907:

    # player "But, uh... is that meant to be flirting?"
    player "Pero, eh... ¿eso se supone que es coquetear?"

# game/chapters/5_day.rpyc:425
translate es day5_start2_bbfda765:

    # GR "i... what? flirting? don't be absurd, mortal."
    GR "yo... ¿qué? ¿coquetear? ni se te ocurra, mortal."

# game/chapters/5_day.rpyc:426
translate es day5_start2_84c8f829:

    # GR "the... the grim reaper does not {i}flirt{/}."
    GR "la...la Parca no {i}coquetea{/}."

# game/chapters/5_day.rpyc:427
translate es day5_start2_e0ad3aa5:

    # GR "that would be... ridiculous."
    GR "Eso sería... ridículo."

# game/chapters/5_day.rpyc:431
translate es day5_start2_fd7bb3fa:

    # player "Wow, you're really wooing me right now."
    player "Wow, realmente me estás seduciendo en este momento."

# game/chapters/5_day.rpyc:434
translate es day5_start2_ab5d136d:

    # player "Flirt away, Grim."
    player "Coquetea todo lo que quieras, Parca."

# game/chapters/5_day.rpyc:437
translate es day5_start2_5a0b5f75:

    # player "Are you feeling okay?"
    player "¿Te sientes bien?"

# game/chapters/5_day.rpyc:440
translate es day5_start2_e5cb73c6:

    # player "You're acting very weird."
    player "Estás actuando muy raro."

# game/chapters/5_day.rpyc:443
translate es day5_start2_ed8b7802:

    # player "Where is my grumpy Grim gone?"
    player "¿Dónde se ha ido mi Parca gruñóna?"

# game/chapters/5_day.rpyc:444
translate es day5_start2_29dd44b9:

    # GR "i, um... i'm feeling a little tired..."
    GR "yo, umm... me siento un poco cansado..."

# game/chapters/5_day.rpyc:445
translate es day5_start2_4a5861b4:

    # GR "i have not been sleeping. much. at all?"
    GR "no he estado durmiendo. ¿mucho? ¿en absoluto?"

# game/chapters/5_day.rpyc:446
translate es day5_start2_a34e53ee:

    # GR "and that's your fault."
    GR "y eso es tu culpa."

# game/chapters/5_day.rpyc:449
translate es day5_start2_ef32c1c8:

    # player "And so... now you've decided to strangely flirt with me?"
    player "Y entonces... ¿ahora has decidido coquetear conmigo de forma extraña?"

# game/chapters/5_day.rpyc:451
translate es day5_start2_6565754b:

    # GR "flirting??? the grim reaper... i... i do not flirt."
    GR "¿¿¿coquetear??? la parca... yo... yo no coqueteo."

# game/chapters/5_day.rpyc:455
translate es day5_start2_3560d363:

    # player "Then what are you doing?"
    player "Entonces, ¿qué estás haciendo?"

# game/chapters/5_day.rpyc:456
translate es day5_start2_dbeccc73:

    # GR "just... uh... speaking normally."
    GR "solo... uh... hablando normalmente."

# game/chapters/5_day.rpyc:457
translate es day5_start2_d9bfce47:

    # GR "thinking too much about you."
    GR "pensando demasiado en ti."

# game/chapters/5_day.rpyc:458
translate es day5_start2_51a923d1:

    # GR "i mean... thinking too much of taking your soul, obviously!"
    GR "quiero decir... ¡pensando demasiado en llevarme tu alma, obviamente!"

# game/chapters/5_day.rpyc:460
translate es day5_start2_ff74a288:

    # GR "anyway. my questions."
    GR "de todos modos, mis preguntas."

# game/chapters/5_day.rpyc:461
translate es day5_start2_2808f0f3:

    # GR "what about your family?"
    GR "¿qué hay de tu familia?"

# game/chapters/5_day.rpyc:465
translate es day5_start2_0ff7170e:

    # player "Want to meet the in-laws, Grim?"
    player "¿Quieres conocer a tus suegros, Parca?"

# game/chapters/5_day.rpyc:466
translate es day5_start2_c5d6dc6d:

    # GR "we are not married."
    GR "no estamos casados."

# game/chapters/5_day.rpyc:469
translate es day5_start2_0678352f:

    # player "Should we get married, then?"
    player "¿Deberíamos casarnos, entonces?"

# game/chapters/5_day.rpyc:470
translate es day5_start2_cc21bd84:

    # GR "!!!"
    GR "!!!"

# game/chapters/5_day.rpyc:471
translate es day5_start2_3c967b36:

    # GR "right now? that's... that's a little short notice!"
    GR "¿ahora mismo? ¡eso es... eso es muy poco tiempo!"

# game/chapters/5_day.rpyc:474
translate es day5_start2_797d50a3:

    # player "Fine, fine."
    player "Bien, bien."

# game/chapters/5_day.rpyc:477
translate es day5_start2_f2a8b26b:

    # player "Maybe later then."
    player "Tal vez más tarde entonces."

# game/chapters/5_day.rpyc:480
translate es day5_start2_17f1454c:

    # player "What did you wanna know about them?"
    player "¿Qué querías saber sobre ellos?"

# game/chapters/5_day.rpyc:483
translate es day5_start2_d298f672:

    # player "Want to meet my family, do you?"
    player "¿Quieres conocer a mi familia, ¿verdad?"

# game/chapters/5_day.rpyc:484
translate es day5_start2_4046ac5d:

    # GR "are they as... enthusiastic as you?"
    GR "¿son tan... entusiastas como tú?"

# game/chapters/5_day.rpyc:487
translate es day5_start2_12e06e7f:

    # player "They are 100 percent worse."
    player "Son 100 por ciento peores."

# game/chapters/5_day.rpyc:491
translate es day5_start2_1f135242:

    # player "Just a fair warning."
    player "Solo una advertencia."

# game/chapters/5_day.rpyc:494
translate es day5_start2_aecd6c96:

    # player "I'm something of a black sheep in my family."
    player "Soy una especie de oveja negra en mi familia."

# game/chapters/5_day.rpyc:498
translate es day5_start2_54b889c3:

    # player "Compared to me, you'd be able to deal with them easily."
    player "En comparación a mí, podrías lidiar con ellos fácilmente."

# game/chapters/5_day.rpyc:499
translate es day5_start2_f2a3013d:

    # GR "yes, well, you have provided good practice at being around mortals."
    GR "sí, bueno, me has enseñado a relacionarme con los mortales."

# game/chapters/5_day.rpyc:500
translate es day5_start2_0135aca7:

    # GR "difficult mortals."
    GR "mortales difíciles."

# game/chapters/5_day.rpyc:503
translate es day5_start2_17f1454c_1:

    # player "What did you wanna know about them?"
    player "¿Qué querías saber sobre ellos?>"

# game/chapters/5_day.rpyc:506
translate es day5_start2_c3f26f75:

    # player "I don't really like talking about my family."
    player "Realmente no me gusta hablar de mi familia."

# game/chapters/5_day.rpyc:509
translate es day5_start2_82c1fe2d:

    # player "Can we maybe skip this question...?"
    player "¿Podemos saltar esa pregunta...?"

# game/chapters/5_day.rpyc:510
translate es day5_start2_c9ec2b7b:

    # GR "...okay. yes, of course."
    GR "...bueno. sí, claro."

# game/chapters/5_day.rpyc:513
translate es day5_start2_10618ec5:

    # player "Thank you, Grim."
    player "Gracias, Parca."

# game/chapters/5_day.rpyc:516
translate es day5_start2_29c83294:

    # player "Let's skip to the next question."
    player "Pasemos a la siguiente pregunta."

# game/chapters/5_day.rpyc:519
translate es day5_start2_3260c50f:

    # player "I'm just not ready to talk about it yet."
    player "Todavía no soy capaz de hablar de eso."

# game/chapters/5_day.rpyc:520
translate es day5_start2_1d6acec6:

    # GR "that's fine."
    GR "está bien."

# game/chapters/5_day.rpyc:521
translate es day5_start2_19054b1e:

    # GR "let's move to a different question."
    GR "pasemos a una pregunta diferente."

# game/chapters/5_day.rpyc:524
translate es day5_start2_7d808f35:

    # player "Yeah, thanks Grim."
    player "Sí, gracias Parca."

# game/chapters/5_day.rpyc:529
translate es day5_start2_9db98616:

    # player "I don't mind if you ask me questions about them,."
    player "No me molesta que me hagas preguntas sobre ellos."

# game/chapters/5_day.rpyc:533
translate es day5_start2_572f66b9:

    # GR "do you have any family?"
    GR "¿Tienes familia?"

# game/chapters/5_day.rpyc:537
translate es day5_start2_6bd97f64:

    # player "Of course I do."
    player "Por supuesto que sí."

# game/chapters/5_day.rpyc:540
translate es day5_start2_f5379dfd:

    # player "I see them pretty often. We're close."
    player "Los veo bastante seguido. Somos muy unidos."

# game/chapters/5_day.rpyc:543
translate es day5_start2_865d0f15:

    # player "Some of them live in this same building."
    player "Algunos de ellos viven en este mismo edificio."

# game/chapters/5_day.rpyc:546
translate es day5_start2_47dc1e33:

    # player "Kinda hard to not see them, actually."
    player "La verdad, es difícil no verlos."

# game/chapters/5_day.rpyc:547
translate es day5_start2_18851564:

    # GR "that sounds exhausting."
    GR "eso suena agotador."

# game/chapters/5_day.rpyc:550
translate es day5_start2_f6d521ff:

    # player "You wouldn't like living with your family?"
    player "¿No te gustaría vivir con tu familia?"

# game/chapters/5_day.rpyc:551
translate es day5_start2_7772a27d_2:

    # GR "..."
    GR "..."

# game/chapters/5_day.rpyc:552
translate es day5_start2_cac79a7e:

    # GR "i like to have my own personal space. i have never shared it."
    GR "me gusta tener mi propio espacio personal. nunca lo he compartido."

# game/chapters/5_day.rpyc:555
translate es day5_start2_6b0c3900:

    # player "That's fair."
    player "Tienes razón."

# game/chapters/5_day.rpyc:558
translate es day5_start2_0bb2b68b:

    # player "I was thinking about moving at some point."
    player "Estaba pensando en mudarme en algún momento."

# game/chapters/5_day.rpyc:562
translate es day5_start2_73f6d1b8:

    # player "Living somewhere a little more solitary."
    player "Vivir en un lugar un poco más solitario."

# game/chapters/5_day.rpyc:566
translate es day5_start2_2eeb7da0:

    # player "I love my family, but I agree it can be exhausting."
    player "Amo a mi familia, pero estoy de acuerdo en que puede ser agotador."

# game/chapters/5_day.rpyc:569
translate es day5_start2_b3af9a2e:

    # player "I wouldn't mind seeing them a little less sometimes, haha."
    player "No me importaría verlos un poco menos a veces, jaja."

# game/chapters/5_day.rpyc:571
translate es day5_start2_9fc50aea:

    # GR "indeed, it sounds like a move would be good for you."
    GR "de hecho, parece que mudarse sería bueno para ti."

# game/chapters/5_day.rpyc:575
translate es day5_start2_561f68b4:

    # player "Decorating a whole house myself will also be nice."
    player "Decorar toda la casa por mi cuenta también será agradable."

# game/chapters/5_day.rpyc:579
translate es day5_start2_ea4b0dfa:

    # player "I like my apartment, but I could use some more space."
    player "Me gusta mi apartamento, pero me vendría bien un poco más de espacio."

# game/chapters/5_day.rpyc:583
translate es day5_start2_80d370b0:

    # player "But I am a little worried that I'd get kinda lonely after awhile."
    player "Pero me preocupa un poco volverme una persona solitaria después de un tiempo."

# game/chapters/5_day.rpyc:586
translate es day5_start2_c4a47185:

    # player "Maybe you could just come move in with me, huh?"
    player "¿Quizás podrías venir a vivir conmigo, huh?"

# game/chapters/5_day.rpyc:587
translate es day5_start2_8f5079b9:

    # GR "me?"
    GR "¿yo?"

# game/chapters/5_day.rpyc:590
translate es day5_start2_ba38ebb9:

    # player "Yes you. Who else would I ask?"
    player "Si tu. ¿A quién más le preguntaría?"

# game/chapters/5_day.rpyc:593
translate es day5_start2_ecdc0e1f:

    # player "Sounds kinda nice, don't you think?"
    player "Suena bastante bien, ¿no crees?"

# game/chapters/5_day.rpyc:596
translate es day5_start2_992c3110:

    # player "We'll have to merge our aesthetics somehow, but I'm sure we can figure that out."
    player "Tendremos que combinar nuestras estéticas de alguna manera, pero lo conseguiremos."

# game/chapters/5_day.rpyc:599
translate es day5_start2_566b697b:

    # player "I'd be too scared to live completely alone."
    player "Me daría demasiado miedo vivir completamente a solas."

# game/chapters/5_day.rpyc:602
translate es day5_start2_2d4787f5:

    # player "I'm so used to having people around me."
    player "Tengo tanta costumbre de tener gente a mi alrededor."

# game/chapters/5_day.rpyc:605
translate es day5_start2_64bdab83:

    # player "So if I ever moved out, it would have to be with someone else."
    player "Así que si alguna vez me mudara, tendría que ser con otra persona."

# game/chapters/5_day.rpyc:606
translate es day5_start2_38a3e0bb:

    # GR "you are scared to be alone?"
    GR "¿te da miedo la soledad?"

# game/chapters/5_day.rpyc:609
translate es day5_start2_b63abf0c:

    # player "Everyone is scared of something."
    player "Todos tienen miedo de algo."

# game/chapters/5_day.rpyc:612
translate es day5_start2_a703cd3f:

    # player "It's just one of those things you can't control."
    player "Es solo una de esas cosas que no puedes controlar."

# game/chapters/5_day.rpyc:613
translate es day5_start2_03767585:

    # GR "i see."
    GR "ya veo."

# game/chapters/5_day.rpyc:616
translate es day5_start2_c4a47185_1:

    # player "Maybe you could just come move in with me, huh?"
    player "¿Tal vez podrías venir a vivir conmigo, huh?"

# game/chapters/5_day.rpyc:617
translate es day5_start2_eee5c952:

    # GR "me? why?"
    GR "¿yo? ¿por qué?"

# game/chapters/5_day.rpyc:620
translate es day5_start2_3d5be9cb:

    # player "I won't ever get lonely if I'm with you."
    player "Nunca me sentiré en soledad si estoy contigo."

# game/chapters/5_day.rpyc:622
translate es day5_start2_28c00a5e:

    # player "Sounds like a dream come true, that's why."
    player "Suena como un sueño hecho realidad, por eso."

# game/chapters/5_day.rpyc:624
translate es day5_start2_008cfe9d:

    # player "Because then I can wake up and tease you in person."
    player "Porque así podré despertarme y burlarme de ti en persona."

# game/chapters/5_day.rpyc:627
translate es day5_start2_5e1ab3b4:

    # player "Everyday."
    player "Cada día."

# game/chapters/5_day.rpyc:630
translate es day5_start2_f7f6ca29:

    # player "For the rest of forever."
    player "Por el resto de la eternidad."

# game/chapters/5_day.rpyc:631
translate es day5_start2_7253e19a:

    # GR "that is an extremely long time. also extremely terrifying."
    GR "es un tiempo extremadamente largo. también extremadamente aterrador."

# game/chapters/5_day.rpyc:635
translate es day5_start2_96dd4361:

    # player "We don't live too far apart."
    player "No vivimos muy lejos el uno del otro."

# game/chapters/5_day.rpyc:638
translate es day5_start2_d62ae62e:

    # player "So we catch up when we can."
    player "Así que nos ponemos al día cuando podemos."

# game/chapters/5_day.rpyc:640
translate es day5_start2_6c76a098:

    # GR "that sounds... nice."
    GR "eso suena... bien."

# game/chapters/5_day.rpyc:641
translate es day5_start2_ce9ed5e8:

    # GR "do you enjoy the proximity?"
    GR "¿disfrutas de la cercanía?"

# game/chapters/5_day.rpyc:645
translate es day5_start2_81185e0a:

    # player "I do, actually."
    player "La verdad es que sí."

# game/chapters/5_day.rpyc:649
translate es day5_start2_5782baf7:

    # player "I'm really close with my family."
    player "Tengo una relación muy estrecha con mi familia."

# game/chapters/5_day.rpyc:652
translate es day5_start2_fb62a976:

    # player "I don't, really."
    player "La verdad es que no."

# game/chapters/5_day.rpyc:656
translate es day5_start2_63d6131d:

    # player "I love them, but I like having space to myself."
    player "Los amo, pero me gusta tener espacio para mí."

# game/chapters/5_day.rpyc:661
translate es day5_start2_779ef889:

    # player "I've been considering moving for awhile, so I can have some more space."
    player "He estado pensando en mudarme desde hace tiempo, para tener más espacio."

# game/chapters/5_day.rpyc:663
translate es day5_start2_9317e71e:

    # GR "why would you need more space?"
    GR "¿por qué necesitarías más espacio?"

# game/chapters/5_day.rpyc:667
translate es day5_start2_f2557da0:

    # player "I like decorating. I want to decorate a whole house."
    player "Me gusta decorar. Quiero decorar una casa entera."

# game/chapters/5_day.rpyc:670
translate es day5_start2_e78cf39f:

    # player "More room for collectibles!"
    player "¡Más espacio para coleccionables!"

# game/chapters/5_day.rpyc:673
translate es day5_start2_b9703598:

    # player "Things are getting a little cramped here."
    player "Las cosas se están poniendo un poco apretadas aquí."

# game/chapters/5_day.rpyc:676
translate es day5_start2_d8d82918:

    # player "I want a garden, actually."
    player "Quiero un jardín, en realidad."

# game/chapters/5_day.rpyc:679
translate es day5_start2_f661e329:

    # GR "huh. i suppose that makes sense."
    GR "eh. supongo que eso tiene sentido."

# game/chapters/5_day.rpyc:680
translate es day5_start2_696b5722:

    # GR "my abode is quite small, but i've never thought of upgrading."
    GR "mi morada es bastante pequeña, pero nunca he pensado en cambiarla."

# game/chapters/5_day.rpyc:681
translate es day5_start2_4cd5105c:

    # GR "i'm not sure it's an option."
    GR "no estoy seguro de que sea una opción."

# game/chapters/5_day.rpyc:685
translate es day5_start2_9d696f50:

    # player "Hey, you can come share a place with me."
    player "Oye, puedes venir a compartir casa conmigo."

# game/chapters/5_day.rpyc:689
translate es day5_start2_9edab709:

    # player "I don't need an entire house to myself."
    player "No necesito una casa entera para mí."

# game/chapters/5_day.rpyc:691
translate es day5_start2_5aa63dbc:

    # GR "why would you want to live with me?"
    GR "¿Por qué ibas a querer vivir conmigo?"

# game/chapters/5_day.rpyc:695
translate es day5_start2_8304de6d:

    # player "Sadly I don't see them that much these days."
    player "Lamentablemente, no los veo mucho últimamente."

# game/chapters/5_day.rpyc:698
translate es day5_start2_629082ef:

    # player "Hopefully that'll change."
    player "Ojalá eso cambie."

# game/chapters/5_day.rpyc:702
translate es day5_start2_18c9a1d9:

    # player "It's a bit lonely being without them."
    player "Es un poco solitario estar sin ellos."

# game/chapters/5_day.rpyc:706
translate es day5_start2_beabd389:

    # player "Guess thats what happens when you move away."
    player "Supongo que eso es lo que sucede cuando te alejas."

# game/chapters/5_day.rpyc:710
translate es day5_start2_669e45b0:

    # player "I knew it would happen, but I'm still a little sad."
    player "Sabía que sucedería, pero todavía estoy un poco triste."

# game/chapters/5_day.rpyc:713
translate es day5_start2_bf0c001d:

    # player "I'm hoping I'll see them again soon."
    player "Espero volver a verlos pronto."

# game/chapters/5_day.rpyc:717
translate es day5_start2_0a5b77f2:

    # GR "why did you move away from them?"
    GR "¿por qué te alejaste de ellos?"

# game/chapters/5_day.rpyc:721
translate es day5_start2_f74411f5:

    # player "I moved for school, then stayed."
    player "Me mudé por estudios y luego me quedé."

# game/chapters/5_day.rpyc:724
translate es day5_start2_a9451d36:

    # player "House prices are too high back home."
    player "Los precios de las casas son demasiado altos en mi país."

# game/chapters/5_day.rpyc:727
translate es day5_start2_12801657:

    # player "I moved away for work."
    player "Me mudé por motivos laborales."

# game/chapters/5_day.rpyc:730
translate es day5_start2_f87d5fc5:

    # player "I just needed a change."
    player "Solo necesitaba un cambio."

# game/chapters/5_day.rpyc:732
translate es day5_start2_2641b324:

    # GR "i see. as good a reason as any."
    GR "ya veo. una razón tan buena como cualquier otra."

# game/chapters/5_day.rpyc:736
translate es day5_start2_7ea63155:

    # player "I'd like to get a house at some point, but I think I'd have to move even further away."
    player "Me gustaría conseguir una casa en algún momento, pero creo que tendría que alejarme aún más."

# game/chapters/5_day.rpyc:740
translate es day5_start2_5318cf21:

    # player "Double as lonely!"
    player "¡El doble de soledad!"

# game/chapters/5_day.rpyc:744
translate es day5_start2_e565d25f:

    # player "Oh, I know. You could just move in with me!"
    player "Oh, ya sé. ¡Podrías mudarte conmigo!"

# game/chapters/5_day.rpyc:746
translate es day5_start2_5e646f99:

    # GR "huh?? me?"
    GR "¿¿eh?? ¿yo?"

# game/chapters/5_day.rpyc:751
translate es day5_start2_f55e41d3:

    # player "Not really."
    player "No precisamente."

# game/chapters/5_day.rpyc:754
translate es day5_start2_29113672:

    # player "No."
    player "No."

# game/chapters/5_day.rpyc:756
translate es day5_start2_cda36214:

    # player "Not anymore, anyway."
    player "Ya no, en cualquier caso."

# game/chapters/5_day.rpyc:757
translate es day5_start2_7772a27d_3:

    # GR "..."
    GR "..."

# game/chapters/5_day.rpyc:758
translate es day5_start2_5b3e0e01:

    # GR "my apologies. i did not mean to bring up a difficult subject."
    GR "mis disculpas. no quise mencionar un tema difícil."

# game/chapters/5_day.rpyc:759
translate es day5_start2_e6cf59cb:

    # GR "made even more difficult because of my profession, i assume."
    GR "supongo que mi profesión lo hace aún más difícil."

# game/chapters/5_day.rpyc:763
translate es day5_start2_6d6fa134:

    # player "It's fine, I don't mind talking about it."
    player "Está bien, no me importa hablar de eso."

# game/chapters/5_day.rpyc:766
translate es day5_start2_1035cac3:

    # player "It's been just me for awhile."
    player "He sido solo yo durante un tiempo."

# game/chapters/5_day.rpyc:769
translate es day5_start2_508e1132:

    # player "It's kind of a recent thing."
    player "Es algo bastante reciente."

# game/chapters/5_day.rpyc:773
translate es day5_start2_ff2211a5:

    # player "It's been hard, because I was very close with them."
    player "Ha sido difícil, porque les tenía mucho cariño."

# game/chapters/5_day.rpyc:776
translate es day5_start2_999cb2d6:

    # player "We weren't close, but it's still been hard."
    player "No teníamos una relación cercana, pero aun así ha sido difícil."

# game/chapters/5_day.rpyc:778
translate es day5_start2_79e7c9c6:

    # GR "so that is why you live alone?"
    GR "¿por eso no vives con nadie?"

# game/chapters/5_day.rpyc:782
translate es day5_start2_7da113b1:

    # player "Pretty much."
    player "Más o menos."

# game/chapters/5_day.rpyc:786
translate es day5_start2_06f5e783:

    # player "I don't mind it, but it's a little lonely."
    player "No me molesta, pero es un poco solitario."

# game/chapters/5_day.rpyc:789
translate es day5_start2_25b3bb6e:

    # player "I don't like living alone much."
    player "No me gusta mucho la vida solitaria."

# game/chapters/5_day.rpyc:792
translate es day5_start2_05460bf1:

    # player "I much prefer being around more people."
    player "Prefiero estar cerca de más personas."

# game/chapters/5_day.rpyc:796
translate es day5_start2_f4954ea2:

    # player "You could just come join me, of course."
    player "Por supuesto, puedes venir conmigo."

# game/chapters/5_day.rpyc:798
translate es day5_start2_3a919061:

    # GR "me???"
    GR "¿¿¿yo???"

# game/chapters/5_day.rpyc:802
translate es day5_start2_b4316465:

    # player "Thanks for being considerate."
    player "Gracias por ser considerado."

# game/chapters/5_day.rpyc:805
translate es day5_start2_50646155:

    # player "That surprised me."
    player "Eso me sorprendió."

# game/chapters/5_day.rpyc:808
translate es day5_start2_887f19b3:

    # player "Thanks."
    player "Gracias."

# game/chapters/5_day.rpyc:809
translate es day5_start2_2a66e123:

    # GR "i don't think that deserves thanks."
    GR "no creo que eso merezca un agradecimiento."

# game/chapters/5_day.rpyc:810
translate es day5_start2_6afdeedd:

    # GR "especially not twice."
    GR "especialmente no dos veces."

# game/chapters/5_day.rpyc:812
translate es day5_start2_c8e86e95:

    # GR "then, let's change the subject."
    GR "entonces, cambiemos el tema."

# game/chapters/5_day.rpyc:813
translate es day5_start2_4017e373:

    # GR "why did you paint your walls that color?"
    GR "¿por qué pintaste tus paredes de ese color?"

# game/chapters/5_day.rpyc:817
translate es day5_start2_da2d8930:

    # player "I like the color."
    player "Me gusta ese color."

# game/chapters/5_day.rpyc:818
translate es day5_start2_5bc5deea:

    # GR "it does suit you."
    GR "te queda bien."

# game/chapters/5_day.rpyc:822
translate es day5_start2_df269ff8:

    # player "And why did you pick your wall color, Mr Reaper?"
    player "¿Y por qué eligió el color de su pared, Sr. Parca?"

# game/chapters/5_day.rpyc:823
translate es day5_start2_7851c558:

    # GR "for a similar reason to you."
    GR "por una razón similar a la tuya."

# game/chapters/5_day.rpyc:824
translate es day5_start2_4a13715d:

    # GR "i liked the color."
    GR "me gustó ese color."

# game/chapters/5_day.rpyc:825
translate es day5_start2_5da1ecd3:

    # GR "i think it suits me."
    GR "creo que me queda bien."

# game/chapters/5_day.rpyc:828
translate es day5_start2_de8d1c27:

    # player "They were already that color."
    player "Ya eran de ese color."

# game/chapters/5_day.rpyc:831
translate es day5_start2_261fcd28:

    # player "I kinda grew to like it, though."
    player "Sin embargo, con el tiempo me empezó a gustar."

# game/chapters/5_day.rpyc:833
translate es day5_start2_a8f73e12:

    # player "And I couldn't be bothered to repaint, you know?"
    player "Y no me apetecía volver a pintar, ¿sabes?"

# game/chapters/5_day.rpyc:835
translate es day5_start2_0b32795c:

    # player "And I already liked that color. It's a win-win really."
    player "Y ya me gustaba ese color. Es realmente un beneficio mutuo."

# game/chapters/5_day.rpyc:838
translate es day5_start2_9e8965f6:

    # player "Why, do you not like the color of my walls?"
    player "¿Por qué? ¿No te gusta el color de mis paredes?"

# game/chapters/5_day.rpyc:840
translate es day5_start2_6334ff88:

    # GR "i was just curious."
    GR "solo tenía curiosidad."

# game/chapters/5_day.rpyc:844
translate es day5_start2_315c9706:

    # player "Well, if we ever live together I'm going to pick the color scheme."
    player "Bueno, si alguna vez vivimos juntos, yo elegiré la combinación de colores."

# game/chapters/5_day.rpyc:846
translate es day5_start2_7dd18653:

    # GR "and since when are we moving in together, mortal?"
    GR "¿y desde cuándo vamos a vivir juntos, mortal?"

# game/chapters/5_day.rpyc:850
translate es day5_start2_c286ac18:

    # player "I said {i}if{/i}."
    player "Dije '{i}si alguna vez{/i}'."

# game/chapters/5_day.rpyc:853
translate es day5_start2_9529a1c3:

    # player "You never know what'll happen in the future."
    player "Nunca se sabe lo que sucederá en el futuro."

# game/chapters/5_day.rpyc:856
translate es day5_start2_6ef3f443:

    # GR "little mortal, you wouldn't like living with me."
    GR "mortalcito, no te gustaría vivir conmigo."

# game/chapters/5_day.rpyc:859
translate es day5_start2_fab81563:

    # player "Do you hog the sheets?"
    player "¿Acaparas las sábanas?"

# game/chapters/5_day.rpyc:862
translate es day5_start2_1e1359ce:

    # player "Snore super loud?"
    player "¿Roncas super fuerte?"

# game/chapters/5_day.rpyc:864
translate es day5_start2_5f89c9aa:

    # GR "that is not what i meant at all."
    GR "eso no es lo que quise decir en absoluto."

# game/chapters/5_day.rpyc:865
translate es day5_start2_5cd76016:

    # GR "and no, i do neither of these things."
    GR "y no, no hago ninguna de estas dos cosas."

# game/chapters/5_day.rpyc:869
translate es day5_start2_0fa79698:

    # player "How do you know?"
    player "¿Cómo lo sabes?"

# game/chapters/5_day.rpyc:872
translate es day5_start2_706b4e14:

    # player "Unless someone's there to tell you?"
    player "¿A menos que haya alguien ahí para decírtelo?"

# game/chapters/5_day.rpyc:875
translate es day5_start2_d5b1e174:

    # player "{i}'O Grim we cannot be! You steal all the blankets and I was chilled to the bone!'{/i}"
    player "{i}'¡No puedo ser Parca! ¡Me robas todas las cobijas y me quedo helado hasta los huesos!'{/i}"

# game/chapters/5_day.rpyc:878
translate es day5_start2_f676fa1d:

    # player "{i}'And you snored so loudly I could not hear my own thoughts!'{/i}"
    player "{i}'¡Y roncabas tan fuerte que no podía escuchar mis propios pensamientos!'{/i}"

# game/chapters/5_day.rpyc:880
translate es day5_start2_7772a27d_4:

    # GR "..."
    GR "..."

# game/chapters/5_day.rpyc:881
translate es day5_start2_b8982dfd:

    # GR "you have a vivid imagination."
    GR "tienes una imaginación vívida."

# game/chapters/5_day.rpyc:882
translate es day5_start2_78146074:

    # GR "but no, i do not {i}sleep{/i} with others."
    GR "pero no, no {i}duermo{/i} con otras personas."

# game/chapters/5_day.rpyc:883
translate es day5_start2_2061896c:

    # GR "i don't like to share my own space."
    GR "no me gusta compartir mi espacio personal."

# game/chapters/5_day.rpyc:888
translate es day5_start2_058a19a9:

    # player "So there's no way for me to convince you?"
    player "¿Entonces no hay forma de que te convenza?"

# game/chapters/5_day.rpyc:890
translate es day5_start2_9a490430:

    # GR "i... why you would ever want to live with me, i will never understand."
    GR "yo... nunca entenderé por qué te gustaría vivir conmigo."

# game/chapters/5_day.rpyc:891
translate es day5_start2_fe352ff0:

    # GR "you didn't even know i existed a week ago."
    GR "ni siquiera sabías que existía hace una semana."

# game/chapters/5_day.rpyc:895
translate es day5_start2_9031bc01:

    # player "Okay. That is a totally reasonable point to make."
    player "Bueno. Ese es un punto totalmente razonable."

# game/chapters/5_day.rpyc:898
translate es day5_start2_b798bed4:

    # player "Very fair."
    player "Muy acertado."

# game/chapters/5_day.rpyc:900
translate es day5_start2_be67a938:

    # GR "exactly."
    GR "exactamente."

# game/chapters/5_day.rpyc:904
translate es day5_start2_97ccc370:

    # player "But once this week is over, I'll own {i}your{/i} soul."
    player "Pero una vez que termine esta semana, {i}tu{/i} alma me pertenecerá."

# game/chapters/5_day.rpyc:908
translate es day5_start2_6d1bfc0a:

    # player "Then we can revisit this."
    player "Entonces podemos volver a hablar de esto."

# game/chapters/5_day.rpyc:910
translate es day5_start2_8e83fd70:

    # GR "you definitely will not, but sure."
    GR "definitivamente, no será así, pero claro."

# game/chapters/5_day.rpyc:917
translate es day5_start2_60534deb:

    # player "Back tracking a few steps then."
    player "Retrocedamos unos pasos entonces."

# game/chapters/5_day.rpyc:920
translate es day5_start2_f34cc444:

    # player "My family..."
    player "Mi familia..."

# game/chapters/5_day.rpyc:925
translate es day5_start2_34742a12:

    # player "I've got my Mom and Dad."
    player "Tengo a mi mamá y a mi papá."

# game/chapters/5_day.rpyc:929
translate es day5_start2_5a16e81a:

    # player "I've got two Moms, actually."
    player "Tengo dos mamás, en realidad."

# game/chapters/5_day.rpyc:933
translate es day5_start2_d0261213:

    # player "I've got two Dads!"
    player "¡Tengo dos papás!"

# game/chapters/5_day.rpyc:937
translate es day5_start2_45bffe15:

    # player "My Mom raised me alone."
    player "Mi mamá me crió sola."

# game/chapters/5_day.rpyc:940
translate es day5_start2_632a9ca2:

    # player "She's very strong and capable. I admire her."
    player "Ella es muy fuerte y capaz. La admiro."

# game/chapters/5_day.rpyc:943
translate es day5_start2_8689978f:

    # player "I can't imagine the stress of raising a child alone."
    player "No puedo imaginar el estrés de criar a un bebé sola."

# game/chapters/5_day.rpyc:946
translate es day5_start2_71a19799:

    # player "I'll always be thankful to her."
    player "Siempre estaré en deuda con ella."

# game/chapters/5_day.rpyc:949
translate es day5_start2_0ebedb36:

    # player "It must've been tough, considering I'm her kid."
    player "Debió de ser difícil, teniendo en cuenta que soy su retoño."

# game/chapters/5_day.rpyc:950
translate es day5_start2_434a6554:

    # GR "yes, i imagine you were a difficult child."
    GR "sí, imagino que eras uno de esos hijos difíciles."

# game/chapters/5_day.rpyc:953
translate es day5_start2_aae0ac46:

    # player "I was an absolute demon."
    player "Yo era un demonio absoluto."

# game/chapters/5_day.rpyc:955
translate es day5_start2_956bdfb6:

    # player "I wasn't too bad, all things considered."
    player "No me fue tan mal, considerando todas las circunstancias."

# game/chapters/5_day.rpyc:957
translate es day5_start2_18224a4c:

    # player "I was practically an angel. Definitely."
    player "Yo era prácticamente un ángel. Definitivamente."

# game/chapters/5_day.rpyc:961
translate es day5_start2_5f704799:

    # player "I wouldn't have changed what we had for the world, though."
    player "Sin embargo, no habría cambiado lo que teníamos por nada del mundo."

# game/chapters/5_day.rpyc:967
translate es day5_start2_ca973f42:

    # player "My Dad raised me by himself."
    player "Mi papá me crió solo."

# game/chapters/5_day.rpyc:971
translate es day5_start2_80973612:

    # player "And he did a brilliant job, if I can say so myself."
    player "E hizo un trabajo brillante, si puedo decirlo yo."

# game/chapters/5_day.rpyc:974
translate es day5_start2_53fb517e:

    # player "I think people usually assume a single parent would usually be the mother."
    player "Creo que la gente suele asumir que un solo padre generalmente sería la madre."

# game/chapters/5_day.rpyc:977
translate es day5_start2_500cf4a7:

    # player "But my Dad is awesome :D"
    player "Pero mi papá es increíble :D"

# game/chapters/5_day.rpyc:980
translate es day5_start2_f43e9a38:

    # player "It must've been tough, considering I'm his kid."
    player "Debe haber sido difícil, considerando que soy su retoño."

# game/chapters/5_day.rpyc:981
translate es day5_start2_434a6554_1:

    # GR "yes, i imagine you were a difficult child."
    GR "sí, imagino que eras uno de esos hijos difíciles."

# game/chapters/5_day.rpyc:984
translate es day5_start2_aae0ac46_1:

    # player "I was an absolute demon."
    player "Yo era un demonio absoluto."

# game/chapters/5_day.rpyc:986
translate es day5_start2_956bdfb6_1:

    # player "I wasn't too bad, all things considered."
    player "No me fue tan mal, considerando todas las circunstancias."

# game/chapters/5_day.rpyc:988
translate es day5_start2_18224a4c_1:

    # player "I was practically an angel. Definitely."
    player "Yo era prácticamente un ángel. Definitivamente."

# game/chapters/5_day.rpyc:991
translate es day5_start2_5f704799_1:

    # player "I wouldn't have changed what we had for the world, though."
    player "Sin embargo, no habría cambiado lo que teníamos por nada del mundo."

# game/chapters/5_day.rpyc:996
translate es day5_start2_e1375193:

    # player "My older sibling raised me, actually."
    player "Uno de mis hermanos mayores me crió, en realidad."

# game/chapters/5_day.rpyc:997
translate es day5_start2_161f0551:

    # GR "your sibling?"
    GR "¿uno de tus hermanos?"

# game/chapters/5_day.rpyc:1000
translate es day5_start2_2557fa58:

    # player "Yep! She's amazing!"
    player "¡Síp! ¡Ella es increíble!"

# game/chapters/5_day.rpyc:1003
translate es day5_start2_66c668cc:

    # player "She's a few years older than me."
    player "Ella es unos años mayor que yo."

# game/chapters/5_day.rpyc:1005
translate es day5_start2_01948e90:

    # GR "and your parents?"
    GR "¿y tus padres?"

# game/chapters/5_day.rpyc:1009
translate es day5_start2_c407ae34:

    # player "I've just always been closer to her, you know?"
    player "Siempre he tenido más confianza con ella, ¿sabes?"

# game/chapters/5_day.rpyc:1012
translate es day5_start2_6753d50a:

    # player "If I needed anything I would go to her."
    player "Si necesitaba algo, acudía a ella."

# game/chapters/5_day.rpyc:1015
translate es day5_start2_3d66f4c1:

    # player "And she would always be there for me."
    player "Y ella siempre estaría allí para mí."

# game/chapters/5_day.rpyc:1018
translate es day5_start2_29a3d187:

    # player "No matter what I needed, always."
    player "No importaba lo que necesitara, siempre."

# game/chapters/5_day.rpyc:1021
translate es day5_start2_1206b94f:

    # player "They're not in the picture."
    player "No aparecen en la foto."

# game/chapters/5_day.rpyc:1025
translate es day5_start2_615b1d17:

    # player "I was with her all throughout my childhood."
    player "Estuve con ella durante toda mi infancia."

# game/chapters/5_day.rpyc:1029
translate es day5_start2_a4c90c9c:

    # player "I had the biggest cheerleader in the world behind my back :)"
    player "Tenía a mi fan número uno en el mundo apoyándome :)"

# game/chapters/5_day.rpyc:1035
translate es day5_start2_de2c9893:

    # player "Yep! He's amazing!"
    player "¡Síp! ¡Él es increíble! "

# game/chapters/5_day.rpyc:1038
translate es day5_start2_a2772e8d:

    # player "He's a few years older than me."
    player "Es unos años mayor que yo."

# game/chapters/5_day.rpyc:1040
translate es day5_start2_01948e90_1:

    # GR "and your parents?"
    GR "¿y tus padres?"

# game/chapters/5_day.rpyc:1043
translate es day5_start2_2742a356:

    # player "I've just always been closer to him, you know?"
    player "Siempre he tenido más confianza con él, ¿sabes?"

# game/chapters/5_day.rpyc:1046
translate es day5_start2_7eb7f3ce:

    # player "If I ever needed anything I would go to him."
    player "Si alguna vez necesitaba algo, acudía a él."

# game/chapters/5_day.rpyc:1049
translate es day5_start2_9a0535d0:

    # player "And he would always be there for me."
    player "Y él siempre estaría allí para mí."

# game/chapters/5_day.rpyc:1052
translate es day5_start2_29a3d187_1:

    # player "No matter what I needed, always."
    player "No importaba lo que necesitara, siempre."

# game/chapters/5_day.rpyc:1055
translate es day5_start2_1206b94f_1:

    # player "They're not in the picture."
    player "No aparecen en la foto."

# game/chapters/5_day.rpyc:1059
translate es day5_start2_b4cade67:

    # player "I was with him all throughout my childhood."
    player "Estuve con él durante toda mi infancia."

# game/chapters/5_day.rpyc:1063
translate es day5_start2_a4c90c9c_1:

    # player "I had the biggest cheerleader in the world behind my back :)"
    player "Tenía a mi fan número uno en el mundo apoyándome :)"

# game/chapters/5_day.rpyc:1068
translate es day5_start2_1c1137fc:

    # player "Yep! They're amazing!"
    player "¡Síp! ¡Elle es increíble!"

# game/chapters/5_day.rpyc:1072
translate es day5_start2_d0e4a281:

    # player "They're a few years older than me."
    player "Es unos años mayor que yo."

# game/chapters/5_day.rpyc:1074
translate es day5_start2_01948e90_2:

    # GR "and your parents?"
    GR "¿y tus padres?"

# game/chapters/5_day.rpyc:1078
translate es day5_start2_5f275624:

    # player "I've just always been closer to my sibling, you know?"
    player "Siempre he tenido más confianza con mi hermane, ¿sabes?"

# game/chapters/5_day.rpyc:1081
translate es day5_start2_22eda462:

    # player "If I ever needed anything I would go to them."
    player "Si alguna vez necesitara algo, acudiría a elle."

# game/chapters/5_day.rpyc:1084
translate es day5_start2_b7e65e70:

    # player "And they would always be there for me."
    player "Y siempre estaría allí para mí."

# game/chapters/5_day.rpyc:1087
translate es day5_start2_29a3d187_2:

    # player "No matter what I needed, always."
    player "No importaba lo que necesitara, siempre."

# game/chapters/5_day.rpyc:1090
translate es day5_start2_1206b94f_2:

    # player "They're not in the picture."
    player "No aparece en la foto."

# game/chapters/5_day.rpyc:1094
translate es day5_start2_0b3ccea6:

    # player "I was with them all throughout my childhood."
    player "Estuve con elle durante toda mi infancia."

# game/chapters/5_day.rpyc:1098
translate es day5_start2_a4c90c9c_2:

    # player "I had the biggest cheerleader in the world behind my back :)"
    player "Tenía a mi fan número uno en el mundo apoyándome :)"

# game/chapters/5_day.rpyc:1104
translate es siblingclose_f1632e12:

    # GR "you are very close."
    GR "tienen una relación muy estrecha."

# game/chapters/5_day.rpyc:1107
translate es siblingclose_c5ba06f3:

    # player "Very much so, yes."
    player "Sí, mucho."

# game/chapters/5_day.rpyc:1110
translate es siblingclose_e460b4c1:

    # player "You don't have any siblings?"
    player "¿No tienes hermanos?"

# game/chapters/5_day.rpyc:1112
translate es siblingclose_2885706d:

    # GR "i do not."
    GR "yo no."

# game/chapters/5_day.rpyc:1113
translate es siblingclose_ed8bfbc8:

    # GR "but i am aware of the 'sibling bond' that mortals have."
    GR "pero soy consciente del 'vínculo fraternal' que tienen los mortales."

# game/chapters/5_day.rpyc:1119
translate es parenttogether_ea105ebe:

    # player "And they raised me together."
    player "Y me criaron."

# game/chapters/5_day.rpyc:1122
translate es parenttogether_03389051:

    # player "Apparently it was love at first sight for them."
    player "Al parecer, fue amor a primera vista."

# game/chapters/5_day.rpyc:1126
translate es parenttogether_4a33cf90:

    # player "The moment their eyes met they were drawn to one another."
    player "En el momento en que sus miradas se cruzaron, sintieron una atracción mutua."

# game/chapters/5_day.rpyc:1130
translate es parenttogether_ad83ed6a:

    # player "They told me it was fate."
    player "Me dijeron que era el destino."

# game/chapters/5_day.rpyc:1132
translate es parenttogether_955e2eba:

    # GR "then they were fortunate to find each other."
    GR "entonces tuvieron la suerte de encontrarse."

# game/chapters/5_day.rpyc:1133
translate es parenttogether_2f034710:

    # GR "some soul mates never find their other half."
    GR "algunas almas gemelas nunca encuentran a su media naranja."

# game/chapters/5_day.rpyc:1134
translate es parenttogether_efb17a17:

    # GR "some wouldn't even know their soul called for another."
    GR "algunas ni siquiera saben que su alma busca a otra."

# game/chapters/5_day.rpyc:1138
translate es parenttogether_f8e87f79:

    # player "...Wait, so soul mates are an actual thing?"
    player "... Espera, ¿entonces las almas gemelas existen de verdad?"

# game/chapters/5_day.rpyc:1141
translate es parenttogether_da5a46dd:

    # player "How do you know if you find them :o ?"
    player "¿Cómo sabes si la encuentras :o ?"

# game/chapters/5_day.rpyc:1143
translate es parenttogether_fc0e43fc:

    # GR "you wouldn't know."
    GR "no lo sabrías."

# game/chapters/5_day.rpyc:1144
translate es parenttogether_fa95c1a0:

    # GR "it's quite rare."
    GR "es bastante raro."

# game/chapters/5_day.rpyc:1148
translate es parenttogether_526b95cc:

    # player "Do I have one?"
    player "¿Tengo una?"

# game/chapters/5_day.rpyc:1149
translate es parenttogether_6015e011:

    # GR "how would i know??? seems like a question to ask yourself."
    GR "¿¿¿cómo voy a saberlo??? parece una pregunta que deberías hacerte a ti."

# game/chapters/5_day.rpyc:1152
translate es parenttogether_49e785be:

    # player "Well, you seem quite interested in my soul."
    player "Bueno, pareces bastante interesado en mi alma."

# game/chapters/5_day.rpyc:1155
translate es parenttogether_82e6c0e1:

    # player "Wait, if someone else is my soul mate..."
    player "Espera, si alguien más es mi alma gemela..."

# game/chapters/5_day.rpyc:1158
translate es parenttogether_2cd0c9f3:

    # player "They might take offense at you being so keen for my soul."
    player "Podría ofenderse de que estés tan interesado en mi alma."

# game/chapters/5_day.rpyc:1160
translate es parenttogether_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/5_day.rpyc:1161
translate es parenttogether_1b833434:

    # GR "well, sorry to them, but your soul belongs to me."
    GR "bueno, lo siento por esa persona, pero tu alma me pertenece."

# game/chapters/5_day.rpyc:1162
translate es parenttogether_fb30ec96:

    # GR "so don't go getting any ideas thinking you can get out of our arrangement."
    GR "así que no se te ocurra pensar que puedes salirte de nuestro acuerdo."

# game/chapters/5_day.rpyc:1166
translate es parenttogether_37cc9c68:

    # player "Wouldn't dream of it."
    player "Ni se me ocurriría."

# game/chapters/5_day.rpyc:1169
translate es parenttogether_f4b8c6cb:

    # player "Damn, you totally just foiled all my plans."
    player "Maldita sea, solo frusas todos mis planes."

# game/chapters/5_day.rpyc:1172
translate es parenttogether_70b6baa3:

    # player "Maybe the two of us are soul mates? :D"
    player "¿Quizás los dos somos almas gemelas? :D"

# game/chapters/5_day.rpyc:1173
translate es parenttogether_fb026ac2:

    # GR "don't be preposterous."
    GR "¿qué tontería es esa?"

# game/chapters/5_day.rpyc:1174
translate es parenttogether_9fbdb70b:

    # GR "mortals cannot be soul mates with that which is immortal."
    GR "los mortales no pueden ser almas gemelas de los inmortales."

# game/chapters/5_day.rpyc:1178
translate es parenttogether_888ecc42:

    # player "Why not?"
    player "¿Por qué no?"

# game/chapters/5_day.rpyc:1180
translate es parenttogether_88742bb4:

    # GR "it would be immoral!"
    GR "¡sería inmoral!"

# game/chapters/5_day.rpyc:1184
translate es parenttogether_70fa1305:

    # player "So there's no actual rule saying we can't be soul mates, then."
    player "Entonces, no existe ninguna regla que diga que no podemos ser almas gemelas."

# game/chapters/5_day.rpyc:1186
translate es parenttogether_a911fe44:

    # GR "that is irrelevant to the matter at hand."
    GR "eso es irrelevante para el asunto en cuestión."

# game/chapters/5_day.rpyc:1187
translate es parenttogether_f4834612:

    # GR "it would be unfair to each of us if that was the case, anyway."
    GR "sería injusto para los dos si ese fuera el caso, de todos modos."

# game/chapters/5_day.rpyc:1188
translate es parenttogether_69d958aa:

    # GR "humans live such short lives."
    GR "los humanos viven vidas tan cortas."

# game/chapters/5_day.rpyc:1192
translate es parenttogether_e3995733:

    # player "I could be a Grim Reaper in disguise."
    player "Podría ser una Parca disfrazada."

# game/chapters/5_day.rpyc:1194
translate es parenttogether_df0a1358:

    # GR "are you?"
    GR "¿lo eres?"

# game/chapters/5_day.rpyc:1198
translate es parenttogether_e204b019:

    # player "Probably not."
    player "Probablemente no."

# game/chapters/5_day.rpyc:1200
translate es parenttogether_fe6ad5c3:

    # GR "then... then you should get any thought of romance with me out of your mind."
    GR "entonces... entonces deberías sacarte de la cabeza cualquier idea de romance conmigo."

# game/chapters/5_day.rpyc:1204
translate es parenttogether_36b0f7a9:

    # player "You were the one flirting before."
    player "Tú fuiste quien coqueteó antes."

# game/chapters/5_day.rpyc:1206
translate es parenttogether_64fca011:

    # GR "that... that was not flirting!"
    GR "¡eso... eso no era coquetear!"

# game/chapters/5_day.rpyc:1207
translate es parenttogether_fd4db069:

    # GR "it was another scheme! a trick to take your soul, and nothing more!"
    GR "¡era otro plan! ¡un truco para robarte el alma, y nada más!"

# game/chapters/5_day.rpyc:1211
translate es parenttogether_b5774dd8:

    # player "Sure it was."
    player "Seguro que lo era."

# game/chapters/5_day.rpyc:1215
translate es parenttogether_93aa238f:

    # player "I think you might just have a thing for me :D"
    player "Cree que tal vez sientes algo por mí :D"

# game/chapters/5_day.rpyc:1216
translate es parenttogether_0a5ea016:

    # GR "you are delusional."
    GR "estás delirando."

# game/chapters/5_day.rpyc:1219
translate es parenttogether_054cc952:

    # player "I love you too."
    player "Yo también te amo."

# game/chapters/5_day.rpyc:1220
translate es parenttogether_17010e42:

    # GR "!!!!"
    GR "!!!!"

# game/chapters/5_day.rpyc:1221
translate es parenttogether_8fb46320:

    # GR "family! we were talking about family!"
    GR "¡familia! ¡estábamos hablando de familia!"

# game/chapters/5_day.rpyc:1222
translate es parenttogether_4b223d69:

    # GR "that is enough of this... this.. whatever this is!"
    GR "¡ya basta de esto... esto... sea lo que sea!"

# game/chapters/5_day.rpyc:1223
translate es parenttogether_2c7b86f9:

    # GR "right, other family members. yes."
    GR "correcto, otros miembros de la familia. sí."

# game/chapters/5_day.rpyc:1227
translate es parenttogether_761ab8e9:

    # player "Apparently they were like academic rivals or something."
    player "Al parecer, eran como rivales en lo académico o algo así."

# game/chapters/5_day.rpyc:1230
translate es parenttogether_e361a8f4:

    # player "A couple of incredibly smart yet stupid geniuses."
    player "Una pareja de cerebros increíblemente inteligentes, pero a la vez estúpidos."

# game/chapters/5_day.rpyc:1232
translate es parenttogether_82a57096:

    # GR "sounds like something from one of your human stories."
    GR "suena como algo sacado de una de tus historias humanas."

# game/chapters/5_day.rpyc:1235
translate es parenttogether_0f5f02ca:

    # player "!!!"
    player "!!!"

# game/chapters/5_day.rpyc:1238
translate es parenttogether_a1a3edac:

    # player "Oh, Grimmy."
    player "Oh, Parquita."

# game/chapters/5_day.rpyc:1241
translate es parenttogether_6d5a2ed0:

    # player "What exactly have you been reading?"
    player "¿Qué has estado leyendo exactamente?"

# game/chapters/5_day.rpyc:1244
translate es parenttogether_bf069bb1:

    # player "Saucy enemies to lovers books?"
    player "¿Libros picantes sobre enemigos que se convierten en amantes?"

# game/chapters/5_day.rpyc:1246
translate es parenttogether_22d6c472:

    # GR "what..."
    GR "qué..."

# game/chapters/5_day.rpyc:1250
translate es parenttogether_cb6ceb89:

    # player "I feel like this is the kinda thing you only know about if you read them."
    player "Siento que esto es algo que solo se sabe si se lee."

# game/chapters/5_day.rpyc:1252
translate es parenttogether_53f97957:

    # GR "well, i do not."
    GR "Bueno, no lo hago."

# game/chapters/5_day.rpyc:1253
translate es parenttogether_285fd4e8:

    # GR "you on the other hand, obviously do."
    GR "Tú, por otro lado, obviamente sí."

# game/chapters/5_day.rpyc:1257
translate es parenttogether_2a99116e:

    # player "Of course I do!"
    player "¡Por supuesto que sí!"

# game/chapters/5_day.rpyc:1260
translate es parenttogether_5b457ca0:

    # player "Can you blame me?"
    player "¿Puedes culparme?"

# game/chapters/5_day.rpyc:1263
translate es parenttogether_a2226f55:

    # player "It's harmless fun, really."
    player "Es una diversión inofensiva, de verdad."

# game/chapters/5_day.rpyc:1265
translate es parenttogether_6908470f:

    # GR "yeah, sure it is."
    GR "sí, seguro que lo es."

# game/chapters/5_day.rpyc:1269
translate es parenttogether_f12607a0:

    # player "I could read you one, if you wanted."
    player "Podría leerte uno, si quisieras."

# game/chapters/5_day.rpyc:1273
translate es parenttogether_d52714c8:

    # player "I've been told that I have a good voice for audiobooks."
    player "Me han dicho que tengo una buena voz para los audiolibros."

# game/chapters/5_day.rpyc:1275
translate es parenttogether_7248cdc1:

    # GR "you want to read smut to me?"
    GR "¿Quieres leerme literatura erótica?"

# game/chapters/5_day.rpyc:1279
translate es parenttogether_f10fed52:

    # player "I'll pick out an extra saucy scene and we can see if you blush."
    player "Elegiré una escena extra picante y podemos ver si te sonrojas."

# game/chapters/5_day.rpyc:1281
translate es parenttogether_aee17ccf:

    # GR "i... am not some mortal who is flustered by something as simple as words."
    GR "yo... no soy un simple mortal que se altera por algo tan simple como unas palabras."

# game/chapters/5_day.rpyc:1282
translate es parenttogether_ffbf64d5:

    # GR "if anyone will become flustered, it would be you!"
    GR "si alguien se va a alterar, ¡serás tú!"

# game/chapters/5_day.rpyc:1283
translate es parenttogether_a138de6b:

    # GR "so... maybe you should read it to me."
    GR "entonces... tal vez deberías leerme."

# game/chapters/5_day.rpyc:1284
translate es parenttogether_e8c0be31:

    # GR "i'm suddenly very interested."
    GR "de repente estoy muy interesado."

# game/chapters/5_day.rpyc:1288
translate es parenttogether_0f5f02ca_1:

    # player "!!!"
    player "!!!"

# game/chapters/5_day.rpyc:1290
translate es parenttogether_ef97d50b:

    # player "Woah, the sudden confidence is making me nervous."
    player "Woah, tanta confianza repentina está poniendo mis nervios de punta."

# game/chapters/5_day.rpyc:1293
translate es parenttogether_e1336eeb:

    # player "Maybe it's a bad idea after all..."
    player "Tal vez sea una mala idea después de todo..."

# game/chapters/5_day.rpyc:1295
translate es parenttogether_4166e408:

    # GR "seeing you shy... hm. it gives me an interesting feeling."
    GR "tu timidez... hm. me produce una sensación interesante."

# game/chapters/5_day.rpyc:1296
translate es parenttogether_dd0a7a77:

    # GR "perhaps i will invest in one of these books myself."
    GR "quizás invertiré en uno de estos libros yo mismo."

# game/chapters/5_day.rpyc:1300
translate es parenttogether_8569685e:

    # player "Wow, what a flirt."
    player "Wow, qué coqueteo."

# game/chapters/5_day.rpyc:1302
translate es parenttogether_f53bf627:

    # player "I can't wait to see which one you pick."
    player "No puedo esperar para ver cuál eliges."

# game/chapters/5_day.rpyc:1304
translate es parenttogether_2c81364b:

    # GR "i will do some research."
    GR "investigaré un poco."

# game/chapters/5_day.rpyc:1308
translate es parenttogether_05d9201e:

    # player "You really don't have to do that."
    player "Realmente no tienes que hacer eso."

# game/chapters/5_day.rpyc:1310
translate es parenttogether_9b4d6b24:

    # player "I can give you some recommendations."
    player "Puedo darte algunas recomendaciones."

# game/chapters/5_day.rpyc:1312
translate es parenttogether_44c29754:

    # player "Grim... I think I might die if you do that."
    player "Parca... Creo que podría morir si haces eso."

# game/chapters/5_day.rpyc:1314
translate es parenttogether_083bf135:

    # player "How about we stick to me doing the reading???"
    player "¿¿¿Qué tal si nos limitamos a que yo haga la lectura???"

# game/chapters/5_day.rpyc:1316
translate es parenttogether_73ec8cc5:

    # GR "i feel like i've just learned a lot about you."
    GR "siento que acabo de aprender mucho sobre ti."

# game/chapters/5_day.rpyc:1320
translate es parenttogether_25bdd074:

    # player "How about we go back to talking about family, huh?!"
    player "¿Qué tal si volvemos a hablar de familia, eh?"

# game/chapters/5_day.rpyc:1322
translate es parenttogether_ad6c7f8d:

    # GR "fine."
    GR "bien."

# game/chapters/5_day.rpyc:1325
translate es parenttogether_f5e09f6f:

    # player "I do not!"
    player "¡No lo hago!"

# game/chapters/5_day.rpyc:1326
translate es parenttogether_53db31e8:

    # GR "you just said its the kinda thing you only know about if you've read them."
    GR "acabas de decir que es el tipo de cosas que solo se saben si se han leído."

# game/chapters/5_day.rpyc:1330
translate es parenttogether_76536dd8:

    # player "Did I say that? Maybe you're confused."
    player "¿Dije eso? Quizás estés confundido."

# game/chapters/5_day.rpyc:1332
translate es parenttogether_ebc9eb7a:

    # GR "yes."
    GR "sí."

# game/chapters/5_day.rpyc:1333
translate es parenttogether_09c0573b:

    # GR "maybe i should pick up one of these 'saucy books'."
    GR "quizás debería comprar uno de esos 'libros picantes'."

# game/chapters/5_day.rpyc:1334
translate es parenttogether_52043594:

    # GR "for {i}research{/i}."
    GR "para la {i}investigación{/i}."

# game/chapters/5_day.rpyc:1335
translate es parenttogether_be02d7aa:

    # GR "knowing more about your interests may help me in reaping your soul, after all."
    GR "conocer mejor tus intereses puede ayudarme a cosechar tu alma, después de todo."

# game/chapters/5_day.rpyc:1338
translate es parenttogether_fef1ed91:

    # player "COUGH COUGH..."
    player "TOS TOS..."

# game/chapters/5_day.rpyc:1339
translate es parenttogether_68abd95a:

    # GR "... did you seriously just type cough?"
    GR "...¿en serio solo escribiste tos?"

# game/chapters/5_day.rpyc:1340
translate es parenttogether_fcb3f563:

    # GR "is something the matter, sunshine?"
    GR "¿hay algún problema, solecito?"

# game/chapters/5_day.rpyc:1344
translate es parenttogether_2f6401aa:

    # player "Absolutely nothing. Nope."
    player "Absolutamente ninguno. Nop."

# game/chapters/5_day.rpyc:1346
translate es parenttogether_e3bbe86c:

    # player "I really don't think you should read those-"
    player "Realmente no creo que debas leer esos-"

# game/chapters/5_day.rpyc:1348
translate es parenttogether_fb20bff6:

    # GR "i've added one to my cart."
    GR "he agregado uno a mi carrito."

# game/chapters/5_day.rpyc:1349
translate es parenttogether_800c974a:

    # GR "it should be here in a few days."
    GR "debería estar aquí en unos días."

# game/chapters/5_day.rpyc:1350
translate es parenttogether_3bac55e4:

    # GR "perhaps i will learn more of these 'saucy books'."
    GR "quizás aprenda más sobre estos 'libros picantes'."

# game/chapters/5_day.rpyc:1354
translate es parenttogether_a9a9febb:

    # player "That's VERY unnecessary..."
    player "Eso es MUY innecesario..."

# game/chapters/5_day.rpyc:1357
translate es parenttogether_933d1c8d:

    # player "Right, family! Lets just talk about family again!"
    player "¡Bien, familia! ¡Vamos a hablar de familia de nuevo!"

# game/chapters/5_day.rpyc:1362
translate es siblings_b8f3c0f9:

    # GR "do you have any siblings?"
    GR "¿Tienes hermanos?"

# game/chapters/5_day.rpyc:1365
translate es siblings_c5cef36d:

    # player "Nope, just me!"
    player "¡Nop, solo yo!"

# game/chapters/5_day.rpyc:1368
translate es siblings_0f28f411:

    # player "I would have liked some."
    player "Me hubiera gustado algunos."

# game/chapters/5_day.rpyc:1371
translate es siblings_43d80612:

    # player "Most of my friends had a lot of siblings."
    player "La mayoría de mis amigos tenían muchos hermanos."

# game/chapters/5_day.rpyc:1374
translate es siblings_9b160fdb:

    # player "But I had plenty of friends."
    player "Pero tenía muchos amigos."

# game/chapters/5_day.rpyc:1377
translate es siblings_f6887dd5:

    # player "So it wasn't really too bad."
    player "Así que no fue realmente tan malo."

# game/chapters/5_day.rpyc:1380
translate es siblings_d0b92312:

    # player "And I didn't have many friends."
    player "Y no tenía muchos amigos."

# game/chapters/5_day.rpyc:1383
translate es siblings_827f0bc2:

    # player "So it did feel kind of lonely at times."
    player "Así que a veces sentía cierta soledad."

# game/chapters/5_day.rpyc:1386
translate es siblings_c5800242:

    # player "I've never been bothered by it."
    player "Nunca me ha molestado eso."

# game/chapters/5_day.rpyc:1389
translate es siblings_8145e1ce:

    # player "I never had to deal with siblings taking my stuff, so that's nice."
    player "Nunca tuve que lidiar con hermanos que tomen mis cosas, así que eso es bueno."

# game/chapters/5_day.rpyc:1392
translate es siblings_4e176502:

    # player "I've always felt pretty independent."
    player "Siempre me he sentido bastante independiente."

# game/chapters/5_day.rpyc:1395
translate es siblings_60671ae6:

    # player "I do, yeah!"
    player "¡Sí, claro!"

# game/chapters/5_day.rpyc:1398
translate es siblings_aade3378:

    # player "I've got a brother."
    player "Tengo un hermano."

# game/chapters/5_day.rpyc:1401
translate es siblings_528013d6:

    # player "He's annoying, but I love him."
    player "Es molesto, pero lo amo."

# game/chapters/5_day.rpyc:1403
translate es siblings_f0169b70:

    # player "He's the best."
    player "Él es el mejor."

# game/chapters/5_day.rpyc:1406
translate es siblings_7d6f6e10:

    # player "I've got brothers."
    player "Tengo hermanos."

# game/chapters/5_day.rpyc:1409
translate es siblings_5992aef2:

    # player "They're total nuisances, but I love them."
    player "Son un fastidio total, pero me encantan."

# game/chapters/5_day.rpyc:1412
translate es siblings_23295753:

    # player "I've got a sister."
    player "Tengo una hermana."

# game/chapters/5_day.rpyc:1415
translate es siblings_e56b511f:

    # player "She's kinda way cooler than I am."
    player "Ella es un poco más genial que yo."

# game/chapters/5_day.rpyc:1417
translate es siblings_dc698b6b:

    # player "She's my role model."
    player "Ella es mi modelo a seguir."

# game/chapters/5_day.rpyc:1420
translate es siblings_30fbf844:

    # player "I have sisters."
    player "Tengo hermanas."

# game/chapters/5_day.rpyc:1423
translate es siblings_5992aef2_1:

    # player "They're total nuisances, but I love them."
    player "Son un fastidio total, pero me encantan."

# game/chapters/5_day.rpyc:1427
translate es siblings_d812beed:

    # player "I have a sibling."
    player "Tengo un hermane."

# game/chapters/5_day.rpyc:1431
translate es siblings_00017c8d:

    # player "They're annoying, but I love them."
    player "Elle es una molestia, pero le amo."

# game/chapters/5_day.rpyc:1433
translate es siblings_35df120f:

    # player "They're the best."
    player "Elle es lo mejor."

# game/chapters/5_day.rpyc:1436
translate es siblings_0200eb2b:

    # player "I have siblings."
    player "Tengo hermanos."

# game/chapters/5_day.rpyc:1439
translate es siblings_5992aef2_2:

    # player "They're total nuisances, but I love them."
    player "Son un fastidio total, pero me encantan."

# game/chapters/5_day.rpyc:1442
translate es siblings_7cd56f86:

    # player "I have a brother and a sister."
    player "Tengo un hermano y una hermana."

# game/chapters/5_day.rpyc:1445
translate es siblings_5992aef2_3:

    # player "They're total nuisances, but I love them."
    player "Son un fastidio total, pero me encantan."

# game/chapters/5_day.rpyc:1448
translate es siblings_99d52403:

    # player "I have {i}lots{/i} of brothers and sisters."
    player "Tengo {i}muchos{/i} hermanos y hermanas."

# game/chapters/5_day.rpyc:1449
translate es siblings_02b55570:

    # GR "i'm sure it was a house of chaos."
    GR "estoy seguro de que era una casa del caos."

# game/chapters/5_day.rpyc:1452
translate es siblings_fe614a7b:

    # player "More than you can even imagine."
    player "Más de lo que puedes imaginar."

# game/chapters/5_day.rpyc:1456
translate es siblings_e091880f:

    # player "Do you have any siblings, Grim?"
    player "¿Tienes algún hermano, Parca?"

# game/chapters/5_day.rpyc:1458
translate es siblings_2885706d:

    # GR "i do not."
    GR "no tengo."

# game/chapters/5_day.rpyc:1459
translate es siblings_a6d21737:

    # GR "and thank the lords for that."
    GR "y doy gracias a los dioses por eso."

# game/chapters/5_day.rpyc:1463
translate es siblings_e39e0546:

    # player "You do give only child vibes, so I'm not surprised."
    player "Solo das vibraciones infantiles, así que no me sorprende."

# game/chapters/5_day.rpyc:1465
translate es siblings_6f2155f3:

    # GR "how so?"
    GR "¿cómo así?"

# game/chapters/5_day.rpyc:1468
translate es siblings_d8756cef:

    # player "It's just the way you act sometimes."
    player "Es solo la forma en que actúas a veces."

# game/chapters/5_day.rpyc:1471
translate es siblings_2cb39ea8:

    # player "Your disgust at the idea of sharing."
    player "Tu disgusto ante la idea de compartir."

# game/chapters/5_day.rpyc:1474
translate es siblings_21d84ae0:

    # player "And sometimes you're kinda demanding."
    player "Y a veces eres un poco exigente."

# game/chapters/5_day.rpyc:1476
translate es siblings_81691151:

    # GR "i take what i want when i want it."
    GR "tomo lo que quiero cuando lo quiero."

# game/chapters/5_day.rpyc:1480
translate es siblings_d2968bd8:

    # player "Yes... exactly."
    player "Sí... exactamente."

# game/chapters/5_day.rpyc:1482
translate es siblings_7877090f:

    # GR "it's my right as a reaper."
    GR "es mi derecho como una parca."

# game/chapters/5_day.rpyc:1486
translate es siblings_c2283b39:

    # player "I bet if you had a sibling, they'd put you in your place."
    player "Apuesto a que si tuvieras un hermano, te pondrían en tu lugar."

# game/chapters/5_day.rpyc:1488
translate es siblings_92d5133d:

    # GR "i know my place."
    GR "conozco mi lugar."

# game/chapters/5_day.rpyc:1492
translate es siblings_1a4a4067:

    # player "Sure you do."
    player "Seguro que lo haces."

# game/chapters/5_day.rpyc:1502
translate es day5afterfamily_528db4c9:

    # player "So that's the family questions out of the way, then?"
    player "¿Entonces ya hemos resuelto las cuestiones familiares?"

# game/chapters/5_day.rpyc:1506
translate es day5afterfamily_29e37c31:

    # player "What's next?"
    player "¿Qué sigue?"

# game/chapters/5_day.rpyc:1508
translate es day5afterfamily_13ec3c60:

    # GR "i require any names of mortals who {i}'tickle your fancy'{/i}."
    GR "Necesito los nombres de los mortales que {i}'te llaman la atención'{/i}."

# game/chapters/5_day.rpyc:1512
translate es day5afterfamily_393a4da7:

    # player "What exactly do you need that for?"
    player "¿Para qué necesitas exactamente eso?"

# game/chapters/5_day.rpyc:1513
translate es day5afterfamily_b7ddc949:

    # GR "i will have them taken care of."
    GR "me encargaré de ellos."

# game/chapters/5_day.rpyc:1516
translate es day5afterfamily_61e1f58d:

    # player "I think my idea of {i}'taken care of'{/i} and yours are probably very different..."
    player "Creo que mi idea de {i}'encargarse de ellos'{/i} y la tuya son probablemente muy diferentes..."

# game/chapters/5_day.rpyc:1517
translate es day5afterfamily_04d29e2d:

    # GR "whatever do you mean?"
    GR "¿qué quieres decir?"

# game/chapters/5_day.rpyc:1520
translate es day5afterfamily_3e870c36:

    # player "What will do you with the information?"
    player "¿Qué harás con la información?"

# game/chapters/5_day.rpyc:1523
translate es day5afterfamily_c0671c56:

    # player "Do you plan to take their souls prematurely?"
    player "¿Planeas llevarte sus almas prematuramente?"

# game/chapters/5_day.rpyc:1524
translate es day5afterfamily_5c2d13f9:

    # GR "their souls? no, that would be against the code."
    GR "¿sus almas? no, eso estaría en contra del código."

# game/chapters/5_day.rpyc:1525
translate es day5afterfamily_05cdb256:

    # GR "i'll just..."
    GR "solo voy a..."

# game/chapters/5_day.rpyc:1526
translate es day5afterfamily_2096513d:

    # GR "make sure they do not get in my way."
    GR "asegurarmede que no se interpongan en mi camino."

# game/chapters/5_day.rpyc:1527
translate es day5afterfamily_24f615f2:

    # GR "in my way of getting your soul, of course. nothing else. nothing whatsoever."
    GR "es mi forma de conseguir tu alma, por supuesto. nada más. absolutamente nada."

# game/chapters/5_day.rpyc:1530
translate es day5afterfamily_03775ec8:

    # player "..."
    player "..."

# game/chapters/5_day.rpyc:1533
translate es day5afterfamily_bdb5f263:

    # player "I think I should keep these names to myself."
    player "Creo que debería mantener estos nombres en secreto."

# game/chapters/5_day.rpyc:1534
translate es day5afterfamily_42b62433:

    # GR "tell me. immediately."
    GR "dímelos. Inmediatamente."

# game/chapters/5_day.rpyc:1537
translate es day5afterfamily_4276bb52:

    # player "I don't think so, mister."
    player "No lo creo, señor."

# game/chapters/5_day.rpyc:1538
translate es day5afterfamily_b71588d1:

    # GR "what if i command you to tell me?"
    GR "¿y si te ordeno que me los digas?"

# game/chapters/5_day.rpyc:1541
translate es day5afterfamily_47814f90:

    # player "I would laugh at you for being edgy."
    player "Me reiría de ti por ser edgy."

# game/chapters/5_day.rpyc:1542
translate es day5afterfamily_d7f6c86d:

    # GR "you should do as you are told."
    GR "debes hacer lo que te dicen."

# game/chapters/5_day.rpyc:1543
translate es day5afterfamily_61fb5a5c:

    # GR "there is no point in making this more difficult than it needs to be."
    GR "no tiene sentido complicar esto más de lo necesario."

# game/chapters/5_day.rpyc:1547
translate es day5afterfamily_1349c855:

    # player "Grimmy..."
    player "Parquita..."

# game/chapters/5_day.rpyc:1549
translate es day5afterfamily_7e4f001c:

    # player "You really are troublesome."
    player "Realmente eres problemático."

# game/chapters/5_day.rpyc:1551
translate es day5afterfamily_336856e0:

    # GR "i'm waiting, mortal."
    GR "estoy esperando, mortal."

# game/chapters/5_day.rpyc:1552
translate es day5afterfamily_4b7c60f3:

    # GR "i don't need random people getting in the way of my work."
    GR "no necesito que gente al azar se interponga en mi trabajo."

# game/chapters/5_day.rpyc:1555
translate es day5afterfamily_7275df94:

    # player "How exactly do you expect them to interfere?"
    player "¿Cómo esperas exactamente que interfieran?"

# game/chapters/5_day.rpyc:1556
translate es day5afterfamily_08443a35:

    # GR "i do not wish to find out."
    GR "no deseo averiguarlo."

# game/chapters/5_day.rpyc:1557
translate es day5afterfamily_a59b4a1f:

    # GR "so just give me the names and do not worry about it."
    GR "así que dame los nombres y no te preocupes por eso."

# game/chapters/5_day.rpyc:1558
translate es day5afterfamily_7415deed:

    # GR "there must be someone, correct?"
    GR "debe haber alguien, ¿correcto?"

# game/chapters/5_day.rpyc:1561
translate es day5afterfamily_0f239d56:

    # player "There might be."
    player "Puede haber."

# game/chapters/5_day.rpyc:1562
translate es day5afterfamily_97fa0687:

    # GR "they won't be an issue for much longer, i'll deal with it."
    GR "no serán un problema por mucho tiempo más, yo me encargaré de ello."

# game/chapters/5_day.rpyc:1563
translate es day5afterfamily_5d586d69:

    # GR "as soon as you tell me who they are."
    GR "en cuanto me digas quiénes son."

# game/chapters/5_day.rpyc:1564
translate es day5afterfamily_782112e7:

    # GR "i'll go deal with it right away."
    GR "me encargaré de ello inmediatamente."

# game/chapters/5_day.rpyc:1567
translate es day5afterfamily_70ed1030:

    # player "Someone is sounding a little jealous right now."
    player "Alguien suena un poco celoso en este momento."

# game/chapters/5_day.rpyc:1568
translate es day5afterfamily_6083e401:

    # GR "jealous??? no. i am serious about my work."
    GR "¿¿¿celoso??? no. me tomo mi trabajo muy en serio."

# game/chapters/5_day.rpyc:1571
translate es day5afterfamily_229492df:

    # player "Even if there was someone special in my life..."
    player "Incluso si hubiera alguien especial en mi vida..."

# game/chapters/5_day.rpyc:1574
translate es day5afterfamily_13aba3a1:

    # player "They wouldn't be able to stop a Grim Reaper."
    player "No podría detener a una Parca."

# game/chapters/5_day.rpyc:1576
translate es day5afterfamily_a6d4f02e:

    # GR "i don't share, sunshine."
    GR "no comparto, solecito."

# game/chapters/5_day.rpyc:1579
translate es day5afterfamily_0a0346a9:

    # player "Share what?"
    player "¿Compartir qué?"

# game/chapters/5_day.rpyc:1580
translate es day5afterfamily_d612b723:

    # GR "you, obviously."
    GR "a ti, obviamente."

# game/chapters/5_day.rpyc:1583
translate es day5afterfamily_2c2503e7:

    # player "Luckily for you I don't have anyone special."
    player "Por suerte para ti, no tengo a nadie especial."

# game/chapters/5_day.rpyc:1586
translate es day5afterfamily_9be0b08c:

    # player "There's no one like that in my life, Grim."
    player "No hay nadie así en mi vida, Parca."

# game/chapters/5_day.rpyc:1587
translate es day5afterfamily_875c705e:

    # GR "well, that makes my job a bit easier."
    GR "bueno, eso me facilita un poco el trabajo."

# game/chapters/5_day.rpyc:1588
translate es day5afterfamily_f80ac3f9:

    # GR "i suppose no maiming will need to occur today."
    GR "supongo que hoy no habrá que mutilar a nadie."

# game/chapters/5_day.rpyc:1592
translate es day5afterfamily_02368100:

    # player "MAIMING???"
    player "¿¿¿MUTILAR???"

# game/chapters/5_day.rpyc:1594
translate es day5afterfamily_041952ca:

    # GR "whoops, did i say that?"
    GR "Uups, ¿dije eso?"

# game/chapters/5_day.rpyc:1598
translate es day5afterfamily_9e89ebb4:

    # player "You wouldn't REALLY do that... would you?"
    player "No harías eso de VERDAD... ¿o sí?"

# game/chapters/5_day.rpyc:1600
translate es day5afterfamily_1f15ab0b:

    # GR "who knows."
    GR "quién sabe."

# game/chapters/5_day.rpyc:1603
translate es day5afterfamily_2920d744:

    # player "Why?"
    player "¿Por qué?"

# game/chapters/5_day.rpyc:1605
translate es day5afterfamily_55b29fe0:

    # GR "i am serious about my work. i do not want anyone getting in the way."
    GR "me tomo mi trabajo muy en serio. no quiero que nadie se interponga en mi camino."

# game/chapters/5_day.rpyc:1609
translate es day5afterfamily_229492df_1:

    # player "Even if there was someone special in my life..."
    player "Incluso si hubiera alguien especial en mi vida..."

# game/chapters/5_day.rpyc:1612
translate es day5afterfamily_13aba3a1_1:

    # player "They wouldn't be able to stop a Grim Reaper."
    player "No podría detener a una Parca."

# game/chapters/5_day.rpyc:1614
translate es day5afterfamily_a6d4f02e_1:

    # GR "i don't share, sunshine."
    GR "No comparto, solecito."

# game/chapters/5_day.rpyc:1618
translate es day5afterfamily_0a0346a9_1:

    # player "Share what?"
    player "¿Compartir qué?"

# game/chapters/5_day.rpyc:1619
translate es day5afterfamily_d612b723_1:

    # GR "you, obviously."
    GR "a ti, obviamente."

# game/chapters/5_day.rpyc:1622
translate es day5afterfamily_79c96d56:

    # player "Luckily there really is no one."
    player "Por suerte, realmente no hay nadie."

# game/chapters/5_day.rpyc:1625
translate es day5afterfamily_7a5fe125:

    # player "There is someone, but he isn't 'mortal'."
    player "Hay alguien, pero no es 'mortal'."

# game/chapters/5_day.rpyc:1626
translate es day5afterfamily_ed4f0675:

    # GR "what?? what do you mean?"
    GR "¿¿qué?? ¿qué quieres decir?"

# game/chapters/5_day.rpyc:1627
translate es day5afterfamily_3cacb93f:

    # GR "you have been in contact with someone else immortal?"
    GR "¿has estado en contacto con algún otro inmortal?"

# game/chapters/5_day.rpyc:1628
translate es day5afterfamily_4af4b715:

    # GR "is it another grim reaper? they will have hell to pay for touching my quarry."
    GR "¿es otra parca? lo pagará caro por tocar mi presa."

# game/chapters/5_day.rpyc:1632
translate es day5afterfamily_666e5da3:

    # player "Yeah, they're a Grim Reaper."
    player "Sí, es una Parca."

# game/chapters/5_day.rpyc:1636
translate es day5afterfamily_24fbc056:

    # player "Sorry for not bringing it up before."
    player "Perdón por no mencionarlo antes."

# game/chapters/5_day.rpyc:1637
translate es day5afterfamily_cc21bd84:

    # GR "!!!"
    GR "!!!"

# game/chapters/5_day.rpyc:1638
translate es day5afterfamily_0c6cf4fb:

    # GR "this is unacceptable!"
    GR "¡Esto es inaceptable!"

# game/chapters/5_day.rpyc:1639
translate es day5afterfamily_24b45cd0:

    # GR "how dare someone else... come in and... and..."
    GR "¿cómo se atreve alguien más... a entrar y... y..."

# game/chapters/5_day.rpyc:1643
translate es day5afterfamily_3891fc3c:

    # player "And what?"
    player "¿Y qué?"

# game/chapters/5_day.rpyc:1645
translate es day5afterfamily_e22c899f:

    # GR "get in the way of my work!"
    GR "¡entrometerse en mi trabajo!!"

# game/chapters/5_day.rpyc:1649
translate es day5afterfamily_999121bf:

    # player "This is sounding less and less work related, Grim."
    player "Esto cada vez parece menos relacionado con el trabajo, Parca."

# game/chapters/5_day.rpyc:1652
translate es day5afterfamily_004b9a34:

    # player "Anyway, I think you'd like him."
    player "De todos modos, creo que te caería bien."

# game/chapters/5_day.rpyc:1656
translate es day5afterfamily_70490819:

    # player "He's funny, handsome, and incredibly stupid. But I like his stupidity."
    player "Es divertido, guapo e increíblemente estúpido. Pero me gusta su estupidez."

# game/chapters/5_day.rpyc:1657
translate es day5afterfamily_dcd0ed54:

    # GR "he sounds absolutely awful."
    GR "suena absolutamente horrible."

# game/chapters/5_day.rpyc:1658
translate es day5afterfamily_5e47ed36:

    # GR "why you would spend time around him, i do not understand."
    GR "por qué pasarías tiempo con él, no entiendo."

# game/chapters/5_day.rpyc:1662
translate es day5afterfamily_3c1af018:

    # player "Well, yeah. He's you."
    player "Bueno, sí. Él eres tú."

# game/chapters/5_day.rpyc:1664
translate es day5afterfamily_230dec51:

    # GR "...."
    GR "...."

# game/chapters/5_day.rpyc:1665
translate es day5afterfamily_a0402d82:

    # GR "m... me?"
    GR "¿y... yo?"

# game/chapters/5_day.rpyc:1666
translate es day5afterfamily_ef969a0c:

    # GR "i... do not count as someone who tickles your fancy...!"
    GR "¡yo... no cuento como alguien que te llame la atención...!"

# game/chapters/5_day.rpyc:1670
translate es day5afterfamily_03d8f1b4:

    # player "Yeah you do."
    player "Sí, lo haces."

# game/chapters/5_day.rpyc:1672
translate es day5afterfamily_1146c3fb:

    # player "I keep telling you I like you :D"
    player "Te sigo diciendo que me gustas :D"

# game/chapters/5_day.rpyc:1674
translate es day5afterfamily_1799b0de:

    # GR "........."
    GR "........."

# game/chapters/5_day.rpyc:1675
translate es day5afterfamily_537ca2cd:

    # GR "but.... why???"
    GR "¿¿¿pero por qué???"

# game/chapters/5_day.rpyc:1676
translate es day5afterfamily_e02a91aa:

    # GR "do you hate living that badly???"
    GR "¿¿¿odias tanto vivir???"

# game/chapters/5_day.rpyc:1680
translate es day5afterfamily_f55e41d3:

    # player "Not really."
    player "No precisamente."

# game/chapters/5_day.rpyc:1684
translate es day5afterfamily_35a91eff:

    # player "You're just fun to be around."
    player "Es divertido estar contigo."

# game/chapters/5_day.rpyc:1686
translate es day5afterfamily_c11348d3:

    # player "I enjoy your company."
    player "Disfruto de tu compañía."

# game/chapters/5_day.rpyc:1690
translate es day5afterfamily_ddc9eb51:

    # GR "but... why? why is there no one else?"
    GR "¿pero por qué? ¿por qué no hay nadie más?"

# game/chapters/5_day.rpyc:1693
translate es day5afterfamily_c2d74f20:

    # player "What do you mean?"
    player "¿Qué quieres decir?"

# game/chapters/5_day.rpyc:1695
translate es day5afterfamily_8fbb9752:

    # GR "why do you not have someone???"
    GR "¿¿¿Por qué no tienes a alguien???"

# game/chapters/5_day.rpyc:1696
translate es day5afterfamily_10b23360:

    # GR "you are so..."
    GR "eres tan..."

# game/chapters/5_day.rpyc:1700
translate es day5afterfamily_8074078d:

    # player "So what?"
    player "¿Tan que?"

# game/chapters/5_day.rpyc:1701
translate es day5afterfamily_82d16bdf:

    # GR "uh... "
    GR "uh... "

# game/chapters/5_day.rpyc:1702
translate es day5afterfamily_75252565:

    # GR "just... how could you not have a special person?"
    GR "Es que... ¿cómo es posible que no tengas a alguien especial?"

# game/chapters/5_day.rpyc:1705
translate es day5afterfamily_3ab5f9bd:

    # player "Are you asking me why I'm single right now?"
    player "¿Me estás preguntando por qué no tengo pareja en este momento?"

# game/chapters/5_day.rpyc:1707
translate es day5afterfamily_90214b56:

    # GR "yes, i do not understand."
    GR "Sí, no entiendo."

# game/chapters/5_day.rpyc:1708
translate es day5afterfamily_cf20d5c5:

    # GR "you're... well..."
    GR "eres... bueno..."

# game/chapters/5_day.rpyc:1709
translate es day5afterfamily_b7703208:

    # GR "nevermind."
    GR "no importa."

# game/chapters/5_day.rpyc:1712
translate es day5afterfamily_342b4931:

    # player "No, what were you going to say?"
    player "No, ¿qué ibas a decir?"

# game/chapters/5_day.rpyc:1715
translate es day5afterfamily_88ca668e:

    # player "I'm what?"
    player "¿Soy que?"

# game/chapters/5_day.rpyc:1717
translate es day5afterfamily_7c9ed2bf:

    # GR "have you seen yourself?"
    GR "¿Te has visto?"

# game/chapters/5_day.rpyc:1721
translate es day5afterfamily_d86dd48f:

    # player "Are you trying to insult me or compliment me?"
    player "¿Estás tratando de insultarme o de halagarme?"

# game/chapters/5_day.rpyc:1723
translate es day5afterfamily_c2d96512:

    # GR "did i tell you how absolutely awful you look?"
    GR "¿te dije lo absolutamente horrible que te ves?"

# game/chapters/5_day.rpyc:1727
translate es day5afterfamily_03775ec8_1:

    # player "..."
    player "..."

# game/chapters/5_day.rpyc:1729
translate es day5afterfamily_c87ddf10:

    # player "Wow."
    player "Wow."

# game/chapters/5_day.rpyc:1731
translate es day5afterfamily_37e286ec:

    # player "No, you didn't."
    player "No, no lo hiciste."

# game/chapters/5_day.rpyc:1732
translate es day5afterfamily_8d286a39:

    # GR "i did not."
    GR "no lo hice."

# game/chapters/5_day.rpyc:1733
translate es day5afterfamily_c3dc2813:

    # GR "that would be because i cannot lie."
    GR "eso sería porque no puedo mentir."

# game/chapters/5_day.rpyc:1734
translate es day5afterfamily_3fb1cebb:

    # GR "so."
    GR "así que."

# game/chapters/5_day.rpyc:1735
translate es day5afterfamily_523cf77f:

    # GR "surely people have asked to court you?"
    GR "¿seguro que nadie te ha pedido salir?"

# game/chapters/5_day.rpyc:1739
translate es day5afterfamily_0161a672:

    # player "Not at all."
    player "Para nada."

# game/chapters/5_day.rpyc:1742
translate es day5afterfamily_0c85ef9b:

    # player "I've never actually dated anyone."
    player "En realidad nunca he salido con nadie."

# game/chapters/5_day.rpyc:1743
translate es day5afterfamily_cb8e7c39:

    # GR "i find that hard to believe."
    GR "me resulta difícil de creer."

# game/chapters/5_day.rpyc:1746
translate es day5afterfamily_75fab10a:

    # player "I'm not lying to you."
    player "No te estoy mintiendo."

# game/chapters/5_day.rpyc:1749
translate es day5afterfamily_08377893:

    # player "No one's ever asked me out."
    player "Nadie me ha invitado a salir."

# game/chapters/5_day.rpyc:1750
translate es day5afterfamily_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/5_day.rpyc:1751
translate es day5afterfamily_70a6b42c:

    # GR "not one person has ever asked to court you?"
    GR "¿nunca nadie te ha hecho una proposición?"

# game/chapters/5_day.rpyc:1754
translate es day5afterfamily_7ef68524:

    # player "Nope, that's what I'm saying."
    player "Nop, eso es lo que estoy diciendo."

# game/chapters/5_day.rpyc:1757
translate es day5afterfamily_aa056da6:

    # player "No flowers or fancy dates."
    player "Sin flores ni citas elegantes."

# game/chapters/5_day.rpyc:1760
translate es day5afterfamily_02b172f3:

    # player "No chocolates or anything on Valentine's Day."
    player "Nada de chocolates ni nada por el estilo en San Valentín."

# game/chapters/5_day.rpyc:1762
translate es day5afterfamily_fdc59174:

    # GR "and you are interested in that sort of thing?"
    GR "¿y te interesa ese tipo de cosas?"

# game/chapters/5_day.rpyc:1763
translate es day5afterfamily_149bfb59:

    # GR "food? flowers?"
    GR "¿comida? ¿flores?"

# game/chapters/5_day.rpyc:1766
translate es day5afterfamily_14924fe2:

    # player "I think so? I don't need anything fancy, though."
    player "¿Eso creo? Aunque no necesito nada sofisticado."

# game/chapters/5_day.rpyc:1769
translate es day5afterfamily_a13045bb:

    # player "It would be nice to get some flowers or something."
    player "Sería bonito recibir unas flores o algo así"

# game/chapters/5_day.rpyc:1772
translate es day5afterfamily_eb53cf6f:

    # player "Well, yes."
    player "Bueno, sí."

# game/chapters/5_day.rpyc:1775
translate es day5afterfamily_7ced18a1:

    # player "I have dated before."
    player "He tenido citas antes."

# game/chapters/5_day.rpyc:1778
translate es day5afterfamily_62019b26:

    # player "But it's never been anything serious."
    player "Pero nunca ha sido nada serio."

# game/chapters/5_day.rpyc:1779
translate es day5afterfamily_483d0292:

    # GR "their name?"
    GR "¿su nombre?"

# game/chapters/5_day.rpyc:1782
translate es day5afterfamily_2516c7ca:

    # player "Seriously?"
    player "¿En serio?"

# game/chapters/5_day.rpyc:1783
translate es day5afterfamily_d7ed507e:

    # GR "very."
    GR "mucho."

# game/chapters/5_day.rpyc:1786
translate es day5afterfamily_97a115b0:

    # player "We don't even talk anymore."
    player "Ya ni siquiera hablamos."

# game/chapters/5_day.rpyc:1789
translate es day5afterfamily_b52a1d50:

    # player "You don't need to worry about them getting in the way of your reaping."
    player "No tienes que preocuparte de que te estorben a la hora de cosechar mi alma."

# game/chapters/5_day.rpyc:1791
translate es day5afterfamily_c33e3811:

    # GR "that is not the reason."
    GR "esa no es la razón."

# game/chapters/5_day.rpyc:1792
translate es day5afterfamily_b6beeba7:

    # GR "it just annoys me."
    GR "simplemente me molesta."

# game/chapters/5_day.rpyc:1795
translate es day5afterfamily_6b44bffb:

    # player "That I've dated before?"
    player "¿Que haya salido con alguien antes?"

# game/chapters/5_day.rpyc:1798
translate es day5afterfamily_c04f6e4a:

    # player "I was like 15, it hardly counts."
    player "Tenía 15 años, apenas cuenta."

# game/chapters/5_day.rpyc:1801
translate es day5afterfamily_e51e1bbb:

    # player "We didn't even hold hands."
    player "Ni siquiera nos tomamos de las manos."

# game/chapters/5_day.rpyc:1803
translate es day5afterfamily_f675d4c9:

    # GR "what a waste."
    GR "qué desperdicio."

# game/chapters/5_day.rpyc:1804
translate es day5afterfamily_7ef6fbb5:

    # GR "such a fool."
    GR "qué idiota."

# game/chapters/5_day.rpyc:1808
translate es day5afterfamily_05cf1b99:

    # player "???"
    player "???"

# game/chapters/5_day.rpyc:1809
translate es day5afterfamily_b8313434:

    # GR "did they take you out to eat in fancy places? Buy you flowers?"
    GR "¿te llevaban a comer a restaurantes elegantes? ¿Te compraban flores?"

# game/chapters/5_day.rpyc:1812
translate es day5afterfamily_95ff21d4:

    # player "No, we were practically kids."
    player "No, éramos prácticamente niños."

# game/chapters/5_day.rpyc:1813
translate es day5afterfamily_9f0d42cd:

    # GR "what a disappointment. i would never be that disappointing."
    GR "qué decepción. yo nunca sería tan decepcionante."

# game/chapters/5_day.rpyc:1814
translate es day5afterfamily_f5d15a41:

    # GR "would you like that, though?"
    GR "¿te gustaría eso?"

# game/chapters/5_day.rpyc:1817
translate es day5afterfamily_7c176f8d:

    # player "Fancy dates and flowers?"
    player "¿Citas elegantes y flores?"

# game/chapters/5_day.rpyc:1818
translate es day5afterfamily_1279bd14:

    # GR "what else would i be speaking about?"
    GR "¿de qué más estaría hablando?"

# game/chapters/5_day.rpyc:1821
translate es day5afterfamily_42237af5:

    # player "I don't need over the top fancy, flowers would be nice though."
    player "No necesito nada muy sofisticado, aunque unas flores estarían bien."

# game/chapters/5_day.rpyc:1824
translate es day5afterfamily_191927d6:

    # player "Is that cliché?"
    player "¿Ese cliché?"

# game/chapters/5_day.rpyc:1826
translate es day5afterfamily_b4a71773:

    # GR "is it not a basic part of courting?"
    GR "¿no es una parte fundamental del cortejo?"

# game/chapters/5_day.rpyc:1827
translate es day5afterfamily_13beff0f:

    # GR "to give flowers?"
    GR "¿regalar flores?"

# game/chapters/5_day.rpyc:1828
translate es day5afterfamily_473f5c29:

    # GR "this mortal was truly an idiot."
    GR "ese mortal era realmente un idiota."

# game/chapters/5_day.rpyc:1831
translate es day5afterfamily_6a1db045:

    # player "But I turned them down."
    player "Pero los rechacé."

# game/chapters/5_day.rpyc:1834
translate es day5afterfamily_6089d621:

    # player "So I haven't actually ever dated... if that's what you mean?"
    player "Así que, en realidad, nunca he salido con nadie... ¿es eso lo que quieres decir?"

# game/chapters/5_day.rpyc:1835
translate es day5afterfamily_293c3a9a:

    # GR "you turned them down?"
    GR "¿los rechazaste?"

# game/chapters/5_day.rpyc:1836
translate es day5afterfamily_9fd9a76d:

    # GR "why?"
    GR "¿por qué?"

# game/chapters/5_day.rpyc:1839
translate es day5afterfamily_8e962cf3:

    # player "They didn't feel right for me."
    player "No me parecían adecuados para mí."

# game/chapters/5_day.rpyc:1842
translate es day5afterfamily_e1102a9a:

    # player "I didn't feel the same way they did, so it wouldn't have been fair to them."
    player "No sentía lo mismo, así que no habría sido justo."

# game/chapters/5_day.rpyc:1845
translate es day5afterfamily_d0ee0903:

    # player "I just didn't want to be with them."
    player "Simplemente no quería estar con esos."

# game/chapters/5_day.rpyc:1848
translate es day5afterfamily_b09169a9:

    # player "And it was really as simple as that."
    player "Y fue tan sencillo como eso."

# game/chapters/5_day.rpyc:1850
translate es day5afterfamily_6a2c3e2c:

    # GR "so nobody has ever taken you to eat somewhere fancy or bought you nice flowers?"
    GR "¿así que nadie te ha llevado nunca a comer a un lugar elegante ni comprado flores?"

# game/chapters/5_day.rpyc:1853
translate es day5afterfamily_61656bfa:

    # player "That usually requires accepting going on a date, so no."
    player "Eso normalmente implica aceptar ir a una cita, así que no."

# game/chapters/5_day.rpyc:1856
translate es day5afterfamily_9af13fa8:

    # player "No flowers or fancy meals for me, I'm afraid."
    player "No hay flores ni comidas elegantes para mí, me temo."

# game/chapters/5_day.rpyc:1857
translate es day5afterfamily_80fafe24:

    # GR "and do you like that stuff?"
    GR "¿a ti te gustan esas cosas?"

# game/chapters/5_day.rpyc:1858
translate es day5afterfamily_fadf1d50:

    # GR "...fancy meals or flowers?"
    GR "...¿comidas elegantes o flores?"

# game/chapters/5_day.rpyc:1861
translate es day5afterfamily_8a4d97a2:

    # player "Mmm."
    player "Mmm."

# game/chapters/5_day.rpyc:1864
translate es day5afterfamily_3ba9f135:

    # player "I don't need fancy, but some cute flowers would be nice."
    player "No necesito nada sofisticado, pero unas flores estarían bien."

# game/chapters/5_day.rpyc:1868
translate es day5afterfamily_80906906:

    # player "And what about you then, Grim?"
    player "¿Y tú qué, Parca?"

# game/chapters/5_day.rpyc:1872
translate es day5afterfamily_0a92fcab:

    # player "You said yesterday you've never been in love."
    player "Dijiste ayer que nunca has estado enamorado."

# game/chapters/5_day.rpyc:1876
translate es day5afterfamily_07f4ed90:

    # player "But that doesn't mean you've never dated, or had a crush on someone."
    player "Pero eso no significa que nunca hayas tenido una cita o te hayas flechado."

# game/chapters/5_day.rpyc:1879
translate es day5afterfamily_d45c1128:

    # player "Any underworldings take your fancy?"
    player "¿Algún habitante del inframundo te llama la atención?"

# game/chapters/5_day.rpyc:1881
translate es day5afterfamily_f48f5c08:

    # GR "underworldings...."
    GR "habitante del inframundo...."

# game/chapters/5_day.rpyc:1882
translate es day5afterfamily_5d364529:

    # GR "no."
    GR "no."

# game/chapters/5_day.rpyc:1886
translate es day5afterfamily_382889fe:

    # player "Then... any mortals?"
    player "Entonces... ¿Algún mortal?"

# game/chapters/5_day.rpyc:1887
translate es day5afterfamily_7772a27d_1:

    # GR "..."
    GR "..."

# game/chapters/5_day.rpyc:1890
translate es day5afterfamily_417f3cc6:

    # player "Well?"
    player "¿Y bien?"

# game/chapters/5_day.rpyc:1891
translate es day5afterfamily_c59b953a:

    # GR "and on to the final question... right or left side of the bed?"
    GR "y pasemos a la última pregunta... ¿el lado derecho o el izquierdo de la cama?"

# game/chapters/5_day.rpyc:1894
translate es day5afterfamily_e4b7733b:

    # player "Nuh uh, you haven't answered yet."
    player "Nuh uh, aún no has respondido."

# game/chapters/5_day.rpyc:1896
translate es day5afterfamily_a4222bb6:

    # player "If I have to answer, so do you."
    player "Si tengo que responder, tú también."

# game/chapters/5_day.rpyc:1897
translate es day5afterfamily_de707f8b:

    # GR "i choose to pass."
    GR "elijo pasar."

# game/chapters/5_day.rpyc:1898
translate es day5afterfamily_a9a3981a:

    # GR "left or right side?"
    GR "lado izquierdo o derecho?"

# game/chapters/5_day.rpyc:1901
translate es day5afterfamily_0d830e18:

    # player "The left."
    player "Izquierdo."

# game/chapters/5_day.rpyc:1902
translate es day5afterfamily_cd6959d9:

    # GR "noted."
    GR "anotado."

# game/chapters/5_day.rpyc:1904
translate es day5afterfamily_13bc2558:

    # player "The right."
    player "Derecho."

# game/chapters/5_day.rpyc:1905
translate es day5afterfamily_cd6959d9_1:

    # GR "noted."
    GR "anotado."

# game/chapters/5_day.rpyc:1907
translate es day5afterfamily_24d1dc84:

    # player "I'm taking the whole bed."
    player "Me quedo con toda la cama."

# game/chapters/5_day.rpyc:1908
translate es day5afterfamily_5edc2e79:

    # GR "don't be so greedy, mortal."
    GR "no seas tan codicioso, mortal."

# game/chapters/5_day.rpyc:1911
translate es day5afterfamily_eb068f2c:

    # player "It's alright, you can lay under me."
    player "Está bien, puedes recostarte debajo de mí."

# game/chapters/5_day.rpyc:1914
translate es day5afterfamily_a21de21c:

    # player "Or on top of me, if you prefer?"
    player "¿O encima de mí, si lo prefieres?"

# game/chapters/5_day.rpyc:1916
translate es day5afterfamily_045a8ad2:

    # GR "wh... what?!"
    GR "¡¿qu... qué?!"

# game/chapters/5_day.rpyc:1919
translate es day5afterfamily_c75e2e72:

    # player "Sorry, I'm a bed hog."
    player "Lo siento, acaparo la cama."

# game/chapters/5_day.rpyc:1922
translate es day5afterfamily_86897550:

    # player "We can both lie in the middle and snuggle ;)"
    player "Podemos acostarnos en el medio y abrazarnos ;)"

# game/chapters/5_day.rpyc:1923
translate es day5afterfamily_c2d9e3cc:

    # GR "i don't... 'snuggle'."
    GR "yo no... 'doy abrazos'."

# game/chapters/5_day.rpyc:1926
translate es day5afterfamily_b6d8f7b6:

    # player "I feel like you do."
    player "Siento que lo haces."

# game/chapters/5_day.rpyc:1929
translate es day5afterfamily_73c3a46b:

    # player "But I suppose to actually sleep..."
    player "Pero supongo que para dormir realmente..."

# game/chapters/5_day.rpyc:1932
translate es day5afterfamily_ebb91abc:

    # player "I'll take the left."
    player "Tomaré la izquierda."

# game/chapters/5_day.rpyc:1934
translate es day5afterfamily_37656841:

    # player "I'll take the right."
    player "Tomaré la derecha."

# game/chapters/5_day.rpyc:1935
translate es day5afterfamily_aac132d2:

    # GR "noted..."
    GR "anotado..."

# game/chapters/5_day.rpyc:1936
translate es day5afterfamily_2a05635c:

    # GR "sunshine, you really... ugh..."
    GR "solecito, tu realmente... ugh..."

# game/chapters/5_day.rpyc:1937
translate es day5afterfamily_194ff93c:

    # GR "anyway."
    GR "de todos modos."

# game/chapters/5_day.rpyc:1939
translate es day5afterfamily_81b0e9e5:

    # GR "those were all the questions i had prepared."
    GR "esas fueron todas las preguntas que había preparado."

# game/chapters/5_day.rpyc:1942
translate es day5afterfamily_926982fa:

    # player "So, you gonna ask me again why it took me so long to respond?"
    player "Entonces, ¿vas a volver a preguntarme por qué tardé tanto en responder?"

# game/chapters/5_day.rpyc:1945
translate es day5afterfamily_51c72494:

    # player "Or whether I thought your approach to this little game was wrong?"
    player "¿O si consideré que tu enfoque de este pequeño juego era incorrecto?"

# game/chapters/5_day.rpyc:1946
translate es day5afterfamily_9269d5e8:

    # GR "fine... answer them this time, then."
    GR "está bien... esta vez las responderé."

# game/chapters/5_day.rpyc:1947
translate es day5afterfamily_7f4d8289:

    # GR "...was my approach wrong?"
    GR "... ¿mi enfoque fue incorrecto?"

# game/chapters/5_day.rpyc:1950
translate es day5afterfamily_3e9ba8a5:

    # player "The way you asked was a little strange."
    player "La forma en que lo preguntaste fue un poco extraña."

# game/chapters/5_day.rpyc:1952
translate es day5afterfamily_daf508ea:

    # player "It was cute in a weird way."
    player "Fue linda, pero de una manera rara."

# game/chapters/5_day.rpyc:1955
translate es day5afterfamily_7c262afe:

    # player "The approach was fine, you just phrase things kind of strangely."
    player "El enfoque estaba bien, solo que expresas las cosas de una manera un poco extraña."

# game/chapters/5_day.rpyc:1958
translate es day5afterfamily_2b6b189b:

    # player "Like you're interested, but don't want to seem too interested."
    player "Como si te interesara, pero no quisieras parecer demasiado interesado."

# game/chapters/5_day.rpyc:1961
translate es day5afterfamily_3540eba7:

    # player "It is actually kind of cute."
    player "En realidad, fue bastante lindo."

# game/chapters/5_day.rpyc:1963
translate es day5afterfamily_26d08fa3:

    # player "It's hilarious, if you ask me."
    player "Es gracioso, si me lo preguntas."

# game/chapters/5_day.rpyc:1965
translate es day5afterfamily_a91cbc8f:

    # player "You are so obvious sometimes, it's sweet."
    player "A veces eres tan obvio, es dulce."

# game/chapters/5_day.rpyc:1966
translate es day5afterfamily_75b7b9f5:

    # GR "obvious, in what way?"
    GR "obvio, ¿de qué manera?"

# game/chapters/5_day.rpyc:1969
translate es day5afterfamily_99fd80db:

    # player "Obviously really interested in getting to know me."
    player "Obviamente, está muy interesado en conocerme."

# game/chapters/5_day.rpyc:1972
translate es day5afterfamily_0871eea8:

    # player "Oh, also...!"
    player "¡Oh, también...!"

# game/chapters/5_day.rpyc:1975
translate es day5afterfamily_2521c0c4:

    # player "You rambled to yourself again!"
    player "¡Te pusiste a divagar otra vez!"

# game/chapters/5_day.rpyc:1978
translate es day5afterfamily_02f6fd3e:

    # player "The last time you did that was when we first met."
    player "La última vez que hiciste eso fue cuando nos conocimos."

# game/chapters/5_day.rpyc:1979
translate es day5afterfamily_d10cfe95:

    # GR "i did not ramble then."
    GR "Entonces no divagué."

# game/chapters/5_day.rpyc:1982
translate es day5afterfamily_a25799d6:

    # player "You kind of did. Had a little chat to yourself."
    player "En cierto modo, sí. Tuviste una pequeña charla contigo mismo."

# game/chapters/5_day.rpyc:1983
translate es day5afterfamily_5a2fc423:

    # GR "nope. you are remembering incorrectly."
    GR "nop. estás recordando incorrectamente."

# game/chapters/5_day.rpyc:1984
translate es day5afterfamily_fc908f9d:

    # GR "i would not make such a fool of myself. i am the grim reaper."
    GR "no me puse en ridículo a mí mismo. yo soy la parca."

# game/chapters/5_day.rpyc:1987
translate es day5afterfamily_b28101fc:

    # player "If you say so, Grim."
    player "Si tu lo dices, Parca."

# game/chapters/5_day.rpyc:1989
translate es day5afterfamily_10726f16:

    # GR "i was simply testing the program to ensure it ran correctly."
    GR "simplemente estaba probando el programa para asegurarme de que se ejecutara correctamente."

# game/chapters/5_day.rpyc:1990
translate es day5afterfamily_f3426f52:

    # GR "that is all."
    GR "eso es todo."

# game/chapters/5_day.rpyc:1993
translate es day5afterfamily_95356836:

    # player "Well, it definitely did."
    player "Bueno, sin duda lo hacías."

# game/chapters/5_day.rpyc:1996
translate es day5afterfamily_ab950562:

    # player "I saw them just in time to witness something hilarious."
    player "Los vi justo a tiempo para presenciar algo muy gracioso."

# game/chapters/5_day.rpyc:1997
translate es day5afterfamily_66b0a1b9:

    # GR "just in time to bare witness to my shame..."
    GR "justo a tiempo para ser testigo de mi vergüenza..."

# game/chapters/5_day.rpyc:2000
translate es day5afterfamily_69b0ca05:

    # player "Right as you yelled 'Fuck Me!'"
    player "Justo cuando gritaste '¡Que Me Jodan!'."

# game/chapters/5_day.rpyc:2003
translate es day5afterfamily_4d7f2d2f:

    # player "Definitely a way to introduce yourself to someone."
    player "Sin duda, una forma de presentarse a alguien."

# game/chapters/5_day.rpyc:2005
translate es day5afterfamily_8a5ec062:

    # player "And it certainly got my attention, that's for sure."
    player "Y sin duda llamó mi atención, eso es seguro."

# game/chapters/5_day.rpyc:2006
translate es day5afterfamily_7772a27d_2:

    # GR "..."
    GR "..."

# game/chapters/5_day.rpyc:2009
translate es day5afterfamily_83eac142:

    # player "I'm never going to let you live it down."
    player "Nunca te voy a dejar olvidarlo."

# game/chapters/5_day.rpyc:2010
translate es day5afterfamily_f1fbacdd:

    # GR "oh, yay."
    GR "Oh, yey."

# game/chapters/5_day.rpyc:2011
translate es day5afterfamily_f252156b:

    # GR "i'm so joyful at the prospect. how lovely. fantastic, even."
    GR "estoy tan alegre con la noticia. qué encantador. fantástico, incluso."

# game/chapters/5_day.rpyc:2014
translate es day5afterfamily_4f1f4833:

    # player "I'm glad! :)"
    player "¡Me alegro! :)"

# game/chapters/5_day.rpyc:2016
translate es day5afterfamily_5adf6877:

    # player "I knew you would be!"
    player "¡Sabía que lo sería!"

# game/chapters/5_day.rpyc:2022
translate es day5afterfamily_47a83bf3:

    # player "Oh, my mistake. I must be remembering wrong, huh?"
    player "Oh, mi error. Debo estar recordando mal, ¿eh?"

# game/chapters/5_day.rpyc:2023
translate es day5afterfamily_ab00da51:

    # GR "you should see about getting your memory looked at."
    GR "deberías hacerte revisar la memoria."

# game/chapters/5_day.rpyc:2024
translate es day5afterfamily_0a2551cc:

    # GR "maybe you are developing an issue."
    GR "quizás estés desarrollando un problema."

# game/chapters/5_day.rpyc:2025
translate es day5afterfamily_9507ccca:

    # GR "it could be quite serious."
    GR "podría ser bastante grave."

# game/chapters/5_day.rpyc:2028
translate es day5afterfamily_d7f4cca7:

    # player "Stop messing around."
    player "Deja de jugar."

# game/chapters/5_day.rpyc:2031
translate es day5afterfamily_985936ce:

    # player "I don't have any memory issues."
    player "No tengo problemas de memoria."

# game/chapters/5_day.rpyc:2034
translate es day5afterfamily_634a35b3:

    # player "I was just being sarcastic."
    player "Solo estaba hablando con sarcasmo."

# game/chapters/5_day.rpyc:2035
translate es day5afterfamily_e8b0a9dd:

    # GR "you? sarcastic? no, you would never."
    GR "¿tú? ¿sarcasmo? no, nunca lo harías."

# game/chapters/5_day.rpyc:2039
translate es day5afterfamily_6d965baf:

    # player "Ha ha ha, very funny."
    player "Ja, ja, ja, muy divertido."

# game/chapters/5_day.rpyc:2040
translate es day5afterfamily_204714e6:

    # GR "i am hilarious, yes. thank you for noticing."
    GR "soy gracioso, sí. gracias por notarlo."

# game/chapters/5_day.rpyc:2043
translate es day5afterfamily_812d8506:

    # player "Golly gosh, I just cannot stop laughing."
    player "Diosh mioh, Simplemente no puedo dejar de reír."

# game/chapters/5_day.rpyc:2047
translate es day5afterfamily_457447d4:

    # player "Boy, I've never heard anything so funny before!"
    player "Chico, ¡nunca antes había escuchado nada tan divertido!"

# game/chapters/5_day.rpyc:2050
translate es day5afterfamily_2c1b3606:

    # player "I'm still being sarcastic."
    player "Todavía estoy hablando con sarcasmo."

# game/chapters/5_day.rpyc:2051
translate es day5afterfamily_7772a27d_3:

    # GR "..."
    GR "..."

# game/chapters/5_day.rpyc:2052
translate es day5afterfamily_025bb444:

    # GR "it seems i was fooled this time."
    GR "parece que esta vez me han engañado."

# game/chapters/5_day.rpyc:2055
translate es day5afterfamily_ebc90222:

    # player "That seems to happen a lot with you."
    player "Eso parece sucederte muy a menudo."

# game/chapters/5_day.rpyc:2059
translate es day5afterfamily_64fa8dbc:

    # player "You did! I screenshot the messages to look at later!"
    player "¡Lo hiciste! ¡Hice una captura de pantalla de los mensajes para verlos más tarde!"

# game/chapters/5_day.rpyc:2060
translate es day5afterfamily_3e2f6fac:

    # GR "huh? why? why would you ever need to look at them again...?"
    GR "¿eh? ¿por qué? ¿por qué ibas a necesitar volver a verlos...?"

# game/chapters/5_day.rpyc:2063
translate es day5afterfamily_d04f6735:

    # player "Honestly?"
    player "¿Honestamente?"

# game/chapters/5_day.rpyc:2066
translate es day5afterfamily_a89514cd:

    # player "At first because I thought it was kind of funny."
    player "Al principio porque me pareció gracioso."

# game/chapters/5_day.rpyc:2069
translate es day5afterfamily_8bb669f2:

    # player "So I kept them, for a laugh."
    player "Así que las guardé, por diversión."

# game/chapters/5_day.rpyc:2070
translate es day5afterfamily_d622a28b:

    # GR "i do not intend to amuse you."
    GR "no tenia la intención de divertirte."

# game/chapters/5_day.rpyc:2071
translate es day5afterfamily_1de26bf4:

    # GR "i was being quite serious."
    GR "estaba siendo bastante serio."

# game/chapters/5_day.rpyc:2074
translate es day5afterfamily_a39f8828:

    # player "I know you were."
    player "Sé que lo estabas haciendo."

# game/chapters/5_day.rpyc:2077
translate es day5afterfamily_805cabf3:

    # player "And that made it even funnier."
    player "Y eso lo hizo aún más divertido."

# game/chapters/5_day.rpyc:2078
translate es day5afterfamily_f07d318a:

    # GR "oh, how pleased i am to amuse you..."
    GR "oh, qué feliz me hace entretenerte..."

# game/chapters/5_day.rpyc:2079
translate es day5afterfamily_b4228ac8:

    # GR "i will forever live with this tattooed onto my soul."
    GR "viviré para siempre con esto tatuado en mi alma."

# game/chapters/5_day.rpyc:2080
translate es day5afterfamily_897f2468:

    # GR "may they forever sing melodies about how i, the best reaper around, was able to {i}amuse{/i} a mortal [girl]."
    GR "que canten melodías sobre cómo yo, la mejor parca que existe, fui capaz de {i}divertir{/i} a un[girl!t] mortal."

# game/chapters/5_day.rpyc:2081
translate es day5afterfamily_87e786eb:

    # GR "i have truly broken out of the shell that defines us reapers."
    GR "realmente he salido del caparazón que nos define a las parcas."

# game/chapters/5_day.rpyc:2085
translate es day5afterfamily_9c925446:

    # player "Are you trying to be funny now, too?"
    player "¿Estás tratando de ser divertido ahora también?"

# game/chapters/5_day.rpyc:2086
translate es day5afterfamily_0dd36503:

    # GR "indeed. i'm glad you could tell."
    GR "por supuesto. me alegra que lo hayas notado."

# game/chapters/5_day.rpyc:2087
translate es day5afterfamily_649157ba:

    # GR "though i have done many things that would be worth singing about..."
    GR "aunque he hecho muchas cosas que merecerían ser cantadas..."

# game/chapters/5_day.rpyc:2088
translate es day5afterfamily_fb1f3c78:

    # GR "i would not enjoy it if a bard sang about me."
    GR "no me gustaría que un bardo cantara sobre mí."

# game/chapters/5_day.rpyc:2089
translate es day5afterfamily_d2a7ec6b:

    # GR "i would have to resort to drastic measures to silence them."
    GR "tendría que recurrir a medidas drásticas para silenciarlos."

# game/chapters/5_day.rpyc:2090
translate es day5afterfamily_a721128d:

    # GR "after all, being a reaper is a secret."
    GR "después de todo, ser una parca es un secreto."

# game/chapters/5_day.rpyc:2091
translate es day5afterfamily_50d274f8:

    # GR "if they knew of my deeds, they would need to be... taken care of."
    GR "si supieran de mis actos, habría que... ocuparse de ellos."

# game/chapters/5_day.rpyc:2094
translate es day5afterfamily_229560f9:

    # player "Woah hold up now buddy, that is just a tad extreme."
    player "Woah espera un momento, amigo, eso es un poco extremo."

# game/chapters/5_day.rpyc:2096
translate es day5afterfamily_b10c84f9:

    # player "You'd {i}kill{/i} them???"
    player "¿¿¿Los {i}matarías{/i}???"

# game/chapters/5_day.rpyc:2098
translate es day5afterfamily_0c669aca:

    # GR "it would be an appropriate response."
    GR "sería una respuesta adecuada."

# game/chapters/5_day.rpyc:2101
translate es day5afterfamily_8c139725:

    # player "Fortunately, I've never heard a... 'bard' singing about you."
    player "Afortunadamente, nunca he escuchado a un... 'bardo' cantar sobre ti."

# game/chapters/5_day.rpyc:2103
translate es day5afterfamily_a6d21737:

    # GR "and thank the lords for that."
    GR "y da gracias a los cielos por eso."

# game/chapters/5_day.rpyc:2106
translate es day5afterfamily_eb5741cd:

    # player "I would pay to see that, though."
    player "Sin embargo, pagaría para ver eso."

# game/chapters/5_day.rpyc:2108
translate es day5afterfamily_7d3aa033:

    # GR "and i would pay to {i}not{/i}."
    GR "y pagaría por {i}no{/i}."

# game/chapters/5_day.rpyc:2111
translate es day5afterfamily_3344e46b:

    # player "Then I would simply have to offer more money than you."
    player "Entonces simplemente tendría que ofrecer más dinero que tú."

# game/chapters/5_day.rpyc:2114
translate es day5afterfamily_1c3cf86c:

    # player "They'd have no choice but to play."
    player "No tendrían más remedio que tocar."

# game/chapters/5_day.rpyc:2119
translate es day5afterfamily_a00b373f:

    # player "Since when do reapers have shells, btw?"
    player "Por cierto, ¿desde cuándo las parcas tienen caparazones?"

# game/chapters/5_day.rpyc:2120
translate es day5afterfamily_45fab179:

    # GR "they don't."
    GR "no los tienen."

# game/chapters/5_day.rpyc:2121
translate es day5afterfamily_7b1e9709:

    # GR "we are not {i}crabs{/i}."
    GR "no somos {i}cangrejos{/i}."

# game/chapters/5_day.rpyc:2124
translate es day5afterfamily_d7330fd0:

    # player "Are you sure?"
    player "¿Estás seguro?"

# game/chapters/5_day.rpyc:2128
translate es day5afterfamily_80755539:

    # player "You do usually look kinda... crabby."
    player "Sueles ponerte un poco... cangrejudo."

# game/chapters/5_day.rpyc:2130
translate es day5afterfamily_f3b1f875:

    # GR "......"
    GR "......"

# game/chapters/5_day.rpyc:2131
translate es day5afterfamily_060e3d03:

    # GR "your pun pains me."
    GR "tu juego de palabras me duele."

# game/chapters/5_day.rpyc:2132
translate es day5afterfamily_9f5f2b47:

    # GR "you are like a splinter."
    GR "eres como una astilla."

# game/chapters/5_day.rpyc:2133
translate es day5afterfamily_c32aba75:

    # GR "truly one of the worst pains one can suffer."
    GR "verdaderamente uno de los peores dolores que uno puede sufrir."

# game/chapters/5_day.rpyc:2136
translate es day5afterfamily_8845d76b:

    # player "That's what you think one of the worse pains is???"
    player "¿¿¿Eso es lo que consideras uno de los peores dolores???"

# game/chapters/5_day.rpyc:2137
translate es day5afterfamily_cb587b0c:

    # GR "i also dislike papercuts."
    GR "también me disgustan los cortes con papel."

# game/chapters/5_day.rpyc:2138
translate es day5afterfamily_500456e5:

    # GR "i get them often enough doing paperwork."
    GR "me ocurren con bastante frecuencia al hacer papeleo."

# game/chapters/5_day.rpyc:2139
translate es day5afterfamily_27f6483d:

    # GR "they might be worse than splinters, actually."
    GR "de hecho, pueden ser peores que las astillas."

# game/chapters/5_day.rpyc:2140
translate es day5afterfamily_3467fa7c:

    # GR "you are like a papercut to me."
    GR "eres como un corte de papel para mí."

# game/chapters/5_day.rpyc:2143
translate es day5afterfamily_b9dc34f7:

    # player "I'm your favorite papercut!"
    player "¡Soy tu corte de papel favorito!"

# game/chapters/5_day.rpyc:2144
translate es day5afterfamily_24c91eb3:

    # GR "i do not understand what that means."
    GR "no entiendo lo que eso significa."

# game/chapters/5_day.rpyc:2145
translate es day5afterfamily_dcf93fcf:

    # GR "i do not have a favorite papercut. they are all equally bad."
    GR "no tengo un corte de papel favorito. todos son igualmente malos."

# game/chapters/5_day.rpyc:2149
translate es day5afterfamily_c8fdf58b:

    # player "Except for me. I'm slightly better than the others."
    player "Excepto por mí. Soy un poco mejor que los demás."

# game/chapters/5_day.rpyc:2152
translate es day5afterfamily_60d49a5e:

    # player "You're my favorite idiot, did you know that?"
    player "Eres mi idiota favorito, ¿lo sabías?"

# game/chapters/5_day.rpyc:2155
translate es day5afterfamily_98b51594:

    # player "You never make any sense."
    player "Nunca tienes sentido."

# game/chapters/5_day.rpyc:2158
translate es day5afterfamily_569833eb:

    # player "At all."
    player "En absoluto."

# game/chapters/5_day.rpyc:2160
translate es day5afterfamily_1febb025:

    # GR "ha."
    GR "ha."

# game/chapters/5_day.rpyc:2161
translate es day5afterfamily_e1f75ed1:

    # GR "you are unable to understand."
    GR "no puedes entender."

# game/chapters/5_day.rpyc:2162
translate es day5afterfamily_2f97cf25:

    # GR "my brain is truly on another level."
    GR "mi cerebro está realmente en otro nivel."

# game/chapters/5_day.rpyc:2165
translate es day5afterfamily_c237b9ba:

    # player "...?"
    player "...?"

# game/chapters/5_day.rpyc:2168
translate es day5afterfamily_f16ad197:

    # player "Moving away from... that."
    player "Dejando atrás... eso."

# game/chapters/5_day.rpyc:2171
translate es day5afterfamily_4205dbd9:

    # player "I'd listen to a song about you on repeat."
    player "Escucharía una canción sobre ti una y otra vez."

# game/chapters/5_day.rpyc:2173
translate es day5afterfamily_649157ba_1:

    # GR "though i have done many things that would be worth singing about..."
    GR "aunque he hecho muchas cosas que merecerían ser cantadas..."

# game/chapters/5_day.rpyc:2174
translate es day5afterfamily_fb1f3c78_1:

    # GR "i would not enjoy it if a bard sang about me."
    GR "no me gustaría que un bardo cantara sobre mí."

# game/chapters/5_day.rpyc:2175
translate es day5afterfamily_d2a7ec6b_1:

    # GR "i would have to resort to drastic measures to silence them."
    GR "tendría que recurrir a medidas drásticas para silenciarlos."

# game/chapters/5_day.rpyc:2176
translate es day5afterfamily_a721128d_1:

    # GR "after all, being a reaper is a secret."
    GR "después de todo, ser una parca es un secreto."

# game/chapters/5_day.rpyc:2177
translate es day5afterfamily_50d274f8_1:

    # GR "if they knew of my deeds, they would need to be... taken care of."
    GR "si supieran de mis actos, habría que... ocuparse de ellos."

# game/chapters/5_day.rpyc:2180
translate es day5afterfamily_20e00019:

    # player "Wow! Straight to murder!"
    player "¡Wow! ¡Directo al asesinato!"

# game/chapters/5_day.rpyc:2184
translate es day5afterfamily_7a9cb536:

    # player "Somehow this is one of the least surprising things you've said."
    player "De alguna manera, esta es una de las cosas menos sorprendentes que has dicho."

# game/chapters/5_day.rpyc:2188
translate es day5afterfamily_9cb11067:

    # player "I would seriously pay to see someone sing about you, though."
    player "Sin embargo, pagaría con mucho gusto por ver a alguien cantar sobre ti."

# game/chapters/5_day.rpyc:2192
translate es day5afterfamily_742cf695:

    # player "Maybe I will."
    player "Tal vez lo haga."

# game/chapters/5_day.rpyc:2198
translate es day5afterfamily_ea96ebcc:

    # player "So you're like one of those ninja tortoises, then?"
    player "¿Entonces eres como una de esas tortugas ninja?"

# game/chapters/5_day.rpyc:2199
translate es day5afterfamily_5125381a:

    # GR "excuse me?"
    GR "¿disculpa?"

# game/chapters/5_day.rpyc:2200
translate es day5afterfamily_8f44bc4e:

    # GR "do i look like a ninja to you?"
    GR "¿Te parezco un ninja?"

# game/chapters/5_day.rpyc:2203
translate es day5afterfamily_e8d12327:

    # player "Your outfit does kinda give an 'I'm a ninja' vibe."
    player "Tu atuendo da vibra de 'soy un ninja'."

# game/chapters/5_day.rpyc:2204
translate es day5afterfamily_fa4b3f57:

    # GR "no, it gives reaper vibes."
    GR "no, da vibras de parca."

# game/chapters/5_day.rpyc:2207
translate es day5afterfamily_090bdd44:

    # player "They are similar enough, no?"
    player "Son lo suficientemente similares, ¿no?"

# game/chapters/5_day.rpyc:2208
translate es day5afterfamily_cbef98a7:

    # GR "they are extremely different!"
    GR "¡son extremadamente diferentes!"

# game/chapters/5_day.rpyc:2209
translate es day5afterfamily_0e51f2a1:

    # GR "reapers have structure!"
    GR "¡las parcas tienen estructura!"

# game/chapters/5_day.rpyc:2210
translate es day5afterfamily_4bec9bb2:

    # GR "order!"
    GR "¡orden!"

# game/chapters/5_day.rpyc:2211
translate es day5afterfamily_4ef7d739:

    # GR "i cannot say the same for any ninja i have met!"
    GR "¡no puedo decir lo mismo de ningún ninja que haya conocido.!"

# game/chapters/5_day.rpyc:2214
translate es day5afterfamily_8f75cd1e:

    # player "Oh, really?"
    player "¿Ah, de verdad?"

# game/chapters/5_day.rpyc:2216
translate es day5afterfamily_aada664c:

    # player "I didn't know you were a ninja expert, Grim."
    player "No sabía que eras un experto en ninjas, Parca."

# game/chapters/5_day.rpyc:2217
translate es day5afterfamily_7772a27d_4:

    # GR "..."
    GR "..."

# game/chapters/5_day.rpyc:2218
translate es day5afterfamily_4fed0a66:

    # GR "i mean, i just assume..."
    GR "quiero decir, solo supongo..."

# game/chapters/5_day.rpyc:2221
translate es day5afterfamily_2c6912fd:

    # player "So that's how it is."
    player "Así que eso es lo que pasa."

# game/chapters/5_day.rpyc:2223
translate es day5afterfamily_4db2931d:

    # player "Yeah I guessed as much."
    player "Sí, eso me imaginaba."

# game/chapters/5_day.rpyc:2226
translate es day5afterfamily_a985972a:

    # player "Not at all. Ninjas are kinda cool, and you're..."
    player "Para nada. Los ninjas son geniales, y tú eres..."

# game/chapters/5_day.rpyc:2227
translate es day5afterfamily_80e7848e:

    # GR "i feel insulted right now. wow."
    GR "me siento insultado en este momento. wow."

# game/chapters/5_day.rpyc:2230
translate es day5afterfamily_7d462523:

    # player "Though I gotta say, your scythe is cooler than little ninja daggers."
    player "Aunque tengo que decir que tu guadaña es más cool que las pequeñas dagas ninja."

# game/chapters/5_day.rpyc:2231
translate es day5afterfamily_34f1c616:

    # GR "that's right. i am much cooler than a ninja."
    GR "así es. soy mucho más genial que un ninja."

# game/chapters/5_day.rpyc:2232
translate es day5afterfamily_35f9f2ca:

    # GR "stupid ninjas."
    GR "estúpidos ninjas."

# game/chapters/5_day.rpyc:2233
translate es day5afterfamily_053273ea:

    # GR "they could never do what i do with those puny little knives."
    GR "nunca podrían hacer lo que yo hago con esos cuchillos tan pequeños."

# game/chapters/5_day.rpyc:2237
translate es day5afterfamily_b5ae47a3:

    # player "Do you think there are songs about ninjas?"
    player "¿Crees que hay canciones sobre ninjas?"

# game/chapters/5_day.rpyc:2238
translate es day5afterfamily_59da8f5b:

    # GR "i think there are probably songs about most things."
    GR "creo que probablemente hay canciones sobre casi todo."

# game/chapters/5_day.rpyc:2241
translate es day5afterfamily_b2ed67e6:

    # player "But not about you, it seems. Maybe the ninjas {i}do{/i} have one up on you?"
    player "Pero parece que no es tu caso. ¿Quizás los ninjas {i}te llevan{/i} ventaja?"

# game/chapters/5_day.rpyc:2242
translate es day5afterfamily_7772a27d_5:

    # GR "..."
    GR "..."

# game/chapters/5_day.rpyc:2245
translate es day5afterfamily_0d2c9cc2:

    # player "Should I look for someone to make a pity song about you?"
    player "¿Debería buscar a alguien que componga una canción compasiva sobre ti?"

# game/chapters/5_day.rpyc:2246
translate es day5afterfamily_7772a27d_6:

    # GR "..."
    GR "..."

# game/chapters/5_day.rpyc:2247
translate es day5afterfamily_5d364529_1:

    # GR "no."
    GR "no."

# game/chapters/5_day.rpyc:2248
translate es day5afterfamily_2a655365:

    # GR "if they ever sung songs about me..."
    GR "si alguna vez cantaran canciones sobre mí.."

# game/chapters/5_day.rpyc:2249
translate es day5afterfamily_d2a7ec6b_2:

    # GR "i would have to resort to drastic measures to silence them."
    GR "tendría que recurrir a medidas drásticas para silenciarlos."

# game/chapters/5_day.rpyc:2250
translate es day5afterfamily_c1d496b7:

    # GR "after all, being a reaper is a secret. if they knew of my deeds, they would need to be... taken care of."
    GR "después de todo, ser una parca es un secreto. si supieran de mis actos, habría que... ocuparse de ellos."

# game/chapters/5_day.rpyc:2253
translate es day5afterfamily_a537d782:

    # player "Wow. That's a little extreme."
    player "Wow. Eso es un poco extremo."

# game/chapters/5_day.rpyc:2254
translate es day5afterfamily_0c669aca_1:

    # GR "it would be an appropriate response."
    GR "sería una respuesta apropiada."

# game/chapters/5_day.rpyc:2257
translate es day5afterfamily_12e576c0:

    # player "I'm not sure about 'appropriate'..."
    player "No sé si es lo más 'apropiado'...."

# game/chapters/5_day.rpyc:2261
translate es day5afterfamily_762cfc47:

    # player "I really do think some kind of theme song would help your image, though."
    player "Sin embargo, realmente creo que algún tipo de tema musical ayudaría a mejorar tu imagen."

# game/chapters/5_day.rpyc:2265
translate es day5afterfamily_2c8ea8ae:

    # player "Lets find someone to sing it :D"
    player "Busquemos a alguien que lo cante :D"

# game/chapters/5_day.rpyc:2270
translate es day5afterfamily_bd86d20a:

    # player "There are plenty of animals with shells, you know?"
    player "Hay muchos animales con caparazón, ¿sabes?"

# game/chapters/5_day.rpyc:2271
translate es day5afterfamily_d001687a:

    # GR "it is simply what came to mind first."
    GR "es simplemente lo primero que se me vino a la mente."

# game/chapters/5_day.rpyc:2274
translate es day5afterfamily_790b8279:

    # player "Wait, I know a gnarly song about crabs having a rave."
    player "Espera, conozco una canción genial sobre cangrejos que se van de fiesta."

# game/chapters/5_day.rpyc:2275
translate es day5afterfamily_f2acb82d:

    # GR "that is... certainly a sentence."
    GR "eso es... sin duda, una frase."

# game/chapters/5_day.rpyc:2276
translate es day5afterfamily_a3e52d50:

    # GR "that you should not finish."
    GR "que no debes terminar."

# game/chapters/5_day.rpyc:2277
translate es day5afterfamily_275c13ad:

    # GR "crabs having a rave? that is not possible."
    GR "¿cangrejos haciendo una fiesta? eso no es posible."

# game/chapters/5_day.rpyc:2280
translate es day5afterfamily_aca92269:

    # player "Fine fine. Your loss though. It really is a banger."
    player "Está bien, está bien. Pero tú te lo pierdes. Es realmente increíble."

# game/chapters/5_day.rpyc:2283
translate es day5afterfamily_955d7576:

    # player "Speaking of bangers!"
    player "¡Hablando de éxitos!"

# game/chapters/5_day.rpyc:2286
translate es day5afterfamily_3ac7a72d:

    # player "I hope someone does write songs about you."
    player "Espero que alguien escriba canciones sobre ti."

# game/chapters/5_day.rpyc:2288
translate es day5afterfamily_2a655365_1:

    # GR "if they ever sung songs about me..."
    GR "si alguna vez cantaran canciones sobre mí.."

# game/chapters/5_day.rpyc:2289
translate es day5afterfamily_d2a7ec6b_3:

    # GR "i would have to resort to drastic measures to silence them."
    GR "tendría que recurrir a medidas drásticas para silenciarlos."

# game/chapters/5_day.rpyc:2290
translate es day5afterfamily_c1d496b7_1:

    # GR "after all, being a reaper is a secret. if they knew of my deeds, they would need to be... taken care of."
    GR "después de todo, ser una parca es un secreto. si supieran de mis actos, habría que... ocuparse de ellos."

# game/chapters/5_day.rpyc:2294
translate es day5afterfamily_0d0e48f7:

    # player "Okay, edgelord. No need to resort to murder."
    player "Ok, señor edgy. No hay necesidad de recurrir al asesinato."

# game/chapters/5_day.rpyc:2295
translate es day5afterfamily_0c669aca_2:

    # GR "it would be an appropriate response."
    GR "sería una respuesta apropiada."

# game/chapters/5_day.rpyc:2299
translate es day5afterfamily_c7326676:

    # player "I doubt you'd really do that, anyway."
    player "Dudo que realmente hagas eso, de todos modos."

# game/chapters/5_day.rpyc:2303
translate es day5afterfamily_bd2fe980:

    # player "So I'm gonna find someone to sing about you :D"
    player "Así que voy a encontrar a alguien que cante sobre ti: D"

# game/chapters/5_day.rpyc:2347
translate es call1a_day5_614e603a:

    # GRC "You wouldn't dare."
    GRC "no te atreverías."

# game/chapters/5_day.rpyc:2358
translate es call1a_day5_d6a20b5f:

    # GRC "You wouldn't. You are just being dramatic, as per usual."
    GRC "no lo harías. solo estás exagerando, como siempre."

# game/chapters/5_day.rpyc:2371
translate es call1a_day5_4966c0ec:

    # GRC "Tsk..."
    GRC "Tsk..."

# game/chapters/5_day.rpyc:2376
translate es call1a_day5_343235ee:

    # GRC "And what look is that exactly?"
    GRC "¿Y qué mirada es esa exactamente?"

# game/chapters/5_day.rpyc:2391
translate es call1a_day5_5c65e1bb:

    # GRC "What in the nine hells are you talking about?"
    GRC "¿De qué demonios estás hablando?"

# game/chapters/5_day.rpyc:2392
translate es call1a_day5_189d2751:

    # GRC "Why would I ever want someone to {i}bully{/i} me?"
    GRC "¿Por qué iba a querer que alguien me {i}intimidara{/i}?"

# game/chapters/5_day.rpyc:2393
translate es call1a_day5_b0dda70e:

    # GRC "Please, enlighten-"
    GRC "Por favor, aclárame-"

# game/chapters/5_day.rpyc:2399
translate es call1a_day5_28e3c646:

    # GRC "Why?"
    GRC "¿Por qué?"

# game/chapters/5_day.rpyc:2413
translate es call1a_day5_da0bac4b:

    # GRC "You ought to win an award for the most blabbering mouth, mortal."
    GRC "Deberías ganar un premio por ser el más hablador, mortal."

# game/chapters/5_day.rpyc:2415
translate es call1a_day5_94eaecc6:

    # GRC "You talk and talk and talk and it's all nonsense."
    GRC "Hablas y hablas y hablas, y todo lo que dices son tonterías."

# game/chapters/5_day.rpyc:2416
translate es call1a_day5_f4acc881:

    # GRC "It's nearly impressive."
    GRC "Es casi impresionante."

# game/chapters/5_day.rpyc:2418
translate es call1a_day5_62b26e5d:

    # GRC "Instead you're just an idiot."
    GRC "En cambio, solo eres un idiota."

# game/chapters/5_day.rpyc:2425
translate es call1a_day5_b04984aa:

    # GRC "Ah, yes, the children's insult. I have certainly been got."
    GRC "Ah, claro, el típico insulto infantil. Qué golpe tan devastador."

# game/chapters/5_day.rpyc:2428
translate es call1a_day5_04470c01:

    # GRC "I don't need bossing around or {i}bullying{/i}, anyway. I am a creature that was born to be in charge."
    GRC "De todos modos, no necesito que me den órdenes {i}ni me intimiden{/i}. Soy una criatura que nació para mandar."

# game/chapters/5_day.rpyc:2430
translate es call1a_day5_7587e146:

    # GRC "You ought to know your place, mortal."
    GRC "Deberías conocer tu lugar, mortal."

# game/chapters/5_day.rpyc:2434
translate es call1a_day5_fac44fd2:

    # GRC "Good. It is the natural order of things."
    GRC "Bien. Es el orden natural de las cosas."

# game/chapters/5_day.rpyc:2439
translate es call1a_day5_85e548b2:

    # GRC "...Like?"
    GRC "...¿Como?"

# game/chapters/5_day.rpyc:2451
translate es call1a_day5_bff51a52:

    # GRC "You are only setting yourself up for disappointment."
    GRC "Solo te estás preparando para una decepción."

# game/chapters/5_day.rpyc:2457
translate es call1a_day5_29fb6216:

    # GRC "You will not be doing that."
    GRC "No harás eso."

# game/chapters/5_day.rpyc:2472
translate es call1a_day5_1c909085:

    # GRC "Remind me again why I haven't taken your soul yet..."
    GRC "Recuérdame otra vez por qué aún no te he quitado el alma..."

# game/chapters/5_day.rpyc:2481
translate es call1a_day5_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/5_day.rpyc:2486
translate es call1a_day5_3b6f5542:

    # GRC "I could get back to more pressing work, and become more respected in my position."
    GRC "Podría volver a dedicarme a tareas más urgentes y ganar más respeto en mi puesto."

# game/chapters/5_day.rpyc:2495
translate es call1a_day5_0feca6f4:

    # GRC "It is beneficial to have good work ethic."
    GRC "Es beneficioso tener una buena ética de trabajo."

# game/chapters/5_day.rpyc:2500
translate es call1a_day5_35cd5967:

    # GRC "And you think I'm relaxed while talking to you?"
    GRC "¿Y crees que estoy relajado mientras hablo contigo?"

# game/chapters/5_day.rpyc:2508
translate es call1a_day5_496962aa:

    # GRC "I... I have no clue what you're talking about."
    GRC "Yo... no tengo ni idea de lo que estás hablando."

# game/chapters/5_day.rpyc:2509
translate es call1a_day5_f2da9d5c:

    # GRC "You... should learn to keep your mouth shut."
    GRC "Tú... deberías aprender a mantener la boca cerrada."

# game/chapters/5_day.rpyc:2519
translate es call1a_day5_408f7f0c:

    # GRC "What is a 'please treat me gently' look, exactly?"
    GRC "¿Qué es exactamente una mirada que dice 'por favor, sé gentil'?"

# game/chapters/5_day.rpyc:2521
translate es call1a_day5_748eae49:

    # GRC "Do I look gentle to you?"
    GRC "¿Te parezco gentil?"

# game/chapters/5_day.rpyc:2533
translate es call1a_day5_6c08df0f:

    # GRC "I am... literally not that."
    GRC "Yo no soy... literalmente eso."

# game/chapters/5_day.rpyc:2546
translate es call1a_day5_690ebf1c:

    # GRC "I am a man to be feared."
    GRC "Soy un hombre al que hay que temer."

# game/chapters/5_day.rpyc:2558
translate es call1a_day5_9467829c:

    # GRC "....."
    GRC "....."

# game/chapters/5_day.rpyc:2570
translate es call1a_day5_17f2d719:

    # GRC "How is that thing more precious than me?"
    GRC "¿Cómo es posible que esa cosa sea más valiosa que yo?"

# game/chapters/5_day.rpyc:2580
translate es call1a_day5_942bee60:

    # GRC "I just think you couldn't compare me to a {i}pet{/i} of all things!"
    GRC "¡Es que no puedes compararme con una {i}mascota{/i} de todas las cosas!"

# game/chapters/5_day.rpyc:2592
translate es call1a_day5_c522ec7f:

    # GRC "It is just a bunny."
    GRC "Es solo un conejito."

# game/chapters/5_day.rpyc:2604
translate es call1a_day5_ea427a00:

    # GRC "...Not as cute as my face..."
    GRC "...No tan adorable como mi rostro..."

# game/chapters/5_day.rpyc:2613
translate es call1a_day5_5f8549da:

    # GRC "I said, yes, very cute."
    GRC "Dije, sí, muy adorable."

# game/chapters/5_day.rpyc:2614
translate es call1a_day5_0d2b09b3:

    # GRC "I will admit, your pet's ears are very floppy and adorable."
    GRC "Lo admito, las orejas de tu mascota son muy flexibles y adorables."

# game/chapters/5_day.rpyc:2619
translate es call1a_day5_32aebfbb:

    # GRC "How is it different to any other cat in the world?"
    GRC "¿En qué se diferencia de cualquier otro gato del mundo?"

# game/chapters/5_day.rpyc:2634
translate es call1a_day5_ea427a00_1:

    # GRC "...Not as cute as my face..."
    GRC "...No tan adorable como mi rostro..."

# game/chapters/5_day.rpyc:2643
translate es call1a_day5_5f8549da_1:

    # GRC "I said, yes, very cute."
    GRC "Dije, sí, muy adorable."

# game/chapters/5_day.rpyc:2644
translate es call1a_day5_b56bbde9:

    # GRC "Hmm. Its face is very round. I would like to squeeze it."
    GRC "Mmm. Su cara es muy redonda. Me gustaría apretarla."

# game/chapters/5_day.rpyc:2649
translate es call1a_day5_c484c97c:

    # GRC "What happened to it's fur?"
    GRC "¿Qué pasó con su pelaje?"

# game/chapters/5_day.rpyc:2656
translate es call1a_day5_01ace8e9:

    # GRC "That seems irresponsible and concerning if you did it by accident."
    GRC "Eso parece irresponsable y preocupante si lo hiciste por accidente."

# game/chapters/5_day.rpyc:2670
translate es call1a_day5_57cc994e:

    # GRC "What does it feel like, then?"
    GRC "¿Cómo se siente, entonces?"

# game/chapters/5_day.rpyc:2681
translate es call1a_day5_9e62544d:

    # GRC "...Not as cute as me..."
    GRC "...No tan adorable como yo..."

# game/chapters/5_day.rpyc:2690
translate es call1a_day5_5f8549da_2:

    # GRC "I said, yes, very cute."
    GRC "Dije, sí, muy adorable."

# game/chapters/5_day.rpyc:2691
translate es call1a_day5_7ba9a869:

    # GRC "I would like to touch it, just to experience it."
    GRC "Me gustaría tocarle, solo para experimentarlo."

# game/chapters/5_day.rpyc:2696
translate es call1a_day5_32693d81:

    # GRC "A dog like any other."
    GRC "Un perro como cualquier otro."

# game/chapters/5_day.rpyc:2712
translate es call1a_day5_ea427a00_2:

    # GRC "...Not as cute as my face..."
    GRC "...No tan adorable como mi rostro..."

# game/chapters/5_day.rpyc:2722
translate es call1a_day5_5f8549da_3:

    # GRC "I said, yes, very cute."
    GRC "Dije, sí, muy adorable."

# game/chapters/5_day.rpyc:2723
translate es call1a_day5_cc26485f:

    # GRC "I will admit, it does look like an admirable beast."
    GRC "Lo admito, parece una bestia admirable."

# game/chapters/5_day.rpyc:2727
translate es call1a_day5_562b0c4a:

    # GRC "That thing is so small you can barely call it a pet."
    GRC "Esa cosa es tan pequeña que apenas se puede llamar mascota."

# game/chapters/5_day.rpyc:2743
translate es call1a_day5_9e62544d_1:

    # GRC "...Not as cute as me..."
    GRC "...No tan adorable como yo..."

# game/chapters/5_day.rpyc:2753
translate es call1a_day5_5f8549da_4:

    # GRC "I said, yes, very cute."
    GRC "Dije, sí, muy adorable."

# game/chapters/5_day.rpyc:2754
translate es call1a_day5_232b9090:

    # GRC "Hmm. It does seem quite rotund and cute."
    GRC "Hmm. Parece bastante una bolita adorable."

# game/chapters/5_day.rpyc:2759
translate es call1a_day5_43b46380:

    # GRC "Now THIS is a worthy beast for one who defies the Grim Reaper himself!"
    GRC "¡Esta SÍ que es una bestia digna para alguien que desafía a la mismísima Parca!"

# game/chapters/5_day.rpyc:2760
translate es call1a_day5_11030c9e:

    # GRC "A terrifying creature that represents the cycles of birth, death, and rebirth."
    GRC "Una criatura aterradora que representa los ciclos del nacimiento, la muerte y el renacimiento."

# game/chapters/5_day.rpyc:2770
translate es call1a_day5_0c14e6d0:

    # GRC "Oh."
    GRC "Oh."

# game/chapters/5_day.rpyc:2778
translate es call1a_day5_9e62544d_2:

    # GRC "...Not as cute as me..."
    GRC "...No tan adorable como yo..."

# game/chapters/5_day.rpyc:2787
translate es call1a_day5_a65e392e:

    # GRC "I said I don't know about cute."
    GRC "Dije que no sé nada sobre lo que es adorable."

# game/chapters/5_day.rpyc:2788
translate es call1a_day5_641fdd04:

    # GRC "Fearsome, strong. Cute... I suppose."
    GRC "Temible, Fuerte. Adorable... Supongo."

# game/chapters/5_day.rpyc:2830
translate es call1b_day5_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/5_day.rpyc:2833
translate es call1b_day5_a8167405:

    # GRC "I was... simply bored of typing out my responses to your stupidity."
    GRC "Simplemente estaba harto de escribir respuestas a tus estupideces."

# game/chapters/5_day.rpyc:2839
translate es call1b_day5_acecace1:

    # GRC "You are the one spouting nonsense."
    GRC "Tú eres quien dice tonterías."

# game/chapters/5_day.rpyc:2859
translate es day5vcmerge_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/5_day.rpyc:2865
translate es day5vcmerge_2b4e744c:

    # GRC "I'll... take it when the time is right."
    GRC "La tomaré... cuando sea el momento adecuado."

# game/chapters/5_day.rpyc:2879
translate es day5vcmerge_36799c9c:

    # GRC "That will not be happening."
    GRC "Eso no va a suceder."

# game/chapters/5_day.rpyc:2889
translate es day5vcmerge_166e097c:

    # GRC "You're STILL going on about that?!"
    GRC "¿¡Todavía SIGUES con eso?!"

# game/chapters/5_day.rpyc:2890
translate es day5vcmerge_7b03fd44:

    # GRC "It's not a thing! It'll never be a thing! It isn't happening!"
    GRC "¡No existe tal cosa! ¡Nunca existirá tal cosa! ¡No va a suceder!"

# game/chapters/5_day.rpyc:2893
translate es day5vcmerge_0269a621:

    # GRC "No!"
    GRC "¡No!"

# game/chapters/5_day.rpyc:2897
translate es day5vcmerge_e6cade35:

    # GRC "Say yes as many times as you want, it's still not happening!"
    GRC "Di que sí tantas veces como quieras, ¡no va a suceder!"

# game/chapters/5_day.rpyc:2899
translate es day5vcmerge_ed9f87e1:

    # GRC "You need to stop and THINK for a second!"
    GRC "¡Tienes que parar y PENSAR un segundo!"

# game/chapters/5_day.rpyc:2900
translate es day5vcmerge_d2d429fc:

    # GRC "There is no such thing as a SOUL BABY."
    GRC "No existe tal cosa como un BEBÉ ALMA"

# game/chapters/5_day.rpyc:2914
translate es day5vcmerge_0338be70:

    # GRC "I think I'm going to cry."
    GRC "Creo que voy a llorar."

# game/chapters/5_day.rpyc:2929
translate es day5vcmerge_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/5_day.rpyc:2934
translate es day5vcmerge_ddd2a272:

    # GRC "If you stopped talking you would improve as a person tenfold."
    GRC "Si dejaras de hablar, mejorarías como persona diez veces más."

# game/chapters/5_day.rpyc:2948
translate es day5vcmerge_06e47c30:

    # GRC "Another foolish assumption."
    GRC "Otra suposición tonta."

# game/chapters/5_day.rpyc:2949
translate es day5vcmerge_91c287f0:

    # GRC "A reaper outclasses a human in every way. Statistically, you cannot win."
    GRC "Una parca supera al ser humano en todos los aspectos. Estadísticamente, no puedes ganar."

# game/chapters/5_day.rpyc:2962
translate es day5vcmerge_88803113:

    # GRC "Maybe I'm just letting you have it until the last possible moment."
    GRC "Quizás solo te lo esté dejando tener hasta el último momento posible."

# game/chapters/5_day.rpyc:2967
translate es day5vcmerge_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/5_day.rpyc:2972
translate es day5vcmerge_fdf306b8:

    # GRC "You are fortunate, you know."
    GRC "Tienes suerte, ¿sabes?"

# game/chapters/5_day.rpyc:2978
translate es day5vcmerge_d2f61380:

    # GRC "Fortunate I was the reaper assigned to your case."
    GRC "Suerte de que yo soy la parca asignado a tu caso."

# game/chapters/5_day.rpyc:2979
translate es day5vcmerge_714824d1:

    # GRC "Another would not put up with you like I do."
    GRC "Nadie más te aguantaría como yo."

# game/chapters/5_day.rpyc:2989
translate es day05callcont_f1b94ea2:

    # GRC "Haaa..."
    GRC "Haaa..."

# game/chapters/5_day.rpyc:2990
translate es day05callcont_c6b414fe:

    # GRC "That is enough meaningless chatter."
    GRC "Ya basta de charla sin sentido."

# game/chapters/5_day.rpyc:2992
translate es day05callcont_b2b0dde2:

    # GRC "What were you doing, mortal?"
    GRC "¿Qué estabas haciendo, mortal?"

# game/chapters/5_day.rpyc:3001
translate es day05callcont_7176be62:

    # GRC "That much is obvious."
    GRC "Eso es obvio."

# game/chapters/5_day.rpyc:3008
translate es day05callcont_b4457aa3:

    # GRC "I meant before that. I apologize, I forgot I have to be awfully clear with you."
    GRC "Me refería a antes de eso. Lo siento, olvidé que tengo que ser muy claro contigo."

# game/chapters/5_day.rpyc:3016
translate es day05callcont_5d6dede3:

    # GRC "Don't make assumptions."
    GRC "No hagas suposiciones."

# game/chapters/5_day.rpyc:3026
translate es day05callcont_d1cec93b:

    # GRC "........."
    GRC "........."

# game/chapters/5_day.rpyc:3028
translate es day05callcont_03687051:

    # GRC "You are... just... utterly ridiculous."
    GRC "Eres... simplemente... completamente insoportable."

# game/chapters/5_day.rpyc:3031
translate es day05callcont_1f06712e:

    # GRC "Just answer the question."
    GRC "Solo responde la pregunta."

# game/chapters/5_day.rpyc:3041
translate es day05callcont_2c346477:

    # GRC "Well?"
    GRC "¿Bien?"

# game/chapters/5_day.rpyc:3046
translate es day05callcont_89f4d49a:

    # GRC "There wasn't fifty."
    GRC "No eran cincuenta."

# game/chapters/5_day.rpyc:3047
translate es day05callcont_dcaa7dfc:

    # GRC "It was nowhere near fifty."
    GRC "No se acercaba ni remotamente a cincuenta."

# game/chapters/5_day.rpyc:3048
translate es day05callcont_2db76682:

    # GRC "Are you that poor at counting?"
    GRC "¿Tan mal se te da contar?..."

# game/chapters/5_day.rpyc:3066
translate es day05callcont_4369c1cb:

    # GRC "...Maybe you do."
    GRC "...Quizás sí."

# game/chapters/5_day.rpyc:3072
translate es day05callcont_8045fcae:

    # GRC "You do?"
    GRC "¿En serio?"

# game/chapters/5_day.rpyc:3083
translate es day05callcont_11fb8ea7:

    # GRC "I see."
    GRC "ya veo."

# game/chapters/5_day.rpyc:3085
translate es day05callcont_a8e51577:

    # GRC "And your plans for later?"
    GRC "¿Y tus planes para más tarde?"

# game/chapters/5_day.rpyc:3088
translate es day05callcont_021558c8:

    # GRC "Interesting. You don't seem like the party type."
    GRC "Interesante. No pareces el tipo de persona a la que le gustan las fiestas."

# game/chapters/5_day.rpyc:3097
translate es day05callcont_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/5_day.rpyc:3099
translate es day05callcont_10f9d272:

    # GRC "You'd be a bad drunk."
    GRC "Sería un mal borracho."

# game/chapters/5_day.rpyc:3110
translate es day05callcont_4f38b5c0:

    # GRC "Hm. Very responsible of you, mortal."
    GRC "Hm. Muy responsable de tu parte, mortal."

# game/chapters/5_day.rpyc:3126
translate es day05callcont_e105a293:

    # GRC "Yes, well, mortals have a way of being irresponsible sometimes, Sunshine."
    GRC "Sí, bueno, los mortales a veces tienden a ser irresponsables, Solecito."

# game/chapters/5_day.rpyc:3127
translate es day05callcont_31a70b13:

    # GRC "A fault of humankind."
    GRC "Una falla de la humanidad."

# game/chapters/5_day.rpyc:3141
translate es day05callcont_550f1f54:

    # GRC "And will you?"
    GRC "¿Y lo harás?"

# game/chapters/5_day.rpyc:3174
translate es day05callcont_419b2b16:

    # GRC "So you won't be out too long?"
    GRC "¿Entonces no te vas a tardar mucho?"

# game/chapters/5_day.rpyc:3185
translate es day05callcont_932b6775:

    # GRC "I'd like to think that you will not."
    GRC "Me gustaría pensar que no lo harás."

# game/chapters/5_day.rpyc:3193
translate es day05callcont_145eea94:

    # GRC "Leave my legs out of this."
    GRC "Deja mis piernas fuera de esto."

# game/chapters/5_day.rpyc:3194
translate es day05callcont_d1be3c83:

    # GRC "I don't appreciate them being pulled."
    GRC "No me gusta que me tomen el pelo."

# game/chapters/5_day.rpyc:3205
translate es day05callcont_1bca3153:

    # GRC "I think I'm quite smart, actually."
    GRC "Creo que soy bastante inteligente, en realidad."

# game/chapters/5_day.rpyc:3206
translate es day05callcont_3593cd17:

    # GRC "Anyway."
    GRC "De todos modos."

# game/chapters/5_day.rpyc:3211
translate es day05callcont_fceab151:

    # GRC "Perfect."
    GRC "Perfecto."

# game/chapters/5_day.rpyc:3220
translate es day05callcont_90632ae8:

    # GRC "Do you think I sleep in this?"
    GRC "¿Crees que duermo con esto puesto?"

# game/chapters/5_day.rpyc:3228
translate es day05callcont_2709d833:

    # GRC "Of course I have pajamas."
    GRC "Por supuesto que tengo pijamas."

# game/chapters/5_day.rpyc:3229
translate es day05callcont_315f621c:

    # GRC "They are black, and very comfortable."
    GRC "Son negras y muy cómodas."

# game/chapters/5_day.rpyc:3239
translate es day05callcont_b9de0787:

    # GRC "Why do you care?"
    GRC "¿Por qué te importa?"

# game/chapters/5_day.rpyc:3255
translate es day05callcont_8da23161:

    # GRC "...."
    GRC "...."

# game/chapters/5_day.rpyc:3256
translate es day05callcont_8bd111a9:

    # GRC "It is a short sleeved shirt and shorts. Are you happy now?"
    GRC "Es una camiseta de manga corta y pantalones cortos. ¿Ya estás feliz?"

# game/chapters/5_day.rpyc:3263
translate es day05callcont_78183337:

    # GRC "What... about you?"
    GRC "¿Qué... pasa contigo?"

# game/chapters/5_day.rpyc:3278
translate es day05callcont_46a97c0b:

    # GRC "A... ah..."
    GRC "A... ah..."

# game/chapters/5_day.rpyc:3281
translate es day05callcont_a75dad48:

    # GRC "Well, this is... obviously useful information for my job, of course."
    GRC "Bueno, esto es... obviamente información útil para mi trabajo, por supuesto."

# game/chapters/5_day.rpyc:3282
translate es day05callcont_17aadd7e:

    # GRC "Yes. Uh huh."
    GRC "Sí. Uh huh."

# game/chapters/5_day.rpyc:3283
translate es day05callcont_ae8163bc:

    # GRC "Um. So you won't go anywhere tonight?"
    GRC "Um. ¿Entonces no vas a salir esta noche?"

# game/chapters/5_day.rpyc:3292
translate es day05callcont_441c59e3:

    # GRC "Good. This works for me."
    GRC "Bien. A mí me funciona."

# game/chapters/5_day.rpyc:3313
translate es chat2_day5_0877f0e7:

    # player "What the..."
    player "Qué demo..."

# game/chapters/5_day.rpyc:3314
translate es chat2_day5_972953e0:

    # GR "i hung up."
    GR "colgué."

# game/chapters/5_day.rpyc:3317
translate es chat2_day5_02844a96:

    # player "Yeah I know... but why?"
    player "Sí, lo sé... ¿pero por qué?"

# game/chapters/5_day.rpyc:3318
translate es chat2_day5_a11c5ec0:

    # GR "you'll find out soon enough."
    GR "lo descubrirás muy pronto."

# game/chapters/5_day.rpyc:3319
translate es chat2_day5_1b89bc9c:

    # GR "just wait."
    GR "solo espera."

# game/chapters/5_day.rpyc:3322
translate es chat2_day5_48ceb50b:

    # player "Wait?"
    player "¿Esperar?"

# game/chapters/5_day.rpyc:3323
translate es chat2_day5_9b04de98:

    # GR "i know you don't have that much patience, but yes."
    GR "sé que no tienes tanta paciencia, pero sí."

# game/chapters/5_day.rpyc:3324
translate es chat2_day5_5d420469:

    # GR "wait, mortal."
    GR "espera, mortal."

# game/chapters/5_day.rpyc:3327
translate es chat2_day5_7d76e81c:

    # player "Did it disconnect?"
    player "¿Se desconectó?"

# game/chapters/5_day.rpyc:3328
translate es chat2_day5_4fbd7bcb:

    # GR "no. i ended the call."
    GR "no. terminé la llamada."

# game/chapters/5_day.rpyc:3331
translate es chat2_day5_d9edb7af:

    # player "That was a little sudden."
    player "Eso fue un poco repentino."

# game/chapters/5_day.rpyc:3334
translate es chat2_day5_d99b4aed:

    # player "Is everything alright?"
    player "¿Está todo bien?"

# game/chapters/5_day.rpyc:3335
translate es chat2_day5_d79a3474:

    # GR "yes, everything is good."
    GR "sí, todo está bien."

# game/chapters/5_day.rpyc:3338
translate es chat2_day5_76d8525a:

    # player "Er..."
    player "Er..."

# game/chapters/5_day.rpyc:3340
translate es chat2_day5_97dfdc91:

    # player "You coulda said bye!"
    player "¡Podrías decir adiós!"

# game/chapters/5_day.rpyc:3341
translate es chat2_day5_989a6a22:

    # GR "wait."
    GR "espera."

# game/chapters/5_day.rpyc:3344
translate es chat2_day5_66a22e58:

    # player "For?"
    player "¿Para?"

# game/chapters/5_day.rpyc:3345
translate es chat2_day5_cb158aec:

    # GR "just wait. be patient for a bit."
    GR "solo espera. se paciente por un momento."

# game/chapters/5_day.rpyc:3348
translate es chat2_day5_6afe163c:

    # player "Oi Grim, what's going on?"
    player "Oye Parca, ¿qué está pasando?"

# game/chapters/5_day.rpyc:3351
translate es chat2_day5_728b8b3b:

    # player "Did you accidentally hang up?"
    player "¿Accidentalmente colgiste?"

# game/chapters/5_day.rpyc:3352
translate es chat2_day5_e07cfd2e:

    # GR "it was no accident."
    GR "no fue un accidente."

# game/chapters/5_day.rpyc:3355
translate es chat2_day5_870369f0:

    # player "Oh..."
    player "Oh..."

# game/chapters/5_day.rpyc:3356
translate es chat2_day5_cba03bfa:

    # GR "just hold on a minute."
    GR "solo espera un minuto."

# game/chapters/5_day.rpyc:3357
translate es chat2_day5_4e0aa35f:

    # GR "or a bit longer than that, maybe."
    GR "o un poco más que eso, tal vez."

# game/chapters/5_day.rpyc:3358
translate es chat2_day5_a5f8cbd0:

    # GR "just."
    GR "solo."

# game/chapters/5_day.rpyc:3359
translate es chat2_day5_989a6a22_1:

    # GR "wait."
    GR "espera."

# game/chapters/5_day.rpyc:3362
translate es chat2_day5_1b88eef7:

    # player "And what exactly am I waiting for?"
    player "¿Y qué espero exactamente?"

# game/chapters/5_day.rpyc:3363
translate es chat2_day5_1b89bc9c_1:

    # GR "just wait."
    GR "solo espera."

# game/chapters/5_day.rpyc:3366
translate es chat2_day5_06dfbc16:

    # player "No goodbyes today, Grim?"
    player "No hay despedidas hoy, ¿Parca?"

# game/chapters/5_day.rpyc:3367
translate es chat2_day5_4c4ed04a:

    # GR "it is not time for a goodbye yet."
    GR "no es hora de un adiós todavía."

# game/chapters/5_day.rpyc:3368
translate es chat2_day5_989a6a22_2:

    # GR "wait."
    GR "espera."

# game/chapters/5_day.rpyc:3371
translate es chat2_day5_65fad231:

    # player "Uhh, what exactly am I waiting for?"
    player "Uhh, ¿qué espero exactamente?"

# game/chapters/5_day.rpyc:3372
translate es chat2_day5_edce1986:

    # GR "just do as you're told."
    GR "solo haz lo que te dicen."

# game/chapters/5_day.rpyc:3375
translate es chat2_day5_77ab6df4:

    # player "And when have I ever done that?"
    player "¿Y cuándo he hecho eso?"

# game/chapters/5_day.rpyc:3376
translate es chat2_day5_47d50fd7:

    # GR "let's make this your first time, then."
    GR "hagamos que esta sea tu primera vez, entonces."

# game/chapters/5_day.rpyc:3379
translate es chat2_day5_03775ec8:

    # player "..."
    player "..."

# game/chapters/5_day.rpyc:3381
translate es chat2_day5_5e2602a8:

    # GR "good [girl]."
    GR "buen[girl!t]."

# game/chapters/5_day.rpyc:3382
translate es chat2_day5_222bc614:

    # GR "now just wait."
    GR "ahora solo espera."

# game/chapters/5_day.rpyc:3386
translate es chat2_day5_d70587ac:

    # player "Yes, sir..."
    player "Sí, señor..."

# game/chapters/5_day.rpyc:3388
translate es chat2_day5_4c77ee87:

    # player "Woof woof..."
    player "Guau guau..."

# game/chapters/5_day.rpyc:3391
translate es chat2_day5_785f1ebc:

    # player "I feel like a dog right now..."
    player "Me siento como un perro ahora mismo..."

# game/chapters/5_day.rpyc:3411
translate es chat2_day5_77348fa1:

    # "You step back from your computer - you're not sure what you're waiting for exactly, but you might as well hang out until he messages you again."
    "Te alejas de la computadora, sin saber muy bien qué estás esperando, pero decides quedarte ahí hasta que él te vuelva a enviar un mensaje."

# game/chapters/5_day.rpyc:3413
translate es chat2_day5_9583757f:

    # "You spend a little time with [pet_name] and check the moisture of your sprout."
    "Pasas un rato con [pet_name] y compruebas la humedad de tu retoño."

# game/chapters/5_day.rpyc:3415
translate es chat2_day5_75139ba4:

    # "You spend a little time with your pet and check the moisture of your sprout."
    "Pasas un rato con tu mascota y compruebas la humedad de tu retoño."

# game/chapters/5_day.rpyc:3416
translate es chat2_day5_237d1d76:

    # "Eventually, you can't find anything fun to do while you wait for Grim to get back in contact."
    "Al final, no encuentras nada divertido que hacer mientras esperas a que Parca se ponga en contacto contigo."

# game/chapters/5_day.rpyc:3417
translate es chat2_day5_0abcf85a:

    # "Honestly, it worries you a little just how dependent you've become on talking to him."
    "Sinceramente, te preocupa un poco lo dependiente que te has vuelto de hablar con él"

# game/chapters/5_day.rpyc:3418
translate es chat2_day5_f98ca6dc:

    # "You lie back on your bed, staring at the ceiling."
    "Te tumbas en la cama y te quedas mirando al techo."

# game/chapters/5_day.rpyc:3419
translate es chat2_day5_29a0461c:

    # "You only met him five days ago, but it feels like a lifetime you've known each other."
    "Solo hace cinco días que lo conociste, pero parece que lo conoces de toda la vida."

# game/chapters/5_day.rpyc:3420
translate es chat2_day5_ebc628a5:

    # "Putting aside the fact that he's the Grim Reaper, you've honestly never enjoyed someone's company as much as his."
    "Dejando a un lado el hecho de que es la Parca, sinceramente nunca has disfrutado tanto de la compañía de alguien como de la suya."

# game/chapters/5_day.rpyc:3421
translate es chat2_day5_0216a33e:

    # "It's a little confusing."
    "Es un poco confuso."

# game/chapters/5_day.rpyc:3422
translate es chat2_day5_9f6ed31a:

    # "You know full well what this strange feeling in your heart is, but you try to put it aside."
    "Sabes muy bien qué es ese extraño sentimiento que tienes en el corazón, pero intentas dejarlo a un lado."

# game/chapters/5_day.rpyc:3423
translate es chat2_day5_400ad18c:

    # "As fun as talking to him is, he's still the Grim Reaper."
    "Por muy divertido que sea hablar con él, sigue siendo la Parca"

# game/chapters/5_day.rpyc:3424
translate es chat2_day5_9a6fe9b9:

    # "You wander back over to your computer... it's been around thirty minutes now."
    "Vuelves a tu computadora... ya han pasado unos treinta minutos."

# game/chapters/5_day.rpyc:3425
translate es chat2_day5_ac3a5251:

    # "There's still nothing."
    "Sigue sin haber nada."

# game/chapters/5_day.rpyc:3426
translate es chat2_day5_bdd0272e:

    # "Disappointed, you go to turn away when you see an incoming call..."
    "Sientes decepción y te das la vuelta cuando ves que tienes una llamada entrante..."

# game/chapters/5_day.rpyc:3458
translate es call2_day5_c561e756:

    # GRC "Look up."
    GRC "Busca."

# game/chapters/5_day.rpyc:3482
translate es chat3_day5_a301715c:

    # "You look up from your computer, out towards the night sky."
    "Levantas la vista de tu computadora y miras hacia el cielo nocturno."

# game/chapters/5_day.rpyc:3487
translate es chat3_day5_706b9a16:

    # "And on the other side of your currently closed window, you see something so surprising you're sure you must be imagining it."
    "Y al otro lado de la ventana que ahora está cerrada, ves algo tan sorprendente que estás seguro de que debe ser tu imaginación."

# game/chapters/5_day.rpyc:3512
translate es chat3_day5_9b8f077e:

    # GRC "Now that face is priceless. Well worth the trip here, I have to say."
    GRC "Esa cara no tiene precio. Debo decir que ha merecido la pena el viaje hasta aquí."

# game/chapters/5_day.rpyc:3519
translate es chat3_day5_8a28656c:

    # GRC "Don't call me that to my face..."
    GRC "No me llames así en persona..."

# game/chapters/5_day.rpyc:3520
translate es chat3_day5_7537f196:

    # GRC "It's embarrassing enough hearing it over our calls."
    GRC "Ya es bastante vergonzoso escucharlo en nuestras llamadas."

# game/chapters/5_day.rpyc:3521
translate es chat3_day5_f1b94ea2:

    # GRC "Haaa..."
    GRC "Haaa..."

# game/chapters/5_day.rpyc:3522
translate es chat3_day5_723f6c21:

    # GRC "It's Casper. That's my real name."
    GRC "Es Casper. Ese es mi verdadero nombre."

# game/chapters/5_day.rpyc:3528
translate es chat3_day5_5ac4be6e:

    # GRC "Believe me, I know it's hilarious."
    GRC "Créeme, sé que es muy gracioso."

# game/chapters/5_day.rpyc:3529
translate es chat3_day5_66cfa924:

    # GRC "No need to dwell on it, I suppose."
    GRC "No hay necesidad de darle más vueltas, supongo."

# game/chapters/5_day.rpyc:3549
translate es chat3_day5_17357762:

    # GRC "Hello, Sunshine."
    GRC "Hola, Solecito."

# game/chapters/5_day.rpyc:3551
translate es chat3_day5_d84093d7:

    # GRC "You look like you've seen a ghost."
    GRC "Parece que hubieras visto un fantasma."

# game/chapters/5_day.rpyc:3559
translate es chat3_day5_bd475991:

    # GRC "I'm far from a ghost, Sunshine."
    GRC "Estoy lejos de ser un fantasma, Solecito."

# game/chapters/5_day.rpyc:3563
translate es chat3_day5_d22d8225:

    # GRC "Certain."
    GRC "Cierto."

# game/chapters/5_day.rpyc:3567
translate es chat3_day5_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/5_day.rpyc:3568
translate es chat3_day5_6fbe03f4:

    # GRC "No."
    GRC "No."

# game/chapters/5_day.rpyc:3569
translate es chat3_day5_c1dd0150:

    # GRC "I'll admit that you are, though."
    GRC "Sin embargo, admito que tú lo eres."

# game/chapters/5_day.rpyc:3573
translate es chat3_day5_bd475991_1:

    # GRC "I'm far from a ghost, Sunshine."
    GRC "Estoy lejos de ser un fantasma, Solecito."

# game/chapters/5_day.rpyc:3577
translate es chat3_day5_d22d8225_1:

    # GRC "Certain."
    GRC "Cierto."

# game/chapters/5_day.rpyc:3581
translate es chat3_day5_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/5_day.rpyc:3582
translate es chat3_day5_6fbe03f4_1:

    # GRC "No."
    GRC "No."

# game/chapters/5_day.rpyc:3583
translate es chat3_day5_fe3273d7:

    # GRC "I'll admit that you're... ahem... quite cute, though."
    GRC "Admito que eres... ejem... bastante adorable, sin embargo."

# game/chapters/5_day.rpyc:3587
translate es chat3_day5_bd475991_2:

    # GRC "I'm far from a ghost, Sunshine."
    GRC "Estoy lejos de ser un fantasma, Solecito."

# game/chapters/5_day.rpyc:3591
translate es chat3_day5_d22d8225_2:

    # GRC "Certain."
    GRC "Cierto."

# game/chapters/5_day.rpyc:3595
translate es chat3_day5_d7cc82d1:

    # GRC "That much is obvious. I am lovely to look at, after all."
    GRC "Eso es obvio. Después de todo, soy encantador a la vista."

# game/chapters/5_day.rpyc:3596
translate es chat3_day5_be3e5b44:

    # GRC "Perhaps not as lovely to look at as you, though..."
    GRC "Aunque quizá no sea tan adorable como tú..."

# game/chapters/5_day.rpyc:3604
translate es chat3_day5_368f0e8c:

    # GRC "Which you should know to be truthful."
    GRC "Lo cual deberías saber para ser sincero."

# game/chapters/5_day.rpyc:3605
translate es chat3_day5_dfe297da:

    # GRC "Because, as you know well, I cannot lie."
    GRC "Porque, como sabes bien, no puedo mentir."

# game/chapters/5_day.rpyc:3608
translate es chat3_day5_aedc37b5:

    # GRC "Ah, am I flustering you? You're blushing right now..."
    GRC "Ah, ¿te he hecho sentir nervios? Te estás sonrojando..."

# game/chapters/5_day.rpyc:3614
translate es chat3_day5_d9e183f3:

    # GRC "Ha. You look rather cute, don't you?"
    GRC "Ja. Te ves bastante adorable, ¿no?"

# game/chapters/5_day.rpyc:3618
translate es chat3_day5_798e2261:

    # GRC "Stop turning away. I'm trying to get a good look at you."
    GRC "Deja de apartar la vista. Estoy tratando de verte bien."

# game/chapters/5_day.rpyc:3629
translate es chat3_day5_4392c0a9:

    # GRC "Stop angling your face away."
    GRC "Deja de girar tu cara hacia otro lado."

# game/chapters/5_day.rpyc:3630
translate es chat3_day5_7b280d9d:

    # GRC "I'm trying to look at you."
    GRC "Estoy tratando de mirarte."

# game/chapters/5_day.rpyc:3641
translate es chat3_day5_a0f3dcba:

    # GRC "Are you trying to avoid my gaze right now?"
    GRC "¿Estás tratando de evitar mi mirada ahora mismo?"

# game/chapters/5_day.rpyc:3642
translate es chat3_day5_a632e9b8:

    # GRC "Stop hiding your face, I'm trying to look at you."
    GRC "Deja de esconder tu cara, estoy tratando de mirarte."

# game/chapters/5_day.rpyc:3648
translate es chat3_day5_bf4be486:

    # GRC "Why not? You are an attractive mortal, it's only right I tell you so."
    GRC "¿Por qué no? Eres un mortal atrayente, es justo que te lo diga."

# game/chapters/5_day.rpyc:3653
translate es chat3_day5_d241ca15:

    # GRC "You are those things."
    GRC "Eres esas cosas."

# game/chapters/5_day.rpyc:3654
translate es chat3_day5_cc1b31cd:

    # GRC "I... ahem... like all of that about you."
    GRC "Yo... ejem... me gusta todo eso de ti."

# game/chapters/5_day.rpyc:3667
translate es chat3_day5_9e78a1cd:

    # GRC "Yes, well, it's confusing me as well, trust me."
    GRC "Sí, bueno, a mí también me confunde, créeme."

# game/chapters/5_day.rpyc:3668
translate es chat3_day5_dc9cc126:

    # GRC "Seeing you like this... messes with my feelings and makes me say strange things."
    GRC "Verte así... me confunde y me hace decir cosas extrañas."

# game/chapters/5_day.rpyc:3669
translate es chat3_day5_ec2dfdde:

    # GRC "But, well, they're the truth, so..."
    GRC "Pero, bueno, son la verdad, así que..."

# game/chapters/5_day.rpyc:3674
translate es chat3_day5_8f2864ac:

    # GRC "There's no need to be shy, anyway."
    GRC "De todos modos, no hay por qué tener vergüenza."

# game/chapters/5_day.rpyc:3676
translate es chat3_day5_acf0f79f:

    # GRC "You are lovely. That is nothing to... be shy about."
    GRC "Eres [pretty!t]. No hay nada de qué... avergonzarse."

# game/chapters/5_day.rpyc:3679
translate es chat3_day5_4e55bca7:

    # GRC "You are cute. That is nothing to... be shy about."
    GRC "Eres adorable. No hay nada de qué... avergonzarse."

# game/chapters/5_day.rpyc:3682
translate es chat3_day5_df3ec9ea:

    # GRC "You are attractive. That is nothing to... be shy about."
    GRC "Eres [beautiful!t]. No hay nada de qué... avergonzarse."

# game/chapters/5_day.rpyc:3691
translate es chat3_day5_809ef1d2:

    # GRC "Nice to see you looking flustered for a change."
    GRC "Me alegra verte así, con nervios, para variar. "

# game/chapters/5_day.rpyc:3696
translate es chat3_day5_ca791944:

    # GRC "Casper."
    GRC "Casper."

# game/chapters/5_day.rpyc:3700
translate es chat3_day5_c3d56e8f:

    # GRC "Yes, mortal?"
    GRC "¿Si, mortal?"

# game/chapters/5_day.rpyc:3712
translate es chat3_day5_f5a175dd:

    # GRC "You do."
    GRC "Así es."

# game/chapters/5_day.rpyc:3713
translate es chat3_day5_263703aa:

    # GRC "Not too much of an inconvenience for me, luckily."
    GRC "Por suerte, no me supone un gran inconveniente"

# game/chapters/5_day.rpyc:3717
translate es chat3_day5_a4928e60:

    # GRC "I'm neither sitting nor standing."
    GRC "No estoy ni sentado ni de pie."

# game/chapters/5_day.rpyc:3721
translate es chat3_day5_c3dbd781:

    # GRC "Congratulations. Would you like an award?"
    GRC "Felicidades. ¿Te gustaría recibir un premio?"

# game/chapters/5_day.rpyc:3722
translate es chat3_day5_9389d0bd:

    # GRC "But you'll find I'm floating."
    GRC "Pero verás que estoy flotando."

# game/chapters/5_day.rpyc:3735
translate es chat3_day5_e7adc897:

    # GRC "Since always."
    GRC "Desde siempre."

# game/chapters/5_day.rpyc:3736
translate es chat3_day5_d2f627f6:

    # GRC "Why do you act so surprised?"
    GRC "¿Por qué te sorprendes tanto?"

# game/chapters/5_day.rpyc:3743
translate es chat3_day5_575eff93:

    # GRC "So being a Grim Reaper is fine and believable..."
    GRC "Así que ser la Parca está bien y es creíble..."

# game/chapters/5_day.rpyc:3744
translate es chat3_day5_2fcc0154:

    # GRC "But you draw the line at floating?"
    GRC "¿Pero no aceptas flotar?"

# game/chapters/5_day.rpyc:3751
translate es chat3_day5_d0f8ce0d:

    # GRC "Something like that. It's quite simple."
    GRC "Algo así. Es bastante simple."

# game/chapters/5_day.rpyc:3757
translate es chat3_day5_79143c89:

    # GRC "I don't think that's a good idea."
    GRC "No creo que sea una buena idea."

# game/chapters/5_day.rpyc:3758
translate es chat3_day5_7188b47c:

    # GRC "If something went wrong, it would be my fault."
    GRC "Si algo saliera mal, sería mi culpa."

# game/chapters/5_day.rpyc:3759
translate es chat3_day5_11f22856:

    # GRC "...and, of course, it would be breaking many rules..."
    GRC "...y, por supuesto, estaría rompiendo muchas reglas ..."

# game/chapters/5_day.rpyc:3763
translate es chat3_day5_c01a064b:

    # GRC "Maybe I'm just not fond of cleaning you up off the floor?"
    GRC "¿Quizás simplemente no me gustaría limpiarte del piso?"

# game/chapters/5_day.rpyc:3767
translate es chat3_day5_94d0cdd2:

    # GRC "No levitation lessons for you."
    GRC "No habrá clases de levitación para ti."

# game/chapters/5_day.rpyc:3777
translate es chat3_day5_20dc5bdf:

    # GRC "You think I would be so careless?"
    GRC "¿Crees que sería tan descuidado?"

# game/chapters/5_day.rpyc:3785
translate es chat3_day5_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/5_day.rpyc:3786
translate es chat3_day5_c5a8ccaf:

    # GRC "I've cast a glamour."
    GRC "He lanzado un hechizo."

# game/chapters/5_day.rpyc:3797
translate es chat3_day5_a0f9dc6e:

    # GRC "Invisible? No."
    GRC "¿Invisible? No."

# game/chapters/5_day.rpyc:3798
translate es chat3_day5_4ae69b8d:

    # GRC "I've taken another form to everyone's eyes but yours."
    GRC "He adoptado otra forma ante los ojos de todos menos ante los tuyos."

# game/chapters/5_day.rpyc:3802
translate es chat3_day5_8696720a:

    # GRC "If they were to look, they'd simply see a raven."
    GRC "Si miraran, solo verían un cuervo."

# game/chapters/5_day.rpyc:3805
translate es chat3_day5_b620a15e:

    # GRC "Not a good choice?"
    GRC "¿No es una buena opción?"

# game/chapters/5_day.rpyc:3811
translate es chat3_day5_f15687c2:

    # GRC "Why would I pick something overly cute?"
    GRC "¿Por qué elegiría algo demasiado lindo?"

# game/chapters/5_day.rpyc:3815
translate es chat3_day5_1bf8501b:

    # GRC "I shall keep it in mind for next time..."
    GRC "Lo tendré en cuenta para la próxima vez..."

# game/chapters/5_day.rpyc:3818
translate es chat3_day5_bd0bdb3f:

    # GRC "Why a bat?"
    GRC "¿Por qué un bate?"

# game/chapters/5_day.rpyc:3822
translate es chat3_day5_7c7ba5ff:

    # GRC "Well, that's true."
    GRC "Bueno, eso es cierto."

# game/chapters/5_day.rpyc:3823
translate es chat3_day5_c098cac9:

    # GRC "But it's leaning a little too 'vampirey'."
    GRC "Pero se inclina un poco demasiado hacia lo 'vampírico'."

# game/chapters/5_day.rpyc:3827
translate es chat3_day5_1fd16af6:

    # GRC "Exactly."
    GRC "Exactamente."

# game/chapters/5_day.rpyc:3831
translate es chat3_day5_d7ae7e2b:

    # GRC "Yes?"
    GRC "¿Sí?"

# game/chapters/5_day.rpyc:3835
translate es chat3_day5_db3756d9:

    # GRC "You think I didn't know where you lived?"
    GRC "¿Crees que no sabía dónde vivías?"

# game/chapters/5_day.rpyc:3839
translate es chat3_day5_a09703f3:

    # GRC "I know everything about you, Sunshine."
    GRC "Sé todo sobre ti, Solecito."

# game/chapters/5_day.rpyc:3850
translate es chat3_day5_98b2d5e8:

    # GRC "...No, I'm actually not here for that."
    GRC "...No, en realidad no estoy aquí para eso."

# game/chapters/5_day.rpyc:3854
translate es chat3_day5_79a9d206:

    # GRC "That's what I said."
    GRC "Eso es lo que dije."

# game/chapters/5_day.rpyc:3857
translate es chat3_day5_3fcce230:

    # GRC "The purpose for my visit is..."
    GRC "El motivo de mi visita es..."

# game/chapters/5_day.rpyc:3858
translate es chat3_day5_13a36a76:

    # GRC "Well..."
    GRC "Bien..."

# game/chapters/5_day.rpyc:3863
translate es chat3_day5_24ad7106:

    # GRC "It's not."
    GRC "No lo es."

# game/chapters/5_day.rpyc:3870
translate es chat3_day5_6fbe03f4_2:

    # GRC "No."
    GRC "No."

# game/chapters/5_day.rpyc:3873
translate es chat3_day5_84487837:

    # GRC "I'm here because..."
    GRC "Estoy aquí porque..."

# game/chapters/5_day.rpyc:3876
translate es chat3_day5_e19e0844:

    # GRC "Extremely sure."
    GRC "Totalmente seguro."

# game/chapters/5_day.rpyc:3881
translate es chat3_day5_4d8e7e1d:

    # GRC "I've come for something else entirely."
    GRC "He venido por otro motivo completamente distinto."

# game/chapters/5_day.rpyc:3884
translate es chat3_day5_870130fb:

    # GRC "I've come to..."
    GRC "He venido a..."

# game/chapters/5_day.rpyc:3885
translate es chat3_day5_4c57b897:

    # GRC "I've..."
    GRC "He..."

# game/chapters/5_day.rpyc:3896
translate es chat3_day5_116cf20d:

    # GRC "That... depends."
    GRC "Eso... depende"

# game/chapters/5_day.rpyc:3900
translate es chat3_day5_9383bd46:

    # GRC "Do you want to be whisked away?"
    GRC "¿Quieres que te lleve?"

# game/chapters/5_day.rpyc:3912
translate es chat3_day5_567e8d19:

    # GRC "Don't... tempt me."
    GRC "No... me tientes"

# game/chapters/5_day.rpyc:3913
translate es chat3_day5_cc9523f4:

    # GRC "There is something else I am here for today."
    GRC "Hay otra cosa por la que estoy aquí hoy."

# game/chapters/5_day.rpyc:3914
translate es chat3_day5_7131317e:

    # GRC "You see, Sunshine..."
    GRC "Verás, Solecito..."

# game/chapters/5_day.rpyc:3916
translate es chat3_day5_008afe10_3:

    # GRC "..."
    GRC "..."

# game/chapters/5_day.rpyc:3917
translate es chat3_day5_e0335646:

    # GRC "I have something... um. Something here. With me. Hidden."
    GRC "Tengo algo... eh... algo aquí. Conmigo. Escondido."

# game/chapters/5_day.rpyc:3918
translate es chat3_day5_1d532c36:

    # GRC "Something to give to you."
    GRC "Algo para darte."

# game/chapters/5_day.rpyc:3919
translate es chat3_day5_ce83dfe2:

    # GRC "Here."
    GRC "Aquí."

# game/chapters/5_day.rpyc:3929
translate es chat3_day5_ece2c373:

    # GRC "Is there anyone else here?"
    GRC "¿Hay alguien más aquí?"

# game/chapters/5_day.rpyc:3930
translate es chat3_day5_2f2f9d00:

    # GRC "Yes, you. Stupid mortal..."
    GRC "Sí, tú. Estúpido mortal..."

# game/chapters/5_day.rpyc:3932
translate es chat3_day5_55edfc30:

    # GRC "You... said you'd like some."
    GRC "Tú... dijiste que te gustaría algunas."

# game/chapters/5_day.rpyc:3938
translate es chat3_day5_c77148c3:

    # GRC "I didn't think to ask {i}what{/i} type of flowers you liked, so..."
    GRC "No se me ocurrió preguntarte {i}qué{/i} tipo de flores te gustaban, así que..."

# game/chapters/5_day.rpyc:3939
translate es chat3_day5_9b589497:

    # GRC "I picked ones that looked like you."
    GRC "Elegí las que se parecían a ti."

# game/chapters/5_day.rpyc:3940
translate es chat3_day5_3bda11d5:

    # GRC "The brightest... sunniest flowers I could find."
    GRC "Las flores más brillantes... más solares que pude encontrar."

# game/chapters/5_day.rpyc:3947
translate es chat3_day5_c3d56e8f_1:

    # GRC "Yes, mortal?"
    GRC "¿Si, mortal?"

# game/chapters/5_day.rpyc:3954
translate es chat3_day5_008afe10_4:

    # GRC "..."
    GRC "..."

# game/chapters/5_day.rpyc:3955
translate es chat3_day5_1060971f:

    # GRC "You know, if you want them you're going to have to open the window."
    GRC "Si las quieres, tendrás que abrir la ventana."

# game/chapters/5_day.rpyc:3961
translate es chat3_day5_1514bff0:

    # GRC "Are you inviting me in?"
    GRC "¿Me estás invitando?"

# game/chapters/5_day.rpyc:3962
translate es chat3_day5_0c865761:

    # GRC "I'll promise to {i}try{/i} and be good."
    GRC "Prometo {i}intentarlo{/i} y portarme bien."

# game/chapters/5_day.rpyc:3965
translate es chat3_day5_f39d3e02:

    # GRC "Not going to invite me in?"
    GRC "¿No me vas a invitar a pasar?"

# game/chapters/5_day.rpyc:3966
translate es chat3_day5_b49bd25a:

    # GRC "I'll try to be on my best behavior."
    GRC "Intentaré comportarme lo mejor posible."

# game/chapters/5_day.rpyc:3969
translate es chat3_day5_e89b0791:

    # GRC "There is some brain in that head of yours."
    GRC "Hay algo de cerebro en esa cabeza tuya."

# game/chapters/5_day.rpyc:3970
translate es chat3_day5_b1f99021:

    # GRC "If death's on your doorstop, best not to let him in."
    GRC "Si la muerte llama a tu puerta, mejor no la dejes entrar."

# game/chapters/5_day.rpyc:3974
translate es chat3_day5_8c2662a7:

    # GRC "Ah..."
    GRC "Ah..."

# game/chapters/5_day.rpyc:3975
translate es chat3_day5_38473314:

    # GRC "Though I am greatly.... pleased.... by the invitation..."
    GRC "Aunque estoy muy... complacido... por la invitación..."

# game/chapters/5_day.rpyc:3976
translate es chat3_day5_52765f1b:

    # GRC "Maybe next time, little human."
    GRC "Quizás la próxima vez, mortal."

# game/chapters/5_day.rpyc:3985
translate es chat3_day5_51aca21c:

    # GRC "Then I won't have to pretend now, will I?"
    GRC "Entonces ya no tendré que fingir, ¿verdad?"

# game/chapters/5_day.rpyc:3986
translate es chat3_day5_b3831cc0:

    # GRC "I'm sure the two of us can find something interesting to do."
    GRC "Estoy seguro de que los dos podemos encontrar algo interesante que hacer."

# game/chapters/5_day.rpyc:3997
translate es chat3_day5_4495c360:

    # GRC "Nothing separating us now, mortal."
    GRC "Ya nada nos separa, mortal."

# game/chapters/5_day.rpyc:4006
translate es chat3_day5_dcabc05e:

    # GRC "You wish I was, don't you?"
    GRC "Te gustaría que lo fuera, ¿verdad?"

# game/chapters/5_day.rpyc:4014
translate es chat3_day5_008afe10_5:

    # GRC "..."
    GRC "..."

# game/chapters/5_day.rpyc:4015
translate es chat3_day5_4becf17f:

    # GRC "Today I'm just here to give you these."
    GRC "Hoy estoy aquí para darte estas."

# game/chapters/5_day.rpyc:4016
translate es chat3_day5_d02755e0:

    # GRC "And maybe next time I'll... take you up on that offer."
    GRC "Y tal vez la próxima vez... acepte tu oferta."

# game/chapters/5_day.rpyc:4017
translate es chat3_day5_554fd98f:

    # GRC "As truly tempting as it is... I fear it may lead to regrets from both of us."
    GRC "Por muy tentador que sea... me temo que ambos nos arrepentiríamos."

# game/chapters/5_day.rpyc:4018
translate es chat3_day5_0a144720:

    # GRC "Next time, I... well... we'll see..."
    GRC "La próxima vez, yo... bueno... ya veremos..."

# game/chapters/5_day.rpyc:4019
translate es chat3_day5_35451f62:

    # GRC "With us, I feel anything could end up happening, my little human."
    GRC "Contigo, siento que cualquier cosa podría suceder, mi humano."

# game/chapters/5_day.rpyc:4022
translate es chat3_day5_20777195:

    # GRC "You're smarter than I give you credit for."
    GRC "Eres más inteligente de lo que yo pensaba."

# game/chapters/5_day.rpyc:4023
translate es chat3_day5_1037aa71:

    # GRC "But you really will have to open it at least a crack if you want these."
    GRC "Pero realmente tendrás que abrirlo al menos un poco si los quieres."

# game/chapters/5_day.rpyc:4028
translate es chat3_day5_a72fb90d:

    # GRC "I'm not going to just barge into your room uninvited, Sunshine."
    GRC "No voy a entrar en tu habitación sin que me invites, Solecito."

# game/chapters/5_day.rpyc:4029
translate es chat3_day5_a5553eda:

    # GRC "I'm trying to be a gentleman here."
    GRC "Estoy tratando de ser un caballero aquí."

# game/chapters/5_day.rpyc:4030
translate es chat3_day5_6a709566:

    # GRC "So, if you could just open up a little for me..."
    GRC "Así que, si pudieras abrirla un poco para mí..."

# game/chapters/5_day.rpyc:4035
translate es chat3_day5_1549a279:

    # GRC "There we go."
    GRC "Ahí vamos."

# game/chapters/5_day.rpyc:4036
translate es chat3_day5_f8c20d52:

    # GRC "Don't you worry your lovely little head."
    GRC "No te rompas la cabeza, cariño."

# game/chapters/5_day.rpyc:4037
translate es chat3_day5_a1312dc3:

    # GRC "I'm only going to stick my hand through."
    GRC "Solo voy a meter la mano."

# game/chapters/5_day.rpyc:4042
translate es chat3_day5_37a736d6:

    # GRC "Aren't you a brave thing?"
    GRC "¿No eres muy valiente?"

# game/chapters/5_day.rpyc:4046
translate es chat3_day5_6f60773e:

    # GRC "I can see that."
    GRC "Puedo ver eso."

# game/chapters/5_day.rpyc:4050
translate es cg1notdlc_1037aa71:

    # GRC "But you really will have to open it at least a crack if you want these."
    GRC "Pero realmente tendrás que abrirlo al menos un poco si los quieres."

# game/chapters/5_day.rpyc:4055
translate es cg1notdlc_1549a279:

    # GRC "There we go."
    GRC "Ahí vamos."

# game/chapters/5_day.rpyc:4056
translate es cg1notdlc_4da65176:

    # GRC "You're quite the risk taker, aren't you?"
    GRC "Te gusta mucho correr riesgos, ¿verdad?"

# game/chapters/5_day.rpyc:4060
translate es cg1notdlc_0e99a605:

    # GRC "I'm simply making an observation."
    GRC "Simplemente estoy haciendo una observación."

# game/chapters/5_day.rpyc:4061
translate es cg1notdlc_53f634df:

    # GRC "What fun would life be if we weren't taking at least a few risks, hmm?"
    GRC "¿Qué gracia tendría la vida si no corriéramos al menos algunos riesgos, eh?"

# game/chapters/5_day.rpyc:4064
translate es cg1notdlc_973705e4:

    # GRC "Scared?"
    GRC "¿Tienes miedo?"

# game/chapters/5_day.rpyc:4073
translate es cg1notdlc_ed06192e:

    # GRC "They're just flowers."
    GRC "Son solo flores."

# game/chapters/5_day.rpyc:4081
translate es cg1notdlc_2c2b9180:

    # GRC "C'mon, Sunshine."
    GRC "Vamos, Solecito."

# game/chapters/5_day.rpyc:4087
translate es cg1notdlc_9f327427:

    # GRC "You tease me even now.."
    GRC "Me molestas incluso ahora.."

# game/chapters/5_day.rpyc:4097
translate es cgflowergive_d4cbc4ed:

    # GRC "Here you go, Sunshine."
    GRC "Aquí tienes, Solecito."

# game/chapters/5_day.rpyc:4103
translate es cgflowergive_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/5_day.rpyc:4104
translate es cgflowergive_8971aea6:

    # GRC "Your hands are really warm."
    GRC "Tus manos son realmente cálidas."

# game/chapters/5_day.rpyc:4112
translate es cgflowergive_3ccab8c3:

    # GRC "How can hands be pretty?"
    GRC "¿Cómo pueden ser bonitas las manos?"

# game/chapters/5_day.rpyc:4120
translate es cgflowergive_6e7426d6:

    # GRC "Then I'd say your hands are also... very... um, nice."
    GRC "Entonces diría que tus manos también son... muy... eh, bonitas."

# game/chapters/5_day.rpyc:4121
translate es cgflowergive_61d78d6b:

    # GRC "{size=20}Who would've thought hands could be so... alluring.{/size}"
    GRC "{size=20}¿Quién hubiera pensado que las manos podían ser tan... seductoras?{/size}"

# game/chapters/5_day.rpyc:4126
translate es cgflowergive_145f5fc5:

    # GRC "I really must be... on my way."
    GRC "Realmente debo... ponerme en camino."

# game/chapters/5_day.rpyc:4127
translate es cgflowergive_fd3bf944:

    # GRC "I've accomplished the thing I wanted to do."
    GRC "He logrado lo que quería hacer."

# game/chapters/5_day.rpyc:4131
translate es cgflowergive_4e04c6bc:

    # GRC "Duty always calls."
    GRC "El deber siempre llama."

# game/chapters/5_day.rpyc:4135
translate es cgflowergive_6a5abaa0:

    # GRC "Better theirs than yours, wouldn't you say?"
    GRC "Mejor que sea de ellos que de tú, ¿no crees?"

# game/chapters/5_day.rpyc:4139
translate es cgflowergive_80a3280b:

    # GRC "No? You can just hand over yours now, if you want."
    GRC "¿No? Si quieres, puedes entregarla ahora mismo."

# game/chapters/5_day.rpyc:4144
translate es cgflowergive_57ea7ad7:

    # GRC "And since when am I yours?"
    GRC "¿Y desde cuándo soy tuyo?"

# game/chapters/5_day.rpyc:4160
translate es cgflowergive_4f4a2da6:

    # GRC "So demanding."
    GRC "Tan exigente."

# game/chapters/5_day.rpyc:4165
translate es cgflowergive_1dc1b57f:

    # GRC "Sunshine."
    GRC "Solecito."

# game/chapters/5_day.rpyc:4170
translate es cgflowergive_d0b415fb:

    # GRC "Since you asked so nicely, I'll try my best."
    GRC "Ya que lo pides tan amablemente, haré todo lo posible."

# game/chapters/5_day.rpyc:4171
translate es cgflowergive_59623694:

    # GRC "Don't forget to close that window after I leave."
    GRC "No olvides cerrar esa ventana después de que me vaya."

# game/chapters/5_day.rpyc:4172
translate es cgflowergive_a6f6147a:

    # GRC "Wouldn't want anyone crawling in when you aren't looking."
    GRC "No quisieras que alguien se colara cuando no estás mirando."
    
    
translate es strings:

    old "1. <Woah okay, wall of text.>"
    new "1. <Woah okey, mucho texto.>"

    old "1. <Not that I'm surprised.>"
    new "1. <No es que me sorprenda.>"

    old "1. <Considering I'm so kind, and friendly, and caring.>"
    new "1. <Teniendo en cuenta que soy tan gentil, amable y servicial.>"

    old "1. <Charismatic, too.>"
    new "1. <Con carisma, también.>"

    old "1. <Someone's gotta toot it for me.>"
    new "1. <Alguien tiene que hacerlo por mí.>"

    old "1. <Anyway, let me read all of this.>"
    new "1. <De todos modos, déjame leer todo eso.>"

    old "1. <Are we playing 20 questions or something?>"
    new "1. <¿Estamos jugando a las 20 preguntas o algo así?>"

    old "1. <Technically there are 8 questions there.>"
    new "1. <Técnicamente hay 8 preguntas ahí.>"

    old "1. <Don't you want to know what took me so long?>"
    new "1. <¿No quieres saber por qué tardé tanto?>"

    old "1. <Sorry to answer it, but yes your approach is wrong (as always).>"
    new "1. <Siento responderte, pero sí, tu enfoque es erróneo (como siempre).>"

    old "1. <Fine, I'll work down the list.>"
    new "1. <Está bien, revisaré la lista.>"

    old "1. <My favorite 'mortal' color...>"
    new "1. <Mi 'mortal' color favorito...>"

    old "1. <Probably [day5_favoritecolor] then.>"
    new "1. <Probablemente sea [day5_favoritecolor].>"

    old "1. <Summer.>"
    new "1. <Verano.>"

    old "1. <I much prefer warmer weather.>"
    new "1. <Prefiero mucho más el clima cálido.>"

    old "1. <The cold and I are {i}not{/i} friends.>"
    new "1. <El frío y yo {i}no{/i} somos amigos.>"

    old "1. <Not at all, do you?>"
    new "1. <En absoluto, ¿verdad?>"

    old "1. <My nemesis, you could say.>"
    new "1. <Mi némesis, se podría decir.>"

    old "1. <Absolutely despise it. You?>"
    new "1. <Lo detesto por completo. ¿Y tú?>"

    old "1. <You're more into Fall or Spring then, maybe?>"
    new "1. <¿Entonces te gusta más el otoño o la primavera?>"

    old "1. <The good thing about Summer is less clothes ;)>"
    new "1. <Lo bueno del verano es que se lleva menos ropa ;)>"

    old "1. <Since it's so hot, you wouldn't wanna get all sweaty.>"
    new "1. <Como hace tanto calor, no te gustaría acabar sudando.>"

    old "1. <You get me?>"
    new "1. <¿Me entiendes?>"

    old "1. <I wouldn't say no to that.>"
    new "1. <No diría que no a eso.>"

    old "1. <Would you prefer I call out for you?>"
    new "1. <¿Preferirías que te llame?>"

    old "1. <We'll see about that ;)>"
    new "1. <Ya lo veremos ;)>"

    old "1. <Have you not seen yourself?>"
    new "1. <¿No te has visto?>"

    old "1. <You've definitely got abs, right?>"
    new "1. <Definitivamente tienes abdominales, ¿verdad?>"

    old "1. <Oh? Why?>"
    new "1. <¿Oh? ¿Por qué?>"

    old "1. <Not too hot, not too cold.>"
    new "1. <Ni muy caliente, ni muy frío.>"

    old "1. <And the ground looks very pretty with all of the leaves.>"
    new "1. <Y el suelo se ve muy bonito con todas las hojas.>"

    old "1. <Yeah, I guess so. It's a comfortable season.>"
    new "1. <Sí, supongo que sí. Es una estación agradable.>"

    old "1. <Warm jumpers, hot chocolate and books :)>"
    new "1. <Suéteres cálidos, chocolate caliente y libros :)>"

    old "1. <You feel me?>"
    new "1. <¿Me entiendes?>"

    old "1. <Why, do you want to?>"
    new "1. <¿Por qué, te gustaría?>"

    old "1. <I bet you thought of touching my hand or hugging me once or twice before.>"
    new "1. <Apuesto a que has pensado en tocarme la mano o abrazarme alguna vez.>"

    old "1. <Um. Yeah.>"
    new "1. <Um. Sí.>"

    old "1. <I might even say please.>"
    new "1. <Incluso podría decir por favor.>"

    old "1. <I like the cold weather.>"
    new "1. <Me gusta el clima frío.>"

    old "1. <And winter fashion is really quite nice.>"
    new "1. <Y la moda de invierno es realmente muy bonita.>"

    old "1. <Plus it's great weather to snuggle in.>"
    new "1. <Además, es un buen clima para abrasarse.>"

    old "1. <You seem like you'd be good for snuggling.>"
    new "1. <Pareces alguien con quien se puede estar bien abrazado.>"

    old "1. <Yeah, you down?>"
    new "1. <Sí, ¿te apuntas?>"

    old "1. <Skin to skin contact helps conserve heat, and all that.>"
    new "1. <El contacto piel con piel ayuda a conservar el calor y todo eso.>"

    old "1. <We should test it out. For science.>"
    new "1. <Deberíamos probarlo. Por ciencia.>"

    old "1. <Then how about just for fun?>"
    new "1. <Entonces, ¿qué tal solo por diversión?>"

    old "1. <Warmer weather, and all of those pretty flowers...>"
    new "1. <Clima más cálido y todas esas bonitas flores...>"

    old "1. <It really is the best time of the year.>"
    new "1. <Realmente es la mejor época del año.>"

    old "1. <I've always wanted to do a Spring photoshoot with flowers or something.>"
    new "1. <Siempre quise hacer una sesión de fotos de primavera con flores o algo.>"

    old "1. <If you wanted to, you could join me. You, me, and the flowers :)>"
    new "1. <Si quisieras, podrías unirte a mí. Tú, yo, y las flores :)>"

    old "1. <That's {i}not{/i} what I meant...>"
    new "1. <Eso {i}no{/i} es lo que quería decir...>"

    old "1. <But I'm down for being a little scandalous.>"
    new "1. <Pero no me importa que sea un poco escandalosa.>"

    old "1. <How about I take the photos, and you pose?>"
    new "1. <¿Qué tal si yo hago las fotos y tú posas?>"

    old "1. <I feel like red flowers would look nice in your hair.>"
    new "1. <Creo que unas flores rojas te quedarían muy bien en el cabello.>"

    old "1. <And against your skin.>"
    new "1. <Y contra tu piel.>"

    old "1. <Why, do you want me to?>"
    new "1. <¿Por qué, quieres que lo haga?>"

    old "1. <I'm actually a little lost for words.>"
    new "1. <La verdad es que no sé qué decir.>"

    old "1. <You're... very forward today.>"
    new "1. <Hoy estás... muy atrevido.>"

    old "1. <Not that I mind! Like at all!>"
    new "1. <¡No es que me importe! ¡En absoluto!>"

    old "1. <In fact, I quite like it.>"
    new "1. <De hecho, me gusta bastante.>"

    old "1. <But, uh... is that meant to be flirting?>"
    new "1. <Pero, eh... ¿eso se supone que es coquetear?>"

    old "1. <Wow, you're really wooing me right now.>"
    new "1. <Wow, realmente me estás seduciendo en este momento.>"

    old "1. <You're acting very weird.>"
    new "1. <Estás actuando muy raro.>"

    old "1. <Where is my grumpy Grim gone?>"
    new "1. <¿Dónde se ha ido mi Parca gruñóna?>"

    old "1. <And so... now you've decided to strangely flirt with me?>"
    new "1. <Y entonces... ¿ahora has decidido coquetear conmigo de forma extraña?>"

    old "1. <Then what are you doing?>"
    new "1. <Entonces, ¿qué estás haciendo?>"

    old "1. <Want to meet the in-laws, Grim?>"
    new "1. <¿Quieres conocer a tus suegros, Parca?>"

    old "1. <Should we get married, then?>"
    new "1. <¿Deberíamos casarnos, entonces?>"

    old "1. <Fine, fine.>"
    new "1. <Bien, bien.>"

    old "1. <Maybe later then.>"
    new "1. <Tal vez más tarde entonces.>"

    old "1. <What did you wanna know about them?>"
    new "1. <¿Qué querías saber sobre ellos?>"

    old "1. <They are 100 percent worse.>"
    new "1. <Son 100 por ciento peores.>"

    old "1. <Just a fair warning.>"
    new "1. <Solo una advertencia.>"

    old "1. <Compared to me, you'd be able to deal with them easily.>"
    new "1. <En comparación a mí, podrías lidiar con ellos fácilmente.>"

    old "1. <Can we maybe skip this question...?>"
    new "1. <¿Podemos saltar esa pregunta...?>"

    old "1. <Thank you, Grim.>"
    new "1. <Gracias, Parca.>"

    old "1. <Let's skip to the next question.>"
    new "1. <Pasemos a la siguiente pregunta.>"

    old "1. <Yeah, thanks Grim.>"
    new "1. <Sí, gracias Parca.>"

    old "1. <Of course I do.>"
    new "1. <Por supuesto que sí.>"

    old "1. <I see them pretty often. We're close.>"
    new "1. <Los veo bastante seguido. Somos muy unidos.>"

    old "1. <Some of them live in this same building.>"
    new "1. <Algunos de ellos viven en este mismo edificio.>"

    old "1. <Kinda hard to not see them, actually.>"
    new "1. <La verdad, es difícil no verlos.>"

    old "1. <You wouldn't like living with your family?>"
    new "1. <¿No te gustaría vivir con tu familia?>"

    old "1. <That's fair.>"
    new "1. <Tienes razón.>"

    old "1. <I was thinking about moving at some point.>"
    new "1. <Estaba pensando en mudarme en algún momento.>"

    old "1. <Living somewhere a little more solitary.>"
    new "1. <Vivir en un lugar un poco más solitario.>"

    old "1. <I love my family, but I agree it can be exhausting.>"
    new "1. <Amo a mi familia, pero estoy de acuerdo en que puede ser agotador.>"

    old "1. <Decorating a whole house myself will also be nice.>"
    new "1. <Decorar toda la casa por mi cuenta también será agradable.>"

    old "1. <I like my apartment, but I could use some more space.>"
    new "1. <Me gusta mi apartamento, pero me vendría bien un poco más de espacio.>"

    old "1. <But I am a little worried that I'd get kinda lonely after awhile.>"
    new "1. <Pero me preocupa un poco volverme una persona solitaria después de un tiempo.>"

    old "1. <Maybe you could just come move in with me, huh?>"
    new "1. <¿Quizás podrías venir a vivir conmigo, huh?>"

    old "1. <Yes you. Who else would I ask?>"
    new "1. <Si tu. ¿A quién más le preguntaría?>"

    old "1. <We'll have to merge our aesthetics somehow, but I'm sure we can figure that out.>"
    new "1. <Tendremos que combinar nuestras estéticas de alguna manera, pero lo conseguiremos.>"

    old "1. <I'm so used to having people around me.>"
    new "1. <Tengo tanta costumbre de tener gente a mi alrededor.>"

    old "1. <So if I ever moved out, it would have to be with someone else.>"
    new "1. <Así que si alguna vez me mudara, tendría que ser con otra persona.>"

    old "1. <Everyone is scared of something.>"
    new "1. <Todos tienen miedo de algo.>"

    old "1. <It's just one of those things you can't control.>"
    new "1. <Es solo una de esas cosas que no puedes controlar.>"

    old "1. <I won't ever get lonely if I'm with you.>"
    new "1. <Nunca me sentiré en soledad si estoy contigo.>"

    old "1. <Everyday.>"
    new "1. <Cada día.>"

    old "1. <For the rest of forever.>"
    new "1. <Por el resto de la eternidad.>"

    old "1. <So we catch up when we can.>"
    new "1. <Así que nos ponemos al día cuando podemos.>"

    old "1. <I do, actually.>"
    new "1. <La verdad es que sí.>"

    old "1. <I'm really close with my family.>"
    new "1. <Tengo una relación muy estrecha con mi familia.>"

    old "1. <I don't, really.>"
    new "1. <La verdad es que no.>"

    old "1. <I love them, but I like having space to myself.>"
    new "1. <Los amo, pero me gusta tener espacio para mí.>"

    old "1. <I've been considering moving for awhile, so I can have some more space.>"
    new "1. <He estado pensando en mudarme desde hace tiempo, para tener más espacio.>"

    old "1. <I like decorating. I want to decorate a whole house.>"
    new "1. <Me gusta decorar. Quiero decorar una casa entera.>"

    old "1. <Hey, you can come share a place with me.>"
    new "1. <Oye, puedes venir a compartir casa conmigo.>"

    old "1. <I don't need an entire house to myself.>"
    new "1. <No necesito una casa entera para mí.>"

    old "1. <Hopefully that'll change.>"
    new "1. <Ojalá eso cambie.>"

    old "1. <It's a bit lonely being without them.>"
    new "1. <Es un poco solitario estar sin ellos.>"

    old "1. <I knew it would happen, but I'm still a little sad.>"
    new "1. <Sabía que sucedería, pero todavía estoy un poco triste.>"

    old "1. <I'm hoping I'll see them again soon.>"
    new "1. <Espero volver a verlos pronto.>"

    old "1. <I moved for school, then stayed.>"
    new "1. <Me mudé por estudios y luego me quedé.>"

    old "1. <I'd like to get a house at some point, but I think I'd have to move even further away.>"
    new "1. <Me gustaría conseguir una casa en algún momento, pero creo que tendría que alejarme aún más.>"

    old "1. <Double as lonely!>"
    new "1. <¡El doble de soledad!>"

    old "1. <Oh, I know. You could just move in with me!>"
    new "1. <Oh, ya sé. ¡Podrías mudarte conmigo!>"

    old "1. <No.>"
    new "1. <No.>"

    old "1. <It's fine, I don't mind talking about it.>"
    new "1. <Está bien, no me importa hablar de eso.>"

    old "1. <It's been just me for awhile.>"
    new "1. <He sido solo yo durante un tiempo.>"

    old "1. <It's been hard, because I was very close with them.>"
    new "1. <Ha sido difícil, porque les tenía mucho cariño.>"

    old "1. <Pretty much.>"
    new "1. <Más o menos.>"

    old "1. <I don't mind it, but it's a little lonely.>"
    new "1. <No me molesta, pero es un poco solitario.>"

    old "1. <I much prefer being around more people.>"
    new "1. <Prefiero estar cerca de más personas.>"

    old "1. <You could just come join me, of course.>"
    new "1. <Por supuesto, puedes venir conmigo.>"

    old "1. <That surprised me.>"
    new "1. <Eso me sorprendió.>"

    old "1. <Thanks.>"
    new "1. <Gracias.>"

    old "1. <I like the color.>"
    new "1. <Me gusta ese color.>"

    old "1. <And why did you pick your wall color, Mr Reaper?>"
    new "1. <¿Y por qué eligió el color de su pared, Sr. Parca?>"

    old "1. <I kinda grew to like it, though.>"
    new "1. <Sin embargo, con el tiempo me empezó a gustar.>"

    old "1. <Why, do you not like the color of my walls?>"
    new "1. <¿Por qué? ¿No te gusta el color de mis paredes?>"

    old "1. <Well, if we ever live together I'm going to pick the color scheme.>"
    new "1. <Bueno, si alguna vez vivimos juntos, yo elegiré la combinación de colores.>"

    old "1. <I said {i}if{/i}.>"
    new "1. <Dije '{i}si alguna vez{/i}'.>"

    old "1. <You never know what'll happen in the future.>"
    new "1. <Nunca se sabe lo que sucederá en el futuro.>"

    old "1. <Do you hog the sheets?>"
    new "1. <¿Acaparas las sábanas?>"

    old "1. <Snore super loud?>"
    new "1. <¿Roncas super fuerte?>"

    old "1. <How do you know?>"
    new "1. <¿Cómo lo sabes?>"

    old "1. <Unless someone's there to tell you?>"
    new "1. <¿A menos que haya alguien ahí para decírtelo?>"

    old "1. <{i}'O Grim we cannot be! You steal all the blankets and I was chilled to the bone!'{/i}>"
    new "1. <{i}'¡No puedo ser Parca! ¡Me robas todas las cobijas y me quedo helado hasta los huesos!'{/i}>"

    old "1. <{i}'And you snored so loudly I could not hear my own thoughts!'{/i}>"
    new "1. <{i}'¡Y roncabas tan fuerte que no podía escuchar mis propios pensamientos!'{/i}>"

    old "1. <So there's no way for me to convince you?>"
    new "1. <¿Entonces no hay forma de que te convenza?>"

    old "1. <Okay. That is a totally reasonable point to make.>"
    new "1. <Bueno. Ese es un punto totalmente razonable.>"

    old "1. <Very fair.>"
    new "1. <Muy acertado.>"

    old "1. <But once this week is over, I'll own {i}your{/i} soul.>"
    new "1. <Pero una vez que termine esta semana, {i}tu{/i} alma me pertenecerá.>"

    old "1. <Then we can revisit this.>"
    new "1. <Entonces podemos volver a hablar de esto.>"

    old "1. <Back tracking a few steps then.>"
    new "1. <Retrocedamos unos pasos entonces.>"

    old "1. <My family...>"
    new "1. <Mi familia...>"

    old "1. <I've got my Mom and Dad.>"
    new "1. <Tengo a mi mamá y a mi papá.>"

    old "1. <She's very strong and capable. I admire her.>"
    new "1. <Ella es muy fuerte y capaz. La admiro.>"

    old "1. <I can't imagine the stress of raising a child alone.>"
    new "1. <No puedo imaginar el estrés de criar a un bebé sola.>"

    old "1. <I'll always be thankful to her.>"
    new "1. <Siempre estaré en deuda con ella.>"

    old "1. <It must've been tough, considering I'm her kid.>"
    new "1. <Debió de ser difícil, teniendo en cuenta que soy su retoño.>"

    old "1. <I was an absolute demon.>"
    new "1. <Yo era un demonio absoluto.>"

    old "1. <I wouldn't have changed what we had for the world, though.>"
    new "1. <Sin embargo, no habría cambiado lo que teníamos por nada del mundo.>"

    old "1. <And he did a brilliant job, if I can say so myself.>"
    new "1. <E hizo un trabajo brillante, si puedo decirlo yo.>"

    old "1. <I think people usually assume a single parent would usually be the mother.>"
    new "1. <Creo que la gente suele asumir que un solo padre generalmente sería la madre.>"

    old "1. <But my Dad is awesome :D>"
    new "1. <Pero mi papá es increíble :D>"

    old "1. <It must've been tough, considering I'm his kid.>"
    new "1. <Debe haber sido difícil, considerando que soy su retoño.>"

    old "1. <Yep! She's amazing!>"
    new "1. <¡Síp! ¡Ella es increíble!>"

    old "1. <She's a few years older than me.>"
    new "1. <Ella es unos años mayor que yo.>"

    old "1. <I've just always been closer to her, you know?>"
    new "1. <Siempre he tenido más confianza con ella, ¿sabes?>"

    old "1. <If I needed anything I would go to her.>"
    new "1. <Si necesitaba algo, acudía a ella.>"

    old "1. <And she would always be there for me.>"
    new "1. <Y ella siempre estaría allí para mí.>"

    old "1. <No matter what I needed, always.>"
    new "1. <No importaba lo que necesitara, siempre.>"

    old "1. <I was with her all throughout my childhood.>"
    new "1. <Estuve con ella durante toda mi infancia.>"



    old "1. <He's a few years older than me.>"
    new "1. <Es unos años mayor que yo.>"

    old "1. <I've just always been closer to him, you know?>"
    new "1. <Siempre he tenido más confianza con él, ¿sabes?>"

    old "1. <If I ever needed anything I would go to him.>"
    new "1. <Si alguna vez necesitaba algo, acudía a él.>"

    old "1. <And he would always be there for me.>"
    new "1. <Y él siempre estaría allí para mí.>"

    old "1. <I was with him all throughout my childhood.>"
    new "1. <Estuve con él durante toda mi infancia.>"

    old "1. <I had the biggest cheerleader in the world behind my back :)>"
    new "1. <Tenía a mi fan número uno en el mundo apoyándome :)>"

    old "1. <They're a few years older than me.>"
    new "1. <Es unos años mayor que yo.>"

    old "1. <I've just always been closer to my sibling, you know?>"
    new "1. <Siempre he tenido más confianza con mi hermane, ¿sabes?>"

    old "1. <If I ever needed anything I would go to them.>"
    new "1. <Si alguna vez necesitara algo, acudiría a elle.>"

    old "1. <And they would always be there for me.>"
    new "1. <Y siempre estaría allí para mí.>"

    old "1. <I was with them all throughout my childhood.>"
    new "1. <Estuve con elle durante toda mi infancia.>"

    old "1. <Very much so, yes.>"
    new "1. <Sí, mucho.>"

    old "1. <You don't have any siblings?>"
    new "1. <¿No tienes hermanos?>"

    old "1. <And they raised me together.>"
    new "1. <Y me criaron.>"

    old "1. <Apparently it was love at first sight for them.>"
    new "1. <Al parecer, fue amor a primera vista.>"

    old "1. <The moment their eyes met they were drawn to one another.>"
    new "1. <En el momento en que sus miradas se cruzaron, sintieron una atracción mutua.>"

    old "1. <They told me it was fate.>"
    new "1. <Me dijeron que era el destino.>"

    old "1. <...Wait, so soul mates are an actual thing?>"
    new "1. <... Espera, ¿entonces las almas gemelas existen de verdad?>"

    old "1. <How do you know if you find them :o ?>"
    new "1. <¿Cómo sabes si la encuentras :o ?>"

    old "1. <Do I have one?>"
    new "1. <¿Tengo una?>"

    old "1. <Well, you seem quite interested in my soul.>"
    new "1. <Bueno, pareces bastante interesado en mi alma.>"

    old "1. <Wait, if someone else is my soul mate...>"
    new "1. <Espera, si alguien más es mi alma gemela...>"

    old "1. <They might take offense at you being so keen for my soul.>"
    new "1. <Podría ofenderse de que estés tan interesado en mi alma.>"

    old "1. <Wouldn't dream of it.>"
    new "1. <Ni se me ocurriría.>"

    old "1. <So there's no actual rule saying we can't be soul mates, then.>"
    new "1. <Entonces, no existe ninguna regla que diga que no podemos ser almas gemelas.>"

    old "1. <I could be a Grim Reaper in disguise.>"
    new "1. <Podría ser una Parca disfrazada.>"

    old "1. <Probably not.>"
    new "1. <Probablemente no.>"

    old "1. <You were the one flirting before.>"
    new "1. <Tú fuiste quien coqueteó antes.>"

    old "1. <Sure it was.>"
    new "1. <Seguro que lo era.>"

    old "1. <I think you might just have a thing for me :D>"
    new "1. <Creo que tal vez sientes algo por mí :D>"

    old "1. <I love you too.>"
    new "1. <Yo también te amo.>"

    old "1. <A couple of incredibly smart yet stupid geniuses.>"
    new "1. <Una pareja de cerebros increíblemente inteligentes, pero a la vez estúpidos.>"

    old "1. <Oh, Grimmy.>"
    new "1. <Oh, Parquita.>"

    old "1. <What exactly have you been reading?>"
    new "1. <¿Qué has estado leyendo exactamente?>"

    old "1. <Saucy enemies to lovers books?>"
    new "1. <¿Libros picantes sobre enemigos que se convierten en amantes?>"

    old "1. <I feel like this is the kinda thing you only know about if you read them.>"
    new "1. <Siento que esto es algo que solo se sabe si se lee.>"

    old "1. <Can you blame me?>"
    new "1. <¿Puedes culparme?>"

    old "1. <It's harmless fun, really.>"
    new "1. <Es una diversión inofensiva, de verdad.>"

    old "1. <I could read you one, if you wanted.>"
    new "1. <Podría leerte uno, si quisieras.>"

    old "1. <I've been told that I have a good voice for audiobooks.>"
    new "1. <Me han dicho que tengo una buena voz para los audiolibros.>"

    old "1. <I'll pick out an extra saucy scene and we can see if you blush.>"
    new "1. <Elegiré una escena extra picante y podemos ver si te sonrojas.>"



    old "1. <Maybe it's a bad idea after all...>"
    new "1. <Tal vez sea una mala idea después de todo...>"

    old "1. <Wow, what a flirt.>"
    new "1. <Wow, qué coqueteo.>"

    old "1. <You really don't have to do that.>"
    new "1. <Realmente no tienes que hacer eso.>"

    old "1. <How about we go back to talking about family, huh?!>"
    new "1. <¿Qué tal si volvemos a hablar de familia, eh?>"

    old "1. <Did I say that? Maybe you're confused.>"
    new "1. <¿Dije eso? Quizás estés confundido.>"

    old "1. <COUGH COUGH...>"
    new "1. <TOS TOS...>"

    old "1. <Absolutely nothing. Nope.>"
    new "1. <Absolutamente ninguno. Nop.>"

    old "1. <That's VERY unnecessary...>"
    new "1. <Eso es MUY innecesario...>"

    old "1. <Right, family! Lets just talk about family again!>"
    new "1. <¡Bien, familia! ¡Vamos a hablar de familia de nuevo!>"

    old "1. <Nope, just me!>"
    new "1. <¡Nop, solo yo!>"

    old "1. <I would have liked some.>"
    new "1. <Me hubiera gustado algunos.>"

    old "1. <Most of my friends had a lot of siblings.>"
    new "1. <La mayoría de mis amigos tenían muchos hermanos.>"

    old "1. <But I had plenty of friends.>"
    new "1. <Pero tenía muchos amigos.>"

    old "1. <So it wasn't really too bad.>"
    new "1. <Así que no fue realmente tan malo.>"

    old "1. <So it did feel kind of lonely at times.>"
    new "1. <Así que a veces sentía cierta soledad.>"

    old "1. <I never had to deal with siblings taking my stuff, so that's nice.>"
    new "1. <Nunca tuve que lidiar con hermanos que tomen mis cosas, así que eso es bueno.>"

    old "1. <I've always felt pretty independent.>"
    new "1. <Siempre me he sentido bastante independiente.>"

    old "1. <I've got a brother.>"
    new "1. <Tengo un hermano.>"

    old "1. <He's annoying, but I love him.>"
    new "1. <Es molesto, pero lo amo.>"

    old "1. <They're total nuisances, but I love them.>"
    new "1. <Son un fastidio total, pero me encantan.>"

    old "1. <She's kinda way cooler than I am.>"
    new "1. <Ella es un poco más genial que yo.>"

    old "1. <They're annoying, but I love them.>"
    new "1. <Elle es una molestia, pero le amo.>"

    old "1. <More than you can even imagine.>"
    new "1. <Más de lo que puedes imaginar.>"

    old "1. <Do you have any siblings, Grim?>"
    new "1. <¿Tienes algún hermano, Parca?>"

    old "1. <You do give only child vibes, so I'm not surprised.>"
    new "1. <Solo das vibraciones infantiles, así que no me sorprende.>"

    old "1. <It's just the way you act sometimes.>"
    new "1. <Es solo la forma en que actúas a veces.>"

    old "1. <Your disgust at the idea of sharing.>"
    new "1. <Tu disgusto ante la idea de compartir.>"

    old "1. <And sometimes you're kinda demanding.>"
    new "1. <Y a veces eres un poco exigente.>"

    old "1. <Yes... exactly.>"
    new "1. <Sí... exactamente.>"

    old "1. <I bet if you had a sibling, they'd put you in your place.>"
    new "1. <Apuesto a que si tuvieras un hermano, te pondrían en tu lugar.>"

    old "1. <Sure you do.>"
    new "1. <Seguro que lo haces.>"

    old "1. <So that's the family questions out of the way, then?>"
    new "1. <¿Entonces ya hemos resuelto las cuestiones familiares?>"

    old "1. <What's next?>"
    new "1. <¿Qué sigue?>"

    old "1. <What exactly do you need that for?>"
    new "1. <¿Para qué necesitas exactamente eso?>"

    old "1. <I think my idea of {i}'taken care of'{/i} and yours are probably very different...>"
    new "1. <Creo que mi idea de {i}'encargarse de ellos'{/i} y la tuya son probablemente muy diferentes...>"

    old "1. <What will do you with the information?>"
    new "1. <¿Qué harás con la información?>"

    old "1. <Do you plan to take their souls prematurely?>"
    new "1. <¿Planeas llevarte sus almas prematuramente?>"

    old "1. <I think I should keep these names to myself.>"
    new "1. <Creo que debería mantener estos nombres en secreto.>"

    old "1. <I don't think so, mister.>"
    new "1. <No lo creo, señor.>"

    old "1. <I would laugh at you for being edgy.>"
    new "1. <Me reiría de ti por ser edgy.>"

    old "1. <Grimmy...>"
    new "1. <Parquita...>"

    old "1. <How exactly do you expect them to interfere?>"
    new "1. <¿Cómo esperas exactamente que interfieran?>"

    old "1. <There might be.>"
    new "1. <Puede haber.>"

    old "1. <Someone is sounding a little jealous right now.>"
    new "1. <Alguien suena un poco celoso en este momento.>"

    old "1. <Even if there was someone special in my life...>"
    new "1. <Incluso si hubiera alguien especial en mi vida...>"

    old "1. <They wouldn't be able to stop a Grim Reaper.>"
    new "1. <No podría detener a una Parca.>"

    old "1. <Share what?>"
    new "1. <¿Compartir qué?>"

    old "1. <Luckily for you I don't have anyone special.>"
    new "1. <Por suerte para ti, no tengo a nadie especial.>"

    old "1. <MAIMING???>"
    new "1. <¿¿¿MUTILAR??? >"

    old "1. <You wouldn't REALLY do that... would you?>"
    new "1. <No harías eso de VERDAD... ¿o sí?>"


    old "1. <Luckily there really is no one.>"
    new "1. <Por suerte, realmente no hay nadie.>"

    old "1. <Yeah, they're a Grim Reaper.>"
    new "1. <Sí, es una Parca.>"

    old "1. <Sorry for not bringing it up before.>"
    new "1. <Perdón por no mencionarlo antes.>"

    old "1. <And what?>"
    new "1. <¿Y qué?>"

    old "1. <This is sounding less and less work related, Grim.>"
    new "1. <Esto cada vez parece menos relacionado con el trabajo, Parca.>"

    old "1. <Anyway, I think you'd like him.>"
    new "1. <De todos modos, creo que te caería bien.>"

    old "1. <He's funny, handsome, and incredibly stupid. But I like his stupidity.>"
    new "1. <Es divertido, guapo e increíblemente estúpido. Pero me gusta su estupidez.>"

    old "1. <Well, yeah. He's you.>"
    new "1. <Bueno, sí. Él eres tú.>"

    old "1. <Yeah you do.>"
    new "1. <Sí, lo haces.>"

    old "1. <Not really.>"
    new "1. <No precisamente.>"

    old "1. <You're just fun to be around.>"
    new "1. <Es divertido estar contigo.>"

    old "1. <What do you mean?>"
    new "1. <¿Qué quieres decir?>"

    old "1. <So what?>"
    new "1. <¿Tan que?>"

    old "1. <Are you asking me why I'm single right now?>"
    new "1. <¿Me estás preguntando por qué no tengo pareja en este momento?>"

    old "1. <No, what were you going to say?>"
    new "1. <No, ¿qué ibas a decir?>"

    old "1. <Are you trying to insult me or compliment me?>"
    new "1. <¿Estás tratando de insultarme o de halagarme?>"

    old "1. <I've never actually dated anyone.>"
    new "1. <En realidad nunca he salido con nadie.>"

    old "1. <I'm not lying to you.>"
    new "1. <No te estoy mintiendo.>"

    old "1. <No one's ever asked me out.>"
    new "1. <Nadie me ha invitado a salir.>"

    old "1. <Nope, that's what I'm saying.>"
    new "1. <Nop, eso es lo que estoy diciendo.>"

    old "1. <No flowers or fancy dates.>"
    new "1. <Sin flores ni citas elegantes.>"

    old "1. <No chocolates or anything on Valentine's Day.>"
    new "1. <Nada de chocolates ni nada por el estilo en San Valentín.>"

    old "1. <I think so? I don't need anything fancy, though.>"
    new "1. <¿Eso creo? Aunque no necesito nada sofisticado.>"

    old "1. <It would be nice to get some flowers or something.>"
    new "1. <Sería bonito recibir unas flores o algo así.>"

    old "1. <I have dated before.>"
    new "1. <He tenido citas antes.>"

    old "1. <But it's never been anything serious.>"
    new "1. <Pero nunca ha sido nada serio.>"

    old "1. <Seriously?>"
    new "1. <¿En serio?>"

    old "1. <We don't even talk anymore.>"
    new "1. <Ya ni siquiera hablamos.>"

    old "1. <You don't need to worry about them getting in the way of your reaping.>"
    new "1. <No tienes que preocuparte de que te estorben a la hora de cosechar mi alma.>"

    old "1. <That I've dated before?>"
    new "1. <¿Que haya salido con alguien antes?>"

    old "1. <I was like 15, it hardly counts.>"
    new "1. <Tenía 15 años, apenas cuenta.>"

    old "1. <We didn't even hold hands.>"
    new "1. <Ni siquiera nos tomamos de las manos.>"

    old "1. <No, we were practically kids.>"
    new "1. <No, éramos prácticamente niños.>"

    old "1. <Fancy dates and flowers?>"
    new "1. <¿Citas elegantes y flores?>"

    old "1. <I don't need over the top fancy, flowers would be nice though.>"
    new "1. <No necesito nada muy sofisticado, aunque unas flores estarían bien.>"

    old "1. <Is that cliché?>"
    new "1. <¿Ese cliché?>"

    old "1. <So I haven't actually ever dated... if that's what you mean?>"
    new "1. <Así que, en realidad, nunca he salido con nadie... ¿es eso lo que quieres decir?>"

    old "1. <They didn't feel right for me.>"
    new "1. <No me parecían adecuados para mí.>"

    old "1. <I didn't feel the same way they did, so it wouldn't have been fair to them.>"
    new "1. <No sentía lo mismo, así que no habría sido justo.>"

    old "1. <And it was really as simple as that.>"
    new "1. <Y fue tan sencillo como eso.>"

    old "1. <That usually requires accepting going on a date, so no.>"
    new "1. <Eso normalmente implica aceptar ir a una cita, así que no.>"

    old "1. <No flowers or fancy meals for me, I'm afraid.>"
    new "1. <No hay flores ni comidas elegantes para mí, me temo.>"

    old "1. <Mmm.>"
    new "1. <Mmm.>"

    old "1. <I don't need fancy, but some cute flowers would be nice.>"
    new "1. <No necesito nada sofisticado, pero unas flores estarían bien.>"

    old "1. <And what about you then, Grim?>"
    new "1. <¿Y tú, Parca?>"

    old "1. <You said yesterday you've never been in love.>"
    new "1. <Ayer dijiste que nunca te has enamorado.>"

    old "1. <But that doesn't mean you've never dated, or had a crush on someone.>"
    new "1. <Pero eso no significa que nunca hayas salido con alguien o tenido un amor platónico.>"

    old "1. <Any underworldings take your fancy?>"
    new "1. <¿Algún habitante del inframundo te llama la atención?>"

    old "1. <Then... any mortals?>"
    new "1. <Entonces... ¿algún mortal?>"

    old "1. <Nuh uh, you haven't answered yet.>"
    new "1. <Nuh uh, aún no has respondido.>"

    old "1. <The left.>"
    new "1. <Izquierdo.>"

    old "1. <It's alright, you can lay under me.>"
    new "1. <Está bien, puedes recostarte debajo de mí.>"

    old "1. <Or on top of me, if you prefer?>"
    new "1. <¿O encima de mí, si lo prefieres?>"

    old "1. <Sorry, I'm a bed hog.>"
    new "1. <Lo siento, acaparo la cama.>"

    old "1. <We can both lie in the middle and snuggle ;)>"
    new "1. <Podemos acostarnos en el medio y abrazarnos ;)>"

    old "1. <I feel like you do.>"
    new "1. <Siento que lo haces.>"

    old "1. <But I suppose to actually sleep...>"
    new "1. <Pero supongo que para dormir realmente...>"

    old "1. <I'll take the left.>"
    new "1. <Tomaré la izquierda.>"

    old "1. <So, you gonna ask me again why it took me so long to respond?>"
    new "1. <Entonces, ¿vas a volver a preguntarme por qué tardé tanto en responder?>"

    old "1. <Or whether I thought your approach to this little game was wrong?>"
    new "1. <¿O si consideré que tu enfoque de este pequeño juego era incorrecto?>"

    old "1. <The way you asked was a little strange.>"
    new "1. <La forma en que lo preguntaste fue un poco extraña.>"

    old "1. <The approach was fine, you just phrase things kind of strangely.>"
    new "1. <El enfoque estaba bien, solo que expresas las cosas de una manera un poco extraña.>"

    old "1. <Like you're interested, but don't want to seem too interested.>"
    new "1. <Como si te interesara, pero no quisieras parecer demasiado interesado.>"

    old "1. <It is actually kind of cute.>"
    new "1. <En realidad, fue bastante lindo.>"

    old "1. <Obviously really interested in getting to know me.>"
    new "1. <Obviamente, está muy interesado en conocerme.>"

    old "1. <Oh, also...!>"
    new "1. <¡Oh, también...!>"

    old "1. <You rambled to yourself again!>"
    new "1. <¡Te pusiste a divagar otra vez!>"
    old "1. <The last time you did that was when we first met.>"
    new "1. <La última vez que hiciste eso fue cuando nos conocimos.>"

    old "1. <You kind of did. Had a little chat to yourself.>"
    new "1. <En cierto modo, sí. Tuviste una pequeña charla contigo mismo.>"

    old "1. <Well, it definitely did.>"
    new "1. <Bueno, sin duda lo hacías.>"

    old "1. <I saw them just in time to witness something hilarious.>"
    new "1. <Los vi justo a tiempo para presenciar algo muy gracioso.>"

    old "1. <Right as you yelled 'Fuck Me!'>"
    new "1. <Justo cuando gritaste '¡Que me jodan!'>"

    old "1. <Definitely a way to introduce yourself to someone.>"
    new "1. <Sin duda, una forma de presentarte a alguien.>"

    old "1. <I'm never going to let you live it down.>"
    new "1. <Nunca te voy a dejar olvidarlo.>"

    old "1. <I'm glad! :)>"
    new "1. <¡Me alegro! :)>"

    old "1. <Stop messing around.>"
    new "1. <Deja de jugar.>"

    old "1. <I don't have any memory issues.>"
    new "1. <No tengo problemas de memoria.>"

    old "1. <I was just being sarcastic.>"
    new "1. <Solo estaba hablando con sarcasmo.>"

    old "1. <Ha ha ha, very funny.>"
    new "1. <Ja, ja, ja, muy divertido.>"

    old "1. <Golly gosh, I just cannot stop laughing.>"
    new "1. <Diosh mioh, simplemente no puedo dejar de reír.>"

    old "1. <Boy, I've never heard anything so funny before!>"
    new "1. <Chico, ¡nunca antes había escuchado nada tan divertido!>"

    old "1. <That seems to happen a lot with you.>"
    new "1. <Eso parece sucederte muy a menudo.>"

    old "1. <Honestly?>"
    new "1. <¿Honestamente?>"

    old "1. <At first because I thought it was kind of funny.>"
    new "1. <Al principio porque me pareció gracioso.>"

    old "1. <So I kept them, for a laugh.>"
    new "1. <Así que las guardé, por diversión.>"

    old "1. <I know you were.>"
    new "1. <Sé que lo estabas haciendo.>"

    old "1. <And that made it even funnier.>"
    new "1. <Y eso lo hizo aún más divertido.>"

    old "1. <Are you trying to be funny now, too?>"
    new "1. <¿Estás tratando de ser divertido ahora también?>"

    old "1. <Woah hold up now buddy, that is just a tad extreme.>"
    new "1. <Woah espera un momento, amigo, eso es un poco extremo.>"

    old "1. <Fortunately, I've never heard a... 'bard' singing about you.>"
    new "1. <Afortunadamente, nunca he escuchado a un... 'bardo' cantar sobre ti.>"

    old "1. <I would pay to see that, though.>"
    new "1. <Sin embargo, pagaría para ver eso.>"

    old "1. <Then I would simply have to offer more money than you.>"
    new "1. <Entonces simplemente tendría que ofrecer más dinero que tú.>"

    old "1. <They'd have no choice but to play.>"
    new "1. <No tendrían más remedio que tocar.>"

    old "1. <You do usually look kinda... crabby.>"
    new "1. <Sueles ponerte un poco... cangrejudo.>"

    old "1. <That's what you think one of the worse pains is???>"
    new "1. <¿¿¿Eso es lo que consideras uno de los peores dolores??? >"

    old "1. <I'm your favorite papercut!>"
    new "1. <¡Soy tu corte de papel favorito!>"

    old "1. <Except for me. I'm slightly better than the others.>"
    new "1. <Excepto por mí. Soy un poco mejor que los demás.>"

    old "1. <You never make any sense.>"
    new "1. <Nunca tienes sentido.>"

    old "1. <At all.>"
    new "1. <En absoluto.>"

    old "1. <Moving away from... that.>"
    new "1. <Dejando atrás... eso.>"

    old "1. <I'd listen to a song about you on repeat.>"
    new "1. <Escucharía una canción sobre ti una y otra vez.>"

    old "1. <Wow! Straight to murder!>"
    new "1. <¡Wow! ¡Directo al asesinato!>"

    old "1. <Somehow this is one of the least surprising things you've said.>"
    new "1. <De alguna manera, esta es una de las cosas menos sorprendentes que has dicho.>"

    old "1. <I would seriously pay to see someone sing about you, though.>"
    new "1. <Sin embargo, pagaría con mucho gusto por ver a alguien cantar sobre ti.>"

    old "1. <Maybe I will.>"
    new "1. <Tal vez lo haga.>"

    old "1. <Your outfit does kinda give an 'I'm a ninja' vibe.>"
    new "1. <Tu atuendo da vibra de 'soy un ninja'.>"

    old "1. <They are similar enough, no?>"
    new "1. <Son lo suficientemente similares, ¿no?>"

    old "1. <Oh, really?>"
    new "1. <¿Ah, de verdad?>"

    old "1. <So that's how it is.>"
    new "1. <Así que eso es lo que pasa.>"

    old "1. <Though I gotta say, your scythe is cooler than little ninja daggers.>"
    new "1. <Aunque tengo que decir que tu guadaña es más cool que las pequeñas dagas ninja.>"

    old "1. <Do you think there are songs about ninjas?>"
    new "1. <¿Crees que hay canciones sobre ninjas?>"

    old "1. <But not about you, it seems. Maybe the ninjas {i}do{/i} have one up on you?>"
    new "1. <Pero parece que no es tu caso. ¿Quizás los ninjas {i}te llevan{/i} ventaja?>"

    old "1. <Should I look for someone to make a pity song about you?>"
    new "1. <¿Debería buscar a alguien que componga una canción compasiva sobre ti?>"

    old "1. <Wow. That's a little extreme.>"
    new "1. <Wow. Eso es un poco extremo.>"

    old "1. <I'm not sure about 'appropriate'...>"
    new "1. <No sé si es lo más 'apropiado'...>"

    old "1. <I really do think some kind of theme song would help your image, though.>"
    new "1. <Sin embargo, realmente creo que algún tipo de tema musical ayudaría a mejorar tu imagen.>"

    old "1. <Lets find someone to sing it :D>"
    new "1. <Busquemos a alguien que lo cante :D>"

    old "1. <Wait, I know a gnarly song about crabs having a rave.>"
    new "1. <Espera, conozco una canción genial sobre cangrejos que se van de fiesta.>"

    old "1. <Fine fine. Your loss though. It really is a banger.>"
    new "1. <Está bien, está bien. Pero tú te lo pierdes. Es realmente increíble.>"

    old "1. <Speaking of bangers!>"
    new "1. <¡Hablando de éxitos!>"

    old "1. <I hope someone does write songs about you.>"
    new "1. <Espero que alguien escriba canciones sobre ti.>"

    old "1. <Okay, edgelord. No need to resort to murder.>"
    new "1. <Ok, señor edgy. No hay necesidad de recurrir al asesinato.>"

    old "1. <I doubt you'd really do that, anyway.>"
    new "1. <Dudo que realmente hagas eso, de todos modos.>"

    old "1. <So I'm gonna find someone to sing about you :D>"
    new "1. <Así que voy a encontrar a alguien que cante sobre ti :D>"

    old "1. <Hello to you as well, Grimmy.>"
    new "1. <Hola a ti también, Parquita>"

    old "1. <And I definitely would.>"
    new "1. <Y definitivamente lo haría.>"

    old "1. <That's funny, coming from you.>"
    new "1. <Eso es gracioso, viniendo de ti.>"

    old "1. <Maybe I should look for composers right now.>"
    new "1. <Quizás debería buscar compositores ahora mismo.>"

    old "1. <Oh, stop giving me that look.>"
    new "1. <Oh, deja de mirarme así.>"

    old "1. <The 'I think I'm so menacing' look.>"
    new "1. <La mirada de 'creo que soy muy amenazante'>"

    old "1. <Well, that's what you think it is.>"
    new "1. <Bueno, eso es lo que tú crees.>"

    old "1. <It's more like a...>"
    new "1. <Es más bien una...>"

    old "1. <'Please bully me' look.>"
    new "1. <Mirada de 'por favor, intimídame'.>"

    old "1. <I like it when you say please.>"
    new "1. <Me gusta cuando dices por favor>"

    old "1. <It's leaning even further into the bullying thing.>"
    new "1. <Eso se parece aún más a la intimidación.>"

    old "1. <Please Sunshine, bully me :D>"
    new "1. <Por favor, Solecito, intimídame :D>"

    old "1. <Takes one to know one.>"
    new "1. <Se necesita ser uno para reconocer a otro.>"

    old "1. <I wouldn't actually mind it if you were in charge of me.>"
    new "1. <En realidad, no me importaría que tú me dieras órdenes.>"

    old "1. <But you've gotta tell me to do interesting things.>"
    new "1. <Pero tienes que decirme que haga cosas interesantes.>"

    old "1. <I'll leave that up to you to decide ;)>"
    new "1. <Eso lo dejo a tu criterio ;)>"

    old "1. <Anyway, I was wondering something.>"
    new "1. <De todos modos, me preguntaba algo.>"

    old "1. <You'll be surprised when I send you a file \nwith people singing a merry little tune about you.>"
    new "1. <Te sorprenderás cuando te envíe un archivo \ncon gente cantando una alegre canción sobre ti.>"

    old "1. <I can't wait to see your reaction.>"
    new "1. <Estoy deseando ver tu reacción.>"

    old "1. <We can listen to it the first time together.>"
    new "1. <Podemos escucharla juntos por primera vez.>"

    old "1. <Your very own theme song, Grim!>"
    new "1. <¡Tu propia canción temática, Parca!>"

    old "1. <I bet you can't wait :D>"
    new "1. <Apuesto a que no puedes esperar :D>"

    old "1. <You just can't bring yourself to \nbe parted from me, obviously.>"
    new "1. <Es obvio que no te atreves a separarte de mí.>"

    old "1. <If I was gone, whatever would you do with your days?>"
    new "1. <Si yo no estuviera, ¿qué harías con tus días?>"

    old "1. <How dull.>"
    new "1. <Qué aburrido.>"

    old "1. <It's also good to have downtime to relax.>"
    new "1. <También es bueno tener tiempo libre para relajarse.>"

    old "1. <Maybe? You are looking kinda flush.>"
    new "1. <¿Quizás? Pareces un poco sonrojado.>"

    old "1. <Or maybe that's a different feeling, hmm?>"
    new "1. <¿O tal vez sea otra sensación, eh?>"

    old "1. <I was wondering something.>"
    new "1. <Me preguntaba algo.>"

    old "1. <You don't have to look gentle to be want to \nbe treated gently, Grim.>"
    new "1. <No tienes que parecer gentil para que te \ntraten con gentileza, Parca.>"

    old "1. <Don't worry, I can see past the bad boy aesthetic.>"
    new "1. <No te preocupes, puedo ver más allá de tu actitud de chico malo.>"

    old "1. <You're just a lil dude that gets easily flustered \nand needs to be taken care of.>"
    new "1. <Solo eres un pequeño que se altera fácilmente y necesita que lo cuiden.>"

    old "1. <I beg to differ.>"
    new "1. <No estoy de acuerdo.>"

    old "1. <You're what the kids might call a 'little skrunkly'.>"
    new "1. <Eres lo que los niños llamarían un 'pequeño enclenque'.>"

    old "1. <Precious little man.>"
    new "1. <Mi precioso hombrecito.>"

    old "1. <Not QUITE as precious as [pet_name], though.>"
    new "1. <Aunque no TAN adorable como [pet_name].>"

    old "1. <Not QUITE as precious as my little pet, though.>"
    new "1. <Aunque no TAN adorable como mi mascotita.>"

    old "1. <Suddenly you want to be a precious \nto me, huh?>"
    new "1. <De repente quieres ser una preciosa babygirl para mí, ¿eh?>"

    old "1. <You're so competitive sometimes.>"
    new "1. <A veces eres tan competitivo.>"

    old "1. <{i}Raise your pet to the camera{/i}.>"
    new "1. <{i}Levantar a tu mascota hacia la cámara{/i}.>"

    old "1. <You're right, it's hard to compare to this perfection.>"
    new "1. <Tienes razón, es difícil compararse con esta perfección.>"

    old "1. <Just the cutest bunny in the world, you mean.>"
    new "1. <Te refieres al conejito más lindo del mundo.>"

    old "1. <Look at [pet_her] little face!>"
    new "1. <¡Mira la carita de [pet_she!t]!>"

    old "1. <What did you just mutter?>"
    new "1. <¿Qué acabas de murmurar?>"

    old "1. <[pet_She]'s the best one of all!>"
    new "1. <¡[pet_She!t] es mejor que todos!>"

    old "1. <The cutest, the cuddliest, the sweetest...>"
    new "1. <Adorable, abrazable, una ternura...>"

    old "1. <Just look at [pet_her] lil face.>"
    new "1. <Solo hay que ver la carita de [pet_she!t].>"

    old "1. <Whoops, I accidentally shaved it all off.>"
    new "1. <Ups, se me pasó y se lo afeité todo.>"

    old "1. <You're such a doofus.>"
    new "1. <Eres un tonto.>"

    old "1. <Sphynxes don't come with fur.>"
    new "1. <Los gatos esfinge no tienen pelo.>"

    old "1. <Well, most of the time, anyway.>"
    new "1. <Bueno, la mayoría de las veces, al menos.>"

    old "1. <Kinda like velvet.>"
    new "1. <Es como el terciopelo.>"

    old "1. <I bet you wanna feel [pet_her]. [pet_She]'s so cute.>"
    new "1. <Apuesto a que quieres darle una caricia a [pet_she!t]. [pet_She!t] es tan adorable.>"

    old "1. <Except [pet_she] is the coolest one of all.>"
    new "1. <Excepto que [pet_she!t] es más genial de todos.>"

    old "1. <Don't be mean!>"
    new "1. <¡No seas cruel!>"

    old "1. <[pet_She]'s the sweetest lil hamster around.>"
    new "1. <[pet_She!t] es el hámster más dulce que existe.>"

    old "1. <If you held [pet_her2], you'd see how cute [pet_she] is.>"
    new "1. <Si le sujetaras, verías lo adorable que es [pet_she!t].>"

    old "1. <[pet_She]'s just a lil danger noodle, actually.>"
    new "1. <[pet_She!t] es solo un peligro menor, en realidad.>"

    old "1. <Not scary or terrifying in the slightest.>"
    new "1. <No da miedo ni es aterrorizante en absoluto.>"

    old "1. <Don't you think [pet_she]'s cute?>"
    new "1. <¿No crees que [pet_she!t] es adorable?>"

    old "1. <{i}Put your pet back to bed.{/i}>"
    new "1. <{i}Vuelves a dejar a tu mascota en la cama.{/i}>"

    old "1. <When exactly do you plan to take my soul, Mr Reaper?>"
    new "1. <¿Cuándo piensa llevarse mi alma exactamente, señor Parca?>"

    old "1. <Yes? Is there something I can help you \nwith, little reaper?>"
    new "1. <¿Sí? ¿Puedo ayudarte en algo, parquita?>"

    old "1. <That's a little rude!>"
    new "1. <¡Eso es un poco cruel!>"

    old "1. <I know you don't really mind.>"
    new "1. <Sé que en realidad no te importa.>"

    old "1. <You wouldn't talk to me all this time if you did.>"
    new "1. <Si te importara, no habrías hablado conmigo todo este tiempo.>"

    old "1. <You'd just take my soul and be done with it.>"
    new "1. <Simplemente me quitarías el alma y se acabaría.>"

    old "1. <Mmm, you appear to be running low on time, though.>"
    new "1. <Mmm, aunque parece que se te acaba el tiempo.>"

    old "1. <Two days and then your soul is mine, remember?>"
    new "1. <Dos días y tu alma será mía, ¿recuerdas?>"

    old "1. <Oh!>"
    new "1. <!Oh!>"

    old "1. <I'm still looking forward to our soul baby, by the way.>"
    new "1. <Por cierto, sigo esperando con ilusión a nuestro bebé alma.>"

    old "1. <We're gonna make it happen!>"
    new "1. <¡Vamos a hacer que pase!>"

    old "1. <Yes yes yes yes.>"
    new "1. <Sí sí sí sí.>"

    old "1. <I'll cherish it and raise it well.>"
    new "1. <Lo cuidaré y lo criaré bien.>"

    old "1. <Well, you haven't taken my soul yet.>"
    new "1. <Bueno, aún no me has quitado el alma.>"

    old "1. <Soooooo.>"
    new "1. <Entoooonces.>"

    old "1. <I may as well mentally prepare myself for the baby.>"
    new "1. <Más vale que me prepare mentalmente para el bebé.>"

    old "1. <You better help.>"
    new "1. <Más vale que me ayudes.>"

    old "1. <You're a grumpy thing, but I know you'll be a \ngood soul father.>"
    new "1. <Eres un gruñón, pero sé que serás un buen padre.>"

    old "1. <How can you be sure?>"
    new "1. <¿Cómo puedes estar seguro?>"

    old "1. <Statistically speaking, I'm just as likely to \nwin this bet as you are.>"
    new "1. <Estadísticamente hablando, tengo las mismas  \nposibilidades de ganar esta apuesta que tú.>"

    old "1. <I think I'm doing a decent job so far.>"
    new "1. <Creo que hasta ahora lo estoy haciendo \nbastante bien.>"

    old "1. <Considering I'm still, you know, alive.>"
    new "1. <Teniendo en cuenta que sigo, ya sabes, con vida.>"

    old "1. <Or maybe you just can't take it.>"
    new "1. <O quizás simplemente no puedes soportarlo.>"

    old "1. <Well, yeah, I do feel lucky to have met you.>"
    new "1. <Bueno, sí, me siento con suerte de haberte conocido.>"

    old "1. <Right now?>"
    new "1. <¿Ahora mismo?>"

    old "1. <Talking to you?>"
    new "1. <¿Hablando contigo?>"

    old "1. <Why do you wanna know?>"
    new "1. <¿Por qué quieres saberlo?>"

    old "1. <Grim wants to know about my daaaay.>"
    new "1. <Parca quiere saber cómo me ha ido el díaaaa.>"

    old "1. <Grim's got a little cruuuush...>"
    new "1. <Parca está un poco enamorado..>"

    old "1. <So demanding.>"
    new "1. <Qué exigente.>"

    old "1. <Hmmm, before your fifty questions...>"
    new "1. <Mmmm, antes de tus cincuenta preguntas...>"

    old "1. <Your {i}nearly{/i} 50 questions, I was...>"
    new "1. <Tus {i}casi{/i} 50 preguntas, yo estaba...>"

    old "1. <Well, not doing much, actually. Hanging out \naround my apartment.>"
    new "1. <Bueno, en realidad no haciendo mucho. Pasando \nel rato por mi apartamento.>"

    old "1. <[pet_name] was acting a little strange earlier. \nI thought [pet_she] might be getting sick.>"
    new "1. <[pet_name] estaba actuando un poco raro antes. Pensé que [pet_she!t] podría estar enfermando.>"

    old "1. <But [pet_she] perked right up.>"
    new "1. <Pero [pet_she!t] se animó enseguida.>"

    old "1. <I suppose I just have a healing presence.>"
    new "1. <Supongo que tengo un don curativo.>"

    old "1. <I actually just got home from work, but I have \nthe next few days off.>"
    new "1. <De hecho, acabo de llegar a casa del trabajo, \npero tengo los próximos días libres.>>"

    old "1. <Figured if I was gonna die, I didn't wanna \nspend my last days at work.>"
    new "1. <Pensé que si iba a morir, no quería pasar mis \núltimos días en el trabajo.>"

    old "1. <But I know I'll be fine, anyway.>"
    new "1. <Pero sé que estaré bien, de todos modos.>"

    old "1. <So I'm just gonna enjoy my little at home vacation.>"
    new "1. <Así que voy a disfrutar de mis pequeñas vacaciones en casa.>"

    old "1. <I'm gonna hit the town and paaaartaaay.>"
    new "1. <Voy a salir por ahí y de fiestaaaa.>"

    old "1. <That's because I'm not.>"
    new "1. <Eso es porque no lo soy.>"

    old "1. <Me and alcohol don't really mix.>"
    new "1. <El alcohol y yo no nos llevamos muy bien.>"

    old "1. <Correct.>"
    new "1. <Correcto.>"

    old "1. <I've never been drunk, but I can tell.>"
    new "1. <Nunca me he emborrachado, pero puedo imaginarlo.>"

    old "1. <I'd be a mess. Better to never find out.>"
    new "1. <Sería un desastre. Mejor no averiguarlo nunca.>"

    old "1. <Indeed. I'll be a responsible [girl] a bit longer.>"
    new "1. <En efecto. Seré un[girl!t] responsable un poco más.>"

    old "1. <By staying right here at home to relax for \nthe next few days.>"
    new "1. <Quedándome aquí en casa para relajarme durante los próximos días.>"

    old "1. <Can't say I want a repeat of that.>"
    new "1. <No puedo decir que quiera repetir la experiencia.>"

    old "1. <Or the splitting headache I had the next day. \nDo not recommend.>"
    new "1. <Ni el dolor de cabeza que tuve al día siguiente. \nNo lo recomiendo.>"

    old "1. <Yeah, well, I'm not gonna be doing that again.>"
    new "1. <Sí, bueno, no voy a volver a hacerlo.>"

    old "1. <I'm gonna stay here and relax, I think.>"
    new "1. <Creo que me voy a quedar aquí y relajarme.>"

    old "1. <I could start right now.>"
    new "1. <Podría empezar ahora mismo.>"

    old "1. <Honestly, I don't have the energy for that.>"
    new "1. <Sinceramente, no tengo energía para eso.>"

    old "1. <Instead, I'll probably just stay here.>"
    new "1. <En cambio, probablemente me quedaré aquí.>"

    old "1. <I do like walking in the park.>"
    new "1. <Me gusta pasear por el parque.>"

    old "1. <Grab a coffee.>"
    new "1. <Tomar un café.>"

    old "1. <And that's only like a block or so down the road.>"
    new "1. <Y eso está solo a una cuadra más o menos.>"

    old "1. <Very convenient.>"
    new "1. <Muy conveniente.>"

    old "1. <I'll probably go tomorrow. It's a little late now.>"
    new "1. <Probablemente iré mañana. Ahora es un poco tarde.>"

    old "1. <But I shouldn't be long, unless I get lost \nsomewhere along the way.>"
    new "1. <Pero no debería tardar mucho, a menos que me \npierda por el camino.>"

    old "1. <Of course I won't.>"
    new "1. <Por supuesto que no.>"

    old "1. <I was just pulling your leg.>"
    new "1. <Solo te estaba tomando el pelo.>"

    old "1. <Hahaha, Grim, you're so dumb.>"
    new "1. <Jajaja, Parca, eres tan tonto.>"

    old "1. <Nothing beats staying at home in your PJs, after all.>"
    new "1. <Al fin y al cabo, no hay nada mejor que quedarse en casa en pijama.>"

    old "1. <Do you have any PJs, Grim?>"
    new "1. <¿Tienes pijamas, Grim?>"

    old "1. <Honestly, yeah.>"
    new "1. <Sinceramente, sí>"

    old "1. <I could've guessed the color, honestly.>"
    new "1. <Podría haber adivinado el color, sinceramente.>"

    old "1. <What kind are they?>"
    new "1. <¿De qué tipo es?>"

    old "1. <I wanna imagine you in them.>"
    new "1. <Quiero imaginarte con eso puesto.>"

    old "1. <You would look cute in pajamas.>"
    new "1. <Te verías lindo con pijama.>"

    old "1. <Immensely.>"
    new "1. <Muchísimo.>"

    old "1. <Awww, the Grim Reaper wants to know what \nmy PJs look like.>"
    new "1. <Awww, la Parca quiere saber cómo es mi pijama.>"

    old "1. <The same as you, actually.>"
    new "1. <Igual que la tuya, en realidad.>"

    old "1. <Yeah I know... but why?>"
    new "1. <Sí, lo sé... ¿pero por qué?>"

    old "1. <Wait?>"
    new "1. <¿Esperar?>"

    old "1. <That was a little sudden.>"
    new "1. <Eso fue un poco repentino.>"

    old "1. <Is everything alright?>"
    new "1. <¿Está todo bien?>"

    old "1. <For?>"
    new "1. <¿Para?>"

    old "1. <Did you accidentally hang up?>"
    new "1. <¿Accidentalmente colgiste?>"

    old "1. <And what exactly am I waiting for?>"
    new "1. <¿Y qué espero exactamente?>"

    old "1. <Uhh, what exactly am I waiting for?>"
    new "1. <Uhh, ¿qué espero exactamente?>"

    old "1. <And when have I ever done that?>"
    new "1. <¿Y cuándo he hecho eso?>"

    old "1. <Yes, sir...>"
    new "1. <Sí, señor...>"

    old "1. <I feel like a dog right now...>"
    new "1. <Me siento como un perro ahora mismo...>"

    old "1. <Welcome ba->"
    new "1. <Bienvenido de->"

    old "1. <W-what the hell?!>"
    new "1. <¡¿Q-qué diablos?!>>"

    old "1. <What are you doing here?!>"
    new "1. <¡¿Qué haces aquí?!>"

    old "1. <AAAAAAH?>"
    new "1. <¿AAAAAAH?>"

    old "1. <WHAT ARE YOU DOING HERE?>"
    new "1. <¿QUÉ HACES AQUÍ?>"

    old "1. <Why are you still there even after I rub my eyes...>"
    new "1. <¿Por qué sigues ahí incluso después de frotarme los ojos...>"

    old "1. <Grim?!>"
    new "1. <¡¿Parca?!>"

    old "1. <Wait, your name is Casper too?>"
    new "1. <Espera, ¿tú también te llamas Casper?>"

    old "1. <I'll be Casper 1, you be Casper 2.>"
    new "1. <Yo seré Casper 1 y tú, Casper 2.>"

    old "1. <That'll stop things being confusing.>"
    new "1. <Así no habrá confusión.>"

    old "1. <Well, hello Casper. It's nice to meet you finally.>"
    new "1. <Bueno, hola, Casper. Me alegro de conocerte por fin.>"

    old "1. <Maybe I have.>"
    new "1. <Quizás sí.>"

    old "1. <A really pretty one...>"
    new "1. <Uno muy lindo...>"

    old "1. <So you admit you're pretty?>"
    new "1. <¿Entonces admites que eres lindo?>"

    old "1. <So you'll admit you're cute, though?>"
    new "1. <Entonces, ¿admites que eres adorable?>"

    old "1. <So you'll admit to being sexy, then?>"
    new "1. <¿Entonces admites que eres sexy?>"

    old "1. <No! Nope!>"
    new "1. <¡No! ¡Nop!>"

    old "1. <I have no clue what you're talking about!>"
    new "1. <¡No tengo ni idea de lo que estás hablando!>"

    old "1. <This is how I always look.>"
    new "1. <Siempre tengo este aspecto.>"

    old "1. <Totally normal...>"
    new "1. <Totalmente normal...>"

    old "1. <A literal sauna...>"
    new "1. <Es una sauna literal...>"

    old "1. <Mmmhmm. So hot tonight. Yup.>"
    new "1. <Mmmhmm. Qué calor hace esta noche. Sí.>"

    old "1. <You usually call me stupid or annoying!>"
    new "1. <¡Normalmente me llamas idiota o molestia!>"

    old "1. <You're... a lot more forward in person.>"
    new "1. <Eres... mucho más atrevido en persona.>"

    old "1. <Grimmmm.>"
    new "1. <Parcaaaa.>"

    old "1. <Casper, then.>"
    new "1. .<Casper, entonces>"

    old "1. <How are you even here?>"
    new "1. <¿Cómo es que estás aquí?>"

    old "1. <Wait a second...!>"
    new "1. <¡Espera un momento...!>"

    old "1. <I live on the 5th floor!>"
    new "1. <¡Vivo en el quinto piso!>"

    old "1. <How are you even standing... sitting... whatever you're doing there?!>"
    new "1. <¿Cómo es posible que estés de pie... sentado... o lo que sea que estés haciendo ahí?>"

    old "1. <I can literally see you on the other side of this window!>"
    new "1. <¡Puedo verte literalmente al otro lado de esta ventana!>"

    old "1. <What the hell...>"
    new "1. <Qué demonios...>"

    old "1. <Okay... I'll add this to the list of things I wasn't expecting today.>"
    new "1. <Vale... Lo añadiré a la lista de cosas que no esperaba hoy.>"

    old "1. <I feel like I've been cheated out of some very important information about you!>"
    new "1. <¡Siento que me han engañado y me han ocultado información muy importante sobre ti!>"

    old "1. <Since when can you fly?!>"
    new "1. <¿Desde cuándo puedes volar?>"

    old "1. <You're floating five stories up from the ground!>"
    new "1. <¡Estás flotando a cinco pisos del suelo!>"

    old "1. <Alright, fair point.>"
    new "1. <De acuerdo, tienes razón.>"

    old "1. <Is it magic?>"
    new "1. <¿Es magia?>"

    old "1. <Can you teach me?>"
    new "1. <¿Me puedes enseñar?>"

    old "1. <Aww, you can just say you care!>"
    new "1. <¡Aww, solo tienes que decir que te importa!>"

    old "1. <Maybe you just want to avoid admitting you kinda care?>"
    new "1. <¿Quizás solo quieres evitar admitir que te importa?>"

    old "1. <Booooo.>"
    new "1. <Buuuuu.>"

    old "1. <WAIT!>"
    new "1. < ¡ESPERA! >"

    old "1. <Can't people see you...?>"
    new "1. <¿No te ven las personas...?>"

    old "1. <I don't know, would you be?>"
    new "1. <No lo sé, ¿lo serías?>"

    old "1. <Okaaay...?>"
    new "1. <¿Vaaale...?>"

    old "1. <Obviously you've cast a glamour.>"
    new "1. <Obviamente has lanzado un hechizo.>"

    old "1. <Are you invisible, then...?>"
    new "1. <¿Entonces eres invisible...?>"

    old "1. <...So my neighbors aren't gonna see a mysterious man floating outside of my window?>"
    new "1. <... ¿Entonces mis vecinos no verán a un hombre misterioso flotando fuera de mi ventana?>"

    old "1. <A raven, of course.>"
    new "1. <Un cuervo, claro.>"

    old "1. <You have a predictable side to you sometimes.>"
    new "1. <A veces eres muy predecible.>"

    old "1. <Why {i}wouldn't{/i} you?>"
    new "1. <¿Por qué {i}no{/i} lo harías?>"

    old "1. <Well, it's dark. Good camouflage?>"
    new "1. <Bueno, es oscuro. ¿Buen camuflaje?>"

    old "1. <Ah, yes. Wouldn't want to be mistaken for a vampire.>"
    new "1. <Ah, sí. No iba a querer que me confundieran con un vampiro.>"

    old "1. <But I do need to know...>"
    new "1. <Pero necesito saber...>"

    old "1. <How exactly did you find me?>"
    new "1. <¿Cómo me has encontrado exactamente?>"

    old "1. <I never told you.>"
    new "1. <Nunca te lo dije.>"

    old "1. <So I assume you've come to claim it?>"
    new "1. <¿Entonces supongo que has venido a reclamarla?>"

    old "1. <My soul, that is.>"
    new "1. <Mi alma, eso es.>"

    old "1. <I had a good run, I suppose.>"
    new "1. <Supongo que he tenido una buena vida.>"

    old "1. <I know you can't lie... but that sounds like a lie.>"
    new "1. <Sé que no puedes mentir... pero eso suena a mentira.>"

    old "1. <I know.>"
    new "1. <Lo sé.>"

    old "1. <Did you just drop by to say 'hi' then?>"
    new "1. <¿Entonces solo has venido a saludar?>"

    old "1. <Sooo, you're here... why?>"
    new "1. <Entooonces, ¿por qué... estás aquí?>"

    old "1. <You've come to whisk me away.>"
    new "1. <Has venido a llevarme lejos.>"

    old "1. <We'll fly through the night, fall deeply in love, then part sadly.>"
    new "1. <Volaremos toda la noche, nos enamoraremos profundamente y luego nos separaremos con tristeza.>"

    old "1. <On what?>"
    new "1. <¿De qué?>"

    old "1. <I wouldn't say no.>"
    new "1. <No diría que no.>"

    old "1. <How often do you get to fly around in the night sky?>"
    new "1. <¿Cuántas veces tienes la oportunidad de volar por el cielo nocturno?>"

    old "1. <But I'm guessing that isn't what you're here for.>"
    new "1. <Pero supongo que no es por eso por lo que estás aquí.>"

    old "1. <F... flowers?>"
    new "1. <¿F... flores?>"

    old "1. <You... you got me flowers?>"
    new "1. <¿Tú... me has traído flores?>"

    old "1. <Oh! Oh of course!>"
    new "1. <¡Oh! ¡Por supuesto!>"

    old "1. <Are you going to... come in?>"
    new "1. <¿Vas a... entrar?>"

    old "1. <Um... I feel like it could be a little dangerous...>"
    new "1. <Um... Creo que podría ser un poco peligroso...>"

    old "1. <What a shame, but fine...>"
    new "1. <Qué pena, pero está bien...>"

    old "1. <You really are a flirt tonight, aren't you?>"
    new "1. <Esta noche estás muy coqueto, ¿no?>"

    old "1. <{i}Open the window fully.{/i}>"
    new "1. <{i}Abrir la ventana del todo.{/i}>"

    old "1. <Seems that way.>"
    new "1. <Así parece.>"

    old "1. <Coming in, little reaper?>"
    new "1. <¿Entras, parquita?>"

    old "1. <Well, I opened the window for a reason.>"
    new "1. <Bueno, abrí la ventana por una razón.>"

    old "1. <Are you too scared to come in, {i}Casper{/i}?>"
    new "1. <¿Tienes demasiado miedo para entrar, {i}Casper{/i}?>"

    old "1. <And you'll stay there?>"
    new "1. <¿Y te quedarás ahí?>"

    old "1. <{i}Open the window slightly.{/i}>"
    new "1. <{i}Abrir ligeramente la ventana.{/i}>"

    old "1. <I'm not afraid of {i}you{/i}, Casper.>"
    new "1. <No te {i}tengo{/i} miedo, Casper.>"

    old "1. <{i}Open the window a crack.{/i}>"
    new "1. <{i}Abrir un poco la ventana.{/i}>"

    old "1. <Are you telling me I should be scared?>"
    new "1. <¿Me estás diciendo que debería tener miedo?>"

    old "1. <I'm not worried about the flowers.>"
    new "1. <No me preocupan las flores.>"

    old "1. <{i}You{/i} are the troublesome one, {i}Casper{/i}.>"
    new "1. <{i}Tú{/i} eres el problemático, {i}Casper{/i}.>"

    old "1. <{i}Open it.{/i}>"
    new "1. <{i}Abrirla.{/i} >"

    old "1. <{i}Open reluctantly... and very slowly.{i}>"
    new "1. <{i}Abre con desgana... y muy despacio.{i}>"

    old "1. <{i}Reach for the flowers.{/i}>"
    new "1. <{i}Alcanza las flores.{/i}>"

    old "1. <And yours are... quite cold, even through the gloves.>"
    new "1. <Y las tuyas están... bastante frías, incluso a través de los guantes.>"

    old "1. <They're really pretty.>"
    new "1. <Son realmente bonitas.>"

    old "1. <I meant the flowers.>"
    new "1. <Me refería a las flores.>"

    old "1. <But your hands are quite pretty too, now that you mention it.>"
    new "1. <Pero tus manos también son muy bonitas, ahora que lo mencionas.>"

    old "1. <What are you whispering about now?>"
    new "1. <¿Qué están susurrando ahora?>"

    old "1. <So soon?>"
    new "1. <¿Tan pronto?>"

    old "1. <Off to steal souls, then?>"
    new "1. <¿Te vas a robar almas, entonces?>"

    old "1. <Better get to work before you get in trouble, my little reaper.>"
    new "1. <Mejor ponte a trabajar antes de que te metas en problemas, mi parquita.>"

    old "1. <Since right now.>"
    new "1. <Desde este momento.>"

    old "1. <Don't be damaging my goods, you hear?>"
    new "1. <No dañes mis cosas, ¿me oyes?>"

    old "1. <Do be careful.>"
    new "1. <Ten cuidado.>"

    old "1. <Hey, Casper...> {font=gui/Kembang.ttf}{size=30}o{/size}{/font}"
    new "1. <Oye, Casper...> {font=gui/Kembang.ttf}{size=30}o{/size}{/font}"

    old "1. <I wish we had a few \nmore days together.> {font=gui/Kembang.ttf}{size=30}o{/size}{/font}"
    new "1. <Ojalá pudiéramos pasar \nunos días más juntos.> {font=gui/Kembang.ttf}{size=30}o{/size}{/font}"
    
    old "2. <Desperate for my attention, are we?>"
    new "2. <¿Desesperado por mi atención, verdad?>"

    old "2. <I was trying to embody your attitude.>"
    new "2. <Estaba tratando de imitar tu actitud.>"

    old "2. <The cold is my greatest enemy.>"
    new "2. <El frío es mi mayor enemigo.>"

    old "2. <I thought you'd never ask.>"
    new "2. <Pensaba que nunca me lo pedirías.>"

    old "2. <Fall.>"
    new "2. <Otoño.>"

    old "2. <Pretty colors everywhere I look!>"
    new "2. <¡Bonitos colores en todas partes!>"

    old "2. <I don't usually like touching much, but with you...>"
    new "2. <Normalmente no me gusta el contacto físico, pero contigo...>"

    old "2. <I crave it.>"
    new "2. <Lo deseo con todas mis fuerzas.>"

    old "2. <You're adventurous today!>"
    new "2. <¡Hoy estás muy atrevido!>"

    old "2. <Flirt away, Grim.>"
    new "2. <Coquetea todo lo que quieras, Parca.>"

    old "2. <Are you feeling okay?>"
    new "2. <¿Te sientes bien?>"

    old "2. <Want to meet my family, do you?>"
    new "2. <¿Quieres conocer a mi familia, verdad?>"

    old "2. <I'm something of a black sheep in my family.>"
    new "2. <Soy una especie de oveja negra en mi familia.>"

    old "2. <I'm just not ready to talk about it yet.>"
    new "2. <Todavía no soy capaz de hablar de eso.>"

    old "2. <I wouldn't mind seeing them a little less sometimes, haha.>"
    new "2. <No me importaría verlos un poco menos a veces, jaja.>"

    old "2. <Sounds kinda nice, don't you think?>"
    new "2. <Suena bastante bien, ¿no crees?>"

    old "2. <I'd be too scared to live completely alone.>"
    new "2. <Me daría demasiado miedo vivir completamente a solas.>"

    old "2. <Sounds like a dream come true, that's why.>"
    new "2. <Suena como un sueño hecho realidad, por eso.>"

    old "2. <We don't live too far apart.>"
    new "2. <No vivimos muy lejos el uno del otro.>"

    old "2. <More room for collectibles!>"
    new "2. <¡Más espacio para coleccionables!>"

    old "2. <Sadly I don't see them that much these days.>"
    new "2. <Lamentablemente, no los veo mucho últimamente.>"

    old "2. <Guess thats what happens when you move away.>"
    new "2. <Supongo que eso es lo que sucede cuando te alejas.>"

    old "2. <House prices are too high back home.>"
    new "2. <Los precios de las casas son demasiado altos en mi país.>"

    old "2. <Not really.>"
    new "2. <No precisamente.>"

    old "2. <Not anymore, anyway.>"
    new "2. <Ya no, en cualquier caso.>"

    old "2. <It's kind of a recent thing.>"
    new "2. <Es algo bastante reciente.>"

    old "2. <We weren't close, but it's still been hard.>"
    new "2. <No teníamos una relación cercana, pero aun así ha sido difícil.>"

    old "2. <I don't like living alone much.>"
    new "2. <No me gusta mucho la vida solitaria.>"

    old "2. <Thanks for being considerate.>"
    new "2. <Gracias por ser considerado.>"

    old "2. <They were already that color.>"
    new "2. <Ya eran de ese color.>"

    old "2. <And I couldn't be bothered to repaint, you know?>"
    new "2. <Y no me apetecía volver a pintar, ¿sabes?>"

    old "2. <I've got two Moms, actually.>"
    new "2. <Tengo dos mamás, en realidad.>"

    old "2. <I wasn't too bad, all things considered.>"
    new "2. <No me fue tan mal, considerando todas las circunstancias.>"

    old "2. <They're not in the picture.>"
    new "2. <No aparece en la foto.>"

    old "2. <Yep! He's amazing!>"
    new "2. <¡Síp! ¡Elle es increíble!>"

    old "2. <Damn, you totally just foiled all my plans.>"
    new "2. <Maldita sea, solo frusas todos mis planes.>"

    old "2. <Maybe the two of us are soul mates? :D> {font=gui/starthings.ttf}a{/font}"
    new "2. <¿Quizás los dos somos almas gemelas? :D> {font=gui/starthings.ttf}a{/font}"

    old "2. <Apparently they were like academic rivals or something.>"
    new "2. <Al parecer, eran como rivales en lo académico o algo así.>"

    old "2. <Woah, the sudden confidence is making me nervous.>"
    new "2. <Woah, tanta confianza repentina está poniendo mis nervios de punta.>"

    old "2. <I can't wait to see which one you pick.>"
    new "2. <No puedo esperar para ver cuál eliges.>"

    old "2. <I can give you some recommendations.>"
    new "2. <Puedo darte algunas recomendaciones.>"

    old "2. <I do not!>"
    new "2. <¡No lo hago!>"

    old "2. <I really don't think you should read those->"
    new "2. <Realmente no creo que debas leer esos->"

    old "2. <And I didn't have many friends.>"
    new "2. <Y no tenía muchos amigos.>"

    old "2. <I've never been bothered by it.>"
    new "2. <Nunca me ha molestado eso.>"

    old "2. <I do, yeah!>"
    new "2. <¡Sí, claro!>"

    old "2. <He's the best.>"
    new "2. <Él es el mejor.>"

    old "2. <I've got brothers.>"
    new "2. <Tengo hermanos.>"

    old "2. <She's my role model.>"
    new "2. <Ella es mi modelo a seguir.>"

    old "2. <They're the best.>"
    new "2. <Elle es lo mejor.>"

    old "2. <You really are troublesome.>"
    new "2. <Realmente eres problemático.>"

    old "2. <There's no one like that in my life, Grim.>"
    new "2. <No hay nadie así en mi vida, Parca.>"

    old "2. <I keep telling you I like you :D>"
    new "2. <Te sigo diciendo que me gustas :D>"

    old "2. <I enjoy your company.>"
    new "2. <Disfruto de tu compañía.>"

    old "2. <Well, yes.>"
    new "2. <Bueno, sí.>"

    old "2. <But I turned them down.>"
    new "2. <Pero los rechacé.>"

    old "2. <I just didn't want to be with them.>"
    new "2. <Simplemente no quería estar con esos.>"

    old "2. <If I have to answer, so do you.>"
    new "2. <Si tengo que responder, tú también.>"

    old "2. <The right.>"
    new "2. <Derecho.>"

    old "2. <I'll take the right.>"
    new "2. <Tomaré la derecha.>"

    old "2. <It was cute in a weird way.>"
    new "2. <Fue linda, pero de una manera rara.>"

    old "2. <It's hilarious, if you ask me.>"
    new "2. <Es gracioso, si me lo preguntas.>"

    old "2. <And it certainly got my attention, that's for sure.>"
    new "2. <Y sin duda llamó mi atención, eso es seguro.>"

    old "2. <I knew you would be!>"
    new "2. <¡Sabía que lo serías!>"

    old "2. <Oh, my mistake. I must be remembering wrong, huh?>"
    new "2. <Oh, mi error. Debo estar recordando mal, ¿eh?>"

    old "2. <I'm still being sarcastic.>"
    new "2. <Todavía estoy hablando con sarcasmo.>"

    old "2. <You'd {i}kill{/i} them???>"
    new "2. <¿¿¿Los {i}matarías{/i}???>"

    old "2. <Since when do reapers have shells, btw?>"
    new "2. <Por cierto, ¿desde cuándo las parcas tienen caparazones?>"

    old "2. <You're my favorite idiot, did you know that?>"
    new "2. <Eres mi idiota favorito, ¿lo sabías?>"

    old "2. <So you're like one of those ninja tortoises, then?>"
    new "2. <¿Entonces eres como una de esas tortugas ninja?>"

    old "2. <I didn't know you were a ninja expert, Grim.>"
    new "2. <No sabía que eras un experto en ninjas, Parca.>"

    old "2. <Yeah I guessed as much.>"
    new "2. <Sí, eso me imaginaba.>"

    old "2. <Not at all. Ninjas are kinda cool, and you're...>"
    new "2. <Para nada. Los ninjas son geniales, y tú eres...>"

    old "2. <Wow, someone missed me. You called so suddenly!>"
    new "2. <Wow, alguien me extrañaba. ¡Me llamaste de repente!>"

    old "2. <It's cute, coming from you.>"
    new "2. <Es lindo viniendo de ti.>"

    old "2. <Boss me around, pretty please?>"
    new "2. <Mándame, por favorcito.>"

    old "2. <Nope! I stand by what I said!>"
    new "2. <¡Nop! Mantengo lo que dije!>"

    old "2. <That's SO boring.>"
    new "2. <Eso es TAN aburrido.>"

    old "2. <'Please treat me gently' look.>"
    new "2. <Esa mirada de 'por favor, sé gentil'.>"

    old "2. <I couldn't disagree more.>"
    new "2. <No podría estar más en desacuerdo.>"

    old "2. <You're my precious babygirl.>"
    new "2. <Eres mi preciosa babygirl.>"

    old "2. <You called me so suddenly! Did you miss my \nface that much?>"
    new "2. <¡Me llamaste tan de repente! ¿Extrañabas tanto mi \nrostro?>"

    old "2. <Mean, but fair.>"
    new "2. <Cruel, pero justo.>"

    old "2. <It's already been decided!>"
    new "2. <¡Ya está decidido!>"

    old "2. <Lucky is a bit much...>"
    new "2. <Afortunado es exagerar un poco...>"

    old "2. <Looking at you?>"
    new "2. <¿Mirándote a ti?>"

    old "2. <Someone's being nosy.>"
    new "2. <Alguien está siendo entrometido.>"

    old "2. <Such a bossy boy.>"
    new "2. <Qué chico tan mandón.>"

    old "2. <Unfortunately, I imagine you'd be right.>"
    new "2. <Lamentablemente, imagino que tienes razón.>"

    old "2. <I can still picture the first time I was drunk.>"
    new "2. <Aún puedo recordar la primera vez que me emborraché.>"

    old "2. <I could be!>"
    new "2. <¡Podría serlo!>"

    old "2. <Maybe I'll go for a walk or something?>"
    new "2. <¿Tal vez salga a caminar o algo así?>"

    old "2. <Get some nice tea.>"
    new "2. <Tomar un buen té.>"

    old "2. <I can't picture you wearing anything else.>"
    new "2. <No puedo imaginarte usando otra cosa.>"

    old "2. <I bet it'd be funny.>"
    new "2. <Apuesto a que sería divertido.>"

    old "2. <Long sleeves all the way.>"
    new "2. <Mangas largas, sin duda.>"

    old "2. <Did it disconnect?>"
    new "2. <¿Se desconectó?>"

    old "2. <You coulda said bye!>"
    new "2. <¡Podrías haber dicho adiós!>"

    old "2. <Woof woof...>"
    new "2. <Guau guau...>"

    old "2. <Aaaaah?>"
    new "2. <¿Aaaaah?>"

    old "2. <A very cute one...>"
    new "2. <Uno muy lindo...>"

    old "2. <Not flustered one bit.>"
    new "2. <Sin perder la calma en absoluto.>"

    old "2. <Just stop talking for a minute.>"
    new "2. <Solo deja de hablar por un minuto.>"

    old "2. <This doesn't make sense...>"
    new "2. <Esto no tiene sentido...>"

    old "2. <No..?>"
    new "2. <¿No..?>"

    old "2. <Silly me, of course.>"
    new "2. <Tonto de mí, por supuesto.>"

    old "2. <Why not something a little more cute?>"
    new "2. <¿Por qué no algo un poco más lindo?>"

    old "2. <You aren't?>"
    new "2. <¿No lo eres?>"

    old "2. <What... why?>"
    new "2. <¿Qué... por qué?>"

    old "2. <It really means a lot to me...>"
    new "2. <Realmente significa mucho para mí...>"

    old "2. <Will you stay out there?>"
    new "2. <¿Te quedarás ahí fuera?>"

    old "2. <Then please, do come in.>"
    new "2. <Entonces, por favor, entra.>"

    old "2. <If you change your mind...>"
    new "2. <Si cambias de opinión...>"

    old "2. <I quite like it that way.>"
    new "2. <Me gusta bastante así.>"

    old "2. <{i}Don't open the window.{/i}>"
    new "2. <{i}No abrir la ventana.{/i}>"

    old "2. <{i}Open the window completely.{/i}>"
    new "2. <{i}Abrir la ventana por completo.{/i}>"

    old "2. <{i}Keep the window closed.{/i}>"
    new "2. <{i}Mantener la ventana cerrada.{/i}>"

    old "2. <Maybe.>"
    new "2. <Tal vez.>"

    old "2. <{i}Don't open it... yet.{/i}>"
    new "2. <{i}No abrirla... todavía.{/i}>"

    old "2. <{i}Open with a smirk on your face.{i}>"
    new "2. <{i}Abrirla con una sonrisa burlona.{i}>"

    old "2. <Two more days and your soul is mine, anyway.>"
    new "2. <De todos modos, en dos días tu alma será mía.>"

    old "2. <Nevermind...>"
    new "2. <Olvídalo...>"

    old "3. <Aww, did you miss me?>"
    new "3. <Aww, ¿me extrañaste?>"

    old "3. <Hey, if you want to.>"
    new "3. <Oye, si tú quieres.>"

    old "3. <I've thought about it a little.>"
    new "3. <Lo he pensado un poco.>"

    old "3. <The touch of death... I wouldn't mind it.>"
    new "3. <El toque de la muerte... no me importaría.>"

    old "3. <Winter.>"
    new "3. <Invierno.>"

    old "3. <Why not. That sounds fun.>"
    new "3. <Por qué no. Suena divertido.>"

    old "3. <I don't really like talking about my family.>"
    new "3. <Realmente no me gusta hablar de mi familia.>"

    old "3. <Because then I can wake up and tease you in person.>"
    new "3. <Porque así podré despertarme y burlarme de ti en persona.>"

    old "3. <Things are getting a little cramped here.>"
    new "3. <Las cosas se están poniendo un poco apretadas aquí.>"

    old "3. <I moved away for work.>"
    new "3. <Me mudé por motivos laborales.>"

    old "3. <And I already liked that color. It's a win-win really.>"
    new "3. <Y ya me gustaba ese color. Es realmente un beneficio mutuo.>"

    old "3. <I've got two Dads!>"
    new "3. <¡Tengo dos papás!>"

    old "3. <I was practically an angel. Definitely.>"
    new "3. <Yo era prácticamente un ángel. Definitivamente.>"

    old "3. <Yep! They're amazing!>"
    new "3. <¡Síp! ¡Elle es increíble!>"

    old "3. <Grim... I think I might die if you do that.>"
    new "3. <Parca... Creo que podría morir si haces eso.>"

    old "3. <I've got a sister.>"
    new "3. <Tengo una hermana.>"

    old "3. <There is someone, but he isn't 'mortal'.> {font=gui/starthings.ttf}a{/font}"
    new "3. <Hay alguien, pero no es 'mortal'.> {font=gui/starthings.ttf}a{/font}"

    old "3. <No, you didn't.>"
    new "3. <No, no lo hiciste.>"

    old "3. <I'm taking the whole bed.> {font=gui/starthings.ttf}a{/font}"
    new "3. <Me quedo con toda la cama.> {font=gui/starthings.ttf}a{/font}"

    old "3. <You are so obvious sometimes, it's sweet.>"
    new "3. <A veces eres tan obvio, es dulce.>"

    old "3. <You did! I screenshot the messages to look at later!> {font=gui/starthings.ttf}a{/font}"
    new "3. <¡Lo hiciste! ¡Hice una captura de pantalla de los mensajes para verlos más tarde!> {font=gui/starthings.ttf}a{/font}"

    old "3. <There are plenty of animals with shells, you know?>"
    new "3. <Hay muchos animales con caparazón, ¿sabes?>"

    old "3. <'Tell me what to do, I'll be a good reaper for you.'>"
    new "3. <'Dime qué hacer, seré una buena parca para ti.'>"

    old "3. <Wow. You sure are an exciting guy, huh.>"
    new "3. <Wow. Sí que eres un tipo emocionante, ¿eh?>"

    old "3. <Nawww, you care about me enough to\n ask about my day.> {font=gui/starthings.ttf}a{/font}"
    new "3. <Awww, te preocupas por mí lo suficiente\n como para preguntar por mi día.> {font=gui/starthings.ttf}a{/font}"

    old "3. <Alright, Mr Insistent.>"
    new "3. <Está bien, Señor insistente.>"

    old "3. <Have one of those delicious hot chocolates.>"
    new "3. <Tomar uno de esos deliciosos chocolates calientes.>"

    old "3. <Honestly, I think I'll stay at home.>"
    new "3. <Sinceramente, creo que me quedaré en casa.>"

    old "3. <I have a cute little nightie.>"
    new "3. <Tengo un camisón pequeño y lindo.>"

    old "3. <Oi Grim, what's going on?>"
    new "3. <Oye, Parca, ¿qué está pasando?>"

    old "3. <Oh, great, now I'm seeing things.>"
    new "3. <Oh, genial, ahora estoy viendo cosas.>"

    old "3. <One that is kinda sexy...>"
    new "3. <Uno que es algo sexy...>"

    old "3. <It's just real warm in here.>"
    new "3. <Es solo que hace mucho calor aquí.>"

    old "3. <You're staring too much...>"
    new "3. <Estás mirando demasiado...>"

    old "4. <Someone's interested in me.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Alguien está interesado en mí.> {font=gui/starthings.ttf}a{/font}"

    old "4. <God, please???> {font=gui/starthings.ttf}a{/font}"
    new "4. <Dios, ¿¿¿por favor???> {font=gui/starthings.ttf}a{/font}"

    old "4. <You'd have to ask veeeery nicely.>"
    new "4. <Tendrías que pedírmelo muuuuy amablemente.>"

    old "4. <If you were here right now, I'd ask you to.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Si estuvieras aquí ahora mismo, te lo pediría.> {font=gui/starthings.ttf}a{/font}"

    old "4. <Spring.>"
    new "4. <Primavera.>"

    old "4. <I don't mind if you ask me questions about them.>"
    new "4. <No me molesta que me hagas preguntas sobre ellos.>"

    old "4. <I want a garden, actually.>"
    new "4. <Quiero un jardín, en realidad.>"

    old "4. <I just needed a change.>"
    new "4. <Solo necesitaba un cambio.>"

    old "4. <My Mom raised me alone.>"
    new "4. <Mi mamá me crió sola.>"

    old "4. <How about we stick to me doing the reading???>"
    new "4. <¿¿¿Qué tal si nos limitamos a que yo haga la lectura???>"

    old "4. <I have sisters.>"
    new "4. <Tengo hermanas.>"

    old "4. <Find myself a nice drink.>"
    new "4. <Buscar una buena bebida.>"

    old "4. <To be honest, I don't sleep in any pajamas.>"
    new "4. <Sinceramente, no duermo en pijama.>"

    old "4. <No goodbyes today, Grim?> {font=gui/starthings.ttf}a{/font}"
    new "4. <No hay despedidas hoy, ¿Parca?> {font=gui/starthings.ttf}a{/font}"

    old "4. <I just... didn't expect the compliment.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Es solo que... no esperaba el cumplido.> {font=gui/starthings.ttf}a{/font}"

    old "4. <This is like Peter Pan, isn't it?> {font=gui/starthings.ttf}a{/font}"
    new "4. <Esto es como Peter Pan, ¿no?> {font=gui/starthings.ttf}a{/font}"

    old "5. <My Dad raised me by himself.>"
    new "5. <Mi papá me crió solo.>"

    old "5. <I have a sibling.>"
    new "5. <Tengo un hermane.>"

    old "6. <My older sibling raised me, actually.>"
    new "6. <Uno de mis hermanos mayores me crió, en realidad.>"

    old "6. <I have siblings.>"
    new "6. <Tengo hermanos.>"

    old "7. <I have a brother and a sister.>"
    new "7. <Tengo un hermano y una hermana.>"

    old "8. <I have {i}lots{/i} of brothers and sisters.>"
    new "8. <Tengo {i}muchos{/i} hermanos y hermanas.>"

    old "don't touch my mortal."
    new "no toques a mi mortal."

    old "Type in your favorite color."
    new "Escribe tu color favorito."


