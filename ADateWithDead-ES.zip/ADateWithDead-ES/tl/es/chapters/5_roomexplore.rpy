
# game/chapters/5_roomexplore.rpyc:213
translate es bed_hub5_bd2d672a:

    # "You collapse on your bed, sprawling out on your back and staring towards the ceiling."
    "Te desplomas sobre la cama, te tumbas boca arriba y te quedas mirando al techo."

# game/chapters/5_roomexplore.rpyc:214
translate es bed_hub5_8d721e8e:

    # "Today was a long day."
    "Hoy ha sido un día muy largo."

# game/chapters/5_roomexplore.rpyc:215
translate es bed_hub5_254c8d9f:

    # "However, now you're going on vacation!"
    "¡Pero ahora te vas de vacaciones!"

# game/chapters/5_roomexplore.rpyc:216
translate es bed_hub5_d5526558:

    # "...Kind of."
    "...Más o menos."

# game/chapters/5_roomexplore.rpyc:217
translate es bed_hub5_17b2cea9:

    # "You decided to take the next couple of days off from work. You don't have any particular plans, but..."
    "Has decidido tomarte los próximos días libres en el trabajo. No tienes ningún plan en particular, pero..."

# game/chapters/5_roomexplore.rpyc:218
translate es bed_hub5_67ad3fc1:

    # "You thought that if you were going to have your soul reaped, you didn't want to spend the last hours of your life 'working for the man', so to speak."
    "Piensas que si te van a arrebatar el alma, no quieres pasar las últimas horas de tu vida 'trabajando como un burro', por así decirlo."

# game/chapters/5_roomexplore.rpyc:219
translate es bed_hub5_e315eae9:

    # "Though you were staying at home this time, you..."
    "Aunque esta vez te quedaste en casa, tú..."

# game/chapters/5_roomexplore.rpyc:225
translate es bed_hub5_019316ea:

    # "You love traveling around the world, and you've visited lots of different countries."
    "Te encanta viajar por todo el mundo y has visitado muchos países diferentes."

# game/chapters/5_roomexplore.rpyc:226
translate es bed_hub5_4b005878:

    # "You're looking forward to spending a few days at home, though."
    "Sin embargo, estás deseando pasar unos días en casa."

# game/chapters/5_roomexplore.rpyc:229
translate es bed_hub5_dacc0f6e:

    # "There's loads of beautiful places to go without even leaving the country, and you take full advantage of that."
    "Hay un montón de lugares hermosos a los que ir sin siquiera salir del país, y tú aprovechas eso al máximo."

# game/chapters/5_roomexplore.rpyc:230
translate es bed_hub5_4b005878_1:

    # "You're looking forward to spending a few days at home, though."
    "Sin embargo, estás deseando pasar unos días en casa."

# game/chapters/5_roomexplore.rpyc:233
translate es bed_hub5_81c31a77:

    # "There's so much beauty hidden nearby, and you try your best to discover it."
    "Hay tanta belleza escondida cerca, y tú haces todo lo posible por descubrirla."

# game/chapters/5_roomexplore.rpyc:234
translate es bed_hub5_4b005878_2:

    # "You're looking forward to spending a few days at home, though."
    "Sin embargo, estás deseando pasar unos días en casa."

# game/chapters/5_roomexplore.rpyc:237
translate es bed_hub5_bf383c40:

    # "You're not really into traveling. The packing, the airports, lugging your suitcase around, travel time... you'd much rather stay at home."
    "No te gusta mucho viajar. Hacer las maletas, los aeropuertos, cargar con la maleta, el tiempo de viaje... Prefieres quedarte en casa."

# game/chapters/5_roomexplore.rpyc:238
translate es bed_hub5_3d49d53e:

    # "You're looking forward to spending a few days at home once again."
    "Estás deseando pasar unos días en casa otra vez."

# game/chapters/5_roomexplore.rpyc:240
translate es bed_hub5_a461b6de:

    # "You hope it'll give you some time to work out all of your feelings."
    "Esperas que eso te dé tiempo para aclarar todos tus sentimientos."

# game/chapters/5_roomexplore.rpyc:249
translate es door_hub5_bbd8e42a:

    # "You hear footsteps from the hallway. You wonder if it's your neighbors again?"
    "Oyes pasos en el pasillo. ¿Te preguntas si serán tus vecinos otra vez?"

# game/chapters/5_roomexplore.rpyc:255
translate es door_hub5_75742b08:

    # "Putting your ear to the door, you hear a knock at the apartment next to yours."
    "Al pegar la oreja a tu puerta, se oye que llaman a la puerta del apartamento contiguo al tuyo."

# game/chapters/5_roomexplore.rpyc:256
translate es door_hub5_415788f9:

    # "There's a pause... ten seconds go by, then thirty, then it's been a minute before you even realize it."
    "Hay una pausa... pasan diez segundos, luego treinta, y de repente te das cuenta de que ha pasado un minuto."

# game/chapters/5_roomexplore.rpyc:257
translate es door_hub5_8f1d1fdc:

    # "No one answers the door."
    "Nadie responde a la puerta."

# game/chapters/5_roomexplore.rpyc:258
translate es door_hub5_2ee1af2e:

    # "You hear a sigh in the hallway beyond."
    "Oyes un suspiro en el pasillo."

# game/chapters/5_roomexplore.rpyc:259
translate es door_hub5_595e1278:

    # "'Are you in there?' a deep voice starts, but it's much quieter than usual."
    "'¿Estás ahí?', dice una voz grave, pero mucho más tranquila de lo habitual."

# game/chapters/5_roomexplore.rpyc:260
translate es door_hub5_21eb83d2:

    # "'Sorry. For taking off like that last night.'"
    "'Lo siento. Por irme así anoche.'"

# game/chapters/5_roomexplore.rpyc:261
translate es door_hub5_6721d39c:

    # "'And for... not answering your texts.'"
    "'Y por... no responder a tus mensajes.'"

# game/chapters/5_roomexplore.rpyc:262
translate es door_hub5_427fbb4b:

    # "That voice, which you've come to know as calm and composed, sounds strained. Vulnerable."
    "Esa voz, que has llegado a conocer como tranquila y serena, suena tensa. Vulnerable."

# game/chapters/5_roomexplore.rpyc:263
translate es door_hub5_8ce6ad38:

    # "'I didn't mean to worry you,' the voice continues, 'but I needed some time alone. Something's been on my mind, and I didn't want to burden you with it.'"
    "'No quería preocuparte', continúa la voz, 'pero necesitaba tener un rato a solas. Tenía algo en la cabeza y no quería agobiarte con ello.'"

# game/chapters/5_roomexplore.rpyc:264
translate es door_hub5_fbab5138:

    # "'I've never been very good at talking to you about things. Not that you'd know that...'"
    "'Nunca se me ha dado bien hablar contigo de ciertas cosas. Aunque tú no lo sabes...'"

# game/chapters/5_roomexplore.rpyc:265
translate es door_hub5_70dd419d:

    # "The hallway falls silent for a moment, broken only by the sound of distant traffic."
    "El pasillo se queda en silencio por un momento, solo roto por el sonido lejano del tráfico."

# game/chapters/5_roomexplore.rpyc:266
translate es door_hub5_cb7d7d73:

    # "'I've been keeping something from you. Something I didn't want to share... but that's never gone well for either of us.'"
    "'Te he estado ocultando algo. Algo que no quería compartir... pero eso nunca nos ha ido bien a ninguno de los dos.'"

# game/chapters/5_roomexplore.rpyc:267
translate es door_hub5_ff2bfcf9:

    # "'So... I know you don't want to talk right now, but... you can come find me, and I'll tell you everything.'"
    "'Así que... sé que ahora mismo no quieres hablar, pero... puedes venir a buscarme y te lo contaré todo.'"

# game/chapters/5_roomexplore.rpyc:268
translate es door_hub5_6b039993:

    # "'When you're ready, and only if you want to.'"
    "'Cuando estés listo, y solo si tú quieres.'"

# game/chapters/5_roomexplore.rpyc:269
translate es door_hub5_161ed0a7:

    # "Silence again. You keep listening quietly, but that door never opens."
    "De nuevo silencio. Sigues escuchando en calma, pero esa puerta nunca se abre."

# game/chapters/5_roomexplore.rpyc:270
translate es door_hub5_9fdc1945:

    # "And then the same voice rises for the final time."
    "Y entonces la misma voz se eleva por última vez."

# game/chapters/5_roomexplore.rpyc:271
translate es door_hub5_bd999c78:

    # "'I really want to change. I really want to... get things right, just this once.'"
    "'De verdad quiero cambiar. De verdad quiero... hacer las cosas bien, solo por esta vez.'"

# game/chapters/5_roomexplore.rpyc:272
translate es door_hub5_5ebba7d4:

    # "Footsteps. They're slow and heavy. You can almost feel the weight of their emotions in each step."
    "Pasos. Son lentos y pesados. Casi puedes sentir el peso de sus emociones en cada paso."

# game/chapters/5_roomexplore.rpyc:273
translate es door_hub5_955dc319:

    # "And then all is quiet."
    "Y luego todo está tranquilo."

# game/chapters/5_roomexplore.rpyc:287
translate es door_hub5_75742b08_1:

    # "Putting your ear to the door, you hear a knock at the apartment next to yours."
    "Y entonces todo queda en silencio."

# game/chapters/5_roomexplore.rpyc:288
translate es door_hub5_415788f9_1:

    # "There's a pause... ten seconds go by, then thirty, then it's been a minute before you even realize it."
    "Hay una pausa... pasan diez segundos, luego treinta, y de repente te das cuenta de que ha pasado un minuto."

# game/chapters/5_roomexplore.rpyc:289
translate es door_hub5_8f1d1fdc_1:

    # "No one answers the door."
    "Nadie responde a la puerta."

# game/chapters/5_roomexplore.rpyc:290
translate es door_hub5_2ee1af2e_1:

    # "You hear a sigh in the hallway beyond."
    "Oyes un suspiro en el pasillo."

# game/chapters/5_roomexplore.rpyc:291
translate es door_hub5_595e1278_1:

    # "'Are you in there?' a deep voice starts, but it's much quieter than usual."
    "'¿Estás ahí?', dice una voz grave, pero mucho más tranquila de lo habitual."

# game/chapters/5_roomexplore.rpyc:292
translate es door_hub5_21eb83d2_1:

    # "'Sorry. For taking off like that last night.'"
    "'Lo siento. Por irme así anoche.'"

# game/chapters/5_roomexplore.rpyc:293
translate es door_hub5_6721d39c_1:

    # "'And for... not answering your texts.'"
    "'Y por... no responder a tus mensajes.'"

# game/chapters/5_roomexplore.rpyc:294
translate es door_hub5_427fbb4b_1:

    # "That voice, which you've come to know as calm and composed, sounds strained. Vulnerable."
    "Esa voz, que has llegado a conocer como tranquila y serena, suena tensa. Vulnerable."

# game/chapters/5_roomexplore.rpyc:295
translate es door_hub5_8ce6ad38_1:

    # "'I didn't mean to worry you,' the voice continues, 'but I needed some time alone. Something's been on my mind, and I didn't want to burden you with it.'"
    "'No quería preocuparte', continúa la voz, 'pero necesitaba tener un rato a solas. Tenía algo en la cabeza y no quería agobiarte con ello.'"

# game/chapters/5_roomexplore.rpyc:296
translate es door_hub5_fbab5138_1:

    # "'I've never been very good at talking to you about things. Not that you'd know that...'"
    "'Nunca se me ha dado bien hablar contigo de ciertas cosas. Aunque tú no lo sabes...'"

# game/chapters/5_roomexplore.rpyc:297
translate es door_hub5_0b36b90a:

    # "The hallway falls silent for a moment, broken only by the sound of distant honking."
    "El pasillo se queda en silencio por un momento, solo roto por el sonido lejano del tráfico."

# game/chapters/5_roomexplore.rpyc:298
translate es door_hub5_cb7d7d73_1:

    # "'I've been keeping something from you. Something I didn't want to share... but that's never gone well for either of us.'"
    "'Te he estado ocultando algo. Algo que no quería compartir... pero eso nunca nos ha ido bien a ninguno de los dos.'"

# game/chapters/5_roomexplore.rpyc:299
translate es door_hub5_ff2bfcf9_1:

    # "'So... I know you don't want to talk right now, but... you can come find me, and I'll tell you everything.'"
    "'Así que... sé que ahora mismo no quieres hablar, pero... puedes venir a buscarme y te lo contaré todo.'"

# game/chapters/5_roomexplore.rpyc:300
translate es door_hub5_6b039993_1:

    # "'When you're ready, and only if you want to.'"
    "'Cuando estés listo, y solo si tú quieres.'"

# game/chapters/5_roomexplore.rpyc:301
translate es door_hub5_161ed0a7_1:

    # "Silence again. You keep listening quietly, but that door never opens."
    "De nuevo silencio. Sigues escuchando en calma, pero esa puerta nunca se abre"

# game/chapters/5_roomexplore.rpyc:302
translate es door_hub5_9fdc1945_1:

    # "And then the same voice rises for the final time."
    "Y entonces la misma voz se eleva por última vez."

# game/chapters/5_roomexplore.rpyc:303
translate es door_hub5_bd999c78_1:

    # "'I really want to change. I really want to... get things right, just this once.'"
    "'De verdad quiero cambiar. De verdad quiero... hacer las cosas bien, solo por esta vez.'"

# game/chapters/5_roomexplore.rpyc:304
translate es door_hub5_5ebba7d4_1:

    # "Footsteps. They're slow and heavy. You can almost feel the weight of their emotions in each step."
    "Pasos. Son lentos y pesados. Casi puedes sentir el peso de sus emociones en cada paso."

# game/chapters/5_roomexplore.rpyc:305
translate es door_hub5_955dc319_1:

    # "And then all is quiet."
    "Y luego todo está tranquilo."

# game/chapters/5_roomexplore.rpyc:316
translate es door_hub5_3d403dd1:

    # "The hallway beyond is silent."
    "El pasillo del otro lado está en silencio."

# game/chapters/5_roomexplore.rpyc:317
translate es door_hub5_4c3f06da:

    # "You hope the two will work things out... and that you'll be able to listen in tomorrow."
    "Esperas que los dos resuelvan sus problemas... y que mañana puedas escuchar la conversación."

# game/chapters/5_roomexplore.rpyc:331
translate es snake_hub5_037e1abb:

    # "[pet_name] is out on your bed for the moment."
    "[pet_name] está en tu cama por el momento."

# game/chapters/5_roomexplore.rpyc:332
translate es snake_hub5_d5d9113c:

    # "You set down next to [pet_her2] and think back on your history with pets."
    "Te sientas junto a [pet_she!t] y recuerdas tu historia con las mascotas."

# game/chapters/5_roomexplore.rpyc:338
translate es snake_hub5_7a7efc1e:

    # "You didn't have any other pets growing up, but that didn't bother you."
    "No tuviste otras mascotas mientras crecías, pero eso no te molestaba."

# game/chapters/5_roomexplore.rpyc:342
translate es snake_hub5_b8d22d27:

    # "She was a very good cat, and loved treats and sunbaking."
    "Era una gata muy buena, le encantaban las golosinas y tomar el sol."

# game/chapters/5_roomexplore.rpyc:346
translate es snake_hub5_b0ae547a:

    # "He was a fantastic dog. You used to go to the beach together."
    "Era un perro fantástico. Solían ir juntos a la playa."

# game/chapters/5_roomexplore.rpyc:350
translate es snake_hub5_2730ee45:

    # "They were fun, and you enjoyed their colorful shells."
    "Eran divertidos y te gustaban sus caparazones de colores."

# game/chapters/5_roomexplore.rpyc:352
translate es snake_hub5_179ede57:

    # "You smile down at [pet_name]. You're very happy to have [pet_her2] in your life."
    "Sonríes a [pet_name]. Estás muy feliz de que [pet_she!t] forme parte de tu vida."

# game/chapters/5_roomexplore.rpyc:353
translate es snake_hub5_c9a5d9de:

    # "Earlier today, [pet_name] was looking a little ill - but has totally perked up after spending a little time around you."
    "Hoy temprano, [pet_name] parecía encontrarse un poco mal, pero se ha animado mucho después de pasar un rato contigo."

# game/chapters/5_roomexplore.rpyc:354
translate es snake_hub5_89161ccd:

    # "Strange."
    "Extraño."

# game/chapters/5_roomexplore.rpyc:359
translate es snake_hub5_29a291b1:

    # "You quickly snap a picture of [pet_name]."
    "Rápidamente, le sacas una foto a [pet_name]."

# game/chapters/5_roomexplore.rpyc:360
translate es snake_hub5_0abb0ea8:

    # "You probably have a hundred identical ones, but that didn't matter."
    "Probablemente, tengas cien fotos idénticas, pero eso no importa."

# game/chapters/5_roomexplore.rpyc:361
translate es snake_hub5_833b24a4:

    # "[pet_Her] scales are shining especially bright today."
    "Hoy sus escamas brillan con especial intensidad."

# game/chapters/5_roomexplore.rpyc:373
translate es bingus_hub5_cb699838:

    # "[pet_name] is sitting on your bed, relaxing."
    "[pet_name] está en tu cama, relajándose."

# game/chapters/5_roomexplore.rpyc:374
translate es bingus_hub5_d5d9113c:

    # "You set down next to [pet_her2] and think back on your history with pets."
    "Te sientas junto a [pet_she!t] y recuerdas tu historia con las mascotas."

# game/chapters/5_roomexplore.rpyc:380
translate es bingus_hub5_7a7efc1e:

    # "You didn't have any other pets growing up, but that didn't bother you."
    "No tuviste otras mascotas mientras crecías, pero eso no te molestaba."

# game/chapters/5_roomexplore.rpyc:384
translate es bingus_hub5_b8d22d27:

    # "She was a very good cat, and loved treats and sunbaking."
    "Era una gata muy buena, le encantaban las golosinas y tomar el sol."

# game/chapters/5_roomexplore.rpyc:388
translate es bingus_hub5_b0ae547a:

    # "He was a fantastic dog. You used to go to the beach together."
    "Era un perro fantástico. Solían ir juntos a la playa."

# game/chapters/5_roomexplore.rpyc:392
translate es bingus_hub5_2730ee45:

    # "They were fun, and you enjoyed their colorful shells."
    "Eran divertidos y te gustaban sus caparazones de colores."

# game/chapters/5_roomexplore.rpyc:394
translate es bingus_hub5_179ede57:

    # "You smile down at [pet_name]. You're very happy to have [pet_her2] in your life."
    "Sonríes a [pet_name]. Estás muy feliz de que [pet_she!t] forme parte de tu vida."

# game/chapters/5_roomexplore.rpyc:395
translate es bingus_hub5_c9a5d9de:

    # "Earlier today, [pet_name] was looking a little ill - but has totally perked up after spending a little time around you."
    "Hoy temprano, [pet_name] parecía encontrarse un poco mal, pero se ha animado mucho después de pasar un rato contigo."

# game/chapters/5_roomexplore.rpyc:396
translate es bingus_hub5_89161ccd:

    # "Strange."
    "Extraño."

# game/chapters/5_roomexplore.rpyc:402
translate es bingus_hub5_29a291b1:

    # "You quickly snap a picture of [pet_name]."
    "Rápidamente, le sacas una foto a [pet_name]."

# game/chapters/5_roomexplore.rpyc:403
translate es bingus_hub5_0abb0ea8:

    # "You probably have a hundred identical ones, but that didn't matter."
    "Probablemente, tengas cien fotos idénticas, pero eso no importa."

# game/chapters/5_roomexplore.rpyc:404
translate es bingus_hub5_24b275ff:

    # "[pet_Her] skin is looking especially smooth today."
    "Hoy su piel luce especialmente suave."

# game/chapters/5_roomexplore.rpyc:417
translate es bunny_hub5_037e1abb:

    # "[pet_name] is out on your bed for the moment."
    "[pet_name] está en tu cama por el momento."

# game/chapters/5_roomexplore.rpyc:418
translate es bunny_hub5_d5d9113c:

    # "You set down next to [pet_her2] and think back on your history with pets."
    "Te sientas junto a [pet_she!t] y recuerdas tu historia con las mascotas."

# game/chapters/5_roomexplore.rpyc:424
translate es bunny_hub5_7a7efc1e:

    # "You didn't have any other pets growing up, but that didn't bother you."
    "No tuviste otras mascotas mientras crecías, pero eso no te molestaba."

# game/chapters/5_roomexplore.rpyc:428
translate es bunny_hub5_b8d22d27:

    # "She was a very good cat, and loved treats and sunbaking."
    "Era una gata muy buena, le encantaban las golosinas y tomar el sol."

# game/chapters/5_roomexplore.rpyc:432
translate es bunny_hub5_b0ae547a:

    # "He was a fantastic dog. You used to go to the beach together."
    "Era un perro fantástico. Solían ir juntos a la playa."

# game/chapters/5_roomexplore.rpyc:436
translate es bunny_hub5_2730ee45:

    # "They were fun, and you enjoyed their colorful shells."
    "Eran divertidos y te gustaban sus caparazones de colores."

# game/chapters/5_roomexplore.rpyc:438
translate es bunny_hub5_179ede57:

    # "You smile down at [pet_name]. You're very happy to have [pet_her2] in your life."
    "Sonríes a [pet_name]. Estás muy feliz de que [pet_she!t] forme parte de tu vida."

# game/chapters/5_roomexplore.rpyc:439
translate es bunny_hub5_c9a5d9de:

    # "Earlier today, [pet_name] was looking a little ill - but has totally perked up after spending a little time around you."
    "Hoy temprano, [pet_name] parecía encontrarse un poco mal, pero se ha animado mucho después de pasar un rato contigo."

# game/chapters/5_roomexplore.rpyc:440
translate es bunny_hub5_89161ccd:

    # "Strange."
    "Extraño."

# game/chapters/5_roomexplore.rpyc:446
translate es bunny_hub5_29a291b1:

    # "You quickly snap a picture of [pet_name]."
    "Rápidamente, le sacas una foto a [pet_name]."

# game/chapters/5_roomexplore.rpyc:447
translate es bunny_hub5_0abb0ea8:

    # "You probably have a hundred identical ones, but that didn't matter."
    "Probablemente, tengas cien fotos idénticas, pero eso no importa."

# game/chapters/5_roomexplore.rpyc:448
translate es bunny_hub5_680d566a:

    # "[pet_Her] fur is looking especially soft today."
    "Su pelaje se ve especialmente suave hoy"

# game/chapters/5_roomexplore.rpyc:461
translate es cat_hub5_77b29e59:

    # "[pet_name] is sleeping on your bed for the moment."
    "[pet_name] está durmiendo en tu cama por el momento."

# game/chapters/5_roomexplore.rpyc:462
translate es cat_hub5_d5d9113c:

    # "You set down next to [pet_her2] and think back on your history with pets."
    "Te sientas junto a [pet_she!t] y recuerdas tu historia con las mascotas."

# game/chapters/5_roomexplore.rpyc:468
translate es cat_hub5_7a7efc1e:

    # "You didn't have any other pets growing up, but that didn't bother you."
    "No tuviste otras mascotas mientras crecías, pero eso no te molestaba."

# game/chapters/5_roomexplore.rpyc:472
translate es cat_hub5_b8d22d27:

    # "She was a very good cat, and loved treats and sunbaking."
    "Era una gata muy buena, le encantaban las golosinas y tomar el sol."

# game/chapters/5_roomexplore.rpyc:476
translate es cat_hub5_b0ae547a:

    # "He was a fantastic dog. You used to go to the beach together."
    "Era un perro fantástico. Solían ir juntos a la playa."

# game/chapters/5_roomexplore.rpyc:480
translate es cat_hub5_2730ee45:

    # "They were fun, and you enjoyed their colorful shells."
    "Eran divertidos y te gustaban sus caparazones de colores."

# game/chapters/5_roomexplore.rpyc:482
translate es cat_hub5_179ede57:

    # "You smile down at [pet_name]. You're very happy to have [pet_her2] in your life."
    "Sonríes a [pet_name]. Estás muy feliz de que [pet_she!t] forme parte de tu vida."

# game/chapters/5_roomexplore.rpyc:483
translate es cat_hub5_c9a5d9de:

    # "Earlier today, [pet_name] was looking a little ill - but has totally perked up after spending a little time around you."
    "Hoy temprano, [pet_name] parecía encontrarse un poco mal, pero se ha animado mucho después de pasar un rato contigo."

# game/chapters/5_roomexplore.rpyc:484
translate es cat_hub5_89161ccd:

    # "Strange."
    "Extraño."

# game/chapters/5_roomexplore.rpyc:490
translate es cat_hub5_29a291b1:

    # "You quickly snap a picture of [pet_name]."
    "Rápidamente, le sacas una foto a [pet_name]."

# game/chapters/5_roomexplore.rpyc:491
translate es cat_hub5_0abb0ea8:

    # "You probably have a hundred identical ones, but that didn't matter."
    "Probablemente, tengas cien fotos idénticas, pero eso no importa."

# game/chapters/5_roomexplore.rpyc:492
translate es cat_hub5_680d566a:

    # "[pet_Her] fur is looking especially soft today."
    "Su pelaje se ve especialmente suave hoy."

# game/chapters/5_roomexplore.rpyc:505
translate es dog_hub5_08ed904d:

    # "[pet_name] is hanging out on your bed at the moment."
    "[pet_name] está pasando el rato en tu cama en este momento."

# game/chapters/5_roomexplore.rpyc:506
translate es dog_hub5_d5d9113c:

    # "You set down next to [pet_her2] and think back on your history with pets."
    "Te sientas junto a [pet_she!t] y recuerdas tu historia con las mascotas."

# game/chapters/5_roomexplore.rpyc:512
translate es dog_hub5_7a7efc1e:

    # "You didn't have any other pets growing up, but that didn't bother you."
    "No tuviste otras mascotas mientras crecías, pero eso no te molestaba."

# game/chapters/5_roomexplore.rpyc:516
translate es dog_hub5_b8d22d27:

    # "She was a very good cat, and loved treats and sunbaking."
    "Era una gata muy buena, le encantaban las golosinas y tomar el sol."

# game/chapters/5_roomexplore.rpyc:520
translate es dog_hub5_b0ae547a:

    # "He was a fantastic dog. You used to go to the beach together."
    "Era un perro fantástico. Solían ir juntos a la playa."

# game/chapters/5_roomexplore.rpyc:524
translate es dog_hub5_2730ee45:

    # "They were fun, and you enjoyed their colorful shells."
    "Eran divertidos y te gustaban sus caparazones de colores."

# game/chapters/5_roomexplore.rpyc:526
translate es dog_hub5_179ede57:

    # "You smile down at [pet_name]. You're very happy to have [pet_her2] in your life."
    "Sonríes a [pet_name]. Estás muy feliz de que [pet_she!t] forme parte de tu vida."

# game/chapters/5_roomexplore.rpyc:527
translate es dog_hub5_c9a5d9de:

    # "Earlier today, [pet_name] was looking a little ill - but has totally perked up after spending a little time around you."
    "Hoy temprano, [pet_name] parecía encontrarse un poco mal, pero se ha animado mucho después de pasar un rato contigo."

# game/chapters/5_roomexplore.rpyc:528
translate es dog_hub5_89161ccd:

    # "Strange."
    "Extraño."

# game/chapters/5_roomexplore.rpyc:534
translate es dog_hub5_29a291b1:

    # "You quickly snap a picture of [pet_name]."
    "Rápidamente, le sacas una foto a [pet_name]."

# game/chapters/5_roomexplore.rpyc:535
translate es dog_hub5_0abb0ea8:

    # "You probably have a hundred identical ones, but that didn't matter."
    "Probablemente, tengas cien fotos idénticas, pero eso no importa."

# game/chapters/5_roomexplore.rpyc:536
translate es dog_hub5_680d566a:

    # "[pet_Her] fur is looking especially soft today."
    "Su pelaje se ve especialmente suave hoy."

# game/chapters/5_roomexplore.rpyc:548
translate es hamster_hub5_037e1abb:

    # "[pet_name] is out on your bed for the moment."
    "[pet_name] está en tu cama por el momento."

# game/chapters/5_roomexplore.rpyc:549
translate es hamster_hub5_d5d9113c:

    # "You set down next to [pet_her2] and think back on your history with pets."
    "Te sientas junto a [pet_she!t] y recuerdas tu historia con las mascotas."

# game/chapters/5_roomexplore.rpyc:555
translate es hamster_hub5_7a7efc1e:

    # "You didn't have any other pets growing up, but that didn't bother you."
    "No tuviste otras mascotas mientras crecías, pero eso no te molestaba."

# game/chapters/5_roomexplore.rpyc:559
translate es hamster_hub5_b8d22d27:

    # "She was a very good cat, and loved treats and sunbaking."
    "Era una gata muy buena, le encantaban las golosinas y tomar el sol."

# game/chapters/5_roomexplore.rpyc:563
translate es hamster_hub5_b0ae547a:

    # "He was a fantastic dog. You used to go to the beach together."
    "Era un perro fantástico. Solían ir juntos a la playa."

# game/chapters/5_roomexplore.rpyc:567
translate es hamster_hub5_2730ee45:

    # "They were fun, and you enjoyed their colorful shells."
    "Eran divertidos y te gustaban sus caparazones de colores."

# game/chapters/5_roomexplore.rpyc:569
translate es hamster_hub5_179ede57:

    # "You smile down at [pet_name]. You're very happy to have [pet_her2] in your life."
    "Sonríes a [pet_name]. Estás muy feliz de que [pet_she!t] forme parte de tu vida."

# game/chapters/5_roomexplore.rpyc:570
translate es hamster_hub5_c9a5d9de:

    # "Earlier today, [pet_name] was looking a little ill - but has totally perked up after spending a little time around you."
    "Hoy temprano, [pet_name] parecía encontrarse un poco mal, pero se ha animado mucho después de pasar un rato contigo."

# game/chapters/5_roomexplore.rpyc:571
translate es hamster_hub5_89161ccd:

    # "Strange."
    "Extraño."

# game/chapters/5_roomexplore.rpyc:577
translate es hamster_hub5_29a291b1:

    # "You quickly snap a picture of [pet_name]."
    "Rápidamente, le sacas una foto a [pet_name]."

# game/chapters/5_roomexplore.rpyc:578
translate es hamster_hub5_0abb0ea8:

    # "You probably have a hundred identical ones, but that didn't matter."
    "Probablemente, tengas cien fotos idénticas, pero eso no importa."

# game/chapters/5_roomexplore.rpyc:579
translate es hamster_hub5_bfdb78fe:

    # "[pet_She] is looking especially round today."
    "Hoy se ve con especial redondez."

# game/chapters/5_roomexplore.rpyc:598
translate es plant_hub5_c1229c6a:

    # "You give your little sprout a big drink of water."
    "Le das a tu pequeño retoño un buen trago de agua."

# game/chapters/5_roomexplore.rpyc:599
translate es plant_hub5_c5de961c:

    # "Though you don't speak sprout, it seems to say thank you."
    "Aunque no hablas el idioma retoño, parece que te está dando las gracias."

# game/chapters/5_roomexplore.rpyc:601
translate es plant_hub5_518e64fd:

    # "Your little sprout has grown some leaves!"
    "¡Tu pequeño retoño ha desarrollado algunas hojas!"

# game/chapters/5_roomexplore.rpyc:602
translate es plant_hub5_8036dce1:

    # "You can't help but feel proud as you give it a big drink of water."
    "No puedes evitar sentir orgullo mientras le das un buen trago de agua."

# game/chapters/5_roomexplore.rpyc:604
translate es plant_hub5_adaac543:

    # "Even more leaves have appeared now!"
    "¡Aún más hojas han aparecido ahora!"

# game/chapters/5_roomexplore.rpyc:605
translate es plant_hub5_a4970463:

    # "You water it generously and feel excited that, this time, you didn't kill your plant instantly."
    "Lo riegas generosamente y sientes emoción porque, esta vez, no mataste tu planta al instante."

# game/chapters/5_roomexplore.rpyc:607
translate es plant_hub5_2087a70f:

    # "Your little plant is growing healthily!"
    "¡Tu pequeña planta está creciendo saludablemente!"

# game/chapters/5_roomexplore.rpyc:608
translate es plant_hub5_80d209cf:

    # "You give it a big drink of water, excited about its growth."
    "Le das un buen trago de agua, con entusiasmo por su crecimiento."

# game/chapters/5_roomexplore.rpyc:610
translate es plant_hub5_41affa3b:

    # "Your little plant has sprouted some buds!"
    "¡Tu pequeña planta ha brotado algunos capullos!"

# game/chapters/5_roomexplore.rpyc:611
translate es plant_hub5_75fbf720:

    # "You almost tear up when you notice them. They're so cute - you can't wait to see what the flowers will look like."
    "Casi lloras cuando los notas. Son tan lindos, no puedes esperar a ver cómo se verán las flores."

# game/chapters/5_roomexplore.rpyc:626
translate es plant_hub5_7c26def7:

    # "The more the merrier, right?"
    "Cuantos más, mejor, ¿verdad?"

# game/chapters/5_roomexplore.rpyc:627
translate es plant_hub5_6ff6705f:

    # "You're sure that applies to watering plants, too."
    "Estás seguro de que eso también se aplica al riego de las plantas."

# game/chapters/5_roomexplore.rpyc:628
translate es plant_hub5_0b3e72ff:

    # "Absolutely."
    "Absolutamente."

# game/chapters/5_roomexplore.rpyc:642
translate es plant_hub5_e10d4d87:

    # "You're a responsible adult."
    "Eres un adulto responsable."

# game/chapters/5_roomexplore.rpyc:643
translate es plant_hub5_3896c71e:

    # "Responsible adults make their own decisions."
    "Los adultos responsables toman sus propias decisiones."

# game/chapters/5_roomexplore.rpyc:644
translate es plant_hub5_196b9f83:

    # "But these decisions are usually (hopefully) informed and reasonable."
    "Pero estas decisiones suelen estar (con suerte) informadas y razonables."

# game/chapters/5_roomexplore.rpyc:645
translate es plant_hub5_2a824992:

    # "There is nothing informed or reasonable about what you're doing."
    "No hay nada informado o razonable sobre lo que estás haciendo."

# game/chapters/5_roomexplore.rpyc:646
translate es plant_hub5_908a3374:

    # "You're making a mess."
    "Estás haciendo un desastre."

# game/chapters/5_roomexplore.rpyc:647
translate es plant_hub5_124d0ed7:

    # "You are a chaos-loving goblin."
    "Eres un duende amante del caos."

translate es strings:

    old "1. Usually go on a lot of international trips."
    new "1. Sueles hacer muchos viajes internacionales."

    old "1. [pet_name] was your first pet."
    new "1. [pet_name] fue tu primera mascota."

    old "2. Like to visit other places around the country."
    new "2. Te gusta visitar otros lugares del país."

    old "2. Your first pet was a cat named 'Cleo'."
    new "2. Tu primera mascota fue una gata llamada 'Cleo'."

    old "3. Enjoy traveling around your state."
    new "3. Disfrutas viajar por tu estado."

    old "3. Your first pet was a dog named 'Oreo'."
    new "3. Tu primera mascota fue un perro llamado 'Oreo'."

    old "4. Stay at home most of the time."
    new "4. Te quedas en casa la mayor parte del tiempo."

    old "4. Your first pets were hermit crabs!"
    new "4. ¡Tus primeras mascotas fueron cangrejos ermitaños!"

    old "Take a photo of [pet_name]."
    new "Tomar una foto de [pet_name]."

    old "{i}Affirmations{/i}"
    new "{i}Afirmaciones{/i}"

    old "You are made of love."
    new "Estás hecho de amor."

    old "No amount of fear can dissolve that, no pain destroy it, no hatred diminish it, no anguish drown it, no loneliness replace it."
    new "Ninguna cantidad de miedo puede disolverlo, ningún dolor destruirlo, ningún odio disminuirlo, ninguna angustia ahogarlo, ni la soledad reemplazarlo."

    old "You are kind, and caring, and deserve happiness."
    new "Eres amable, considerado y mereces ser feliz."

    old "You are love."
    new "Eres amor."

    old "You are capable of change, of growth."
    new "Eres capaz de cambiar, de crecer."

    old "You deserve the life you desire."
    new "Mereces la vida que deseas."

    old "You are not your mistakes or failures, and you are greater than the sum of your experiences."
    new "No eres tus errores ni tus fracasos, y eres más grande que la suma de tus experiencias."

    old "If you do not already know it, I hope you can come to love yourself."
    new "Si aún no lo sabes, espero que puedas llegar a amarte a ti mismo."

    old "Because you are everything."
    new "Porque lo eres todo."


