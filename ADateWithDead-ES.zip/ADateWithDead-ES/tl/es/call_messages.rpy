translate es strings:

    old "What is this?"
    new "¿Qué es esto?"

    old "Good!!!!"
    new "¡¡¡Bien!!!"

    old "Huh???"
    new "¿¿¿Eh???"

    old "Someone likes bets, huh?"
    new "¿Te gustan las apuestas, eh?"

    old "We'll see about that :)"
    new "Ya veremos :)"

    old "Aw, but this is so fun."
    new "Aw, pero esto es tan divertido."


    old "it's... cute."
    new "es... lindo."

    old "I'm pretty fond of being alive."
    new "Me gusta bastante estar vivo."

    old "OK STEVE."
    new "OK, STEVE."

    old "You are literally not doing that."
    new "Literalmente no estás haciendo eso."

    old "Always room for improvement."
    new "Siempre hay espacio para mejorar."

    old "omg it's so cute???"
    new "¿¿¿omg es tan lindo???"


    old "Er... well, yes."
    new "Eh... bueno, sí."

    old "You're making me worry more!"
    new "¡Me estás preocupando más!"

    old "Nothing new there..."
    new "Nada nuevo ahí..."

    old "I bet you are..."
    new "Apuesto a que sí..."

    old "Steve, at it again..."
    new "Steve, otra vez con lo mismo..."

    old "Get some rest, please."
    new "Descansa un poco, por favor."


    old "I want to see you pout."
    new "Quiero verte hacer pucheros."

    old "You can't stop me."
    new "No puedes detenerme."

    old "That's... sad, actually."
    new "Eso... es triste, en realidad."

    old "TEEHEE????"
    new "¿¿¿¿JEJEJE????"

    old "Then it's working ;)"
    new "Entonces está funcionando ;)"

    old "I... did too."
    new "Yo... también lo hice."


    old "Someone's struuuuggling~"
    new "Alguien está luchandooo~"

    old "It's very wrinkly, though."
    new "Aunque está muy arrugado."


    old "How???"
    new "¿¿¿Cómo???"

    old "Oh, tell me more :0"
    new "Oh, cuéntame más :0"

    old "You think I'm special :D"
    new "¿Piensas que soy especial :D?"

    old "I don't doooo that."
    new "Yo no hagoooo eso."

    old "Mighty suspicious, Casper."
    new "Muy sospechoso, Casper."

    old "I want to perceive you."
    new "Quiero percibirte."


    old "A cute little Casper puddle :D"
    new "Un lindo Casper chiquito :D"

    old "Maybe if you say please ;)"
    new "Tal vez si dices por favor ;)"

    old "Shut up pipsqueak."
    new "Cállate, chiquitín."

    old "I didn't ask :0"
    new "No pregunté :0"

    old "Are you saying it's true?"
    new "¿Estás diciendo que es verdad?"

    old "How you...?"
    new "¿Cómo tú...?"


    old "Awww, you dream about me?"
    new "Awww, ¿sueñas conmigo?"

    old "You are pretty great <3"
    new "Eres bastante genial <3"

    old "He looooves you."
    new "Te amaaaaaa."

    old "Thanks for sharing it with me."
    new "Gracias por compartirlo conmigo."

    old "Neverrrrr!"
    new "¡Nuncaaaa!"

    old "I did, actually."
    new "Sí lo hice, en realidad."

    old "More like the smelliest."
    new "Más bien el más apestoso."

    old "Grim + nuggets = happy"
    new "Parca + nuggets = feliz"

    old "It's the brainrot, Grimmy."
    new "Es el brainrot, Parquita."

    old "'Nearly' everyone ;)"
    new "'Casi' todos ;)"

    old "I like you for you, Casper."
    new "Me gustas tal como eres, Casper."

    old "What, why???"
    new "¿Qué, por qué???"

    old "Guilty. As. Charged."
    new "Culpable. Tal. Como. Acusado."

    old "OK, white bread boy."
    new "OK, chico soso."


translate es strings:

    old "{b}Grim Reaper:{/b} Testing. Testing. Is This Working?"
    new "{b}La Parca:{/b} Probando. Probando. ¿Esto Funciona?"

    old "{b}[playername]:{/b} [day1_flag1_response[0]]"
    new "{b}[playername!t]:{/b} [day1_flag1_response[0]]"

    old "{b}Grim Reaper:{/b} Is It Not Obvious? You Can Type And Text At The Same Time."
    new "{b}La Parca:{/b} ¿No Es Obvio? Puedes Escribir Y Enviar Mensajes Al Mismo Tiempo."

    old "{b}Grim Reaper{/b}: You Are Actually Making Me Feel A Little Guilty..."
    new "{b}La Parca{/b}: En Realidad Me Estás Haciendo Sentir Un Poco Culpable..."

    old "{b}[playername]:{/b} [day1_flag3_response[0]]"
    new "{b}[playername!t]:{/b} [day1_flag3_response[0]]"

    old "{b}Grim Reaper{/b}: Allow Me To Go Perish. Thank You."
    new "{b}La Parca{/b}: Permíteme Ir A Perecer. Gracias."

    old "{b}[playername]:{/b} [day1_flag4_response[0]]"
    new "{b}[playername!t]:{/b} [day1_flag4_response[0]]"

    old "{b}Grim Reaper{/b}: consider my interest piqued."
    new "{b}La Parca{/b}: considera que has despertado mi interés."

    old "{b}[playername]:{/b} [day1_flag5_response[0]]"
    new "{b}[playername!t]:{/b} [day1_flag5_response[0]]"

    old "{b}Grim Reaper{/b}: perhaps i do, yes."
    new "{b}La Parca{/b}: quizás sí, efectivamente."

    old "{b}Grim Reaper{/b}: you will regret this deal, mortal."
    new "{b}La Parca{/b}: lamentarás este trato, mortal."

    old "{b}[playername]:{/b} [day1_flag7_response[0]]"
    new "{b}[playername!t]:{/b} [day1_flag7_response[0]]"

    old "{b}Grim Reaper{/b}: off to bed, immediately."
    new "{b}La Parca{/b}: a la cama, inmediatamente."

    old "{b}[playername]:{/b} [day1_flag8_response[0]]"
    new "{b}[playername!t]:{/b} [day1_flag8_response[0]]"



    old "{b}Grim Reaper:{/b} i am fond of this one... {font=gui/NotoSansJP-VariableFont_wght.ttf}ヾ{/font}{font=gui/NotoSans-Light.ttf}( ˃ᴗ˂ ){/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}ツ • *{/font}{font=gui/Kelvinch-Roman.otf}✰{/font}"
    new "{b}La Parca:{/b} me gusta este... {font=gui/NotoSansJP-VariableFont_wght.ttf}ヾ{/font}{font=gui/NotoSans-Light.ttf}( ˃ᴗ˂ ){/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}ツ • *{/font}{font=gui/Kelvinch-Roman.otf}✰{/font}"

    old "{b}[playername]:{/b} [day2_flag1_response[0]]"
    new "{b}[playername!t]:{/b} [day2_flag1_response[0]]"

    old "{b}Grim Reaper:{/b} thank you. i am well aware."
    new "{b}La Parca:{/b} gracias. lo sé muy bien."

    old "{b}Grim Reaper{/b}: honestly, life is overrated."
    new "{b}La Parca{/b}: sinceramente, la vida está sobrevalorada."

    old "{b}[playername]:{/b} [day2_flag3b_response[0]]"
    new "{b}[playername!t]:{/b} [day2_flag3b_response[0]]"

    old "{b}Grim Reaper{/b}: please, don't subject me to these nicknames any longer..."
    new "{b}La Parca{/b}: por favor, no me pongas más esos apodos..."

    old "{b}[playername]:{/b} [day2_flag4b_response[0]]"
    new "{b}[playername!t]:{/b} [day2_flag4b_response[0]]"

    old "{b}Grim Reaper{/b}: i am stuffing my ears. lalala. i cannot hear you."
    new "{b}La Parca{/b}: me estoy tapando los oídos. lalala. no puedo escucharte."

    old "{b}[playername]:{/b} [day2_flag5b_response[0]]"
    new "{b}[playername!t]:{/b} [day2_flag5b_response[0]]"

    old "{b}Grim Reaper{/b}: lalalala."
    new "{b}La Parca{/b}: lalalala."

    old "{b}Grim Reaper{/b}: i... i can bathe myself perfectly enough already!"
    new "{b}La Parca{/b}: ¡ya... ya puedo bañarme perfectamente por mí mismo!"

    old "{b}[playername]:{/b} [day2_flag7b_response[0]]"
    new "{b}[playername!t]:{/b} [day2_flag7b_response[0]]"

    old "{b}Grim Reaper{/b}: oh... oh no..."
    new "{b}La Parca{/b}: oh... oh no..."

    old "{b}[playername]:{/b} [day2_flag8b_response[0]]"
    new "{b}[playername!t]:{/b} [day2_flag8b_response[0]]"



    old "{b}Grim Reaper:{/b} i swear, you don't listen PURPOSEFULLY."
    new "{b}La Parca:{/b} lo juro, no escuchas a PROPÓSITO."

    old "{b}[playername]:{/b} [day3_flag1_response[0]]"
    new "{b}[playername!t]:{/b} [day3_flag1_response[0]]"

    old "{b}Grim Reaper:{/b} you are not meant to admit to it. what am i supposed to do with you???"
    new "{b}La Parca:{/b} no estás destinado a admitirlo. ¿¿¿qué se supone que debo hacer contigo???"

    old "{b}Grim Reaper{/b}: it's... nothing personal. sorry."
    new "{b}La Parca{/b}: no es... nada personal. lo siento."

    old "{b}[playername]:{/b} [day3_flag3b_response[0]]"
    new "{b}[playername!t]:{/b} [day3_flag3b_response[0]]"

    old "{b}Grim Reaper{/b}: i told you. now you look somewhat foolish, don't you?"
    new "{b}La Parca{/b}: te lo dije. ahora actuas algo ridículo, ¿no?"

    old "{b}[playername]:{/b} [day3_flag4b_response[0]]"
    new "{b}[playername!t]:{/b} [day3_flag4b_response[0]]"

    old "{b}Grim Reaper{/b}: i'm just a little sensitive, okay???"
    new "{b}La Parca{/b}: solo soy un poco sensible, ¿¿¿vale???"

    old "{b}[playername]:{/b} [day3_flag5b_response[0]]"
    new "{b}[playername!t]:{/b} [day3_flag5b_response[0]]"

    old "{b}Grim Reaper{/b}: what??? i didn't mean... i meant my eyes! my eyes!"
    new "{b}La Parca{/b}: ¿¿¿qué??? no quise decir... ¡me refería a mis ojos! ¡mis ojos!"

    old "{b}Grim Reaper{/b}: there is no one better on your plane or mine than i. i am everything people should strive to be."
    new "{b}La Parca{/b}: no hay nadie mejor en tu plano o en el mío que yo. soy todo lo que la gente debería aspirar a ser."

    old "{b}[playername]:{/b} [day3_flag7b_response[0]]"
    new "{b}[playername!t]:{/b} [day3_flag7b_response[0]]"

    old "{b}Grim Reaper{/b}: but... thank you. um. i appreciate it."
    new "{b}La Parca{/b}: pero... gracias. eh. lo aprecio."

    old "{b}[playername]:{/b} [day3_flag8b_response[0]]"
    new "{b}[playername!t]:{/b} [day3_flag8b_response[0]]"


    old "{b}Grim Reaper:{/b} what are you talking about???"
    new "{b}La Parca:{/b} ¿¿¿de qué estás hablando???"

    old "{b}[playername]:{/b} [day4_flag1_response[0]]"
    new "{b}[playername!t]:{/b} [day4_flag1_response[0]]"

    old "{b}Grim Reaper:{/b} WHY???"
    new "{b}La Parca:{/b} ¿¿¿POR QUÉ???"

    old "{b}Grim Reaper{/b}: don't even think about using this to your advantage."
    new "{b}La Parca{/b}: ni se te ocurra usar esto a tu favor."

    old "{b}[playername]:{/b} [day4_flag3b_response[0]]"
    new "{b}[playername!t]:{/b} [day4_flag3b_response[0]]"

    old "{b}Grim Reaper{/b}: you need not concern yourself over my loneliness. that is part of being a reaper."
    new "{b}La Parca{/b}: no necesitas preocuparte por mi soledad. eso es parte de ser una parca."

    old "{b}[playername]:{/b} [day4_flag4b_response[0]]"
    new "{b}[playername!t]:{/b} [day4_flag4b_response[0]]"

    old "{b}Grim Reaper{/b}: whoopsies. teehee."
    new "{b}La Parca{/b}: uupsies. jejeje."

    old "{b}[playername]:{/b} [day4_flag5b_response[0]]"
    new "{b}[playername!t]:{/b} [day4_flag5b_response[0]]"

    old "{b}Grim Reaper{/b}: um... yes. sorry."
    new "{b}La Parca{/b}: eh... sí. lo siento."

    old "{b}Grim Reaper{/b}: you mess with my mind and my heart."
    new "{b}La Parca{/b}: juegas con mi mente y mi corazón."

    old "{b}[playername]:{/b} [day4_flag7b_response[0]]"
    new "{b}[playername!t]:{/b} [day4_flag7b_response[0]]"

    old "{b}Grim Reaper{/b}: i... enjoyed talking to you."
    new "{b}La Parca{/b}: yo... disfruté hablar contigo."

    old "{b}[playername]:{/b} [day4_flag8b_response[0]]"
    new "{b}[playername!t]:{/b} [day4_flag8b_response[0]]"



    old "{b}Grim Reaper:{/b} there's nothing wrong with taking my time."
    new "{b}La Parca:{/b} no hay nada de malo en tomarme mi tiempo."

    old "{b}[playername]:{/b} [day5_flag1_response[0]]"
    new "{b}[playername!t]:{/b} [day5_flag1_response[0]]"

    old "{b}Grim Reaper:{/b} i... do not struggle...! {font=gui/NotoSans-Light.ttf}(¬ _¬){/font}"
    new "{b}La Parca:{/b} ¡yo... no me esfuerzo...! {font=gui/NotoSans-Light.ttf}(¬ _¬){/font}"

    old "{b}Grim Reaper{/b}: you and your small brain."
    new "{b}La Parca{/b}: tú y tu cerebrito."

    old "{b}[playername]:{/b} [day5_flag3b_response[0]]"
    new "{b}[playername!t]:{/b} [day5_flag3b_response[0]]"

    old "{b}Grim Reaper{/b}: stay right there."
    new "{b}La Parca{/b}: quédate justo ahí."

    old "{b}[playername]:{/b} [day5_flag4b_response[0]]"
    new "{b}[playername!t]:{/b} [day5_flag4b_response[0]]"


    old "{b}Grim Reaper:{/b} yeah, you're definitely causing it."
    new "{b}La Parca:{/b} sí, definitivamente lo estás causando."

    old "{b}[playername]:{/b} [day6_flag1_response[0]]"
    new "{b}[playername!t]:{/b} [day6_flag1_response[0]]"

    old "{b}Grim Reaper:{/b} maybe you're just too radiant... i knew the nickname 'sunshine' fit you..."
    new "{b}La Parca:{/b} tal vez eres demasiado radiante... sabía que el apodo 'solecito' te quedaba bien..."

    old "{b}Grim Reaper{/b}: there are things i have been... wanting for strongly the last few days. it is infuriating."
    new "{b}La Parca{/b}: hay cosas que he estado... deseando intensamente los últimos días. es exasperante."

    old "{b}[playername]:{/b} [day6_flag3b_response[0]]"
    new "{b}[playername!t]:{/b} [day6_flag3b_response[0]]"

    old "{b}Grim Reaper{/b}: you are... rather unforgettable. i think that fact will cause me much trouble in the future."
    new "{b}La Parca{/b}: eres... bastante inolvidable. creo que eso me causará muchos problemas en el futuro."

    old "{b}[playername]:{/b} [day6_flag4b_response[0]]"
    new "{b}[playername!t]:{/b} [day6_flag4b_response[0]]"

    old "{b}Grim Reaper{/b}: the way you can jump from topic to topic is remarkable. you ought to be studied."
    new "{b}La Parca{/b}: la manera en que saltas de un tema a otro es notable. deberías estudiar."

    old "{b}[playername]:{/b} [day6_flag5b_response[0]]"
    new "{b}[playername!t]:{/b} [day6_flag5b_response[0]]"

    old "{b}Grim Reaper{/b}: oh, you really do. i doubt you and i could ever have a quiet moment."
    new "{b}La Parca{/b}: oh, realmente lo haces. dudo que tú y yo podamos tener algún momento de tranquilidad."

    old "{b}Grim Reaper{/b}: i am the same as always. nothing has changed. nope. not my feelings or anything. not at all."
    new "{b}La Parca{/b}: soy el mismo de siempre. nada ha cambiado. nop. ni mis sentimientos ni nada. para nada."

    old "{b}[playername]:{/b} [day6_flag7b_response[0]]"
    new "{b}[playername!t]:{/b} [day6_flag7b_response[0]]"

    old "{b}Grim Reaper{/b}: dear gods above, this is the most embarrassing thing i have ever done. do not perceive me."
    new "{b}La Parca{/b}: cielos, esto es lo más embarazoso que he hecho. no me percibas."

    old "{b}[playername]:{/b} [day6_flag8b_response[0]]"
    new "{b}[playername!t]:{/b} [day6_flag8b_response[0]]"



    old "{b}Grim Reaper:{/b} i am going to melt into my chair and disappear..."
    new "{b}La Parca:{/b} voy a derretirme en mi silla y desaparecer..."

    old "{b}[playername]:{/b} [day6alt_flag1_response[0]]"
    new "{b}[playername!t]:{/b} [day6alt_flag1_response[0]]"

    old "{b}Grim Reaper:{/b} a scary casper puddle... not cute...."
    new "{b}La Parca:{/b} un pequeño casper aterrador... nada lindo...."

    old "{b}Grim Reaper{/b}: i cannot accept this sickness of yours. nothing should be able to touch you, except me."
    new "{b}La Parca{/b}: no puedo aceptar esta enfermedad tuya. nada debería poder tocarte, excepto yo."

    old "{b}[playername]:{/b} [day6alt_flag3b_response[0]]"
    new "{b}[playername!t]:{/b} [day6alt_flag3b_response[0]]"

    old "{b}Grim Reaper{/b}: the definition of a question is: 'a sentence worded or expressed so as to elicit information'. what you said was a statement. i know this is a difficult concept."
    new "{b}La Parca{/b}: la definición de una pregunta es: 'una oración formulada para obtener información'. lo que dijiste fue una afirmación. sé que es un concepto difícil."

    old "{b}[playername]:{/b} [day6alt_flag4b_response[0]]"
    new "{b}[playername!t]:{/b} [day6alt_flag4b_response[0]]"

    old "{b}Grim Reaper{/b}: yes, i've always been this handsome."
    new "{b}La Parca{/b}: sí, siempre he sido así de guapo."

    old "{b}[playername]:{/b} [day6alt_flag5b_response[0]]"
    new "{b}[playername!t]:{/b} [day6alt_flag5b_response[0]]"

    old "{b}Grim Reaper{/b}: well, now you know {font=gui/NotoSans-Light.ttf}({/font}{font=gui/LinLibertine_R.ttf}` ͜ʖ´{/font}{font=gui/NotoSans-Light.ttf}){/font}"
    new "{b}La Parca{/b}: bueno, ahora lo sabes {font=gui/NotoSans-Light.ttf}({/font}{font=gui/LinLibertine_R.ttf}` ͜ʖ´{/font}{font=gui/NotoSans-Light.ttf}){/font}"

    old "{b}Grim Reaper{/b}: dear gods, you should watch what you say. you might give me a heart attack otherwise."
    new "{b}La Parca{/b}: cielos, deberías cuidar lo que dices. podrías darme un infarto si no."

    old "{b}[playername]:{/b} [day6alt_flag7b_response[0]]"
    new "{b}[playername!t]:{/b} [day6alt_flag7b_response[0]]"

    old "{b}Grim Reaper{/b}: you and i are... different. i know this, and yet i can't help how i..."
    new "{b}La Parca{/b}: tú y yo somos... diferentes. lo sé, y aun así no puedo evitar cómo yo..."
    
    old "{b}[playername]:{/b} [day6alt_flag8b_response[0]]"
    new "{b}[playername!t]:{/b} [day6alt_flag8b_response[0]]"


    old "{b}Grim Reaper:{/b} please dear gods above let this be a dream."
    new "{b}La Parca:{/b} por favor, cielos, que esto sea un sueño."

    old "{b}[playername]:{/b} [day7alt_flag1_response[0]]"
    new "{b}[playername!t]:{/b} [day7alt_flag1_response[0]]"

    old "{b}Grim Reaper:{/b} i meant nightmare. NIGHTMARE."
    new "{b}La Parca:{/b} quise decir pesadilla. PESADILLA."

    old "{b}Grim Reaper{/b}: in a way, i understand. i am just that fantastic to talk to."
    new "{b}La Parca{/b}: de alguna manera, entiendo. soy simplemente tan fantástico para hablar."

    old "{b}[playername]:{/b} [day7alt_flag3b_response[0]]"
    new "{b}[playername!t]:{/b} [day7alt_flag3b_response[0]]"

    old "{b}Grim Reaper{/b}: azrael is his own man. he goes where he wants, does what he wishes, and deigns to spend his spare moments with me."
    new "{b}La Parca{/b}: azrael es un hombre independiente. va donde quiere, hace lo que desea, y se digna a pasar sus momentos libres conmigo."

    old "{b}[playername]:{/b} [day7alt_flag4b_response[0]]"
    new "{b}[playername!t]:{/b} [day7alt_flag4b_response[0]]"

    old "{b}Grim Reaper{/b}: i never felt the passage of time as much as i do now. time passes for you, but continues for i."
    new "{b}La Parca{/b}: nunca sentí el paso del tiempo tanto como ahora. el tiempo pasa para ti, pero continúa para mí."

    old "{b}[playername]:{/b} [day7alt_flag5b_response[0]]"
    new "{b}[playername!t]:{/b} [day7alt_flag5b_response[0]]"

    old "{b}Grim Reaper{/b}: it is my pleasure. truly. i'm honestly being selfish here. mwhahaha."
    new "{b}La Parca{/b}: es un placer. de verdad. sinceramente estoy siendo egoísta aquí. mwhahaha."

    old "{b}Grim Reaper{/b}: remove this from your memory or perish, mortal."
    new "{b}La Parca{/b}: borra esto de tu memoria o perece, mortal."

    old "{b}[playername]:{/b} [day7alt_flag7b_response[0]]"
    new "{b}[playername!t]:{/b} [day7alt_flag7b_response[0]]"

    old "{b}Grim Reaper{/b}: this is... not good. not good at all."
    new "{b}La Parca{/b}: esto es... no bueno. nada bueno."
    
    old "{b}[playername]:{/b} [day7alt_flag8b_response[0]]"
    new "{b}[playername!t]:{/b} [day7alt_flag8b_response[0]]"



    old "{b}Grim Reaper:{/b} did you miss me?"
    new "{b}La Parca:{/b} ¿me extrañaste?"

    old "{b}[playername]:{/b} [day8_flag1_response[0]]"
    new "{b}[playername!t]:{/b} [day8_flag1_response[0]]"

    old "{b}Grim Reaper:{/b} ...oh. i didn't really think you'd... right. well. that's nice. very good. i may have missed you too. there's a chance. perhaps."
    new "{b}La Parca:{/b} ...oh. no pensé que lo harías... cierto. bueno. eso es agradable. muy bien. puede que yo también te haya extrañado. hay una posibilidad. quizá."

    old "{b}Grim Reaper{/b}: other reapers are boring, anyway. you have me. the most interesting one around."
    new "{b}La Parca{/b}: de todas formas, otras parcas son aburridas. me tienes a mí. el más interesante de todos."

    old "{b}[playername]:{/b} [day8_flag3b_response[0]]"
    new "{b}[playername!t]:{/b} [day8_flag3b_response[0]]"

    old "{b}Grim Reaper{/b}: though, i am a fan of your fast food. now i'm hungry..."
    new "{b}La Parca{/b}: aunque, soy fan de tu comida rápida. ahora tengo hambre..."

    old "{b}[playername]:{/b} [day8_flag4b_response[0]]"
    new "{b}[playername!t]:{/b} [day8_flag4b_response[0]]"

    old "{b}Grim Reaper{/b}: so, so many nonsensical thoughts. sometimes i worry about you. "
    new "{b}La Parca{/b}: tantos, tantos pensamientos sin sentido. a veces me preocupo por ti."

    old "{b}[playername]:{/b} [day8_flag5b_response[0]]"
    new "{b}[playername!t]:{/b} [day8_flag5b_response[0]]"

    old "{b}Grim Reaper{/b}: brainrot? an apt description for you, i would think. that would explain why you keep calling me 'babygirl' and 'pookie'."
    new "{b}La Parca{/b}: ¿brainrot? sería una descripción acertada para ti, creo. eso explicaría por qué sigues llamándome 'babygirl' y 'pookie'."

    old "{b}Grim Reaper{/b}: i... i said something along the lines of 'i hate nearly everyone'. obviously."
    new "{b}La Parca{/b}: yo... dije algo como 'odio a casi todos'. obviamente."

    old "{b}[playername]:{/b} [day8_flag7b_response[0]]"
    new "{b}[playername!t]:{/b} [day8_flag7b_response[0]]"

    old "{b}Grim Reaper{/b}: i... i could not even begin to hope to be something else... i have always been this. i... i've always loved this, until..."
    new "{b}La Parca{/b}: yo... no podría ni empezar a esperar ser otra cosa... siempre he sido así. yo... siempre he amado esto, hasta que..."

    old "{b}[playername]:{/b} [day8_flag8b_response[0]]"
    new "{b}[playername!t]:{/b} [day8_flag8b_response[0]]"



    old "{b}Grim Reaper:{/b} are you sure you are not a witch or a warlock or something similar?"
    new "{b}La Parca:{/b} ¿estás segura de que no eres una bruja o un brujo o algo similar?"

    old "{b}[playername]:{/b} [day9_flag1b_response[0]]"
    new "{b}[playername!t]:{/b} [day9_flag1b_response[0]]"

    old "{b}Grim Reaper:{/b} perhaps you have put a spell on me, and that is why i miss you so. "
    new "{b}La Parca:{/b} quizás me hayas hechizado, y por eso te extraño tanto."

    old "{b}Grim Reaper{/b}: you are the reaper version of a homewrecker. a... reaper wrecker."
    new "{b}La Parca{/b}: eres la versión parca de una rompehogares. un... rompehogares parca."

    old "{b}[playername]:{/b} [day9_flag3b_response[0]]"
    new "{b}[playername!t]:{/b} [day9_flag3b_response[0]]"

    old "{b}Grim Reaper{/b}: i feel myself growing hungry just thinking about it..."
    new "{b}La Parca{/b}: siento que me da hambre solo de pensarlo..."

    old "{b}[playername]:{/b} [day9_flag4b_response[0]]"
    new "{b}[playername!t]:{/b} [day9_flag4b_response[0]]"


    old "Messages - Grim Reaper"
    new " Mensajes - La Parca  "