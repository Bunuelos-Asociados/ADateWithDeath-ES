translate es strings:

    old "CG On Your Bed"
    new "CG En Tu Cama"

    old "CG DLC Duo Reapers Sketch"
    new "CG Boceto Dúo Parcas (DLC)"

    old "CG DLC Duo Reapers"
    new "CG Dúo Parcas (DLC)"

    old "CG Wedding Sketch"
    new "CG Boda (Boceto)"

    old "CG Wedding"
    new "CG Boda"

    old "Christmas YCH 2023 Sketch"
    new "CG Navidad YCH 2023 (Boceto)"

    old "Christmas YCH 2023"
    new "CG Navidad YCH 2023"

    old "February 2024 Patreon NSFW Preview"
    new "Vista previa NSFW Patreon Febrero 2024"

    old "Valentines 2024 Sketch"
    new "CG San Valentín 2024 (Boceto)"

    old "CG Fireworks Sketch"
    new "CG Fuegos Artificiales (Boceto)"

    old "CG Fireworks"
    new "CG Fuegos Artificiales"

    old "Kickstarter Celebration 2024"
    new "Celebración Kickstarter 2024"

    old "CG Florist Sketch"
    new "CG Florista (Boceto)"

    old "CG Florist"
    new "CG Florista"

    old "CG Bathtime Sketch"
    new "CG Hora del Baño (Boceto)"

    old "CG Bathtime"
    new "CG Hora del Baño"

    old "CG The Underworld Sketch"
    new "CG Inframundo (Boceto)"

    old "CG The Underworld"
    new "CG Inframundo"

    old "CG Goodbyes Sketch"
    new "CG Despedidas (Boceto)"

    old "CG Goodbyes"
    new "CG Despedidas"

    old "CG NSFW 1"
    new "CG NSFW 1"

    old "CG NSFW 2"
    new "CG NSFW 2"

    old "[tooltip]"
    new "[tooltip!t]"


    old "Grim Reaper Design 1"
    new "Diseño de la Parca 1"

    old "Grim Reaper Design 2"
    new "Diseño de la Parca 2"

    old "Animation Character Designs"
    new "Animación - Diseño de Personaje"

    old "Animation Storyboards"
    new "Storyboards De Animación"

    old "Sprite Sketches"
    new "Bocetos de sprites"

    old "Grim Reaper Bedroom Design"
    new "Diseño del dormitorio de la Parca"

    old "Player Bedroom Design"
    new "Diseño del dormitorio del jugador"

    old "Grim Reaper Finalized Bedroom"
    new "Dormitorio finalizado de la Parca"

    old "Grim Reaper Patreon Artwork #1"
    new "Arte #1 de la Parca (Patreon)"

    old "Grim Reaper Halloween 2023"
    new "La Parca Halloween 2023"

    old "Halloween YCH 2023 Sketch"
    new "YCH de Halloween 2023 (Boceto)"

    old "Halloween YCH 2023"
    new "YCH de Halloween 2023"

    old "Aug 2023 Patreon NSFW Preview"
    new "Vista Previa NSFW De Patreon (Ago 2023)"

    old "CG Flowers Sketches"
    new "CG Flores (Boceto)"

    old "CG Flowers"
    new "CG Flores"

    old "CG Hugging Azrael Sketch"
    new "CG Abrazando a Azrael (Boceto)"

    old "CG Hugging Azrael"
    new "CG Abrazando A Azrael"

    old "CG On Your Bed Sketches"
    new "CG En Tu Cama (Boceto)"
