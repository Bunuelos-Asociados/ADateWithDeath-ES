translate es strings:

    old "Save Your Photo"
    new "Guarda Tu Foto"

    old "IMAGE"
    new "IMAGEN"

    old "BIOGRAPHY"
    new "BIOGRAFÍA"

    old "Presets"
    new "Preajustes"

    old "Left Eye"
    new "Ojo Izq"

    old "Right Eye"
    new "Ojo Der"

    old "Pronouns"
    new "Pronombres"

    old "Gender"
    new "Género"

    old "Descriptive Words"
    new "Descripciones"

    old "NEXT PAGE"
    new "SIG PÁG"

    old "Female"
    new "Mujer"

    old "Nonbinary"
    new "No binarie"

    old "Male"
    new "Hombre"

    old "She/Her"
    new "Ella"

    old "They/Them"
    new "Elle"

    old "He/Him"
    new "Él"

    old "Custom"
    new "Personalizar"

    old "Feminine Leaning"
    new "Pref. femenina"

    old "Masculine Leaning"
    new "Pref. masculina"

    old "Neutral Leaning"
    new "Pref. neutral"

    old "Custom Leaning"
    new "Personalizar"

    old "First Name"
    new "Nombre"

    old "Last Name"
    new "Apellido"

    old "Favorite Animal"
    new "Animal favorito"

    old "PREVIOUS PAGE"
    new "ANT PÁG"

    old "Bunny"
    new "Conejo"

    old "Cat"
    new "Gato"

    old "Sphynx"
    new "Gato esfinge"

    old "Dog"
    new "Perro"

    old "Hamster"
    new "Hámster"

    old "Snake"
    new "Serpiente"

    old "Click here to input your character bio - you can update it along the way!"
    new "Haz clic aquí para introducir la biografía de tu personaje. ¡Puedes actualizarla cuando quieras!"

    old "I am a girl, and use [she]/[her]."
    new "Soy una chica y utilizo [she!t]."

    old "I am nonbinary, and use [she]/[her]."
    new "Soy no binario y utilizo [she!t]."

    old "I am a boy, and use [she]/[her]."
    new "Soy un chico y uso [she!t]."

    old "Example: She looks so cool! I'm proud of her."
    new "Ejemplo: Ella se ve tan genial. Estoy orgulloso de ella."

    old "Example: They looks so cool! I'm proud of them."
    new "Ejemplo: Elle se ve tan genial. Estoy orgulloso de elle."

    old "Example: He looks so cool! I'm proud of him."
    new "Ejemplo: ¡Él se ve tan genial! Estoy orgulloso de él."

    old "Example: [She] looks so cool! I'm proud of [her]."
    new "Ejemplo: ¡[She] se ve tan genial! Estoy orgulloso de [her]."

    old "I prefer to be called beautiful."
    new "Prefiero que me llamen guapa."

    old "I prefer to be called handsome."
    new "Prefiero que me llamen guapo."

    old "I prefer to be called captivating."
    new "Prefiero que me llamen cautivador."

    old "I prefer to be called [beautiful]."
    new "Prefiero que me llamen [beautiful]."

    old "Finish Editing"
    new "Terminar Edición"

    old "Custom Pronouns"
    new "Pronombres Personalizados"

    old "Custom Descriptive Words"
    new "Descripción Personalizada"

    old "Accept"
    new "Aceptar"