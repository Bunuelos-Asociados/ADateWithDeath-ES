translate es strings:

    old "Reinstalling..."
    new "Reinstalando..."

    old "i literally told you not to bother me???"
    new "literalmente te dije que no me molestaras???"

    old "{font=gui/8bitOperatorPlusSC-Regular.ttf}WARNING!{/font}"
    new "{font=gui/8bitOperatorPlusSC-Regular.ttf}¡ADVERTENCIA!{/font}"

    old "{font=gui/8bitOperatorPlusSC-Regular.ttf}ERROR!{/font}"
    new "{font=gui/8bitOperatorPlusSC-Regular.ttf}¡ERROR!{/font}"

    old "{font=gui/8bitOperatorPlusSC-Regular.ttf}SYSTEM MALFUNCTION!{/font}"
    new "{font=gui/8bitOperatorPlusSC-Regular.ttf}¡FALLA DEL SISTEMA!{/font}"

    old "{font=gui/8bitOperatorPlusSC-Regular.ttf}FORCE... RESTART...{/font}"
    new "{font=gui/8bitOperatorPlusSC-Regular.ttf}FORZAR... REINICIO...{/font}"

    old "Calling. Please wait."
    new "Llamando. Por favor espera."

    old "Incoming call. Accept?"
    new "Llamada entrante. ¿Aceptar?"

    old "{font=gui/8bitOperatorPlusSC-Regular.ttf}CALL ENDED{/font}"
    new "{font=gui/8bitOperatorPlusSC-Regular.ttf}LLAMADA FINALIZADA{/font}"

    old "!  New items added to Gallery  !"
    new "¡Nuevos elementos añadidos a la galería!"

    old "!  New item added to Gallery  !"
    new "¡Nuevo elemento añadido a la galería!"

    old "{fi=0-0.5}Ending 1: Untrustworthy{/fi}"
    new "{fi=0-0.5}Final 1: Desconfiable{/fi}"

    old "{fi=0-0.5}Ending 2: Despondent{/fi}"
    new "{fi=0-0.5}Final 2: Abatido{/fi}"

    old "{fi=0-0.5}Ending 3: Mine{/fi}"
    new "{fi=0-0.5}Final 3: Mío{/fi}"

    old "{fi=0-0.5}Ending 4: Duo{/fi}"
    new "{fi=0-0.5}Final 4: Dúo{/fi}"

    old "{fi=0-0.5}Ending 5: Rings{/fi}"
    new "{fi=0-0.5}Final 5: Anillos{/fi}"

    old "{fi=0-0.5}Ending 7: Forget-me-not{/fi}"
    new "{fi=0-0.5}Final 7: No me olvides{/fi}"

    old "{fi=0-0.5}Ending 6: Bloom{/fi}"
    new "{fi=0-0.5}Final 6: Floración{/fi}"

    old "{fi=0-0.5}Ending 9: Metamorphosis{/fi}"
    new "{fi=0-0.5}Final 9: Metamorfosis{/fi}"

    old "{fi=0-0.5}Ending 8: Interwoven{/fi}"
    new "{fi=0-0.5}Final 8: Entretejido{/fi}"

    old "Profile Pictures"
    new "Foto de Perfil"

    old "Username:"
    new "Usuario:"

    old "Settings"
    new "Configuración"

    old "Save"
    new "Guardar"

    old "Load"
    new "Cargar"

    old "Title"
    new "Título"

    old "Quit"
    new "Salir"

    old "QUIT"
    new "SALIR"

    old "Version [config.version!t]\n"
    new "Versión [config.version!t]\n"

    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    old "Would you like to enable Streamer Friendly mode? This will change some music."
    new "¿Quieres activar el modo Streamer Friendly? Esto cambiará parte de la música."

    old "You can change this in the settings."
    new "Puedes cambiar esto en la configuración."

    old "Display"
    new "Pantalla"

    old "Stream Safe Music"
    new "Stream Seguro"

    old "Skipping"
    new "Saltando"

    old "BGM"
    new "BGM"

    old "SFX"
    new "SFX"

    old "VA"
    new "VA"

    old "Auto"
    new "Auto"

    old "Voice Language"
    new "Idioma - Voz"

    old "Text Language"
    new "Idioma - Texto"

    old "Coming soon"
    new "Próximamente"

    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    old "Navigate the interface."
    new "Navega por la interfaz."

    old "Accesses the game menu."
    new "Accede al menú del juego."

    old "Skips dialogue while held down."
    new "Salta el diálogo mientras se mantiene presionado."

    old "Toggles dialogue skipping."
    new "Activa o desactiva el salto de diálogo."

    old "Rolls back to earlier dialogue."
    new "Retrocede al diálogo anterior."

    old "Rolls forward to later dialogue."
    new "Avanza al diálogo posterior."

    old "Hides the user interface."
    new "Oculta la interfaz de usuario."

    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa/desactiva la {a=https://www.renpy.org/l/voicing}narración automática{/a}."

    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."


    old "Return"
    new "Regresar"

    old "Hello, Sunshine!"
    new "¡Hola, Solecito!"

    old "Thank you for installing Beyond the Bet, the newest DLC expansion for A Date with Death."
    new "Gracias por instalar Beyond the Bet, la más reciente expansión DLC de A Date with Death."

    old "This expansion introduces an alternate storyline starting from Day 6, with new choices and events leading up to Day 10."
    new "Esta expansión introduce una historia alternativa que comienza desde el Día 6, con nuevas elecciones y eventos que llegan hasta el Día 10."

    old "{b}Note:{/b} Beyond the Bet is best experienced after completing the main story at least once, as it builds upon the events from the original pathway. \nHowever, if you've already completed the game before or if you’ve lost your save data, we’re giving you the option to jump straight into the new content."
    new "{b}Nota:{/b} Beyond the Bet se disfruta mejor después de completar la historia principal al menos una vez, ya que se construye sobre los eventos de la ruta original. \nSin embargo, si ya completaste el juego antes o si perdiste tus datos guardados, te damos la opción de saltar directamente al nuevo contenido."

    old "Would you like to unlock Beyond the Bet now, or unlock it after finishing the main game?"
    new "¿Quieres desbloquear Beyond the Bet ahora o después de terminar el juego principal?"

    old "How to Access {i}Beyond the Bet{/i}"
    new "Cómo acceder a {i}Beyond the Bet{/i}"

    old "Once you've completed the game at least once, you’ll have a few ways to start Beyond the Bet:"
    new "Una vez que hayas completado el juego al menos una vez, tendrás algunas formas de comenzar Beyond the Bet:"

    old "1. {b}Main Menu{/b}: Select ‘Start’ from the main menu, and you’ll be prompted with the option to jump directly to Beyond the Bet."
    new "1. {b}Menú Principal{/b}: Selecciona ‘Iniciar’ desde el menú principal y se te dará la opción de saltar directamente a Beyond the Bet."

    old "2. {b}In-Game{/b}: Play through the game normally, and when you reach the end of Day 5, choose the options marked with a flower to branch into the Beyond the Bet storyline."
    new "2. {b}Dentro del juego{/b}: Juega normalmente y, al llegar al final del Día 5, elige las opciones marcadas con una flor para entrar en la historia de Beyond the Bet."

    old "3. {b}Settings{/b}: You can also toggle Beyond the Bet on in the settings menu at any time, instead of playing through the original game."
    new "3. {b}Configuración{/b}: También puedes activar Beyond the Bet en el menú de configuración en cualquier momento, en lugar de jugar la historia original."

    old "Enjoy A Date with Death!"
    new "¡Disfruta A Date with Death!"

    old "There's a few ways to start Beyond the Bet:"
    new "Hay varias formas de comenzar Beyond the Bet:"

    old "{b}How to Access Beyond the Bet:{/b}"
    new "{b}Cómo acceder a Beyond the Bet:{/b}"

    old "1. Simply hit Start from the main menu and follow the prompts to jump into Beyond the Bet, beginning at the end of Day 5 (during the flower window scene)."
    new "1. Simplemente selecciona Iniciar en el menú principal y sigue las indicaciones para entrar en Beyond the Bet, comenzando al final del Día 5 (durante la escena de la ventana con la flor)."

    old "2. Alternatively, you can play through the first 5 days as usual, and then unlock Beyond the Bet by selecting the options marked with a flower at the end of Day 5."
    new "2. Alternativamente, puedes jugar los primeros 5 días como de costumbre y luego desbloquear Beyond the Bet seleccionando las opciones marcadas con una flor al final del Día 5."

    old "We hope you enjoy your time with Casper in Beyond the Bet!"
    new "¡Esperamos que disfrutes tu tiempo con Casper en Beyond the Bet!"

    old "Beyond the Bet"
    new "Beyond the Bet"

    old "Continue"
    new "Continuar"

    old "Windowed"
    new "Ventana"

    old "Fullscreen"
    new "Pantalla Completa"

    old "Unread Text"
    new "Texto No Leído"

    old "After Choices"
    new "Después De Elecciones"

    old "[playername]"
    new "[playername!t]"

    old "Toggle automatic messaging"
    new "Activa/desactiva avance automático"

    old "Skip"
    new "Saltar"

    old "Quick save"
    new "Guardado rápido"

    old "Quick load"
    new "Carga rápida"

    old "Show pause menu"
    new "Mostrar menú de pausa"

