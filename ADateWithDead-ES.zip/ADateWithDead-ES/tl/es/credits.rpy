translate es strings:

    old "Credits"
    new "Créditos"

    old "Developed by"
    new "Desarrollado por"

    old "Lead Developers"
    new "Desarrolladores principales"

    old "Lead Producers"
    new "Productores principales"

    old "Game Designers"
    new "Diseñadores de juego"

    old "Lead Writers"
    new "Guionistas principales"

    old "Lead Character Artist"
    new "Artista principal de personajes"

    old "Environmental Artists"
    new "Artistas ambientales"

    old "Additional Artists"
    new "Artistas adicionales"

    old "Programmers"
    new "Programadores"

    old "Lead Composer"
    new "Compositor principal"

    old "Additional Composition"
    new "Composición adicional"

    old "Graphic Designer"
    new "Diseñador gráfico"

    old "Additional Assets"
    new "Recursos adicionales"

    old "Additional Programming"
    new "Programación adicional"

    old "Patrons"
    new "Patrocinadores"

    old "...And you!"
    new "...¡Y tú!"

    old "This game is dedicated to our beautiful cat Bingus. Thank you for everything, baby boy."
    new "Este juego está dedicado a nuestro hermoso gato Bingus. Gracias por todo, pequeñín."