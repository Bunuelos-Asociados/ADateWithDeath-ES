# TODO: Translation updated at 2026-10-15 18:36

translate Spanish strings:

    # game/runner.rpy:233
    old "You lose."
    new "Perdiste."

    # game/runner.rpy:234
    old "Play again"
    new "Jugar de nuevo"

    old "Dodged: [runinstance.score]"
    new "Esquivados: [runinstance.score]"

    old "Speed: [runinstance.speed]"
    new "Velocidad: [runinstance.speed]"