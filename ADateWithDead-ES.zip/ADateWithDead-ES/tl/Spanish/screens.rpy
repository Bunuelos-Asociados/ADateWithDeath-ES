# TODO: Translation updated at 2026-10-15 18:36


translate Spanish strings:

    # game/screens.rpy:101
    old "Reinstalling..."
    new "Reinstalando..."

    # game/screens.rpy:158
    old "i literally told you not to bother me???"
    new "¿¿¿literalmente te dije que no me molestaras???"

    # game/screens.rpy:168
    old "{font=gui/8bitOperatorPlusSC-Regular.ttf}WARNING!{/font}"
    new "{font=gui/8bitOperatorPlusSC-Regular.ttf}¡ADVERTENCIA!{/font}"

    # game/screens.rpy:169
    old "{font=gui/8bitOperatorPlusSC-Regular.ttf}ERROR!{/font}"
    new "{font=gui/8bitOperatorPlusSC-Regular.ttf}¡ERROR!{/font}"

    # game/screens.rpy:170
    old "{font=gui/8bitOperatorPlusSC-Regular.ttf}SYSTEM MALFUNCTION!{/font}"
    new "{font=gui/8bitOperatorPlusSC-Regular.ttf}¡FALLA DEL SISTEMA!{/font}"

    # game/screens.rpy:171
    old "{font=gui/8bitOperatorPlusSC-Regular.ttf}FORCE... RESTART...{/font}"
    new "{font=gui/8bitOperatorPlusSC-Regular.ttf}FORZAR... REINICIO...{/font}"

    # game/screens.rpy:268
    old "Calling. Please wait."
    new "Llamando. Por favor espera."

    # game/screens.rpy:284
    old "Yes"
    new "Sí"

    # game/screens.rpy:302
    old "Incoming call. Accept?"
    new "Llamada entrante. ¿Aceptar?"

    # game/screens.rpy:312
    old "{font=gui/8bitOperatorPlusSC-Regular.ttf}CALL ENDED{/font}"
    new "{font=gui/8bitOperatorPlusSC-Regular.ttf}LLAMADA FINALIZADA{/font}"

    # game/screens.rpy:337
    old "!  New items added to Gallery  !"
    new "¡Nuevos elementos añadidos a la galería!"

    # game/screens.rpy:345
    old "!  New item added to Gallery  !"
    new "¡Nuevo elemento añadido a la galería!"

    # game/screens.rpy:441
    old "{fi=0-0.5}Ending 1: Untrustworthy{/fi}"
    new "{fi=0-0.5}Final 1: Poco confiable{/fi}"

    # game/screens.rpy:445
    old "{fi=0-0.5}Ending 2: Despondent{/fi}"
    new "{fi=0-0.5}Final 2: Abatimiento{/fi}"

    # game/screens.rpy:449
    old "{fi=0-0.5}Ending 3: Mine{/fi}"
    new "{fi=0-0.5}Final 3: Mío{/fi}"

    # game/screens.rpy:453
    old "{fi=0-0.5}Ending 4: Duo{/fi}"
    new "{fi=0-0.5}Final 4: Dúo{/fi}"

    # game/screens.rpy:457
    old "{fi=0-0.5}Ending 5: Rings{/fi}"
    new "{fi=0-0.5}Final 5: Anillos{/fi}"

    # game/screens.rpy:461
    old "{fi=0-0.5}Ending 7: Forget-me-not{/fi}"
    new "{fi=0-0.5}Final 7: No me olvides{/fi}"

    # game/screens.rpy:465
    old "{fi=0-0.5}Ending 6: Bloom{/fi}"
    new "{fi=0-0.5}Final 6: Floración{/fi}"

    # game/screens.rpy:469
    old "{fi=0-0.5}Ending 9: Metamorphosis{/fi}"
    new "{fi=0-0.5}Final 9: Metamorfosis{/fi}"

    # game/screens.rpy:473
    old "{fi=0-0.5}Ending 8: Interwoven{/fi}"
    new "{fi=0-0.5}Final 8: Entretejido{/fi}"

    # game/screens.rpy:481
    old "Profile Pictures"
    new "Fotos de perfil"

    # game/screens.rpy:581
    old "Username:"
    new "Usuario:"

    # game/screens.rpy:650
    old "Hang up disabled :)"
    new "Colgar deshabilitado :)"

    # game/screens.rpy:803
    old "choice_history"
    new "choice_history"

    # game/screens.rpy:963
    old "Toggle automatic messaging"
    new "Activa/desactiva avance automático"

    # game/screens.rpy:964
    old "Skip"
    new "Saltar"

    # game/screens.rpy:965
    old "Quick save"
    new "Guardado rápido"

    # game/screens.rpy:966
    old "Quick load"
    new "Carga rápida"

    # game/screens.rpy:967
    old "Show pause menu"
    new "Mostrar menú de pausa"

    # game/screens.rpy:1029
    old "Return"
    new "Regresar"

    # game/screens.rpy:1036
    old "Settings"
    new "Configuración"

    # game/screens.rpy:1043
    old "Save"
    new "Guardar"

    # game/screens.rpy:1050
    old "Load"
    new "Cargar"

    # game/screens.rpy:1058
    old "Title"
    new "Título"

    # game/screens.rpy:1072
    old "Quit"
    new "Salir"

    # game/screens.rpy:1143
    old "Hello, Sunshine!"
    new "¡Hola, Solecito!"

    # game/screens.rpy:1144
    old "Thank you for installing Beyond the Bet, the newest DLC expansion for A Date with Death."
    new "Gracias por instalar Beyond the Bet, la más reciente expansión DLC de A Date with Death."

    # game/screens.rpy:1145
    old "This expansion introduces an alternate storyline starting from Day 6, with new choices and events leading up to Day 10."
    new "Esta expansión introduce una historia alternativa que comienza desde el Día 6, con nuevas elecciones y eventos que llegan hasta el Día 10."

    # game/screens.rpy:1146
    old "{b}Note:{/b} Beyond the Bet is best experienced after completing the main story at least once, as it builds upon the events from the original pathway. \nHowever, if you've already completed the game before or if you’ve lost your save data, we’re giving you the option to jump straight into the new content."
    new "{b}Nota:{/b} Beyond the Bet se disfruta mejor después de completar la historia principal al menos una vez, ya que se construye sobre los eventos de la ruta original. \nSin embargo, si ya completaste el juego antes o si perdiste tus datos guardados, te damos la opción de saltar directamente al nuevo contenido."

    # game/screens.rpy:1147
    old "Would you like to unlock Beyond the Bet now, or unlock it after finishing the main game?"
    new "¿Quieres desbloquear Beyond the Bet ahora o después de terminar el juego principal?"

    # game/screens.rpy:1151
    old "Unlock Now"
    new "Desbloquear ahora"

    # game/screens.rpy:1152
    old "Not Yet"
    new "Aún no"

    # game/screens.rpy:1161
    old "How to Access {i}Beyond the Bet{/i}"
    new "Cómo acceder a {i}Beyond the Bet{/i}"

    # game/screens.rpy:1162
    old "Once you've completed the game at least once, you’ll have a few ways to start Beyond the Bet:"
    new "Una vez que hayas completado el juego al menos una vez, tendrás algunas formas de comenzar Beyond the Bet:"

    # game/screens.rpy:1163
    old "1. {b}Main Menu{/b}: Select ‘Start’ from the main menu, and you’ll be prompted with the option to jump directly to Beyond the Bet."
    new "1. {b}Menú Principal{/b}: Selecciona ‘Iniciar’ desde el menú principal y se te dará la opción de saltar directamente a Beyond the Bet."

    # game/screens.rpy:1164
    old "2. {b}In-Game{/b}: Play through the game normally, and when you reach the end of Day 5, choose the options marked with a flower to branch into the Beyond the Bet storyline."
    new "2. {b}Dentro del juego{/b}: Juega normalmente y, al llegar al final del Día 5, elige las opciones marcadas con una flor para entrar en la historia de Beyond the Bet."

    # game/screens.rpy:1165
    old "3. {b}Settings{/b}: You can also toggle Beyond the Bet on in the settings menu at any time, instead of playing through the original game."
    new "3. {b}Configuración{/b}: También puedes activar Beyond the Bet en el menú de configuración en cualquier momento, en lugar de jugar la historia original."

    # game/screens.rpy:1166
    old "Enjoy A Date with Death!"
    new "¡Disfruta A Date with Death!"

    # game/screens.rpy:1167
    old "Continue"
    new "Continuar"

    # game/screens.rpy:1177
    old "There's a few ways to start Beyond the Bet:"
    new "Hay varias formas de comenzar Beyond the Bet:"

    # game/screens.rpy:1194
    old "{b}How to Access Beyond the Bet:{/b}"
    new "{b}Cómo acceder a Beyond the Bet:{/b}"

    # game/screens.rpy:1195
    old "1. Simply hit Start from the main menu and follow the prompts to jump into Beyond the Bet, beginning at the end of Day 5 (during the flower window scene)."
    new "1. Simplemente selecciona Iniciar en el menú principal y sigue las indicaciones para entrar en Beyond the Bet, comenzando al final del Día 5 (durante la escena de la ventana con la flor)."

    # game/screens.rpy:1196
    old "2. Alternatively, you can play through the first 5 days as usual, and then unlock Beyond the Bet by selecting the options marked with a flower at the end of Day 5."
    new "2. Alternativamente, puedes jugar los primeros 5 días como de costumbre y luego desbloquear Beyond the Bet seleccionando las opciones marcadas con una flor al final del Día 5."

    # game/screens.rpy:1197
    old "We hope you enjoy your time with Casper in Beyond the Bet!"
    new "¡Esperamos que disfrutes tu tiempo con Casper en Beyond the Bet!"

    # game/screens.rpy:1539
    old "START"
    new "INICIAR"

    # game/screens.rpy:1546
    old "LOAD"
    new "CARGAR"

    # game/screens.rpy:1553
    old "SETTINGS"
    new "AJUSTES"

    # game/screens.rpy:1560
    old "GALLERY"
    new "GALERÍA"

    # game/screens.rpy:1567
    old "MUSIC"
    new "MÚSICA"

    # game/screens.rpy:1576
    old "QUIT"
    new "SALIR"

    # game/screens.rpy:1758
    old "About"
    new "Acerca de"

    # game/screens.rpy:1765
    old "Version [config.version!t]\n"
    new "Versión [config.version!t]\n"

    # game/screens.rpy:1771
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:2023
    old "Would you like to enable Streamer Friendly mode? This will change some music."
    new "¿Quieres activar el modo Streamer Friendly? Esto cambiará parte de la música."

    # game/screens.rpy:2024
    old "You can change this in the settings."
    new "Puedes cambiar esto en la configuración."

    # game/screens.rpy:2030
    old "No"
    new "No"

    # game/screens.rpy:2056
    old "Display"
    new "Pantalla"

    # game/screens.rpy:2057
    old "Stream Safe Music"
    new "Mús. para Stream"

    # game/screens.rpy:2058
    old "Skipping"
    new "Saltar texto"

    # game/screens.rpy:2060
    old "BGM"
    new "BGM"

    # game/screens.rpy:2061
    old "SFX"
    new "SFX"

    # game/screens.rpy:2062
    old "VA"
    new "VA"

    # game/screens.rpy:2063
    old "Auto"
    new "Auto"

    # game/screens.rpy:2065
    old "Voice Language"
    new "Idioma - Voz"

    # game/screens.rpy:2066
    old "Text Language"
    new "Idioma - Texto"

    # game/screens.rpy:2069
    old "Coming soon"
    new "Próximamente"

    # game/screens.rpy:2076
    old "Windowed"
    new "Ventana"

    # game/screens.rpy:2077
    old "Fullscreen"
    new "Pantalla Completa"

    # game/screens.rpy:2081
    old "On"
    new "Sí"

    # game/screens.rpy:2087
    old "Off"
    new "No"

    # game/screens.rpy:2095
    old "Unread Text"
    new "Texto No Leído"

    # game/screens.rpy:2096
    old "After Choices"
    new "Después De Elecciones"

    # game/screens.rpy:2103
    old "English"
    new "Inglés"

    # game/screens.rpy:2110
    old "Typing Sounds"
    new "Sonido de Tecleo"

    # game/screens.rpy:2128
    old "Japanese"
    new "Japonés"
    
    old "Spanish"
    new "Español"

    # game/screens.rpy:2137
    old "Mute All"
    new "Silenciar todo"

    # game/screens.rpy:2146
    old "Beyond the Bet"
    new "Beyond the Bet"

    # game/screens.rpy:2467
    old "Help"
    new "Ayuda"

    # game/screens.rpy:2476
    old "Keyboard"
    new "Teclado"

    # game/screens.rpy:2477
    old "Mouse"
    new "Ratón"

    # game/screens.rpy:2480
    old "Gamepad"
    new "Gamepad"

    # game/screens.rpy:2493
    old "Enter"
    new "Enter"

    # game/screens.rpy:2494
    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    # game/screens.rpy:2497
    old "Space"
    new "Espacio"

    # game/screens.rpy:2498
    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    # game/screens.rpy:2501
    old "Arrow Keys"
    new "Teclas de flecha"

    # game/screens.rpy:2502
    old "Navigate the interface."
    new "Navega por la interfaz."

    # game/screens.rpy:2505
    old "Escape"
    new "Esc"

    # game/screens.rpy:2506
    old "Accesses the game menu."
    new "Accede al menú del juego."

    # game/screens.rpy:2509
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:2510
    old "Skips dialogue while held down."
    new "Salta el diálogo mientras se mantiene presionado."

    # game/screens.rpy:2513
    old "Tab"
    new "Tab"

    # game/screens.rpy:2514
    old "Toggles dialogue skipping."
    new "Activa o desactiva el salto de diálogo."

    # game/screens.rpy:2517
    old "Page Up"
    new "Re Pág"

    # game/screens.rpy:2518
    old "Rolls back to earlier dialogue."
    new "Retrocede al diálogo anterior."

    # game/screens.rpy:2521
    old "Page Down"
    new "Av Pág"

    # game/screens.rpy:2522
    old "Rolls forward to later dialogue."
    new "Avanza al diálogo posterior."

    # game/screens.rpy:2526
    old "Hides the user interface."
    new "Oculta la interfaz de usuario."

    # game/screens.rpy:2530
    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    # game/screens.rpy:2534
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa/desactiva la {a=https://www.renpy.org/l/voicing}narración automática{/a}."

    # game/screens.rpy:2538
    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

    # game/screens.rpy:2544
    old "Left Click"
    new "Clic izquierdo"

    # game/screens.rpy:2548
    old "Middle Click"
    new "Clic central"

    # game/screens.rpy:2552
    old "Right Click"
    new "Clic derecho"

    # game/screens.rpy:2556
    old "Mouse Wheel Up\nClick Rollback Side"
    new "Rueda del ratón arriba\nClic en el lado de retroceso"

    # game/screens.rpy:2560
    old "Mouse Wheel Down"
    new "Rueda del ratón abajo"

    # game/screens.rpy:2567
    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nA/Botón inferior"

    # game/screens.rpy:2571
    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nBotón dorsal izquierdo"

    # game/screens.rpy:2575
    old "Right Shoulder"
    new "Botón dorsal derecho"

    # game/screens.rpy:2580
    old "D-Pad, Sticks"
    new "Cruceta, Sticks"

    # game/screens.rpy:2584
    old "Start, Guide"
    new "Start, Guía"

    # game/screens.rpy:2588
    old "Y/Top Button"
    new "Y/Botón superior"

    # game/screens.rpy:2591
    old "Calibrate"
    new "Calibrar"

    # game/screens.rpy:3020
    old "Awaiting status..."
    new "Esperando estado..."

    # game/screens.rpy:3755
    old "Back"
    new "Atrás"

    # game/screens.rpy:3758
    old "Menu"
    new "Menú"
    
    old "[tooltip]"
    new "[tooltip!t]"

