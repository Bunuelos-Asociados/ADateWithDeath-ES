﻿# TODO: Translation updated at 2026-10-15 18:36

# game/kinetic_text_tags.rpy:1
translate Spanish 6c0c3176:

    # "Kinetic Text Tags Ren'Py Module 2021 Daniel Westfall <SoDaRa2595@gmail.com>"
    "Módulo de etiquetas de texto cinético para Ren'Py, 2021. Daniel Westfall <SoDaRa2595@gmail.com>"

# game/kinetic_text_tags.rpy:1
translate Spanish 8689f4cd:

    # "http://twitter.com/sodara9 I'd appreciate being given credit if you do end up using it! :D Would really make my day to know I helped some people out! Really hope this can help the community create some really neat ways to spice up their dialogue! http://opensource.org/licenses/mit-license.php Github: https://github.com/SoDaRa/Kinetic-Text-Tags itch.io: https://wattson.itch.io/kinetic-text-tags Forum Post: https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b"
    "[http://twitter.com/sodara9](http://twitter.com/sodara9) ¡Agradecería que me dieran crédito si finalmente deciden usarlo! :D ¡Me alegraría muchísimo saber que pude ayudar a algunas personas! ¡De verdad espero que esto ayude a la comunidad a crear formas geniales de darle más vida a sus diálogos! [http://opensource.org/licenses/mit-license.php](http://opensource.org/licenses/mit-license.php) GitHub: [https://github.com/SoDaRa/Kinetic-Text-Tags](https://github.com/SoDaRa/Kinetic-Text-Tags) itch.io: [https://wattson.itch.io/kinetic-text-tags](https://wattson.itch.io/kinetic-text-tags) Publicación en el foro: [https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b](https://lemmasoft.renai.us/forums/viewtopic.php?f=51\&t=60527\&sid=75b4eb1aa5212a33cbfe9b0354e5376b)"

