# TODO: Translation updated at 2026-10-15 18:36

# game/NSFW Patch/nsfwpatch.rpy:2
translate Spanish nsfwpatch_4efe1b19:

    # "present!"
    "¡Presente!"

# game/NSFW Patch/nsfwpatch.rpy:392
translate Spanish dlcday8nsfw1_810c35e4:

    # "In the following NSFW scenes, please choose the genitals you will use:"
    "En las siguientes escenas NSFW, elige los genitales que usarás:"

# game/NSFW Patch/nsfwpatch.rpy:397
translate Spanish dlcday8nsfw1_6d0c3f3a:

    # "In future scenes, you would like to..."
    "En las próximas escenas, te gustaría..."

# game/NSFW Patch/nsfwpatch.rpy:408
translate Spanish dlcday8nsfw1_6d0c3f3a_1:

    # "In future scenes, you would like to..."
    "En las próximas escenas, te gustaría..."

# game/NSFW Patch/nsfwpatch.rpy:430
translate Spanish dlcday8nsfw1_0f58707c:

    # "{i}Your room is as you left it - the sheets are slightly rumpled, the curtains are pulled open, and the window is cracked, allowing in a warm breeze.{/i}"
    "{i}Tu habitación está tal y como la dejaste: las sábanas ligeramente arrugadas, las cortinas abiertas y la ventana entreabierta, dejando entrar una brisa cálida.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:431
translate Spanish dlcday8nsfw1_f80d5bb6:

    # "{i}You don't bother turning on the lights, as the moonlight streams through the windows. The lamps are plenty enough to set the mood.{/i}"
    "{i}No te molestas en encender las luces; la luz de la luna se cuela por las ventanas. Las lámparas bastan para crear el ambiente.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:434
translate Spanish dlcday8nsfw1_270add67:

    # "{i}As soon as the door closes behind you, you turn towards Casper.{/i}"
    "{i}En cuanto la puerta se cierra tras de ti, te giras hacia Casper.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:435
translate Spanish dlcday8nsfw1_4c833c38:

    # "{i}Without hesitation, you press a kiss to his lips.{/i}"
    "{i}Sin dudar, posas un beso en sus labios.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:436
translate Spanish dlcday8nsfw1_1b6f4605:

    # "{i}It's only a momentary thing - chaste, but lingering, and he looks a little shocked as you pull away.{/i}"
    "{i}Es solo un instante: casto, pero persistente. Él parece un poco sorprendido cuando te apartas.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:442
translate Spanish dlcday8nsfw1_34c3e59a:

    # GRC "I... you..."
    GRC "Yo... tú..."

# game/NSFW Patch/nsfwpatch.rpy:448
translate Spanish dlcday8nsfw1_008afe10:

    # GRC "..."
    GRC "..."

# game/NSFW Patch/nsfwpatch.rpy:450
translate Spanish dlcday8nsfw1_cb6a0043:

    # GRC "You are so... warm."
    GRC "Eres tan... cálid[letra]."

# game/NSFW Patch/nsfwpatch.rpy:452
translate Spanish dlcday8nsfw1_3dd5e0a0:

    # GRC "Warm, addicting, and... intoxicating."
    GRC "Cálid[letra], adictiv[letra] e... intoxicante."

# game/NSFW Patch/nsfwpatch.rpy:453
translate Spanish dlcday8nsfw1_3fb26603:

    # GRC "I am... totally and completely under your thumb."
    GRC "Estoy... total y completamente a tu merced."

# game/NSFW Patch/nsfwpatch.rpy:461
translate Spanish dlcday8nsfw1_008afe10_1:

    # GRC "..."
    GRC "..."

# game/NSFW Patch/nsfwpatch.rpy:462
translate Spanish dlcday8nsfw1_13dd6b8b:

    # GRC "Your... desire for me is... quite evident..."
    GRC "Tu... deseo por mí es... bastante evidente..."

# game/NSFW Patch/nsfwpatch.rpy:463
translate Spanish dlcday8nsfw1_0e9e60ed:

    # GRC "Not that I can rightfully say anything, the way you make me feel."
    GRC "No es que yo pueda decir nada al respecto, con lo que me haces sentir."

# game/NSFW Patch/nsfwpatch.rpy:464
translate Spanish dlcday8nsfw1_538b1dee:

    # "{i}The two of you flop down beside each other on your bed.{/i}"
    "{i}Los dos caen uno al lado del otro sobre la cama.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:466
translate Spanish dlcday8nsfw1_2de4e94f:

    # GRC "I am not the type of man who can be led easily."
    GRC "No soy el tipo de hombre que se deja llevar fácilmente."

# game/NSFW Patch/nsfwpatch.rpy:468
translate Spanish dlcday8nsfw1_0aedc11f:

    # GRC "Yet, the moment you tug me along, I am powerless to resist."
    GRC "Y, sin embargo, en el momento en que me tiras de la mano, soy incapaz de resistirme."

# game/NSFW Patch/nsfwpatch.rpy:470
translate Spanish dlcday8nsfw1_26ee3b35:

    # GRC "I am so weak to you."
    GRC "Soy tan débil ante ti."

# game/NSFW Patch/nsfwpatch.rpy:471
translate Spanish dlcday8nsfw1_3dd85e35:

    # "{i}Rays of moonlight stream down through your window, illuminating the man beside you in bed.{/i}"
    "{i}Rayos de luna se cuelan por la ventana, iluminando al hombre que yace a tu lado en la cama.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:472
translate Spanish dlcday8nsfw1_89312618:

    # "{i}He looks... otherworldly.{/i}"
    "{i}Parece... de otro mundo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:473
translate Spanish dlcday8nsfw1_dd75c8e0:

    # "{i}Which makes sense, considering he IS otherworldly.{/i}"
    "{i}Lo cual tiene sentido, considerando que realmente lo es.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:474
translate Spanish dlcday8nsfw1_d4d28775:

    # "{i}Still, the sensation takes you, seeing this beautiful, strange man in your bed.{/i}"
    "{i}Aun así, la sensación te embarga al ver a este hombre hermoso y extraño en tu cama.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:475
translate Spanish dlcday8nsfw1_360eeabf:

    # "{i}This man you've come to feel great affection for.{/i}"
    "{i}Este hombre por el que has llegado a sentir un profundo cariño.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:479
translate Spanish dlcday8nsfw1_d21b07bc:

    # GRC "Beautiful? Well, I would say I hardly compare to you."
    GRC "¿Hermoso? Bueno, yo diría que apenas puedo compararme contigo."

# game/NSFW Patch/nsfwpatch.rpy:490
translate Spanish dlcday8nsfw1_ea874250:

    # GRC "I have never thought you were ugly."
    GRC "Nunca pensé que fueras fe[letra]."

# game/NSFW Patch/nsfwpatch.rpy:492
translate Spanish dlcday8nsfw1_34c6e660:

    # GRC "From the moment I laid eyes on you, I..."
    GRC "Desde el momento en que te vi, yo..."

# game/NSFW Patch/nsfwpatch.rpy:493
translate Spanish dlcday8nsfw1_feacf034:

    # GRC "...Let's just say you have always been alluring. Menacingly so."
    GRC "...Digamos que siempre has resultado atractiv[letra]. De forma amenazante."

# game/NSFW Patch/nsfwpatch.rpy:497
translate Spanish dlcday8nsfw1_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/NSFW Patch/nsfwpatch.rpy:498
translate Spanish dlcday8nsfw1_f359bd3c:

    # GRC "I don't suppose I'll be used to that any time soon.."
    GRC "Supongo que no me acostumbraré a esto tan pronto..."

# game/NSFW Patch/nsfwpatch.rpy:500
translate Spanish dlcday8nsfw1_a7996840:

    # GRC "I... feel the same."
    GRC "Yo... siento lo mismo."

# game/NSFW Patch/nsfwpatch.rpy:501
translate Spanish dlcday8nsfw1_41692f00:

    # GRC "You are a wonderful person, Sunshine."
    GRC "Eres una persona maravillosa, Solecito."

# game/NSFW Patch/nsfwpatch.rpy:504
translate Spanish dlcday8nsfw1_44d56f37:

    # GRC "Mortal, what we do is dangerous."
    GRC "Mortal, lo que hacemos es peligroso."

# game/NSFW Patch/nsfwpatch.rpy:505
translate Spanish dlcday8nsfw1_06e024df:

    # GRC "We are not walking a fine line, we are firmly crossing it."
    GRC "No estamos andando por el filo de la navaja; lo estamos cruzando de lleno."

# game/NSFW Patch/nsfwpatch.rpy:507
translate Spanish dlcday8nsfw1_c70fecff:

    # GRC "You and I should not be... but I want us to be, terribly."
    GRC "Tú y yo no deberíamos... pero lo deseo con todas mis fuerzas."

# game/NSFW Patch/nsfwpatch.rpy:508
translate Spanish dlcday8nsfw1_e7927937:

    # GRC "My heart, my body, my mind... everything yearns for you."
    GRC "Mi corazón, mi cuerpo, mi mente... todo te anhela."

# game/NSFW Patch/nsfwpatch.rpy:509
translate Spanish dlcday8nsfw1_c9004031:

    # GRC "Your touch, your voice, even your god forsaken teasing."
    GRC "Tu tacto, tu voz, incluso tus malditas provocaciones."

# game/NSFW Patch/nsfwpatch.rpy:510
translate Spanish dlcday8nsfw1_0fe3fbaa:

    # GRC "You are... glorious."
    GRC "Eres... glorios[letra]."

# game/NSFW Patch/nsfwpatch.rpy:512
translate Spanish dlcday8nsfw1_8deb200e:

    # GRC "But I still cannot help but worry."
    GRC "Pero aun así no puedo evitar preocuparme."

# game/NSFW Patch/nsfwpatch.rpy:516
translate Spanish dlcday8nsfw1_215e2e57:

    # GRC "I wish it were that easy."
    GRC "Ojalá fuera tan fácil."

# game/NSFW Patch/nsfwpatch.rpy:518
translate Spanish dlcday8nsfw1_ee50ae40:

    # GRC "I am no longer containing myself, but I cannot help but worry."
    GRC "Ya no me contengo, pero no puedo evitar preocuparme."

# game/NSFW Patch/nsfwpatch.rpy:519
translate Spanish dlcday8nsfw1_59053f8c:

    # GRC "For myself, of course, but..."
    GRC "Por mí, claro, pero..."

# game/NSFW Patch/nsfwpatch.rpy:520
translate Spanish dlcday8nsfw1_01609834:

    # GRC "Mostly for you."
    GRC "Sobre todo por ti."

# game/NSFW Patch/nsfwpatch.rpy:526
translate Spanish dlcday8nsfw1_5f4ee48e:

    # GRC "You are precious to me."
    GRC "Eres muy valios[letra] para mí."

# game/NSFW Patch/nsfwpatch.rpy:528
translate Spanish dlcday8nsfw1_3c178e1d:

    # GRC "So much so that it makes me angry."
    GRC "Tanto que me enfurece."

# game/NSFW Patch/nsfwpatch.rpy:530
translate Spanish dlcday8nsfw1_1dc9425b:

    # GRC "How could I let myself fall for you so hard?"
    GRC "¿Cómo pude enamorarme de ti con tanta fuerza?"

# game/NSFW Patch/nsfwpatch.rpy:532
translate Spanish dlcday8nsfw1_8703119b:

    # GRC "How could I so easily turn to mush with a single sentence from your lips?"
    GRC "¿Cómo puedo derretirme con una sola frase de tus labios?"

# game/NSFW Patch/nsfwpatch.rpy:534
translate Spanish dlcday8nsfw1_c09bce09:

    # GRC "Just a look, and I am undone."
    GRC "Con solo una mirada, me deshago."

# game/NSFW Patch/nsfwpatch.rpy:539
translate Spanish dlcday8nsfw1_d7ae7e2b:

    # GRC "Yes?"
    GRC "¿Sí?"

# game/NSFW Patch/nsfwpatch.rpy:544
translate Spanish dlcday8nsfw1_008afe10_2:

    # GRC "..."
    GRC "..."

# game/NSFW Patch/nsfwpatch.rpy:546
translate Spanish dlcday8nsfw1_e61e1ff8:

    # GRC "Y... yes."
    GRC "S... sí."

# game/NSFW Patch/nsfwpatch.rpy:548
translate Spanish dlcday8nsfw1_7417c106:

    # GRC "I'd... like that."
    GRC "Me... gustaría."

# game/NSFW Patch/nsfwpatch.rpy:549
translate Spanish dlcday8nsfw1_0e628a26:

    # "{i}His face looks hot to the touch, the way his cheeks are flushing red.{/i}"
    "{i}Su rostro parece arder al tacto; las mejillas se le han puesto de un rojo intenso.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:553
translate Spanish dlcday8nsfw1_e3b4a830:

    # "{i}Gently, you use your fingertips to trace his features. His nose, his cheekbones, his jaw.{/i}"
    "{i}Con suavidad, trazas con las yemas de los dedos sus rasgos: la nariz, los pómulos, la mandíbula.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:555
translate Spanish dlcday8nsfw1_1e19fadd:

    # "{i}You can feel him lean into your touch, his eyelashes fluttering shut.{/i}"
    "{i}Sientes cómo se inclina hacia tu tacto, con las pestañas temblando al cerrarse.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:556
translate Spanish dlcday8nsfw1_943001de:

    # GRC "Can you feel that?"
    GRC "¿Puedes sentirlo?"

# game/NSFW Patch/nsfwpatch.rpy:557
translate Spanish dlcday8nsfw1_e6c8c25b:

    # "{i}You nod, which is a little silly, because his eyes are closed.{/i}"
    "{i}Asientes, lo cual resulta un poco absurdo, porque tiene los ojos cerrados.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:558
translate Spanish dlcday8nsfw1_1e970f35:

    # "{i}There it is again.{/i}"
    "{i}Ahí está otra vez.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:559
translate Spanish dlcday8nsfw1_8e06cb71:

    # "{i}That... buzz.{/i}"
    "{i}Ese... zumbido.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:560
translate Spanish dlcday8nsfw1_02cb8926:

    # "{i}Like an electric current that runs between the places where you connect.{/i}"
    "{i}Como una corriente eléctrica que recorre los puntos donde se tocan.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:561
translate Spanish dlcday8nsfw1_f0ab6746:

    # "{i}It doesn't hurt, though.{/i}"
    "{i}Aunque no duele.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:562
translate Spanish dlcday8nsfw1_b59b6a40:

    # "{i}If anything, it's... pleasant.{/i}"
    "{i}Si acaso, es... placentero.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:564
translate Spanish dlcday8nsfw1_866d6991:

    # GRC "What are you thinking, mortal? You have that look on your face again."
    GRC "¿En qué piensas, mortal? Tienes esa expresión otra vez."

# game/NSFW Patch/nsfwpatch.rpy:569
translate Spanish dlcday8nsfw1_d624b544:

    # GRC "There's a mischievous glint in your eyes."
    GRC "Hay un brillo travieso en tus ojos."

# game/NSFW Patch/nsfwpatch.rpy:576
translate Spanish dlcday8nsfw1_65122790_1:

    # GRC "I..."
    GRC "Yo..."

# game/NSFW Patch/nsfwpatch.rpy:578
translate Spanish dlcday8nsfw1_e0460749:

    # GRC "Who's to say."
    GRC "Quién sabe."

# game/NSFW Patch/nsfwpatch.rpy:580
translate Spanish dlcday8nsfw1_fe70da5e:

    # GRC "Perhaps you should come and find out."
    GRC "Quizá deberías acercarte y descubrirlo."

# game/NSFW Patch/nsfwpatch.rpy:582
translate Spanish dlcday8nsfw1_72f34c72:

    # "{i}He doesn't need to ask you twice.{/i}"
    "{i}No hace falta que te lo diga dos veces.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:583
translate Spanish dlcday8nsfw1_f28f3780:

    # "{i}You lean down, and your lips meet his.{/i}"
    "{i}Te inclinas y los labios de ambos se encuentran.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:584
translate Spanish dlcday8nsfw1_04fdf759:

    # "{i}You still feel it - that buzz where you touch, as if your very souls are reacting to each other, humming in ecstacy.{/i}"
    "{i}Aún lo sientes: ese zumbido donde se tocan, como si sus almas reaccionaran la una a la otra, vibrando en éxtasis.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:585
translate Spanish dlcday8nsfw1_c41bd856:

    # "{i}Casper sighs against you, his hands moving to grip your waist as you feel his slight fangs nibble against your lower lip.{/i}"
    "{i}Casper suspira contra ti; sus manos se aferran a tu cintura mientras sientes cómo sus pequeños colmillos mordisquean tu labio inferior.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:586
translate Spanish dlcday8nsfw1_1fcec2b0:

    # "{i}You pull back, hovering over the man who tried to take your soul.{/i}"
    "{i}Te apartas, quedando suspendid[letra] sobre el hombre que intentó llevarse tu alma.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:587
translate Spanish dlcday8nsfw1_c31efc31:

    # "{i}And failed, of course.{/i}"
    "{i}Y falló, por supuesto.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:588
translate Spanish dlcday8nsfw1_e68ce2b6:

    # "{i}He's panting, looking up at you with a desperate sort of expression glued to his face.{/i}"
    "{i}Jadea, mirándote con una expresión desesperada pegada al rostro.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:612
translate Spanish dlcday8nsfw1_2555ad3b:

    # "{i}Reaching down, you touch his gloved hand gently, and you can't help but notice the way his breath hitches in his throat at your action.{/i}"
    "{i}Alargas la mano y tocas con suavidad su mano enguantada; no puedes evitar notar cómo se le corta la respiración ante tu gesto.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:613
translate Spanish dlcday8nsfw1_7cdfd7c7:

    # GRC "Sunshine... you're driving me crazy."
    GRC "Solecito... me estás volviendo loco."

# game/NSFW Patch/nsfwpatch.rpy:614
translate Spanish dlcday8nsfw1_ef50a940:

    # GRC "A single touch from you is enough to render me absolutely useless."
    GRC "Un solo roce tuyo basta para dejarme completamente inútil."

# game/NSFW Patch/nsfwpatch.rpy:615
translate Spanish dlcday8nsfw1_e0f0a816:

    # GRC "Enough to make me weak."
    GRC "Lo suficiente para debilitarme."

# game/NSFW Patch/nsfwpatch.rpy:616
translate Spanish dlcday8nsfw1_508c5455:

    # GRC "Can't you see how you unravel me?"
    GRC "¿No ves cómo me deshaces?"

# game/NSFW Patch/nsfwpatch.rpy:633
translate Spanish dlcday8nsfw1_2d683498:

    # "{i}You can hear him swallow, and his eyes are wide as he looks up at you.{/i}"
    "{i}Oyes cómo traga saliva; tiene los ojos muy abiertos mientras te mira desde abajo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:634
translate Spanish dlcday8nsfw1_8b4fcec2:

    # GRC "You cannot help but get yourself into trouble, mortal."
    GRC "No puedes evitar meterte en problemas, mortal."

# game/NSFW Patch/nsfwpatch.rpy:635
translate Spanish dlcday8nsfw1_629fbe20:

    # GRC "You are drawn to it."
    GRC "Te atrae."

# game/NSFW Patch/nsfwpatch.rpy:639
translate Spanish dlcday8nsfw1_1fd16af6:

    # GRC "Exactly."
    GRC "Exacto."

# game/NSFW Patch/nsfwpatch.rpy:640
translate Spanish dlcday8nsfw1_9467829c:

    # GRC "....."
    GRC "....."

# game/NSFW Patch/nsfwpatch.rpy:641
translate Spanish dlcday8nsfw1_403d8e74:

    # GRC "............"
    GRC "............"

# game/NSFW Patch/nsfwpatch.rpy:642
translate Spanish dlcday8nsfw1_cfd337cc:

    # GRC "I am yours."
    GRC "Soy tuyo."

# game/NSFW Patch/nsfwpatch.rpy:643
translate Spanish dlcday8nsfw1_6aefad8f:

    # "{i}He says this in a tone so low and full of desire it sends a shiver through your entire being.{/i}"
    "{i}Lo dice con un tono tan bajo y cargado de deseo que te provoca un escalofrío por todo el cuerpo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:644
translate Spanish dlcday8nsfw1_7a6f37d9:

    # "{i}You're not sure if he's trying to warn you or seduce you, but at this point you couldn't care less.{/i}"
    "{i}No estás segur[letra] de si intenta advertirte o seducirte, pero a estas alturas te da igual.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:645
translate Spanish dlcday8nsfw1_ddf26973:

    # "{i}Sitting over him, your hand finds his gloved hand, and your fingertips begin tracing his palm, the lengths of his fingers, and his wrist.{/i}"
    "{i}Sentad[letra] a horcajadas sobre él, tu mano encuentra la suya enguantada y las yemas de tus dedos empiezan a recorrer su palma, la longitud de sus dedos y su muñeca.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:646
translate Spanish dlcday8nsfw1_b8d247a4:

    # "{i}He shivers, a soft groan escaping his slightly parted lips.{/i}"
    "{i}Se estremece; un suave gemido se le escapa de los labios entreabiertos.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:647
translate Spanish dlcday8nsfw1_9a988c6f:

    # "{i}He watches you, and you can see the want, the desire, the absolute NEED in his expression.{/i}"
    "{i}Te observa, y puedes ver el anhelo, el deseo, la NECESIDAD absoluta en su expresión.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:654
translate Spanish dlcday8nsfw1_0b60ae00:

    # GRC "They're... practical, but... I will not argue if you find them alluring."
    GRC "Son... prácticos, pero... no discutiré si te resultan atractivos."

# game/NSFW Patch/nsfwpatch.rpy:658
translate Spanish dlcday8nsfw1_008afe10_3:

    # GRC "..."
    GRC "..."

# game/NSFW Patch/nsfwpatch.rpy:659
translate Spanish dlcday8nsfw1_d7c04260:

    # GRC "I am... unused to touch."
    GRC "Yo... no estoy acostumbrado al tacto."

# game/NSFW Patch/nsfwpatch.rpy:660
translate Spanish dlcday8nsfw1_7955e821:

    # GRC "My hands are... especially sensitive. I have always worn gloves."
    GRC "Mis manos son... especialmente sensibles. Siempre he llevado guantes."

# game/NSFW Patch/nsfwpatch.rpy:685
translate Spanish dlcday8nsfw1_3b37e3f8:

    # "{i}Your hand changes course now. You gently wrap it around his wrist, and slip your thumb up and into his glove.{/i}"
    "{i}Tu mano cambia de rumbo. La envuelves con suavidad alrededor de su muñeca y deslizas el pulgar hacia arriba, dentro del guante.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:686
translate Spanish dlcday8nsfw1_2b2e3b1d:

    # "{i}Slowly, you run the pad of your thumb up his bare wrist, and up the palm of his hand.{/i}"
    "{i}Con lentitud, deslizas la yema del pulgar por su muñeca desnuda y luego por la palma de su mano.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:687
translate Spanish dlcday8nsfw1_483ff5df:

    # "{i}Casper's entire body jerks, and he bites his lip.{/i}"
    "{i}Todo el cuerpo de Casper se estremece y se muerde el labio.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:688
translate Spanish dlcday8nsfw1_9d581ce7:

    # "{i}He's looking up at you, his mouth open, his chest rising and falling rapidly, and you can feel the energy building between you.{/i}"
    "{i}Te mira desde abajo, con la boca abierta y el pecho subiendo y bajando a toda velocidad; puedes sentir cómo la energía se acumula entre ustedes.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:689
translate Spanish dlcday8nsfw1_a578fbbc:

    # "{i}The warmth mixes with the buzz, sending a quickly spreading warmth through your veins.{/i}"
    "{i}El calor se mezcla con el zumbido, enviando una oleada de calor que se extiende rápidamente por tus venas.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:690
translate Spanish dlcday8nsfw1_202745ac:

    # "{i}It's... addictive.{/i}"
    "{i}Es... adictivo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:691
translate Spanish dlcday8nsfw1_52ac2b17:

    # "{i}Touching him is like touching an exposed nerve.{/i}"
    "{i}Tocarle es como tocar un nervio al descubierto.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:692
translate Spanish dlcday8nsfw1_86a434d5:

    # "{i}It's like being drunk on adrenaline.{/i}"
    "{i}Es como estar borrach[letra] de adrenalina.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:693
translate Spanish dlcday8nsfw1_f04fe3b2:

    # "{i}Your thumb runs gentle circles, the touch light, teasing, but you can tell already the effect it's having on Casper.{/i}"
    "{i}Tu pulgar traza círculos suaves; el roce es ligero, provocador, pero ya puedes notar el efecto que tiene en Casper.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:713
translate Spanish dlcday8nsfw1_d0d09482:

    # "{i}You push his glove up further now, until just his palm is exposed.{/i}"
    "{i}Empujas el guante un poco más hacia arriba, hasta dejar solo la palma al descubierto.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:714
translate Spanish dlcday8nsfw1_a58347d6:

    # "{i}And your touch is soft - ever so soft. The light touches of your fingertips are barely there, and they ghost over his palm, his wrist, his fingers.{/i}"
    "{i}Y tu tacto es suave, extremadamente suave. Los toques ligeros de tus dedos apenas se perciben; rozan su palma, su muñeca, sus dedos como un fantasma.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:715
translate Spanish dlcday8nsfw1_44d09b18:

    # "{i}They are the kiss of a summer's breeze, and they leave goosebumps on his skin.{/i}"
    "{i}Son el beso de una brisa de verano, y le dejan la piel de gallina.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:716
translate Spanish dlcday8nsfw1_552a0f06:

    # "{i}Your other hand - resting on his thigh - feels it first.{/i}"
    "{i}Tu otra mano, posada sobre su muslo, es la primera en notarlo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:717
translate Spanish dlcday8nsfw1_de2b62e9:

    # "{i}The twitch of his cock, reacting to your teasing.{/i}"
    "{i}El sobresalto de su pene, reaccionando a tus caricias.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:721
translate Spanish dlcday8nsfw1_e2f57d54:

    # GRC "Ha... ah..."
    GRC "Ah... ah..."

# game/NSFW Patch/nsfwpatch.rpy:722
translate Spanish dlcday8nsfw1_d10e039c:

    # GRC "You... you are... evil, you know that?"
    GRC "Tú... eres... malvad[letra], ¿lo sabes?"

# game/NSFW Patch/nsfwpatch.rpy:726
translate Spanish dlcday8nsfw1_4bb8f45d:

    # GRC "You... haa... you're killing me."
    GRC "Tú... jaa... me estás matando."

# game/NSFW Patch/nsfwpatch.rpy:732
translate Spanish dlcday8nsfw1_03b0c978:

    # "{i}You let your thumb drift across his palm again, and his eyes flutter shut for just a moment, a low moan rumbling through his throat.{/i}"
    "{i}Dejas que tu pulgar se deslice de nuevo por su palma y sus ojos se cierran un instante; un gemido bajo le retumba en la garganta.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:733
translate Spanish dlcday8nsfw1_96ab40c2:

    # "{i}His other hand - the one that is currently gripping your sheets - tightens its grip, and you have to stop yourself from visibly gulping.{/i}"
    "{i}Su otra mano, la que agarra las sábanas, aprieta con más fuerza, y tienes que contenerte para no tragar saliva de forma visible.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:734
translate Spanish dlcday8nsfw1_3865e796:

    # "{i}This man will be the death of you, one way or the other.{/i}"
    "{i}Este hombre será tu perdición, de una forma u otra.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:754
translate Spanish dlcday8nsfw1_103838ee:

    # "{i}In one fell swoop, you push free the rest of Casper's glove, and tangle your fingers together.{/i}"
    "{i}De un solo movimiento, terminas de quitarle el guante y entrelazas tus dedos con los suyos.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:755
translate Spanish dlcday8nsfw1_1c97796c:

    # "{i}It is an instant reaction.{/i}"
    "{i}La reacción es inmediata.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:756
translate Spanish dlcday8nsfw1_e48f1615:

    # "{i}The warmth, the heat, the energy, the buzz... it all hits you in a wave.{/i}"
    "{i}El calor, la energía, el zumbido... todo te golpea como una ola.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:757
translate Spanish dlcday8nsfw1_efa8688e:

    # "{i}The heat pools down between your legs as you watch Casper's dick throb through his trousers, leaving a tent.{/i}"
    "{i}El calor se concentra entre tus piernas mientras ves cómo el pene de Casper late a través del pantalón, formando una tienda de campaña.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:758
translate Spanish dlcday8nsfw1_c1fbc1d3:

    # GRC "Ah... ugh..."
    GRC "Ah... eh..."

# game/NSFW Patch/nsfwpatch.rpy:759
translate Spanish dlcday8nsfw1_b16637f5:

    # GRC "No... no mortal has ever made me beg before."
    GRC "Ningún... ningún mortal me había hecho rogar antes."

# game/NSFW Patch/nsfwpatch.rpy:760
translate Spanish dlcday8nsfw1_a36dec5a:

    # GRC "But... please?"
    GRC "Pero... ¿por favor?"

# game/NSFW Patch/nsfwpatch.rpy:761
translate Spanish dlcday8nsfw1_982204d3:

    # "{i}The way his voice comes out as a whisper, a plea, a prayer.{/i}"
    "{i}La forma en que su voz sale como un susurro, una súplica, una plegaria.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:762
translate Spanish dlcday8nsfw1_394f6f99:

    # "{i}It drives you mad.{/i}"
    "{i}Te vuelve loc[letra].{/i}"

# game/NSFW Patch/nsfwpatch.rpy:782
translate Spanish dlcday8nsfw1_86f3849d:

    # "{i}Your hand untangles from his, and a moment later you've unbuttoned the front of his trousers, and reached in, gripping his hardness in your hand.{/i}"
    "{i}Tu mano se desprende de la suya y, un momento después, has desabrochado el frontal de su pantalón y metido la mano, agarrando su dureza.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:783
translate Spanish dlcday8nsfw1_434e005c:

    # "{i}It's... bigger than you expected, and oh so hot to the touch.{/i}"
    "{i}Es... más grande de lo que esperabas, y está ardiendo al tacto.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:784
translate Spanish dlcday8nsfw1_79463664:

    # "{i}His other hand, gloved, grips at the sheets next to his head as you play with his tip, pre-cum beading at the top.{/i}"
    "{i}Su otra mano, aún enguantada, se aferra a las sábanas junto a su cabeza mientras juegas con la punta; el líquido preseminal se acumula en el extremo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:785
translate Spanish dlcday8nsfw1_2b7a5bb8:

    # GRC "S... Sunshine..."
    GRC "S... Solecito..."

# game/NSFW Patch/nsfwpatch.rpy:786
translate Spanish dlcday8nsfw1_8f881767:

    # "{i}His voice is thick, laced with want, and need, and lust.{/i}"
    "{i}Su voz está espesa, cargada de deseo, necesidad y lujuria.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:790
translate Spanish dlcday8nsfw1_36c59374:

    # GRC "That... that much is obvious!"
    GRC "¡Eso... eso es evidente!"

# game/NSFW Patch/nsfwpatch.rpy:791
translate Spanish dlcday8nsfw1_7f72acf4:

    # "{i}You move your hand down his length, fist slowly moving along his cock, and you can't help but notice the way his hips buck at your movement.{/i}"
    "{i}Deslizas la mano por su longitud, el puño moviéndose despacio a lo largo de su pene, y no puedes evitar notar cómo sus caderas se arquean ante tu movimiento.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:792
translate Spanish dlcday8nsfw1_c226617d:

    # "{i}You keep your movements slow, your gaze focused on his face as you work him.{/i}"
    "{i}Mantienes los movimientos lentos, la mirada fija en su rostro mientras le estimulas.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:793
translate Spanish dlcday8nsfw1_93f2efb0:

    # "{i}His breathing is ragged, his mouth agape, his brows furrowed in a desperate want.{/i}"
    "{i}Su respiración es irregular, la boca entreabierta, las cejas fruncidas por un deseo desesperado.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:794
translate Spanish dlcday8nsfw1_0ad9528b:

    # "{i}And, strangely, for every stroke, you feel as though someone's hand was on you, teasing, caressing.{/i}"
    "{i}Y, de forma extraña, con cada caricia sientes como si una mano te tocara a ti también, provocándote, acariciándote.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:798
translate Spanish dlcday8nsfw1_ee168eab:

    # GRC "It... it is our... connection..."
    GRC "Es... es nuestra... conexión..."

# game/NSFW Patch/nsfwpatch.rpy:799
translate Spanish dlcday8nsfw1_7a4fe3f8:

    # GRC "Beyond the... the hum of our souls intertwining..."
    GRC "Más allá del... del zumbido de nuestras almas entrelazándose..."

# game/NSFW Patch/nsfwpatch.rpy:800
translate Spanish dlcday8nsfw1_02bdc198:

    # GRC "I can... I can feel your want... your need..."
    GRC "Puedo... puedo sentir tu deseo... tu necesidad..."

# game/NSFW Patch/nsfwpatch.rpy:804
translate Spanish dlcday8nsfw1_13fe7221:

    # "{i}He nods, and the look on his face tells you he knows exactly what you mean.{/i}"
    "{i}Asiente, y la expresión de su rostro te dice que entiende perfectamente a lo que te refieres.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:805
translate Spanish dlcday8nsfw1_136f8eb3:

    # "{i}Forget Casper being the death of you. THIS is what's likely to kill you.{/i}"
    "{i}Olvídate de que Casper sea tu perdición. ESTO es lo que probablemente te mate.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:806
translate Spanish dlcday8nsfw1_971838b1:

    # "{i}The pleasure is overwhelming. Every motion, every stroke of his cock sends waves of pleasure through your own body, and the feeling only intensifies the more you touch him.{/i}"
    "{i}El placer es abrumador. Cada movimiento, cada caricia a su pene envía oleadas de placer por tu propio cuerpo, y la sensación solo se intensifica cuanto más le tocas.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:807
translate Spanish dlcday8nsfw1_215aa3ab:

    # "{i}He is moaning and gasping under you, and you can't help but think the sounds he's making are beautiful.{/i}"
    "{i}Gime y jadea debajo de ti, y no puedes evitar pensar que los sonidos que emite son hermosos.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:808
translate Spanish dlcday8nsfw1_e1370441:

    # "{i}This man, who was beyond cocky, edgy and snarky... the same man is coming undone by a single hand.{/i}"
    "{i}Este hombre, que era arrogante, cortante y sarcástico... el mismo hombre se deshace con una sola mano.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:809
translate Spanish dlcday8nsfw1_54a0d52c:

    # "{i}Well, you can't blame him, you suppose.{/i}"
    "{i}Bueno, supones que no puedes culparlo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:810
translate Spanish dlcday8nsfw1_4a105274:

    # "{i}All you're doing is touching his dick and you feel like you're about to explode.{/i}"
    "{i}Solo le estás tocando el pene y sientes que estás a punto de explotar.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:811
translate Spanish dlcday8nsfw1_05cad11f:

    # "{i}You move your hand faster, the strokes harder, and you're rewarded by his hips bucking, his thighs trembling, his cock throbbing, and his hand, tangled in the sheets, gripping tighter.{/i}"
    "{i}Aceleras la mano, las caricias se vuelven más firmes, y te recompensan sus caderas arqueándose, sus muslos temblando, su pene latiendo y su mano, enredada en las sábanas, apretando con más fuerza.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:818
translate Spanish dlcday8nsfw1_ab176b9d:

    # GRC "Not... not yet...."
    GRC "Aún... aún no...."

# game/NSFW Patch/nsfwpatch.rpy:819
translate Spanish dlcday8nsfw1_0cf28c0a:

    # GRC "I want to... I must..."
    GRC "Quiero... debo..."

# game/NSFW Patch/nsfwpatch.rpy:820
translate Spanish dlcday8nsfw1_054a4feb:

    # "{i}His hand, the one you had so boldly stripped, reaches for you, gripping onto your clothes as if for dear life.{/i}"
    "{i}Su mano, a la que le habías quitado el guante con tanta osadía, se alarga hacia ti, aferrándose a tu ropa como si le fuera la vida en ello.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:824
translate Spanish dlcday8nsfw1_bce7de5a:

    # "{i}His hand reaches down to cup your own hardened cock, and a shuddering moan escapes your throat.{/i}"
    "{i}Su mano baja hasta envolver tu propio pene endurecido, y un gemido tembloroso se te escapa de la garganta.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:828
translate Spanish dlcday8nsfw1_e1e30fd4:

    # "{i}His hand reaches down between your legs, finding the wetness that's grown between your thighs, a shuddering moan escaping your throat.{/i}"
    "{i}Su mano baja entre tus piernas, encontrando la humedad que se ha acumulado entre tus muslos, y un gemido tembloroso se te escapa de la garganta.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:832
translate Spanish dlcday8nsfw1_420ad3a2:

    # GRC "Can I..."
    GRC "¿Puedo...?"

# game/NSFW Patch/nsfwpatch.rpy:836
translate Spanish dlcday8nsfw1_ea0334ae:

    # "{i}You nod frantically, the sensation overwhelming.{/i}"
    "{i}Asientes con frenesí; la sensación es abrumadora.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:837
translate Spanish dlcday8nsfw1_69609666:

    # "{i}His touch, your touch, they seem to magnify each other, and the spot where the two of you meet starts to blur.{/i}"
    "{i}Su tacto y el tuyo parecen magnificar el uno al otro, y el punto donde se encuentran empieza a difuminarse.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:838
translate Spanish dlcday8nsfw1_1f783003:

    # "{i}Is it his hand, or yours?{/i}"
    "{i}¿Es su mano o la tuya?{/i}"

# game/NSFW Patch/nsfwpatch.rpy:839
translate Spanish dlcday8nsfw1_28110b19:

    # "{i}Does it matter?{/i}"
    "{i}¿Importa?{/i}"

# game/NSFW Patch/nsfwpatch.rpy:843
translate Spanish dlcday8nsfw1_255646c1:

    # "{i}As you continue to stroke up and down his length, feeling his veins against your palm, Casper reaches into your pants, pulling free your dick, and begins stroking you, his hand moving in time with your own.{/i}"
    "{i}Mientras sigues subiendo y bajando por su longitud, sintiendo las venas contra tu palma, Casper mete la mano en tus pantalones, saca tu pene y empieza a acariciarte, su mano moviéndose al mismo ritmo que la tuya.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:844
translate Spanish dlcday8nsfw1_af10799e:

    # "{i}His touch is warm and inviting, and he wraps his slender fingers around you, the touch so intense it makes you feel dizzy.{/i}"
    "{i}Su tacto es cálido y acogedor; envuelve sus delgados dedos a tu alrededor, el contacto tan intenso que te marea.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:848
translate Spanish dlcday8nsfw1_3195dc4f:

    # "{i}As you continue to stroke up and down his length, feeling his veins against your palm, Casper reaches into your pants, his fingers finding your clit, and begins stroking you, his hand moving in time with your own.{/i}"
    "{i}Mientras sigues subiendo y bajando por su longitud, sintiendo las venas contra tu palma, Casper mete la mano en tus pantalones, sus dedos encuentran tu clítoris y empieza a acariciarte, su mano moviéndose al mismo ritmo que la tuya.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:849
translate Spanish dlcday8nsfw1_b28aa15a:

    # "{i}His touch is warm and inviting, and he presses his fingertip against your clit, the touch so intense it makes you feel dizzy.{/i}"
    "{i}Su tacto es cálido y acogedor; presiona la yema del dedo contra tu clítoris, el contacto tan intenso que te marea.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:856
translate Spanish dlcday8nsfw1_8ac3c826:

    # GRC "Ha... haa..."
    GRC "Ah... aah..."

# game/NSFW Patch/nsfwpatch.rpy:857
translate Spanish dlcday8nsfw1_a335b1b9:

    # "{i}Your moans come in unison, and you can feel yourself reaching the edge.{/i}"
    "{i}Los gemidos de ambos salen al unísono, y sientes que estás a punto de llegar al límite.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:858
translate Spanish dlcday8nsfw1_c99fcdc0:

    # "{i}But, so is Casper.{/i}"
    "{i}Pero Casper también.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:859
translate Spanish dlcday8nsfw1_ee612774:

    # "{i}Waves after waves of pleasure crash over you, intensifying with each passing second.{/i}"
    "{i}Ola tras ola de placer se estrella contra ti, intensificándose a cada segundo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:860
translate Spanish dlcday8nsfw1_18b2aaa8:

    # "{i}You're both sweating and panting, and your grip tightens on his cock, eliciting a loud moan from the man under you.{/i}"
    "{i}Ambos sudan y jadean; tu agarre se aprieta en torno a su pene, provocando un gemido fuerte del hombre que tienes debajo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:864
translate Spanish dlcday8nsfw1_e4f407c3:

    # GRC "Me... me too..."
    GRC "Yo... yo también..."

# game/NSFW Patch/nsfwpatch.rpy:884
translate Spanish dlcday8nsfw1_4ac3f46d:

    # "{i}His release comes hard - his dick throbs in your hand as you continue pumping him, cum spilling out and onto your fingers.{/i}"
    "{i}Su orgasmo llega con fuerza: su pene late en tu mano mientras sigues bombeándolo; el semen se derrama sobre tus dedos.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:888
translate Spanish dlcday8nsfw1_567493a0:

    # "{i}Casper's hand tightens, the pressure and heat and the pleasure overwhelming, and it tips you over the edge.{/i}"
    "{i}La mano de Casper se aprieta; la presión, el calor y el placer son abrumadores, y te empujan al límite.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:889
translate Spanish dlcday8nsfw1_190370b0:

    # "{i}You come into his hand, and as your own orgasm overtakes you, you can feel Casper's body twitch and shudder, his dick still sensitive from his own orgasm.{/i}"
    "{i}Te corres en su mano y, mientras tu propio orgasmo te envuelve, sientes el cuerpo de Casper estremecerse y temblar; su pene aún está sensible tras su propio orgasmo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:893
translate Spanish dlcday8nsfw1_17ef878f:

    # "{i}Casper's fingers stroke against you quickly, the pressure and heat and the pleasure overwhelming, and it tips you over the edge.{/i}"
    "{i}Los dedos de Casper te acarician con rapidez; la presión, el calor y el placer son abrumadores, y te empujan al límite.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:894
translate Spanish dlcday8nsfw1_e8bbeffb:

    # "{i}You come against his fingers, and as your own orgasm overtakes you, you can feel Casper's body twitching and shuddering, his dick still sensitive from his own orgasm.{/i}"
    "{i}Te corres contra sus dedos y, mientras tu propio orgasmo te envuelve, sientes el cuerpo de Casper estremecerse y temblar; su pene aún está sensible tras su propio orgasmo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:906
translate Spanish dlcday8nsfw1_28a68c82:

    # GRC "Haa... haaa... S.... Sunshine..."
    GRC "Jaa... jaaa... S.... Solecito..."

# game/NSFW Patch/nsfwpatch.rpy:907
translate Spanish dlcday8nsfw1_4eda1876:

    # "{i}His voice comes out breathy, needy.{/i}"
    "{i}Su voz sale entrecortada, necesitada.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:908
translate Spanish dlcday8nsfw1_a76f000b:

    # GRC "That was... I feel as though I have not truly lived until this second..."
    GRC "Eso fue... siento como si no hubiera vivido de verdad hasta este segundo..."

# game/NSFW Patch/nsfwpatch.rpy:912
translate Spanish dlcday8nsfw1_9ef57fb3:

    # GRC "You are... incredible."
    GRC "Eres... increíble."

# game/NSFW Patch/nsfwpatch.rpy:913
translate Spanish dlcday8nsfw1_c3425988:

    # "{i}He sits up, cupping your cheek with his clean hand, tender.{/i}"
    "{i}Se incorpora, acunando tu mejilla con la mano limpia, con ternura.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:914
translate Spanish dlcday8nsfw1_e200e8fe:

    # GRC "I struggle to put together my thoughts on fate, these days, but..."
    GRC "Me cuesta ordenar mis pensamientos sobre el destino, estos días, pero..."

# game/NSFW Patch/nsfwpatch.rpy:915
translate Spanish dlcday8nsfw1_1e10da06:

    # GRC "Sunshine, if fate exists, you and I were surely meant to meet."
    GRC "Solecito, si el destino existe, tú y yo estábamos destinados a encontrarnos."

# game/NSFW Patch/nsfwpatch.rpy:916
translate Spanish dlcday8nsfw1_a4e7c00d:

    # GRC "And if it doesn't, then I have found a miracle that even a god cannot grant to me."
    GRC "Y si no existe, entonces he encontrado un milagro que ni siquiera un dios podría concederme."

# game/NSFW Patch/nsfwpatch.rpy:917
translate Spanish dlcday8nsfw1_e33200b4:

    # GRC "You are..."
    GRC "Eres..."

# game/NSFW Patch/nsfwpatch.rpy:918
translate Spanish dlcday8nsfw1_b367effa:

    # GRC "Words fail me."
    GRC "Las palabras me fallan."

# game/NSFW Patch/nsfwpatch.rpy:925
translate Spanish dlcday8nsfw1_4907f7da:

    # GRC "What can I say, I'm a charming man?"
    GRC "¿Qué quieres que diga? Soy un hombre encantador."

# game/NSFW Patch/nsfwpatch.rpy:930
translate Spanish dlcday8nsfw1_008afe10_4:

    # GRC "..."
    GRC "..."

# game/NSFW Patch/nsfwpatch.rpy:931
translate Spanish dlcday8nsfw1_128afbd1:

    # GRC "Let us... wash up."
    GRC "Vamos a... limpiarnos."

# game/NSFW Patch/nsfwpatch.rpy:939
translate Spanish dlcday8nsfw1_632ef684:

    # GRC "Then rest."
    GRC "Y después descansar."

# game/NSFW Patch/nsfwpatch.rpy:943
translate Spanish dlcday8nsfw1_0ed2f238:

    # GRC "I'll get something."
    GRC "Traeré algo."

# game/NSFW Patch/nsfwpatch.rpy:944
translate Spanish dlcday8nsfw1_fe281fb5:

    # GRC "Rest, I insist."
    GRC "Descansa, insisto."

# game/NSFW Patch/nsfwpatch.rpy:946
translate Spanish dlcday8nsfw1_efefa525:

    # "{i}With that, he gets up, and walks into your bathroom.{/i}"
    "{i}Dicho esto, se levanta y se dirige al baño.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:947
translate Spanish dlcday8nsfw1_874ee3a8:

    # "{i}You lay there, feeling as though you are glowing. Echoes of Casper's touch still linger against your skin.{/i}"
    "{i}Te quedas tendid[letra], sintiendo que brillas. Los ecos del tacto de Casper aún permanecen en tu piel.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:948
translate Spanish dlcday8nsfw1_adb82802:

    # "{i}In your entire life, you've never felt anything like that.{/i}"
    "{i}En toda tu vida nunca habías sentido algo así.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:949
translate Spanish dlcday8nsfw1_9fb68670:

    # "{i}You felt your pleasure. Casper's pleasure. They combined, twisted, turned, amplified, and echoed back and forth between the two of you.{/i}"
    "{i}Sentiste tu placer. El de Casper. Se combinaron, se retorcieron, se amplificaron y rebotaron de uno a otro.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:950
translate Spanish dlcday8nsfw1_7b4800be:

    # "{i}At some point, Casper will return and clean you up. But for now, you close your eyes, and drift off.{/i}"
    "{i}En algún momento Casper volverá y te limpiará. Pero por ahora cierras los ojos y te dejas llevar.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:988
translate Spanish day9nsfwinstalled_008afe10:

    # GRC "..."
    GRC "..."

# game/NSFW Patch/nsfwpatch.rpy:996
translate Spanish day9nsfwinstalled_c3d77c31:

    # GRC "...Such as?"
    GRC "...¿Como qué?"

# game/NSFW Patch/nsfwpatch.rpy:1010
translate Spanish day9nsfwscene_dcc138aa:

    # center_text "Your hands are on him and his are on you in moments."
    center_text "En cuestión de segundos, tus manos están en él y las suyas en ti."

# game/NSFW Patch/nsfwpatch.rpy:1012
translate Spanish day9nsfwscene_11bbc042:

    # center_text "There's a hunger to his motions - a need for you that is nearly overwhelming."
    center_text "Hay un hambre en sus movimientos: una necesidad de ti casi abrumadora."

# game/NSFW Patch/nsfwpatch.rpy:1013
translate Spanish day9nsfwscene_0f0c6d00:

    # center_text "Casper's gloved hands grip your hips tightly as you kiss him, and even with clothes separating your skin, you can feel a warmth, a heat, a buzz, radiating between you."
    center_text "Las manos enguantadas de Casper se aferran con fuerza a tus caderas mientras le besas, y aunque la ropa separe su piel, sientes un calor, un zumbido, irradiando entre ustedes."

# game/NSFW Patch/nsfwpatch.rpy:1014
translate Spanish day9nsfwscene_5577fa7c:

    # center_text "It's an addictive feeling - as if your souls were always supposed to be one, and by touching, the two of you are becoming a whole again."
    center_text "Es una sensación adictiva: como si sus almas hubieran estado siempre destinadas a ser una, y al tocarse, vuelven a ser un todo."

# game/NSFW Patch/nsfwpatch.rpy:1019
translate Spanish day9nsfwscene_06ade992:

    # center_text "His lips are like fire against your own, and as his hands grip your hips tighter, his lips move to your neck, leaving a trail of kisses as he goes."
    center_text "Sus labios son como fuego contra los tuyos, y mientras sus manos aprietan más tus caderas, se desplazan hacia tu cuello, dejando un rastro de besos a su paso."

# game/NSFW Patch/nsfwpatch.rpy:1030
translate Spanish day9nsfwscene_3c267bb8:

    # GRC "Ha... ha.... Sunshine, this is... having you here really is dangerous..."
    GRC "Ah... Ah.... Solecito, esto es... tenerte aquí es realmente peligroso..."

# game/NSFW Patch/nsfwpatch.rpy:1034
translate Spanish day9nsfwscene_5e109f09:

    # GRC "Because when you're around I can't even think clearly."
    GRC "Porque cuando estás cerca no puedo ni pensar con claridad."

# game/NSFW Patch/nsfwpatch.rpy:1036
translate Spanish day9nsfwscene_ed48a595:

    # GRC "Every thought is consumed by you."
    GRC "Cada pensamiento está consumido por ti."

# game/NSFW Patch/nsfwpatch.rpy:1038
translate Spanish day9nsfwscene_f4d7bc8e:

    # GRC "Your touch, your taste, your voice, your scent..."
    GRC "Tu tacto, tu sabor, tu voz, tu aroma..."

# game/NSFW Patch/nsfwpatch.rpy:1040
translate Spanish day9nsfwscene_6c1bbfcd:

    # GRC "And gods above and below, do you have the most beautiful soul I have ever laid eyes on."
    GRC "Y por los dioses de arriba y de abajo, tienes el alma más hermosa que he visto jamás."

# game/NSFW Patch/nsfwpatch.rpy:1054
translate Spanish day9nsfwscene_1719cbc4:

    # "{i}And then your lips find his again as you stumble backwards through his small apartment, his hands roaming your body, and yours roaming his.{/i}"
    "{i}Y entonces los labios de ambos se encuentran de nuevo mientras retroceden a trompicones por su pequeño apartamento; sus manos recorren tu cuerpo y las tuyas el suyo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1055
translate Spanish day9nsfwscene_d0b67f40:

    # "{i}The bulge already apparent in Casper's pants doesn't escape your notice, and you teasingly brush your hand against him.{/i}"
    "{i}El bulto ya evidente en el pantalón de Casper no se te escapa, y le rozas con la mano de forma provocadora.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1056
translate Spanish day9nsfwscene_7a43c1c4:

    # "{i}A low groan escapes his lips as your hand flitters away, and you can't help the smirk that spreads across your face.{/i}"
    "{i}Un gemido bajo se le escapa de los labios cuando tu mano se aleja, y no puedes evitar la sonrisa de satisfacción que se dibuja en tu rostro.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1067
translate Spanish day9nsfwscene_008afe10:

    # GRC "..."
    GRC "..."

# game/NSFW Patch/nsfwpatch.rpy:1069
translate Spanish day9nsfwscene_13b5be4b:

    # GRC "Don't tease me."
    GRC "No me provoques."

# game/NSFW Patch/nsfwpatch.rpy:1076
translate Spanish day9nsfwscene_9467829c:

    # GRC "....."
    GRC "....."

# game/NSFW Patch/nsfwpatch.rpy:1078
translate Spanish day9nsfwscene_6624d04d:

    # GRC "You do not know how much I crave your touch. Crave to touch you."
    GRC "No sabes cuánto anhelo tu tacto. Anhelo tocarte."

# game/NSFW Patch/nsfwpatch.rpy:1083
translate Spanish day9nsfwscene_8bc98c97:

    # "{i}Your hand finds his dick once more, and this time you press against it, rubbing through the fabric.{/i}"
    "{i}Tu mano encuentra de nuevo su pene, y esta vez presionas contra él, frotándolo a través de la tela.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1084
translate Spanish day9nsfwscene_9cb7b1f1:

    # "{i}It twitches against you - hard and eager - and another groan escapes Casper's lips.{/i}"
    "{i}Late contra ti, duro y ansioso, y otro gemido se le escapa a Casper.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1087
translate Spanish day9nsfwscene_d3c46d0a:

    # GRC "Sunshine..."
    GRC "Solecito..."

# game/NSFW Patch/nsfwpatch.rpy:1100
translate Spanish day9nsfwscene_4355f81a:

    # "{i}The words hang in the air, heavy and hot, and you can hear Casper's breath hitch in his throat.{/i}"
    "{i}Las palabras quedan suspendidas en el aire, pesadas y calientes, y oyes cómo se le corta la respiración a Casper.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1104
translate Spanish day9nsfwscene_3fb40237:

    # GRC "Ha... ha... Sunshine, I..."
    GRC "Ah... ah... Solecito, yo..."

# game/NSFW Patch/nsfwpatch.rpy:1105
translate Spanish day9nsfwscene_2f7dd605:

    # GRC "Are you... are you sure?"
    GRC "¿Estás... estás segur[letra]?"

# game/NSFW Patch/nsfwpatch.rpy:1123
translate Spanish day9nsfwscene_927332cc:

    # "{i}And that's all it takes - a moment later your back meets Casper's bed. You instinctively reach up to cup his growing hardness, and the gasp he lets out is intoxicating.{/i}"
    "{i}Y eso es todo lo que hace falta: un momento después tu espalda encuentra la cama de Casper. Instintivamente alargas la mano para envolver su dureza creciente, y el jadeo que se le escapa es embriagador.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1124
translate Spanish day9nsfwscene_1d8b4d06:

    # "{i}You watch as he throws his gloves to the side, desperate to feel your skin against his own.{/i}"
    "{i}Le ves tirar los guantes a un lado, desesperado por sentir tu piel contra la suya.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1125
translate Spanish day9nsfwscene_ba64d2fe:

    # "{i}His hands move under your shirt, and his fingertips trace along the lines of your body. Every touch brings with it that buzz-like feeling - the feeling of your souls resonating, finding completeness.{/i}"
    "{i}Sus manos se deslizan bajo tu camisa y las yemas de sus dedos recorren las líneas de tu cuerpo. Cada roce trae consigo ese zumbido: la sensación de que sus almas resuenan, encontrando la plenitud.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1132
translate Spanish day9nsfwscene_e6a59885:

    # GRC "Can I... take off your clothes?"
    GRC "¿Puedo... quitarte la ropa?"

# game/NSFW Patch/nsfwpatch.rpy:1134
translate Spanish day9nsfwscene_49da07a8:

    # "{i}You nod furiously as you start to do the same to him - unbuttoning buttons, unzipping zippers and unbuckling buckles.{/i}"
    "{i}Asientes con frenesí mientras empiezas a hacer lo mismo con él: desabrochando botones, bajando cremalleras y soltando hebillas.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1135
translate Spanish day9nsfwscene_bad524fc:

    # "{i}And boy, does this man have a lot of zips and buckles.{/i}"
    "{i}Y vaya si este hombre tiene cremalleras y hebillas.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1136
translate Spanish day9nsfwscene_5eaa52e8:

    # "{i}By the time he's managed to slip your clothes off of you, you've barely gotten half of his off.{/i}"
    "{i}Para cuando él ha conseguido quitarte la ropa, tú apenas has logrado quitarle la mitad de la suya.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1143
translate Spanish day9nsfwscene_b24528f1:

    # "{i}But that's not really your focus.{/i}"
    "{i}Pero eso no es realmente tu prioridad.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1144
translate Spanish day9nsfwscene_677b881b:

    # "{i}You see the way his cock strains against his underwear, twitching, and then finally pull it free.{/i}"
    "{i}Ves cómo su pene tensa la ropa interior, latiendo, y finalmente lo liberas.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1147
translate Spanish day9nsfwscene_2883e725:

    # "{i}Your own dick twitches at the sight. Casper is... well-endowed, to say the least.{/i}"
    "{i}Tu propio pene se estremece ante la vista. Casper está... bien dotado, por decirlo suavemente.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1150
translate Spanish day9nsfwscene_12d81152:

    # "{i}You feel a pooling heat between your legs, looking at his size. He's definitely not lacking.{/i}"
    "{i}Sientes un calor acumulándose entre tus piernas al contemplar su tamaño. Definitivamente no le falta de nada.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1155
translate Spanish day9nsfwscene_9467829c_1:

    # GRC "....."
    GRC "....."

# game/NSFW Patch/nsfwpatch.rpy:1156
translate Spanish day9nsfwscene_f7507b35:

    # GRC "What?"
    GRC "¿Qué?"

# game/NSFW Patch/nsfwpatch.rpy:1163
translate Spanish day9nsfwscene_9467829c_2:

    # GRC "....."
    GRC "....."

# game/NSFW Patch/nsfwpatch.rpy:1167
translate Spanish day9nsfwscene_18f36d7f:

    # GRC "Your... you... how can you say something like that so easily..."
    GRC "Tú... cómo puedes decir algo así con tanta facilidad..."

# game/NSFW Patch/nsfwpatch.rpy:1174
translate Spanish day9nsfwscene_008afe10_1:

    # GRC "..."
    GRC "..."

# game/NSFW Patch/nsfwpatch.rpy:1176
translate Spanish day9nsfwscene_87f4a386:

    # GRC "I... want it too. I want to... be deep inside of you."
    GRC "Yo... también lo quiero. Quiero... estar profundamente dentro de ti."

# game/NSFW Patch/nsfwpatch.rpy:1180
translate Spanish day9nsfwscene_e1b95f83:

    # GRC "You..."
    GRC "Tú..."

# game/NSFW Patch/nsfwpatch.rpy:1181
translate Spanish day9nsfwscene_533036ab:

    # GRC "Looking down at you like this is more than I can manage..."
    GRC "Mirarte desde arriba de esta forma es más de lo que puedo soportar..."

# game/NSFW Patch/nsfwpatch.rpy:1182
translate Spanish day9nsfwscene_f2a70b01:

    # GRC "You are... radiant."
    GRC "Eres... radiante."

# game/NSFW Patch/nsfwpatch.rpy:1256
translate Spanish day9nsfwscene_10059618:

    # "{i}His hands, no longer gloved, slide down to grip your hips, pulling them towards him.{/i}"
    "{i}Sus manos, ya sin guantes, se deslizan hacia abajo para agarrar tus caderas y atraerlas hacia él.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1279
translate Spanish day9nsfwscene_af5cf2cc:

    # "{i}Timidly at first, Casper presses his length to yours.{/i}"
    "{i}Al principio con timidez, Casper presiona su longitud contra la tuya.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1280
translate Spanish day9nsfwscene_5c9d0688:

    # "{i}He's warm, and the contact sends a shock through your system - and then he starts moving, grinding his dick against your own.{/i}"
    "{i}Está caliente, y el contacto envía una descarga por todo tu sistema; luego empieza a moverse, frotando su pene contra el tuyo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1301
translate Spanish day9nsfwscene_a7709cf6:

    # "{i}Timidly at first, Casper presses his length between your legs, rubbing the tip of his cock against your clit as he grinds.{/i}"
    "{i}Al principio con timidez, Casper presiona su longitud entre tus piernas, frotando la punta de su pene contra tu clítoris mientras se mueve.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1303
translate Spanish day9nsfwscene_e524a34b:

    # "{i}You let out a whimper at the sudden movement, and Casper bites his lip, trying to keep himself contained.{/i}"
    "{i}Dejas escapar un gemido ante el movimiento repentino, y Casper se muerde el labio, intentando contenerse.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1304
translate Spanish day9nsfwscene_32e150f4:

    # "{i}Instantly you're reminded of your actions just last night, of the overwhelming pleasure that came from simply touching Casper.{/i}"
    "{i}Al instante recuerdas lo de anoche, el placer abrumador que sentiste con solo tocar a Casper.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1305
translate Spanish day9nsfwscene_bce986ea:

    # "{i}Right now, with Casper above you, rubbing his dick against you, it's almost too much to handle.{/i}"
    "{i}Ahora mismo, con Casper encima de ti, frotando su pene contra ti, es casi demasiado para soportar.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1309
translate Spanish day9nsfwscene_6d58e319:

    # "{i}The pleasure doubles over itself, short circuiting your system. You feel his length against you, but you also feel his pleasure on top of that.{/i}"
    "{i}El placer se duplica sobre sí mismo, cortocircuitando tu sistema. Sientes su longitud contra ti, pero también sientes su placer encima de eso.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1310
translate Spanish day9nsfwscene_9f2a3aba:

    # "{i}It's like an infinite loop of ecstasy, and for each moment that passes, it becomes that much more difficult to distinguish what is Casper's pleasure, and what is your own.{/i}"
    "{i}Es como un bucle infinito de éxtasis, y a cada segundo que pasa se vuelve más difícil distinguir qué es el placer de Casper y qué es el tuyo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1320
translate Spanish day9nsfwscene_74a21a81:

    # GRC "Ha... ah... okay..."
    GRC "Ah... ah... okey..."

# game/NSFW Patch/nsfwpatch.rpy:1324
translate Spanish day9nsfwscene_9601ea18:

    # "{i}At some point, a bottle of lube appeared on the bed beside you.{/i}"
    "{i}En algún momento apareció una botella de lubricante en la cama a tu lado.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1325
translate Spanish day9nsfwscene_14107064:

    # "{i}You never saw Casper get it out - he's smooth.{/i}"
    "{i}Nunca le viste sacarla; es muy hábil.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1331
translate Spanish day9nsfwscene_008afe10_2:

    # GRC "..."
    GRC "..."

# game/NSFW Patch/nsfwpatch.rpy:1359
translate Spanish day9nsfwscene_2c07faca:

    # "{i}You reach up, stroking his dick from base to tip, drawing out your touch as you look into his eyes.{/i}"
    "{i}Alargas la mano y acaricias su pene de la base a la punta, alargando el roce mientras le miras a los ojos.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1366
translate Spanish day9nsfwscene_b2742a6f:

    # GRC "Shut up."
    GRC "Cállate."

# game/NSFW Patch/nsfwpatch.rpy:1367
translate Spanish day9nsfwscene_b3b0d703:

    # GRC "The... after yesterday, there was... always going to be a possibility..."
    GRC "Después de... de ayer, siempre iba a haber... una posibilidad..."

# game/NSFW Patch/nsfwpatch.rpy:1368
translate Spanish day9nsfwscene_5fcd7b17:

    # GRC "Better to... ah... be prepared..."
    GRC "Mejor... ah... estar preparado..."

# game/NSFW Patch/nsfwpatch.rpy:1389
translate Spanish day9nsfwscene_113c9126:

    # "{i}Casper's cock lines up with your entrance, the head just brushing against you.{/i}"
    "{i}El pene de Casper se alinea con tu entrada; la cabeza apenas te roza.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1440
translate Spanish day9nsfwscene_195b479b:

    # "{i}You watch a bead of precum gather at the tip, and then he slowly pushes into you.{/i}"
    "{i}Ves cómo una gota de líquido preseminal se acumula en la punta, y entonces él empuja lentamente dentro de ti.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1441
translate Spanish day9nsfwscene_e1283d83:

    # "{i}His size stretches you out, and you grip at his arms, waiting in case of any pain.... but it never comes.{/i}"
    "{i}Su tamaño te estira, y te aferras a sus brazos, esperando el dolor... pero no llega.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1485
translate Spanish day9nsfwscene_fd8fba6b:

    # GRC "Ah... ha... gods, you are.... tight..."
    GRC "Ah... ah... dioses, estás... tan estrech[letra]..."

# game/NSFW Patch/nsfwpatch.rpy:1486
translate Spanish day9nsfwscene_2ec997ae:

    # "{i}In place of any pain or discomfort from his size, you feel waves and waves of pleasure crashing over you.{/i}"
    "{i}En lugar de dolor o molestia por su tamaño, sientes oleada tras oleada de placer estrellándose contra ti.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1487
translate Spanish day9nsfwscene_00783b47:

    # "{i}Casper's own pleasure and yours mingle inside of you. It feels like nothing you've ever felt before.{/i}"
    "{i}El placer de Casper y el tuyo se mezclan dentro de ti. Es una sensación que nunca habías experimentado.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1493
translate Spanish day9nsfwscene_17747b19:

    # GRC "Fuck... our connection... it's almost too much..."
    GRC "Maldición... nuestra conexión... es casi demasiado..."

# game/NSFW Patch/nsfwpatch.rpy:1501
translate Spanish day9nsfwscene_a1ce594b:

    # "{i}At that, he pushes in further. You feel the way his tip reaches deep inside you until he's filled you to his hilt.{/i}"
    "{i}Entonces empuja más. Sientes cómo la punta llega profundamente hasta que te llena por completo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1502
translate Spanish day9nsfwscene_01075cad:

    # GRC "S... Sunshine, you... you feel so good..."
    GRC "S... Solecito, te... te sientes tan bien..."

# game/NSFW Patch/nsfwpatch.rpy:1503
translate Spanish day9nsfwscene_e8f79208:

    # "{i}Before he's even noticed he's doing it, he starts to move. It's slow, gentle, and each thrust pushes deeper, stretching you open further.{/i}"
    "{i}Antes de que se dé cuenta, empieza a moverse. Es lento, suave, y cada embestida llega más profundo, abriéndote aún más.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1509
translate Spanish day9nsfwscene_e90ba7f8:

    # "{i}The moan comes from deep inside your chest. It's a sound that seems to reverberate throughout the entire room, and you're certain you've never made such a sound before.{/i}"
    "{i}El gemido surge desde lo más profundo de tu pecho. Es un sonido que parece reverberar por toda la habitación, y estás segur[letra] de que nunca habías emitido un sonido así.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1510
translate Spanish day9nsfwscene_9bb96d3a:

    # "{i}But, judging by the reaction it had on Casper, he seems to like it.{/i}"
    "{i}Pero, a juzgar por la reacción de Casper, parece que le gusta.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1511
translate Spanish day9nsfwscene_3ec7e592:

    # GRC "I... ah... haa..."
    GRC "Yo... ah... jaa..."

# game/NSFW Patch/nsfwpatch.rpy:1514
translate Spanish day9nsfwscene_49d99183:

    # GRC "I want to make you sound like that again. Again and again forever."
    GRC "Quiero hacerte gemir así otra vez. Una y otra vez, para siempre."

# game/NSFW Patch/nsfwpatch.rpy:1515
translate Spanish day9nsfwscene_b53e2bf1:

    # "{i}He picks up the pace, thrusting faster and harder, consumed by his desire to please you.{/i}"
    "{i}Acelera el ritmo, embistiendo más rápido y con más fuerza, consumido por el deseo de complacerte.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1516
translate Spanish day9nsfwscene_e2d838e4:

    # "{i}His hips crash into yours with each motion, and the sensation of being taken by Casper like this is... indescribable.{/i}"
    "{i}Sus caderas chocan contra las tuyas con cada movimiento, y la sensación de ser tomad[letra] por Casper de esta forma es... indescriptible.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1517
translate Spanish day9nsfwscene_f5642391:

    # "{i}If touching him is like an electric current, fucking him is like the entire damn generator.{/i}"
    "{i}Si tocarlo es como una corriente eléctrica, acostarte con él es como todo el maldito generador.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1518
translate Spanish day9nsfwscene_f3a8c121:

    # "{i}You don't even need to reach down and touch yourself - there's no need. Through Casper, it already feels like you're getting double the stimulation.{/i}"
    "{i}Ni siquiera necesitas llevar la mano hacia abajo para tocarte: no hace falta. A través de Casper ya sientes el doble de estimulación.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1519
translate Spanish day9nsfwscene_4b6354a2:

    # "{i}Your eyes screw shut, your head tilts back, and the moans that leave your mouth are loud, unashamed.{/i}"
    "{i}Cierras los ojos con fuerza, echas la cabeza hacia atrás y los gemidos que salen de tu boca son fuertes, sin vergüenza.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1521
translate Spanish day9nsfwscene_7378d772:

    # GRC "Haaa.... ah, Sunshine, look at you..."
    GRC "Jaaa.... ah, Solecito, mírate..."

# game/NSFW Patch/nsfwpatch.rpy:1522
translate Spanish day9nsfwscene_ff544a7d:

    # GRC "You take me... so well..."
    GRC "Me recibes... tan bien..."

# game/NSFW Patch/nsfwpatch.rpy:1523
translate Spanish day9nsfwscene_952f84c3:

    # GRC "You are... everything."
    GRC "Eres... todo."

# game/NSFW Patch/nsfwpatch.rpy:1524
translate Spanish day9nsfwscene_77873126:

    # "{i}You can't help but whimper at his praise. His thrusts are becoming harder, his breathing is heavy, and his words are thick with lust.{/i}"
    "{i}No puedes evitar gemir ante sus elogios. Sus embestidas se vuelven más fuertes, su respiración es pesada y sus palabras están cargadas de lujuria.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1525
translate Spanish day9nsfwscene_c60e35f0:

    # GRC "Ah... I can feel... the way you tighten around me..."
    GRC "Ah... puedo sentir... cómo te aprietas a mi alrededor..."

# game/NSFW Patch/nsfwpatch.rpy:1527
translate Spanish day9nsfwscene_9e01b179:

    # GRC "Ha.... it feels so..."
    GRC "Ah.... se siente tan..."

# game/NSFW Patch/nsfwpatch.rpy:1528
translate Spanish day9nsfwscene_647208a0:

    # "{i}He groans and pants above you, his fingers digging into your leg, as if to keep himself from coming.{/i}"
    "{i}Gime y jadea encima de ti; sus dedos se clavan en tu pierna, como si intentara contenerse para no correrse.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1529
translate Spanish day9nsfwscene_245230f4:

    # "{i}Not yet. Those words echo through your mind, and you're sure the same words are on his tongue.{/i}"
    "{i}Aún no. Esas palabras resuenan en tu mente, y estás segur[letra] de que las mismas palabras están en su lengua.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1535
translate Spanish day9nsfwscene_c3194c16:

    # "{i}His name comes from your mouth like a mantra, and his thrusts quicken at the sound.{/i}"
    "{i}Su nombre sale de tu boca como un mantra, y sus embestidas se aceleran al oírlo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1536
translate Spanish day9nsfwscene_9187555b:

    # "{i}With every movement, every touch, the line where the two of you meet begins to blur.{/i}"
    "{i}Con cada movimiento, con cada roce, la línea donde se encuentran empieza a difuminarse.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1537
translate Spanish day9nsfwscene_f35b7193:

    # "{i}Your bodies, intertwined. Your souls, connected.{/i}"
    "{i}Sus cuerpos, entrelazados. Sus almas, conectadas.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1538
translate Spanish day9nsfwscene_87d54efe:

    # "{i}And when Casper hits a particularly sweet spot, your eyes shoot open and your vision goes white, stars and light dancing behind your eyelids.{/i}"
    "{i}Y cuando Casper da en un punto especialmente sensible, tus ojos se abren de golpe y tu visión se vuelve blanca; estrellas y luz bailan detrás de tus párpados.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1539
translate Spanish day9nsfwscene_53afe953:

    # "{i}At the same time, he nearly buckles over you, the pleasure and sensation too much for him.{/i}"
    "{i}Al mismo tiempo, casi se derrumba encima de ti; el placer y la sensación son demasiado para él.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1613
translate Spanish day9nsfwscene_a72dcb55:

    # "{i}Your release is sudden, and intense, and you can feel Casper's as well.{/i}"
    "{i}Tu orgasmo es repentino e intenso, y también sientes el de Casper.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1614
translate Spanish day9nsfwscene_736ab0db:

    # "{i}Cum spills out, covering his cock and your walls, and a soft gasp leaves your throat as he continues thrusting, riding out both of your orgasms.{/i}"
    "{i}El semen se derrama, cubriendo su pene y tus paredes, y un suave jadeo se te escapa de la garganta mientras él sigue embistiendo, prolongando ambos orgasmos.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1615
translate Spanish day9nsfwscene_d3c46d0a_1:

    # GRC "Sunshine..."
    GRC "Solecito..."

# game/NSFW Patch/nsfwpatch.rpy:1616
translate Spanish day9nsfwscene_7c7486f7:

    # "{i}His voice comes out breathy and low, and the sound sends a shiver up your spine.{/i}"
    "{i}Su voz sale entrecortada y baja, y el sonido te provoca un escalofrío por la espalda.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1620
translate Spanish day9nsfwscene_7fcdb1e7:

    # "{i}He's leaning over you now, his body pressing against yours.{/i}"
    "{i}Ahora se inclina sobre ti, su cuerpo presionando el tuyo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1621
translate Spanish day9nsfwscene_3716f5b0:

    # GRC "Ha.... ha... that was..."
    GRC "Ah.... ah... eso fue..."

# game/NSFW Patch/nsfwpatch.rpy:1622
translate Spanish day9nsfwscene_04987108:

    # GRC "Nine hells, I never knew it could be so good..."
    GRC "Por los nueve infiernos, nunca supe que podía ser tan bueno..."

# game/NSFW Patch/nsfwpatch.rpy:1626
translate Spanish day9nsfwscene_2a37a578:

    # GRC "A week ago I would have laughed at the notion."
    GRC "Hace una semana me habría reído de la idea."

# game/NSFW Patch/nsfwpatch.rpy:1627
translate Spanish day9nsfwscene_9852b13d:

    # GRC "Now... I... I find it hard to deny."
    GRC "Ahora... me... me resulta difícil negarlo."

# game/NSFW Patch/nsfwpatch.rpy:1628
translate Spanish day9nsfwscene_0cf8e42e:

    # GRC "When I am inside of you, it feels as if the universe has finally come together."
    GRC "Cuando estoy dentro de ti, siento como si el universo por fin se hubiera unido."

# game/NSFW Patch/nsfwpatch.rpy:1629
translate Spanish day9nsfwscene_62010ef0:

    # GRC "Like the pieces of the puzzle have fit."
    GRC "Como si las piezas del puzzle hubieran encajado."

# game/NSFW Patch/nsfwpatch.rpy:1630
translate Spanish day9nsfwscene_008afe10_3:

    # GRC "..."
    GRC "..."

# game/NSFW Patch/nsfwpatch.rpy:1631
translate Spanish day9nsfwscene_319a65ac:

    # GRC "You and I, together. It makes me feel complete."
    GRC "Tú y yo, juntos. Me hace sentir completo."

# game/NSFW Patch/nsfwpatch.rpy:1632
translate Spanish day9nsfwscene_93880d64:

    # GRC "I do not understand it. I find it infuriating to not understand something, usually."
    GRC "No lo entiendo. Normalmente me enfurece no entender algo."

# game/NSFW Patch/nsfwpatch.rpy:1633
translate Spanish day9nsfwscene_a5d844d6:

    # GRC "But... perhaps this time I can accept it."
    GRC "Pero... quizá esta vez pueda aceptarlo."

# game/NSFW Patch/nsfwpatch.rpy:1634
translate Spanish day9nsfwscene_bf05ac0d:

    # GRC "We... we should clean up."
    GRC "Deberíamos... deberíamos limpiarnos."

# game/NSFW Patch/nsfwpatch.rpy:1640
translate Spanish day9nsfwscene_a8d15598:

    # "{i}You watch his cheeks become three shades redder, somehow.{/i}"
    "{i}Ves cómo sus mejillas se ponen tres tonos más rojas, de alguna manera.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1641
translate Spanish day9nsfwscene_f9b21dc9:

    # GRC "You... you should not say something so... so..."
    GRC "No... no deberías decir algo tan... tan..."

# game/NSFW Patch/nsfwpatch.rpy:1642
translate Spanish day9nsfwscene_0987274e:

    # GRC "Gods above and below, you've made a mess of me...."
    GRC "Por los dioses de arriba y de abajo, me has dejado hecho un desastre...."

# game/NSFW Patch/nsfwpatch.rpy:1646
translate Spanish day9nsfwscene_013f28d9:

    # GRC "I am afraid that could lead to a second act to our... current performance."
    GRC "Me temo que eso podría llevar a un segundo acto de nuestra... actuación actual."

# game/NSFW Patch/nsfwpatch.rpy:1647
translate Spanish day9nsfwscene_008afe10_4:

    # GRC "..."
    GRC "..."

# game/NSFW Patch/nsfwpatch.rpy:1648
translate Spanish day9nsfwscene_17c5253a:

    # GRC "But, that is not a bad thing, I suppose. Not at all."
    GRC "Pero no es algo malo, supongo. En absoluto."

# game/NSFW Patch/nsfwpatch.rpy:1649
translate Spanish day9nsfwscene_cf690e7d:

    # GRC "In fact, I think I would prefer a second, and third, and fourth act."
    GRC "De hecho, creo que preferiría un segundo, un tercero y un cuarto acto."

# game/NSFW Patch/nsfwpatch.rpy:1665
translate Spanish day9nsfwscene_4355f81a_1:

    # "{i}The words hang in the air, heavy and hot, and you can hear Casper's breath hitch in his throat.{/i}"
    "{i}Las palabras quedan suspendidas en el aire, pesadas y calientes, y oyes cómo se le corta la respiración a Casper.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1666
translate Spanish day9nsfwscene_aaf8bd7d:

    # GRC "Are you... are you certain?"
    GRC "¿Estás... estás segur[letra]?"

# game/NSFW Patch/nsfwpatch.rpy:1675
translate Spanish day9nsfwscene_7bbc22a0:

    # "{i}You reach up and run your fingers through the back of Casper's hair, and he lets out a shaky breath.{/i}"
    "{i}Alargas la mano y pasas los dedos por la nuca de Casper; él suelta un suspiro tembloroso.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1676
translate Spanish day9nsfwscene_7548ae1f:

    # "{i}He looks at you with glassy eyes, and his lips find yours once more, hungry and passionate.{/i}"
    "{i}Te mira con los ojos vidriosos y sus labios encuentran los tuyos de nuevo, hambrientos y apasionados.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1677
translate Spanish day9nsfwscene_ff08c4ac:

    # "{i}All of his years of being starved of touch are being made up for tenfold as your hand finds his growing hardness once again.{/i}"
    "{i}Todos sus años de privación de tacto se compensan por diez cuando tu mano encuentra de nuevo su dureza creciente.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1678
translate Spanish day9nsfwscene_7be45844:

    # "{i}As you lead Casper backwards, touching and caressing and kissing all the while, you watch him throw his gloves to the side, then he slides his bare hands up your sides.{/i}"
    "{i}Mientras guías a Casper hacia atrás, tocándolo, acariciándolo y besándolo todo el tiempo, le ves tirar los guantes a un lado y luego deslizar sus manos desnudas por tus costados.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1679
translate Spanish day9nsfwscene_240c539f:

    # "{i}The sensation of his skin on yours is intoxicating - almost electric. Every touch brings with it that buzz-like feeling - the feeling of your souls resonating, finding completeness.{/i}"
    "{i}La sensación de su piel sobre la tuya es embriagadora, casi eléctrica. Cada roce trae consigo ese zumbido: la sensación de que sus almas resuenan, encontrando la plenitud.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1680
translate Spanish day9nsfwscene_43d62540:

    # "{i}And then, with one final push, Casper collapses to his bed beneath you. You straddle him, then look down at him with a smirk.{/i}"
    "{i}Y entonces, con un último empujón, Casper se desploma en la cama debajo de ti. Te subes a horcajadas sobre él y le miras desde arriba con una sonrisa de lado.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1687
translate Spanish day9nsfwscene_9467829c_3:

    # GRC "....."
    GRC "....."

# game/NSFW Patch/nsfwpatch.rpy:1688
translate Spanish day9nsfwscene_7b25558e:

    # "{i}You can't help but admire him like this. The way his normally perfectly kept hair has become mussed, the way his face is flushed, the way his lips are parted as he pants.{/i}"
    "{i}No puedes evitar admirarlo así. Cómo su cabello, normalmente tan perfecto, se ha desordenado; cómo tiene el rostro sonrojado; cómo tiene los labios entreabiertos mientras jadea.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1689
translate Spanish day9nsfwscene_c47849c9:

    # "{i}And the way he looks back at you.{/i}"
    "{i}Y la forma en que te mira a su vez.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1690
translate Spanish day9nsfwscene_3909146a:

    # "{i}As if you were a piece of art.{/i}"
    "{i}Como si fueras una obra de arte.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1691
translate Spanish day9nsfwscene_426ee8b1:

    # GRC "Gods, you are just..."
    GRC "Dioses, eres simplemente..."

# game/NSFW Patch/nsfwpatch.rpy:1692
translate Spanish day9nsfwscene_57ce192d:

    # GRC "I cannot even put into words the things you make me feel."
    GRC "Ni siquiera puedo poner en palabras las cosas que me haces sentir."

# game/NSFW Patch/nsfwpatch.rpy:1693
translate Spanish day9nsfwscene_1d76a8a3:

    # GRC "The things you DO to me."
    GRC "Las cosas que me HACES."

# game/NSFW Patch/nsfwpatch.rpy:1702
translate Spanish day9nsfwscene_941d2360:

    # GRC "...Please."
    GRC "...Por favor."

# game/NSFW Patch/nsfwpatch.rpy:1705
translate Spanish day9nsfwscene_dbaafc49:

    # "{i}Slowly, you undo each buckle, strap and zip Casper has on him - which is, in your opinion, far too many.{/i}"
    "{i}Despacio, vas desabrochando cada hebilla, correa y cremallera que lleva Casper, que, en tu opinión, son demasiadas.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1706
translate Spanish day9nsfwscene_a83b6cb3:

    # "{i}But it definitely makes for some good teasing.{/i}"
    "{i}Pero sin duda da para unas buenas provocaciones.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1707
translate Spanish day9nsfwscene_f1c2c49d:

    # "{i}A hand brushing against him here, a tugging on a zipper there, a slight kiss on a hipbone...{/i}"
    "{i}Una mano rozándolo aquí, un tirón de cremallera allá, un beso ligero en un hueso de la cadera...{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1708
translate Spanish day9nsfwscene_56a8d0b4:

    # "{i}By the time Casper is completely undressed, the look on his face is a desperate sort of hunger.{/i}"
    "{i}Para cuando Casper está completamente desnudo, la expresión de su rostro es de un hambre desesperada.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1712
translate Spanish day9nsfwscene_5c5e68ad:

    # "{i}He visibly gulps.{/i}"
    "{i}Traga saliva de forma visible.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1713
translate Spanish day9nsfwscene_6301f245:

    # "{i}And you begin to strip layer after layer from your body, still straddling his hips, rubbing against his exposed cock.{/i}"
    "{i}Y empiezas a quitarte capa tras capa, aún a horcajadas sobre sus caderas, frotándote contra su pene al descubierto.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1714
translate Spanish day9nsfwscene_c39caadc:

    # "{i}The friction is a delicious sort of torture, and as you pull free the final piece of clothing from your body, Casper looks like he's about to explode.{/i}"
    "{i}La fricción es una tortura deliciosa, y cuando te quitas la última prenda, Casper parece a punto de explotar.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1717
translate Spanish day9nsfwscene_1a620341:

    # "{i}Your own cock is already hard when you finally pull your underwear from your body{/i}"
    "{i}Tu propio pene ya está duro cuando finalmente te quitas la ropa interior.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1718
translate Spanish day9nsfwscene_1bdfb31d:

    # "{i}Pre-cum beads at the tip, and you can't help the satisfied grin that appears on your face as you see the look in Casper's eyes.{/i}"
    "{i}El líquido preseminal se acumula en la punta, y no puedes evitar la sonrisa de satisfacción que se dibuja en tu rostro al ver la expresión de los ojos de Casper.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1721
translate Spanish day9nsfwscene_ec1dd0f9:

    # "{i}A hot wetness has grown between your legs, and the sight of you nude and wet for him makes Casper's dick throb and his breathing grow shallow.{/i}"
    "{i}Una humedad caliente se ha acumulado entre tus piernas, y la visión de ti desnud[letra] y mojad[letra] por él hace que el pene de Casper lata y su respiración se vuelva superficial.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1729
translate Spanish day9nsfwscene_9467829c_4:

    # GRC "....."
    GRC "....."

# game/NSFW Patch/nsfwpatch.rpy:1733
translate Spanish day9nsfwscene_29fde1f2:

    # GRC "I... I am..."
    GRC "Yo... yo estoy..."

# game/NSFW Patch/nsfwpatch.rpy:1738
translate Spanish day9nsfwscene_746b3edd:

    # GRC "You... did?"
    GRC "¿Tú... lo hiciste?"

# game/NSFW Patch/nsfwpatch.rpy:1739
translate Spanish day9nsfwscene_9c41e845:

    # "{i}You reach down to your bag, pulling out the thing you'd bought just yesterday online.{/i}"
    "{i}Bajas la mano a tu bolso y sacas lo que compraste ayer mismo por internet.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1740
translate Spanish day9nsfwscene_232796e1:

    # "{i}Just in case.{/i}"
    "{i}Por si acaso.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1741
translate Spanish day9nsfwscene_0aaea4a9:

    # "{i}And as it happens, that just in case moment has come to pass.{/i}"
    "{i}Y resulta que ese momento de «por si acaso» ha llegado.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1742
translate Spanish day9nsfwscene_b332002a:

    # GRC "A..."
    GRC "Un..."

# game/NSFW Patch/nsfwpatch.rpy:1756
translate Spanish day9nsfwscene_2cd5b4aa:

    # "{i}Casper nods.{/i}"
    "{i}Casper asiente.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1762
translate Spanish day9nsfwscene_d93acdb6:

    # GRC "Ah... you should not... throw around such a term so easily..."
    GRC "Ah... no deberías... usar ese término con tanta facilidad..."

# game/NSFW Patch/nsfwpatch.rpy:1763
translate Spanish day9nsfwscene_0d5763b0:

    # GRC "It... has an effect on me."
    GRC "Tiene... un efecto en mí."

# game/NSFW Patch/nsfwpatch.rpy:1769
translate Spanish day9nsfwscene_e82ed4c9:

    # "{i}You put it on - again, agonizingly slowly. You desperately want his touch, but making him wait just makes the whole thing that much sweeter.{/i}"
    "{i}Te lo pones, otra vez con una lentitud agonizante. Deseas desesperadamente su tacto, pero hacerlo esperar solo hace que todo sea más dulce.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1770
translate Spanish day9nsfwscene_a6b06561:

    # "{i}All strapped in, you press your new cock up against Casper's.{/i}"
    "{i}Ya ajustad[letra], presionas tu nuevo pene contra el de Casper.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1774
translate Spanish day9nsfwscene_1c500f99:

    # "{i}Standing above Casper, your hand wraps around your own penis, stroking up and down slowly, keeping eye contact with him.{/i}"
    "{i}De pie sobre Casper, tu mano envuelve tu propio pene, subiendo y bajando despacio, manteniendo el contacto visual con él.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1775
translate Spanish day9nsfwscene_8b2c6b08:

    # "{i}He looks entranced - completely mesmerized. His eyes are wide and glazed over, and his gaze follows the movement of your hand.{/i}"
    "{i}Parece hipnotizado, completamente fascinado. Tiene los ojos muy abiertos y vidriosos, y su mirada sigue el movimiento de tu mano.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1776
translate Spanish day9nsfwscene_861e7754:

    # "{i}As if he couldn't decide whether to watch your face or your dick, his head flits back and forth between the two.{/i}"
    "{i}Como si no pudiera decidir si mirar tu cara o tu pene, su cabeza va de un lado a otro.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1777
translate Spanish day9nsfwscene_0d7235a9:

    # "{i}Finally done teasing him, you press your dick to his."
    "{i}Cuando por fin terminas de provocarlo, presionas tu pene contra el suyo."

# game/NSFW Patch/nsfwpatch.rpy:1827
translate Spanish day9nsfwscene_a1ecece1:

    # "{i}Then you start moving, grinding against him, watching the way he writhes under you.{/i}"
    "{i}Entonces empiezas a moverte, frotándote contra él, viendo cómo se retuerce debajo de ti.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1828
translate Spanish day9nsfwscene_48e24a03:

    # "{i}His hands grip the bed underneath him as he moves his hips in turn, craving the friction.{/i}"
    "{i}Sus manos se aferran a la cama mientras mueve las caderas a su vez, ansioso por la fricción.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1829
translate Spanish day9nsfwscene_32e150f4_1:

    # "{i}Instantly you're reminded of your actions just last night, of the overwhelming pleasure that came from simply touching Casper.{/i}"
    "{i}Al instante recuerdas lo de anoche, el placer abrumador que sentiste con solo tocar a Casper.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1830
translate Spanish day9nsfwscene_77589163:

    # "{i}Right now, with Casper under you, it's almost too much to handle.{/i}"
    "{i}Ahora mismo, con Casper debajo de ti, es casi demasiado para soportar.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1831
translate Spanish day9nsfwscene_368780d4:

    # "{i}The pleasure doubles over itself, short circuiting your system. You feel his pleasure - every thrust, every stroke, every sensation - and the pleasure is multiplied.{/i}"
    "{i}El placer se duplica sobre sí mismo, cortocircuitando tu sistema. Sientes su placer —cada embestida, cada caricia, cada sensación— y el placer se multiplica.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1832
translate Spanish day9nsfwscene_5801192f:

    # "{i}It's like an infinite loop of ecstasy, and as the moments pass, the more difficult it becomes to distinguish what is Casper's pleasure, and what is your own.{/i}"
    "{i}Es como un bucle infinito de éxtasis, y a medida que pasan los segundos se vuelve más difícil distinguir qué es el placer de Casper y qué es el tuyo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1836
translate Spanish day9nsfwscene_38343cb1:

    # "{i}It's like... nothing you have ever felt before. Despite your cock being made of silicone, it's almost like it's real, as the sensations that Casper feels echo through you.{/i}"
    "{i}Es como... nada que hayas sentido nunca. Aunque tu pene sea de silicona, casi parece real, porque las sensaciones que siente Casper resuenan a través de ti.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1837
translate Spanish day9nsfwscene_011a0bc3:

    # "{i}It's heavenly.{/i}"
    "{i}Es celestial.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1841
translate Spanish day9nsfwscene_a79a24a4:

    # "{i}Your dick twitches, throbbing as it presses against his. Casper feels so hot and hard against you.{/i}"
    "{i}Tu pene se estremece, latiendo mientras se presiona contra el suyo. Casper se siente tan caliente y duro contra ti.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1842
translate Spanish day9nsfwscene_fbfcc61e:

    # "{i}And the noises he makes - god, the noises he makes.{/i}"
    "{i}Y los sonidos que hace... dios, los sonidos que hace.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1849
translate Spanish day9nsfwscene_73e716ff:

    # GRC "Ugh... ah... Sun... shine..."
    GRC "Ugh... ah... Sole... cito..."

# game/NSFW Patch/nsfwpatch.rpy:1853
translate Spanish day9nsfwscene_27b62eef:

    # GRC "It feels..."
    GRC "Se siente..."

# game/NSFW Patch/nsfwpatch.rpy:1854
translate Spanish day9nsfwscene_9467829c_5:

    # GRC "....."
    GRC "....."

# game/NSFW Patch/nsfwpatch.rpy:1855
translate Spanish day9nsfwscene_6aa1c6ef:

    # GRC "So. Damn. Good."
    GRC "Tan. Malditamente. Bien."

# game/NSFW Patch/nsfwpatch.rpy:1856
translate Spanish day9nsfwscene_7eee55a0:

    # GRC "Fuck, it almost makes me angry how good it feels."
    GRC "Maldición, casi me enfada lo bien que se siente."

# game/NSFW Patch/nsfwpatch.rpy:1857
translate Spanish day9nsfwscene_3899b161:

    # GRC "That a mortal could destroy me so... and yet, I... I feel happy, too..."
    GRC "Que un mortal pueda destruirme así... y, sin embargo, yo... también me siento feliz..."

# game/NSFW Patch/nsfwpatch.rpy:1858
translate Spanish day9nsfwscene_dcddf5ca:

    # GRC "Because it's you."
    GRC "Porque eres tú."

# game/NSFW Patch/nsfwpatch.rpy:1859
translate Spanish day9nsfwscene_d43e50cc:

    # GRC "I would happily be destroyed for you."
    GRC "Me destruiría con gusto por ti."

# game/NSFW Patch/nsfwpatch.rpy:1860
translate Spanish day9nsfwscene_186bccf0:

    # "{i}You reach out and stroke his cheek.{/i}"
    "{i}Alargas la mano y acaricias su mejilla.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1861
translate Spanish day9nsfwscene_91c7e51b:

    # "{i}There's that familiar buzzing - your souls touching one another. You let out a content sigh.{/i}"
    "{i}Ahí está ese zumbido familiar: sus almas tocándose. Dejas escapar un suspiro de satisfacción.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1873
translate Spanish day9nsfwscene_6b9dd621:

    # "{i}Pulling away from Casper slightly, you position yourself between his legs.{/i}"
    "{i}Te apartas un poco de Casper y te colocas entre sus piernas.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1874
translate Spanish day9nsfwscene_f538bb2e:

    # "{i}You can't help but admire his body for a moment. His lean muscles, his pale skin, his cock standing at attention.{/i}"
    "{i}No puedes evitar admirar su cuerpo un momento. Sus músculos delgados, su piel pálida, su pene erecto.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1875
translate Spanish day9nsfwscene_9601ea18_1:

    # "{i}At some point, a bottle of lube appeared on the bed beside you.{/i}"
    "{i}En algún momento apareció una botella de lubricante en la cama a tu lado.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1876
translate Spanish day9nsfwscene_14107064_1:

    # "{i}You never saw Casper get it out - he's smooth.{/i}"
    "{i}Nunca le viste sacarla; es muy hábil.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1880
translate Spanish day9nsfwscene_008afe10_5:

    # GRC "..."
    GRC "..."

# game/NSFW Patch/nsfwpatch.rpy:1881
translate Spanish day9nsfwscene_e940b154:

    # "{i}You reach down, stroking his dick from base to tip, drawing out your touch as you look into his eyes.{/i}"
    "{i}Bajas la mano y acaricias su pene de la base a la punta, alargando el roce mientras le miras a los ojos.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1888
translate Spanish day9nsfwscene_b2742a6f_1:

    # GRC "Shut up."
    GRC "Cállate."

# game/NSFW Patch/nsfwpatch.rpy:1889
translate Spanish day9nsfwscene_b3b0d703_1:

    # GRC "The... after yesterday, there was... always going to be a possibility..."
    GRC "Después de... de ayer, siempre iba a haber... una posibilidad..."

# game/NSFW Patch/nsfwpatch.rpy:1890
translate Spanish day9nsfwscene_5fcd7b17_1:

    # GRC "Better to... ah... be prepared..."
    GRC "Mejor... ah... estar preparado..."

# game/NSFW Patch/nsfwpatch.rpy:1893
translate Spanish day9nsfwscene_cee7d2ad:

    # "{i}You take a generous pump, then spread the lube over your dick.{/i}"
    "{i}Sacas una generosa cantidad y la extiendes por tu pene.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1896
translate Spanish day9nsfwscene_e149f4d6:

    # "{i}Taking a pump of lube, you pour it onto your strap-on.{/i}"
    "{i}Sacas una cantidad de lubricante y la viertes sobre tu arnés.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1899
translate Spanish day9nsfwscene_347aee12:

    # "{i}With a slick hand, you begin to work the lube over Casper's dick, eliciting a low moan from his throat.{/i}"
    "{i}Con la mano resbaladiza, empiezas a extender el lubricante por el pene de Casper, arrancándole un gemido bajo de la garganta.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1900
translate Spanish day9nsfwscene_0fd90e1b:

    # "{i}Then your hand slides lower.{/i}"
    "{i}Luego tu mano baja más.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1901
translate Spanish day9nsfwscene_8f90be4d:

    # "{i}You cup his balls, gently rolling them, and a louder moan comes from his lips.{/i}"
    "{i}Envuelves sus testículos, haciéndolos rodar con suavidad, y un gemido más fuerte se le escapa de los labios.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1902
translate Spanish day9nsfwscene_3e79c50c:

    # "{i}Finally, your hand moves even further down.{/i}"
    "{i}Finalmente, tu mano baja aún más.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1903
translate Spanish day9nsfwscene_99d79160:

    # "{i}And carefully, you press a finger inside of him.{/i}"
    "{i}Y con cuidado, introduces un dedo en su interior.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1904
translate Spanish day9nsfwscene_21db78d7:

    # "{i}This time, his reaction is a mix between a gasp and a moan, and his thighs tremble slightly.{/i}"
    "{i}Esta vez su reacción es una mezcla de jadeo y gemido, y sus muslos tiemblan ligeramente.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1908
translate Spanish day9nsfwscene_f737534b:

    # GRC "It... does not..."
    GRC "No... no duele..."

# game/NSFW Patch/nsfwpatch.rpy:1909
translate Spanish day9nsfwscene_b1b9e5c8:

    # GRC "It is... quite... ah..."
    GRC "Es... bastante... ah..."

# game/NSFW Patch/nsfwpatch.rpy:1913
translate Spanish day9nsfwscene_ae3f1419:

    # GRC "An understatement, but... ah... it'll have to do..."
    GRC "Es quedarse corto, pero... ah... tendrá que valer..."

# game/NSFW Patch/nsfwpatch.rpy:1914
translate Spanish day9nsfwscene_9e7f652e:

    # "{i}You press your finger in further, exploring, watching Casper's reactions carefully.{/i}"
    "{i}Introduces el dedo más a fondo, explorando, observando con atención las reacciones de Casper.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1915
translate Spanish day9nsfwscene_deb9a190:

    # "{i}After a moment, his breathing begins to deepen, his chest rising and falling faster and faster, and his legs spread wider.{/i}"
    "{i}Al cabo de un momento, su respiración se profundiza, el pecho sube y baja cada vez más rápido y abre más las piernas.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1916
translate Spanish day9nsfwscene_f5678843:

    # "{i}You can feel his muscles relax around your finger, so you press in another. Slowly you stretch him out.{/i}"
    "{i}Sientes cómo sus músculos se relajan alrededor de tu dedo, así que introduces otro. Despacio, lo vas abriendo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1917
translate Spanish day9nsfwscene_d3c46d0a_2:

    # GRC "Sunshine..."
    GRC "Solecito..."

# game/NSFW Patch/nsfwpatch.rpy:1918
translate Spanish day9nsfwscene_5a72f8a4:

    # "{i}His voice is a desperate plea.{/i}"
    "{i}Su voz es una súplica desesperada.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1922
translate Spanish day9nsfwscene_b0cf139f:

    # GRC "Must I beg?"
    GRC "¿Debo rogar?"

# game/NSFW Patch/nsfwpatch.rpy:1928
translate Spanish day9nsfwscene_4d7f5b9d:

    # "{i}You pull your fingers out of Casper, then position the head of your dick between his legs.{/i}"
    "{i}Sacas los dedos de Casper y colocas la cabeza de tu pene entre sus piernas.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1931
translate Spanish day9nsfwscene_c0a417a5:

    # "{i}You pull your fingers out of Casper, then line up your strap-on cock to his entrance.{/i}"
    "{i}Sacas los dedos de Casper y alineas el arnés con su entrada.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1934
translate Spanish day9nsfwscene_d401fc5c:

    # "{i}Slowly, you press inside of him.{/i}"
    "{i}Despacio, te introduces en él.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1985
translate Spanish day9nsfwscene_9364a440:

    # "{i}He tenses at first, but soon relaxes, letting you slide further and further in.{/i}"
    "{i}Al principio se tensa, pero pronto se relaja, dejándote entrar cada vez más.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1988
translate Spanish day9nsfwscene_32479930:

    # "{i}The strap-on has a section that connects to you - a curved part that sits just right, and presses against your clit.{/i}"
    "{i}El arnés tiene una sección que se conecta contigo: una parte curva que se asienta justo en el sitio y presiona contra tu clítoris.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1989
translate Spanish day9nsfwscene_db85f1d3:

    # "{i}With every small movement, it sends pleasure through your body.{/i}"
    "{i}Con cada pequeño movimiento envía placer por todo tu cuerpo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1992
translate Spanish day9nsfwscene_c753a2c4:

    # "{i}He feels so tight around you - Casper's body keeps pulling you deeper and deeper inside, and as you press into him, you can't hold back the sounds that escape from your throat.{/i}"
    "{i}Se siente tan estrecho a tu alrededor: el cuerpo de Casper te va atrayendo cada vez más adentro, y mientras te introduces no puedes contener los sonidos que se te escapan de la garganta.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1993
translate Spanish day9nsfwscene_2eda7d7c:

    # "{i}It's as if your dick was always supposed to fit here - to be held so tight by Casper's body.{/i}"
    "{i}Es como si tu pene hubiera estado siempre destinado a encajar aquí, a ser sostenido con tanta fuerza por el cuerpo de Casper.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1995
translate Spanish day9nsfwscene_db61444f:

    # "{i}But even beyond your own pleasure, there's Casper's.{/i}"
    "{i}Pero incluso más allá de tu propio placer, está el de Casper.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1996
translate Spanish day9nsfwscene_00783b47_1:

    # "{i}Casper's own pleasure and yours mingle inside of you. It feels like nothing you've ever felt before.{/i}"
    "{i}El placer de Casper y el tuyo se mezclan dentro de ti. Es una sensación que nunca habías experimentado.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:1997
translate Spanish day9nsfwscene_e0edc007:

    # GRC "Fuck, it... our... our connection, it's..."
    GRC "Maldición, es... nuestra... nuestra conexión, es..."

# game/NSFW Patch/nsfwpatch.rpy:2006
translate Spanish day9nsfwscene_539b2834:

    # "{i}You push in further and further, until you're buried up to the hilt inside of Casper. You feel a sense of fullness, which continues to surprise you.{/i}"
    "{i}Empujas cada vez más hasta quedar enterrad[letra] hasta la empuñadura dentro de Casper. Sientes una sensación de plenitud que sigue sorprendiéndote.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2007
translate Spanish day9nsfwscene_36f97929:

    # "{i}You're starting to really like this soul connection thing you have going on between you.{/i}"
    "{i}Te está empezando a gustar de verdad esta conexión de almas que comparten.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2008
translate Spanish day9nsfwscene_323bb0b6:

    # "{i}You've never felt a pleasure like it. Two different feelings becoming one. It feels... right. Overwhelming, but right.{/i}"
    "{i}Nunca habías sentido un placer así. Dos sensaciones distintas convirtiéndose en una. Se siente... bien. Abrumador, pero bien.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2009
translate Spanish day9nsfwscene_a97e08d0:

    # "{i}It is bliss. It is... indescribable.{/i}"
    "{i}Es dicha. Es... indescriptible.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2010
translate Spanish day9nsfwscene_32b3cf69:

    # "{i}And so you don't try to describe it - instead, you start moving.{/i}"
    "{i}Y por eso no intentas describirlo: en su lugar, empiezas a moverte.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2011
translate Spanish day9nsfwscene_23cbce6b:

    # "{i}Slowly at first, you rock your hips.{/i}"
    "{i}Al principio despacio, balanceas las caderas.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2012
translate Spanish day9nsfwscene_1a6465d1:

    # "{i}Casper is already moaning, but as you begin to move, his moans become louder.{/i}"
    "{i}Casper ya está gimiendo, pero cuando empiezas a moverte sus gemidos se vuelven más fuertes.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2013
translate Spanish day9nsfwscene_76ce4f3a:

    # GRC "Ah.... ugh..."
    GRC "Ah.... eh..."

# game/NSFW Patch/nsfwpatch.rpy:2014
translate Spanish day9nsfwscene_e074f251:

    # "{i}You continue to speed up, feeling Casper's pleasure building up alongside yours. His dick bobs as you thrust into him, leaking from the tip.{/i}"
    "{i}Sigues acelerando, sintiendo cómo el placer de Casper se acumula junto al tuyo. Su pene se mueve al ritmo de tus embestidas, goteando por la punta.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2015
translate Spanish day9nsfwscene_3b4a5ae9:

    # "{i}You feel like you're losing control. The sensations are so much, so overwhelming, so incredible. Casper's pleasure is yours, and yours is Casper's.{/i}"
    "{i}Sientes que estás perdiendo el control. Las sensaciones son demasiadas, demasiado abrumadoras, demasiado increíbles. El placer de Casper es el tuyo, y el tuyo es el de Casper.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2016
translate Spanish day9nsfwscene_e737c359:

    # "{i}Where do you end, and where does Casper begin?{/i}"
    "{i}¿Dónde terminas tú y dónde empieza Casper?{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2017
translate Spanish day9nsfwscene_28110b19:

    # "{i}Does it matter?{/i}"
    "{i}¿Importa?{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2018
translate Spanish day9nsfwscene_85c69e96:

    # "{i}Not at the moment, that's for sure.{/i}"
    "{i}En este momento, desde luego que no.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2029
translate Spanish day9nsfwscene_b2bf9c1f:

    # "{i}At this point he can't even answer. His mouth is agape, with sweet moans spilling from his throat, his hair is a mess, and his cheeks are a deep red.{/i}"
    "{i}A estas alturas ni siquiera puede responder. Tiene la boca abierta, con dulces gemidos escapando de su garganta; el cabello está revuelto y las mejillas de un rojo intenso.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2030
translate Spanish day9nsfwscene_8ff6816f:

    # "{i}All he can do is grip the sheets, his knuckles white, as you hold his legs in place, fucking him into the bed.{/i}"
    "{i}Lo único que puede hacer es aferrarse a las sábanas, con los nudillos blancos, mientras tú le sujetas las piernas y le follas contra la cama.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2031
translate Spanish day9nsfwscene_7f137852:

    # "{i}The pace quickens and quickens. You're both getting lost in the sensations - your souls, your bodies, the heat, the friction.{/i}"
    "{i}El ritmo se acelera cada vez más. Ambos se pierden en las sensaciones: sus almas, sus cuerpos, el calor, la fricción.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2032
translate Spanish day9nsfwscene_fb7cb3d0:

    # GRC "Haaa... ah... Sunshine, please, I'm going to-"
    GRC "Jaaa... ah... Solecito, por favor, me voy a-"

# game/NSFW Patch/nsfwpatch.rpy:2033
translate Spanish day9nsfwscene_2ce30da6:

    # "{i}Every thrust sends shivers up your spine. The pleasure pools, like a coil winding tighter and tighter, and your thighs tremble as you feel the orgasm approaching.{/i}"
    "{i}Cada embestida te envía escalofríos por la espalda. El placer se acumula, como un resorte que se tensa cada vez más, y tus muslos tiemblan al sentir acercarse el orgasmo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2034
translate Spanish day9nsfwscene_83c61764:

    # "{i}You can tell he's close, too. He's moaning, his back arching, his hips meeting your thrusts.{/i}"
    "{i}Puedes notar que él también está cerca. Gime, arquea la espalda y sus caderas se encuentran con tus embestidas.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2035
translate Spanish day9nsfwscene_cd7f3da4:

    # GRC "Ha.... ah.. S... Sun... shine!"
    GRC "Ah.... ah.. S... Sole... cito!"

# game/NSFW Patch/nsfwpatch.rpy:2039
translate Spanish day9nsfwscene_e178a3eb:

    # "{i}His eyes shut tight and his body jerks. His dick twitches and throbs, then he's finishing, painting his stomach with his own cum.{/i}"
    "{i}Cierra los ojos con fuerza y su cuerpo se estremece. Su pene late y se contrae, y entonces se corre, pintando su estómago con su propio semen.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2040
translate Spanish day9nsfwscene_3f0162aa:

    # "{i}The sensation sends you over the edge. You're so close, so close, and then...{/i}"
    "{i}La sensación te empuja al límite. Estás tan cerca, tan cerca, y entonces...{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2041
translate Spanish day9nsfwscene_56da88f0:

    # "{i}It's like an explosion.{/i}"
    "{i}Es como una explosión.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2042
translate Spanish day9nsfwscene_05383165:

    # "{i}Waves of pleasure, of heat, of buzz, crash over you.{/i}"
    "{i}Oleadas de placer, de calor, de zumbido, se estrellan contra ti.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2045
translate Spanish day9nsfwscene_18ae802d:

    # "{i}You spill out inside of Casper, filling him, and his body clenches around your cock, his eyes closed and his head back, riding out his orgasm.{/i}"
    "{i}Te corres dentro de Casper, llenándolo, y su cuerpo se aprieta alrededor de tu pene; tiene los ojos cerrados y la cabeza echada hacia atrás, prolongando su orgasmo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2048
translate Spanish day9nsfwscene_208a9a74:

    # "{i}You come around your strap-on, feeling a wetness growing even further between your thighs.{/i}"
    "{i}Te corres alrededor del arnés, sintiendo cómo la humedad aumenta aún más entre tus muslos.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2049
translate Spanish day9nsfwscene_8a4d1c0d:

    # "{i}You keep moving, riding out both of your orgasms in ecstacy.{/i}"
    "{i}Sigues moviéndote, prolongando ambos orgasmos en éxtasis.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2052
translate Spanish day9nsfwscene_d79a1876:

    # "{i}You collapse on top of Casper, panting, sweating, your mind blown.{/i}"
    "{i}Te desplomas encima de Casper, jadeando, sudando, con la mente en blanco.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2053
translate Spanish day9nsfwscene_06ccf409:

    # "{i}You can still feel the buzzing - the energy that seems to radiate from you both, your souls connecting.{/i}"
    "{i}Aún sientes el zumbido: la energía que parece irradiar de ambos, sus almas conectándose.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2054
translate Spanish day9nsfwscene_a81ecb54:

    # "{i}Your head is in the crook of his neck, and his arms wrap around you, holding you close.{/i}"
    "{i}Tu cabeza está en el hueco de su cuello y sus brazos te envuelven, apretándote contra él.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2065
translate Spanish day9nsfwscene_185ec9d9:

    # GRC "That was... was..."
    GRC "Eso fue... fue..."

# game/NSFW Patch/nsfwpatch.rpy:2070
translate Spanish day9nsfwscene_b367effa:

    # GRC "Words fail me."
    GRC "Las palabras me fallan."

# game/NSFW Patch/nsfwpatch.rpy:2074
translate Spanish day9nsfwscene_e1aef0ef:

    # GRC "Consider me blown, then."
    GRC "Considérame alucinado, entonces."

# game/NSFW Patch/nsfwpatch.rpy:2079
translate Spanish day9nsfwscene_403d8e74:

    # GRC "............"
    GRC "............"

# game/NSFW Patch/nsfwpatch.rpy:2080
translate Spanish day9nsfwscene_94236cd1:

    # GRC "We... should clean up."
    GRC "Deberíamos... limpiarnos."

# game/NSFW Patch/nsfwpatch.rpy:2085
translate Spanish day9nsfwscene_008afe10_6:

    # GRC "..."
    GRC "..."

# game/NSFW Patch/nsfwpatch.rpy:2086
translate Spanish day9nsfwscene_104b3aff:

    # GRC "As long as you want, Solecito."
    GRC "Todo el tiempo que quieras, Solecito."

# game/NSFW Patch/nsfwpatch.rpy:2102
translate Spanish day9aftersmut_e90377d8:

    # "{i}It's some time later when you rest in Casper's bed. He lays on his back, you lay on his chest.{/i}"
    "{i}Ha pasado un rato y descansan en la cama de Casper. Él está boca arriba y tú apoyad[letra] en su pecho.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2103
translate Spanish day9aftersmut_3f47a6d2:

    # "{i}He has an arm around you, gently tracing shapes into your skin with his fingertip.{/i}"
    "{i}Tiene un brazo a tu alrededor, trazando formas suaves en tu piel con la yema del dedo.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2108
translate Spanish day9aftersmut_a251eeb4:

    # "{i}You listen to his heart beat, slow and steady, and his breathing, soft and calm.{/i}"
    "{i}Escuchas los latidos de su corazón, lentos y constantes, y su respiración, suave y calmada.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2109
translate Spanish day9aftersmut_17bc3805:

    # "{i}Sleep threatens to overtake you, and yet you fight against it.{/i}"
    "{i}El sueño amenaza con vencerte, y aun así luchas contra él.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2117
translate Spanish day9aftersmut_f164ba37:

    # GRC "You should sleep, you know."
    GRC "Deberías dormir, ¿sabes?"

# game/NSFW Patch/nsfwpatch.rpy:2122
translate Spanish day9aftersmut_46e6d107:

    # GRC "Have you finally decided that I'm a terrifying Grim Reaper?"
    GRC "¿Has decidido por fin que soy una Parca aterradora?"

# game/NSFW Patch/nsfwpatch.rpy:2128
translate Spanish day9aftersmut_d5de1da1:

    # GRC "What are you scared of?"
    GRC "¿De qué tienes miedo?"

# game/NSFW Patch/nsfwpatch.rpy:2132
translate Spanish day9aftersmut_37038866:

    # GRC "Don't be scared."
    GRC "No tengas miedo."

# game/NSFW Patch/nsfwpatch.rpy:2133
translate Spanish day9aftersmut_be636f28:

    # GRC "...Is what I would like to say, but that would be stupid of me, for I feel the same fear."
    GRC "...Es lo que me gustaría decir, pero sería estúpido por mi parte, porque siento el mismo miedo."

# game/NSFW Patch/nsfwpatch.rpy:2134
translate Spanish day9aftersmut_2f84b4d8:

    # GRC "We'll work it out, Sunshine. We have to."
    GRC "Lo resolveremos, Solecito. Tenemos que hacerlo."

# game/NSFW Patch/nsfwpatch.rpy:2135
translate Spanish day9aftersmut_8c27c65f:

    # GRC "Fate could not be so cruel."
    GRC "El destino no puede ser tan cruel."

# game/NSFW Patch/nsfwpatch.rpy:2140
translate Spanish day9aftersmut_c4fa8c16:

    # GRC "If it is, then I'll have to fight fate for a future with you."
    GRC "Si lo es, entonces tendré que luchar contra el destino por un futuro contigo."

# game/NSFW Patch/nsfwpatch.rpy:2142
translate Spanish day9aftersmut_7c872991:

    # GRC "Get some sleep. I won't go anywhere just yet."
    GRC "Duerme un poco. No me iré a ninguna parte todavía."

# game/NSFW Patch/nsfwpatch.rpy:2150
translate Spanish day9aftersmut_ec939d9d:

    # GRC "I... love you too. Dearly."
    GRC "Yo... también te amo. Profundamente."

# game/NSFW Patch/nsfwpatch.rpy:2154
translate Spanish day9aftersmut_2fa317ae:

    # GRC "I will try my best."
    GRC "Haré todo lo posible."

# game/NSFW Patch/nsfwpatch.rpy:2155
translate Spanish day9aftersmut_d8bf87cd:

    # "{i}He kisses you on the forehead, so very gently.{/i}"
    "{i}Te besa en la frente, con mucha suavidad.{/i}"

# game/NSFW Patch/nsfwpatch.rpy:2156
translate Spanish day9aftersmut_18707930:

    # "{i}Your eyes grow heavier and heavier, and finally, sleep overtakes you.{/i}"
    "{i}Tus ojos se vuelven cada vez más pesados y, por fin, el sueño te vence.{/i}"

translate Spanish strings:

    # game/NSFW Patch/nsfwpatch.rpy:395
    old "1. <Penis.>"
    new "1. <Pene.>"

    # game/NSFW Patch/nsfwpatch.rpy:400
    old "1. <Insert into Casper.>"
    new "1. <Penetrar a Casper.>"

    # game/NSFW Patch/nsfwpatch.rpy:403
    old "2. <Be inserted into.>"
    new "2. <Ser penetrad[letra].>"

    # game/NSFW Patch/nsfwpatch.rpy:406
    old "2. <Vagina.>"
    new "2. <Vagina.>"

    # game/NSFW Patch/nsfwpatch.rpy:411
    old "1. <Insert into Casper (strap-on).>"
    new "1. <Penetrar a Casper (arnés).>"

    # game/NSFW Patch/nsfwpatch.rpy:439
    old "1. <Gotcha.>"
    new "1. <Te atrapé.>"

    # game/NSFW Patch/nsfwpatch.rpy:444
    old "1. <I've wanted to do that for ages.>"
    new "1. <Llevaba siglos queriendo hacer eso.>"

    # game/NSFW Patch/nsfwpatch.rpy:446
    old "2. <Sorry, the want to do that was overwhelming all night.>"
    new "2. <Perdona, el deseo de hacerlo me ha estado abrumando toda la noche.>"

    # game/NSFW Patch/nsfwpatch.rpy:455
    old "1. <Come over here.>"
    new "1. <Ven aquí.>"

    # game/NSFW Patch/nsfwpatch.rpy:458
    old "1. <{i} Pull Casper towards the bed.{/i}>"
    new "1. <{i}Tirar de Casper hacia la cama.{/i}>"

    # game/NSFW Patch/nsfwpatch.rpy:477
    old "1. <You're beautiful.>"
    new "1. <Eres hermoso.>"

    # game/NSFW Patch/nsfwpatch.rpy:481
    old "1. <You've changed, you know.>"
    new "1. <Has cambiado, ¿sabes?>"

    # game/NSFW Patch/nsfwpatch.rpy:484
    old "1. <A week ago you would've started arguing with me.>"
    new "1. <Hace una semana habrías empezado a discutir conmigo.>"

    # game/NSFW Patch/nsfwpatch.rpy:487
    old "1. <Also, probably called me ugly.>"
    new "1. <Y probablemente me habrías llamado fe[letra].>"

    # game/NSFW Patch/nsfwpatch.rpy:495
    old "2. <Casper, I really love you.>"
    new "2. <Casper, te amo de verdad.>"

    # game/NSFW Patch/nsfwpatch.rpy:514
    old "1. <I thought you were throwing your worries to the wind?>"
    new "1. <Creía que habías decidido dejar las preocupaciones a un lado.>"

    # game/NSFW Patch/nsfwpatch.rpy:522
    old "1. <You don't need to worry about me.>"
    new "1. <No tienes que preocuparte por mí.>"

    # game/NSFW Patch/nsfwpatch.rpy:524
    old "2. <Thank you for caring, Casper.>"
    new "2. <Gracias por preocuparte, Casper.>"

    # game/NSFW Patch/nsfwpatch.rpy:536
    old "1. <Casper.>"
    new "1. <Casper.>"

    # game/NSFW Patch/nsfwpatch.rpy:541
    old "1. <Can I touch you?>"
    new "1. <¿Puedo tocarte?>"

    # game/NSFW Patch/nsfwpatch.rpy:551
    old "1. <{i}Trace his features with your hand.{/i}>"
    new "1. <{i}Trazar sus rasgos con la mano.{/i}>"

    # game/NSFW Patch/nsfwpatch.rpy:566
    old "1. <What look is that?>"
    new "1. <¿Qué expresión es esa?>"

    # game/NSFW Patch/nsfwpatch.rpy:571
    old "1. <I'm wondering what happens if we kiss.>"
    new "1. <Me pregunto qué pasa si nos besamos.>"

    # game/NSFW Patch/nsfwpatch.rpy:574
    old "1. <While we feel it, that is.>"
    new "1. <Mientras lo sentimos, quiero decir.>"

    # game/NSFW Patch/nsfwpatch.rpy:618
    old "1. <That's the idea.>"
    new "1. <Esa es la idea.>"

    # game/NSFW Patch/nsfwpatch.rpy:620
    old "2. <Casper, I can barely contain myself.>"
    new "2. <Casper, apenas puedo contenerme.>"

    # game/NSFW Patch/nsfwpatch.rpy:623
    old "1. <All I want to do is... touch you.>"
    new "1. <Lo único que quiero es... tocarte.>"

    # game/NSFW Patch/nsfwpatch.rpy:626
    old "1. <I want to feel your skin on mine.>"
    new "1. <Quiero sentir tu piel contra la mía.>"

    # game/NSFW Patch/nsfwpatch.rpy:629
    old "1. <I want to make you fall apart.>"
    new "1. <Quiero hacer que te deshagas.>"

    # game/NSFW Patch/nsfwpatch.rpy:631
    old "2. <I want to show you how I feel about you.>"
    new "2. <Quiero mostrarte cómo me siento por ti.>"

    # game/NSFW Patch/nsfwpatch.rpy:637
    old "1. <I'm drawn to you.>"
    new "1. <Me atraes.>"

    # game/NSFW Patch/nsfwpatch.rpy:649
    old "1. <You know, I really like your gloves.>"
    new "1. <Sabes, me gustan mucho tus guantes.>"

    # game/NSFW Patch/nsfwpatch.rpy:652
    old "1. <They're... sexy.>"
    new "1. <Son... sexys.>"

    # game/NSFW Patch/nsfwpatch.rpy:656
    old "1. <Do you like it when I touch your hands?>"
    new "1. <¿Te gusta que te toque las manos?>"

    # game/NSFW Patch/nsfwpatch.rpy:662
    old "1. <Sensitive, huh?>"
    new "1. <¿Sensibles, eh?>"

    # game/NSFW Patch/nsfwpatch.rpy:664
    old "2. <Oh, Casper....>"
    new "2. <Oh, Casper....>"

    # game/NSFW Patch/nsfwpatch.rpy:719
    old "1. <Are you enjoying this, Casper?>"
    new "1. <¿Estás disfrutando de esto, Casper?>"

    # game/NSFW Patch/nsfwpatch.rpy:724
    old "1. <Whatever do you mean?>"
    new "1. <¿A qué te refieres?>"

    # game/NSFW Patch/nsfwpatch.rpy:728
    old "1. <Ironic, really.>"
    new "1. <Irónico, la verdad.>"

    # game/NSFW Patch/nsfwpatch.rpy:730
    old "2. <Trust me, you're having the same effect on me.>"
    new "2. <Créeme, me estás haciendo el mismo efecto.>"

    # game/NSFW Patch/nsfwpatch.rpy:788
    old "1. <You really wanted me, didn't you?>"
    new "1. <Me deseabas con muchas ganas, ¿no?>"

    # game/NSFW Patch/nsfwpatch.rpy:796
    old "1. <A... ah...>"
    new "1. <A... ah...>"

    # game/NSFW Patch/nsfwpatch.rpy:802
    old "1. <I... when I touch you, it's... like I can feel it, too.>"
    new "1. <Yo... cuando te toco, es... como si también lo sintiera.>"

    # game/NSFW Patch/nsfwpatch.rpy:813
    old "1. <I...>"
    new "1. <Yo...>"

    # game/NSFW Patch/nsfwpatch.rpy:816
    old "1. <Fuck... Casper...>"
    new "1. <Maldición... Casper...>"

    # game/NSFW Patch/nsfwpatch.rpy:834
    old "1. <Yes.>"
    new "1. <Sí.>"

    # game/NSFW Patch/nsfwpatch.rpy:854
    old "1. <Ah... Casper...>"
    new "1. <Ah... Casper...>"

    # game/NSFW Patch/nsfwpatch.rpy:862
    old "1. <Casper, I... I'm going to...>"
    new "1. <Casper, yo... me voy a...>"

    # game/NSFW Patch/nsfwpatch.rpy:910
    old "1. <I don't think I have, either.>"
    new "1. <Creo que yo tampoco.>"

    # game/NSFW Patch/nsfwpatch.rpy:920
    old "1. <Ah, so you're extra sweet after finishing.>"
    new "1. <Ah, así que eres especialmente dulce después de correrte.>"

    # game/NSFW Patch/nsfwpatch.rpy:922
    old "2. <Sounds to me like someone's trying to get into my pants.>"
    new "2. <Me suena a que alguien intenta meterse en mis pantalones.>"

    # game/NSFW Patch/nsfwpatch.rpy:927
    old "1. <A charming man who just came in my hand.>"
    new "1. <Un hombre encantador que acaba de correrse en mi mano.>"

    # game/NSFW Patch/nsfwpatch.rpy:933
    old "1. <I'm exhausted...>"
    new "1. <Estoy agotad[letra]...>"

    # game/NSFW Patch/nsfwpatch.rpy:935
    old "2. <Sleepy...>"
    new "2. <Con sueño...>"

    # game/NSFW Patch/nsfwpatch.rpy:941
    old "1. <But we're still a mess...>"
    new "1. <Pero aún estamos hechos un desastre...>"

    # game/NSFW Patch/nsfwpatch.rpy:985
    old "1. <I'm scared... scared something will happen to you, and this will be the last time I see you.>"
    new "1. <Tengo miedo... miedo de que te pase algo y esta sea la última vez que te vea.>"

    # game/NSFW Patch/nsfwpatch.rpy:990
    old "1. <So, please stay.>"
    new "1. <Así que, por favor, quédate.>"

    # game/NSFW Patch/nsfwpatch.rpy:993
    old "1. <There's still so much I want to do with you.>"
    new "1. <Todavía hay tantas cosas que quiero hacer contigo.>"

    # game/NSFW Patch/nsfwpatch.rpy:998
    old "1. <Let me hold you. Just for a little while. (Skips NSFW scene)> "
    new "1. <Déjame abrazarte. Solo un ratito. (Omite la escena NSFW)> "

    # game/NSFW Patch/nsfwpatch.rpy:1002
    old "2. <Why don't you hurry up and kiss me, and we can work out the rest together? (Begins NSFW scene)>"
    new "2. <¿Por qué no te das prisa y me besas, y resolvemos el resto juntos? (Inicia la escena NSFW)>"

    # game/NSFW Patch/nsfwpatch.rpy:1032
    old "1. <Because... because I'm not allowed here?>"
    new "1. <¿Porque... porque no se me permite estar aquí?>"

    # game/NSFW Patch/nsfwpatch.rpy:1042
    old "1. <Casper...>"
    new "1. <Casper...>"

    # game/NSFW Patch/nsfwpatch.rpy:1058
    old "1. <I take it you like that, Casper?>"
    new "1. <Supongo que te gusta eso, Casper.>"

    # game/NSFW Patch/nsfwpatch.rpy:1071
    old "1. <What do you mean, 'don't tease me'?>"
    new "1. <¿Qué quieres decir con «no me provoques»?>"

    # game/NSFW Patch/nsfwpatch.rpy:1074
    old "1. <Isn't that our whole thing?>"
    new "1. <¿No es eso lo nuestro?>"

    # game/NSFW Patch/nsfwpatch.rpy:1080
    old "1. <I think I can tell.>"
    new "1. <Creo que me doy cuenta.>"

    # game/NSFW Patch/nsfwpatch.rpy:1095
    old "1. <I want you.>"
    new "1. <Te deseo.>"

    # game/NSFW Patch/nsfwpatch.rpy:1097
    old "2. <Casper, I want to feel you inside of me.>"
    new "2. <Casper, quiero sentirte dentro de mí.>"

    # game/NSFW Patch/nsfwpatch.rpy:1107
    old "1. <Of course I'm sure.>"
    new "1. <Por supuesto que estoy segur[letra].>"

    # game/NSFW Patch/nsfwpatch.rpy:1109
    old "2. <As sure as I've ever been about anything.>"
    new "2. <Tan segur[letra] como lo he estado nunca de nada.>"

    # game/NSFW Patch/nsfwpatch.rpy:1112
    old "1. <I've never wanted anyone as much as I want you right now.>"
    new "1. <Nunca he deseado a nadie tanto como te deseo ahora.>"

    # game/NSFW Patch/nsfwpatch.rpy:1153
    old "1. <.....>"
    new "1. <.....>"

    # game/NSFW Patch/nsfwpatch.rpy:1158
    old "1. <I'm just admiring the sight.>"
    new "1. <Solo estoy admirando la vista.>"

    # game/NSFW Patch/nsfwpatch.rpy:1161
    old "1. <And thinking of what you're going to do to me.>"
    new "1. <Y pensando en lo que me vas a hacer.>"

    # game/NSFW Patch/nsfwpatch.rpy:1165
    old "2. <God damn, I need that inside of me.>"
    new "2. <Maldición, necesito eso dentro de mí.>"

    # game/NSFW Patch/nsfwpatch.rpy:1169
    old "1. <I'm just being honest.>"
    new "1. <Solo estoy siendo sincer[letra].>"

    # game/NSFW Patch/nsfwpatch.rpy:1172
    old "1. <Don't you like it when I'm telling the truth?>"
    new "1. <¿No te gusta cuando digo la verdad?>"

    # game/NSFW Patch/nsfwpatch.rpy:1178
    old "3. <Ha... Casper...>"
    new "3. <Ah... Casper...>"

    # game/NSFW Patch/nsfwpatch.rpy:1312
    old "1. <Casper... Casper, please....>"
    new "1. <Casper... Casper, por favor....>"

    # game/NSFW Patch/nsfwpatch.rpy:1315
    old "1. <Put it... put it in...>"
    new "1. <Métela... métela...>"

    # game/NSFW Patch/nsfwpatch.rpy:1317
    old "2. <I need you...>"
    new "2. <Te necesito...>"

    # game/NSFW Patch/nsfwpatch.rpy:1327
    old "1. <Did... did you buy that just for me?>"
    new "1. <¿La... la compraste solo por mí?>"

    # game/NSFW Patch/nsfwpatch.rpy:1361
    old "1. <You diiiid.>"
    new "1. <Sííí que lo hiciste.>"

    # game/NSFW Patch/nsfwpatch.rpy:1364
    old "1. <You got this because you wanted to do me so badly, huh?>"
    new "1. <La compraste porque me deseabas tanto, ¿eh?>"

    # game/NSFW Patch/nsfwpatch.rpy:1489
    old "1. <Ahh.... ah...>"
    new "1. <Ahh.... ah...>"

    # game/NSFW Patch/nsfwpatch.rpy:1491
    old "2. <God, it feels so good...>"
    new "2. <Dios, se siente tan bien...>"

    # game/NSFW Patch/nsfwpatch.rpy:1495
    old "1. <Keep going. Please.>"
    new "1. <Sigue. Por favor.>"

    # game/NSFW Patch/nsfwpatch.rpy:1497
    old "2. <Don't stop there.>"
    new "2. <No te quedes ahí.>"

    # game/NSFW Patch/nsfwpatch.rpy:1499
    old "3. <Deeper, Casper...>"
    new "3. <Más profundo, Casper...>"

    # game/NSFW Patch/nsfwpatch.rpy:1505
    old "1. <Nnnnggh...>"
    new "1. <Nnnnggh...>"

    # game/NSFW Patch/nsfwpatch.rpy:1507
    old "2. <Ah.. ha...>"
    new "2. <Ah.. ah...>"

    # game/NSFW Patch/nsfwpatch.rpy:1531
    old "1. <Casper, Casper...>"
    new "1. <Casper, Casper...>"

    # game/NSFW Patch/nsfwpatch.rpy:1533
    old "2. <C... Casper...>"
    new "2. <C... Casper...>"

    # game/NSFW Patch/nsfwpatch.rpy:1624
    old "1. <It's like we were made for each other.>"
    new "1. <Es como si estuviéramos hechos el uno para el otro.>"

    # game/NSFW Patch/nsfwpatch.rpy:1636
    old "1. <...Not yet.>"
    new "1. <...Aún no.>"

    # game/NSFW Patch/nsfwpatch.rpy:1638
    old "1. <Stay inside me for a bit longer, please.>"
    new "1. <Quédate dentro de mí un poco más, por favor.>"

    # game/NSFW Patch/nsfwpatch.rpy:1645
    old "2. <You clean me up, I'll clean you up.>"
    new "2. <Tú me limpias a mí, yo te limpio a ti.>"

    # game/NSFW Patch/nsfwpatch.rpy:1651
    old "1. <You're insatiable.>"
    new "1. <Eres insaciable.>"

    # game/NSFW Patch/nsfwpatch.rpy:1662
    old "2. <I need to be inside of you. Please.>"
    new "2. <Necesito estar dentro de ti. Por favor.>"

    # game/NSFW Patch/nsfwpatch.rpy:1669
    old "1. <Absolutely.>"
    new "1. <Absolutamente.>"

    # game/NSFW Patch/nsfwpatch.rpy:1671
    old "2. <I've never been more certain of anything.>"
    new "2. <Nunca he estado más segur[letra] de nada.>"

    # game/NSFW Patch/nsfwpatch.rpy:1695
    old "1. <That goes both ways.>"
    new "1. <Eso es mutuo.>"

    # game/NSFW Patch/nsfwpatch.rpy:1697
    old "2. <I think I can imagine just fine.>"
    new "2. <Creo que puedo imaginarlo perfectamente.>"

    # game/NSFW Patch/nsfwpatch.rpy:1700
    old "1. <Can I undress you?>"
    new "1. <¿Puedo desnudarte?>"

    # game/NSFW Patch/nsfwpatch.rpy:1710
    old "1. <Now, be a good boy and wait a little longer, okay?>"
    new "1. <Ahora sé un buen chico y espera un poco más, ¿okey?>"

    # game/NSFW Patch/nsfwpatch.rpy:1731
    old "1. <Are you enjoying the view, Casper?>"
    new "1. <¿Estás disfrutando de la vista, Casper?>"

    # game/NSFW Patch/nsfwpatch.rpy:1737
    old "1. <I brought something just for this, you know.>"
    new "1. <Traje algo precisamente para esto, ¿sabes?>"

    # game/NSFW Patch/nsfwpatch.rpy:1744
    old "1. <Strap-on.>"
    new "1. <Arnés.>"

    # game/NSFW Patch/nsfwpatch.rpy:1747
    old "1. <I'm not gonna lie Casper, I want to absolutely wreck you.>"
    new "1. <No te voy a mentir, Casper: quiero destrozarte por completo.>"

    # game/NSFW Patch/nsfwpatch.rpy:1749
    old "2. <I want to bury it inside of you.>"
    new "2. <Quiero enterrarlo dentro de ti.>"

    # game/NSFW Patch/nsfwpatch.rpy:1751
    old "3. <It'll feel good. I promise.>"
    new "3. <Se sentirá bien. Te lo prometo.>"

    # game/NSFW Patch/nsfwpatch.rpy:1754
    old "1. <Can I use it on you?>"
    new "1. <¿Puedo usarlo contigo?>"

    # game/NSFW Patch/nsfwpatch.rpy:1758
    old "1. <Good boy.>"
    new "1. <Buen chico.>"

    # game/NSFW Patch/nsfwpatch.rpy:1765
    old "1. <Good to know.>"
    new "1. <Bueno saberlo.>"

    # game/NSFW Patch/nsfwpatch.rpy:1767
    old "2. <I'll keep that in mind.>"
    new "2. <Lo tendré en cuenta.>"

    # game/NSFW Patch/nsfwpatch.rpy:1851
    old "1. <Does it feel good?>"
    new "1. <¿Se siente bien?>"

    # game/NSFW Patch/nsfwpatch.rpy:1863
    old "1. <I could say the same thing to you.>"
    new "1. <Podría decirte lo mismo.>"

    # game/NSFW Patch/nsfwpatch.rpy:1865
    old "2. <Then let's destroy each other already.>"
    new "2. <Entonces vamos a destrozarnos ya.>"

    # game/NSFW Patch/nsfwpatch.rpy:1906
    old "1. <Does that hurt?>"
    new "1. <¿Duele?>"

    # game/NSFW Patch/nsfwpatch.rpy:1911
    old "1. <Good?>"
    new "1. <¿Bien?>"

    # game/NSFW Patch/nsfwpatch.rpy:1920
    old "1. <Do you want me?>"
    new "1. <¿Me deseas?>"

    # game/NSFW Patch/nsfwpatch.rpy:1924
    old "1. <No, but I do enjoy it.>"
    new "1. <No, pero sí lo disfruto.>"

    # game/NSFW Patch/nsfwpatch.rpy:1999
    old "1. <Amazing...>"
    new "1. <Increíble...>"

    # game/NSFW Patch/nsfwpatch.rpy:2020
    old "1. <Casper, you're...>"
    new "1. <Casper, eres...>"

    # game/NSFW Patch/nsfwpatch.rpy:2023
    old "1. <Beautiful.>"
    new "1. <Hermoso.>"

    # game/NSFW Patch/nsfwpatch.rpy:2025
    old "2. <Incredible.>"
    new "2. <Increíble.>"

    # game/NSFW Patch/nsfwpatch.rpy:2027
    old "3. <Perfect.>"
    new "3. <Perfecto.>"

    # game/NSFW Patch/nsfwpatch.rpy:2067
    old "1. <Amazing?>"
    new "1. <¿Increíble?>"

    # game/NSFW Patch/nsfwpatch.rpy:2072
    old "1. <I told you I'd blow your mind.>"
    new "1. <Te dije que te iba a dejar alucinado.>"

    # game/NSFW Patch/nsfwpatch.rpy:2076
    old "1. <Maybe next time, if you're a good boy.>"
    new "1. <Quizá la próxima vez, si eres un buen chico.>"

    # game/NSFW Patch/nsfwpatch.rpy:2082
    old "1. <Can we stay like this a bit longer?>"
    new "1. <¿Podemos quedarnos así un poco más?>"

    # game/NSFW Patch/nsfwpatch.rpy:2119
    old "1. <I'm scared.>"
    new "1. <Tengo miedo.>"

    # game/NSFW Patch/nsfwpatch.rpy:2125
    old "1. <Hah. You're funny.>"
    new "1. <Ja. Eres gracioso.>"

    # game/NSFW Patch/nsfwpatch.rpy:2130
    old "1. <This being the last time we see each other.>"
    new "1. <Que esta sea la última vez que nos vemos.>"

    # game/NSFW Patch/nsfwpatch.rpy:2137
    old "1. <And if it is?>"
    new "1. <¿Y si lo es?>"

    # game/NSFW Patch/nsfwpatch.rpy:2144
    old "1. <...Mmmkay.>"
    new "1. <...Mmmkay.>"

    # game/NSFW Patch/nsfwpatch.rpy:2147
    old "1. <I love you, Casper.>"
    new "1. <Te amo, Casper.>"

    # game/NSFW Patch/nsfwpatch.rpy:2152
    old "1. <Stay safe, okay?>"
    new "1. <Cuídate, ¿okey?>"

