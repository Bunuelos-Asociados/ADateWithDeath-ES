﻿# TODO: Translation updated at 2026-10-15 18:36

# game/lingo.rpy:220
translate Spanish lingo_example_e08fd731:

    # "Lets start with a word we choose. This time \"lingo\""
    "Empecemos con una palabra que elijamos. Esta vez, \"lingo\"."

# game/lingo.rpy:222
translate Spanish lingo_example_d6042bdc:

    # "Easy when you know the answer right?"
    "Es fácil cuando sabes la respuesta, ¿verdad?"

# game/lingo.rpy:223
translate Spanish lingo_example_23c8539e:

    # "Let's try with a random word from a list of 5757."
    "Probemos con una palabra aleatoria de una lista de 7553."

# game/lingo.rpy:229
translate Spanish lingo_example_8315f6f1:

    # "Impressive! guessed \"[word]\" in [tries] attempts."
    "¡Impresionante! Adivinaste \"[word]\" en [tries] intentos."

# game/lingo.rpy:231
translate Spanish lingo_example_c749cb6c:

    # "Guessed \"[word]\" in [tries] attempts. Not bad."
    "Adivinaste \"[word]\" en [tries] intentos. Nada mal."

# game/lingo.rpy:233
translate Spanish lingo_example_3ce155b5:

    # "Couldn't guess it? it was: \"[word]\"."
    "¿No pudiste adivinarla? Era: \"[word]\"."

# game/lingo.rpy:234
translate Spanish lingo_example_fb9a811c:

    # "Now let's enable resetting."
    "Ahora habilitemos la opción de reiniciar."

# game/lingo.rpy:237
translate Spanish lingo_example_f0641ab6:

    # "the word was \"[word]\""
    "la palabra era \"[word]\""
    
translate Spanish strings:
    

    old "Rules"
    new "Reglas"

    old "You have five turns to guess the five letter word."
    new "Tienes cinco intentos para adivinar la palabra de cinco letras."

    old "A correct letter turns green, a correct letter in the wrong place"
    new "Una letra correcta se vuelve verde; si está en el lugar equivocado,"

    old "turns yellow, and an incorrect letter turns gray."
    new "se vuelve amarilla; si es incorrecta, se vuelve gris."

    old "The word was: [lingo_word]."
    new "La palabra era: [lingo_word]."

    old "Lets start with a word we choose. This time \"lingo\""
    new "Empecemos con una palabra que elijamos. Esta vez, \"lingo\"."

    old "Easy when you know the answer right?"
    new "Es fácil cuando sabes la respuesta, ¿verdad?"

    old "Let's try with a random word from a list of 5757."
    new "Probemos con una palabra aleatoria de una lista de 7553."

    old "Impressive! guessed \"[word]\" in [tries] attempts."
    new "¡Impresionante! Adivinaste  \"[word]\" en [tries] intentos."

    old "Guessed \"[word]\" in [tries] attempts. Not bad."
    new "Adivinaste \"[word]\" en [tries] intentos. Nada mal."

    old "Couldn't guess it? it was: \"[word]\"."
    new "¿No pudiste adivinarla? Era: \"[word]\"."

    old "Now let's enable resetting."
    new "Ahora habilitemos la opción de reiniciar."

    old "the word was \"[word]\""
    new "La palabra era \"[word]\"."