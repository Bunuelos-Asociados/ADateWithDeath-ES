# TODO: Translation updated at 2026-10-15 18:36

translate Spanish strings:

    # game/pong.rpy:218
    old "Click to Begin"
    new "Haz clic para comenzar"

    # game/pong.rpy:232
    old "You lose!"
    new "¡Perdiste!"

    # game/pong.rpy:234
    old "You win!"
    new "¡Ganaste!"

    # game/pong.rpy:238
    old "Play Again"
    new "Jugar de nuevo"

