# TODO: Translation updated at 2026-10-15 18:36

translate Spanish strings:

    # game/pronoun selection.rpy:15
    old "Him"
    new "Él"

    # game/pronoun selection.rpy:22
    old "they"
    new "elle"

    # game/pronoun selection.rpy:23
    old "them"
    new "elle"

    # game/pronoun selection.rpy:24
    old "They"
    new "Elle"

    # game/pronoun selection.rpy:25
    old "Them"
    new "Elle"

    # game/pronoun selection.rpy:27
    old "their"
    new "su"

    # game/pronoun selection.rpy:28
    old "Their"
    new "Su"

    # game/pronoun selection.rpy:42
    old "Girl"
    new "Chica"

    # game/pronoun selection.rpy:43
    old "women"
    new "mujeres"

    # game/pronoun selection.rpy:44
    old "woman"
    new "mujer"

    # game/pronoun selection.rpy:45
    old "wife"
    new "esposa"

    # game/pronoun selection.rpy:48
    old "male"
    new "hombre"

    # game/pronoun selection.rpy:49
    old "guy"
    new "chico"

    # game/pronoun selection.rpy:50
    old "Guy"
    new "Chico"

    # game/pronoun selection.rpy:51
    old "men"
    new "hombres"

    # game/pronoun selection.rpy:52
    old "man"
    new "hombre"

    # game/pronoun selection.rpy:53
    old "husband"
    new "esposo"

    # game/pronoun selection.rpy:56
    old "nb"
    new "nb"

    # game/pronoun selection.rpy:57
    old "person"
    new "persona"

    # game/pronoun selection.rpy:58
    old "Person"
    new "Persona"

    # game/pronoun selection.rpy:60
    old "people"
    new "personas"

    # game/pronoun selection.rpy:61
    old "partner"
    new "pareja"

    # game/pronoun selection.rpy:64
    old "pretty"
    new "linda"

    # game/pronoun selection.rpy:65
    old "beautiful"
    new "hermosa"

    # game/pronoun selection.rpy:68
    old "cute"
    new "lindo"

    # game/pronoun selection.rpy:69
    old "handsome"
    new "guapo"

    # game/pronoun selection.rpy:72
    old "captivating"
    new "cautivante"

    # game/pronoun selection.rpy:73
    old "divine"
    new "sublime"

    # game/pronoun selection.rpy:164
    old "Custom Pronouns"
    new "Pronombres Personalizados"

    # game/pronoun selection.rpy:209
    old "Custom Descriptive Words"
    new "Palabras descriptivas personalizadas"

    # game/pronoun selection.rpy:226
    old "Pretty/Cute"
    new "Linda/Lindo"

    # game/pronoun selection.rpy:227
    old "Beautiful/Handsome"
    new "Hermosa/Guapo"

