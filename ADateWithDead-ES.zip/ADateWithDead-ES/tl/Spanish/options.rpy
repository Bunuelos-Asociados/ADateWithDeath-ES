﻿# TODO: Translation updated at 2026-10-15 18:36

translate Spanish strings:

    # game/options.rpy:22
    old "A Date with Death"
    new "A Date with Death"

