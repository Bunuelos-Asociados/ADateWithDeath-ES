# TODO: Translation updated at 2026-10-15 18:36

translate Spanish strings:

    # game/call_messages.rpy:14
    old "What is this?"
    new "¿Qué es esto?"

    # game/call_messages.rpy:15
    old "Good!!!!"
    new "¡¡¡Bien!!!"

    # game/call_messages.rpy:16
    old "Huh???"
    new "¿¿¿Eh???"

    # game/call_messages.rpy:17
    old "Someone likes bets, huh?"
    new "¿Te gustan las apuestas, eh?"

    # game/call_messages.rpy:18
    old "We'll see about that :)"
    new "Ya veremos :)"

    # game/call_messages.rpy:19
    old "Aw, but this is so fun."
    new "Aw, pero esto es tan divertido."

    # game/call_messages.rpy:30
    old "it's... cute."
    new "es... lindo."

    # game/call_messages.rpy:31
    old "I'm pretty fond of being alive."
    new "Me gusta bastante seguir con vida."

    # game/call_messages.rpy:32
    old "OK STEVE."
    new "OK, STEVE."

    # game/call_messages.rpy:33
    old "You are literally not doing that."
    new "Literalmente no estás haciendo eso."

    # game/call_messages.rpy:34
    old "Always room for improvement."
    new "Siempre hay espacio para mejorar."

    # game/call_messages.rpy:35
    old "omg it's so cute???"
    new "¿¿¿omg es tan lindo???"

    # game/call_messages.rpy:46
    old "Er... well, yes."
    new "Eh... bueno, sí."

    # game/call_messages.rpy:47
    old "You're making me worry more!"
    new "¡Me estás preocupando más!"

    # game/call_messages.rpy:48
    old "Nothing new there..."
    new "Nada nuevo ahí..."

    # game/call_messages.rpy:49
    old "I bet you are..."
    new "Apuesto a que sí..."

    # game/call_messages.rpy:50
    old "Steve, at it again..."
    new "Steve, otra vez con lo mismo..."

    # game/call_messages.rpy:51
    old "Get some rest, please."
    new "Descansa un poco, por favor."

    # game/call_messages.rpy:64
    old "I want to see you pout."
    new "Quiero verte hacer pucheros."

    # game/call_messages.rpy:65
    old "You can't stop me."
    new "No puedes detenerme."

    # game/call_messages.rpy:66
    old "That's... sad, actually."
    new "Eso... es triste, en realidad."

    # game/call_messages.rpy:67
    old "TEEHEE????"
    new "¿¿¿¿JEJEJE????"

    # game/call_messages.rpy:68
    old "Then it's working ;)"
    new "Entonces está funcionando ;)"

    # game/call_messages.rpy:69
    old "I... did too."
    new "Yo... también lo hice."

    # game/call_messages.rpy:80
    old "Someone's struuuuggling~"
    new "Alguien está luchandooo~"

    # game/call_messages.rpy:81
    old "It's very wrinkly, though."
    new "Aunque está muy arrugado."

    # game/call_messages.rpy:95
    old "How???"
    new "¿¿¿Cómo???"

    # game/call_messages.rpy:96
    old "Oh, tell me more :0"
    new "Oh, cuéntame más :0"

    # game/call_messages.rpy:97
    old "You think I'm special :D"
    new "Piensas que soy especial :D"

    # game/call_messages.rpy:98
    old "I don't doooo that."
    new "Yo no hagoooo eso."

    # game/call_messages.rpy:99
    old "Mighty suspicious, Casper."
    new "Muy sospechoso, Casper."

    # game/call_messages.rpy:100
    old "I want to perceive you."
    new "Quiero percibirte."

    # game/call_messages.rpy:104
    old "A cute little Casper puddle :D"
    new "Un lindo Casper derretido :D"

    # game/call_messages.rpy:105
    old "Maybe if you say please ;)"
    new "Tal vez si dices por favor ;)"

    # game/call_messages.rpy:106
    old "Shut up pipsqueak."
    new "Cállate, chiquitín."

    # game/call_messages.rpy:107
    old "I didn't ask :0"
    new "No pregunté :0"

    # game/call_messages.rpy:108
    old "Are you saying it's true?"
    new "¿Estás diciendo que es verdad?"

    # game/call_messages.rpy:109
    old "How you...?"
    new "¿Cómo tú...?"

    # game/call_messages.rpy:121
    old "Awww, you dream about me?"
    new "Awww, ¿sueñas conmigo?"

    # game/call_messages.rpy:122
    old "You are pretty great <3"
    new "Eres bastante genial <3"

    # game/call_messages.rpy:123
    old "He looooves you."
    new "Te amaaaaaa."

    # game/call_messages.rpy:124
    old "Thanks for sharing it with me."
    new "Gracias por compartirlo conmigo."

    # game/call_messages.rpy:125
    old "Neverrrrr!"
    new "¡Nuncaaaa!"

    # game/call_messages.rpy:126
    old "o_o"
    new "o_o"

    # game/call_messages.rpy:138
    old "I did, actually."
    new "Sí lo hice, en realidad."

    # game/call_messages.rpy:139
    old "More like the smelliest."
    new "Más bien el más apestoso."

    # game/call_messages.rpy:140
    old "Grim + nuggets = happy"
    new "Parca + nuggets = feliz"

    # game/call_messages.rpy:141
    old "It's the brainrot, Grimmy."
    new "Es el brainrot, Parquita."

    # game/call_messages.rpy:142
    old "'Nearly' everyone ;)"
    new "'Casi' todos ;)"

    # game/call_messages.rpy:143
    old "I like you for you, Casper."
    new "Me gustas tal como eres, Casper."

    # game/call_messages.rpy:160
    old "What, why???"
    new "¿¿¿Qué, por qué???"

    # game/call_messages.rpy:161
    old "Guilty. As. Charged."
    new "Culpable. De. Todos. Los. Cargos."

    # game/call_messages.rpy:162
    old "OK, white bread boy."
    new "OK, chico soso."

    # game/call_messages.rpy:345
    old "{b}Grim Reaper:{/b} Testing. Testing. Is This Working?"
    new "{b}La Parca:{/b} Probando. Probando. ¿Esto Funciona?"

    # game/call_messages.rpy:349
    old "[playername]: [day1_flag1_response[0]!t]"
    new "[playername]: [day1_flag1_response[0]!t]"

    # game/call_messages.rpy:351
    old "{b}[playername]:{/b} [day1_flag1_response[0]!t]"
    new "{b}[playername]:{/b} [day1_flag1_response[0]!t]"

    # game/call_messages.rpy:354
    old "{b}Grim Reaper:{/b} Is It Not Obvious? You Can Type And Text At The Same Time."
    new "{b}La Parca:{/b} ¿No Es Obvio? Puedes Escribir Y Enviar Mensajes Al Mismo Tiempo."

    # game/call_messages.rpy:357
    old "{b}Grim Reaper{/b}: You Are Actually Making Me Feel A Little Guilty..."
    new "{b}La Parca{/b}: En Realidad Me Estás Haciendo Sentir Un Poco Culpable..."

    # game/call_messages.rpy:361
    old "[playername]: [day1_flag3_response[0]!t]"
    new "[playername]: [day1_flag3_response[0]!t]"

    # game/call_messages.rpy:363
    old "{b}[playername]:{/b} [day1_flag3_response[0]!t]"
    new "{b}[playername]:{/b} [day1_flag3_response[0]!t]"

    # game/call_messages.rpy:366
    old "{b}Grim Reaper{/b}: Allow Me To Go Perish. Thank You."
    new "{b}La Parca{/b}: Permíteme Ir A Perecer. Gracias."

    # game/call_messages.rpy:370
    old "[playername]: [day1_flag4_response[0]!t]"
    new "[playername]: [day1_flag4_response[0]!t]"

    # game/call_messages.rpy:372
    old "{b}[playername]:{/b} [day1_flag4_response[0]!t]"
    new "{b}[playername]:{/b} [day1_flag4_response[0]!t]"

    # game/call_messages.rpy:375
    old "{b}Grim Reaper{/b}: consider my interest piqued."
    new "{b}La Parca{/b}: considera que has despertado mi interés."

    # game/call_messages.rpy:379
    old "[playername]: [day1_flag5_response[0]!t]"
    new "[playername]: [day1_flag5_response[0]!t]"

    # game/call_messages.rpy:381
    old "{b}[playername]:{/b} [day1_flag5_response[0]!t]"
    new "{b}[playername]:{/b} [day1_flag5_response[0]!t]"

    # game/call_messages.rpy:384
    old "{b}Grim Reaper{/b}: perhaps i do, yes."
    new "{b}La Parca{/b}: quizás sí, efectivamente."

    # game/call_messages.rpy:387
    old "{b}Grim Reaper{/b}: you will regret this deal, mortal."
    new "{b}La Parca{/b}: lamentarás este trato, mortal."

    # game/call_messages.rpy:391
    old "[playername]: [day1_flag7_response[0]!t]"
    new "[playername]: [day1_flag7_response[0]!t]"

    # game/call_messages.rpy:393
    old "{b}[playername]:{/b} [day1_flag7_response[0]!t]"
    new "{b}[playername]:{/b} [day1_flag7_response[0]!t]"

    # game/call_messages.rpy:396
    old "{b}Grim Reaper{/b}: off to bed, immediately."
    new "{b}La Parca{/b}: a la cama, inmediatamente."

    # game/call_messages.rpy:400
    old "[playername]: [day1_flag8_response[0]!t]"
    new "[playername]: [day1_flag8_response[0]!t]"

    # game/call_messages.rpy:402
    old "{b}[playername]:{/b} [day1_flag8_response[0]!t]"
    new "{b}[playername]:{/b} [day1_flag8_response[0]!t]"

    # game/call_messages.rpy:406
    old "{b}Grim Reaper:{/b} i am fond of this one... {font=gui/NotoSansJP-VariableFont_wght.ttf}ヾ{/font}{font=gui/NotoSans-Light.ttf}( ˃ᴗ˂ ){/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}ツ • *{/font}{font=gui/Kelvinch-Roman.otf}✰{/font}"
    new "{b}La Parca:{/b} me gusta este... {font=gui/NotoSansJP-VariableFont_wght.ttf}ヾ{/font}{font=gui/NotoSans-Light.ttf}( ˃ᴗ˂ ){/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}ツ • *{/font}{font=gui/Kelvinch-Roman.otf}✰{/font}"

    # game/call_messages.rpy:410
    old "[playername]: [day2_flag1_response[0]!t]"
    new "[playername]: [day2_flag1_response[0]!t]"

    # game/call_messages.rpy:412
    old "{b}[playername]:{/b} [day2_flag1_response[0]!t]"
    new "{b}[playername]:{/b} [day2_flag1_response[0]!t]"

    # game/call_messages.rpy:415
    old "{b}Grim Reaper:{/b} thank you. i am well aware."
    new "{b}La Parca:{/b} gracias. lo sé muy bien."

    # game/call_messages.rpy:418
    old "{b}Grim Reaper{/b}: honestly, life is overrated."
    new "{b}La Parca{/b}: sinceramente, la vida está sobrevalorada."

    # game/call_messages.rpy:422
    old "[playername]: [day2_flag3b_response[0]!t]"
    new "[playername]: [day2_flag3b_response[0]!t]"

    # game/call_messages.rpy:424
    old "{b}[playername]:{/b} [day2_flag3b_response[0]!t]"
    new "{b}[playername]:{/b} [day2_flag3b_response[0]!t]"

    # game/call_messages.rpy:427
    old "{b}Grim Reaper{/b}: please, don't subject me to these nicknames any longer..."
    new "{b}La Parca{/b}: por favor, no me pongas más esos apodos..."

    # game/call_messages.rpy:431
    old "[playername]: [day2_flag4b_response[0]!t]"
    new "[playername]: [day2_flag4b_response[0]!t]"

    # game/call_messages.rpy:433
    old "{b}[playername]:{/b} [day2_flag4b_response[0]!t]"
    new "{b}[playername]:{/b} [day2_flag4b_response[0]!t]"

    # game/call_messages.rpy:436
    old "{b}Grim Reaper{/b}: i am stuffing my ears. lalala. i cannot hear you."
    new "{b}La Parca{/b}: me estoy tapando los oídos. lalala. no puedo escucharte."

    # game/call_messages.rpy:440
    old "[playername]: [day2_flag5b_response[0]!t]"
    new "[playername]: [day2_flag5b_response[0]!t]"

    # game/call_messages.rpy:442
    old "{b}[playername]:{/b} [day2_flag5b_response[0]!t]"
    new "{b}[playername]:{/b} [day2_flag5b_response[0]!t]"

    # game/call_messages.rpy:445
    old "{b}Grim Reaper{/b}: lalalala."
    new "{b}La Parca{/b}: lalalala."

    # game/call_messages.rpy:448
    old "{b}Grim Reaper{/b}: i... i can bathe myself perfectly enough already!"
    new "{b}La Parca{/b}: ¡ya... ya puedo bañarme perfectamente por mí mismo!"

    # game/call_messages.rpy:452
    old "[playername]: [day2_flag7b_response[0]!t]"
    new "[playername]: [day2_flag7b_response[0]!t]"

    # game/call_messages.rpy:454
    old "{b}[playername]:{/b} [day2_flag7b_response[0]!t]"
    new "{b}[playername]:{/b} [day2_flag7b_response[0]!t]"

    # game/call_messages.rpy:457
    old "{b}Grim Reaper{/b}: oh... oh no..."
    new "{b}La Parca{/b}: oh... oh no..."

    # game/call_messages.rpy:463
    old "{b}[playername]:{/b} [day2_flag8b_response[0]!t]"
    new "{b}[playername]:{/b} [day2_flag8b_response[0]!t]"

    # game/call_messages.rpy:467
    old "{b}Grim Reaper:{/b} i swear, you don't listen PURPOSEFULLY."
    new "{b}La Parca:{/b} lo juro, no escuchas a PROPÓSITO."

    # game/call_messages.rpy:471
    old "[playername]: [day3_flag1_response[0]!t]"
    new "[playername]: [day3_flag1_response[0]!t]"

    # game/call_messages.rpy:473
    old "{b}[playername]:{/b} [day3_flag1_response[0]!t]"
    new "{b}[playername]:{/b} [day3_flag1_response[0]!t]"

    # game/call_messages.rpy:476
    old "{b}Grim Reaper:{/b} you are not meant to admit to it. what am i supposed to do with you???"
    new "{b}La Parca:{/b} se supone que no debes admitirlo. ¿¿¿qué voy a hacer contigo???"

    # game/call_messages.rpy:479
    old "{b}Grim Reaper{/b}: it's... nothing personal. sorry."
    new "{b}La Parca{/b}: no es... nada personal. lo siento."

    # game/call_messages.rpy:483
    old "[playername]: [day3_flag3b_response[0]!t]"
    new "[playername]: [day3_flag3b_response[0]!t]"

    # game/call_messages.rpy:485
    old "{b}[playername]:{/b} [day3_flag3b_response[0]!t]"
    new "{b}[playername]:{/b} [day3_flag3b_response[0]!t]"

    # game/call_messages.rpy:488
    old "{b}Grim Reaper{/b}: i told you. now you look somewhat foolish, don't you?"
    new "{b}La Parca{/b}: te lo dije. ahora has quedado algo en ridículo, ¿no?"

    # game/call_messages.rpy:492
    old "[playername]: [day3_flag4b_response[0]!t]"
    new "[playername]: [day3_flag4b_response[0]!t]"

    # game/call_messages.rpy:494
    old "{b}[playername]:{/b} [day3_flag4b_response[0]!t]"
    new "{b}[playername]:{/b} [day3_flag4b_response[0]!t]"

    # game/call_messages.rpy:497
    old "{b}Grim Reaper{/b}: i'm just a little sensitive, okay???"
    new "{b}La Parca{/b}: solo soy un poco sensible, ¿¿¿okey???"

    # game/call_messages.rpy:501
    old "[playername]: [day3_flag5b_response[0]!t]"
    new "[playername]: [day3_flag5b_response[0]!t]"

    # game/call_messages.rpy:503
    old "{b}[playername]:{/b} [day3_flag5b_response[0]!t]"
    new "{b}[playername]:{/b} [day3_flag5b_response[0]!t]"

    # game/call_messages.rpy:506
    old "{b}Grim Reaper{/b}: what??? i didn't mean... i meant my eyes! my eyes!"
    new "{b}La Parca{/b}: ¿¿¿qué??? no quise decir... ¡me refería a mis ojos! ¡mis ojos!"

    # game/call_messages.rpy:509
    old "{b}Grim Reaper{/b}: there is no one better on your plane or mine than i. i am everything people should strive to be."
    new "{b}La Parca{/b}: no hay nadie mejor en tu plano o en el mío que yo. soy todo lo que la gente debería aspirar a ser."

    # game/call_messages.rpy:513
    old "[playername]: [day3_flag7b_response[0]!t]"
    new "[playername]: [day3_flag7b_response[0]!t]"

    # game/call_messages.rpy:515
    old "{b}[playername]:{/b} [day3_flag7b_response[0]!t]"
    new "{b}[playername]:{/b} [day3_flag7b_response[0]!t]"

    # game/call_messages.rpy:518
    old "{b}Grim Reaper{/b}: but... thank you. um. i appreciate it."
    new "{b}La Parca{/b}: pero... gracias. eh. lo aprecio."

    # game/call_messages.rpy:522
    old "[playername]: [day3_flag8b_response[0]!t]"
    new "[playername]: [day3_flag8b_response[0]!t]"

    # game/call_messages.rpy:524
    old "{b}[playername]:{/b} [day3_flag8b_response[0]!t]"
    new "{b}[playername]:{/b} [day3_flag8b_response[0]!t]"

    # game/call_messages.rpy:528
    old "{b}Grim Reaper:{/b} what are you talking about???"
    new "{b}La Parca:{/b} ¿¿¿de qué estás hablando???"

    # game/call_messages.rpy:532
    old "[playername]: [day4_flag1_response[0]!t]"
    new "[playername]: [day4_flag1_response[0]!t]"

    # game/call_messages.rpy:534
    old "{b}[playername]:{/b} [day4_flag1_response[0]!t]"
    new "{b}[playername]:{/b} [day4_flag1_response[0]!t]"

    # game/call_messages.rpy:537
    old "{b}Grim Reaper:{/b} WHY???"
    new "{b}La Parca:{/b} ¿¿¿POR QUÉ???"

    # game/call_messages.rpy:540
    old "{b}Grim Reaper{/b}: don't even think about using this to your advantage."
    new "{b}La Parca{/b}: ni se te ocurra usar esto a tu favor."

    # game/call_messages.rpy:544
    old "[playername]: [day4_flag3b_response[0]!t]"
    new "[playername]: [day4_flag3b_response[0]!t]"

    # game/call_messages.rpy:546
    old "{b}[playername]:{/b} [day4_flag3b_response[0]!t]"
    new "{b}[playername]:{/b} [day4_flag3b_response[0]!t]"

    # game/call_messages.rpy:549
    old "{b}Grim Reaper{/b}: you need not concern yourself over my loneliness. that is part of being a reaper."
    new "{b}La Parca{/b}: no necesitas preocuparte por mi soledad. eso es parte de ser una parca."

    # game/call_messages.rpy:553
    old "[playername]: [day4_flag4b_response[0]!t]"
    new "[playername]: [day4_flag4b_response[0]!t]"

    # game/call_messages.rpy:555
    old "{b}[playername]:{/b} [day4_flag4b_response[0]!t]"
    new "{b}[playername]:{/b} [day4_flag4b_response[0]!t]"

    # game/call_messages.rpy:558
    old "{b}Grim Reaper{/b}: whoopsies. teehee."
    new "{b}La Parca{/b}: uupsies. jejeje."

    # game/call_messages.rpy:562
    old "[playername]: [day4_flag5b_response[0]!t]"
    new "[playername]: [day4_flag5b_response[0]!t]"

    # game/call_messages.rpy:564
    old "{b}[playername]:{/b} [day4_flag5b_response[0]!t]"
    new "{b}[playername]:{/b} [day4_flag5b_response[0]!t]"

    # game/call_messages.rpy:567
    old "{b}Grim Reaper{/b}: um... yes. sorry."
    new "{b}La Parca{/b}: eh... sí. lo siento."

    # game/call_messages.rpy:570
    old "{b}Grim Reaper{/b}: you mess with my mind and my heart."
    new "{b}La Parca{/b}: juegas con mi mente y mi corazón."

    # game/call_messages.rpy:574
    old "[playername]: [day4_flag7b_response[0]!t]"
    new "[playername]: [day4_flag7b_response[0]!t]"

    # game/call_messages.rpy:576
    old "{b}[playername]:{/b} [day4_flag7b_response[0]!t]"
    new "{b}[playername]:{/b} [day4_flag7b_response[0]!t]"

    # game/call_messages.rpy:579
    old "{b}Grim Reaper{/b}: i... enjoyed talking to you."
    new "{b}La Parca{/b}: yo... disfruté hablando contigo."

    # game/call_messages.rpy:583
    old "[playername]: [day4_flag8b_response[0]!t]"
    new "[playername]: [day4_flag8b_response[0]!t]"

    # game/call_messages.rpy:585
    old "{b}[playername]:{/b} [day4_flag8b_response[0]!t]"
    new "{b}[playername]:{/b} [day4_flag8b_response[0]!t]"

    # game/call_messages.rpy:589
    old "{b}Grim Reaper:{/b} there's nothing wrong with taking my time."
    new "{b}La Parca:{/b} no hay nada de malo en tomarme mi tiempo."

    # game/call_messages.rpy:593
    old "[playername]: [day5_flag1_response[0]!t]"
    new "[playername]: [day5_flag1_response[0]!t]"

    # game/call_messages.rpy:595
    old "{b}[playername]:{/b} [day5_flag1_response[0]!t]"
    new "{b}[playername]:{/b} [day5_flag1_response[0]!t]"

    # game/call_messages.rpy:598
    old "{b}Grim Reaper:{/b} i... do not struggle...! {font=gui/NotoSans-Light.ttf}(¬ _¬){/font}"
    new "{b}La Parca:{/b} ¡yo... no me esfuerzo...! {font=gui/NotoSans-Light.ttf}(¬ _¬){/font}"

    # game/call_messages.rpy:601
    old "{b}Grim Reaper{/b}: you and your small brain."
    new "{b}La Parca{/b}: tú y tu cerebrito."

    # game/call_messages.rpy:605
    old "[playername]: [day5_flag3b_response[0]!t]"
    new "[playername]: [day5_flag3b_response[0]!t]"

    # game/call_messages.rpy:607
    old "{b}[playername]:{/b} [day5_flag3b_response[0]!t]"
    new "{b}[playername]:{/b} [day5_flag3b_response[0]!t]"

    # game/call_messages.rpy:610
    old "{b}Grim Reaper{/b}: stay right there."
    new "{b}La Parca{/b}: quédate justo ahí."

    # game/call_messages.rpy:614
    old "[playername]: [day5_flag4b_response[0]!t]"
    new "[playername]: [day5_flag4b_response[0]!t]"

    # game/call_messages.rpy:616
    old "{b}[playername]:{/b} [day5_flag4b_response[0]!t]"
    new "{b}[playername]:{/b} [day5_flag4b_response[0]!t]"

    # game/call_messages.rpy:620
    old "{b}Grim Reaper:{/b} yeah, you're definitely causing it."
    new "{b}La Parca:{/b} sí, definitivamente lo estás causando."

    # game/call_messages.rpy:624
    old "[playername]: [day6_flag1_response[0]!t]"
    new "[playername]: [day6_flag1_response[0]!t]"

    # game/call_messages.rpy:626
    old "{b}[playername]:{/b} [day6_flag1_response[0]!t]"
    new "{b}[playername]:{/b} [day6_flag1_response[0]!t]"

    # game/call_messages.rpy:629
    old "{b}Grim Reaper:{/b} maybe you're just too radiant... i knew the nickname 'sunshine' fit you..."
    new "{b}La Parca:{/b} tal vez eres demasiado radiante... sabía que el apodo 'solecito' te quedaba bien..."

    # game/call_messages.rpy:632
    old "{b}Grim Reaper{/b}: there are things i have been... wanting for strongly the last few days. it is infuriating."
    new "{b}La Parca{/b}: hay cosas que he estado... deseando intensamente los últimos días. es exasperante."

    # game/call_messages.rpy:636
    old "[playername]: [day6_flag3b_response[0]!t]"
    new "[playername]: [day6_flag3b_response[0]!t]"

    # game/call_messages.rpy:638
    old "{b}[playername]:{/b} [day6_flag3b_response[0]!t]"
    new "{b}[playername]:{/b} [day6_flag3b_response[0]!t]"

    # game/call_messages.rpy:641
    old "{b}Grim Reaper{/b}: you are... rather unforgettable. i think that fact will cause me much trouble in the future."
    new "{b}La Parca{/b}: eres... bastante inolvidable. creo que eso me causará muchos problemas en el futuro."

    # game/call_messages.rpy:645
    old "[playername]: [day6_flag4b_response[0]!t]"
    new "[playername]: [day6_flag4b_response[0]!t]"

    # game/call_messages.rpy:647
    old "{b}[playername]:{/b} [day6_flag4b_response[0]!t]"
    new "{b}[playername]:{/b} [day6_flag4b_response[0]!t]"

    # game/call_messages.rpy:650
    old "{b}Grim Reaper{/b}: the way you can jump from topic to topic is remarkable. you ought to be studied."
    new "{b}La Parca{/b}: la manera en que saltas de un tema a otro es notable. deberías ser objeto de estudio."

    # game/call_messages.rpy:654
    old "[playername]: [day6_flag5b_response[0]!t]"
    new "[playername]: [day6_flag5b_response[0]!t]"

    # game/call_messages.rpy:656
    old "{b}[playername]:{/b} [day6_flag5b_response[0]!t]"
    new "{b}[playername]:{/b} [day6_flag5b_response[0]!t]"

    # game/call_messages.rpy:659
    old "{b}Grim Reaper{/b}: oh, you really do. i doubt you and i could ever have a quiet moment."
    new "{b}La Parca{/b}: oh, realmente lo haces. dudo que tú y yo podamos tener algún momento de tranquilidad."

    # game/call_messages.rpy:662
    old "{b}Grim Reaper{/b}: i am the same as always. nothing has changed. nope. not my feelings or anything. not at all."
    new "{b}La Parca{/b}: soy el mismo de siempre. nada ha cambiado. nop. ni mis sentimientos ni nada. para nada."

    # game/call_messages.rpy:666
    old "[playername]: [day6_flag7b_response[0]!t]"
    new "[playername]: [day6_flag7b_response[0]!t]"

    # game/call_messages.rpy:668
    old "{b}[playername]:{/b} [day6_flag7b_response[0]!t]"
    new "{b}[playername]:{/b} [day6_flag7b_response[0]!t]"

    # game/call_messages.rpy:671
    old "{b}Grim Reaper{/b}: dear gods above, this is the most embarrassing thing i have ever done. do not perceive me."
    new "{b}La Parca{/b}: cielos, esto es lo más embarazoso que he hecho. no me percibas."

    # game/call_messages.rpy:675
    old "[playername]: [day6_flag8b_response[0]!t]"
    new "[playername]: [day6_flag8b_response[0]!t]"

    # game/call_messages.rpy:677
    old "{b}[playername]:{/b} [day6_flag8b_response[0]!t]"
    new "{b}[playername]:{/b} [day6_flag8b_response[0]!t]"

    # game/call_messages.rpy:681
    old "{b}Grim Reaper:{/b} i am going to melt into my chair and disappear..."
    new "{b}La Parca:{/b} voy a derretirme en mi silla y desaparecer..."

    # game/call_messages.rpy:685
    old "[playername]: [day6alt_flag1_response[0]!t]"
    new "[playername]: [day6alt_flag1_response[0]!t]"

    # game/call_messages.rpy:687
    old "{b}[playername]:{/b} [day6alt_flag1_response[0]!t]"
    new "{b}[playername]:{/b} [day6alt_flag1_response[0]!t]"

    # game/call_messages.rpy:690
    old "{b}Grim Reaper:{/b} a scary casper puddle... not cute...."
    new "{b}La Parca:{/b} un casper hecho charco, aterrador... nada lindo...."

    # game/call_messages.rpy:695
    old "{b}Grim Reaper{/b}: i cannot accept this sickness of yours. nothing should be able to touch you, except me."
    new "{b}La Parca{/b}: no puedo aceptar esta enfermedad tuya. nada debería poder tocarte, excepto yo."

    # game/call_messages.rpy:699
    old "[playername]: [day6alt_flag3b_response[0]!t]"
    new "[playername]: [day6alt_flag3b_response[0]!t]"

    # game/call_messages.rpy:701
    old "{b}[playername]:{/b} [day6alt_flag3b_response[0]!t]"
    new "{b}[playername]:{/b} [day6alt_flag3b_response[0]!t]"

    # game/call_messages.rpy:705
    old "{b}Grim Reaper{/b}: the definition of a question is: 'a sentence worded or expressed so as to elicit information'. what you said was a statement. i know this is a difficult concept."
    new "{b}La Parca{/b}: la definición de una pregunta es: 'una oración formulada para obtener información'. lo que dijiste fue una afirmación. sé que es un concepto difícil."

    # game/call_messages.rpy:709
    old "[playername]: [day6alt_flag4b_response[0]!t]"
    new "[playername]: [day6alt_flag4b_response[0]!t]"

    # game/call_messages.rpy:711
    old "{b}[playername]:{/b} [day6alt_flag4b_response[0]!t]"
    new "{b}[playername]:{/b} [day6alt_flag4b_response[0]!t]"

    # game/call_messages.rpy:715
    old "{b}Grim Reaper{/b}: yes, i've always been this handsome."
    new "{b}La Parca{/b}: sí, siempre he sido así de guapo."

    # game/call_messages.rpy:719
    old "[playername]: [day6alt_flag5b_response[0]!t]"
    new "[playername]: [day6alt_flag5b_response[0]!t]"

    # game/call_messages.rpy:721
    old "{b}[playername]:{/b} [day6alt_flag5b_response[0]!t]"
    new "{b}[playername]:{/b} [day6alt_flag5b_response[0]!t]"

    # game/call_messages.rpy:724
    old "{b}Grim Reaper{/b}: well, now you know {font=gui/NotoSans-Light.ttf}({/font}{font=gui/LinLibertine_R.ttf}` ͜ʖ´{/font}{font=gui/NotoSans-Light.ttf}){/font}"
    new "{b}La Parca{/b}: bueno, ahora lo sabes {font=gui/NotoSans-Light.ttf}({/font}{font=gui/LinLibertine_R.ttf}` ͜ʖ´{/font}{font=gui/NotoSans-Light.ttf}){/font}"

    # game/call_messages.rpy:729
    old "{b}Grim Reaper{/b}: dear gods, you should watch what you say. you might give me a heart attack otherwise."
    new "{b}La Parca{/b}: cielos, deberías cuidar lo que dices. podrías darme un infarto si no."

    # game/call_messages.rpy:733
    old "[playername]: [day6alt_flag7b_response[0]!t]"
    new "[playername]: [day6alt_flag7b_response[0]!t]"

    # game/call_messages.rpy:735
    old "{b}[playername]:{/b} [day6alt_flag7b_response[0]!t]"
    new "{b}[playername]:{/b} [day6alt_flag7b_response[0]!t]"

    # game/call_messages.rpy:740
    old "{b}Grim Reaper{/b}: you and i are... different. i know this, and yet i can't help how i..."
    new "{b}La Parca{/b}: tú y yo somos... diferentes. lo sé, y aun así no puedo evitar cómo yo..."

    # game/call_messages.rpy:744
    old "[playername]: [day6alt_flag8b_response[0]!t]"
    new "[playername]: [day6alt_flag8b_response[0]!t]"

    # game/call_messages.rpy:746
    old "{b}[playername]:{/b} [day6alt_flag8b_response[0]!t]"
    new "{b}[playername]:{/b} [day6alt_flag8b_response[0]!t]"

    # game/call_messages.rpy:750
    old "{b}Grim Reaper:{/b} please dear gods above let this be a dream."
    new "{b}La Parca:{/b} por favor, cielos, que esto sea un sueño."

    # game/call_messages.rpy:754
    old "[playername]: [day7alt_flag1_response[0]!t]"
    new "[playername]: [day7alt_flag1_response[0]!t]"

    # game/call_messages.rpy:756
    old "{b}[playername]:{/b} [day7alt_flag1_response[0]!t]"
    new "{b}[playername]:{/b} [day7alt_flag1_response[0]!t]"

    # game/call_messages.rpy:759
    old "{b}Grim Reaper:{/b} i meant nightmare. NIGHTMARE."
    new "{b}La Parca:{/b} quise decir pesadilla. PESADILLA."

    # game/call_messages.rpy:764
    old "{b}Grim Reaper{/b}: in a way, i understand. i am just that fantastic to talk to."
    new "{b}La Parca{/b}: de alguna manera, entiendo. soy simplemente tan fantástico para hablar."

    # game/call_messages.rpy:768
    old "[playername]: [day7alt_flag3b_response[0]!t]"
    new "[playername]: [day7alt_flag3b_response[0]!t]"

    # game/call_messages.rpy:770
    old "{b}[playername]:{/b} [day7alt_flag3b_response[0]!t]"
    new "{b}[playername]:{/b} [day7alt_flag3b_response[0]!t]"

    # game/call_messages.rpy:774
    old "{b}Grim Reaper{/b}: azrael is his own man. he goes where he wants, does what he wishes, and deigns to spend his spare moments with me."
    new "{b}La Parca{/b}: azrael es un hombre independiente. va donde quiere, hace lo que desea, y se digna a pasar sus momentos libres conmigo."

    # game/call_messages.rpy:778
    old "[playername]: [day7alt_flag4b_response[0]!t]"
    new "[playername]: [day7alt_flag4b_response[0]!t]"

    # game/call_messages.rpy:780
    old "{b}[playername]:{/b} [day7alt_flag4b_response[0]!t]"
    new "{b}[playername]:{/b} [day7alt_flag4b_response[0]!t]"

    # game/call_messages.rpy:784
    old "{b}Grim Reaper{/b}: i never felt the passage of time as much as i do now. time passes for you, but continues for i."
    new "{b}La Parca{/b}: nunca sentí el paso del tiempo tanto como ahora. el tiempo pasa para ti, pero continúa para mí."

    # game/call_messages.rpy:788
    old "[playername]: [day7alt_flag5b_response[0]!t]"
    new "[playername]: [day7alt_flag5b_response[0]!t]"

    # game/call_messages.rpy:790
    old "{b}[playername]:{/b} [day7alt_flag5b_response[0]!t]"
    new "{b}[playername]:{/b} [day7alt_flag5b_response[0]!t]"

    # game/call_messages.rpy:793
    old "{b}Grim Reaper{/b}: it is my pleasure. truly. i'm honestly being selfish here. mwhahaha."
    new "{b}La Parca{/b}: es un placer. de verdad. sinceramente estoy siendo egoísta aquí. mwhahaha."

    # game/call_messages.rpy:798
    old "{b}Grim Reaper{/b}: remove this from your memory or perish, mortal."
    new "{b}La Parca{/b}: borra esto de tu memoria o perece, mortal."

    # game/call_messages.rpy:802
    old "[playername]: [day7alt_flag7b_response[0]!t]"
    new "[playername]: [day7alt_flag7b_response[0]!t]"

    # game/call_messages.rpy:804
    old "{b}[playername]:{/b} [day7alt_flag7b_response[0]!t]"
    new "{b}[playername]:{/b} [day7alt_flag7b_response[0]!t]"

    # game/call_messages.rpy:809
    old "{b}Grim Reaper{/b}: this is... not good. not good at all."
    new "{b}La Parca{/b}: esto es... no bueno. nada bueno."

    # game/call_messages.rpy:813
    old "[playername]: [day7alt_flag8b_response[0]!t]"
    new "[playername]: [day7alt_flag8b_response[0]!t]"

    # game/call_messages.rpy:815
    old "{b}[playername]:{/b} [day7alt_flag8b_response[0]!t]"
    new "{b}[playername]:{/b} [day7alt_flag8b_response[0]!t]"

    # game/call_messages.rpy:819
    old "{b}Grim Reaper:{/b} did you miss me?"
    new "{b}La Parca:{/b} ¿me extrañaste?"

    # game/call_messages.rpy:823
    old "[playername]: [day8_flag1_response[0]!t]"
    new "[playername]: [day8_flag1_response[0]!t]"

    # game/call_messages.rpy:825
    old "{b}[playername]:{/b} [day8_flag1_response[0]!t]"
    new "{b}[playername]:{/b} [day8_flag1_response[0]!t]"

    # game/call_messages.rpy:828
    old "{b}Grim Reaper:{/b} ...oh. i didn't really think you'd... right. well. that's nice. very good. i may have missed you too. there's a chance. perhaps."
    new "{b}La Parca:{/b} ...oh. no pensé que lo harías... cierto. bueno. eso es agradable. muy bien. puede que yo también te haya extrañado. hay una posibilidad. quizá."

    # game/call_messages.rpy:833
    old "{b}Grim Reaper{/b}: other reapers are boring, anyway. you have me. the most interesting one around."
    new "{b}La Parca{/b}: de todas formas, otras parcas son aburridas. me tienes a mí. el más interesante de todos."

    # game/call_messages.rpy:837
    old "[playername]: [day8_flag3b_response[0]!t]"
    new "[playername]: [day8_flag3b_response[0]!t]"

    # game/call_messages.rpy:839
    old "{b}[playername]:{/b} [day8_flag3b_response[0]!t]"
    new "{b}[playername]:{/b} [day8_flag3b_response[0]!t]"

    # game/call_messages.rpy:843
    old "{b}Grim Reaper{/b}: though, i am a fan of your fast food. now i'm hungry..."
    new "{b}La Parca{/b}: aunque, soy fan de tu comida rápida. ahora tengo hambre..."

    # game/call_messages.rpy:847
    old "[playername]: [day8_flag4b_response[0]!t]"
    new "[playername]: [day8_flag4b_response[0]!t]"

    # game/call_messages.rpy:849
    old "{b}[playername]:{/b} [day8_flag4b_response[0]!t]"
    new "{b}[playername]:{/b} [day8_flag4b_response[0]!t]"

    # game/call_messages.rpy:853
    old "{b}Grim Reaper{/b}: so, so many nonsensical thoughts. sometimes i worry about you. "
    new "{b}La Parca{/b}: tantos, tantos pensamientos sin sentido. a veces me preocupo por ti."

    # game/call_messages.rpy:857
    old "[playername]: [day8_flag5b_response[0]!t]"
    new "[playername]: [day8_flag5b_response[0]!t]"

    # game/call_messages.rpy:859
    old "{b}[playername]:{/b} [day8_flag5b_response[0]!t]"
    new "{b}[playername]:{/b} [day8_flag5b_response[0]!t]"

    # game/call_messages.rpy:862
    old "{b}Grim Reaper{/b}: brainrot? an apt description for you, i would think. that would explain why you keep calling me 'babygirl' and 'pookie'."
    new "{b}La Parca{/b}: ¿brainrot? sería una descripción acertada para ti, creo. eso explicaría por qué sigues llamándome 'babygirl' y 'pookie'."

    # game/call_messages.rpy:867
    old "{b}Grim Reaper{/b}: i... i said something along the lines of 'i hate nearly everyone'. obviously."
    new "{b}La Parca{/b}: yo... dije algo como 'odio a casi todos'. obviamente."

    # game/call_messages.rpy:871
    old "[playername]: [day8_flag7b_response[0]!t]"
    new "[playername]: [day8_flag7b_response[0]!t]"

    # game/call_messages.rpy:873
    old "{b}[playername]:{/b} [day8_flag7b_response[0]!t]"
    new "{b}[playername]:{/b} [day8_flag7b_response[0]!t]"

    # game/call_messages.rpy:878
    old "{b}Grim Reaper{/b}: i... i could not even begin to hope to be something else... i have always been this. i... i've always loved this, until..."
    new "{b}La Parca{/b}: yo... no podría ni empezar a esperar ser otra cosa... siempre he sido así. yo... siempre he amado esto, hasta que..."

    # game/call_messages.rpy:882
    old "[playername]: [day8_flag8b_response[0]!t]"
    new "[playername]: [day8_flag8b_response[0]!t]"

    # game/call_messages.rpy:884
    old "{b}[playername]:{/b} [day8_flag8b_response[0]!t]"
    new "{b}[playername]:{/b} [day8_flag8b_response[0]!t]"

    # game/call_messages.rpy:888
    old "{b}Grim Reaper:{/b} are you sure you are not a witch or a warlock or something similar?"
    new "{b}La Parca:{/b} ¿de verdad no eres una bruja, un brujo o algo similar?"

    # game/call_messages.rpy:892
    old "[playername]: [day9_flag1b_response[0]!t]"
    new "[playername]: [day9_flag1b_response[0]!t]"

    # game/call_messages.rpy:894
    old "{b}[playername]:{/b} [day9_flag1b_response[0]!t]"
    new "{b}[playername]:{/b} [day9_flag1b_response[0]!t]"

    # game/call_messages.rpy:897
    old "{b}Grim Reaper:{/b} perhaps you have put a spell on me, and that is why i miss you so. "
    new "{b}La Parca:{/b} quizás me hayas hechizado, y por eso te extraño tanto."

    # game/call_messages.rpy:902
    old "{b}Grim Reaper{/b}: you are the reaper version of a homewrecker. a... reaper wrecker."
    new "{b}La Parca{/b}: eres la versión parca de un rompehogares. un... rompeparcas."

    # game/call_messages.rpy:906
    old "[playername]: [day9_flag3b_response[0]!t]"
    new "[playername]: [day9_flag3b_response[0]!t]"

    # game/call_messages.rpy:908
    old "{b}[playername]:{/b} [day9_flag3b_response[0]!t]"
    new "{b}[playername]:{/b} [day9_flag3b_response[0]!t]"

    # game/call_messages.rpy:912
    old "{b}Grim Reaper{/b}: i feel myself growing hungry just thinking about it..."
    new "{b}La Parca{/b}: siento que me da hambre solo de pensarlo..."

    # game/call_messages.rpy:916
    old "[playername]: [day9_flag4b_response[0]!t]"
    new "[playername]: [day9_flag4b_response[0]!t]"

    # game/call_messages.rpy:918
    old "{b}[playername]:{/b} [day9_flag4b_response[0]!t]"
    new "{b}[playername]:{/b} [day9_flag4b_response[0]!t]"

    # game/call_messages.rpy:1257
    old "Messages - Grim Reaper"
    new "Mensajes          "

