# TODO: Translation updated at 2026-10-15 18:36

translate Spanish strings:

    # game/charactercreator.rpy:1014
    old "Click here to input your character bio - you can update it along the way!"
    new "Haz clic aquí para introducir la biografía de tu personaje. ¡Puedes actualizarla cuando quieras!"

    # game/charactercreator.rpy:1048
    old "Save Your Photo"
    new "Guarda Tu Foto"

    # game/charactercreator.rpy:1083
    old "Next"
    new "Siguiente"

    # game/charactercreator.rpy:1103
    old "Finish Editing"
    new "Terminar Edición"

    # game/charactercreator.rpy:1110
    old "IMAGE"
    new "IMAGEN"

    # game/charactercreator.rpy:1111
    old "BIOGRAPHY"
    new "BIOGRAFÍA"

    # game/charactercreator.rpy:1168
    old "Presets"
    new "Preajustes"

    # game/charactercreator.rpy:1190
    old "Accept"
    new "Aceptar"

    # game/charactercreator.rpy:2139
    old "Left Eye"
    new "Ojo Izq"

    # game/charactercreator.rpy:2140
    old "Right Eye"
    new "Ojo Der"

    # game/charactercreator.rpy:2427
    old "Pronouns"
    new "Pronombres"

    # game/charactercreator.rpy:2428
    old "Gender"
    new "Género"

    # game/charactercreator.rpy:2429
    old "Descriptive Words"
    new "Palabras descriptivas"

    # game/charactercreator.rpy:2438
    old "NEXT PAGE"
    new "SIG PÁG"

    # game/charactercreator.rpy:2449
    old "I am a girl, and use [she]/[her]."
    new "Soy una chica y utilizo [she!t]."

    # game/charactercreator.rpy:2458
    old "I am nonbinary, and use [she]/[her]."
    new "Soy no binarie y utilizo [she!t]."

    # game/charactercreator.rpy:2464
    old "Nonbinary"
    new "No binarie"

    # game/charactercreator.rpy:2468
    old "I am a boy, and use [she]/[her]."
    new "Soy un chico y uso [she!t]."

    # game/charactercreator.rpy:2483
    old "Example: She looks so cool! I'm proud of her."
    new "Ejemplo: ¡Ella se ve tan genial! Estoy orgulloso de ella."

    # game/charactercreator.rpy:2489
    old "She/Her"
    new "Ella"

    # game/charactercreator.rpy:2492
    old "Example: They looks so cool! I'm proud of them."
    new "Ejemplo: ¡Elle se ve tan genial! Estoy orgulloso de elle."

    # game/charactercreator.rpy:2498
    old "They/Them"
    new "Elle"

    # game/charactercreator.rpy:2503
    old "Example: He looks so cool! I'm proud of him."
    new "Ejemplo: ¡Él se ve tan genial! Estoy orgulloso de él."

    # game/charactercreator.rpy:2509
    old "He/Him"
    new "Él"

    # game/charactercreator.rpy:2512
    old "Example: [She] looks so cool! I'm proud of [her]."
    new "Ejemplo: ¡[She!t] se ve tan genial! Estoy orgulloso de [she!t]."

    # game/charactercreator.rpy:2518
    old "Custom"
    new "Personalizado"

    # game/charactercreator.rpy:2524
    old "I prefer to be called beautiful."
    new "Prefiero que me llamen guapa."

    # game/charactercreator.rpy:2530
    old "Feminine Leaning"
    new "Pref. femenina"

    # game/charactercreator.rpy:2533
    old "I prefer to be called handsome."
    new "Prefiero que me llamen guapo."

    # game/charactercreator.rpy:2539
    old "Masculine Leaning"
    new "Pref. masculina"

    # game/charactercreator.rpy:2542
    old "I prefer to be called captivating."
    new "Prefiero que me llamen cautivante."

    # game/charactercreator.rpy:2548
    old "Neutral Leaning"
    new "Pref. neutral"

    # game/charactercreator.rpy:2551
    old "I prefer to be called [beautiful]."
    new "Prefiero que me llamen [beautiful!t]."

    # game/charactercreator.rpy:2557
    old "Custom Leaning"
    new "Pref. personalizada"

    # game/charactercreator.rpy:2565
    old "First Name"
    new "Nombre"

    # game/charactercreator.rpy:2566
    old "Last Name"
    new "Apellido"

    # game/charactercreator.rpy:2567
    old "Favorite Animal"
    new "Animal favorito"

    # game/charactercreator.rpy:2600
    old "PREVIOUS PAGE"
    new "ANT PÁG"

    # game/charactercreator.rpy:2615
    old "Bunny"
    new "Conejo"

    # game/charactercreator.rpy:2623
    old "Cat"
    new "Gato"

    # game/charactercreator.rpy:2631
    old "Sphynx"
    new "Gato esfinge"

    # game/charactercreator.rpy:2639
    old "Dog"
    new "Perro"

    # game/charactercreator.rpy:2648
    old "Hamster"
    new "Hámster"

    # game/charactercreator.rpy:2657
    old "Snake"
    new "Serpiente"

