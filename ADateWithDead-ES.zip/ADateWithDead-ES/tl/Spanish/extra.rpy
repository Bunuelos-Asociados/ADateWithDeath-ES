# TODO: Translation updated at 2026-10-15 18:36

translate Spanish strings:

    # game/extra.rpy:45
    old "RETURN"
    new "VOLVER"

    # game/extra.rpy:459
    old "Grim Reaper Design 1"
    new "Diseño de la Parca 1"

    # game/extra.rpy:460
    old "Grim Reaper Design 2"
    new "Diseño de la Parca 2"

    # game/extra.rpy:461
    old "Animation Character Designs"
    new "Diseños de personajes de la animación"

    # game/extra.rpy:462
    old "Animation Storyboards"
    new "Storyboards De Animación"

    # game/extra.rpy:463
    old "Sprite Sketches"
    new "Bocetos de sprites"

    # game/extra.rpy:464
    old "Grim Reaper Bedroom Design"
    new "Diseño del dormitorio de la Parca"

    # game/extra.rpy:465
    old "Player Bedroom Design"
    new "Diseño del dormitorio del jugador"

    # game/extra.rpy:466
    old "Grim Reaper Finalized Bedroom"
    new "Dormitorio finalizado de la Parca"

    # game/extra.rpy:467
    old "Grim Reaper Patreon Artwork #1"
    new "Arte #1 de la Parca (Patreon)"

    # game/extra.rpy:468
    old "Grim Reaper Halloween 2023"
    new "La Parca Halloween 2023"

    # game/extra.rpy:469
    old "Halloween YCH 2023 Sketch"
    new "YCH de Halloween 2023 (Boceto)"

    # game/extra.rpy:470
    old "Halloween YCH 2023"
    new "YCH de Halloween 2023"

    # game/extra.rpy:471
    old "Aug 2023 Patreon NSFW Preview"
    new "Vista Previa NSFW De Patreon (Ago 2023)"

    # game/extra.rpy:472
    old "CG Flowers Sketches"
    new "CG Flores (Boceto)"

    # game/extra.rpy:473
    old "CG Flowers"
    new "CG Flores"

    # game/extra.rpy:474
    old "CG Hugging Azrael Sketch"
    new "CG Abrazando a Azrael (Boceto)"

    # game/extra.rpy:475
    old "CG Hugging Azrael"
    new "CG Abrazando A Azrael"

    # game/extra.rpy:476
    old "CG On Your Bed Sketches"
    new "CG En Tu Cama (Boceto)"

    # game/extra.rpy:479
    old "CG On Your Bed"
    new "CG En Tu Cama"

    # game/extra.rpy:491
    old "CG DLC Duo Reapers Sketch"
    new "CG Dúo de Parcas (DLC) (Boceto)"

    # game/extra.rpy:492
    old "CG DLC Duo Reapers"
    new "CG Dúo de Parcas (DLC)"

    # game/extra.rpy:494
    old "CG Wedding Sketch"
    new "CG Boda (Boceto)"

    # game/extra.rpy:495
    old "CG Wedding"
    new "CG Boda"

    # game/extra.rpy:496
    old "Christmas YCH 2023 Sketch"
    new "Navidad YCH 2023 (Boceto)"

    # game/extra.rpy:497
    old "Christmas YCH 2023"
    new "Navidad YCH 2023"

    # game/extra.rpy:500
    old "February 2024 Patreon NSFW Preview"
    new "Vista previa NSFW Patreon Febrero 2024"

    # game/extra.rpy:501
    old "Valentines 2024 Sketch"
    new "San Valentín 2024 (Boceto)"

    # game/extra.rpy:502
    old "CG Fireworks Sketch"
    new "CG Fuegos Artificiales (Boceto)"

    # game/extra.rpy:503
    old "CG Fireworks"
    new "CG Fuegos Artificiales"

    # game/extra.rpy:504
    old "Kickstarter Celebration 2024"
    new "Celebración Kickstarter 2024"

    # game/extra.rpy:505
    old "CG Florist Sketch"
    new "CG Florista (Boceto)"

    # game/extra.rpy:506
    old "CG Florist"
    new "CG Florista"

    # game/extra.rpy:507
    old "CG Bathtime Sketch"
    new "CG Hora del Baño (Boceto)"

    # game/extra.rpy:508
    old "CG Bathtime"
    new "CG Hora del Baño"

    # game/extra.rpy:509
    old "CG The Underworld Sketch"
    new "CG Inframundo (Boceto)"

    # game/extra.rpy:510
    old "CG The Underworld"
    new "CG Inframundo"

    # game/extra.rpy:511
    old "CG Goodbyes Sketch"
    new "CG Despedidas (Boceto)"

    # game/extra.rpy:512
    old "CG Goodbyes"
    new "CG Despedidas"

    # game/extra.rpy:515
    old "CG NSFW 1"
    new "CG NSFW 1"

    # game/extra.rpy:516
    old "CG NSFW 2"
    new "CG NSFW 2"

