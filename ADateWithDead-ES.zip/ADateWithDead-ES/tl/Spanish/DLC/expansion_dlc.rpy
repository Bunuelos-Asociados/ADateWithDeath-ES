﻿# TODO: Translation updated at 2026-10-15 18:36

# game/DLC/expansion_dlc.rpy:8
translate Spanish dlc_is_present_4efe1b19:

    # "present!"
    "¡presente!"

