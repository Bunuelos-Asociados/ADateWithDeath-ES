# TODO: Translation updated at 2026-10-15 18:36

# game/chapters/6_roomexplore.rpy:216
translate Spanish bed_hub6_c0bdcd4c:

    # "Sitting on your bed, you have a perfect view of a certain bouquet of yellow flowers that was given to you yesterday."
    "Cuando te sientas en la cama, tienes una vista perfecta de un ramo de flores amarillas que te regalaron ayer."

# game/chapters/6_roomexplore.rpy:217
translate Spanish bed_hub6_967b6279:

    # "Given to you by... the Grim Reaper, of all people."
    "Te las regaló... nada menos que la Parca."

# game/chapters/6_roomexplore.rpy:218
translate Spanish bed_hub6_f4ae7946:

    # "The thought makes you somewhat giddy. Who could have guessed that strange talking weirdo could be such a romantic?"
    "La idea te llena de una ligera euforia. ¿Quién hubiera imaginado que ese bicho raro y parlanchín pudiera ser tan romántico?"

# game/chapters/6_roomexplore.rpy:219
translate Spanish bed_hub6_7e3e2e90:

    # "Though you've never received flowers before, you have given them to someone else..."
    "Aunque nunca antes habías recibido flores, tú sí las habías regalado a alguien más..."

# game/chapters/6_roomexplore.rpy:235
translate Spanish bed_hub6_03572a02:

    # "You have always thought of flowers as a special thing. A simple thing, but still special."
    "Siempre has considerado las flores como algo especial. Algo sencillo, pero especial al fin y al cabo."

# game/chapters/6_roomexplore.rpy:236
translate Spanish bed_hub6_a62d2724:

    # "And you felt very special when you looked at the flowers Casper brought you yesterday."
    "Y te sintiste muy especial cuando viste las flores que Casper te trajo ayer."

# game/chapters/6_roomexplore.rpy:247
translate Spanish door_hub6_bbd8e42a:

    # "You hear footsteps from the hallway. You wonder if it's your neighbors again?"
    "Oyes pasos en el pasillo. Te preguntas si serán tus vecinos otra vez."

# game/chapters/6_roomexplore.rpy:253
translate Spanish door_hub6_52eb8252:

    # "You hear a sniffling coming from the hallway, then the sound of someone sliding down to the floor."
    "Oyes un sollozo procedente del pasillo, seguido del sonido de alguien deslizándose hasta el suelo."

# game/chapters/6_roomexplore.rpy:254
translate Spanish door_hub6_06af4f93:

    # "You imagine someone is currently leaning against the doorway of their apartment."
    "Imaginas que alguien está apoyado contra la puerta de su apartamento."

# game/chapters/6_roomexplore.rpy:255
translate Spanish door_hub6_4db76323:

    # "You hear a fumbling - the sound of someone digging through their bag, searching for something."
    "Oyes un trasteo: alguien está hurgando en su bolso, buscando algo."

# game/chapters/6_roomexplore.rpy:256
translate Spanish door_hub6_07880855:

    # "Then a sigh."
    "Luego, un suspiro."

# game/chapters/6_roomexplore.rpy:257
translate Spanish door_hub6_0b700eb9:

    # "A ringing. The sound of someone who desperately seeks another."
    "Un tono de llamada. El sonido de alguien que busca desesperadamente a otra persona."

# game/chapters/6_roomexplore.rpy:258
translate Spanish door_hub6_571aa237:

    # "And then, finally, a voice."
    "Y entonces, por fin, una voz."

# game/chapters/6_roomexplore.rpy:259
translate Spanish door_hub6_0b1481c8:

    # "'Mom, are you there? Can you talk right now?' a light and airy voice starts."
    "'Mamá, ¿estás ahí? ¿Puedes hablar ahora?', comienza a decir una voz suave y despreocupada."

# game/chapters/6_roomexplore.rpy:260
translate Spanish door_hub6_8f07a59a:

    # "'No, I'm fine. No, I wasn't crying...'"
    "'No, estoy bien. No, no estaba llorando...'"

# game/chapters/6_roomexplore.rpy:261
translate Spanish door_hub6_e2c7a5cb:

    # "'I just wanted to talk for a bit. If that's okay.'"
    "'Solo quería hablar un rato. Si no te importa.'"

# game/chapters/6_roomexplore.rpy:262
translate Spanish door_hub6_b4994b24:

    # "Another sniffle."
    "Otro sollozo."

# game/chapters/6_roomexplore.rpy:263
translate Spanish door_hub6_326dfbb2:

    # "'Nothing happened, really. I'm just confused. And I lost my keys, but I'll worry about that in a minute...'"
    "'‘No ha pasado nada, de verdad. Solo tengo la cabeza hecha un lío. Y perdí las llaves, pero ya me preocuparé por eso después...'"

# game/chapters/6_roomexplore.rpy:264
translate Spanish door_hub6_dc28c832:

    # "There's silence for a minute. You imagine their mother is currently fretting, trying to console their child despite not knowing what's wrong."
    "Hay un minuto de silencio. Imaginas a su madre, preocupada, tratando de consolar a su retoño sin saber qué le pasa."

# game/chapters/6_roomexplore.rpy:265
translate Spanish door_hub6_be23173c:

    # "'Have you ever liked someone so much that it's made you terrified?'"
    "'¿Alguna vez te ha gustado alguien tanto que te ha dado miedo?'"

# game/chapters/6_roomexplore.rpy:266
translate Spanish door_hub6_a813b3cf:

    # "'I really like them, mom. I've only known them for like a week, but I feel like it's been so much longer...'"
    "'Me gusta mucho, mamá. Solo hace una semana que nos conocemos, pero siento como si fuera mucho más tiempo...'"

# game/chapters/6_roomexplore.rpy:267
translate Spanish door_hub6_0b49988a:

    # "'And I'm scared.'"
    "'Y tengo miedo.'"

# game/chapters/6_roomexplore.rpy:268
translate Spanish door_hub6_4beb1ab3:

    # "There's vulnerability in that voice. Immense vulnerability."
    "Hay vulnerabilidad en esa voz. Una vulnerabilidad inmensa."

# game/chapters/6_roomexplore.rpy:269
translate Spanish door_hub6_480ae9e4:

    # "Their voice is like a plea to something they cannot see."
    "Su voz es como una súplica a algo que no puede ver."

# game/chapters/6_roomexplore.rpy:270
translate Spanish door_hub6_94ecefc1:

    # "Like a wish upon a star."
    "Como pedirle un deseo a una estrella."

# game/chapters/6_roomexplore.rpy:271
translate Spanish door_hub6_1913f0a4:

    # "'I want to understand them. I want to make things work. But I'm scared I will make things worse.'"
    "'Quiero entender a esa persona. Quiero que las cosas funcionen. Pero tengo miedo de empeorar las cosas.'"

# game/chapters/6_roomexplore.rpy:272
translate Spanish door_hub6_d6020bd7:

    # "'I'm scared that neither of us are what we expect of each other.'"
    "'Tengo miedo de que ninguno de los dos sea lo que el otro espera.'"

# game/chapters/6_roomexplore.rpy:273
translate Spanish door_hub6_8932e9cb:

    # "The fear of not living up to expectations, the fear of misunderstandings. Such human emotions."
    "El miedo a no estar a la altura de las expectativas, el miedo a los malentendidos. Emociones tan humanas."

# game/chapters/6_roomexplore.rpy:274
translate Spanish door_hub6_bf243446:

    # "'I know, Mom. I know I should talk to them, but it's so much. It's like there's this weight, this secret between us, and I don't know how to bridge the gap.'"
    "'Lo sé, mamá. Sé que debería hablar con esa persona, pero es demasiado para mí. Es como si hubiera un peso, un secreto entre nosotros, y no sé cómo superar esa barrera.'"

# game/chapters/6_roomexplore.rpy:275
translate Spanish door_hub6_a88c3fb9:

    # "'I think I heard them say something last night, something important. But they didn't open up completely, and now I'm torn between wanting to know and being afraid of what I might discover.'"
    "'Creo que anoche le oí decir algo, algo importante. Pero no llegó a sincerarse del todo, y ahora no sé qué hacer: quiero saber más, pero también me da miedo lo que pueda descubrir.'"

# game/chapters/6_roomexplore.rpy:276
translate Spanish door_hub6_f2ea5841:

    # "An internal struggle. A deep desire."
    "Una lucha interna. Un deseo profundo."

# game/chapters/6_roomexplore.rpy:277
translate Spanish door_hub6_b4462bca:

    # "'But, Mom, I can't stay away. I've never believed in fate, but this is... I just... I need some guidance. What do I do?'"
    "'Pero, mamá, no puedo alejarme. Nunca he creído en el destino, pero esto es... Es solo que... Necesito orientación. ¿Qué hago?'"

# game/chapters/6_roomexplore.rpy:278
translate Spanish door_hub6_cef912f6:

    # "Silence again."
    "Silencio de nuevo."

# game/chapters/6_roomexplore.rpy:279
translate Spanish door_hub6_f3a4e945:

    # "You imagine their mother is speaking words of wisdom, filled with kindness, love and worry."
    "Te imaginas a su madre pronunciando palabras de sabiduría, llenas de amabilidad, amor y preocupación."

# game/chapters/6_roomexplore.rpy:280
translate Spanish door_hub6_3209ea9a:

    # "'...Okay. I'll go talk to them tomorrow and make a decision.'"
    "'...Está bien. Mañana hablaré con esa persona y tomaré una decisión.'"

# game/chapters/6_roomexplore.rpy:281
translate Spanish door_hub6_e2832f78:

    # "'Thank you, Mom. I love you.'"
    "'Gracias, mamá. Te amo.'"

# game/chapters/6_roomexplore.rpy:282
translate Spanish door_hub6_a9f941ab:

    # "The sound of the call ending reaches you even beyond the hallway, and then there's silence."
    "El sonido de la llamada al terminar llega hasta donde estás, incluso desde el otro lado del pasillo. Después, todo queda en silencio."

# game/chapters/6_roomexplore.rpy:283
translate Spanish door_hub6_5f6e59cd:

    # "You hope they find their keys."
    "Ojalá encuentre las llaves."

# game/chapters/6_roomexplore.rpy:298
translate Spanish door_hub6_52eb8252_1:

    # "You hear a sniffling coming from the hallway, then the sound of someone sliding down to the floor."
    "Oyes un sollozo procedente del pasillo, seguido del sonido de alguien deslizándose hasta el suelo."

# game/chapters/6_roomexplore.rpy:299
translate Spanish door_hub6_06af4f93_1:

    # "You imagine someone is currently leaning against the doorway of their apartment."
    "Imaginas que alguien está apoyado contra la puerta de su apartamento."

# game/chapters/6_roomexplore.rpy:300
translate Spanish door_hub6_4db76323_1:

    # "You hear a fumbling - the sound of someone digging through their bag, searching for something."
    "Oyes un trasteo: alguien está hurgando en su bolso, buscando algo."

# game/chapters/6_roomexplore.rpy:301
translate Spanish door_hub6_07880855_1:

    # "Then a sigh."
    "Luego, un suspiro."

# game/chapters/6_roomexplore.rpy:302
translate Spanish door_hub6_0b700eb9_1:

    # "A ringing. The sound of someone who desperately seeks another."
    "Un tono de llamada. El sonido de alguien que busca desesperadamente a otra persona."

# game/chapters/6_roomexplore.rpy:303
translate Spanish door_hub6_571aa237_1:

    # "And then, finally, a voice."
    "Y entonces, por fin, una voz."

# game/chapters/6_roomexplore.rpy:304
translate Spanish door_hub6_0b1481c8_1:

    # "'Mom, are you there? Can you talk right now?' a light and airy voice starts."
    "'Mamá, ¿estás ahí? ¿Puedes hablar ahora?', comienza a decir una voz suave y despreocupada."

# game/chapters/6_roomexplore.rpy:305
translate Spanish door_hub6_8f07a59a_1:

    # "'No, I'm fine. No, I wasn't crying...'"
    "'No, estoy bien. No, no estaba llorando...'"

# game/chapters/6_roomexplore.rpy:306
translate Spanish door_hub6_e2c7a5cb_1:

    # "'I just wanted to talk for a bit. If that's okay.'"
    "'Solo quería hablar un rato. Si no te importa.'"

# game/chapters/6_roomexplore.rpy:307
translate Spanish door_hub6_b4994b24_1:

    # "Another sniffle."
    "Otro sollozo."

# game/chapters/6_roomexplore.rpy:308
translate Spanish door_hub6_326dfbb2_1:

    # "'Nothing happened, really. I'm just confused. And I lost my keys, but I'll worry about that in a minute...'"
    "'No ha pasado nada, de verdad. Solo tengo la cabeza hecha un lío. Y perdí las llaves, pero ya me preocuparé por eso después...'"

# game/chapters/6_roomexplore.rpy:309
translate Spanish door_hub6_dc28c832_1:

    # "There's silence for a minute. You imagine their mother is currently fretting, trying to console their child despite not knowing what's wrong."
    "Hay un minuto de silencio. Imaginas a su madre, preocupada, tratando de consolar a su retoño sin saber qué le pasa."

# game/chapters/6_roomexplore.rpy:310
translate Spanish door_hub6_be23173c_1:

    # "'Have you ever liked someone so much that it's made you terrified?'"
    "'¿Alguna vez te ha gustado alguien tanto que te ha dado miedo?'"

# game/chapters/6_roomexplore.rpy:311
translate Spanish door_hub6_a813b3cf_1:

    # "'I really like them, mom. I've only known them for like a week, but I feel like it's been so much longer...'"
    "'Me gusta mucho, mamá. Solo hace una semana que nos conocemos, pero siento como si fuera mucho más tiempo...'"

# game/chapters/6_roomexplore.rpy:312
translate Spanish door_hub6_0b49988a_1:

    # "'And I'm scared.'"
    "'Y tengo miedo.'"

# game/chapters/6_roomexplore.rpy:313
translate Spanish door_hub6_4beb1ab3_1:

    # "There's vulnerability in that voice. Immense vulnerability."
    "Hay vulnerabilidad en esa voz. Una vulnerabilidad inmensa."

# game/chapters/6_roomexplore.rpy:314
translate Spanish door_hub6_480ae9e4_1:

    # "Their voice is like a plea to something they cannot see."
    "Su voz es como una súplica a algo que no puede ver."

# game/chapters/6_roomexplore.rpy:315
translate Spanish door_hub6_94ecefc1_1:

    # "Like a wish upon a star."
    "Como pedirle un deseo a una estrella."

# game/chapters/6_roomexplore.rpy:316
translate Spanish door_hub6_1913f0a4_1:

    # "'I want to understand them. I want to make things work. But I'm scared I will make things worse.'"
    "'Quiero entender a esa persona. Quiero que las cosas funcionen. Pero tengo miedo de empeorar las cosas.'"

# game/chapters/6_roomexplore.rpy:317
translate Spanish door_hub6_d6020bd7_1:

    # "'I'm scared that neither of us are what we expect of each other.'"
    "'Tengo miedo de que ninguno de los dos sea lo que el otro espera.'"

# game/chapters/6_roomexplore.rpy:318
translate Spanish door_hub6_8932e9cb_1:

    # "The fear of not living up to expectations, the fear of misunderstandings. Such human emotions."
    "El miedo a no estar a la altura de las expectativas, el miedo a los malentendidos. Emociones tan humanas."

# game/chapters/6_roomexplore.rpy:319
translate Spanish door_hub6_bf243446_1:

    # "'I know, Mom. I know I should talk to them, but it's so much. It's like there's this weight, this secret between us, and I don't know how to bridge the gap.'"
    "'Lo sé, mamá. Sé que debería hablar con esa persona, pero es demasiado para mí. Es como si hubiera un peso, un secreto entre nosotros, y no sé cómo superar esa barrera.'"

# game/chapters/6_roomexplore.rpy:320
translate Spanish door_hub6_a88c3fb9_1:

    # "'I think I heard them say something last night, something important. But they didn't open up completely, and now I'm torn between wanting to know and being afraid of what I might discover.'"
    "'Creo que anoche le oí decir algo, algo importante. Pero no llegó a sincerarse del todo, y ahora no sé qué hacer: quiero saber más, pero también me da miedo lo que pueda descubrir.'"

# game/chapters/6_roomexplore.rpy:321
translate Spanish door_hub6_f2ea5841_1:

    # "An internal struggle. A deep desire."
    "Una lucha interna. Un deseo profundo."

# game/chapters/6_roomexplore.rpy:322
translate Spanish door_hub6_b4462bca_1:

    # "'But, Mom, I can't stay away. I've never believed in fate, but this is... I just... I need some guidance. What do I do?'"
    "'Pero, mamá, no puedo alejarme. Nunca he creído en el destino, pero esto es... Es solo que... Necesito orientación. ¿Qué hago?'"

# game/chapters/6_roomexplore.rpy:323
translate Spanish door_hub6_cef912f6_1:

    # "Silence again."
    "Silencio de nuevo."

# game/chapters/6_roomexplore.rpy:324
translate Spanish door_hub6_f3a4e945_1:

    # "You imagine their mother is speaking words of wisdom, filled with kindness, love and worry."
    "Te imaginas a su madre pronunciando palabras de sabiduría, llenas de amabilidad, amor y preocupación."

# game/chapters/6_roomexplore.rpy:325
translate Spanish door_hub6_3209ea9a_1:

    # "'...Okay. I'll go talk to them tomorrow and make a decision.'"
    "'...Está bien. Mañana hablaré con esa persona y tomaré una decisión.'"

# game/chapters/6_roomexplore.rpy:326
translate Spanish door_hub6_e2832f78_1:

    # "'Thank you, Mom. I love you.'"
    "'Gracias, mamá. Te amo.'"

# game/chapters/6_roomexplore.rpy:327
translate Spanish door_hub6_a9f941ab_1:

    # "The sound of the call ending reaches you even beyond the hallway, and then there's silence."
    "El sonido de la llamada al terminar llega hasta donde estás, incluso desde el otro lado del pasillo. Después, todo queda en silencio."

# game/chapters/6_roomexplore.rpy:328
translate Spanish door_hub6_5f6e59cd_1:

    # "You hope they find their keys."
    "Ojalá encuentre las llaves."

# game/chapters/6_roomexplore.rpy:340
translate Spanish door_hub6_b82ac03c:

    # "The hallway beyond is silent now."
    "El pasillo está ahora en silencio."

# game/chapters/6_roomexplore.rpy:341
translate Spanish door_hub6_33f78972:

    # "You hope tomorrow will bring resolution."
    "Esperas que mañana llegue una solución."

# game/chapters/6_roomexplore.rpy:355
translate Spanish snake_hub6_21a76a54:

    # "[pet_name] seems to be doing well today!"
    "¡[pet_name] parece estar bien hoy!"

# game/chapters/6_roomexplore.rpy:356
translate Spanish snake_hub6_f1b7a781:

    # "You sit down on the bed next to [pet_her2] and think towards the future..."
    "Te sientas en la cama junto a [pet_her2] y empiezas a pensar en el futuro..."

# game/chapters/6_roomexplore.rpy:357
translate Spanish snake_hub6_2a45099f:

    # "If you ever manage to afford a house with the market looking like it is, you..."
    "Si alguna vez consigues ahorrar lo suficiente para comprarte una casa, con el mercado tal y como está, tú..."

# game/chapters/6_roomexplore.rpy:362
translate Spanish snake_hub6_d8b52889:

    # "You've always liked dogs. They appeal to you, but you want one that needs a big yard... and you don't have that. {i}Yet.{/i}"
    "Siempre te han gustado los perros. Te encantan, pero quieres uno que necesite un jardín grande... y no lo tienes. {i}Todavía.{/i}"

# game/chapters/6_roomexplore.rpy:366
translate Spanish snake_hub6_aa6976c3:

    # "Is there anything greater in the world than cats? Well, [pet_name] first of all, but you do love cats."
    "¿Hay algo mejor en el mundo que los gatos? Bueno, [pet_name] en primer lugar, pero tú adoras a los gatos."

# game/chapters/6_roomexplore.rpy:370
translate Spanish snake_hub6_209ecbae:

    # "What's better than one snake? Two, if you had the room for more enclosures."
    "¿Qué es mejor que tener una serpiente? ¡Dos! Si tuvieras espacio para más terrarios."

# game/chapters/6_roomexplore.rpy:374
translate Spanish snake_hub6_176f6622:

    # "Pets need so much time, effort and love... and money. One pet is plenty for you."
    "Las mascotas requieren mucho tiempo, esfuerzo, cariño... y dinero. Una mascota es suficiente para ti."

# game/chapters/6_roomexplore.rpy:376
translate Spanish snake_hub6_97641580:

    # "For now, you enjoy [pet_name]'s company immensely. You hope that, Grim Reaper and strange soul notwithstanding, you have many fun times ahead of you together."
    "Por ahora, disfrutas enormemente de la compañía de [pet_name]. Esperas que, a pesar de la Parca y de esa alma extraña, les esperen muchos momentos divertidos juntos."

# game/chapters/6_roomexplore.rpy:382
translate Spanish snake_hub6_414bf7f5:

    # "'Why did the snake go to school?' you ask [pet_name]."
    "'¿Por qué la serpiente fue a la escuela?' le preguntas a [pet_name]."

# game/chapters/6_roomexplore.rpy:383
translate Spanish snake_hub6_6de53b57:

    # "[pet_name] doesn't reply, but that doesn't stop you from continuing your joke."
    "[pet_name] no responde, pero eso no te impide continuar tu chiste."

# game/chapters/6_roomexplore.rpy:384
translate Spanish snake_hub6_8432cb99:

    # "'To improve in hiss-tory!'"
    "'¡Para mejorar en hisssstoria!'"

# game/chapters/6_roomexplore.rpy:385
translate Spanish snake_hub6_0cfddb63:

    # "[pet_name] completely cracks up laughing.... not."
    "[pet_name] se parte de risa... o no."

# game/chapters/6_roomexplore.rpy:386
translate Spanish snake_hub6_9c89023a:

    # "But you still think your joke was appreciated. Maybe."
    "Pero sigues pensando que tu chiste fue bien recibido. Quizás."

# game/chapters/6_roomexplore.rpy:398
translate Spanish bingus_hub6_21a76a54:

    # "[pet_name] seems to be doing well today!"
    "¡[pet_name] parece estar bien hoy!"

# game/chapters/6_roomexplore.rpy:399
translate Spanish bingus_hub6_f1b7a781:

    # "You sit down on the bed next to [pet_her2] and think towards the future..."
    "Te sientas en la cama junto a [pet_her2] y empiezas a pensar en el futuro..."

# game/chapters/6_roomexplore.rpy:400
translate Spanish bingus_hub6_2a45099f:

    # "If you ever manage to afford a house with the market looking like it is, you..."
    "Si alguna vez consigues ahorrar lo suficiente para comprarte una casa, con el mercado tal y como está, tú..."

# game/chapters/6_roomexplore.rpy:405
translate Spanish bingus_hub6_d8b52889:

    # "You've always liked dogs. They appeal to you, but you want one that needs a big yard... and you don't have that. {i}Yet.{/i}"
    "Siempre te han gustado los perros. Te encantan, pero quieres uno que necesite un jardín grande... y no lo tienes. {i}Todavía.{/i}"

# game/chapters/6_roomexplore.rpy:409
translate Spanish bingus_hub6_9d665288:

    # "You've always liked birds. Having a big aviary would be nice."
    "Siempre te han gustado los pájaros. Tener un gran aviario sería bueno."

# game/chapters/6_roomexplore.rpy:413
translate Spanish bingus_hub6_33bb3961:

    # "What's better than one cat? Two. Or three."
    "¿Qué es mejor que tener un gato? ¡Dos! ¡O tres!"

# game/chapters/6_roomexplore.rpy:417
translate Spanish bingus_hub6_176f6622:

    # "Pets need so much time, effort and love... and money. One pet is plenty for you."
    "Las mascotas requieren mucho tiempo, esfuerzo, cariño... y dinero. Una mascota es suficiente para ti."

# game/chapters/6_roomexplore.rpy:419
translate Spanish bingus_hub6_97641580:

    # "For now, you enjoy [pet_name]'s company immensely. You hope that, Grim Reaper and strange soul notwithstanding, you have many fun times ahead of you together."
    "Por ahora, disfrutas enormemente de la compañía de [pet_name]. Esperas que, a pesar de la Parca y de esa alma extraña, les esperen muchos momentos divertidos juntos."

# game/chapters/6_roomexplore.rpy:425
translate Spanish bingus_hub6_8815343c:

    # "'Why was the Sphynx a great detective?' you ask [pet_name]."
    "'¿Por qué el gato esfinge era tan buen detective?', le preguntas a [pet_name]."

# game/chapters/6_roomexplore.rpy:426
translate Spanish bingus_hub6_4fb3270a:

    # "[pet_name] doesn't reply, but you know [pet_she] can't wait for the punchline."
    "[pet_name] no responde, pero sabes que [pet_she!t] se muere de ganas de escuchar el remate."

# game/chapters/6_roomexplore.rpy:427
translate Spanish bingus_hub6_e63e61e0:

    # "'Because it always uncovered the {i}naked{/i} truth!'"
    "'Porque siempre descubría la verdad {i}al desnudo{/i}.'"

# game/chapters/6_roomexplore.rpy:428
translate Spanish bingus_hub6_954404e2:

    # "'Get it? Because you don't have fur. You're naked.' you continue. [pet_name] doesn't laugh."
    "'¿Lo entiendes? Porque no tienes pelaje. ¡Estás desnud[letra_pet]!', continúas. [pet_name] no se ríe."

# game/chapters/6_roomexplore.rpy:429
translate Spanish bingus_hub6_7b889282:

    # "Well, you thought it was a good joke."
    "Bueno, pensaste que era una buena broma."

# game/chapters/6_roomexplore.rpy:441
translate Spanish bunny_hub6_21a76a54:

    # "[pet_name] seems to be doing well today!"
    "¡[pet_name] parece estar bien hoy!"

# game/chapters/6_roomexplore.rpy:442
translate Spanish bunny_hub6_f1b7a781:

    # "You sit down on the bed next to [pet_her2] and think towards the future..."
    "Te sientas en la cama junto a [pet_her2] y empiezas a pensar en el futuro..."

# game/chapters/6_roomexplore.rpy:443
translate Spanish bunny_hub6_2a45099f:

    # "If you ever manage to afford a house with the market looking like it is, you..."
    "Si alguna vez consigues ahorrar lo suficiente para comprarte una casa, con el mercado tal y como está, tú..."

# game/chapters/6_roomexplore.rpy:448
translate Spanish bunny_hub6_d8b52889:

    # "You've always liked dogs. They appeal to you, but you want one that needs a big yard... and you don't have that. {i}Yet.{/i}"
    "Siempre te han gustado los perros. Te encantan, pero quieres uno que necesite un jardín grande... y no lo tienes. {i}Todavía.{/i}"

# game/chapters/6_roomexplore.rpy:452
translate Spanish bunny_hub6_9d665288:

    # "You've always liked birds. Having a big aviary would be nice."
    "Siempre te han gustado los pájaros. Tener un gran aviario sería bueno."

# game/chapters/6_roomexplore.rpy:456
translate Spanish bunny_hub6_332e4842:

    # "What's better than one bunny? More."
    "¿Qué es mejor que un conejito? Más conejitos."

# game/chapters/6_roomexplore.rpy:460
translate Spanish bunny_hub6_176f6622:

    # "Pets need so much time, effort and love... and money. One pet is plenty for you."
    "Las mascotas requieren mucho tiempo, esfuerzo, cariño... y dinero. Una mascota es suficiente para ti."

# game/chapters/6_roomexplore.rpy:462
translate Spanish bunny_hub6_97641580:

    # "For now, you enjoy [pet_name]'s company immensely. You hope that, Grim Reaper and strange soul notwithstanding, you have many fun times ahead of you together."
    "Por ahora, disfrutas enormemente de la compañía de [pet_name]. Esperas que, a pesar de la Parca y de esa alma extraña, les esperen muchos momentos divertidos juntos."

# game/chapters/6_roomexplore.rpy:467
translate Spanish bunny_hub6_fd8c52c1:

    # "'What do you call a rabbit who wears a fur coat in the summer?' you ask [pet_name]."
    "'¿Cómo llamas a un conejo que lleva un abrigo de piel en verano?', le preguntas a [pet_name]."

# game/chapters/6_roomexplore.rpy:468
translate Spanish bunny_hub6_4fb3270a:

    # "[pet_name] doesn't reply, but you know [pet_she] can't wait for the punchline."
    "[pet_name] no responde, pero sabes que [pet_she!t] se muere de ganas de escuchar el remate."

# game/chapters/6_roomexplore.rpy:469
translate Spanish bunny_hub6_9e204c1d:

    # "'A hot cross bunny!'"
    "'¡Un conejo asado!'"

# game/chapters/6_roomexplore.rpy:470
translate Spanish bunny_hub6_71cc6c4b:

    # "[pet_name] doesn't laugh. That's probably because [pet_name] is a rabbit."
    "[pet_name] no se ríe. Probablemente sea porque [pet_name] es [arti_2_pet] conej[letra_pet]."

# game/chapters/6_roomexplore.rpy:471
translate Spanish bunny_hub6_ed3f7a8a:

    # "You're sure the joke was enjoyed."
    "Tienes la certeza de que disfrutó el chiste."

# game/chapters/6_roomexplore.rpy:483
translate Spanish cat_hub6_21a76a54:

    # "[pet_name] seems to be doing well today!"
    "¡[pet_name] parece estar bien hoy!"

# game/chapters/6_roomexplore.rpy:484
translate Spanish cat_hub6_f1b7a781:

    # "You sit down on the bed next to [pet_her2] and think towards the future..."
    "Te sientas en la cama junto a [pet_her2] y empiezas a pensar en el futuro..."

# game/chapters/6_roomexplore.rpy:485
translate Spanish cat_hub6_2a45099f:

    # "If you ever manage to afford a house with the market looking like it is, you..."
    "Si alguna vez consigues ahorrar lo suficiente para comprarte una casa, con el mercado tal y como está, tú..."

# game/chapters/6_roomexplore.rpy:490
translate Spanish cat_hub6_d8b52889:

    # "You've always liked dogs. They appeal to you, but you want one that needs a big yard... and you don't have that. {i}Yet.{/i}"
    "Siempre te han gustado los perros. Te encantan, pero quieres uno que necesite un jardín grande... y no lo tienes. {i}Todavía.{/i}"

# game/chapters/6_roomexplore.rpy:494
translate Spanish cat_hub6_9d665288:

    # "You've always liked birds. Having a big aviary would be nice."
    "Siempre te han gustado los pájaros. Tener un gran aviario sería bueno."

# game/chapters/6_roomexplore.rpy:498
translate Spanish cat_hub6_33bb3961:

    # "What's better than one cat? Two. Or three."
    "¿Qué es mejor que tener un gato? ¡Dos! ¡O tres!"

# game/chapters/6_roomexplore.rpy:502
translate Spanish cat_hub6_176f6622:

    # "Pets need so much time, effort and love... and money. One pet is plenty for you."
    "Las mascotas requieren mucho tiempo, esfuerzo, cariño... y dinero. Una mascota es suficiente para ti."

# game/chapters/6_roomexplore.rpy:504
translate Spanish cat_hub6_97641580:

    # "For now, you enjoy [pet_name]'s company immensely. You hope that, Grim Reaper and strange soul notwithstanding, you have many fun times ahead of you together."
    "Por ahora, disfrutas enormemente de la compañía de [pet_name]. Esperas que, a pesar de la Parca y de esa alma extraña, les esperen muchos momentos divertidos juntos."

# game/chapters/6_roomexplore.rpy:509
translate Spanish cat_hub6_8991e7a1:

    # "'What's a cat's favorite dessert?' you ask [pet_name]."
    "'¿Cuál es el postre favorito de un gato?' le preguntas a [pet_name]."

# game/chapters/6_roomexplore.rpy:510
translate Spanish cat_hub6_4fb3270a:

    # "[pet_name] doesn't reply, but you know [pet_she] can't wait for the punchline."
    "[pet_name] no responde, pero sabes que [pet_she!t] se muere de ganas de escuchar el remate."

# game/chapters/6_roomexplore.rpy:511
translate Spanish cat_hub6_6e0ad5ce:

    # "'Mice cream!'"
    "'¡Mousse de ratón!'"

# game/chapters/6_roomexplore.rpy:512
translate Spanish cat_hub6_f3552b96:

    # "[pet_name] doesn't laugh. In fact, you think [pet_name] looks to be judging you heavily."
    "[pet_name] no se ríe. De hecho, parece que [pet_name] te está juzgando duramente."

# game/chapters/6_roomexplore.rpy:513
translate Spanish cat_hub6_2536a239:

    # "Well... you enjoyed the joke, at least."
    "Bueno... disfrutaste el chiste, al menos."

# game/chapters/6_roomexplore.rpy:525
translate Spanish dog_hub6_21a76a54:

    # "[pet_name] seems to be doing well today!"
    "¡[pet_name] parece estar bien hoy!"

# game/chapters/6_roomexplore.rpy:526
translate Spanish dog_hub6_f1b7a781:

    # "You sit down on the bed next to [pet_her2] and think towards the future..."
    "Te sientas en la cama junto a [pet_her2] y empiezas a pensar en el futuro..."

# game/chapters/6_roomexplore.rpy:527
translate Spanish dog_hub6_2a45099f:

    # "If you ever manage to afford a house with the market looking like it is, you..."
    "Si alguna vez consigues ahorrar lo suficiente para comprarte una casa, con el mercado tal y como está, tú..."

# game/chapters/6_roomexplore.rpy:532
translate Spanish dog_hub6_aa6976c3:

    # "Is there anything greater in the world than cats? Well, [pet_name] first of all, but you do love cats."
    "¿Hay algo mejor en el mundo que los gatos? Bueno, [pet_name] en primer lugar, pero tú adoras a los gatos."

# game/chapters/6_roomexplore.rpy:536
translate Spanish dog_hub6_9d665288:

    # "You've always liked birds. Having a big aviary would be nice."
    "Siempre te han gustado los pájaros. Tener un gran aviario sería bueno."

# game/chapters/6_roomexplore.rpy:540
translate Spanish dog_hub6_4b6c0ed3:

    # "What's better than one dog? Two, of course!"
    "¿Qué es mejor que un perro? ¡Dos, por supuesto!"

# game/chapters/6_roomexplore.rpy:544
translate Spanish dog_hub6_176f6622:

    # "Pets need so much time, effort and love... and money. One pet is plenty for you."
    "Las mascotas requieren mucho tiempo, esfuerzo, cariño... y dinero. Una mascota es suficiente para ti."

# game/chapters/6_roomexplore.rpy:546
translate Spanish dog_hub6_97641580:

    # "For now, you enjoy [pet_name]'s company immensely. You hope that, Grim Reaper and strange soul notwithstanding, you have many fun times ahead of you together."
    "Por ahora, disfrutas enormemente de la compañía de [pet_name]. Esperas que, a pesar de la Parca y de esa alma extraña, les esperen muchos momentos divertidos juntos."

# game/chapters/6_roomexplore.rpy:551
translate Spanish dog_hub6_f18a88f8:

    # "'What do you call a dog magician?' you ask [pet_name]."
    "'¿Cómo se le llama a un perro mago?', le preguntas a [pet_name]."

# game/chapters/6_roomexplore.rpy:552
translate Spanish dog_hub6_4fb3270a:

    # "[pet_name] doesn't reply, but you know [pet_she] can't wait for the punchline."
    "[pet_name] no responde, pero sabes que [pet_she!t] se muere de ganas de escuchar el remate."

# game/chapters/6_roomexplore.rpy:553
translate Spanish dog_hub6_27dbb87b:

    # "'A labracadabrador!'"
    "'¡Labracadabrador!'"

# game/chapters/6_roomexplore.rpy:554
translate Spanish dog_hub6_85bd48ac:

    # "[pet_name] doesn't laugh, but that's probably because [pet_she]'s a dog."
    "[pet_name] no se ríe, pero probablemente sea porque [pet_she!t] es [arti_2_pet] perr[letra_pet]."

# game/chapters/6_roomexplore.rpy:555
translate Spanish dog_hub6_628a0467:

    # "The joke was definitely appreciated."
    "Sin duda, el chiste fue todo un éxito."

# game/chapters/6_roomexplore.rpy:567
translate Spanish hamster_hub6_21a76a54:

    # "[pet_name] seems to be doing well today!"
    "¡[pet_name] parece estar bien hoy!"

# game/chapters/6_roomexplore.rpy:568
translate Spanish hamster_hub6_f1b7a781:

    # "You sit down on the bed next to [pet_her2] and think towards the future..."
    "Te sientas en la cama junto a [pet_her2] y empiezas a pensar en el futuro..."

# game/chapters/6_roomexplore.rpy:569
translate Spanish hamster_hub6_2a45099f:

    # "If you ever manage to afford a house with the market looking like it is, you..."
    "Si alguna vez consigues ahorrar lo suficiente para comprarte una casa, con el mercado tal y como está, tú..."

# game/chapters/6_roomexplore.rpy:574
translate Spanish hamster_hub6_aa6976c3:

    # "Is there anything greater in the world than cats? Well, [pet_name] first of all, but you do love cats."
    "¿Hay algo mejor en el mundo que los gatos? Bueno, [pet_name] en primer lugar, pero tú adoras a los gatos."

# game/chapters/6_roomexplore.rpy:578
translate Spanish hamster_hub6_9d665288:

    # "You've always liked birds. Having a big aviary would be nice."
    "Siempre te han gustado los pájaros. Tener un gran aviario sería bueno."

# game/chapters/6_roomexplore.rpy:582
translate Spanish hamster_hub6_7573068b:

    # "You don't have the room for extra enclosures at the moment... but one day!"
    "No tienes el espacio para recintos adicionales en este momento... ¡pero algún día!"

# game/chapters/6_roomexplore.rpy:586
translate Spanish hamster_hub6_176f6622:

    # "Pets need so much time, effort and love... and money. One pet is plenty for you."
    "Las mascotas requieren mucho tiempo, esfuerzo, cariño... y dinero. Una mascota es suficiente para ti."

# game/chapters/6_roomexplore.rpy:588
translate Spanish hamster_hub6_97641580:

    # "For now, you enjoy [pet_name]'s company immensely. You hope that, Grim Reaper and strange soul notwithstanding, you have many fun times ahead of you together."
    "Por ahora, disfrutas enormemente de la compañía de [pet_name]. Esperas que, a pesar de la Parca y de esa alma extraña, les esperen muchos momentos divertidos juntos."

# game/chapters/6_roomexplore.rpy:593
translate Spanish hamster_hub6_19a09656:

    # "'What's a hamster's favorite game show?' you ask [pet_name]."
    "'¿Cuál es el programa de juegos favorito de los hámsters?' preguntas a [pet_name]."

# game/chapters/6_roomexplore.rpy:594
translate Spanish hamster_hub6_4fb3270a:

    # "[pet_name] doesn't reply, but you know [pet_she] can't wait for the punchline."
    "[pet_name] no responde, pero sabes que [pet_she!t] se muere de ganas de escuchar el remate."

# game/chapters/6_roomexplore.rpy:595
translate Spanish hamster_hub6_71a32cab:

    # "'Wheel of Fortune!'"
    "'¡Rueda de la fortuna!'"

# game/chapters/6_roomexplore.rpy:596
translate Spanish hamster_hub6_987152b4:

    # "'Get it?' you continue, 'because you love your wheel so much!'"
    "'¿Lo entiendes?', continúas, '¡porque te encanta tu rueda!'"

# game/chapters/6_roomexplore.rpy:597
translate Spanish hamster_hub6_8f27007f:

    # "[pet_name] doesn't laugh, but that's probably because [pet_she]'s a hamster."
    "[pet_name] no se ríe, pero eso probablemente sea porque [pet_she!t] es [arti_2_pet] hámster."

# game/chapters/6_roomexplore.rpy:598
translate Spanish hamster_hub6_628a0467:

    # "The joke was definitely appreciated."
    "Sin duda, el chiste fue todo un éxito."

# game/chapters/6_roomexplore.rpy:617
translate Spanish plant_hub6_c1229c6a:

    # "You give your little sprout a big drink of water."
    "Le das a tu pequeño retoño un buen trago de agua."

# game/chapters/6_roomexplore.rpy:618
translate Spanish plant_hub6_c5de961c:

    # "Though you don't speak sprout, it seems to say thank you."
    "Aunque no hablas el idioma de los retoños, parece darte las gracias."

# game/chapters/6_roomexplore.rpy:620
translate Spanish plant_hub6_518e64fd:

    # "Your little sprout has grown some leaves!"
    "¡A tu pequeño retoño le han salido hojas!"

# game/chapters/6_roomexplore.rpy:621
translate Spanish plant_hub6_8036dce1:

    # "You can't help but feel proud as you give it a big drink of water."
    "No puedes evitar sentir orgullo mientras le das un buen trago de agua."

# game/chapters/6_roomexplore.rpy:623
translate Spanish plant_hub6_adaac543:

    # "Even more leaves have appeared now!"
    "¡Ahora han aparecido aún más hojas!"

# game/chapters/6_roomexplore.rpy:624
translate Spanish plant_hub6_a4970463:

    # "You water it generously and feel excited that, this time, you didn't kill your plant instantly."
    "La riegas abundantemente y te emociona comprobar que esta vez no has matado tu planta nada más empezar."

# game/chapters/6_roomexplore.rpy:626
translate Spanish plant_hub6_2087a70f:

    # "Your little plant is growing healthily!"
    "¡Tu pequeña planta está creciendo sana!"

# game/chapters/6_roomexplore.rpy:627
translate Spanish plant_hub6_80d209cf:

    # "You give it a big drink of water, excited about its growth."
    "Le das un buen trago de agua, con entusiasmo por su crecimiento."

# game/chapters/6_roomexplore.rpy:629
translate Spanish plant_hub6_41affa3b:

    # "Your little plant has sprouted some buds!"
    "¡Tu pequeña planta ha echado algunos capullos!"

# game/chapters/6_roomexplore.rpy:630
translate Spanish plant_hub6_75fbf720:

    # "You almost tear up when you notice them. They're so cute - you can't wait to see what the flowers will look like."
    "Casi se te saltan las lágrimas al verlos. ¡Son tan adorables! No puedes esperar a descubrir cómo serán las flores."

# game/chapters/6_roomexplore.rpy:632
translate Spanish plant_hub6_33ab5804:

    # "The buds on your little plant seem to be doing well!"
    "¡Los capullos de tu pequeña planta parecen estar muy bien!"

# game/chapters/6_roomexplore.rpy:633
translate Spanish plant_hub6_19058b26:

    # "You can't believe how healthy it is..."
    "No puedes creer lo saludable que está..."

# game/chapters/6_roomexplore.rpy:648
translate Spanish plant_hub6_03e35dbb:

    # "One seems like an unlucky number to you."
    "El número uno te parece de mala suerte."

# game/chapters/6_roomexplore.rpy:649
translate Spanish plant_hub6_4a128500:

    # "Better to water it twice, right?"
    "Es mejor regarla dos veces, ¿no?"

# game/chapters/6_roomexplore.rpy:663
translate Spanish plant_hub6_b3a702e0:

    # "You know what number is better than two?"
    "¿Sabes qué número es mejor que el dos?"

# game/chapters/6_roomexplore.rpy:664
translate Spanish plant_hub6_d698ea09:

    # "Three!"
    "¡Tres!"

# game/chapters/6_roomexplore.rpy:665
translate Spanish plant_hub6_712e11cc:

    # "You empty your watering can into the plant, but it's not enough."
    "Viertes el contenido de la regadera sobre la planta, pero no es suficiente."

# game/chapters/6_roomexplore.rpy:666
translate Spanish plant_hub6_7c9c787c:

    # "You go fill it a second time. Then a third time."
    "Vas a llenarla una segunda vez. Luego, una tercera."

# game/chapters/6_roomexplore.rpy:667
translate Spanish plant_hub6_a756208f:

    # "You're drowning this plant, and yet you keep going."
    "Estás ahogando a la planta, pero aun así sigues regándola."

# game/chapters/6_roomexplore.rpy:668
translate Spanish plant_hub6_d140d894:

    # "You don't follow the rules. The rules follow you."
    "Tú no sigues las reglas. Las reglas te siguen a ti."

translate Spanish strings:

    # game/chapters/6_roomexplore.rpy:223
    old "1. Your teacher in middle school."
    new "1. Tu docente de la secundaria."

    # game/chapters/6_roomexplore.rpy:226
    old "2. Your crush when you were ten."
    new "2. Tu amor platónico cuando tenías diez años."

    # game/chapters/6_roomexplore.rpy:229
    old "3. Your childhood best friend."
    new "3. Tu mejor amistad de la infancia."

    # game/chapters/6_roomexplore.rpy:232
    old "3. A family member."
    new "3. Un miembro de la familia."

    # game/chapters/6_roomexplore.rpy:360
    old "1. Would love to get a dog!"
    new "1. ¡Te encantaría tener un perro!"

    # game/chapters/6_roomexplore.rpy:364
    old "2. Would love a cat. Or two cats. Or three?"
    new "2. Te encantaría tener un gato. ¿O dos? ¿O tres?"

    # game/chapters/6_roomexplore.rpy:368
    old "3. Would like another snake."
    new "3. Te gustaría tener otra serpiente."

    # game/chapters/6_roomexplore.rpy:372
    old "4. Probably don't want any more pets."
    new "4. Probablemente no quieras más mascotas."

    # game/chapters/6_roomexplore.rpy:380
    old "Tell [pet_name] a joke."
    new "Contarle un chiste a [pet_name]."

    # game/chapters/6_roomexplore.rpy:407
    old "2. A bird would be nice."
    new "2. Un ave estaría bien."

    # game/chapters/6_roomexplore.rpy:411
    old "3. Would like another cat!"
    new "3. ¡Te gustaría tener otro gato!"

    # game/chapters/6_roomexplore.rpy:454
    old "3. More bunnies!"
    new "3. ¡Más conejitos!"

    # game/chapters/6_roomexplore.rpy:496
    old "3. You want more cats!"
    new "3. ¡Quieres más gatos!"

    # game/chapters/6_roomexplore.rpy:530
    old "1. Would love to get a cat!"
    new "1. ¡Te encantaría tener un gato!"

    # game/chapters/6_roomexplore.rpy:538
    old "3. You want more dogs!"
    new "3. ¡Quieres más perros!"

    # game/chapters/6_roomexplore.rpy:580
    old "3. You want more hamsters!"
    new "3. ¡Quieres más hámsters!"

    # game/chapters/6_roomexplore.rpy:691
    old "{i}Diary #2{/i}"
    new "{i}Diario #2{/i}"

    # game/chapters/6_roomexplore.rpy:709
    old "today i found a HUGE bug."
    new "hoy encontré un BICHO ENORME."

    # game/chapters/6_roomexplore.rpy:710
    old "it was so cool it had wings and legs but no arms."
    new "era genialísimo: ¡tenía alas y patas, pero no brazos!"

    # game/chapters/6_roomexplore.rpy:711
    old "or maybe they were all arms and it had no legs."
    new "o tal vez todas eran brazos y no tenía patas."

    # game/chapters/6_roomexplore.rpy:712
    old "IDK."
    new "Yo... no lo sé."

    # game/chapters/6_roomexplore.rpy:713
    old "what i DO know, is that it was the best thing i've ever seen in my entire life!"
    new "¡lo que SÍ sé es que fue lo mejor que he visto en toda mi vida!"

    # game/chapters/6_roomexplore.rpy:714
    old "anywayz."
    new "en fin."

    # game/chapters/6_roomexplore.rpy:715
    old "something wicked cool happened at school."
    new "pasó algo súper genial en la escuela."

    # game/chapters/6_roomexplore.rpy:716
    old "i was climbing this tree (we call it 'the' tree btw but i don't think thats its actual name but IDK i haven't asked), and i was REALLY high up."
    new "estaba trepando a un árbol (lo llamamos 'el' árbol, aunque creo que ese no es su nombre real, pero no lo sé, nunca he preguntado), y estaba MUY arriba."

    # game/chapters/6_roomexplore.rpy:717
    old "AND I FELL!!!"
    new "¡¡¡Y ME CAÍ!!!"

    # game/chapters/6_roomexplore.rpy:718
    old "i fell so far i thought was was going to DIE and i got in sooo much trouble ROFLMAO."
    new "¡caí desde tan alto que pensé que iba a MORIR y me metí en un montón de problemas! JAJAJAJA."

    # game/chapters/6_roomexplore.rpy:719
    old "the teachers kept saying i could have broken my leg or my back or something and i was lucky i just got a scratch."
    new "los profes no dejaban de decir que podría haberme roto una pierna, la espalda o algo así, y que tuve suerte de que solo me hiciera un rasguño."

    # game/chapters/6_roomexplore.rpy:720
    old "what my teachers dont know is that i am totally {s}enda{/s} {s}inde{/s} indestructable!!! nothing can kill me!!!!!!"
    new "lo que mis profes no saben es que soy totalmente {s}inda{/s} {s}estra{/s} ¡¡¡¡indestructible!!!! ¡¡¡¡¡nada puede matarme!!!!!"

    # game/chapters/6_roomexplore.rpy:721
    old "anywayz thats all thats been happening."
    new "en fin, eso es todo lo que ha pasado."

    # game/chapters/6_roomexplore.rpy:722
    old "i gotta go play now."
    new "ahora tengo que ir a jugar."

    # game/chapters/6_roomexplore.rpy:723
    old "BAIIII"
    new "CHAAAAO"

