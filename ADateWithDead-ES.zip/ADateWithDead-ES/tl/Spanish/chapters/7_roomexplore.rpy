# TODO: Translation updated at 2026-10-15 18:36

# game/chapters/7_roomexplore.rpy:214
translate Spanish bed_hub7_9ba07fd9:

    # "The dawn of the final day... or something." id bed_hub7_9ba07fd9
    "Amanece el último día... o algo así." id bed_hub7_9ba07fd9

# game/chapters/7_roomexplore.rpy:215
translate Spanish bed_hub7_f3ecab0e:

    # "You don't particularly feel like you're going to die today." id bed_hub7_f3ecab0e
    "No tienes precisamente la sensación de que vayas a morir hoy." id bed_hub7_f3ecab0e

# game/chapters/7_roomexplore.rpy:216
translate Spanish bed_hub7_9a72db9b:

    # "Something about the Grim Reaper you've come to know feels too... soft for things to end like that." id bed_hub7_9a72db9b
    "Hay algo en la Parca que has llegado a conocer que se siente demasiado... blanda de corazón como para que todo termine así." id bed_hub7_9a72db9b

# game/chapters/7_roomexplore.rpy:217
translate Spanish bed_hub7_627e6eb5:

    # "Perhaps you can celebrate your win early?" id bed_hub7_627e6eb5
    "¿Quizás puedas celebrar tu victoria antes de tiempo?" id bed_hub7_627e6eb5

# game/chapters/7_roomexplore.rpy:218
translate Spanish bed_hub7_4936c776:

    # "You could..." id bed_hub7_4936c776
    "Podrías..." id bed_hub7_4936c776

# game/chapters/7_roomexplore.rpy:223
translate Spanish bed_hub7_637c89f0:

    # "Yes! A whole party just to celebrate living." id bed_hub7_637c89f0
    "¡Sí! ¡Una fiesta en toda regla para celebrar que sigues viv[letra]!" id bed_hub7_637c89f0

# game/chapters/7_roomexplore.rpy:226
translate Spanish bed_hub7_23e32432:

    # "Everyone needs a little treat sometimes, right?" id bed_hub7_23e32432
    "Todo el mundo necesita darse un capricho de vez en cuando, ¿no?" id bed_hub7_23e32432

# game/chapters/7_roomexplore.rpy:229
translate Spanish bed_hub7_6eea3c32:

    # "Maybe even two. Who's going to stop you?" id bed_hub7_6eea3c32
    "Quizás incluso dos. ¿Quién te lo va a impedir?" id bed_hub7_6eea3c32

# game/chapters/7_roomexplore.rpy:232
translate Spanish bed_hub7_af372622:

    # "You might even invite your little reaper friend." id bed_hub7_af372622
    "Incluso podrías invitar a tu amiga parquita." id bed_hub7_af372622

# game/chapters/7_roomexplore.rpy:235
translate Spanish bed_hub7_e0bc646e:

    # "But for now, you decide not to celebrate too early - there'll be plenty of time for that in the future." id bed_hub7_e0bc646e
    "Pero, por ahora, decides no adelantarte a los acontecimientos: ya habrá tiempo de sobra para celebrar más adelante." id bed_hub7_e0bc646e

# game/chapters/7_roomexplore.rpy:246
translate Spanish door_hub7_b878add3:

    # "You hear something in the hallway beyond." id door_hub7_b878add3
    "Oyes algo en el pasillo, al otro lado de la puerta." id door_hub7_b878add3

# game/chapters/7_roomexplore.rpy:253
translate Spanish door_hub7_c977c122:

    # "You hear a door open, and feet moving against a wooden floor." id door_hub7_c977c122
    "Oyes cómo se abre una puerta y unos pasos sobre un piso de madera." id door_hub7_c977c122

# game/chapters/7_roomexplore.rpy:254
translate Spanish door_hub7_3f9c3447:

    # "Two people - your neighbors?" id door_hub7_3f9c3447
    "Dos personas... ¿tus vecinos?" id door_hub7_3f9c3447

# game/chapters/7_roomexplore.rpy:255
translate Spanish door_hub7_2fef7956:

    # "Your breath grows silent as you listen carefully." id door_hub7_2fef7956
    "Contienes la respiración mientras escuchas con atención." id door_hub7_2fef7956

# game/chapters/7_roomexplore.rpy:256
translate Spanish door_hub7_b1cfc305:

    # "'You came' the light voice starts after a few moment of quiet." id door_hub7_b1cfc305
    "'Has venido', dice la voz suave tras unos instantes de silencio." id door_hub7_b1cfc305

# game/chapters/7_roomexplore.rpy:257
translate Spanish door_hub7_305da658:

    # "'Of course I did. You invited me' the deeper voice answers." id door_hub7_305da658
    "'Por supuesto que vine. Tú me invitaste', responde la voz más grave." id door_hub7_305da658

# game/chapters/7_roomexplore.rpy:258
translate Spanish door_hub7_13874df2:

    # "'I'm... sorry for running away like that. It was immature of me...'" id door_hub7_13874df2
    "'Lo... siento por haber salido huyendo así. Fue una actitud inmadura de mi parte...'" id door_hub7_13874df2

# game/chapters/7_roomexplore.rpy:259
translate Spanish door_hub7_be025594:

    # "Then quiet again." id door_hub7_be025594
    "Luego, vuelve el silencio." id door_hub7_be025594

# game/chapters/7_roomexplore.rpy:260
translate Spanish door_hub7_79f60596:

    # "You imagine both people are struggling for words - the right words." id door_hub7_79f60596
    "Imaginas que ambos están buscando las palabras adecuadas." id door_hub7_79f60596

# game/chapters/7_roomexplore.rpy:261
translate Spanish door_hub7_c532361c:

    # "The lighter voice speaks up again."
    "La voz suave vuelve a hablar."

# game/chapters/7_roomexplore.rpy:262
translate Spanish door_hub7_c22c4449:

    # "'Why do you always seem so sad when you look at me?'"
    "'¿Por qué siempre pareces tan triste cuando me miras?'"

# game/chapters/7_roomexplore.rpy:263
translate Spanish door_hub7_7d572ef2:

    # "It was a question neither of them likely expected to be asked."
    "Era una pregunta que probablemente ninguno de los dos esperaba que le hicieran."

# game/chapters/7_roomexplore.rpy:264
translate Spanish door_hub7_27f88332:

    # "'Because...'"
    "'Porque...'"

# game/chapters/7_roomexplore.rpy:265
translate Spanish door_hub7_c293808e:

    # "'I've lost you so many times... and I'm waiting to lose you again.'"
    "'Te he perdido tantas veces... y siento que estoy esperando el momento de volver a perderte.'"

# game/chapters/7_roomexplore.rpy:266
translate Spanish door_hub7_3ea5df15:

    # "Quiet. So quiet you could hear a pin drop."
    "Silencio. Un silencio tan profundo que se podía oír caer un alfiler."

# game/chapters/7_roomexplore.rpy:267
translate Spanish door_hub7_b7e61d5e:

    # "Time flowed onwards through this quiet, winding its way between the pair."
    "El tiempo seguía avanzando en medio de aquel silencio, abriéndose paso entre ambos."

# game/chapters/7_roomexplore.rpy:268
translate Spanish door_hub7_7f779b55:

    # "'What... do you mean?'"
    "'¿Qué... quieres decir?'"

# game/chapters/7_roomexplore.rpy:269
translate Spanish door_hub7_5ec0c6e4:

    # "A laugh - but not a humorous one. A self-mocking one."
    "Una risa, pero no de diversión. Más bien, una risa cargada de autodesprecio."

# game/chapters/7_roomexplore.rpy:270
translate Spanish door_hub7_891a4758:

    # "'You might not believe me, but hear me out anyway, okay?'"
    "'Puede que no me creas, pero escúchame de todos modos, ¿okey?'"

# game/chapters/7_roomexplore.rpy:271
translate Spanish door_hub7_1b6f822f:

    # "'...We didn't meet by chance,' they start."
    "'...No nos conocimos por casualidad', comienza a explicar."

# game/chapters/7_roomexplore.rpy:272
translate Spanish door_hub7_2640037a:

    # "'I was sent here to meet you. Like I've met you dozens of times in the past.'"
    "'Me enviaron aquí para conocerte. Igual que te he conocido docenas de veces en el pasado.'"

# game/chapters/7_roomexplore.rpy:273
translate Spanish door_hub7_a3e3f842:

    # "'Sent here? Why?' there's genuine confusion in their voice. They don't sound scared, just... confused."
    "'¿Te enviaron aquí? ¿Por qué?', hay verdadera confusión en su voz. No suena a miedo, solo a... confusión."

# game/chapters/7_roomexplore.rpy:274
translate Spanish door_hub7_10476352:

    # "'I was sent here to take your soul, because I am... a Grim Reaper.'"
    "'Me enviaron aquí para llevarme tu alma, porque soy... una Parca.'"

# game/chapters/7_roomexplore.rpy:275
translate Spanish door_hub7_31b92461:

    # "The silence this time is so loud you almost have to cover your ears."
    "El silencio esta vez es tan ensordecedor que casi tienes que taparte los oídos."

# game/chapters/7_roomexplore.rpy:276
translate Spanish door_hub7_244c5c89:

    # "Tension hangs in the air."
    "La tensión flota en el aire."

# game/chapters/7_roomexplore.rpy:277
translate Spanish door_hub7_177b2ea2:

    # "'You and I met a long time ago, in a different lifetime, and I... refused to take your soul then.'"
    "'Nos conocimos hace mucho tiempo, en otra vida, y yo... me negué a llevarme tu alma.'"

# game/chapters/7_roomexplore.rpy:278
translate Spanish door_hub7_85e8a3aa:

    # "'Ever since, in every lifetime, I have... been sent to you as punishment.'"
    "'Desde entonces, en cada vida, me han enviado a ti como castigo.'"

# game/chapters/7_roomexplore.rpy:279
translate Spanish door_hub7_cea3b071:

    # "'And in every lifetime, I've loved you.'"
    "'Y en cada vida, te he amado.'"

# game/chapters/7_roomexplore.rpy:280
translate Spanish door_hub7_5595cf1f:

    # "'You...' the light voice cracks, 'are you... telling the truth?'"
    "'Tú...', dice la voz suave, quebrándose, '¿estás... diciendo la verdad?'"

# game/chapters/7_roomexplore.rpy:281
translate Spanish door_hub7_14f1f0a2:

    # "The sound of movement. You can see it in your mind, as they touch hands."
    "Se oye un movimiento. Puedes imaginártelo: están juntando sus manos."

# game/chapters/7_roomexplore.rpy:282
translate Spanish door_hub7_f28d905e:

    # "'I wouldn't lie to you. Feel my warmth, hear my heartbeat... have I ever felt familiar to you?'"
    "'No te mentiría. Siente mi calor, escucha los latidos de mi corazón... ¿Alguna vez te he resultado familiar?'"

# game/chapters/7_roomexplore.rpy:283
translate Spanish door_hub7_9cf1c6da:

    # "The rustling of cloth. A hand over a heart."
    "El susurro de la tela. Una mano sobre el corazón."

# game/chapters/7_roomexplore.rpy:284
translate Spanish door_hub7_91a1bda9:

    # "'...I've felt nostalgic ever since we met.' the light voice whispers."
    "'...Desde que nos conocimos, he sentido una extraña nostalgia', susurra la voz suave."

# game/chapters/7_roomexplore.rpy:285
translate Spanish door_hub7_209be59a:

    # "A deep voice continues."
    "Una voz grave continúa."

# game/chapters/7_roomexplore.rpy:286
translate Spanish door_hub7_2d20177b:

    # "'I didn't want to hurt you. I still don't. I want to keep you safe. The best way to keep you safe is... if I'm far away from you.'"
    "'No quería hacerte daño. Sigo sin quererlo. Quiero mantenerte a salvo. La mejor manera de mantenerte a salvo es... estar lejos de ti.'"

# game/chapters/7_roomexplore.rpy:287
translate Spanish door_hub7_93697ebb:

    # "'What would happen to you?'"
    "'¿Qué te pasaría?'"

# game/chapters/7_roomexplore.rpy:288
translate Spanish door_hub7_348f8bf2:

    # "'...You don't need to worry about me.'"
    "'...No tienes que preocuparte por mí.'"

# game/chapters/7_roomexplore.rpy:289
translate Spanish door_hub7_58d93d36:

    # "'...Why don't we run away together?'"
    "'...¿Por qué no huimos juntos?'"

# game/chapters/7_roomexplore.rpy:290
translate Spanish door_hub7_f33086e8:

    # "'What?'"
    "'¿Qué?'"

# game/chapters/7_roomexplore.rpy:291
translate Spanish door_hub7_b7177f5a:

    # "There's genuine confusion in them. Their voice, which is usually so low and cool, picks up."
    "Se nota su desconcierto. Su voz, que normalmente es tan grave y serena, adquiere un tono más elevado."

# game/chapters/7_roomexplore.rpy:292
translate Spanish door_hub7_f89081b9:

    # "'I think I've been dreaming about you. For years. I don't want to lose you just when I've found you.' the airy voice adds."
    "'Creo que he estado soñando contigo. Durante años. No quiero perderte justo ahora que por fin te he encontrado', añade la voz suave."

# game/chapters/7_roomexplore.rpy:293
translate Spanish door_hub7_6fcfe9d1:

    # "'Are you... serious?' the deep voice responds, filled with surprise."
    "'¿Hablas... en serio?', responde la voz grave, llena de sorpresa."

# game/chapters/7_roomexplore.rpy:294
translate Spanish door_hub7_9dccc1fc:

    # "'I am.' the lighter voice repeats, a note of determination weaving through their words. "
    "'Hablo en serio', repite la voz suave, dejando entrever una firme determinación."

# game/chapters/7_roomexplore.rpy:295
translate Spanish door_hub7_dda321bb:

    # "'Stay with me.'"
    "'Quédate conmigo.'"

# game/chapters/7_roomexplore.rpy:296
translate Spanish door_hub7_245827d4:

    # "The deep voice, once calm and composed, now carries a trace of vulnerability. 'I never thought... I never imagined you'd want me to stay.'"
    "La voz grave, antes tranquila y serena, ahora deja entrever cierta vulnerabilidad. 'Nunca pensé... Nunca imaginé que quisieras que me quedara'."

# game/chapters/7_roomexplore.rpy:297
translate Spanish door_hub7_5a6a5c42:

    # "You can feel it even from here - a fragile hope. A possibility."
    "Puedes sentirlo incluso desde aquí: una esperanza frágil. Una posibilidad."

# game/chapters/7_roomexplore.rpy:298
translate Spanish door_hub7_08439034:

    # "A pause - a suspended moment in which the weight of a thousand lifetimes seems to hang in the balance."
    "Una pausa... un instante suspendido en el que parece estar en juego el destino de mil vidas."

# game/chapters/7_roomexplore.rpy:299
translate Spanish door_hub7_21adce2d:

    # "And then, the deep voice responds, 'If you'd have me, I'd stay by your side forever.'"
    "Y entonces, la voz grave responde: 'Si me quieres a tu lado, me quedaré contigo para siempre'."

# game/chapters/7_roomexplore.rpy:300
translate Spanish door_hub7_6998a72a:

    # "You hear footsteps, then a door closing."
    "Oyes pasos y luego una puerta que se cierra."

# game/chapters/7_roomexplore.rpy:301
translate Spanish door_hub7_8fba9551:

    # "And then, silence."
    "Y luego, silencio."

# game/chapters/7_roomexplore.rpy:302
translate Spanish door_hub7_f1c7d38a:

    # "The mystery of your neighbors seems to come to a close, and you step back from the door filled with wonder and confusion."
    "El misterio de tus vecinos parece llegar a su fin, y te apartas de la puerta, llen[letra] de asombro y confusión."

# game/chapters/7_roomexplore.rpy:303
translate Spanish door_hub7_accad361:

    # "Two people in the very same apartment with their own Grim Reapers? What are the chances?"
    "¿Dos personas en el mismo edificio con su propia Parca? ¿Qué probabilidades hay?"

# game/chapters/7_roomexplore.rpy:304
translate Spanish door_hub7_3b1344a0:

    # "One in a million, you assume."
    "Una entre un millón, supones."

# game/chapters/7_roomexplore.rpy:305
translate Spanish door_hub7_fc572854:

    # "Though you're the only person, probably, in the entire world who would believe what just happened, you can't help but feel happy."
    "Aunque probablemente seas la única persona en todo el mundo que creería lo que acaba de suceder, no puedes evitar sentirte feliz."

# game/chapters/7_roomexplore.rpy:306
translate Spanish door_hub7_58f362e7:

    # "Love is an infectious thing."
    "El amor es algo contagioso."

# game/chapters/7_roomexplore.rpy:307
translate Spanish door_hub7_4752e78e:

    # "You pray for a moment that the two, whoever they are, whatever they look like, have a happy future ahead of them."
    "Por un momento, deseas de corazón que esos dos, sean quienes sean y tengan el aspecto que tengan, disfruten de un futuro feliz."

# game/chapters/7_roomexplore.rpy:312
translate Spanish door_hub7_05d20ce8:

    # "And you think about your own Grim Reaper... the one who has captured your heart, as well."
    "Y piensas en tu propia Parca... la que también ha capturado tu corazón."

# game/chapters/7_roomexplore.rpy:329
translate Spanish door_hub7_c977c122_1:

    # "You hear a door open, and feet moving against a wooden floor."
    "Oyes cómo se abre una puerta y unos pasos sobre un piso de madera."

# game/chapters/7_roomexplore.rpy:330
translate Spanish door_hub7_3f9c3447_1:

    # "Two people - your neighbors?"
    "Dos personas... ¿tus vecinos?"

# game/chapters/7_roomexplore.rpy:331
translate Spanish door_hub7_2fef7956_1:

    # "Your breath grows silent as you listen carefully."
    "Contienes la respiración mientras escuchas con atención."

# game/chapters/7_roomexplore.rpy:332
translate Spanish door_hub7_b1cfc305_1:

    # "'You came' the light voice starts after a few moment of quiet."
    "'Has venido', dice la voz suave tras unos instantes de silencio."

# game/chapters/7_roomexplore.rpy:333
translate Spanish door_hub7_305da658_1:

    # "'Of course I did. You invited me' the deeper voice answers."
    "'Por supuesto que vine. Tú me invitaste', responde la voz más grave."

# game/chapters/7_roomexplore.rpy:334
translate Spanish door_hub7_13874df2_1:

    # "'I'm... sorry for running away like that. It was immature of me...'"
    "'Lo... siento por haber salido huyendo así. Fue una actitud inmadura de mi parte...'"

# game/chapters/7_roomexplore.rpy:335
translate Spanish door_hub7_be025594_1:

    # "Then quiet again."
    "Luego, vuelve el silencio."

# game/chapters/7_roomexplore.rpy:336
translate Spanish door_hub7_79f60596_1:

    # "You imagine both people are struggling for words - the right words."
    "Imaginas que ambos están buscando las palabras adecuadas."

# game/chapters/7_roomexplore.rpy:337
translate Spanish door_hub7_c532361c_1:

    # "The lighter voice speaks up again."
    "La voz suave vuelve a hablar."

# game/chapters/7_roomexplore.rpy:338
translate Spanish door_hub7_c22c4449_1:

    # "'Why do you always seem so sad when you look at me?'"
    "'¿Por qué siempre pareces tan triste cuando me miras?'"

# game/chapters/7_roomexplore.rpy:339
translate Spanish door_hub7_7d572ef2_1:

    # "It was a question neither of them likely expected to be asked."
    "Era una pregunta que probablemente ninguno de los dos esperaba que le hicieran."

# game/chapters/7_roomexplore.rpy:340
translate Spanish door_hub7_27f88332_1:

    # "'Because...'"
    "'Porque...'"

# game/chapters/7_roomexplore.rpy:341
translate Spanish door_hub7_c293808e_1:

    # "'I've lost you so many times... and I'm waiting to lose you again.'"
    "'Te he perdido tantas veces... y siento que estoy esperando el momento de volver a perderte.'"

# game/chapters/7_roomexplore.rpy:342
translate Spanish door_hub7_3ea5df15_1:

    # "Quiet. So quiet you could hear a pin drop."
    "Silencio. Un silencio tan profundo que se podía oír caer un alfiler."

# game/chapters/7_roomexplore.rpy:343
translate Spanish door_hub7_b7e61d5e_1:

    # "Time flowed onwards through this quiet, winding its way between the pair."
    "El tiempo seguía avanzando en medio de aquel silencio, abriéndose paso entre ambos."

# game/chapters/7_roomexplore.rpy:344
translate Spanish door_hub7_7f779b55_1:

    # "'What... do you mean?'"
    "'¿Qué... quieres decir?'"

# game/chapters/7_roomexplore.rpy:345
translate Spanish door_hub7_5ec0c6e4_1:

    # "A laugh - but not a humorous one. A self-mocking one."
    "Una risa, pero no de diversión. Más bien, una risa cargada de autodesprecio."

# game/chapters/7_roomexplore.rpy:346
translate Spanish door_hub7_891a4758_1:

    # "'You might not believe me, but hear me out anyway, okay?'"
    "'Puede que no me creas, pero escúchame de todos modos, ¿okey?'"

# game/chapters/7_roomexplore.rpy:347
translate Spanish door_hub7_1b6f822f_1:

    # "'...We didn't meet by chance,' they start."
    "'...No nos conocimos por casualidad', comienza a explicar."

# game/chapters/7_roomexplore.rpy:348
translate Spanish door_hub7_2640037a_1:

    # "'I was sent here to meet you. Like I've met you dozens of times in the past.'"
    "'Me enviaron aquí para conocerte. Igual que te he conocido docenas de veces en el pasado.'"

# game/chapters/7_roomexplore.rpy:349
translate Spanish door_hub7_a3e3f842_1:

    # "'Sent here? Why?' there's genuine confusion in their voice. They don't sound scared, just... confused."
    "'¿Te enviaron aquí? ¿Por qué?', hay verdadera confusión en su voz. No suena a miedo, solo a... confusión."

# game/chapters/7_roomexplore.rpy:350
translate Spanish door_hub7_10476352_1:

    # "'I was sent here to take your soul, because I am... a Grim Reaper.'"
    "'Me enviaron aquí para llevarme tu alma, porque soy... una Parca.'"

# game/chapters/7_roomexplore.rpy:351
translate Spanish door_hub7_31b92461_1:

    # "The silence this time is so loud you almost have to cover your ears."
    "El silencio esta vez es tan ensordecedor que casi tienes que taparte los oídos."

# game/chapters/7_roomexplore.rpy:352
translate Spanish door_hub7_244c5c89_1:

    # "Tension hangs in the air."
    "La tensión flota en el aire."

# game/chapters/7_roomexplore.rpy:353
translate Spanish door_hub7_177b2ea2_1:

    # "'You and I met a long time ago, in a different lifetime, and I... refused to take your soul then.'"
    "'Nos conocimos hace mucho tiempo, en otra vida, y yo... me negué a llevarme tu alma.'"

# game/chapters/7_roomexplore.rpy:354
translate Spanish door_hub7_85e8a3aa_1:

    # "'Ever since, in every lifetime, I have... been sent to you as punishment.'"
    "'Desde entonces, en cada vida, me han enviado a ti como castigo.'"

# game/chapters/7_roomexplore.rpy:355
translate Spanish door_hub7_cea3b071_1:

    # "'And in every lifetime, I've loved you.'"
    "'Y en cada vida, te he amado.'"

# game/chapters/7_roomexplore.rpy:356
translate Spanish door_hub7_5595cf1f_1:

    # "'You...' the light voice cracks, 'are you... telling the truth?'"
    "'Tú...', dice la voz suave, quebrándose, '¿estás... diciendo la verdad?'"

# game/chapters/7_roomexplore.rpy:357
translate Spanish door_hub7_14f1f0a2_1:

    # "The sound of movement. You can see it in your mind, as they touch hands."
    "Se oye un movimiento. Puedes imaginártelo: están juntando sus manos."

# game/chapters/7_roomexplore.rpy:358
translate Spanish door_hub7_f28d905e_1:

    # "'I wouldn't lie to you. Feel my warmth, hear my heartbeat... have I ever felt familiar to you?'"
    "'No te mentiría. Siente mi calor, escucha los latidos de mi corazón... ¿Alguna vez te he resultado familiar?'"

# game/chapters/7_roomexplore.rpy:359
translate Spanish door_hub7_9cf1c6da_1:

    # "The rustling of cloth. A hand over a heart."
    "El susurro de la tela. Una mano sobre el corazón."

# game/chapters/7_roomexplore.rpy:360
translate Spanish door_hub7_91a1bda9_1:

    # "'...I've felt nostalgic ever since we met.' the light voice whispers."
    "'...Desde que nos conocimos, he sentido una extraña nostalgia', susurra la voz suave."

# game/chapters/7_roomexplore.rpy:361
translate Spanish door_hub7_209be59a_1:

    # "A deep voice continues."
    "Una voz grave continúa."

# game/chapters/7_roomexplore.rpy:362
translate Spanish door_hub7_2d20177b_1:

    # "'I didn't want to hurt you. I still don't. I want to keep you safe. The best way to keep you safe is... if I'm far away from you.'"
    "'No quería hacerte daño. Sigo sin quererlo. Quiero mantenerte a salvo. La mejor manera de mantenerte a salvo es... estar lejos de ti.'"

# game/chapters/7_roomexplore.rpy:363
translate Spanish door_hub7_93697ebb_1:

    # "'What would happen to you?'"
    "'¿Qué te pasaría a ti?'"

# game/chapters/7_roomexplore.rpy:364
translate Spanish door_hub7_348f8bf2_1:

    # "'...You don't need to worry about me.'"
    "'...No tienes que preocuparte por mí.'"

# game/chapters/7_roomexplore.rpy:365
translate Spanish door_hub7_58d93d36_1:

    # "'...Why don't we run away together?'"
    "'...¿Por qué no huimos juntos?'"

# game/chapters/7_roomexplore.rpy:366
translate Spanish door_hub7_f33086e8_1:

    # "'What?'"
    "'¿Qué?'"

# game/chapters/7_roomexplore.rpy:367
translate Spanish door_hub7_b7177f5a_1:

    # "There's genuine confusion in them. Their voice, which is usually so low and cool, picks up."
    "Se nota su desconcierto. Su voz, que normalmente es tan grave y serena, adquiere un tono más elevado."

# game/chapters/7_roomexplore.rpy:368
translate Spanish door_hub7_f89081b9_1:

    # "'I think I've been dreaming about you. For years. I don't want to lose you just when I've found you.' the airy voice adds."
    "'Creo que he estado soñando contigo. Durante años. No quiero perderte justo ahora que por fin te he encontrado', añade la voz suave."

# game/chapters/7_roomexplore.rpy:369
translate Spanish door_hub7_6fcfe9d1_1:

    # "'Are you... serious?' the deep voice responds, filled with surprise."
    "'¿Hablas... en serio?', responde la voz grave, llena de sorpresa."

# game/chapters/7_roomexplore.rpy:370
translate Spanish door_hub7_9dccc1fc_1:

    # "'I am.' the lighter voice repeats, a note of determination weaving through their words. "
    "'Hablo en serio', repite la voz suave, dejando entrever una firme determinación."

# game/chapters/7_roomexplore.rpy:371
translate Spanish door_hub7_dda321bb_1:

    # "'Stay with me.'"
    "'Quédate conmigo.'"

# game/chapters/7_roomexplore.rpy:372
translate Spanish door_hub7_245827d4_1:

    # "The deep voice, once calm and composed, now carries a trace of vulnerability. 'I never thought... I never imagined you'd want me to stay.'"
    "La voz grave, antes tranquila y serena, ahora deja entrever cierta vulnerabilidad. 'Nunca pensé... Nunca imaginé que quisieras que me quedara'."

# game/chapters/7_roomexplore.rpy:373
translate Spanish door_hub7_5a6a5c42_1:

    # "You can feel it even from here - a fragile hope. A possibility."
    "Puedes sentirlo incluso desde aquí: una esperanza frágil. Una posibilidad."

# game/chapters/7_roomexplore.rpy:374
translate Spanish door_hub7_08439034_1:

    # "A pause - a suspended moment in which the weight of a thousand lifetimes seems to hang in the balance."
    "Una pausa... un instante suspendido en el que parece estar en juego el destino de mil vidas."

# game/chapters/7_roomexplore.rpy:375
translate Spanish door_hub7_21adce2d_1:

    # "And then, the deep voice responds, 'If you'd have me, I'd stay by your side forever.'"
    "Y entonces, la voz grave responde: 'Si me quieres a tu lado, me quedaré contigo para siempre'."

# game/chapters/7_roomexplore.rpy:376
translate Spanish door_hub7_6998a72a_1:

    # "You hear footsteps, then a door closing."
    "Oyes pasos y luego una puerta que se cierra."

# game/chapters/7_roomexplore.rpy:377
translate Spanish door_hub7_8fba9551_1:

    # "And then, silence."
    "Y luego, silencio."

# game/chapters/7_roomexplore.rpy:378
translate Spanish door_hub7_f1c7d38a_1:

    # "The mystery of your neighbors seems to come to a close, and you step back from the door filled with wonder and confusion."
    "El misterio de tus vecinos parece llegar a su fin, y te apartas de la puerta, llen[letra] de asombro y confusión."

# game/chapters/7_roomexplore.rpy:379
translate Spanish door_hub7_accad361_1:

    # "Two people in the very same apartment with their own Grim Reapers? What are the chances?"
    "¿Dos personas en el mismo edificio con su propia Parca? ¿Qué probabilidades hay?"

# game/chapters/7_roomexplore.rpy:380
translate Spanish door_hub7_3b1344a0_1:

    # "One in a million, you assume."
    "Una entre un millón, supones."

# game/chapters/7_roomexplore.rpy:381
translate Spanish door_hub7_fc572854_1:

    # "Though you're the only person, probably, in the entire world who would believe what just happened, you can't help but feel happy."
    "Aunque probablemente seas la única persona en todo el mundo que creería lo que acaba de suceder, no puedes evitar sentirte feliz."

# game/chapters/7_roomexplore.rpy:382
translate Spanish door_hub7_58f362e7_1:

    # "Love is an infectious thing."
    "El amor es algo contagioso."

# game/chapters/7_roomexplore.rpy:383
translate Spanish door_hub7_4752e78e_1:

    # "You pray for a moment that the two, whoever they are, whatever they look like, have a happy future ahead of them."
    "Por un momento, deseas de corazón que esos dos, sean quienes sean y tengan el aspecto que tengan, disfruten de un futuro feliz."

# game/chapters/7_roomexplore.rpy:387
translate Spanish door_hub7_05d20ce8_1:

    # "And you think about your own Grim Reaper... the one who has captured your heart, as well."
    "Y piensas en tu propia Parca... la que también ha capturado tu corazón."

# game/chapters/7_roomexplore.rpy:400
translate Spanish door_hub7_b82ac03c:

    # "The hallway beyond is silent now."
    "El pasillo al otro lado de la puerta está en silencio."

# game/chapters/7_roomexplore.rpy:401
translate Spanish door_hub7_3e9c4266:

    # "But that's okay."
    "Pero está bien."

# game/chapters/7_roomexplore.rpy:406
translate Spanish door_hub7_179bdf8a:

    # "The hallway beyond is quiet."
    "El pasillo de afuera está en silencio."

# game/chapters/7_roomexplore.rpy:407
translate Spanish door_hub7_0c77ee5d:

    # "It seems you missed the ending to this story."
    "Parece que te perdiste el final de esta historia."

# game/chapters/7_roomexplore.rpy:425
translate Spanish snake_hub7_66fb5a74:

    # "[pet_name] is lazing around happily."
    "[pet_name] holgazanea felizmente."

# game/chapters/7_roomexplore.rpy:426
translate Spanish snake_hub7_d3841b0d:

    # "For some reason, you feel oddly nostalgic today, sitting next to [pet_name]."
    "Por alguna razón, hoy sientes una extraña nostalgia mientras estás junto a [pet_name]."

# game/chapters/7_roomexplore.rpy:427
translate Spanish snake_hub7_7e98b7b9:

    # "You're certain you'll win your bet, but you still give [pet_name] some extra love."
    "Tienes la certeza de que ganarás tu apuesta, pero aun así le das a [pet_name] un poco más de cariño."

# game/chapters/7_roomexplore.rpy:428
translate Spanish snake_hub7_e50d3ec8:

    # "Anything could happen, after all."
    "Cualquier cosa podría pasar, después de todo."

# game/chapters/7_roomexplore.rpy:433
translate Spanish snake_hub7_4fdd2058:

    # "You go on to tell [pet_name] how much you love [pet_her2] for fifteen minutes."
    "Pasas quince minutos contándole a [pet_name] cuánto l[letra_pet] quieres."

# game/chapters/7_roomexplore.rpy:434
translate Spanish snake_hub7_8adfc2c9:

    # "It's not enough. [pet_She] deserves even more!"
    "¡Pero eso no es suficiente! ¡[pet_She!t] se merece mucho más!"

# game/chapters/7_roomexplore.rpy:435
translate Spanish snake_hub7_e10211bc:

    # "You get [pet_name] some treats, hang out together, and overall just enjoy each other's company this morning."
    "Le das algunas golosinas a [pet_name], se hacen compañía y disfrutan de estar juntos durante toda la mañana."

# game/chapters/7_roomexplore.rpy:436
translate Spanish snake_hub7_e0852936:

    # "You love [pet_name] so much, words cannot even come close to describing how you feel."
    "Quieres tanto a [pet_name] que las palabras no bastan para describir lo que sientes."

# game/chapters/7_roomexplore.rpy:437
translate Spanish snake_hub7_6496bf3f:

    # "And in return, you feel immense trust from [pet_name] as [pet_her] tongue flickers out towards you."
    "Y, a cambio, sientes la inmensa confianza que [pet_name] deposita en ti cuando saca y mueve la lengua en tu dirección."

# game/chapters/7_roomexplore.rpy:449
translate Spanish bingus_hub7_66fb5a74:

    # "[pet_name] is lazing around happily."
    "[pet_name] holgazanea felizmente."

# game/chapters/7_roomexplore.rpy:450
translate Spanish bingus_hub7_d3841b0d:

    # "For some reason, you feel oddly nostalgic today, sitting next to [pet_name]."
    "Por alguna razón, hoy sientes una extraña nostalgia mientras estás junto a [pet_name]."

# game/chapters/7_roomexplore.rpy:451
translate Spanish bingus_hub7_7e98b7b9:

    # "You're certain you'll win your bet, but you still give [pet_name] some extra love."
    "Tienes la certeza de que ganarás tu apuesta, pero aun así le das a [pet_name] un poco más de cariño."

# game/chapters/7_roomexplore.rpy:452
translate Spanish bingus_hub7_e50d3ec8:

    # "Anything could happen, after all."
    "Cualquier cosa podría pasar, después de todo."

# game/chapters/7_roomexplore.rpy:457
translate Spanish bingus_hub7_4fdd2058:

    # "You go on to tell [pet_name] how much you love [pet_her2] for fifteen minutes."
    "Pasas quince minutos contándole a [pet_name] cuánto l[letra_pet] quieres."

# game/chapters/7_roomexplore.rpy:458
translate Spanish bingus_hub7_8adfc2c9:

    # "It's not enough. [pet_She] deserves even more!"
    "¡Pero eso no es suficiente! ¡[pet_She!t] se merece mucho más!"

# game/chapters/7_roomexplore.rpy:459
translate Spanish bingus_hub7_e10211bc:

    # "You get [pet_name] some treats, hang out together, and overall just enjoy each other's company this morning."
    "Le das algunas golosinas a [pet_name], se hacen compañía y disfrutan de estar juntos durante toda la mañana."

# game/chapters/7_roomexplore.rpy:460
translate Spanish bingus_hub7_e0852936:

    # "You love [pet_name] so much, words cannot even come close to describing how you feel."
    "Quieres tanto a [pet_name] que las palabras no bastan para describir lo que sientes."

# game/chapters/7_roomexplore.rpy:461
translate Spanish bingus_hub7_a72838eb:

    # "And in return, you feel immense love from [pet_name] as [pet_she] rubs [pet_her] velvety head against you."
    "Y, a cambio, sientes todo el cariño que [pet_name] te tiene cuando [pet_she!t] frota su suave cabecita contra ti."

# game/chapters/7_roomexplore.rpy:473
translate Spanish bunny_hub7_66fb5a74:

    # "[pet_name] is lazing around happily."
    "[pet_name] holgazanea felizmente."

# game/chapters/7_roomexplore.rpy:474
translate Spanish bunny_hub7_d3841b0d:

    # "For some reason, you feel oddly nostalgic today, sitting next to [pet_name]."
    "Por alguna razón, hoy sientes una extraña nostalgia mientras estás junto a [pet_name]."

# game/chapters/7_roomexplore.rpy:475
translate Spanish bunny_hub7_7e98b7b9:

    # "You're certain you'll win your bet, but you still give [pet_name] some extra love."
    "Tienes la certeza de que ganarás tu apuesta, pero aun así le das a [pet_name] un poco más de cariño."

# game/chapters/7_roomexplore.rpy:476
translate Spanish bunny_hub7_e50d3ec8:

    # "Anything could happen, after all."
    "Cualquier cosa podría pasar, después de todo."

# game/chapters/7_roomexplore.rpy:481
translate Spanish bunny_hub7_4fdd2058:

    # "You go on to tell [pet_name] how much you love [pet_her2] for fifteen minutes."
    "Pasas quince minutos contándole a [pet_name] cuánto l[letra_pet] quieres."

# game/chapters/7_roomexplore.rpy:482
translate Spanish bunny_hub7_8adfc2c9:

    # "It's not enough. [pet_She] deserves even more!"
    "¡Pero eso no es suficiente! ¡[pet_She!t] se merece mucho más!"

# game/chapters/7_roomexplore.rpy:483
translate Spanish bunny_hub7_e10211bc:

    # "You get [pet_name] some treats, hang out together, and overall just enjoy each other's company this morning."
    "Le das algunas golosinas a [pet_name], se hacen compañía y disfrutan de estar juntos durante toda la mañana."

# game/chapters/7_roomexplore.rpy:484
translate Spanish bunny_hub7_e0852936:

    # "You love [pet_name] so much, words cannot even come close to describing how you feel."
    "Quieres tanto a [pet_name] que las palabras no bastan para describir lo que sientes."

# game/chapters/7_roomexplore.rpy:485
translate Spanish bunny_hub7_0db6a096:

    # "And in return, you feel immense love from [pet_name] as [pet_she] nudges up against you."
    "Y, a cambio, sientes todo el cariño que [pet_name] te tiene cuando se acerca a ti y se pega a tu lado."

# game/chapters/7_roomexplore.rpy:497
translate Spanish cat_hub7_66fb5a74:

    # "[pet_name] is lazing around happily."
    "[pet_name] holgazanea felizmente."

# game/chapters/7_roomexplore.rpy:498
translate Spanish cat_hub7_d3841b0d:

    # "For some reason, you feel oddly nostalgic today, sitting next to [pet_name]."
    "Por alguna razón, hoy sientes una extraña nostalgia mientras estás junto a [pet_name]."

# game/chapters/7_roomexplore.rpy:499
translate Spanish cat_hub7_7e98b7b9:

    # "You're certain you'll win your bet, but you still give [pet_name] some extra love."
    "Tienes la certeza de que ganarás tu apuesta, pero aun así le das a [pet_name] un poco más de cariño."

# game/chapters/7_roomexplore.rpy:500
translate Spanish cat_hub7_e50d3ec8:

    # "Anything could happen, after all."
    "Cualquier cosa podría pasar, después de todo."

# game/chapters/7_roomexplore.rpy:505
translate Spanish cat_hub7_4fdd2058:

    # "You go on to tell [pet_name] how much you love [pet_her2] for fifteen minutes."
    "Pasas quince minutos contándole a [pet_name] cuánto l[letra_pet] quieres."

# game/chapters/7_roomexplore.rpy:506
translate Spanish cat_hub7_8adfc2c9:

    # "It's not enough. [pet_She] deserves even more!"
    "¡Pero eso no es suficiente! ¡[pet_She!t] se merece mucho más!"

# game/chapters/7_roomexplore.rpy:507
translate Spanish cat_hub7_e10211bc:

    # "You get [pet_name] some treats, hang out together, and overall just enjoy each other's company this morning."
    "Le das algunas golosinas a [pet_name], se hacen compañía y disfrutan de estar juntos durante toda la mañana."

# game/chapters/7_roomexplore.rpy:508
translate Spanish cat_hub7_e0852936:

    # "You love [pet_name] so much, words cannot even come close to describing how you feel."
    "Quieres tanto a [pet_name] que las palabras no bastan para describir lo que sientes."

# game/chapters/7_roomexplore.rpy:509
translate Spanish cat_hub7_c22d7706:

    # "And in return, you feel immense love from [pet_name] as [pet_she] purrs and sits on your lap."
    "Y, a cambio, sientes todo el cariño que [pet_name] te tiene cuando ronronea y se acomoda en tu regazo."

# game/chapters/7_roomexplore.rpy:521
translate Spanish dog_hub7_66fb5a74:

    # "[pet_name] is lazing around happily."
    "[pet_name] holgazanea felizmente."

# game/chapters/7_roomexplore.rpy:522
translate Spanish dog_hub7_d3841b0d:

    # "For some reason, you feel oddly nostalgic today, sitting next to [pet_name]."
    "Por alguna razón, hoy sientes una extraña nostalgia mientras estás junto a [pet_name]."

# game/chapters/7_roomexplore.rpy:523
translate Spanish dog_hub7_7e98b7b9:

    # "You're certain you'll win your bet, but you still give [pet_name] some extra love."
    "Tienes la certeza de que ganarás tu apuesta, pero aun así le das a [pet_name] un poco más de cariño."

# game/chapters/7_roomexplore.rpy:524
translate Spanish dog_hub7_e50d3ec8:

    # "Anything could happen, after all."
    "Cualquier cosa podría pasar, después de todo."

# game/chapters/7_roomexplore.rpy:529
translate Spanish dog_hub7_4fdd2058:

    # "You go on to tell [pet_name] how much you love [pet_her2] for fifteen minutes."
    "Pasas quince minutos contándole a [pet_name] cuánto l[letra_pet] quieres."

# game/chapters/7_roomexplore.rpy:530
translate Spanish dog_hub7_8adfc2c9:

    # "It's not enough. [pet_She] deserves even more!"
    "¡Pero eso no es suficiente! ¡[pet_She!t] se merece mucho más!"

# game/chapters/7_roomexplore.rpy:531
translate Spanish dog_hub7_e10211bc:

    # "You get [pet_name] some treats, hang out together, and overall just enjoy each other's company this morning."
    "Le das algunas golosinas a [pet_name], se hacen compañía y disfrutan de estar juntos durante toda la mañana."

# game/chapters/7_roomexplore.rpy:532
translate Spanish dog_hub7_e0852936:

    # "You love [pet_name] so much, words cannot even come close to describing how you feel."
    "Quieres tanto a [pet_name] que las palabras no bastan para describir lo que sientes."

# game/chapters/7_roomexplore.rpy:533
translate Spanish dog_hub7_34f967cd:

    # "And in return, you feel immense love from [pet_name] as [pet_she] wags [pet_her] tail."
    "Y, a cambio, sientes todo el cariño que [pet_name] te tiene cuando mueve la cola."

# game/chapters/7_roomexplore.rpy:545
translate Spanish hamster_hub7_66fb5a74:

    # "[pet_name] is lazing around happily."
    "[pet_name] holgazanea felizmente."

# game/chapters/7_roomexplore.rpy:546
translate Spanish hamster_hub7_d3841b0d:

    # "For some reason, you feel oddly nostalgic today, sitting next to [pet_name]."
    "Por alguna razón, hoy sientes una extraña nostalgia mientras estás junto a [pet_name]."

# game/chapters/7_roomexplore.rpy:547
translate Spanish hamster_hub7_7e98b7b9:

    # "You're certain you'll win your bet, but you still give [pet_name] some extra love."
    "Tienes la certeza de que ganarás tu apuesta, pero aun así le das a [pet_name] un poco más de cariño."

# game/chapters/7_roomexplore.rpy:548
translate Spanish hamster_hub7_e50d3ec8:

    # "Anything could happen, after all."
    "Cualquier cosa podría pasar, después de todo."

# game/chapters/7_roomexplore.rpy:553
translate Spanish hamster_hub7_4fdd2058:

    # "You go on to tell [pet_name] how much you love [pet_her2] for fifteen minutes."
    "Pasas quince minutos contándole a [pet_name] cuánto l[letra_pet] quieres."

# game/chapters/7_roomexplore.rpy:554
translate Spanish hamster_hub7_8adfc2c9:

    # "It's not enough. [pet_She] deserves even more!"
    "¡Pero eso no es suficiente! ¡[pet_She!t] se merece mucho más!"

# game/chapters/7_roomexplore.rpy:555
translate Spanish hamster_hub7_e10211bc:

    # "You get [pet_name] some treats, hang out together, and overall just enjoy each other's company this morning."
    "Le das algunas golosinas a [pet_name], se hacen compañía y disfrutan de estar juntos durante toda la mañana."

# game/chapters/7_roomexplore.rpy:556
translate Spanish hamster_hub7_e0852936:

    # "You love [pet_name] so much, words cannot even come close to describing how you feel."
    "Quieres tanto a [pet_name] que las palabras no bastan para describir lo que sientes."

# game/chapters/7_roomexplore.rpy:557
translate Spanish hamster_hub7_bac643c8:

    # "And in return, you feel immense love from [pet_name] as [pet_she] nibbles [pet_her] snacks in your hand."
    "Y, a cambio, sientes todo el cariño que [pet_name] te tiene mientras mordisquea las golosinas que tienes en la mano."

# game/chapters/7_roomexplore.rpy:577
translate Spanish plant_hub7_c1229c6a:

    # "You give your little sprout a big drink of water."
    "Le das a tu pequeño retoño un buen trago de agua."

# game/chapters/7_roomexplore.rpy:578
translate Spanish plant_hub7_c5de961c:

    # "Though you don't speak sprout, it seems to say thank you."
    "Aunque no hablas el idioma de los retoños, parece darte las gracias."

# game/chapters/7_roomexplore.rpy:580
translate Spanish plant_hub7_518e64fd:

    # "Your little sprout has grown some leaves!"
    "¡A tu pequeño retoño le han salido hojas!"

# game/chapters/7_roomexplore.rpy:581
translate Spanish plant_hub7_8036dce1:

    # "You can't help but feel proud as you give it a big drink of water."
    "No puedes evitar sentir orgullo mientras le das un buen trago de agua."

# game/chapters/7_roomexplore.rpy:583
translate Spanish plant_hub7_adaac543:

    # "Even more leaves have appeared now!"
    "¡Ahora han aparecido aún más hojas!"

# game/chapters/7_roomexplore.rpy:584
translate Spanish plant_hub7_a4970463:

    # "You water it generously and feel excited that, this time, you didn't kill your plant instantly."
    "La riegas abundantemente y te emociona comprobar que esta vez no has matado tu planta nada más empezar."

# game/chapters/7_roomexplore.rpy:586
translate Spanish plant_hub7_2087a70f:

    # "Your little plant is growing healthily!"
    "¡Tu pequeña planta está creciendo sana!"

# game/chapters/7_roomexplore.rpy:587
translate Spanish plant_hub7_80d209cf:

    # "You give it a big drink of water, excited about its growth."
    "Le das un buen trago de agua, con entusiasmo por su crecimiento."

# game/chapters/7_roomexplore.rpy:589
translate Spanish plant_hub7_41affa3b:

    # "Your little plant has sprouted some buds!"
    "¡Tu pequeña planta ha echado algunos capullos!"

# game/chapters/7_roomexplore.rpy:590
translate Spanish plant_hub7_75fbf720:

    # "You almost tear up when you notice them. They're so cute - you can't wait to see what the flowers will look like."
    "Casi se te saltan las lágrimas al verlos. ¡Son tan adorables! No puedes esperar a descubrir cómo serán las flores."

# game/chapters/7_roomexplore.rpy:592
translate Spanish plant_hub7_33ab5804:

    # "The buds on your little plant seem to be doing well!"
    "¡Los capullos de tu pequeña planta parecen estar muy bien!"

# game/chapters/7_roomexplore.rpy:593
translate Spanish plant_hub7_8b2d7914:

    # "You can't believe how healthy it is... though after what Casper told you, you're starting to understand why..."
    "No puedes creer lo bien que está creciendo... aunque, después de lo que te contó Casper, empiezas a entender por qué..."

# game/chapters/7_roomexplore.rpy:595
translate Spanish plant_hub7_3a8cf5f3:

    # "Your little sprout has grown up happily and healthily all because of you, and today..."
    "Tu pequeño retoño ha crecido feliz y saludable gracias a ti, y hoy..."

# game/chapters/7_roomexplore.rpy:602
translate Spanish plant_hub7_3542ab9b:

    # "It rewards you with four beautiful flowers!"
    "¡Te recompensa con cuatro hermosas flores!"

# game/chapters/7_roomexplore.rpy:603
translate Spanish plant_hub7_c9e73e13:

    # "You water your plant and feel a sense of accomplishment."
    "Riegas tu planta y sientes una gran satisfacción."

# game/chapters/7_roomexplore.rpy:617
translate Spanish plant_hub7_de44b0ea:

    # "A little more water never hurts, right?"
    "Un poco más de agua nunca hace daño, ¿verdad?"

# game/chapters/7_roomexplore.rpy:618
translate Spanish plant_hub7_f763544f:

    # "Except for when it does..."
    "Excepto cuando sí hace daño..."

# game/chapters/7_roomexplore.rpy:632
translate Spanish plant_hub7_efba4e08:

    # "You have never known moderation."
    "Nunca has conocido la moderación."

# game/chapters/7_roomexplore.rpy:633
translate Spanish plant_hub7_30894904:

    # "To you, life is a game. A challenge."
    "Para ti, la vida es un juego. Un desafío."

# game/chapters/7_roomexplore.rpy:634
translate Spanish plant_hub7_7f54f47c:

    # "One that you intend to win."
    "Uno que pretendes ganar."

# game/chapters/7_roomexplore.rpy:635
translate Spanish plant_hub7_2a9efc21:

    # "And the first step to winning is overwatering your plant."
    "Y el primer paso para ganar es regar en exceso tu planta."

# game/chapters/7_roomexplore.rpy:636
translate Spanish plant_hub7_73b256d7:

    # "Obviously."
    "Obviamente."

translate Spanish strings:

    # game/chapters/7_roomexplore.rpy:222
    old "1. Throw a party!"
    new "1. ¡Organizar una fiesta!"

    # game/chapters/7_roomexplore.rpy:225
    old "2. Go on a shopping spree!"
    new "2. ¡Ir de compras sin control!"

    # game/chapters/7_roomexplore.rpy:228
    old "3. Eat a WHOLE chocolate cake."
    new "3. Comer un pastel de chocolate ENTERO."

    # game/chapters/7_roomexplore.rpy:231
    old "4. Go out for a nice meal"
    new "4. Salir a disfrutar de una buena comida"

    # game/chapters/7_roomexplore.rpy:431
    old "Tell [pet_name] you love [pet_her2]."
    new "Decirle a [pet_name] cuánto cariño le tienes."

    # game/chapters/7_roomexplore.rpy:659
    old "{i}My Favorite Quote{/i}"
    new "{i}Mi cita favorita{/i}"

    # game/chapters/7_roomexplore.rpy:676
    old "[[{i}You flip to the end of your favorite childhood book. Resting against the page is a quote that's stuck with you.{/i}]"
    new "[[{i}Pasas a la última página de tu libro favorito de la infancia. Allí encuentras una cita que se te quedó grabada.{/i}]"

    # game/chapters/7_roomexplore.rpy:677
    old "If there's one thing you retain from your journey, I hope it is this: enjoy your life.  Appreciate the small moments. Love with your entire heart."
    new "Si hay algo que deseo que conserves de tu viaje, es esto: disfruta de tu vida. Aprecia los pequeños momentos. Ama con todo tu corazón."

    # game/chapters/7_roomexplore.rpy:678
    old "Not every moment has to be epic; a life filled with great deeds is also filled with great exhaustion."
    new "No todos los momentos tienen que ser épicos; una vida llena de grandes hazañas también puede ser agotadora."

    # game/chapters/7_roomexplore.rpy:679
    old "The smallest, most average moments can contain extraordinary beauty if you pay attention."
    new "Los momentos más pequeños y ordinarios pueden contener una belleza extraordinaria si prestas atención."

    # game/chapters/7_roomexplore.rpy:680
    old "We spend so much time hoping for rest, for the moment when we can relax. But true peace comes not at the end, but in the middle. It will take effort to experience these small joys and stop merely hoping for big ones."
    new "Pasamos tanto tiempo esperando poder descansar, esperando ese momento en el que por fin podamos relajarnos. Pero la verdadera paz no llega al final, sino durante el camino. Hace falta esforzarse para disfrutar de esas pequeñas alegrías y dejar de limitarse a esperar las grandes."

    # game/chapters/7_roomexplore.rpy:681
    old "So, dear reader, this if my gift to you: live every moment like it's your last, and don't forget how damn lucky you are that you will get more."
    new "Así que, querida persona lectora, este es mi regalo para ti: vive cada momento como si fuera el último y no olvides la enorme suerte que tienes de poder vivir muchos más."

