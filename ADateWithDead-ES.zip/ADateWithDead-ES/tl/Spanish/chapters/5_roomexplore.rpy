# TODO: Translation updated at 2026-10-15 18:36

# game/chapters/5_roomexplore.rpy:213
translate Spanish bed_hub5_bd2d672a:

    # "You collapse on your bed, sprawling out on your back and staring towards the ceiling."
    "Te desplomas sobre la cama, te tumbas boca arriba y te quedas mirando al techo."

# game/chapters/5_roomexplore.rpy:214
translate Spanish bed_hub5_8d721e8e:

    # "Today was a long day."
    "Hoy ha sido un día muy largo."

# game/chapters/5_roomexplore.rpy:215
translate Spanish bed_hub5_254c8d9f:

    # "However, now you're going on vacation!"
    "¡Pero ahora te vas de vacaciones!"

# game/chapters/5_roomexplore.rpy:216
translate Spanish bed_hub5_d5526558:

    # "...Kind of."
    "...Más o menos."

# game/chapters/5_roomexplore.rpy:217
translate Spanish bed_hub5_17b2cea9:

    # "You decided to take the next couple of days off from work. You don't have any particular plans, but..."
    "Decidiste tomarte los próximos días libres en el trabajo. No tienes ningún plan en particular, pero..."

# game/chapters/5_roomexplore.rpy:218
translate Spanish bed_hub5_67ad3fc1:

    # "You thought that if you were going to have your soul reaped, you didn't want to spend the last hours of your life 'working for the man', so to speak."
    "Pensaste que, si iban a cosechar tu alma, no querías pasar las últimas horas de tu vida 'trabajando para el sistema', por así decirlo."

# game/chapters/5_roomexplore.rpy:219
translate Spanish bed_hub5_e315eae9:

    # "Though you were staying at home this time, you..."
    "Aunque esta vez te quedabas en casa, tú..."

# game/chapters/5_roomexplore.rpy:225
translate Spanish bed_hub5_019316ea:

    # "You love traveling around the world, and you've visited lots of different countries."
    "Te encanta viajar por todo el mundo y has visitado muchos países diferentes."

# game/chapters/5_roomexplore.rpy:226
translate Spanish bed_hub5_4b005878:

    # "You're looking forward to spending a few days at home, though."
    "Sin embargo, tienes muchas ganas de pasar unos días en casa."

# game/chapters/5_roomexplore.rpy:229
translate Spanish bed_hub5_dacc0f6e:

    # "There's loads of beautiful places to go without even leaving the country, and you take full advantage of that."
    "Hay un montón de lugares hermosos que visitar sin siquiera salir del país, y aprovechas eso al máximo."

# game/chapters/5_roomexplore.rpy:230
translate Spanish bed_hub5_4b005878_1:

    # "You're looking forward to spending a few days at home, though."
    "Sin embargo, tienes muchas ganas de pasar unos días en casa."

# game/chapters/5_roomexplore.rpy:233
translate Spanish bed_hub5_81c31a77:

    # "There's so much beauty hidden nearby, and you try your best to discover it."
    "Hay tanta belleza escondida cerca, y tú haces todo lo posible por descubrirla."

# game/chapters/5_roomexplore.rpy:234
translate Spanish bed_hub5_4b005878_2:

    # "You're looking forward to spending a few days at home, though."
    "Sin embargo, tienes muchas ganas de pasar unos días en casa."

# game/chapters/5_roomexplore.rpy:237
translate Spanish bed_hub5_bf383c40:

    # "You're not really into traveling. The packing, the airports, lugging your suitcase around, travel time... you'd much rather stay at home."
    "No te gusta mucho viajar. Hacer las maletas, pasar por los aeropuertos, cargar tu equipaje de un lado a otro, las horas de viaje... Preferirías quedarte en casa."

# game/chapters/5_roomexplore.rpy:238
translate Spanish bed_hub5_3d49d53e:

    # "You're looking forward to spending a few days at home once again."
    "Tienes ganas de pasar unos días en casa otra vez."

# game/chapters/5_roomexplore.rpy:240
translate Spanish bed_hub5_a461b6de:

    # "You hope it'll give you some time to work out all of your feelings."
    "Esperas que eso te dé tiempo para aclarar todos tus sentimientos."

# game/chapters/5_roomexplore.rpy:249
translate Spanish door_hub5_bbd8e42a:

    # "You hear footsteps from the hallway. You wonder if it's your neighbors again?"
    "Oyes pasos en el pasillo. Te preguntas si serán tus vecinos otra vez."

# game/chapters/5_roomexplore.rpy:255
translate Spanish door_hub5_75742b08:

    # "Putting your ear to the door, you hear a knock at the apartment next to yours."
    "Al acercar la oreja a la puerta, oyes que llaman a la del apartamento de al lado."

# game/chapters/5_roomexplore.rpy:256
translate Spanish door_hub5_415788f9:

    # "There's a pause... ten seconds go by, then thirty, then it's been a minute before you even realize it."
    "Hay una pausa... pasan diez segundos, luego treinta, y de repente te das cuenta de que ha pasado un minuto."

# game/chapters/5_roomexplore.rpy:257
translate Spanish door_hub5_8f1d1fdc:

    # "No one answers the door."
    "Nadie responde a la puerta."

# game/chapters/5_roomexplore.rpy:258
translate Spanish door_hub5_2ee1af2e:

    # "You hear a sigh in the hallway beyond."
    "Oyes un suspiro en el pasillo."

# game/chapters/5_roomexplore.rpy:259
translate Spanish door_hub5_595e1278:

    # "'Are you in there?' a deep voice starts, but it's much quieter than usual."
    "'¿Estás ahí?', empieza a decir una voz grave, aunque suena mucho más baja de lo habitual."

# game/chapters/5_roomexplore.rpy:260
translate Spanish door_hub5_21eb83d2:

    # "'Sorry. For taking off like that last night.'"
    "'Lo siento. Por irme así anoche.'"

# game/chapters/5_roomexplore.rpy:261
translate Spanish door_hub5_6721d39c:

    # "'And for... not answering your texts.'"
    "'Y por... no responder a tus mensajes.'"

# game/chapters/5_roomexplore.rpy:262
translate Spanish door_hub5_427fbb4b:

    # "That voice, which you've come to know as calm and composed, sounds strained. Vulnerable."
    "Esa voz, que has llegado a conocer como tranquila y serena, suena tensa. Vulnerable."

# game/chapters/5_roomexplore.rpy:263
translate Spanish door_hub5_8ce6ad38:

    # "'I didn't mean to worry you,' the voice continues, 'but I needed some time alone. Something's been on my mind, and I didn't want to burden you with it.'"
    "'No quería preocuparte', continúa la voz, 'pero necesitaba tener un rato a solas. Tenía algo en la cabeza y no quería agobiarte con ello.'"

# game/chapters/5_roomexplore.rpy:264
translate Spanish door_hub5_fbab5138:

    # "'I've never been very good at talking to you about things. Not that you'd know that...'"
    "'Nunca se me ha dado bien hablar contigo de estas cosas. Aunque tú no lo sabrías...'"

# game/chapters/5_roomexplore.rpy:265
translate Spanish door_hub5_70dd419d:

    # "The hallway falls silent for a moment, broken only by the sound of distant traffic."
    "El pasillo queda en silencio por un momento, interrumpido solo por el sonido lejano de unas bocinas."

# game/chapters/5_roomexplore.rpy:266
translate Spanish door_hub5_cb7d7d73:

    # "'I've been keeping something from you. Something I didn't want to share... but that's never gone well for either of us.'"
    "'Te he estado ocultando algo. Algo que no quería compartir... pero eso nunca nos ha ido bien a ninguno de los dos.'"

# game/chapters/5_roomexplore.rpy:267
translate Spanish door_hub5_ff2bfcf9:

    # "'So... I know you don't want to talk right now, but... you can come find me, and I'll tell you everything.'"
    "'Así que... sé que ahora mismo no quieres hablar, pero... puedes venir a buscarme y te lo contaré todo.'"

# game/chapters/5_roomexplore.rpy:268
translate Spanish door_hub5_6b039993:

    # "'When you're ready, and only if you want to.'"
    "'Cuando te sientas list[letra], y solo si tú quieres.'"

# game/chapters/5_roomexplore.rpy:269
translate Spanish door_hub5_161ed0a7:

    # "Silence again. You keep listening quietly, but that door never opens."
    "De nuevo, silencio. Sigues escuchando en silencio, pero esa puerta nunca se abre."

# game/chapters/5_roomexplore.rpy:270
translate Spanish door_hub5_9fdc1945:

    # "And then the same voice rises for the final time."
    "Y entonces la misma voz vuelve a escucharse por última vez."

# game/chapters/5_roomexplore.rpy:271
translate Spanish door_hub5_bd999c78:

    # "'I really want to change. I really want to... get things right, just this once.'"
    "'De verdad quiero cambiar. De verdad quiero... hacer las cosas bien, solo por esta vez.'"

# game/chapters/5_roomexplore.rpy:272
translate Spanish door_hub5_5ebba7d4:

    # "Footsteps. They're slow and heavy. You can almost feel the weight of their emotions in each step." id door_hub5_5ebba7d4
    "Pasos. Son lentos y pesados. Casi puedes sentir el peso de sus emociones en cada paso." id door_hub5_5ebba7d4

# game/chapters/5_roomexplore.rpy:273
translate Spanish door_hub5_955dc319:

    # "And then all is quiet."
    "Y después, todo queda en silencio."

# game/chapters/5_roomexplore.rpy:287
translate Spanish door_hub5_75742b08_1:

    # "Putting your ear to the door, you hear a knock at the apartment next to yours."
    "Al acercar la oreja a la puerta, oyes que llaman a la del apartamento de al lado."

# game/chapters/5_roomexplore.rpy:288
translate Spanish door_hub5_415788f9_1:

    # "There's a pause... ten seconds go by, then thirty, then it's been a minute before you even realize it."
    "Hay una pausa... pasan diez segundos, luego treinta, y de repente te das cuenta de que ha pasado un minuto."

# game/chapters/5_roomexplore.rpy:289
translate Spanish door_hub5_8f1d1fdc_1:

    # "No one answers the door."
    "Nadie responde a la puerta."

# game/chapters/5_roomexplore.rpy:290
translate Spanish door_hub5_2ee1af2e_1:

    # "You hear a sigh in the hallway beyond."
    "Oyes un suspiro en el pasillo."

# game/chapters/5_roomexplore.rpy:291
translate Spanish door_hub5_595e1278_1:

    # "'Are you in there?' a deep voice starts, but it's much quieter than usual."
    "'¿Estás ahí?', empieza a decir una voz grave, aunque suena mucho más baja de lo habitual."

# game/chapters/5_roomexplore.rpy:292
translate Spanish door_hub5_21eb83d2_1:

    # "'Sorry. For taking off like that last night.'"
    "'Lo siento. Por irme así anoche.'"

# game/chapters/5_roomexplore.rpy:293
translate Spanish door_hub5_6721d39c_1:

    # "'And for... not answering your texts.'"
    "'Y por... no responder a tus mensajes.'"

# game/chapters/5_roomexplore.rpy:294
translate Spanish door_hub5_427fbb4b_1:

    # "That voice, which you've come to know as calm and composed, sounds strained. Vulnerable."
    "Esa voz, que has llegado a conocer como tranquila y serena, suena tensa. Vulnerable."

# game/chapters/5_roomexplore.rpy:295
translate Spanish door_hub5_8ce6ad38_1:

    # "'I didn't mean to worry you,' the voice continues, 'but I needed some time alone. Something's been on my mind, and I didn't want to burden you with it.'"
    "'No quería preocuparte', continúa la voz, 'pero necesitaba tener un rato a solas. Tenía algo en la cabeza y no quería agobiarte con ello.'"

# game/chapters/5_roomexplore.rpy:296
translate Spanish door_hub5_fbab5138_1:

    # "'I've never been very good at talking to you about things. Not that you'd know that...'"
    "'Nunca se me ha dado bien hablar contigo de estas cosas. Aunque tú no lo sabrías...'"

# game/chapters/5_roomexplore.rpy:297
translate Spanish door_hub5_0b36b90a:

    # "The hallway falls silent for a moment, broken only by the sound of distant honking."
    "El pasillo queda en silencio por un momento, interrumpido solo por el sonido lejano de unas bocinas."

# game/chapters/5_roomexplore.rpy:298
translate Spanish door_hub5_cb7d7d73_1:

    # "'I've been keeping something from you. Something I didn't want to share... but that's never gone well for either of us.'"
    "'Te he estado ocultando algo. Algo que no quería compartir... pero eso nunca nos ha ido bien a ninguno de los dos.'"

# game/chapters/5_roomexplore.rpy:299
translate Spanish door_hub5_ff2bfcf9_1:

    # "'So... I know you don't want to talk right now, but... you can come find me, and I'll tell you everything.'"
    "'Así que... sé que ahora mismo no quieres hablar, pero... puedes venir a buscarme y te lo contaré todo.'"

# game/chapters/5_roomexplore.rpy:300
translate Spanish door_hub5_6b039993_1:

    # "'When you're ready, and only if you want to.'"
    "'Cuando te sientas list[letra], y solo si tú quieres.'"

# game/chapters/5_roomexplore.rpy:301
translate Spanish door_hub5_161ed0a7_1:

    # "Silence again. You keep listening quietly, but that door never opens."
    "De nuevo, silencio. Sigues escuchando en silencio, pero esa puerta nunca se abre."

# game/chapters/5_roomexplore.rpy:302
translate Spanish door_hub5_9fdc1945_1:

    # "And then the same voice rises for the final time."
    "Y entonces la misma voz vuelve a escucharse por última vez."

# game/chapters/5_roomexplore.rpy:303
translate Spanish door_hub5_bd999c78_1:

    # "'I really want to change. I really want to... get things right, just this once.'"
    "'De verdad quiero cambiar. De verdad quiero... hacer las cosas bien, solo por esta vez.'"

# game/chapters/5_roomexplore.rpy:304
translate Spanish door_hub5_5ebba7d4_1:

    # "Footsteps. They're slow and heavy. You can almost feel the weight of their emotions in each step." id door_hub5_5ebba7d4_1
    "Pasos. Son lentos y pesados. Casi puedes sentir el peso de sus emociones en cada paso." id door_hub5_5ebba7d4_1

# game/chapters/5_roomexplore.rpy:305
translate Spanish door_hub5_955dc319_1:

    # "And then all is quiet."
    "Y después, todo queda en silencio."

# game/chapters/5_roomexplore.rpy:316
translate Spanish door_hub5_3d403dd1:

    # "The hallway beyond is silent."
    "El pasillo de afuera está en silencio."

# game/chapters/5_roomexplore.rpy:317
translate Spanish door_hub5_4c3f06da:

    # "You hope the two will work things out... and that you'll be able to listen in tomorrow."
    "Esperas que puedan resolver sus problemas... y que mañana puedas escuchar la conversación."

# game/chapters/5_roomexplore.rpy:331
translate Spanish snake_hub5_037e1abb:

    # "[pet_name] is out on your bed for the moment."
    "[pet_name] está en tu cama por el momento."

# game/chapters/5_roomexplore.rpy:332
translate Spanish snake_hub5_d5d9113c:

    # "You set down next to [pet_her2] and think back on your history with pets."
    "Te sientas junto a [pet_name] y recuerdas las mascotas que has tenido."

# game/chapters/5_roomexplore.rpy:338
translate Spanish snake_hub5_7a7efc1e:

    # "You didn't have any other pets growing up, but that didn't bother you."
    "No tuviste otras mascotas mientras crecías, pero eso no te molestaba."

# game/chapters/5_roomexplore.rpy:342
translate Spanish snake_hub5_b8d22d27:

    # "She was a very good cat, and loved treats and sunbaking."
    "Era una gata muy buena; le encantaban las golosinas y tomar el sol."

# game/chapters/5_roomexplore.rpy:346
translate Spanish snake_hub5_b0ae547a:

    # "He was a fantastic dog. You used to go to the beach together."
    "Era un perro fantástico. Solías ir con él a la playa."

# game/chapters/5_roomexplore.rpy:350
translate Spanish snake_hub5_2730ee45:

    # "They were fun, and you enjoyed their colorful shells."
    "Eran muy entretenidos y te gustaban sus caparazones de colores."

# game/chapters/5_roomexplore.rpy:352
translate Spanish snake_hub5_179ede57:

    # "You smile down at [pet_name]. You're very happy to have [pet_her2] in your life."
    "Le sonríes a [pet_name]. Estás muy feliz de que forme parte de tu vida."

# game/chapters/5_roomexplore.rpy:353
translate Spanish snake_hub5_c9a5d9de:

    # "Earlier today, [pet_name] was looking a little ill - but has totally perked up after spending a little time around you."
    "Hoy temprano, [pet_name] parecía estar un poco enferm[letra_pet], pero se animó por completo después de pasar un rato contigo."

# game/chapters/5_roomexplore.rpy:354
translate Spanish snake_hub5_89161ccd:

    # "Strange."
    "Extraño."

# game/chapters/5_roomexplore.rpy:359
translate Spanish snake_hub5_29a291b1:

    # "You quickly snap a picture of [pet_name]."
    "Rápidamente, le sacas una foto a [pet_name]."

# game/chapters/5_roomexplore.rpy:360
translate Spanish snake_hub5_0abb0ea8:

    # "You probably have a hundred identical ones, but that didn't matter."
    "Probablemente ya tengas cien fotos idénticas, pero no te importa."

# game/chapters/5_roomexplore.rpy:361
translate Spanish snake_hub5_833b24a4:

    # "[pet_Her] scales are shining especially bright today."
    "Hoy sus escamas brillan con especial intensidad."

# game/chapters/5_roomexplore.rpy:373
translate Spanish bingus_hub5_cb699838:

    # "[pet_name] is sitting on your bed, relaxing."
    "[pet_name] está en tu cama, relajándose."

# game/chapters/5_roomexplore.rpy:374
translate Spanish bingus_hub5_d5d9113c:

    # "You set down next to [pet_her2] and think back on your history with pets."
    "Te sientas junto a [pet_name] y recuerdas las mascotas que has tenido."

# game/chapters/5_roomexplore.rpy:380
translate Spanish bingus_hub5_7a7efc1e:

    # "You didn't have any other pets growing up, but that didn't bother you."
    "No tuviste otras mascotas mientras crecías, pero eso no te molestaba."

# game/chapters/5_roomexplore.rpy:384
translate Spanish bingus_hub5_b8d22d27:

    # "She was a very good cat, and loved treats and sunbaking."
    "Era una gata muy buena; le encantaban las golosinas y tomar el sol."

# game/chapters/5_roomexplore.rpy:388
translate Spanish bingus_hub5_b0ae547a:

    # "He was a fantastic dog. You used to go to the beach together."
    "Era un perro fantástico. Solías ir con él a la playa."

# game/chapters/5_roomexplore.rpy:392
translate Spanish bingus_hub5_2730ee45:

    # "They were fun, and you enjoyed their colorful shells."
    "Eran muy entretenidos y te gustaban sus caparazones de colores."

# game/chapters/5_roomexplore.rpy:394
translate Spanish bingus_hub5_179ede57:

    # "You smile down at [pet_name]. You're very happy to have [pet_her2] in your life."
    "Le sonríes a [pet_name]. Estás muy feliz de que forme parte de tu vida."

# game/chapters/5_roomexplore.rpy:395
translate Spanish bingus_hub5_c9a5d9de:

    # "Earlier today, [pet_name] was looking a little ill - but has totally perked up after spending a little time around you."
    "Hoy temprano, [pet_name] parecía estar un poco enferm[letra_pet], pero se animó por completo después de pasar un rato contigo."

# game/chapters/5_roomexplore.rpy:396
translate Spanish bingus_hub5_89161ccd:

    # "Strange."
    "Extraño."

# game/chapters/5_roomexplore.rpy:402
translate Spanish bingus_hub5_29a291b1:

    # "You quickly snap a picture of [pet_name]."
    "Rápidamente, le sacas una foto a [pet_name]."

# game/chapters/5_roomexplore.rpy:403
translate Spanish bingus_hub5_0abb0ea8:

    # "You probably have a hundred identical ones, but that didn't matter."
    "Probablemente ya tengas cien fotos idénticas, pero no te importa."

# game/chapters/5_roomexplore.rpy:404
translate Spanish bingus_hub5_24b275ff:

    # "[pet_Her] skin is looking especially smooth today."
    "Hoy su piel luce especialmente suave."

# game/chapters/5_roomexplore.rpy:417
translate Spanish bunny_hub5_037e1abb:

    # "[pet_name] is out on your bed for the moment."
    "[pet_name] está en tu cama por el momento."

# game/chapters/5_roomexplore.rpy:418
translate Spanish bunny_hub5_d5d9113c:

    # "You set down next to [pet_her2] and think back on your history with pets."
    "Te sientas junto a [pet_name] y recuerdas las mascotas que has tenido."

# game/chapters/5_roomexplore.rpy:424
translate Spanish bunny_hub5_7a7efc1e:

    # "You didn't have any other pets growing up, but that didn't bother you."
    "No tuviste otras mascotas mientras crecías, pero eso no te molestaba."

# game/chapters/5_roomexplore.rpy:428
translate Spanish bunny_hub5_b8d22d27:

    # "She was a very good cat, and loved treats and sunbaking."
    "Era una gata muy buena; le encantaban las golosinas y tomar el sol."

# game/chapters/5_roomexplore.rpy:432
translate Spanish bunny_hub5_b0ae547a:

    # "He was a fantastic dog. You used to go to the beach together."
    "Era un perro fantástico. Solías ir con él a la playa."

# game/chapters/5_roomexplore.rpy:436
translate Spanish bunny_hub5_2730ee45:

    # "They were fun, and you enjoyed their colorful shells."
    "Eran muy entretenidos y te gustaban sus caparazones de colores."

# game/chapters/5_roomexplore.rpy:438
translate Spanish bunny_hub5_179ede57:

    # "You smile down at [pet_name]. You're very happy to have [pet_her2] in your life."
    "Le sonríes a [pet_name]. Estás muy feliz de que forme parte de tu vida."

# game/chapters/5_roomexplore.rpy:439
translate Spanish bunny_hub5_c9a5d9de:

    # "Earlier today, [pet_name] was looking a little ill - but has totally perked up after spending a little time around you."
    "Hoy temprano, [pet_name] parecía estar un poco enferm[letra_pet], pero se animó por completo después de pasar un rato contigo."

# game/chapters/5_roomexplore.rpy:440
translate Spanish bunny_hub5_89161ccd:

    # "Strange."
    "Extraño."

# game/chapters/5_roomexplore.rpy:446
translate Spanish bunny_hub5_29a291b1:

    # "You quickly snap a picture of [pet_name]."
    "Rápidamente, le sacas una foto a [pet_name]."

# game/chapters/5_roomexplore.rpy:447
translate Spanish bunny_hub5_0abb0ea8:

    # "You probably have a hundred identical ones, but that didn't matter."
    "Probablemente ya tengas cien fotos idénticas, pero no te importa."

# game/chapters/5_roomexplore.rpy:448
translate Spanish bunny_hub5_680d566a:

    # "[pet_Her] fur is looking especially soft today."
    "Su pelaje se ve especialmente suave hoy."

# game/chapters/5_roomexplore.rpy:461
translate Spanish cat_hub5_77b29e59:

    # "[pet_name] is sleeping on your bed for the moment."
    "[pet_name] está durmiendo en tu cama por el momento."

# game/chapters/5_roomexplore.rpy:462
translate Spanish cat_hub5_d5d9113c:

    # "You set down next to [pet_her2] and think back on your history with pets."
    "Te sientas junto a [pet_name] y recuerdas las mascotas que has tenido."

# game/chapters/5_roomexplore.rpy:468
translate Spanish cat_hub5_7a7efc1e:

    # "You didn't have any other pets growing up, but that didn't bother you."
    "No tuviste otras mascotas mientras crecías, pero eso no te molestaba."

# game/chapters/5_roomexplore.rpy:472
translate Spanish cat_hub5_b8d22d27:

    # "She was a very good cat, and loved treats and sunbaking."
    "Era una gata muy buena; le encantaban las golosinas y tomar el sol."

# game/chapters/5_roomexplore.rpy:476
translate Spanish cat_hub5_b0ae547a:

    # "He was a fantastic dog. You used to go to the beach together."
    "Era un perro fantástico. Solías ir con él a la playa."

# game/chapters/5_roomexplore.rpy:480
translate Spanish cat_hub5_2730ee45:

    # "They were fun, and you enjoyed their colorful shells."
    "Eran muy entretenidos y te gustaban sus caparazones de colores."

# game/chapters/5_roomexplore.rpy:482
translate Spanish cat_hub5_179ede57:

    # "You smile down at [pet_name]. You're very happy to have [pet_her2] in your life."
    "Le sonríes a [pet_name]. Estás muy feliz de que forme parte de tu vida."

# game/chapters/5_roomexplore.rpy:483
translate Spanish cat_hub5_c9a5d9de:

    # "Earlier today, [pet_name] was looking a little ill - but has totally perked up after spending a little time around you."
    "Hoy temprano, [pet_name] parecía estar un poco enferm[letra_pet], pero se animó por completo después de pasar un rato contigo."

# game/chapters/5_roomexplore.rpy:484
translate Spanish cat_hub5_89161ccd:

    # "Strange."
    "Extraño."

# game/chapters/5_roomexplore.rpy:490
translate Spanish cat_hub5_29a291b1:

    # "You quickly snap a picture of [pet_name]."
    "Rápidamente, le sacas una foto a [pet_name]."

# game/chapters/5_roomexplore.rpy:491
translate Spanish cat_hub5_0abb0ea8:

    # "You probably have a hundred identical ones, but that didn't matter."
    "Probablemente ya tengas cien fotos idénticas, pero no te importa."

# game/chapters/5_roomexplore.rpy:492
translate Spanish cat_hub5_680d566a:

    # "[pet_Her] fur is looking especially soft today."
    "Su pelaje se ve especialmente suave hoy."

# game/chapters/5_roomexplore.rpy:505
translate Spanish dog_hub5_08ed904d:

    # "[pet_name] is hanging out on your bed at the moment."
    "[pet_name] está pasando el rato en tu cama en este momento."

# game/chapters/5_roomexplore.rpy:506
translate Spanish dog_hub5_d5d9113c:

    # "You set down next to [pet_her2] and think back on your history with pets."
    "Te sientas junto a [pet_name] y recuerdas las mascotas que has tenido."

# game/chapters/5_roomexplore.rpy:512
translate Spanish dog_hub5_7a7efc1e:

    # "You didn't have any other pets growing up, but that didn't bother you."
    "No tuviste otras mascotas mientras crecías, pero eso no te molestaba."

# game/chapters/5_roomexplore.rpy:516
translate Spanish dog_hub5_b8d22d27:

    # "She was a very good cat, and loved treats and sunbaking."
    "Era una gata muy buena; le encantaban las golosinas y tomar el sol."

# game/chapters/5_roomexplore.rpy:520
translate Spanish dog_hub5_b0ae547a:

    # "He was a fantastic dog. You used to go to the beach together."
    "Era un perro fantástico. Solías ir con él a la playa."

# game/chapters/5_roomexplore.rpy:524
translate Spanish dog_hub5_2730ee45:

    # "They were fun, and you enjoyed their colorful shells."
    "Eran muy entretenidos y te gustaban sus caparazones de colores."

# game/chapters/5_roomexplore.rpy:526
translate Spanish dog_hub5_179ede57:

    # "You smile down at [pet_name]. You're very happy to have [pet_her2] in your life."
    "Le sonríes a [pet_name]. Estás muy feliz de que forme parte de tu vida."

# game/chapters/5_roomexplore.rpy:527
translate Spanish dog_hub5_c9a5d9de:

    # "Earlier today, [pet_name] was looking a little ill - but has totally perked up after spending a little time around you."
    "Hoy temprano, [pet_name] parecía estar un poco enferm[letra_pet], pero se animó por completo después de pasar un rato contigo."

# game/chapters/5_roomexplore.rpy:528
translate Spanish dog_hub5_89161ccd:

    # "Strange."
    "Extraño."

# game/chapters/5_roomexplore.rpy:534
translate Spanish dog_hub5_29a291b1:

    # "You quickly snap a picture of [pet_name]."
    "Rápidamente, le sacas una foto a [pet_name]."

# game/chapters/5_roomexplore.rpy:535
translate Spanish dog_hub5_0abb0ea8:

    # "You probably have a hundred identical ones, but that didn't matter."
    "Probablemente ya tengas cien fotos idénticas, pero no te importa."

# game/chapters/5_roomexplore.rpy:536
translate Spanish dog_hub5_680d566a:

    # "[pet_Her] fur is looking especially soft today."
    "Su pelaje se ve especialmente suave hoy."

# game/chapters/5_roomexplore.rpy:548
translate Spanish hamster_hub5_037e1abb:

    # "[pet_name] is out on your bed for the moment."
    "[pet_name] está en tu cama por el momento."

# game/chapters/5_roomexplore.rpy:549
translate Spanish hamster_hub5_d5d9113c:

    # "You set down next to [pet_her2] and think back on your history with pets."
    "Te sientas junto a [pet_name] y recuerdas las mascotas que has tenido."

# game/chapters/5_roomexplore.rpy:555
translate Spanish hamster_hub5_7a7efc1e:

    # "You didn't have any other pets growing up, but that didn't bother you."
    "No tuviste otras mascotas mientras crecías, pero eso no te molestaba."

# game/chapters/5_roomexplore.rpy:559
translate Spanish hamster_hub5_b8d22d27:

    # "She was a very good cat, and loved treats and sunbaking."
    "Era una gata muy buena; le encantaban las golosinas y tomar el sol."

# game/chapters/5_roomexplore.rpy:563
translate Spanish hamster_hub5_b0ae547a:

    # "He was a fantastic dog. You used to go to the beach together."
    "Era un perro fantástico. Solías ir con él a la playa."

# game/chapters/5_roomexplore.rpy:567
translate Spanish hamster_hub5_2730ee45:

    # "They were fun, and you enjoyed their colorful shells."
    "Eran muy entretenidos y te gustaban sus caparazones de colores."

# game/chapters/5_roomexplore.rpy:569
translate Spanish hamster_hub5_179ede57:

    # "You smile down at [pet_name]. You're very happy to have [pet_her2] in your life."
    "Le sonríes a [pet_name]. Estás muy feliz de que forme parte de tu vida."

# game/chapters/5_roomexplore.rpy:570
translate Spanish hamster_hub5_c9a5d9de:

    # "Earlier today, [pet_name] was looking a little ill - but has totally perked up after spending a little time around you."
    "Hoy temprano, [pet_name] parecía estar un poco enferm[letra_pet], pero se animó por completo después de pasar un rato contigo."

# game/chapters/5_roomexplore.rpy:571
translate Spanish hamster_hub5_89161ccd:

    # "Strange."
    "Extraño."

# game/chapters/5_roomexplore.rpy:577
translate Spanish hamster_hub5_29a291b1:

    # "You quickly snap a picture of [pet_name]."
    "Rápidamente, le sacas una foto a [pet_name]."

# game/chapters/5_roomexplore.rpy:578
translate Spanish hamster_hub5_0abb0ea8:

    # "You probably have a hundred identical ones, but that didn't matter."
    "Probablemente ya tengas cien fotos idénticas, pero no te importa."

# game/chapters/5_roomexplore.rpy:579
translate Spanish hamster_hub5_bfdb78fe:

    # "[pet_She] is looking especially round today."
    "[pet_She] se ve especialmente redond[letra_pet] hoy."

# game/chapters/5_roomexplore.rpy:598
translate Spanish plant_hub5_c1229c6a:

    # "You give your little sprout a big drink of water."
    "Le das a tu pequeño retoño un buen trago de agua."

# game/chapters/5_roomexplore.rpy:599
translate Spanish plant_hub5_c5de961c:

    # "Though you don't speak sprout, it seems to say thank you."
    "Aunque no hablas el idioma de los retoños, parece darte las gracias."

# game/chapters/5_roomexplore.rpy:601
translate Spanish plant_hub5_518e64fd:

    # "Your little sprout has grown some leaves!"
    "¡A tu pequeño retoño le han salido hojas!"

# game/chapters/5_roomexplore.rpy:602
translate Spanish plant_hub5_8036dce1:

    # "You can't help but feel proud as you give it a big drink of water."
    "No puedes evitar sentir orgullo mientras le das un buen trago de agua."

# game/chapters/5_roomexplore.rpy:604
translate Spanish plant_hub5_adaac543:

    # "Even more leaves have appeared now!"
    "¡Ahora han aparecido aún más hojas!"

# game/chapters/5_roomexplore.rpy:605
translate Spanish plant_hub5_a4970463:

    # "You water it generously and feel excited that, this time, you didn't kill your plant instantly."
    "La riegas abundantemente y te emociona comprobar que esta vez no has matado tu planta nada más empezar."

# game/chapters/5_roomexplore.rpy:607
translate Spanish plant_hub5_2087a70f:

    # "Your little plant is growing healthily!"
    "¡Tu pequeña planta está creciendo sana!"

# game/chapters/5_roomexplore.rpy:608
translate Spanish plant_hub5_80d209cf:

    # "You give it a big drink of water, excited about its growth."
    "Le das un buen trago de agua, con entusiasmo por su crecimiento."

# game/chapters/5_roomexplore.rpy:610
translate Spanish plant_hub5_41affa3b:

    # "Your little plant has sprouted some buds!"
    "¡Tu pequeña planta ha echado algunos capullos!"

# game/chapters/5_roomexplore.rpy:611
translate Spanish plant_hub5_75fbf720:

    # "You almost tear up when you notice them. They're so cute - you can't wait to see what the flowers will look like."
    "Casi se te saltan las lágrimas al verlos. ¡Son tan adorables! No puedes esperar a descubrir cómo serán las flores."

# game/chapters/5_roomexplore.rpy:626
translate Spanish plant_hub5_7c26def7:

    # "The more the merrier, right?"
    "Cuantos más, mejor, ¿verdad?"

# game/chapters/5_roomexplore.rpy:627
translate Spanish plant_hub5_6ff6705f:

    # "You're sure that applies to watering plants, too."
    "Estás segur[letra] de que eso también se aplica a regar las plantas."

# game/chapters/5_roomexplore.rpy:628
translate Spanish plant_hub5_0b3e72ff:

    # "Absolutely."
    "Absolutamente."

# game/chapters/5_roomexplore.rpy:642
translate Spanish plant_hub5_e10d4d87:

    # "You're a responsible adult."
    "Eres [arti_2] adult[letra] responsable."

# game/chapters/5_roomexplore.rpy:643
translate Spanish plant_hub5_3896c71e:

    # "Responsible adults make their own decisions."
    "Los adultos responsables toman sus propias decisiones."

# game/chapters/5_roomexplore.rpy:644
translate Spanish plant_hub5_196b9f83:

    # "But these decisions are usually (hopefully) informed and reasonable."
    "Pero estas decisiones suelen ser (con suerte) informadas y razonables."

# game/chapters/5_roomexplore.rpy:645
translate Spanish plant_hub5_2a824992:

    # "There is nothing informed or reasonable about what you're doing."
    "No hay nada informado ni razonable en lo que estás haciendo."

# game/chapters/5_roomexplore.rpy:646
translate Spanish plant_hub5_908a3374:

    # "You're making a mess."
    "Estás haciendo un desastre."

# game/chapters/5_roomexplore.rpy:647
translate Spanish plant_hub5_124d0ed7:

    # "You are a chaos-loving goblin."
    "Eres [arti_2] duende amante del caos."

translate Spanish strings:

    # game/chapters/5_roomexplore.rpy:224
    old "1. Usually go on a lot of international trips."
    new "1. Sueles hacer muchos viajes internacionales."

    # game/chapters/5_roomexplore.rpy:228
    old "2. Like to visit other places around the country."
    new "2. Te gusta visitar otros lugares del país."

    # game/chapters/5_roomexplore.rpy:232
    old "3. Enjoy traveling around your state."
    new "3. Disfrutas de viajar por tu estado."

    # game/chapters/5_roomexplore.rpy:236
    old "4. Stay at home most of the time."
    new "4. Te quedas en casa la mayor parte del tiempo."

    # game/chapters/5_roomexplore.rpy:336
    old "1. [pet_name] was your first pet."
    new "1. [pet_name] fue tu primera mascota."

    # game/chapters/5_roomexplore.rpy:340
    old "2. Your first pet was a cat named 'Cleo'."
    new "2. Tu primera mascota fue una gata llamada 'Cleo'."

    # game/chapters/5_roomexplore.rpy:344
    old "3. Your first pet was a dog named 'Oreo'."
    new "3. Tu primera mascota fue un perro llamado 'Oreo'."

    # game/chapters/5_roomexplore.rpy:348
    old "4. Your first pets were hermit crabs!"
    new "4. ¡Tus primeras mascotas fueron cangrejos ermitaños!"

    # game/chapters/5_roomexplore.rpy:357
    old "Take a photo of [pet_name]."
    new "Tomar una foto de [pet_name]."

    # game/chapters/5_roomexplore.rpy:670
    old "{i}Affirmations{/i}"
    new "{i}Afirmaciones{/i}"

    # game/chapters/5_roomexplore.rpy:687
    old "You are made of love."
    new "Estás hech[letra] de amor."

    # game/chapters/5_roomexplore.rpy:688
    old "No amount of fear can dissolve that, no pain destroy it, no hatred diminish it, no anguish drown it, no loneliness replace it."
    new "Ningún miedo, por grande que sea, puede disolverlo; ningún dolor destruirlo, ningún odio disminuirlo, ninguna angustia ahogarlo, ninguna soledad reemplazarlo."

    # game/chapters/5_roomexplore.rpy:689
    old "You are kind, and caring, and deserve happiness."
    new "Eres amable, cariños[letra] y mereces ser feliz."

    # game/chapters/5_roomexplore.rpy:690
    old "You are love."
    new "Eres amor."

    # game/chapters/5_roomexplore.rpy:691
    old "You are capable of change, of growth."
    new "Eres capaz de cambiar, de crecer."

    # game/chapters/5_roomexplore.rpy:692
    old "You deserve the life you desire."
    new "Mereces la vida que deseas."

    # game/chapters/5_roomexplore.rpy:693
    old "You are not your mistakes or failures, and you are greater than the sum of your experiences."
    new "No eres tus errores ni tus fracasos, y eres más grande que la suma de tus experiencias."

    # game/chapters/5_roomexplore.rpy:694
    old "If you do not already know it, I hope you can come to love yourself."
    new "Si aún no lo sabes, espero que puedas llegar a amarte."

    # game/chapters/5_roomexplore.rpy:695
    old "Because you are everything."
    new "Porque lo eres todo."

