# TODO: Translation updated at 2026-10-15 18:36

# game/chapters/4_roomexplore.rpy:217
translate Spanish bed_hub4_c63951e0:

    # "Your comfortable bed."
    "Tu cómoda cama."

# game/chapters/4_roomexplore.rpy:218
translate Spanish bed_hub4_2e74d6ea:

    # "Though it's still a little early for sleeping, you can't help but feel a little tired."
    "Aunque todavía es un poco temprano para dormir, no puedes evitar sentir un poco de cansancio."

# game/chapters/4_roomexplore.rpy:219
translate Spanish bed_hub4_636d2ded:

    # "Your sleep last night was..."
    "Tu sueño anoche fue..."

# game/chapters/4_roomexplore.rpy:223
translate Spanish bed_hub4_3adb0565:

    # "You spent most of the night tossing and turning from the day's revelations."
    "Pasaste la mayor parte de la noche dando vueltas en la cama por las revelaciones del día."

# game/chapters/4_roomexplore.rpy:224
translate Spanish bed_hub4_351beb4d:

    # "As it turns out, the strange white haired Grim Reaper roleplayer you met is {i}actually{/i} the Grim Reaper."
    "Resulta que el extraño roleplayer de pelo blanco que conociste, el que hacía de Parca, es {i}de verdad{/i} la Parca."

# game/chapters/4_roomexplore.rpy:225
translate Spanish bed_hub4_92104afb:

    # "{i}Actually{/i} the Grim Reaper, and {i}actually{/i} after your soul."
    "{i}De verdad{/i} la Parca, y {i}de verdad{/i} va tras tu alma."

# game/chapters/4_roomexplore.rpy:226
translate Spanish bed_hub4_ff245ef6:

    # "Somehow, the more surprising thing is that rather than be scared, you feel..."
    "De alguna manera, lo más sorprendente es que, en lugar de sentir miedo, sientes..."

# game/chapters/4_roomexplore.rpy:229
translate Spanish bed_hub4_beee0aeb:

    # "After all, who gets to meet an actual, real life Grim Reaper?"
    "Después de todo, ¿quién tiene la oportunidad de conocer a una Parca de verdad, en la vida real?"

# game/chapters/4_roomexplore.rpy:230
translate Spanish bed_hub4_9d43cbeb:

    # "You do!"
    "¡Tú!"

# game/chapters/4_roomexplore.rpy:231
translate Spanish bed_hub4_47016d5f:

    # "All the excitement from that reveal wore you out, and you slept through the night easily, dreaming of a man whose name you don't even know."
    "Toda la emoción de aquella revelación te dejó agotad[letra], así que dormiste plácidamente toda la noche y soñaste con un hombre cuyo nombre ni siquiera conoces."

# game/chapters/4_roomexplore.rpy:232
translate Spanish bed_hub4_25df4a78:

    # "Somehow, you don't find it scary that he's after your soul. Instead you feel..."
    "De alguna manera, no te da miedo que él vaya tras tu alma. En cambio, sientes..."

# game/chapters/4_roomexplore.rpy:235
translate Spanish bed_hub4_000993e1:

    # "Sleep is an elusive thing at the best of times... and finding out the man you're talking to online is {i}actually{/i} the Grim Reaper is not the best of times."
    "Dormir es algo difícil de conseguir en el mejor de los casos... y descubrir que el hombre con el que estás hablando por Internet es {i}en realidad{/i} la Parca no es precisamente el mejor de los casos."

# game/chapters/4_roomexplore.rpy:236
translate Spanish bed_hub4_91753c3b:

    # "You didn't even get a wink of sleep. Instead, you examined your ceiling in great detail as you thought about the fact that you were actively being hunted for your soul."
    "Ni siquiera pudiste conciliar el sueño. En cambio, te quedaste mirando fijamente el techo mientras pensabas en el hecho de que te perseguían activamente para apoderarse de tu alma."

# game/chapters/4_roomexplore.rpy:237
translate Spanish bed_hub4_f11a95b5:

    # "Somehow, the Grim Reaper still didn't scare you. Talking to him was... enjoyable. You feel..."
    "De alguna manera, la Parca aún no te asustaba. Hablar con él era... agradable. Te sientes..."

# game/chapters/4_roomexplore.rpy:241
translate Spanish bed_hub4_39a19b21:

    # "You feel curious about this mysterious man. He's surrounded by puzzles and riddles - how could you not be curious?"
    "Sientes curiosidad por este hombre misterioso. Está rodeado de enigmas y acertijos, ¿cómo no vas a sentir curiosidad?"

# game/chapters/4_roomexplore.rpy:242
translate Spanish bed_hub4_da0677cc:

    # "You hope that if you keep talking to him, you'll get some answers to the many questions you have about this elusive Grim Reaper."
    "Esperas que si sigues hablando con él, obtendrás algunas respuestas a las muchas preguntas que tienes sobre esta escurridiza Parca."

# game/chapters/4_roomexplore.rpy:245
translate Spanish bed_hub4_e3e47662:

    # "You don't want to admit it, but you feel somewhat attracted to this man you know so little about."
    "No quieres admitirlo, pero te sientes algo atraíd[letra] por este hombre del que sabes tan poco."

# game/chapters/4_roomexplore.rpy:246
translate Spanish bed_hub4_eb34a438:

    # "His attitude is awful, his personality is mediocre at best, but somehow he's become rather charming in your eyes."
    "Su actitud es horrible, su personalidad es mediocre en el mejor de los casos, pero de alguna manera se ha vuelto bastante encantador a tus ojos."

# game/chapters/4_roomexplore.rpy:247
translate Spanish bed_hub4_cce54bcb:

    # "You also like to tease him. A lot."
    "También te gusta molestarlo. Mucho."

# game/chapters/4_roomexplore.rpy:248
translate Spanish bed_hub4_4a6ae7c2:

    # "You hope in the days to come, you'll learn more about him. You are somewhat concerned about what this budding spark may become, however."
    "Esperas que en los próximos días puedas saber más sobre él. Sin embargo, te preocupa un poco en qué puede convertirse esta chispa incipiente."

# game/chapters/4_roomexplore.rpy:251
translate Spanish bed_hub4_54b96c69:

    # "You're excited! Talking to him is so different and fun. He's not like anyone else you've ever met."
    "¡Estás emocionad[letra]! Hablar con él es algo muy diferente y divertido. No se parece a nadie que hayas conocido antes."

# game/chapters/4_roomexplore.rpy:252
translate Spanish bed_hub4_cb42e890:

    # "There's something about the extraordinary you've always enjoyed. You've always felt like there was something more to life that you hadn't yet discovered."
    "Siempre te ha fascinado lo extraordinario. Has sentido que la vida tenía algo más que ofrecerte, algo que todavía no habías descubierto."

# game/chapters/4_roomexplore.rpy:253
translate Spanish bed_hub4_f16ac61c:

    # "Perhaps you've found it now."
    "Quizás ahora lo hayas encontrado."

# game/chapters/4_roomexplore.rpy:263
translate Spanish door_hub4_eb6af445:

    # "You put your ear to the door, listening closely."
    "Pones la oreja en la puerta y escuchas atentamente."

# game/chapters/4_roomexplore.rpy:264
translate Spanish door_hub4_9ecf268a:

    # "You can hear something, but it seems muffled. You wonder if you'll be able to hear better from your window."
    "Puedes oír algo, pero parece amortiguado. Te preguntas si podrás oír mejor desde tu ventana."

# game/chapters/4_roomexplore.rpy:270
translate Spanish door_hub4_722f0a35:

    # "You push open your window. A cool, night time breeze blows inside."
    "Abres la ventana. Una brisa fresca nocturna entra en la habitación."

# game/chapters/4_roomexplore.rpy:271
translate Spanish door_hub4_5fae18ae:

    # "It feels nice."
    "Se siente agradable."

# game/chapters/4_roomexplore.rpy:272
translate Spanish door_hub4_0ca91273:

    # "You look up at the stars above and think for a moment that being alive truly is worth it."
    "Miras hacia las estrellas y piensas por un momento que estar con vida realmente vale la pena."

# game/chapters/4_roomexplore.rpy:273
translate Spanish door_hub4_16973246:

    # "Then you hear two voices from next door - one light and airy, and another deep and calm."
    "Entonces oyes dos voces del apartamento de al lado: una suave y ligera, y otra grave y tranquila."

# game/chapters/4_roomexplore.rpy:274
translate Spanish door_hub4_e6b56933:

    # "Just like you, they seem to be watching the stars. You can't help but feel that under such a big sky, happening to be alive at the same time as people you care about is very special."
    "Al igual que tú, parecen estar contemplando las estrellas. No puedes evitar sentir que, bajo un cielo tan inmenso, coincidir en vida con las personas que te importan es algo muy especial."

# game/chapters/4_roomexplore.rpy:275
translate Spanish door_hub4_2a085af1:

    # "The light voice speaks first."
    "La voz ligera habla primero."

# game/chapters/4_roomexplore.rpy:276
translate Spanish door_hub4_21f6ee7a:

    # "'Isn't it just beautiful? That's why I decided to rent this apartment. The view is amazing during the day, but nothing beats the night sky.'"
    "'¿No es precioso? Por eso decidí alquilar este apartamento. Las vistas son increíbles durante el día, pero nada supera al cielo nocturno.'"

# game/chapters/4_roomexplore.rpy:277
translate Spanish door_hub4_7fe21b16:

    # "'You are... it is very beautiful.' the deeper voice answers, sounding somewhat absent minded."
    "'Tú eres... Es muy bonito', responde la voz más grave, con un tono algo distraído."

# game/chapters/4_roomexplore.rpy:278
translate Spanish door_hub4_03a0ef2e:

    # "'You've always loved the stars, haven't you?' the deep voice continues. 'Forever and ever, right?'"
    "'Siempre te han gustado las estrellas, ¿verdad?', continúa la voz grave. 'Desde siempre y para siempre, ¿no?'"

# game/chapters/4_roomexplore.rpy:279
translate Spanish door_hub4_8e4a5a04:

    # "The lighter voice pauses for a moment, '...Actually, yes. As long as I can remember.'"
    "La voz más ligera hace una pausa por un momento: '...En realidad, sí. Desde que tengo memoria.'"

# game/chapters/4_roomexplore.rpy:280
translate Spanish door_hub4_4ffe0e1a:

    # "'I thought so.'"
    "'Ya me lo imaginaba.'"

# game/chapters/4_roomexplore.rpy:281
translate Spanish door_hub4_cbf6bacf:

    # "'How could you guess?'"
    "'¿Cómo lo adivinaste?'"

# game/chapters/4_roomexplore.rpy:282
translate Spanish door_hub4_10ba9ad7:

    # "'To be honest, I'm a little embarrassed to say it...'"
    "'Honestamente, me da un poco de vergüenza decirlo...'"

# game/chapters/4_roomexplore.rpy:283
translate Spanish door_hub4_d0b17f29:

    # "'I feel like I see the universe in your eyes. Sorry, it sounds a little corny...'"
    "'Siento como si viera el universo en tus ojos. Lo siento, suena un poco cursi...'"

# game/chapters/4_roomexplore.rpy:284
translate Spanish door_hub4_0edfbc16:

    # "The two voices go quiet for a moment, and you feel like these two people you've never met are too busy looking into each other's eyes to say anything."
    "Las dos voces se callan por un momento y sientes que estas dos personas que nunca has conocido están demasiado ocupadas mirándose a los ojos como para decir nada."

# game/chapters/4_roomexplore.rpy:285
translate Spanish door_hub4_0515424d:

    # "The deeper voice finally pipes up again."
    "La voz más grave finalmente vuelve a hablar."

# game/chapters/4_roomexplore.rpy:286
translate Spanish door_hub4_8116e649:

    # "'Do you believe in fate?'"
    "'¿Crees en el destino?'"

# game/chapters/4_roomexplore.rpy:287
translate Spanish door_hub4_27b932b0:

    # "The lighter voice answers, but seems much... smaller than usual."
    "La voz más suave responde, pero suena mucho... más apagada de lo habitual."

# game/chapters/4_roomexplore.rpy:288
translate Spanish door_hub4_5fccdc99:

    # "'I'm... not sure.'"
    "'Yo... no lo sé.'"

# game/chapters/4_roomexplore.rpy:289
translate Spanish door_hub4_708b38ea:

    # "'I feel like you are someone I was always meant to meet.'" id door_hub4_708b38ea
    "'Siento que eres alguien a quien siempre estuve destinado a conocer.'" id door_hub4_708b38ea

# game/chapters/4_roomexplore.rpy:290
translate Spanish door_hub4_3e543646:

    # "'But, I...' the voice, cool like the night sky above, cuts off."
    "'Pero yo...', la voz, fría como el cielo nocturno, se interrumpe."

# game/chapters/4_roomexplore.rpy:291
translate Spanish door_hub4_0958beee:

    # "'...I don't want to hurt you, and I'm afraid that the same fate that made us meet in the first place will make me cause you pain.'"
    "'No quiero hacerte daño, y me da miedo que el mismo destino que hizo que nos encontráramos me lleve a causarte dolor.'"

# game/chapters/4_roomexplore.rpy:292
translate Spanish door_hub4_34ec7590:

    # "'Half of me wants to stay anyway, and the other half knows how selfish that sounds.'"
    "'La mitad de mí quiere quedarse de todos modos, y la otra mitad sabe lo egoísta que suena.'"

# game/chapters/4_roomexplore.rpy:293
translate Spanish door_hub4_12bc8e0d:

    # "'Can't there be a third option?' the light voice adds on, barely a whisper."
    "'¿No puede haber una tercera opción?', añade la voz ligera, apenas en un susurro."

# game/chapters/4_roomexplore.rpy:294
translate Spanish door_hub4_64e1c86e:

    # "A sigh escapes into the night air."
    "Un suspiro escapa al aire nocturno."

# game/chapters/4_roomexplore.rpy:295
translate Spanish door_hub4_e86eb6c9:

    # "'I wish there was.'"
    "'Ojalá la hubiera.'"

# game/chapters/4_roomexplore.rpy:296
translate Spanish door_hub4_396e0781:

    # "'It's getting late. I had better head off.'"
    "'Se está haciendo tarde. Será mejor que me vaya.'"

# game/chapters/4_roomexplore.rpy:297
translate Spanish door_hub4_9d5463fd:

    # "The voices slowly fade, and soon enough you hear your neighbor's door open then close."
    "Las voces se desvanecen lentamente y, al poco tiempo, oyes cómo se abre y se cierra la puerta del apartamento de al lado."

# game/chapters/4_roomexplore.rpy:298
translate Spanish door_hub4_c542f4d0:

    # "That seems to be everything you'll hear for the night."
    "Eso parece ser todo lo que escucharás por la noche."

# game/chapters/4_roomexplore.rpy:299
translate Spanish door_hub4_4b736e1f:

    # "But it did get you thinking. About fate, and chance meetings, and the budding feelings within your chest."
    "Pero te ha hecho pensar. Sobre el destino, los encuentros fortuitos y los sentimientos que brotan en tu pecho."

# game/chapters/4_roomexplore.rpy:313
translate Spanish door_hub4_722f0a35_1:

    # "You push open your window. A cool, night time breeze blows inside."
    "Abres la ventana de un empujón. Una brisa fresca y nocturna sopla dentro."

# game/chapters/4_roomexplore.rpy:314
translate Spanish door_hub4_5fae18ae_1:

    # "It feels nice."
    "Se siente bien."

# game/chapters/4_roomexplore.rpy:315
translate Spanish door_hub4_0ca91273_1:

    # "You look up at the stars above and think for a moment that being alive truly is worth it."
    "Miras hacia las estrellas y piensas por un momento que estar con vida realmente vale la pena."

# game/chapters/4_roomexplore.rpy:316
translate Spanish door_hub4_16973246_1:

    # "Then you hear two voices from next door - one light and airy, and another deep and calm."
    "Entonces oyes dos voces del apartamento de al lado: una suave y ligera, y otra grave y tranquila."

# game/chapters/4_roomexplore.rpy:317
translate Spanish door_hub4_e6b56933_1:

    # "Just like you, they seem to be watching the stars. You can't help but feel that under such a big sky, happening to be alive at the same time as people you care about is very special."
    "Al igual que tú, parecen estar contemplando las estrellas. No puedes evitar sentir que, bajo un cielo tan inmenso, el hecho de estar viv[letra] al mismo tiempo que las personas que te importan es algo muy especial."

# game/chapters/4_roomexplore.rpy:318
translate Spanish door_hub4_2a085af1_1:

    # "The light voice speaks first."
    "La voz ligera habla primero."

# game/chapters/4_roomexplore.rpy:319
translate Spanish door_hub4_21f6ee7a_1:

    # "'Isn't it just beautiful? That's why I decided to rent this apartment. The view is amazing during the day, but nothing beats the night sky.'"
    "'¿No es precioso? Por eso decidí alquilar este apartamento. Las vistas son increíbles durante el día, pero nada supera al cielo nocturno.'"

# game/chapters/4_roomexplore.rpy:320
translate Spanish door_hub4_7fe21b16_1:

    # "'You are... it is very beautiful.' the deeper voice answers, sounding somewhat absent minded."
    "'Tú eres... Es muy bonito', responde la voz más grave, con un tono algo distraído."

# game/chapters/4_roomexplore.rpy:321
translate Spanish door_hub4_03a0ef2e_1:

    # "'You've always loved the stars, haven't you?' the deep voice continues. 'Forever and ever, right?'"
    "'Siempre te han gustado las estrellas, ¿verdad?', continúa la voz grave. 'Desde siempre y para siempre, ¿no?'"

# game/chapters/4_roomexplore.rpy:322
translate Spanish door_hub4_8e4a5a04_1:

    # "The lighter voice pauses for a moment, '...Actually, yes. As long as I can remember.'"
    "La voz más ligera hace una pausa por un momento: '... En realidad, sí. Desde que tengo memoria.'"

# game/chapters/4_roomexplore.rpy:323
translate Spanish door_hub4_4ffe0e1a_1:

    # "'I thought so.'"
    "'Eso pensaba.'"

# game/chapters/4_roomexplore.rpy:324
translate Spanish door_hub4_cbf6bacf_1:

    # "'How could you guess?'"
    "'¿Cómo lo adivinaste?'"

# game/chapters/4_roomexplore.rpy:325
translate Spanish door_hub4_10ba9ad7_1:

    # "'To be honest, I'm a little embarrassed to say it...'"
    "'Honestamente, me da un poco de vergüenza decirlo...'"

# game/chapters/4_roomexplore.rpy:326
translate Spanish door_hub4_d0b17f29_1:

    # "'I feel like I see the universe in your eyes. Sorry, it sounds a little corny...'"
    "'Siento como si viera el universo en tus ojos. Lo siento, suena un poco cursi...'"

# game/chapters/4_roomexplore.rpy:327
translate Spanish door_hub4_0edfbc16_1:

    # "The two voices go quiet for a moment, and you feel like these two people you've never met are too busy looking into each other's eyes to say anything."
    "Las dos voces se callan por un momento y sientes que estas dos personas que nunca has conocido están demasiado ocupadas mirándose a los ojos como para decir nada."

# game/chapters/4_roomexplore.rpy:328
translate Spanish door_hub4_0515424d_1:

    # "The deeper voice finally pipes up again."
    "La voz más grave finalmente vuelve a hablar."

# game/chapters/4_roomexplore.rpy:329
translate Spanish door_hub4_8116e649_1:

    # "'Do you believe in fate?'"
    "'¿Crees en el destino?'"

# game/chapters/4_roomexplore.rpy:330
translate Spanish door_hub4_27b932b0_1:

    # "The lighter voice answers, but seems much... smaller than usual."
    "La voz más ligera responde, pero parece mucho... más débil de lo habitual."

# game/chapters/4_roomexplore.rpy:331
translate Spanish door_hub4_5fccdc99_1:

    # "'I'm... not sure.'"
    "'Yo... no lo sé.'"

# game/chapters/4_roomexplore.rpy:332
translate Spanish door_hub4_708b38ea_1:

    # "'I feel like you are someone I was always meant to meet.'" id door_hub4_708b38ea_1
    "'Siento que eres alguien a quien siempre estuve destinado a conocer.'" id door_hub4_708b38ea_1

# game/chapters/4_roomexplore.rpy:333
translate Spanish door_hub4_3e543646_1:

    # "'But, I...' the voice, cool like the night sky above, cuts off."
    "'Pero yo...', la voz, fría como el cielo nocturno, se interrumpe."

# game/chapters/4_roomexplore.rpy:334
translate Spanish door_hub4_0958beee_1:

    # "'...I don't want to hurt you, and I'm afraid that the same fate that made us meet in the first place will make me cause you pain.'"
    "'...No quiero hacerte daño, y me da miedo que el mismo destino que hizo que nos encontráramos me lleve a causarte dolor.'"

# game/chapters/4_roomexplore.rpy:335
translate Spanish door_hub4_34ec7590_1:

    # "'Half of me wants to stay anyway, and the other half knows how selfish that sounds.'"
    "'La mitad de mí quiere quedarse de todos modos, y la otra mitad sabe lo egoísta que suena eso.'"

# game/chapters/4_roomexplore.rpy:336
translate Spanish door_hub4_12bc8e0d_1:

    # "'Can't there be a third option?' the light voice adds on, barely a whisper."
    "'¿No puede haber una tercera opción?', añade la voz ligera, apenas un susurro."

# game/chapters/4_roomexplore.rpy:337
translate Spanish door_hub4_64e1c86e_1:

    # "A sigh escapes into the night air."
    "Un suspiro se escapa en el aire nocturno."

# game/chapters/4_roomexplore.rpy:338
translate Spanish door_hub4_e86eb6c9_1:

    # "'I wish there was.'"
    "'Ojalá la hubiera.'"

# game/chapters/4_roomexplore.rpy:339
translate Spanish door_hub4_396e0781_1:

    # "'It's getting late. I had better head off.'"
    "'Se está haciendo tarde. Será mejor que me vaya.'"

# game/chapters/4_roomexplore.rpy:340
translate Spanish door_hub4_9d5463fd_1:

    # "The voices slowly fade, and soon enough you hear your neighbor's door open then close."
    "Las voces se desvanecen lentamente y, al poco tiempo, oyes cómo se abre y se cierra la puerta del apartamento de al lado."

# game/chapters/4_roomexplore.rpy:341
translate Spanish door_hub4_c542f4d0_1:

    # "That seems to be everything you'll hear for the night."
    "Parece que eso es todo lo que oirás esta noche."

# game/chapters/4_roomexplore.rpy:342
translate Spanish door_hub4_4b736e1f_1:

    # "But it did get you thinking. About fate, and chance meetings, and the budding feelings within your chest."
    "Pero te ha hecho pensar. Sobre el destino, los encuentros fortuitos y los sentimientos que brotan en tu pecho."

# game/chapters/4_roomexplore.rpy:354
translate Spanish door_hub4_aa9c4dbc:

    # "The apartment and hallway beyond is silent."
    "El apartamento y el pasillo que hay más allá están en silencio."

# game/chapters/4_roomexplore.rpy:355
translate Spanish door_hub4_60e3b598:

    # "You'll have to wait until tomorrow to hear more about your peculiar neighbors."
    "Tendrás que esperar hasta mañana para saber más sobre tus peculiares vecinos."

# game/chapters/4_roomexplore.rpy:369
translate Spanish snake_hub4_08ed904d:

    # "[pet_name] is hanging out on your bed at the moment."
    "[pet_name] está pasando el rato en tu cama en este momento."

# game/chapters/4_roomexplore.rpy:370
translate Spanish snake_hub4_6c976065:

    # "As you sit down next to [pet_her2], you think a little bit on your shared history."
    "Mientras te sientas junto a [pet_her2], piensas un poco en la historia que comparten."

# game/chapters/4_roomexplore.rpy:371
translate Spanish snake_hub4_6b0c7405:

    # "Just how did you come up with [pet_her] name, again?"
    "¿Cómo se te ocurrió ese nombre, otra vez?"

# game/chapters/4_roomexplore.rpy:377
translate Spanish snake_hub4_6f27dc4e:

    # "What best way to memorialize your favorite character but in pet form?"
    "¿Qué mejor manera de rendirle homenaje a tu personaje favorito que poniéndole su nombre a tu mascota?"

# game/chapters/4_roomexplore.rpy:378
translate Spanish snake_hub4_918b0e4c:

    # "You love both [pet_name]'s dearly."
    "Quieres muchísimo a ambos [pet_name]."

# game/chapters/4_roomexplore.rpy:382
translate Spanish snake_hub4_157b1c09:

    # "Sure, it's not very original, but it gets the job done."
    "Claro, no es muy original, pero cumple su función."

# game/chapters/4_roomexplore.rpy:383
translate Spanish snake_hub4_1218ce43:

    # "You can't think of [pet_name] being called anything other than [pet_name]."
    "No puedes imaginar que [pet_name] se llame de otra manera."

# game/chapters/4_roomexplore.rpy:387
translate Spanish snake_hub4_bb04072f:

    # "You didn't have any particular naming plan for [pet_her2]."
    "No tenías ningún plan concreto para ponerle nombre."

# game/chapters/4_roomexplore.rpy:388
translate Spanish snake_hub4_48ce966d:

    # "As soon as you saw [pet_her2], you knew the right name."
    "En cuanto l[letra_pet] viste, supiste cuál era el nombre perfecto."

# game/chapters/4_roomexplore.rpy:392
translate Spanish snake_hub4_e96bb619:

    # "You planned out [pet_her]'s name seven months in advance."
    "Planeaste su nombre con siete meses de anticipación."

# game/chapters/4_roomexplore.rpy:393
translate Spanish snake_hub4_c856f278:

    # "You always have been good at being prepared."
    "Siempre se te ha dado bien estar preparad[letra]."

# game/chapters/4_roomexplore.rpy:399
translate Spanish snake_hub4_0a92517d:

    # "You spend the better part of the night cleaning out [pet_name]'s enclosure."
    "Pasas la mayor parte de la noche limpiando el recinto de [pet_name]."

# game/chapters/4_roomexplore.rpy:400
translate Spanish snake_hub4_73cd42e1:

    # "You remove all of the bowls, accessories and bedding first, cleaning them as you go, then wash out the enclosure with hot, soapy water."
    "Primero retiras todos los cuencos, accesorios y el sustrato, limpiándolos a medida que avanzas, luego lavas el recinto con agua caliente y jabonosa."

# game/chapters/4_roomexplore.rpy:401
translate Spanish snake_hub4_bf05b7bb:

    # "It's a bit of work, but you're pretty used to it, seeing at you do a big clean once a week."
    "Es algo trabajoso, pero ya estás bastante acostumbrad[letra], porque haces una limpieza a fondo una vez por semana."

# game/chapters/4_roomexplore.rpy:402
translate Spanish snake_hub4_44d3a933:

    # "No one said having a pet snake was easy."
    "Nadie dijo que tener una serpiente de mascota fuera fácil."

# game/chapters/4_roomexplore.rpy:414
translate Spanish bingus_hub4_08ed904d:

    # "[pet_name] is hanging out on your bed at the moment."
    "[pet_name] está pasando el rato en tu cama en este momento."

# game/chapters/4_roomexplore.rpy:415
translate Spanish bingus_hub4_6c976065:

    # "As you sit down next to [pet_her2], you think a little bit on your shared history."
    "Mientras te sientas junto a [pet_her2], piensas un poco en la historia que comparten."

# game/chapters/4_roomexplore.rpy:416
translate Spanish bingus_hub4_6b0c7405:

    # "Just how did you come up with [pet_her] name, again?"
    "¿Cómo se te ocurrió ese nombre, otra vez?"

# game/chapters/4_roomexplore.rpy:422
translate Spanish bingus_hub4_6f27dc4e:

    # "What best way to memorialize your favorite character but in pet form?"
    "¿Qué mejor manera de rendirle homenaje a tu personaje favorito que poniéndole su nombre a tu mascota?"

# game/chapters/4_roomexplore.rpy:423
translate Spanish bingus_hub4_918b0e4c:

    # "You love both [pet_name]'s dearly."
    "Quieres muchísimo a ambos [pet_name]."

# game/chapters/4_roomexplore.rpy:427
translate Spanish bingus_hub4_157b1c09:

    # "Sure, it's not very original, but it gets the job done."
    "Claro, no es muy original, pero cumple su función."

# game/chapters/4_roomexplore.rpy:428
translate Spanish bingus_hub4_1218ce43:

    # "You can't think of [pet_name] being called anything other than [pet_name]."
    "No puedes imaginar que [pet_name] se llame de otra manera."

# game/chapters/4_roomexplore.rpy:432
translate Spanish bingus_hub4_bb04072f:

    # "You didn't have any particular naming plan for [pet_her2]."
    "No tenías ningún plan concreto para ponerle nombre."

# game/chapters/4_roomexplore.rpy:433
translate Spanish bingus_hub4_48ce966d:

    # "As soon as you saw [pet_her2], you knew the right name."
    "En cuanto l[letra_pet] viste, supiste cuál era el nombre perfecto."

# game/chapters/4_roomexplore.rpy:437
translate Spanish bingus_hub4_e96bb619:

    # "You planned out [pet_her]'s name seven months in advance."
    "Planeaste su nombre con siete meses de anticipación."

# game/chapters/4_roomexplore.rpy:438
translate Spanish bingus_hub4_c856f278:

    # "You always have been good at being prepared."
    "Siempre se te ha dado bien estar preparad[letra]."

# game/chapters/4_roomexplore.rpy:443
translate Spanish bingus_hub4_f3086971:

    # "One of the first things you learned about Sphynxes was that they are particuarly grubby pets." id bingus_hub4_f3086971
    "Una de las primeras cosas que aprendiste sobre los gatos Sphynx es que son mascotas especialmente sucias." id bingus_hub4_f3086971

# game/chapters/4_roomexplore.rpy:444
translate Spanish bingus_hub4_a09fef10:

    # "Especially in the summer."
    "Especialmente en el verano."

# game/chapters/4_roomexplore.rpy:445
translate Spanish bingus_hub4_dd1d3b4e:

    # "You go about cleaning [pet_name]'s ears, between [pet_her] toes, and wiping down [pet_her] skin."
    "Limpias las orejas de [pet_name], entre los dedos de las patas y le limpias la piel."

# game/chapters/4_roomexplore.rpy:446
translate Spanish bingus_hub4_856e6bd8:

    # "[pet_name] has occassional baths, too, but for today a little maintenance is enough."
    "[pet_name] también se baña de vez en cuando, pero por hoy basta con un poco de mantenimiento."

# game/chapters/4_roomexplore.rpy:447
translate Spanish bingus_hub4_6360d0cb:

    # "[pet_name] purrs the whole time - [pet_she]'s always enjoyed being groomed."
    "[pet_name] ronronea todo el rato: siempre le ha gustado que l[letra_pet] aseen."

# game/chapters/4_roomexplore.rpy:459
translate Spanish bunny_hub4_08ed904d:

    # "[pet_name] is hanging out on your bed at the moment."
    "[pet_name] está pasando el rato en tu cama en este momento."

# game/chapters/4_roomexplore.rpy:460
translate Spanish bunny_hub4_6c976065:

    # "As you sit down next to [pet_her2], you think a little bit on your shared history."
    "Mientras te sientas junto a [pet_her2], piensas un poco en la historia que comparten."

# game/chapters/4_roomexplore.rpy:461
translate Spanish bunny_hub4_6b0c7405:

    # "Just how did you come up with [pet_her] name, again?"
    "¿Cómo se te ocurrió ese nombre, otra vez?"

# game/chapters/4_roomexplore.rpy:467
translate Spanish bunny_hub4_6f27dc4e:

    # "What best way to memorialize your favorite character but in pet form?"
    "¿Qué mejor manera de rendirle homenaje a tu personaje favorito que poniéndole su nombre a tu mascota?"

# game/chapters/4_roomexplore.rpy:468
translate Spanish bunny_hub4_918b0e4c:

    # "You love both [pet_name]'s dearly."
    "Quieres muchísimo a ambos [pet_name]."

# game/chapters/4_roomexplore.rpy:472
translate Spanish bunny_hub4_157b1c09:

    # "Sure, it's not very original, but it gets the job done."
    "Claro, no es muy original, pero cumple su función."

# game/chapters/4_roomexplore.rpy:473
translate Spanish bunny_hub4_1218ce43:

    # "You can't think of [pet_name] being called anything other than [pet_name]."
    "No puedes imaginar que [pet_name] se llame de otra manera."

# game/chapters/4_roomexplore.rpy:477
translate Spanish bunny_hub4_bb04072f:

    # "You didn't have any particular naming plan for [pet_her2]."
    "No tenías ningún plan concreto para ponerle nombre."

# game/chapters/4_roomexplore.rpy:478
translate Spanish bunny_hub4_48ce966d:

    # "As soon as you saw [pet_her2], you knew the right name."
    "En cuanto l[letra_pet] viste, supiste cuál era el nombre perfecto."

# game/chapters/4_roomexplore.rpy:482
translate Spanish bunny_hub4_e96bb619:

    # "You planned out [pet_her]'s name seven months in advance."
    "Planeaste su nombre con siete meses de anticipación."

# game/chapters/4_roomexplore.rpy:483
translate Spanish bunny_hub4_c856f278:

    # "You always have been good at being prepared."
    "Siempre se te ha dado bien estar preparad[letra]."

# game/chapters/4_roomexplore.rpy:488
translate Spanish bunny_hub4_f5f5d976:

    # "You place a small towel across your lap and put [pet_name] on top of it."
    "Colocas una toalla pequeña sobre tu regazo y pones a [pet_name] encima."

# game/chapters/4_roomexplore.rpy:489
translate Spanish bunny_hub4_1ed0bc2f:

    # "With your handy soft bristle brush, you spend some time combing and grooming [pet_name]."
    "Con tu práctico cepillo de cerdas suaves, dedicas un tiempo a peinar y acicalar a [pet_name]."

# game/chapters/4_roomexplore.rpy:490
translate Spanish bunny_hub4_46996560:

    # "You're always very gentle and careful, and [pet_name] enjoys it a lot."
    "Siempre actúas con mucha delicadeza y cuidado, y [pet_name] lo disfruta mucho."

# game/chapters/4_roomexplore.rpy:491
translate Spanish bunny_hub4_9809d23d:

    # "You give [pet_her2] a pat behind the ears when you're done."
    "Cuando terminas, le das unas caricias detrás de las orejas."

# game/chapters/4_roomexplore.rpy:503
translate Spanish cat_hub4_08ed904d:

    # "[pet_name] is hanging out on your bed at the moment."
    "[pet_name] está pasando el rato en tu cama en este momento."

# game/chapters/4_roomexplore.rpy:504
translate Spanish cat_hub4_6c976065:

    # "As you sit down next to [pet_her2], you think a little bit on your shared history."
    "Mientras te sientas junto a [pet_her2], piensas un poco en la historia que comparten."

# game/chapters/4_roomexplore.rpy:505
translate Spanish cat_hub4_6b0c7405:

    # "Just how did you come up with [pet_her] name, again?"
    "¿Cómo se te ocurrió ese nombre, otra vez?"

# game/chapters/4_roomexplore.rpy:511
translate Spanish cat_hub4_6f27dc4e:

    # "What best way to memorialize your favorite character but in pet form?"
    "¿Qué mejor manera de rendirle homenaje a tu personaje favorito que poniéndole su nombre a tu mascota?"

# game/chapters/4_roomexplore.rpy:512
translate Spanish cat_hub4_918b0e4c:

    # "You love both [pet_name]'s dearly."
    "Quieres muchísimo a ambos [pet_name]."

# game/chapters/4_roomexplore.rpy:516
translate Spanish cat_hub4_157b1c09:

    # "Sure, it's not very original, but it gets the job done."
    "Claro, no es muy original, pero cumple su función."

# game/chapters/4_roomexplore.rpy:517
translate Spanish cat_hub4_1218ce43:

    # "You can't think of [pet_name] being called anything other than [pet_name]."
    "No puedes imaginar que [pet_name] se llame de otra manera."

# game/chapters/4_roomexplore.rpy:521
translate Spanish cat_hub4_bb04072f:

    # "You didn't have any particular naming plan for [pet_her2]."
    "No tenías ningún plan concreto para ponerle nombre."

# game/chapters/4_roomexplore.rpy:522
translate Spanish cat_hub4_48ce966d:

    # "As soon as you saw [pet_her2], you knew the right name."
    "En cuanto l[letra_pet] viste, supiste cuál era el nombre perfecto."

# game/chapters/4_roomexplore.rpy:526
translate Spanish cat_hub4_e96bb619:

    # "You planned out [pet_her]'s name seven months in advance."
    "Planeaste su nombre con siete meses de anticipación."

# game/chapters/4_roomexplore.rpy:527
translate Spanish cat_hub4_c856f278:

    # "You always have been good at being prepared."
    "Siempre se te ha dado bien estar preparad[letra]."

# game/chapters/4_roomexplore.rpy:532
translate Spanish cat_hub4_cb6a4193:

    # "[pet_name] is looking particularly relaxed right now, and you know that's the best time to strike."
    "[pet_name] se ve especialmente relajad[letra_pet] en este momento, y sabes que es el mejor momento para actuar."

# game/chapters/4_roomexplore.rpy:533
translate Spanish cat_hub4_b39645bb:

    # "Calmly, you sit next to [pet_her2] on the bed and pull out a rubber brush."
    "Con calma, te sientas junto a [pet_name] en la cama y sacas un cepillo de goma."

# game/chapters/4_roomexplore.rpy:534
translate Spanish cat_hub4_4ebadd13:

    # "Luckily, [pet_name] enjoys being brushed, and happily sleeps through the grooming session."
    "Afortunadamente, [pet_name] disfruta el cepillado, y duerme felizmente durante toda la sesión de aseo."

# game/chapters/4_roomexplore.rpy:535
translate Spanish cat_hub4_c3a804c1:

    # "What [pet_she] enjoys less is having [pet_her] nails clipped, but you manage to get through them all."
    "Lo que menos le gusta a [pet_she!t] es que le corten las uñas, pero te las arreglas para cortárselas todas."

# game/chapters/4_roomexplore.rpy:536
translate Spanish cat_hub4_93d71a1a:

    # "You give [pet_name] a little treat at the end of it."
    "Le das a [pet_name] una pequeña golosina al final."

# game/chapters/4_roomexplore.rpy:548
translate Spanish dog_hub4_08ed904d:

    # "[pet_name] is hanging out on your bed at the moment."
    "[pet_name] está pasando el rato en tu cama en este momento."

# game/chapters/4_roomexplore.rpy:549
translate Spanish dog_hub4_6c976065:

    # "As you sit down next to [pet_her2], you think a little bit on your shared history."
    "Mientras te sientas junto a [pet_her2], piensas un poco en la historia que comparten."

# game/chapters/4_roomexplore.rpy:550
translate Spanish dog_hub4_6b0c7405:

    # "Just how did you come up with [pet_her] name, again?"
    "¿Cómo se te ocurrió ese nombre, otra vez?"

# game/chapters/4_roomexplore.rpy:556
translate Spanish dog_hub4_6f27dc4e:

    # "What best way to memorialize your favorite character but in pet form?"
    "¿Qué mejor manera de rendirle homenaje a tu personaje favorito que poniéndole su nombre a tu mascota?"

# game/chapters/4_roomexplore.rpy:557
translate Spanish dog_hub4_918b0e4c:

    # "You love both [pet_name]'s dearly."
    "Quieres muchísimo a ambos [pet_name]."

# game/chapters/4_roomexplore.rpy:561
translate Spanish dog_hub4_157b1c09:

    # "Sure, it's not very original, but it gets the job done."
    "Claro, no es muy original, pero cumple su función."

# game/chapters/4_roomexplore.rpy:562
translate Spanish dog_hub4_1218ce43:

    # "You can't think of [pet_name] being called anything other than [pet_name]."
    "No puedes imaginar que [pet_name] se llame de otra manera."

# game/chapters/4_roomexplore.rpy:566
translate Spanish dog_hub4_bb04072f:

    # "You didn't have any particular naming plan for [pet_her2]."
    "No tenías ningún plan concreto para ponerle nombre."

# game/chapters/4_roomexplore.rpy:567
translate Spanish dog_hub4_48ce966d:

    # "As soon as you saw [pet_her2], you knew the right name."
    "En cuanto l[letra_pet] viste, supiste cuál era el nombre perfecto."

# game/chapters/4_roomexplore.rpy:571
translate Spanish dog_hub4_e96bb619:

    # "You planned out [pet_her]'s name seven months in advance."
    "Planeaste su nombre con siete meses de anticipación."

# game/chapters/4_roomexplore.rpy:572
translate Spanish dog_hub4_c856f278:

    # "You always have been good at being prepared."
    "Siempre se te ha dado bien estar preparad[letra]."

# game/chapters/4_roomexplore.rpy:577
translate Spanish dog_hub4_520960c8:

    # "You lead [pet_name] to your bathroom and quickly get to giving [pet_her2] a scrub down."
    "Llevas a [pet_name] a tu baño y rápidamente te pones a darle un buen baño."

# game/chapters/4_roomexplore.rpy:578
translate Spanish dog_hub4_9c002b11:

    # "Luckily, [pet_name] LOVES bathes, and honestly would stay in there all day if [pet_she] could."
    "Afortunadamente, [pet_name] AMA los baños y, sinceramente, [pet_she!t] se quedaría allí todo el día si pudiera."

# game/chapters/4_roomexplore.rpy:579
translate Spanish dog_hub4_895918eb:

    # "After the bath, you spend a little time brushing [pet_name] - another favorite activity."
    "Después del baño, pasas un poco de tiempo cepillando a [pet_name] - otra actividad favorita."

# game/chapters/4_roomexplore.rpy:593
translate Spanish hamster_hub4_08ed904d:

    # "[pet_name] is hanging out on your bed at the moment."
    "[pet_name] está pasando el rato en tu cama en este momento."

# game/chapters/4_roomexplore.rpy:594
translate Spanish hamster_hub4_6c976065:

    # "As you sit down next to [pet_her2], you think a little bit on your shared history."
    "Mientras te sientas junto a [pet_her2], piensas un poco en la historia que comparten."

# game/chapters/4_roomexplore.rpy:595
translate Spanish hamster_hub4_6b0c7405:

    # "Just how did you come up with [pet_her] name, again?"
    "¿Cómo se te ocurrió ese nombre, otra vez?"

# game/chapters/4_roomexplore.rpy:601
translate Spanish hamster_hub4_6f27dc4e:

    # "What best way to memorialize your favorite character but in pet form?"
    "¿Qué mejor manera de rendirle homenaje a tu personaje favorito que poniéndole su nombre a tu mascota?"

# game/chapters/4_roomexplore.rpy:602
translate Spanish hamster_hub4_918b0e4c:

    # "You love both [pet_name]'s dearly."
    "Quieres muchísimo a ambos [pet_name]."

# game/chapters/4_roomexplore.rpy:606
translate Spanish hamster_hub4_157b1c09:

    # "Sure, it's not very original, but it gets the job done."
    "Claro, no es muy original, pero cumple su función."

# game/chapters/4_roomexplore.rpy:607
translate Spanish hamster_hub4_1218ce43:

    # "You can't think of [pet_name] being called anything other than [pet_name]."
    "No puedes imaginar que [pet_name] se llame de otra manera."

# game/chapters/4_roomexplore.rpy:611
translate Spanish hamster_hub4_bb04072f:

    # "You didn't have any particular naming plan for [pet_her2]."
    "No tenías ningún plan concreto para ponerle nombre."

# game/chapters/4_roomexplore.rpy:612
translate Spanish hamster_hub4_48ce966d:

    # "As soon as you saw [pet_her2], you knew the right name."
    "En cuanto l[letra_pet] viste, supiste cuál era el nombre perfecto."

# game/chapters/4_roomexplore.rpy:616
translate Spanish hamster_hub4_e96bb619:

    # "You planned out [pet_her]'s name seven months in advance."
    "Planeaste su nombre con siete meses de anticipación."

# game/chapters/4_roomexplore.rpy:617
translate Spanish hamster_hub4_c856f278:

    # "You always have been good at being prepared."
    "Siempre se te ha dado bien estar preparad[letra]."

# game/chapters/4_roomexplore.rpy:624
translate Spanish hamster_hub4_0a92517d:

    # "You spend the better part of the night cleaning out [pet_name]'s enclosure."
    "Pasas la mayor parte de la noche limpiando el recinto de [pet_name]."

# game/chapters/4_roomexplore.rpy:625
translate Spanish hamster_hub4_73cd42e1:

    # "You remove all of the bowls, accessories and bedding first, cleaning them as you go, then wash out the enclosure with hot, soapy water."
    "Primero retiras todos los cuencos, accesorios y el sustrato, limpiándolos a medida que avanzas, luego lavas el recinto con agua caliente y jabonosa."

# game/chapters/4_roomexplore.rpy:626
translate Spanish hamster_hub4_4dce3086:

    # "It's a bit of work, but you're pretty used to it."
    "Es un poco de trabajo, pero ya tienes bastante práctica."

# game/chapters/4_roomexplore.rpy:627
translate Spanish hamster_hub4_54c8936f:

    # "You also find it quite enjoyable to set up your hamster's enclosure again - there's something fun about it!"
    "También te resulta muy entretenido volver a montar el recinto de tu hámster - ¡tiene algo divertido!"

# game/chapters/4_roomexplore.rpy:646
translate Spanish plant_hub4_c1229c6a:

    # "You give your little sprout a big drink of water."
    "Le das a tu pequeño retoño un buen trago de agua."

# game/chapters/4_roomexplore.rpy:647
translate Spanish plant_hub4_c5de961c:

    # "Though you don't speak sprout, it seems to say thank you."
    "Aunque no hablas el idioma de los retoños, parece darte las gracias."

# game/chapters/4_roomexplore.rpy:649
translate Spanish plant_hub4_518e64fd:

    # "Your little sprout has grown some leaves!"
    "¡A tu pequeño retoño le han salido hojas!"

# game/chapters/4_roomexplore.rpy:650
translate Spanish plant_hub4_8036dce1:

    # "You can't help but feel proud as you give it a big drink of water."
    "No puedes evitar sentir orgullo mientras le das un gran trago de agua."

# game/chapters/4_roomexplore.rpy:652
translate Spanish plant_hub4_adaac543:

    # "Even more leaves have appeared now!"
    "¡Aún más hojas han aparecido ahora!"

# game/chapters/4_roomexplore.rpy:653
translate Spanish plant_hub4_a4970463:

    # "You water it generously and feel excited that, this time, you didn't kill your plant instantly."
    "La riegas abundantemente y te emociona comprobar que esta vez no has matado tu planta nada más empezar."

# game/chapters/4_roomexplore.rpy:655
translate Spanish plant_hub4_2087a70f:

    # "Your little plant is growing healthily!"
    "¡Tu pequeña planta está creciendo sana y fuerte!"

# game/chapters/4_roomexplore.rpy:656
translate Spanish plant_hub4_80d209cf:

    # "You give it a big drink of water, excited about its growth."
    "Le das un buen trago de agua, con entusiasmo por su crecimiento."

# game/chapters/4_roomexplore.rpy:671
translate Spanish plant_hub4_1c953138:

    # "Looking at the soil, you're sure more watering is needed."
    "Al mirar la tierra, estás segur[letra] de que hace falta más riego."

# game/chapters/4_roomexplore.rpy:672
translate Spanish plant_hub4_e3142f64:

    # "I mean, you're no soil expert, but you're certain it shouldn't be dry. At all."
    "Es decir, no es que entiendas de tierra, pero tienes claro que no debería estar seca. Para nada."

# game/chapters/4_roomexplore.rpy:673
translate Spanish plant_hub4_b01394aa:

    # "It should be at least a little moist, right?"
    "Debería estar al menos un poco húmeda, ¿verdad?"

# game/chapters/4_roomexplore.rpy:686
translate Spanish plant_hub4_9447ddf1:

    # "No, a little moist isn't enough."
    "No, un poco húmeda no es suficiente."

# game/chapters/4_roomexplore.rpy:687
translate Spanish plant_hub4_cf8752e1:

    # "This plant of yours should be in a swamp."
    "Esta planta tuya debería estar en un pantano."

# game/chapters/4_roomexplore.rpy:688
translate Spanish plant_hub4_f5489103:

    # "Nothing else will do. Nothing else is good enough."
    "Nada más servirá. Nada más es lo suficientemente bueno."

# game/chapters/4_roomexplore.rpy:689
translate Spanish plant_hub4_fadd62a1:

    # "You water, and water, then water some more."
    "Riegas y riegas, luego riegas un poco más."

# game/chapters/4_roomexplore.rpy:690
translate Spanish plant_hub4_06dbebee:

    # "It's still not enough."
    "Todavía no es suficiente."

# game/chapters/4_roomexplore.rpy:692
translate Spanish plant_hub4_a4ceddef:

    # "You only manage to catch yourself when you see your pet staring at you."
    "Solo te das cuenta cuando ves que tu mascota te está mirando fijamente."

# game/chapters/4_roomexplore.rpy:695
translate Spanish plant_hub4_84fb17ec:

    # "You only manage to catch yourself when you see [pet_name] staring at you."
    "Solo logras darte cuenta cuando ves que [pet_name] te está mirando fijamente."

# game/chapters/4_roomexplore.rpy:697
translate Spanish plant_hub4_fc0dba82:

    # "Whoops."
    "Uuups."

translate Spanish strings:

    # game/chapters/4_roomexplore.rpy:222
    old "1. Shallow, at most."
    new "1. Superficial, como mucho."

    # game/chapters/4_roomexplore.rpy:228
    old "2. The best you've had in years."
    new "2. Lo mejor que has tenido en años."

    # game/chapters/4_roomexplore.rpy:234
    old "3. Sleep? What's sleep?"
    new "3. ¿Dormir? ¿Qué es dormir?"

    # game/chapters/4_roomexplore.rpy:240
    old "1. Curious."
    new "1. Curiosidad."

    # game/chapters/4_roomexplore.rpy:244
    old "2. Attracted?"
    new "2. ¿Atracción?"

    # game/chapters/4_roomexplore.rpy:250
    old "3. Excited."
    new "3. Emoción."

    # game/chapters/4_roomexplore.rpy:304
    old "2. Leave them alone."
    new "2. Dejarlos en paz."

    # game/chapters/4_roomexplore.rpy:375
    old "1. You named [pet_her2] after your favorite character."
    new "1. Le pusiste el nombre de tu personaje favorito."

    # game/chapters/4_roomexplore.rpy:380
    old "2. You looked up a list of '100 best animal names'."
    new "2. Buscaste una lista de 'los 100 mejores nombres de animales'."

    # game/chapters/4_roomexplore.rpy:385
    old "3. It came to you on a whim."
    new "3. Se te ocurrió de repente."

    # game/chapters/4_roomexplore.rpy:390
    old "4. You thought about it for ages."
    new "4. Lo pensaste durante mucho tiempo."

    # game/chapters/4_roomexplore.rpy:397
    old "Clean out [pet_name]'s enclosure."
    new "Limpiar el recinto de [pet_name]."

    # game/chapters/4_roomexplore.rpy:441
    old "Groom [pet_name]."
    new "Asear a [pet_name]."

    # game/chapters/4_roomexplore.rpy:720
    old "{i}Rovari{/i}"
    new "{i}Rovari{/i}"

    # game/chapters/4_roomexplore.rpy:736
    old "You are akin to the moon, and the stars, and the oceans,"
    new "Eres como la luna, las estrellas y los océanos,"

    # game/chapters/4_roomexplore.rpy:737
    old "Boundless and free, shining and deep."
    new "Infinita y libre, brillante y profunda."

    # game/chapters/4_roomexplore.rpy:738
    old "You illuminate the darkness and cradle the light,"
    new "Iluminas la oscuridad y acunas la luz,"

    # game/chapters/4_roomexplore.rpy:739
    old "You rise and fall and follow your own path through the night."
    new "Te elevas y caes, siguiendo tu propio camino a través de la noche."

    # game/chapters/4_roomexplore.rpy:740
    old "With a bottomless heart, you help those in need,"
    new "Con un corazón sin fondo, ayudas a quienes lo necesitan,"

    # game/chapters/4_roomexplore.rpy:741
    old "Even when such actions may cause you to bleed."
    new "Incluso cuando esas acciones pueden hacerte sangrar."

    # game/chapters/4_roomexplore.rpy:742
    old "So shine brightly, and embrace the unknown,"
    new "Así que brilla con fuerza y abraza lo desconocido,"

    # game/chapters/4_roomexplore.rpy:743
    old "For in that magic, you find your own."
    new "Porque en esa magia, encuentras la tuya propia."

