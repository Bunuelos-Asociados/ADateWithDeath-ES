# TODO: Translation updated at 2026-10-15 18:36

# game/chapters/bad_end.rpy:5
translate Spanish badend_start_d41d8cd9:

    # nvl clear
    nvl clear

# game/chapters/bad_end.rpy:16
translate Spanish badend_start_9b66546a:

    # center_text "You once again spent the day mostly at home, but..."
    center_text "Una vez más pasaste el día mayormente en casa, pero..."

# game/chapters/bad_end.rpy:17
translate Spanish badend_start_592b60ec:

    # center_text "Since you woke up, you've been feeling a little strange."
    center_text "Desde que despertaste, te has sentido un poco extrañ[letra]."

# game/chapters/bad_end.rpy:18
translate Spanish badend_start_4abb1dce:

    # center_text "Off-balance, perhaps."
    center_text "Fuera de equilibrio, quizá."

# game/chapters/bad_end.rpy:19
translate Spanish badend_start_8ace40da:

    # center_text "Not only that, but [pet_name] was also acting a bit off. A little sluggish."
    center_text "Y no solo eso: [pet_name] también se comportaba de forma extraña. Estaba un poco aletargad[letra_pet]."

# game/chapters/bad_end.rpy:20
translate Spanish badend_start_78fe50ea:

    # center_text "You had a quick trip to the vet, but they found nothing wrong with [pet_her2]."
    center_text "Hiciste una visita rápida al veterinario, pero no encontraron nada malo en [pet_she!t]."

# game/chapters/bad_end.rpy:21
translate Spanish badend_start_372bbfaa:

    # center_text "So, you've stayed by [pet_name]'s side, trying your best to will [pet_her2] to good health."
    center_text "Así que te has quedado al lado de [pet_name], haciendo todo lo posible para que se recupere con la fuerza de tu voluntad."

# game/chapters/bad_end.rpy:59
translate Spanish day7_start_badend_fc4f3f0e:

    # player "Not to alarm you or anything, but I think something's... wrong."
    player "No quiero alarmarte ni nada, pero creo que algo está... mal."

# game/chapters/bad_end.rpy:62
translate Spanish day7_start_badend_3704a528:

    # player "Um..."
    player "Eh..."

# game/chapters/bad_end.rpy:65
translate Spanish day7_start_badend_6891127e:

    # player "I'm starting to freak out a bit..."
    player "Estoy empezando a asustarme un poco..."

# game/chapters/bad_end.rpy:68
translate Spanish day7_start_badend_97a9d6f5:

    # player "My plant just... died."
    player "Mi planta simplemente... murió."

# game/chapters/bad_end.rpy:69
translate Spanish day7_start_badend_70c3d462:

    # GR "your plant? did you not water it?"
    GR "¿tu planta? ¿no la regaste?"

# game/chapters/bad_end.rpy:72
translate Spanish day7_start_badend_c5e75e2b:

    # player "Of course I did."
    player "Por supuesto que sí."

# game/chapters/bad_end.rpy:76
translate Spanish day7_start_badend_3af3ab6b:

    # player "It was fine yesterday."
    player "Ayer estaba bien."

# game/chapters/bad_end.rpy:79
translate Spanish day7_start_badend_d29a2450:

    # player "Why would it suddenly shrivel up overnight?"
    player "¿Por qué de repente se marchitaría de la noche a la mañana?"

# game/chapters/bad_end.rpy:81
translate Spanish day7_start_badend_3f1be4aa:

    # GR "perhaps too much water? i do not know much about keeping plants."
    GR "¿quizá demasiada agua? no sé mucho sobre cuidar plantas."

# game/chapters/bad_end.rpy:84
translate Spanish day7_start_badend_1ca5a80a:

    # player "And [pet_name] is sick again."
    player "Y [pet_name] se enfermó otra vez."

# game/chapters/bad_end.rpy:85
translate Spanish day7_start_badend_8ede3c01:

    # GR "what?"
    GR "¿qué?"

# game/chapters/bad_end.rpy:86
translate Spanish day7_start_badend_7c2d79f2:

    # GR "are you unwell too?"
    GR "¿tú también te sientes mal?"

# game/chapters/bad_end.rpy:89
translate Spanish day7_start_badend_828c4437:

    # player "I think I'm alright?"
    player "Creo que estoy bien, ¿no?"

# game/chapters/bad_end.rpy:91
translate Spanish day7_start_badend_22e1a291:

    # player "No, I'm totally fine..."
    player "No, estoy totalmente bien..."

# game/chapters/bad_end.rpy:94
translate Spanish day7_start_badend_cae94362:

    # player "Just stressed about [pet_name]."
    player "Solo estoy estresad[letra] por [pet_name]."

# game/chapters/bad_end.rpy:96
translate Spanish day7_start_badend_9d36256c:

    # GR "not that i think you should use your 'talent' so much, but have you tried...?"
    GR "no es que crea que deberías usar tanto tu 'talento', pero ¿has intentado...?"

# game/chapters/bad_end.rpy:99
translate Spanish day7_start_badend_fc3b5e7e:

    # player "Of course I have. I've been trying all morning."
    player "Por supuesto que sí. He estado intentándolo toda la mañana."

# game/chapters/bad_end.rpy:101
translate Spanish day7_start_badend_ee4f773f:

    # player "It's all I've done today."
    player "Es todo lo que he hecho hoy."

# game/chapters/bad_end.rpy:104
translate Spanish day7_start_badend_d3fc1410:

    # player "And it's not working."
    player "Y no está funcionando."

# game/chapters/bad_end.rpy:107
translate Spanish day7_start_badend_56ecd767:

    # player "Are you positive I can really... heal things like that?"
    player "¿Estás seguro de que realmente puedo... sanar cosas así?"

# game/chapters/bad_end.rpy:108
translate Spanish day7_start_badend_db9c2be2:

    # GR "i felt it sunshine, i'm pretty sure."
    GR "lo sentí, solecito, estoy bastante seguro."

# game/chapters/bad_end.rpy:109
translate Spanish day7_start_badend_7d131b5f:

    # GR "i am correct 99 percent of the time, after all." id day7_start_badend_7d131b5f
    GR "al fin y al cabo, tengo razón el 99 por ciento del tiempo." id day7_start_badend_7d131b5f

# game/chapters/bad_end.rpy:112
translate Spanish day7_start_badend_fa758fc3:

    # player "And you? How do {i}you{/i} feel?"
    player "¿Y tú? ¿Cómo te sientes {i}tú{/i}?"

# game/chapters/bad_end.rpy:113
translate Spanish day7_start_badend_ad6c7f8d:

    # GR "fine."
    GR "bien."

# game/chapters/bad_end.rpy:114
translate Spanish day7_start_badend_af99844c:

    # GR "well, my body is fine. my mind has taken a beating from lack of sleep last night..."
    GR "bueno, mi cuerpo está bien. mi mente ha recibido una paliza por la falta de sueño anoche..."

# game/chapters/bad_end.rpy:117
translate Spanish day7_start_badend_95eae8c9:

    # player "[pet_She] doesn't even want to eat [pet_her] favorite treats."
    player "[pet_She!t] ni siquiera quiere comer sus golosinas favoritas."

# game/chapters/bad_end.rpy:118
translate Spanish day7_start_badend_a7d2a095:

    # GR "hmm. perhaps there is some limit to the amount of your soul you can give away in a short period of time."
    GR "hmm. tal vez haya un límite en la cantidad de tu alma que puedes entregar en un corto período de tiempo."

# game/chapters/bad_end.rpy:121
translate Spanish day7_start_badend_b37e2154:

    # player "Well... if you say so."
    player "Bueno... si tú lo dices."

# game/chapters/bad_end.rpy:124
translate Spanish day7_start_badend_210514d3:

    # player "I hope you're right."
    player "Espero que tengas razón."

# game/chapters/bad_end.rpy:127
translate Spanish day7_start_badend_55d8a27a:

    # player "I'll... try again later."
    player "Lo... intentaré de nuevo más tarde."

# game/chapters/bad_end.rpy:128
translate Spanish day7_start_badend_59560e6f:

    # GR "you might just need to replenish some energy."
    GR "quizá solo necesites reponer algo de energía."

# game/chapters/bad_end.rpy:129
translate Spanish day7_start_badend_bacf4da5:

    # GR "have you eaten?"
    GR "¿has comido?"

# game/chapters/bad_end.rpy:132
translate Spanish day7_start_badend_c969faaf:

    # player "Yes, of course I have."
    player "Sí, por supuesto que sí."

# game/chapters/bad_end.rpy:135
translate Spanish day7_start_badend_2bd0e441:

    # player "But I did forget to grab a drink."
    player "Pero olvidé tomar algo de beber."

# game/chapters/bad_end.rpy:136
translate Spanish day7_start_badend_a50e9834:

    # GR "go. drink some water. it will do you good."
    GR "ve. bebe un poco de agua. te hará bien."

# game/chapters/bad_end.rpy:139
translate Spanish day7_start_badend_c0c4c6af:

    # player "Right now?"
    player "¿Ahora mismo?"

# game/chapters/bad_end.rpy:140
translate Spanish day7_start_badend_1097ad3b:

    # GR "yes, right now. go on."
    GR "sí, ahora mismo. anda."

# game/chapters/bad_end.rpy:143
translate Spanish day7_start_badend_09f03f38:

    # player "Yes boss... I'll brb."
    player "Sí, jefe... ya vuelvo."

# game/chapters/bad_end.rpy:145
translate Spanish day7_start_badend_01b0c35d:

    # player "Not yet, no."
    player "Aún no, no."

# game/chapters/bad_end.rpy:148
translate Spanish day7_start_badend_83b16343:

    # player "I'll get something soon though."
    player "Pero conseguiré algo pronto."

# game/chapters/bad_end.rpy:151
translate Spanish day7_start_badend_23fdd22e:

    # player "I'm getting a bit hungry now that you mention it."
    player "Me está dando un poco de hambre ahora que lo mencionas."

# game/chapters/bad_end.rpy:152
translate Spanish day7_start_badend_0e2e4ce6:

    # GR "then eat. it is not good to ignore your body."
    GR "entonces come. no es bueno ignorar tu cuerpo."

# game/chapters/bad_end.rpy:155
translate Spanish day7_start_badend_9d2cf585:

    # player "But I'm talking with you."
    player "Pero estoy hablando contigo."

# game/chapters/bad_end.rpy:156
translate Spanish day7_start_badend_fd471719:

    # GR "which you can do after you have eaten."
    GR "lo cual puedes hacer después de haber comido."

# game/chapters/bad_end.rpy:157
translate Spanish day7_start_badend_36119ac7:

    # GR "and had a drink of water. go on."
    GR "y de haber tomado agua. anda."

# game/chapters/bad_end.rpy:160
translate Spanish day7_start_badend_60c79953:

    # player "Yeah okay. I'm on it."
    player "Sí, okey. Ya voy."

# game/chapters/bad_end.rpy:163
translate Spanish day7_start_badend_540d0a6c:

    # player "Alright bossy boots."
    player "Está bien, mandón."

# game/chapters/bad_end.rpy:166
translate Spanish day7_start_badend_e1579e34:

    # player "What a worrywart you've turned out to be."
    player "Qué preocupón resultaste ser."

# game/chapters/bad_end.rpy:167
translate Spanish day7_start_badend_e3726825:

    # GR "wait, what did you just call me..."
    GR "espera, ¿cómo me acabas de llamar...?"

# game/chapters/bad_end.rpy:171
translate Spanish day7_start_badend_78825d93:

    # player "Bossy boots."
    player "Mandón."

# game/chapters/bad_end.rpy:172
translate Spanish day7_start_badend_5cff57dd:

    # GR "...i meant the other thing. bossy, i can accept."
    GR "...me refería a lo otro. lo de 'mandón' lo acepto."

# game/chapters/bad_end.rpy:176
translate Spanish day7_start_badend_b6d0bfb1:

    # player "A worrywart."
    player "Preocupón."

# game/chapters/bad_end.rpy:178
translate Spanish day7_start_badend_76f1d525:

    # GR "what the... that makes me sound like some fussing housewife."
    GR "¿qué demonios...? eso me hace sonar como un ama de casa quisquillosa."

# game/chapters/bad_end.rpy:181
translate Spanish day7_start_badend_65db04cd:

    # player "Ha."
    player "Ja."

# game/chapters/bad_end.rpy:184
translate Spanish day7_start_badend_313285f3:

    # player "You kinda are. BRB."
    player "Un poco lo eres. Ya vuelvo."

# game/chapters/bad_end.rpy:187
translate Spanish day7_start_badend_25b2ab8a:

    # player "Oops... no. I forgot."
    player "Ups... no. Lo olvidé."

# game/chapters/bad_end.rpy:190
translate Spanish day7_start_badend_818585bb:

    # player "I guess I was too distracted with everything going on today..."
    player "Supongo que estaba demasiado distraíd[letra] con todo lo que pasa hoy..."

# game/chapters/bad_end.rpy:193
translate Spanish day7_start_badend_d236b2b6:

    # player "I will soon."
    player "Lo haré pronto."

# game/chapters/bad_end.rpy:194
translate Spanish day7_start_badend_768dc623:

    # GR "soon is not good enough."
    GR "pronto no es suficiente."

# game/chapters/bad_end.rpy:195
translate Spanish day7_start_badend_5f0d8b93:

    # GR "do you often forget to eat?"
    GR "¿olvidas comer a menudo?"

# game/chapters/bad_end.rpy:198
translate Spanish day7_start_badend_c778c7fd:

    # player "Yeah, all the time."
    player "Sí, todo el tiempo."

# game/chapters/bad_end.rpy:199
translate Spanish day7_start_badend_755dd737:

    # GR "i shall remind you then."
    GR "entonces te recordaré."

# game/chapters/bad_end.rpy:200
translate Spanish day7_start_badend_dd307926:

    # GR "go get something now."
    GR "ve a buscar algo ahora."

# game/chapters/bad_end.rpy:203
translate Spanish day7_start_badend_889cc230:

    # player "What? I'm fine."
    player "¿Qué? Estoy bien."

# game/chapters/bad_end.rpy:204
translate Spanish day7_start_badend_5906af53:

    # GR "shoo. it is food time, mortal."
    GR "fuera. es hora de comer, mortal."

# game/chapters/bad_end.rpy:205
translate Spanish day7_start_badend_dd973f1c:

    # GR "come back when you've eaten."
    GR "vuelve cuando hayas comido."

# game/chapters/bad_end.rpy:209
translate Spanish day7_start_badend_876680f1:

    # player "So demanding..."
    player "Tan exigente..."

# game/chapters/bad_end.rpy:212
translate Spanish day7_start_badend_dc850466:

    # player "Fine. I'll be right back!"
    player "Bien. ¡Ya vuelvo!"

# game/chapters/bad_end.rpy:215
translate Spanish day7_start_badend_196b3fcd:

    # player "Nah. I think I'm just stressed out."
    player "Nah. Creo que solo estoy estresad[letra]."

# game/chapters/bad_end.rpy:218
translate Spanish day7_start_badend_cf61fb1b:

    # player "I'll grab something now."
    player "Iré a buscar algo ahora."

# game/chapters/bad_end.rpy:220
translate Spanish day7_start_badend_5f5a5df7:

    # GR "good little mortal."
    GR "[buen] mortalcit[letra]."

# game/chapters/bad_end.rpy:223
translate Spanish day7_start_badend_20a0d775:

    # player "I'll be right back!"
    player "¡Ya vuelvo!"

# game/chapters/bad_end.rpy:237
translate Spanish day7_start_badend_aed80d74:

    # "You step away from your computer and head to your kitchen for a quick snack and some water."
    "Te alejas de tu computadora y vas a la cocina por algo rápido de comer y un poco de agua."

# game/chapters/bad_end.rpy:238
translate Spanish day7_start_badend_5579689f:

    # "Though they make your stomach feel slightly less empty, you now notice something else."
    "Aunque hacen que tu estómago se sienta un poco menos vacío, ahora notas otra cosa."

# game/chapters/bad_end.rpy:239
translate Spanish day7_start_badend_9def2203:

    # "A strange darkness in the corners of your vision... was that there before?"
    "Una extraña oscuridad en los bordes de tu visión... ¿estaba ahí antes?"

# game/chapters/bad_end.rpy:240
translate Spanish day7_start_badend_ea11c52d:

    # "You shake your head and go back to [pet_name]. [pet_She] is still looking a little bit sickly."
    "Sacudes la cabeza y vuelves con [pet_name]. [pet_She!t] todavía parece un poco débil."

# game/chapters/bad_end.rpy:241
translate Spanish day7_start_badend_6eed09cb:

    # "You kneel down in front of [pet_her2] and concentrate as hard as you can - concentrate on your wish."
    "Te arrodillas frente a [pet_she!t] y te concentras con todas tus fuerzas... te concentras en tu deseo."

# game/chapters/bad_end.rpy:242
translate Spanish day7_start_badend_7f31ca5b:

    # "Your head throbs a little, but nothing else happens."
    "Tu cabeza late un poco, pero no pasa nada más."

# game/chapters/bad_end.rpy:243
translate Spanish day7_start_badend_ec690227:

    # "So you try again. And again. And one more time, for good measure."
    "Así que lo intentas de nuevo. Y otra vez. Y una vez más, por si acaso."

# game/chapters/bad_end.rpy:244
translate Spanish day7_start_badend_90cedd77:

    # "You feel slightly faint, but nothing else is obviously changing."
    "Sientes un poco de mareo, pero nada parece cambiar visiblemente."

# game/chapters/bad_end.rpy:245
translate Spanish day7_start_badend_9078101a:

    # "With a sigh, you go back to your computer."
    "Con un suspiro, vuelves a tu computadora."

# game/chapters/bad_end.rpy:273
translate Spanish day7_start_badend_78ae02db:

    # player "I'm back, are you happy now?"
    player "He vuelto, ¿feliz ahora?"

# game/chapters/bad_end.rpy:274
translate Spanish day7_start_badend_e6d167b4:

    # GR "to be honest, yes i am happier if you are eating properly."
    GR "para ser honesto, sí soy más feliz si estás comiendo bien."

# game/chapters/bad_end.rpy:275
translate Spanish day7_start_badend_946b4443:

    # GR "it is a stupid thing to be happy about when i have to kill you and take your soul, but that is... unimportant."
    GR "es una tontería alegrarse porque tengo que matarte y tomar tu alma, pero eso es... irrelevante."

# game/chapters/bad_end.rpy:278
translate Spanish day7_start_badend_c498bcf3:

    # player "I tried to help [pet_name] again, too."
    player "También intenté ayudar a [pet_name] otra vez."

# game/chapters/bad_end.rpy:280
translate Spanish day7_start_badend_5d758716:

    # GR "you tried again? that quickly?!"
    GR "¿intentaste de nuevo? ¿tan pronto?"

# game/chapters/bad_end.rpy:283
translate Spanish day7_start_badend_c5e75e2b_1:

    # player "Of course I did."
    player "Por supuesto que sí."

# game/chapters/bad_end.rpy:286
translate Spanish day7_start_badend_89acbb49:

    # player "I told you I'll always try hard for [pet_her2]"
    player "Te dije que siempre haría mi mejor esfuerzo por [pet_she!t]."

# game/chapters/bad_end.rpy:287
translate Spanish day7_start_badend_d1e891c1:

    # GR "answer this immediately."
    GR "responde esto de inmediato."

# game/chapters/bad_end.rpy:321
translate Spanish call1_daybadend_437abfb9:

    # GRC "You are seriously the biggest idiot I know."
    GRC "En serio, eres el mayor idiota que conozco."

# game/chapters/bad_end.rpy:324
translate Spanish call1_daybadend_b07ce025:

    # GRC "Está bien. Yes, I suppose it is rude. But you know what?"
    GRC "Está bien. Sí, supongo que es grosero. Pero ¿sabes qué?"

# game/chapters/bad_end.rpy:325
translate Spanish call1_daybadend_c4d4f270:

    # GRC "It is also true."
    GRC "También es verdad."

# game/chapters/bad_end.rpy:328
translate Spanish call1_daybadend_1ba0f88a:

    # GRC "At least give yourself some time..."
    GRC "Al menos date algo de tiempo..."

# game/chapters/bad_end.rpy:336
translate Spanish call1_daybadend_6dd87f95:

    # GRC "Makes you sick?"
    GRC "¿Te enferma?"

# game/chapters/bad_end.rpy:337
translate Spanish call1_daybadend_050fcf84:

    # GRC "If you give all your soul away, you won't be sick."
    GRC "Si entregas toda tu alma, no te enfermarás."

# game/chapters/bad_end.rpy:340
translate Spanish call1_daybadend_f3130d22:

    # GRC "You'll be gone."
    GRC "Desaparecerás."

# game/chapters/bad_end.rpy:342
translate Spanish call1_daybadend_4e0180b7:

    # GRC "Not even dead. Just... gone."
    GRC "Ni siquiera estarás muert[letra]. Simplemente... ya no estarás."

# game/chapters/bad_end.rpy:347
translate Spanish call1_daybadend_24308b39:

    # GRC "You've gotta be more careful."
    GRC "Tienes que tener más cuidado."

# game/chapters/bad_end.rpy:355
translate Spanish call1_daybadend_d4b53a19:

    # GRC "If there is anyone you should be sorry to, it should be yourself."
    GRC "Si hay alguien a quien deberías pedirle perdón, es a ti."

# game/chapters/bad_end.rpy:357
translate Spanish call1_daybadend_47952b8e:

    # GRC "Are you sure you're feeling well?"
    GRC "¿Estás bien de verdad?"

# game/chapters/bad_end.rpy:363
translate Spanish call1_daybadend_78950dc1:

    # GRC "...Sunshine?" id call1_daybadend_78950dc1
    GRC "...¿Solecito?" id call1_daybadend_78950dc1

# game/chapters/bad_end.rpy:372
translate Spanish call1_daybadend_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/bad_end.rpy:374
translate Spanish call1_daybadend_0e06ec48:

    # GRC "Close your eyes."
    GRC "Cierra los ojos."

# game/chapters/bad_end.rpy:375
translate Spanish call1_daybadend_54914837:

    # GRC "You still have part of my soul within you, for better or worse."
    GRC "Aún tienes parte de mi alma dentro de ti, para bien o para mal."

# game/chapters/bad_end.rpy:376
translate Spanish call1_daybadend_6e95738f:

    # GRC "I will use it to check your soul more closely."
    GRC "La usaré para examinar tu alma más de cerca."

# game/chapters/bad_end.rpy:384
translate Spanish call1_daybadend_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/bad_end.rpy:385
translate Spanish call1_daybadend_068bddd6:

    # GRC "This... can't be right..."
    GRC "Esto... no puede ser verdad..."

# game/chapters/bad_end.rpy:391
translate Spanish call1_daybadend_2d0e002a:

    # GRC "Stay still and keep your eyes shut. I'm concentrating."
    GRC "No te muevas y mantén los ojos cerrados. Estoy concentrándome."

# game/chapters/bad_end.rpy:392
translate Spanish call1_daybadend_55bdc250:

    # GRC "......"
    GRC "......"

# game/chapters/bad_end.rpy:393
translate Spanish call1_daybadend_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/bad_end.rpy:394
translate Spanish call1_daybadend_e699174f:

    # GRC "Open up."
    GRC "Abre los ojos."

# game/chapters/bad_end.rpy:408
translate Spanish call1_daybadend_87c6dc70:

    # GRC "How many times did you try to heal your pet?"
    GRC "¿Cuántas veces intentaste sanar a tu mascota?"

# game/chapters/bad_end.rpy:414
translate Spanish call1_daybadend_9467829c:

    # GRC "....."
    GRC "....."

# game/chapters/bad_end.rpy:415
translate Spanish call1_daybadend_29f7e139:

    # GRC "I would say something was changing, because now your soul is barely a flicker."
    GRC "Diría que algo estaba cambiando, porque ahora tu alma apenas brilla."

# game/chapters/bad_end.rpy:424
translate Spanish call1_daybadend_f26ff6d4:

    # GRC "It could if you were doing it constantly, all day."
    GRC "Podría pasar si lo hicieras constantemente, todo el día."

# game/chapters/bad_end.rpy:425
translate Spanish call1_daybadend_ff3aa4a6:

    # GRC "Mortal, stay there. I will make my way to your abode this instant."
    GRC "Mortal, quédate ahí. Iré a tu morada en este instante."

# game/chapters/bad_end.rpy:432
translate Spanish call1_daybadend_70aaad38:

    # GRC "It is an urgent matter."
    GRC "Es un asunto urgente."

# game/chapters/bad_end.rpy:444
translate Spanish call1_daybadend_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/bad_end.rpy:445
translate Spanish call1_daybadend_65c01572:

    # GRC "Hang in there, okay?"
    GRC "Aguanta, ¿okey?"

# game/chapters/bad_end.rpy:467
translate Spanish chat2_daybadend_b9c60c4c:

    # "{i}You once again stand up from your desk, but this time you feel much more shaky on your feet.{/i}" id chat2_daybadend_b9c60c4c
    "{i}Una vez más te levantas de tu escritorio, pero esta vez te sientes mucho más inestable sobre tus pies.{/i}" id chat2_daybadend_b9c60c4c

# game/chapters/bad_end.rpy:468
translate Spanish chat2_daybadend_4d462333:

    # "{i}Your vision is going in and out of focus...{/i}" id chat2_daybadend_4d462333
    "{i}Tu visión va y viene, desenfocada...{/i}" id chat2_daybadend_4d462333

# game/chapters/bad_end.rpy:469
translate Spanish chat2_daybadend_0f95e53d:

    # "{i}Something isn't right. Now, you're sure of that.{/i}" id chat2_daybadend_0f95e53d
    "{i}Algo no está bien. Ahora estás segur[letra] de ello.{/i}" id chat2_daybadend_0f95e53d

# game/chapters/bad_end.rpy:470
translate Spanish chat2_daybadend_47a0a03d:

    # "{i}However, turning to look at [pet_name]... [pet_she]'s perked right up.{/i}" id chat2_daybadend_47a0a03d
    "{i}Sin embargo, al girarte para mirar a [pet_name]... [pet_she!t] se animó de inmediato.{/i}" id chat2_daybadend_47a0a03d

# game/chapters/bad_end.rpy:471
translate Spanish chat2_daybadend_11a2f5bc:

    # "{i}'Ah,' you think. 'Everything is okay now.'{/i}" id chat2_daybadend_11a2f5bc
    "{i}'Ah', piensas. 'Todo está bien ahora.'{/i}" id chat2_daybadend_11a2f5bc

# game/chapters/bad_end.rpy:472
translate Spanish chat2_daybadend_6f0a0332:

    # "{i}You sit down on the edge of your bed.{/i}" id chat2_daybadend_6f0a0332
    "{i}Te sientas al borde de la cama.{/i}" id chat2_daybadend_6f0a0332

# game/chapters/bad_end.rpy:473
translate Spanish chat2_daybadend_c07a31f7:

    # "{i}And you wait.{/i}" id chat2_daybadend_c07a31f7
    "{i}Y esperas.{/i}" id chat2_daybadend_c07a31f7

# game/chapters/bad_end.rpy:474
translate Spanish chat2_daybadend_cd886038:

    # "{i}It doesn't take long for your window to be pulled open.{/i}" id chat2_daybadend_cd886038
    "{i}No pasa mucho tiempo antes de que tu ventana se abra de golpe.{/i}" id chat2_daybadend_cd886038

# game/chapters/bad_end.rpy:496
translate Spanish chat2_daybadend_b1599809:

    # GRC "Sunshine!" id chat2_daybadend_b1599809
    GRC "¡Solecito!" id chat2_daybadend_b1599809

# game/chapters/bad_end.rpy:497
translate Spanish chat2_daybadend_09ce10e5:

    # "{i}You hear his voice. You see him standing in your room.{/i}" id chat2_daybadend_09ce10e5
    "{i}Escuchas su voz. Lo ves de pie en tu habitación.{/i}" id chat2_daybadend_09ce10e5

# game/chapters/bad_end.rpy:498
translate Spanish chat2_daybadend_27b5d404:

    # "{i}Why does that seem so natural?{/i}" id chat2_daybadend_27b5d404
    "{i}¿Por qué eso te parece tan natural?{/i}" id chat2_daybadend_27b5d404

# game/chapters/bad_end.rpy:499
translate Spanish chat2_daybadend_ef7b3a7b:

    # "{i}Your vision is blurry and you feel faint.{/i}" id chat2_daybadend_ef7b3a7b
    "{i}Tu visión está borrosa y te sientes débil.{/i}" id chat2_daybadend_ef7b3a7b

# game/chapters/bad_end.rpy:500
translate Spanish chat2_daybadend_a4ae37dc:

    # "{i}You try to get to your feet, but stumble.{/i}" id chat2_daybadend_a4ae37dc
    "{i}Intentas ponerte de pie, pero tropiezas.{/i}" id chat2_daybadend_a4ae37dc

# game/chapters/bad_end.rpy:501
translate Spanish chat2_daybadend_5e010af2:

    # "{i}Casper catches you.{/i}" id chat2_daybadend_5e010af2
    "{i}Casper te atrapa.{/i}" id chat2_daybadend_5e010af2

# game/chapters/bad_end.rpy:506
translate Spanish chat2_daybadend_a17a50dc:

    # GRC "Hey!"
    GRC "¡Oye!"

# game/chapters/bad_end.rpy:507
translate Spanish chat2_daybadend_20222fcc:

    # GRC "Nine hells, this is worse than I thought..."
    GRC "Nueve infiernos, esto está peor de lo que pensaba..."

# game/chapters/bad_end.rpy:508
translate Spanish chat2_daybadend_931eae65:

    # GRC "Come on, everything's going to be alright. Lets get you sitting down, okay?"
    GRC "Vamos, todo va a estar bien. Vamos a sentarte, ¿okey?"

# game/chapters/bad_end.rpy:515
translate Spanish chat2_daybadend_04c207dd:

    # GRC "Don't start spouting nonsense now. It's time for you to rest."
    GRC "No empieces a decir tonterías ahora. Es hora de que descanses."

# game/chapters/bad_end.rpy:525
translate Spanish chat2_daybadend_36b769e2:

    # GRC "I win?"
    GRC "¿Gané?"

# game/chapters/bad_end.rpy:531
translate Spanish chat2_daybadend_8da23161:

    # GRC "...."
    GRC "...."

# game/chapters/bad_end.rpy:546
translate Spanish chat2_daybadend_9ecac4e5:

    # GRC "Don't... don't be absurd."
    GRC "No... no digas tonterías."

# game/chapters/bad_end.rpy:547
translate Spanish chat2_daybadend_8bf0801b:

    # GRC "I lost. Your soul is yours. You can take mine."
    GRC "Perdí. Tu alma es tuya. Puedes tomar la mía."

# game/chapters/bad_end.rpy:562
translate Spanish chat2_daybadend_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/bad_end.rpy:563
translate Spanish chat2_daybadend_30e2e461:

    # GRC "Sunshine, I can't..." id chat2_daybadend_30e2e461
    GRC "Solecito, no puedo..." id chat2_daybadend_30e2e461

# game/chapters/bad_end.rpy:564
translate Spanish chat2_daybadend_f39c2034:

    # GRC "I told you... I told you yesterday, I..."
    GRC "Te lo dije... te lo dije ayer, yo..."

# game/chapters/bad_end.rpy:565
translate Spanish chat2_daybadend_649555b4:

    # GRC "Have come to... care for you too much. I couldn't..."
    GRC "He llegado a... sentir demasiado cariño por ti. No podría..."

# game/chapters/bad_end.rpy:571
translate Spanish chat2_daybadend_0bac6bac:

    # GRC "......."
    GRC "......."

# game/chapters/bad_end.rpy:572
translate Spanish chat2_daybadend_4ee55eb5:

    # GRC "This isn't fair."
    GRC "Esto no es justo."

# game/chapters/bad_end.rpy:579
translate Spanish chat2_daybadend_8da23161_1:

    # GRC "...."
    GRC "...."

# game/chapters/bad_end.rpy:580
translate Spanish chat2_daybadend_dae51e15:

    # GRC "I... I'll take you to the best afterlife. I promise."
    GRC "Yo... te llevaré al mejor más allá. Lo prometo."

# game/chapters/bad_end.rpy:581
translate Spanish chat2_daybadend_5639426c:

    # GRC "You'll never want for anything."
    GRC "Nunca te faltará nada."

# game/chapters/bad_end.rpy:583
translate Spanish chat2_daybadend_b52a11ac:

    # "{i}The room is spinning now. Words are difficult to hear.{/i}" id chat2_daybadend_b52a11ac
    "{i}La habitación gira ahora. Las palabras son difíciles de oír.{/i}" id chat2_daybadend_b52a11ac

# game/chapters/bad_end.rpy:584
translate Spanish chat2_daybadend_12d2f3be:

    # "{i}'So this is what dying feels like,' you think. 'At least [pet_name] is okay...'{/i}" id chat2_daybadend_12d2f3be
    "{i}'Así que esto es lo que se siente morir', piensas. 'Al menos [pet_name] está bien...'{/i}" id chat2_daybadend_12d2f3be

# game/chapters/bad_end.rpy:591
translate Spanish chat2_daybadend_25f43cbc:

    # GRC "Of... of course..."
    GRC "Por... por supuesto..."

# game/chapters/bad_end.rpy:614
translate Spanish badend_afterending_8fdfd7c2:

    # "A lone reapers sits in his bedroom."
    "Una parca solitaria se sienta en su habitación."

# game/chapters/bad_end.rpy:615
translate Spanish badend_afterending_71d4f8b8:

    # "He holds Azrael close as tears run down his cheeks."
    "Sostiene a Azrael entre sus brazos mientras las lágrimas corren por sus mejillas."

# game/chapters/bad_end.rpy:616
translate Spanish badend_afterending_36115f5a:

    # "Casper never knew what love felt like until he met [playerfirstname]."
    "Casper nunca supo lo que era el amor hasta que conoció a [playerfirstname]."

# game/chapters/bad_end.rpy:617
translate Spanish badend_afterending_203f06d3:

    # "Their souls had connected in a way he thought he'd never feel again."
    "Sus almas se habían conectado de una forma que él creyó que nunca volvería a sentir."

# game/chapters/bad_end.rpy:618
translate Spanish badend_afterending_6a1ef054:

    # "And now [playerfirstname] was gone."
    "Y ahora [playerfirstname] se había ido."

# game/chapters/bad_end.rpy:619
translate Spanish badend_afterending_3a882024:

    # "And Casper was alone."
    "Y Casper estaba solo."

# game/chapters/bad_end.rpy:620
translate Spanish badend_afterending_70acb8bb:

    # "Suddenly, he felt there wasn't much fairness in death."
    "De repente, sintió que no había mucha justicia en la muerte."

# game/chapters/bad_end.rpy:621
translate Spanish badend_afterending_9ee2add3:

    # "If death was fair, why would he feel like this?"
    "Si la muerte fuera justa, ¿por qué se sentiría así?"

# game/chapters/bad_end.rpy:623
translate Spanish badend_afterending_f8bb615a:

    # "He'd accomplished what he'd set out to do. His peers congratulated him."
    "Había logrado lo que se había propuesto. Sus compañeros lo felicitaron."

# game/chapters/bad_end.rpy:624
translate Spanish badend_afterending_3d9baaae:

    # "And he'd never felt so empty."
    "Y nunca se había sentido tan vacío."

# game/chapters/bad_end.rpy:625
translate Spanish badend_afterending_0567d861:

    # GRC "'I miss you, Sunshine.' he sniffles." id badend_afterending_0567d861
    GRC "'Te extraño, Solecito', solloza." id badend_afterending_0567d861

# game/chapters/bad_end.rpy:626
translate Spanish badend_afterending_06421382:

    # "But no one answers him."
    "Pero nadie le responde."

# game/chapters/bad_end.rpy:627
translate Spanish badend_afterending_b1b58181:

    # "And so Casper goes on living, alone, thinking on the memory of the mortal who he was supposed to hate, but couldn't help but love."
    "Y así Casper sigue viviendo, solo, pensando en el recuerdo del mortal al que se suponía debía odiar, pero que no pudo evitar amar."

# game/chapters/bad_end.rpy:632
translate Spanish badend_afterending_b9d9bb36:

    # "Such is the life of a Grim Reaper."
    "Así es la vida de una Parca."

translate Spanish strings:

    # game/chapters/bad_end.rpy:30
    old "you have my heart."
    new "tienes mi corazón."

    # game/chapters/bad_end.rpy:58
    old "1. <Not to alarm you or anything, but I think something's... wrong.>"
    new "1. <No quiero alarmarte ni nada, pero creo que algo está... mal.>"

    # game/chapters/bad_end.rpy:64
    old "2. <I'm starting to freak out a bit...>"
    new "2. <Estoy empezando a asustarme un poco...>"

    # game/chapters/bad_end.rpy:67
    old "1. <My plant just... died.>"
    new "1. <Mi planta simplemente... murió.>"

    # game/chapters/bad_end.rpy:71
    old "1. <Of course I did.>"
    new "1. <Por supuesto que sí.>"

    # game/chapters/bad_end.rpy:75
    old "1. <It was fine yesterday.>"
    new "1. <Ayer estaba bien.>"

    # game/chapters/bad_end.rpy:78
    old "1. <Why would it suddenly shrivel up overnight?>"
    new "1. <¿Por qué de repente se marchitaría de la noche a la mañana?>"

    # game/chapters/bad_end.rpy:83
    old "1. <And [pet_name] is sick again.>"
    new "1. <Y [pet_name] se enfermó otra vez.>"

    # game/chapters/bad_end.rpy:88
    old "1. <I think I'm alright?>"
    new "1. <Creo que estoy bien, ¿no?>"

    # game/chapters/bad_end.rpy:90
    old "2. <No, I'm totally fine...>"
    new "2. <No, estoy totalmente bien...>"

    # game/chapters/bad_end.rpy:93
    old "1. <Just stressed about [pet_name].>"
    new "1. <Solo estoy estresad[letra] por [pet_name].>"

    # game/chapters/bad_end.rpy:98
    old "1. <Of course I have. I've been trying all morning.>"
    new "1. <Por supuesto que sí. He estado intentándolo toda la mañana.>"

    # game/chapters/bad_end.rpy:100
    old "2. <It's all I've done today.>"
    new "2. <Es todo lo que he hecho hoy.>"

    # game/chapters/bad_end.rpy:103
    old "1. <And it's not working.>"
    new "1. <Y no está funcionando.>"

    # game/chapters/bad_end.rpy:106
    old "1. <Are you positive I can really... heal things like that?>"
    new "1. <¿Estás seguro de que realmente puedo... sanar cosas así?>"

    # game/chapters/bad_end.rpy:111
    old "1. <And you? How do {i}you{/i} feel?>"
    new "1. <¿Y tú? ¿Cómo te sientes {i}tú{/i}?>"

    # game/chapters/bad_end.rpy:116
    old "1. <[pet_She] doesn't even want to eat [pet_her] favorite treats.>"
    new "1. <[pet_She!t] ni siquiera quiere comer sus golosinas favoritas.>"

    # game/chapters/bad_end.rpy:120
    old "1. <Well... if you say so.>"
    new "1. <Bueno... si tú lo dices.>"

    # game/chapters/bad_end.rpy:123
    old "1. <I hope you're right.>"
    new "1. <Espero que tengas razón.>"

    # game/chapters/bad_end.rpy:126
    old "1. <I'll... try again later.>"
    new "1. <Lo... intentaré de nuevo más tarde.>"

    # game/chapters/bad_end.rpy:131
    old "1. <Yes, of course I have.>"
    new "1. <Sí, por supuesto que sí.>"

    # game/chapters/bad_end.rpy:134
    old "1. <But I did forget to grab a drink.>"
    new "1. <Pero olvidé tomar algo de beber.>"

    # game/chapters/bad_end.rpy:142
    old "1. <Yes boss... I'll brb.>"
    new "1. <Sí, jefe... ya vuelvo.>"

    # game/chapters/bad_end.rpy:144
    old "2. <Not yet, no.>"
    new "2. <Aún no, no.>"

    # game/chapters/bad_end.rpy:147
    old "1. <I'll get something soon though.>"
    new "1. <Pero conseguiré algo pronto.>"

    # game/chapters/bad_end.rpy:150
    old "1. <I'm getting a bit hungry now that you mention it.>"
    new "1. <Me está dando un poco de hambre ahora que lo mencionas.>"

    # game/chapters/bad_end.rpy:154
    old "1. <But I'm talking with you.>"
    new "1. <Pero estoy hablando contigo.>"

    # game/chapters/bad_end.rpy:159
    old "1. <Yeah okay. I'm on it.>"
    new "1. <Sí, okey. Ya voy.>"

    # game/chapters/bad_end.rpy:161
    old "2. <Alright bossy boots.>"
    new "2. <Está bien, mandón.>"

    # game/chapters/bad_end.rpy:165
    old "1. <What a worrywart you've turned out to be.>"
    new "1. <Qué preocupón resultaste ser.>"

    # game/chapters/bad_end.rpy:170
    old "1. <Bossy boots.>"
    new "1. <Mandón.>"

    # game/chapters/bad_end.rpy:175
    old "1. <A worrywart.>"
    new "1. <Preocupón.>"

    # game/chapters/bad_end.rpy:180
    old "1. <Ha.>"
    new "1. <Ja.>"

    # game/chapters/bad_end.rpy:183
    old "1. <You kinda are. BRB.>"
    new "1. <Un poco lo eres. Ya vuelvo.>"

    # game/chapters/bad_end.rpy:186
    old "3. <Oops... no. I forgot.>"
    new "3. <Ups... no. Lo olvidé.>"

    # game/chapters/bad_end.rpy:189
    old "1. <I guess I was too distracted with everything going on today...>"
    new "1. <Supongo que estaba demasiado distraíd[letra] con todo lo que pasa hoy...>"

    # game/chapters/bad_end.rpy:192
    old "1. <I will soon.>"
    new "1. <Lo haré pronto.>"

    # game/chapters/bad_end.rpy:197
    old "1. <Yeah, all the time.>"
    new "1. <Sí, todo el tiempo.>"

    # game/chapters/bad_end.rpy:202
    old "1. <What? I'm fine.>"
    new "1. <¿Qué? Estoy bien.>"

    # game/chapters/bad_end.rpy:208
    old "1. <So demanding...>"
    new "1. <Tan exigente...>"

    # game/chapters/bad_end.rpy:211
    old "1. <Fine. I'll be right back!>"
    new "1. <Bien. ¡Ya vuelvo!>"

    # game/chapters/bad_end.rpy:214
    old "2. <Nah. I think I'm just stressed out.>"
    new "2. <Nah. Creo que solo estoy estresad[letra].>"

    # game/chapters/bad_end.rpy:217
    old "1. <I'll grab something now.>"
    new "1. <Iré a buscar algo ahora.>"

    # game/chapters/bad_end.rpy:222
    old "1. <I'll be right back!>"
    new "1. <¡Ya vuelvo!>"

    # game/chapters/bad_end.rpy:272
    old "1. <I'm back, are you happy now?>"
    new "1. <He vuelto, ¿feliz ahora?>"

    # game/chapters/bad_end.rpy:277
    old "1. <I tried to help [pet_name] again, too.>"
    new "1. <También intenté ayudar a [pet_name] otra vez.>"

    # game/chapters/bad_end.rpy:285
    old "1. <I told you I'll always try hard for [pet_her2]>"
    new "1. <Te dije que siempre haría mi mejor esfuerzo por [pet_she!t].>"

    # game/chapters/bad_end.rpy:323
    old "1. <Wow, that's a little rude.>"
    new "1. <Wow, eso fue un poco grosero.>"

    # game/chapters/bad_end.rpy:326
    old "2. <What else was I supposed to do?!>"
    new "2. <¡¿Qué más se suponía que debía hacer?!>"

    # game/chapters/bad_end.rpy:330
    old "1. <But what if there isn't much time?>"
    new "1. <¿Pero qué pasa si no queda mucho tiempo?>"

    # game/chapters/bad_end.rpy:333
    old "1. <I don't care if it makes me sick.>"
    new "1. <No me importa si me enferma.>"

    # game/chapters/bad_end.rpy:349
    old "1. <...I know.>"
    new "1. <...Lo sé.>"

    # game/chapters/bad_end.rpy:366
    old "1. <I actually... feel kind of dizzy.>"
    new "1. <En realidad... siento algo de mareo.>"

    # game/chapters/bad_end.rpy:388
    old "1. <What's wrong?>"
    new "1. <¿Qué pasa?>"

    # game/chapters/bad_end.rpy:404
    old "1. <What's the diagnosis, doc?>"
    new "1. <¿Cuál es el diagnóstico, doc?>"

    # game/chapters/bad_end.rpy:411
    old "1. <I've been trying all day, but nothing changed.>"
    new "1. <He estado intentándolo todo el día, pero nada cambió.>"

    # game/chapters/bad_end.rpy:418
    old "1. <What? No, that can't be right.>"
    new "1. <¿Qué? No, eso no puede ser.>"

    # game/chapters/bad_end.rpy:422
    old "1. <It couldn't be all used up that quickly!>"
    new "1. <¡No es posible que se haya agotado tan rápido!>"

    # game/chapters/bad_end.rpy:428
    old "1. <What, right now?>"
    new "1. <¿Qué, ahora mismo?>"

    # game/chapters/bad_end.rpy:430
    old "2. <That's a little sudden...>"
    new "2. <Eso fue un poco repentino...>"

    # game/chapters/bad_end.rpy:436
    old "1. <It can't be that bad, right?>"
    new "1. <No puede ser tan malo, ¿cierto?>"

    # game/chapters/bad_end.rpy:440
    old "1. <...Right?>"
    new "1. <...¿Cierto?>"

    # game/chapters/bad_end.rpy:512
    old "1. <Hey Grim?>"
    new "1. <Oye, Parca...>"

    # game/chapters/bad_end.rpy:522
    old "1. <You win.>"
    new "1. <Ganas tú.>"

    # game/chapters/bad_end.rpy:528
    old "1. <My soul's gonna disappear, isn't it?>"
    new "1. <Mi alma va a desaparecer, ¿verdad?>"

    # game/chapters/bad_end.rpy:534
    old "1. <I don't want to disappear.>"
    new "1. <No quiero desaparecer.>"

    # game/chapters/bad_end.rpy:538
    old "1. <So, you win.>"
    new "1. <Así que, ganas tú.>"

    # game/chapters/bad_end.rpy:542
    old "1. <You won the bet. You can take my soul.>"
    new "1. <Ganaste la apuesta. Puedes llevarte mi alma.>"

    # game/chapters/bad_end.rpy:554
    old "1. <Is my soul going to disappear?>"
    new "1. <¿Mi alma va a desaparecer?>"

    # game/chapters/bad_end.rpy:575
    old "1. <Life isn't fair, Casper. The only fairness is in death... right?>"
    new "1. <La vida no es justa, Casper. La única justicia está en la muerte... ¿cierto?>"

    # game/chapters/bad_end.rpy:587
    old "1. <Take care of [pet_name], okay?>"
    new "1. <Cuida de [pet_name], ¿okey?>"

    # game/chapters/bad_end.rpy:594
    old "1. <And, Casper?>"
    new "1. <Y... ¿Casper?>"

    # game/chapters/bad_end.rpy:598
    old "1. <I think I really like you too.>"
    new "1. <Creo que tú también me gustas de verdad.>"

