# TODO: Translation updated at 2026-10-15 18:36

# game/chapters/3_day.rpy:7
translate Spanish day3_start_d41d8cd9:

    # nvl clear
    nvl clear

# game/chapters/3_day.rpy:18
translate Spanish day3_start_434d0604:

    # center_text "You kept turning around to check over your shoulder today."
    center_text "Hoy no dejabas de darte la vuelta para mirar por encima del hombro."

# game/chapters/3_day.rpy:19
translate Spanish day3_start_51081654:

    # center_text "Something felt... strange. Like someone was watching you."
    center_text "Algo se sentía... extraño. Como si alguien te estuviera observando."

# game/chapters/3_day.rpy:20
translate Spanish day3_start_f937d53f:

    # center_text "But whenever you looked, no one was there."
    center_text "Pero cada vez que mirabas, no había nadie allí."

# game/chapters/3_day.rpy:21
translate Spanish day3_start_b6d36abf:

    # center_text "Curious."
    center_text "Curioso."

# game/chapters/3_day.rpy:22
translate Spanish day3_start_9ade52bd:

    # center_text "As you're walking home contemplating this feeling, you hear the sound of heavy wheels."
    center_text "Mientras caminas hacia casa meditando sobre este sentimiento, oyes el ruido de unas ruedas pesadas."

# game/chapters/3_day.rpy:23
translate Spanish day3_start_9e8b1f02:

    # center_text "You turn your head to see a truck rushing down a hill towards you, though no one sits in the driver's seat."
    center_text "Giras la cabeza para ver un camión bajando una colina hacia ti, aunque no hay nadie en el asiento del conductor."

# game/chapters/3_day.rpy:28
translate Spanish day3_start_a42c30c8:

    # center_text "You keep walking at a leisurely pace for a reason even you don't understand."
    center_text "Sigues caminando a un ritmo pausado por una razón que ni siquiera tú comprendes."

# game/chapters/3_day.rpy:29
translate Spanish day3_start_cd4533d2:

    # center_text "You hear a crumbling, collapsing crash and watch as the truck falls down into a sinkhole that appeared out of nowhere."
    center_text "Oyes un estruendo, como de algo que se derrumba, y ves cómo el camión cae en un socavón que ha aparecido de la nada."

# game/chapters/3_day.rpy:30
translate Spanish day3_start_b7f48174:

    # center_text "Strange, but luckily you are unscathed."
    center_text "Es extraño, pero por suerte no has sufrido ningún daño."

# game/chapters/3_day.rpy:34
translate Spanish day3_start_4c5eabd3:

    # center_text "You stop suddenly, watching the truck."
    center_text "Te detienes de golpe, observando el camión."

# game/chapters/3_day.rpy:35
translate Spanish day3_start_c30e5acd:

    # center_text "It barrels forwards, crashing into an empty shop just ahead of you."
    center_text "Se precipita hacia adelante, estrellándose contra una tienda vacía justo delante de ti."

# game/chapters/3_day.rpy:36
translate Spanish day3_start_12b9eef4:

    # center_text "A power pole falls down, just to add a little more chaos."
    center_text "Un poste de luz cae, solo para añadir un poco más de caos."

# game/chapters/3_day.rpy:37
translate Spanish day3_start_2845b799:

    # center_text "Thankfully, you're completely unscathed."
    center_text "Afortunadamente, sales completamente iles[letra]."

# game/chapters/3_day.rpy:76
translate Spanish day3_start2_029a2d83:

    # GR "mortal."
    GR "mortal."

# game/chapters/3_day.rpy:77
translate Spanish day3_start2_695c9038:

    # GR "do not call upon me this day."
    GR "no me invoques este día."

# game/chapters/3_day.rpy:78
translate Spanish day3_start2_cb8f3ca0:

    # GR "adhere to my words, else a curse shall befall you."
    GR "obedece mis palabras o una maldición caerá sobre ti."

# game/chapters/3_day.rpy:82
translate Spanish day3_start2_6099991d:

    # player "What? {color=FF0000}{i}{size=20}Message not sent.{/size}{/i}{/color}"
    player "¿Qué? {color=FF0000}{i}{size=20}Mensaje no enviado.{/size}{/i}{/color}"

# game/chapters/3_day.rpy:85
translate Spanish day3_start2_b110bad7:

    # player "Hello? {color=FF0000}{i}{size=20}Message not sent.{/size}{/i}{/color}"
    player "¿Hola? {color=FF0000}{i}{size=20}Mensaje no enviado.{/size}{/i}{/color}"

# game/chapters/3_day.rpy:88
translate Spanish day3_start2_e6c5e757:

    # player "Grim? {color=FF0000}{i}{size=20}Message not sent.{/size}{/i}{/color}"
    player "¿Parca? {color=FF0000}{i}{size=20}Mensaje no enviado.{/size}{/i}{/color}"

# game/chapters/3_day.rpy:90
translate Spanish day3_start2_eb81b324:

    # player "Steve? {color=FF0000}{i}{size=20}Message not sent.{/size}{/i}{/color}"
    player "¿Steve? {color=FF0000}{i}{size=20}Mensaje no enviado.{/size}{/i}{/color}"

# game/chapters/3_day.rpy:92
translate Spanish day3_start2_4ebd00ab:

    # player "Edgy Reaper Boy? {color=FF0000}{i}{size=20}Message not sent.{/size}{/i}{/color}"
    player "¿Chico Parca Edgy? {color=FF0000}{i}{size=20}Mensaje no enviado.{/size}{/i}{/color}"

# game/chapters/3_day.rpy:94
translate Spanish day3_start2_8efdec7f:

    # player "Babygirl? {color=FF0000}{i}{size=20}Message not sent.{/size}{/i}{/color}"
    player "¿Babygirl? {color=FF0000}{i}{size=20}Mensaje no enviado.{/size}{/i}{/color}"

# game/chapters/3_day.rpy:97
translate Spanish day3_start2_09fe1b43:

    # player "Hellooooo? {color=FF0000}{i}{size=20}Message not sent.{/size}{/i}{/color}"
    player "¿Holaaaaaa? {color=FF0000}{i}{size=20}Mensaje no enviado.{/size}{/i}{/color}"

# game/chapters/3_day.rpy:101
translate Spanish day3_start2_65a2c5eb:

    # player "This just makes me want to send MORE messages... {color=FF0000}{i}{size=20}Message not sent.{/size}{/i}{/color}"
    player "Esto solo hace que quiera mandar MÁS mensajes... {color=FF0000}{i}{size=20}Mensaje no enviado.{/size}{/i}{/color}"

# game/chapters/3_day.rpy:105
translate Spanish day3_start2_8bfc7f6a:

    # player "Your app is brooooken... {color=FF0000}{i}{size=20}Message not sent.{/size}{/i}{/color}"
    player "Tu app está rooooota... {color=FF0000}{i}{size=20}Mensaje no enviado.{/size}{/i}{/color}"

# game/chapters/3_day.rpy:117
translate Spanish continue_after_restart_fa197b0f:

    # player "Is it fixed? {color=FF0000}{i}{size=20}Message not sent.{/size}{/i}{/color}"
    player "¿Ya se arregló? {color=FF0000}{i}{size=20}Mensaje no enviado.{/size}{/i}{/color}"

# game/chapters/3_day.rpy:120
translate Spanish continue_after_restart_892f1154:

    # player "Nope. {color=FF0000}{i}{size=20}Message not sent.{/size}{/i}{/color}"
    player "Nop. {color=FF0000}{i}{size=20}Mensaje no enviado.{/size}{/i}{/color}"

# game/chapters/3_day.rpy:123
translate Spanish continue_after_restart_918d9156:

    # player "I know it says message not sent... {color=FF0000}{i}{size=20}Message not sent.{/size}{/i}{/color}"
    player "Sé que dice mensaje no enviado... {color=FF0000}{i}{size=20}Mensaje no enviado.{/size}{/i}{/color}"

# game/chapters/3_day.rpy:127
translate Spanish continue_after_restart_be665c9a:

    # player "But can you read this anyway, Grim? {color=FF0000}{i}{size=20}Message not sent.{/size}{/i}{/color}"
    player "Pero ¿puedes leer esto aun así, Parca? {color=FF0000}{i}{size=20}Mensaje no enviado.{/size}{/i}{/color}"

# game/chapters/3_day.rpy:131
translate Spanish continue_after_restart_851c8cdf:

    # player "You're cute. {color=FF0000}{i}{size=20}Message not sent.{/size}{/i}{/color}"
    player "Eres lindo. {color=FF0000}{i}{size=20}Mensaje no enviado.{/size}{/i}{/color}"

# game/chapters/3_day.rpy:134
translate Spanish continue_after_restart_2d3f8b89:

    # player "You smell. {color=FF0000}{i}{size=20}Message not sent.{/size}{/i}{/color}" id continue_after_restart_2d3f8b89
    player "Apestas. {color=FF0000}{i}{size=20}Mensaje no enviado.{/size}{/i}{/color}" id continue_after_restart_2d3f8b89

# game/chapters/3_day.rpy:135
translate Spanish continue_after_restart_fe9d3e3e:

    # GR "you are ridiculously incapable of following simple instructions."
    GR "eres ridículamente incapaz de seguir instrucciones simples."

# game/chapters/3_day.rpy:136
translate Spanish continue_after_restart_8d0855c3:

    # GR "fine. i will fix this problem."
    GR "bien. arreglaré este problema."

# game/chapters/3_day.rpy:157
translate Spanish day3_roomforced_c10b8af3:

    # "The screen of your computer goes dark."
    "La pantalla de tu computadora se oscurece."

# game/chapters/3_day.rpy:162
translate Spanish day3_roomforced_7d13fd62:

    # "No matter how many times you press the 'on' button, it won't turn back on."
    "Por más que presiones el botón de 'encendido', no vuelve a encender."

# game/chapters/3_day.rpy:163
translate Spanish day3_roomforced_8d6d4f42:

    # "Frustrated, you contemplate once again throwing your laptop out the window, then decide against it."
    "Con frustración, contemplas una vez más lanzar tu portátil por la ventana, pero decides no hacerlo."

# game/chapters/3_day.rpy:164
translate Spanish day3_roomforced_7f2001f8:

    # "Who can afford a new laptop in this day and age?"
    "¿Quién puede permitirse un portátil nuevo en esta época?"

# game/chapters/3_day.rpy:165
translate Spanish day3_roomforced_eb0ce046:

    # "You're waiting there like this for twenty five minutes when a ding from your computer gets your attention."
    "Estás esperando así durante veinticinco minutos cuando un ding de tu computadora llama tu atención."

# game/chapters/3_day.rpy:166
translate Spanish day3_roomforced_8c20d478:

    # "Slowly it boots back up, but you're not greeted by your desktop."
    "Poco a poco se vuelve a encender, pero no te recibe tu escritorio."

# game/chapters/3_day.rpy:167
translate Spanish day3_roomforced_99c1571b:

    # "Instead, you see a call already connected."
    "En su lugar, ves una llamada ya conectada."

# game/chapters/3_day.rpy:184
translate Spanish call1_day3_e2e83786:

    # GRC "Why are you incapable of listening?"
    GRC "¿Por qué eres incapaz de escuchar?"

# game/chapters/3_day.rpy:192
translate Spanish call1_day3_370d2243:

    # GRC "Nor following a single, simple instruction?"
    GRC "¿Ni de seguir una sola y simple instrucción?"

# game/chapters/3_day.rpy:200
translate Spanish call1_day3_4275ad58:

    # GRC "It is none of your business."
    GRC "No es asunto tuyo."

# game/chapters/3_day.rpy:214
translate Spanish call1_day3_30f04228:

    # GRC "I very clearly said for you not to call upon me."
    GRC "Dije muy claramente que no me invocaras."

# game/chapters/3_day.rpy:233
translate Spanish call1_day3_f5e262c6:

    # GRC "Hah! You cannot escape me {i}that{/i} easily."
    GRC "¡Ja! No puedes escaparte de mí {i}tan{/i} fácilmente."

# game/chapters/3_day.rpy:242
translate Spanish call1_day3_e744d24f:

    # GRC "I obviously meant {i}do not disturb me{/i}."
    GRC "Obviamente quise decir {i}no me molestes{/i}."

# game/chapters/3_day.rpy:243
translate Spanish call1_day3_fde05d4e:

    # GRC "Do not call me. Do not message me."
    GRC "No me llames. No me mandes mensajes."

# game/chapters/3_day.rpy:244
translate Spanish call1_day3_f15e6513:

    # GRC "Yet you could not seem to understand something so simple."
    GRC "Sin embargo, no parecías entender algo tan simple."

# game/chapters/3_day.rpy:245
translate Spanish call1_day3_93db16ab:

    # GRC "So I simply disabled the functions."
    GRC "Así que simplemente desactivé las funciones."

# game/chapters/3_day.rpy:246
translate Spanish call1_day3_c7bcc5ff:

    # GRC "Even that didn't deter you."
    GRC "Ni siquiera eso te detuvo."

# game/chapters/3_day.rpy:251
translate Spanish call1_day3_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/3_day.rpy:260
translate Spanish call1_day3_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/3_day.rpy:266
translate Spanish call1_day3_9c77a7f6:

    # GRC "It is... nothing to worry about."
    GRC "No es... nada de qué preocuparse."

# game/chapters/3_day.rpy:274
translate Spanish call1_day3_8f1f94e4:

    # GRC "What makes you think there is a problem?"
    GRC "¿Qué te hace pensar que hay un problema?"

# game/chapters/3_day.rpy:275
translate Spanish call1_day3_10d9da4c:

    # GRC "Maybe I simply wanted a day of peace and quiet."
    GRC "Tal vez simplemente quería un día de paz y tranquilidad."

# game/chapters/3_day.rpy:276
translate Spanish call1_day3_6489257f:

    # GRC "Two things you're notoriously bad at."
    GRC "Dos cosas que se te dan muy mal."

# game/chapters/3_day.rpy:285
translate Spanish call1_day3_ea1891d0:

    # GRC "It seems your skills of deduction are adequate, at least..."
    GRC "Al menos parece que tus habilidades de deducción son aceptables..."

# game/chapters/3_day.rpy:291
translate Spanish call1_day3_a4d28a31:

    # GRC "I do not wish to discuss the matter."
    GRC "No deseo hablar del asunto."

# game/chapters/3_day.rpy:301
translate Spanish call1_day3_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/3_day.rpy:306
translate Spanish call1_day3_49e7ad97:

    # GRC "No, I would prefer not to. It isn't a good idea at the present moment."
    GRC "No, preferiría no hacerlo. No es buena idea en este momento."

# game/chapters/3_day.rpy:314
translate Spanish call1_day3_5572a993:

    # GRC "...I suppose you could say that."
    GRC "...Supongo que podría decirse que sí."

# game/chapters/3_day.rpy:325
translate Spanish call1_day3_439a21d9:

    # GRC "Stop yelling."
    GRC "Deja de gritar."

# game/chapters/3_day.rpy:326
translate Spanish call1_day3_1e0f0b4d:

    # GRC "My mind just needs to... stabilize itself, so to speak."
    GRC "Mi mente solo necesita... estabilizarse, por así decirlo."

# game/chapters/3_day.rpy:332
translate Spanish call1_day3_3b56ee57:

    # GRC "Yes. Is there something wrong with your hearing today?"
    GRC "Sí. ¿Acaso hoy tienes problemas de audición?"

# game/chapters/3_day.rpy:333
translate Spanish call1_day3_22304325:

    # GRC "Or perhaps there's a parrot in the call with us."
    GRC "O tal vez hay un loro en nuestra llamada."

# game/chapters/3_day.rpy:341
translate Spanish call1_day3_0143146c:

    # GRC "I simply... need to replenish my energy. You wouldn't understand."
    GRC "Simplemente... necesito reponer mi energía. No lo entenderías."

# game/chapters/3_day.rpy:349
translate Spanish call1_day3_40921281:

    # GRC "It would only help partially."
    GRC "Solo ayudaría parcialmente."

# game/chapters/3_day.rpy:352
translate Spanish call1_day3_13421332:

    # GRC "I can replenish a little energy that way, but it's not enough."
    GRC "Puedo reponer un poco de energía así, pero no es suficiente."

# game/chapters/3_day.rpy:355
translate Spanish call1_day3_e26e79e6:

    # GRC "As nice as that sounds, it won't be enough."
    GRC "Por muy bien que suene, no será suficiente."

# game/chapters/3_day.rpy:357
translate Spanish call1_day3_bee2a499:

    # GRC "I just need to rebalance."
    GRC "Solo necesito reequilibrarme."

# game/chapters/3_day.rpy:363
translate Spanish call1_day3_2e26dd3c:

    # GRC "...I just need some time. Which is why I told you to leave me alone today."
    GRC "...Solo necesito algo de tiempo. Por eso te dije que me dejaras en paz hoy."

# game/chapters/3_day.rpy:369
translate Spanish call1_day3_28973ae1:

    # GRC "Yes. My soul has been spent too heavily today."
    GRC "Sí. Mi alma se ha desgastado demasiado hoy."

# game/chapters/3_day.rpy:378
translate Spanish call1_day3_b1a7a07c:

    # GRC "Let us resume via text."
    GRC "Continuemos por texto."

# game/chapters/3_day.rpy:400
translate Spanish chat2_day3_05cf1b99:

    # player "???"
    player "???"

# game/chapters/3_day.rpy:401
translate Spanish chat2_day3_2d8bc2dc:

    # GR "this will work better."
    GR "esto funcionará mejor."

# game/chapters/3_day.rpy:402
translate Spanish chat2_day3_b70edb1e:

    # GR "you are simply too... bright."
    GR "eres simplemente demasiado... brillante."

# game/chapters/3_day.rpy:405
translate Spanish chat2_day3_59799d85:

    # player "Too bright?"
    player "¿Demasiado brillante?"

# game/chapters/3_day.rpy:406
translate Spanish chat2_day3_83c5656f:

    # GR "like sunlight."
    GR "como la luz del sol."

# game/chapters/3_day.rpy:407
translate Spanish chat2_day3_0c70202b:

    # GR "blindingly so."
    GR "de una forma cegadora."

# game/chapters/3_day.rpy:410
translate Spanish chat2_day3_eb6710a1:

    # player "I can't decide if you mean that as a compliment or an insult."
    player "No sé si tomármelo como un cumplido o como un insulto."

# game/chapters/3_day.rpy:411
translate Spanish chat2_day3_b1324e42:

    # GR "honestly."
    GR "honestamente."

# game/chapters/3_day.rpy:412
translate Spanish chat2_day3_4b6214a7:

    # GR "how can someones aura be so intense."
    GR "cómo puede el aura de alguien ser tan intensa."

# game/chapters/3_day.rpy:413
translate Spanish chat2_day3_7819b50e:

    # GR "and yet be so..."
    GR "y aun así ser tan..."

# game/chapters/3_day.rpy:414
translate Spanish chat2_day3_bd074ab8:

    # GR "not."
    GR "no."

# game/chapters/3_day.rpy:415
translate Spanish chat2_day3_30ced879:

    # GR "i am unsure."
    GR "no estoy seguro."

# game/chapters/3_day.rpy:418
translate Spanish chat2_day3_c0d1bdc2:

    # player "Um...?"
    player "¿Um...?"

# game/chapters/3_day.rpy:420
translate Spanish chat2_day3_2d5d9eb6:

    # player "What are you talking about...?"
    player "¿De qué estás hablando...?"

# game/chapters/3_day.rpy:422
translate Spanish chat2_day3_3787cd09:

    # GR "you are an enigma to me."
    GR "eres un enigma para mí."

# game/chapters/3_day.rpy:426
translate Spanish chat2_day3_faecef81:

    # player "I am so confused right now."
    player "Estoy muy confundid[letra] ahora mismo."

# game/chapters/3_day.rpy:427
translate Spanish chat2_day3_8bbd0f21:

    # GR "that is to be expected."
    GR "eso es de esperarse."

# game/chapters/3_day.rpy:430
translate Spanish chat2_day3_82928bca:

    # player "You say a lot of crazy things, but..."
    player "Dices muchas cosas locas, pero..."

# game/chapters/3_day.rpy:434
translate Spanish chat2_day3_96a66d5d:

    # player "You're being extra strange today."
    player "Hoy estás extra raro."

# game/chapters/3_day.rpy:439
translate Spanish chat2_day3_fd49b109:

    # player "What do you mean by my aura...?"
    player "¿Qué quieres decir con mi aura...?"

# game/chapters/3_day.rpy:440
translate Spanish chat2_day3_da711411:

    # GR "you wouldn't understand."
    GR "no lo entenderías."

# game/chapters/3_day.rpy:441
translate Spanish chat2_day3_77a84c7a:

    # GR "after all, your eyes cannot see what mine see." id chat2_day3_77a84c7a
    GR "al fin y al cabo, tus ojos no pueden ver lo que ven los míos." id chat2_day3_77a84c7a

# game/chapters/3_day.rpy:442
translate Spanish chat2_day3_6251573d:

    # GR "your aura, your soul... is like a mirage."
    GR "tu aura, tu alma... es como un espejismo."

# game/chapters/3_day.rpy:445
translate Spanish chat2_day3_5b99feb0:

    # player "I... see?"
    player "Ya... ¿entiendo?"

# game/chapters/3_day.rpy:446
translate Spanish chat2_day3_3e49af71:

    # GR "no, you do not."
    GR "no, no entiendes."

# game/chapters/3_day.rpy:447
translate Spanish chat2_day3_6a93abd4:

    # GR "it is beyond unusual."
    GR "es más que inusual."

# game/chapters/3_day.rpy:448
translate Spanish chat2_day3_855a8af4:

    # GR "most living creatures have solid colors that surround them."
    GR "la mayoría de los seres vivos tienen un aura de un solo color a su alrededor."

# game/chapters/3_day.rpy:451
translate Spanish chat2_day3_f8834c45:

    # player "Uh... right?"
    player "Eh... ¿ah, sí?"

# game/chapters/3_day.rpy:452
translate Spanish chat2_day3_f3ae1597:

    # GR "it's beyond odd."
    GR "es más que raro."

# game/chapters/3_day.rpy:453
translate Spanish chat2_day3_4db7c2fb:

    # GR "Most living creatures have an aura of solid color."
    GR "la mayoría de los seres vivos tienen un aura de un solo color."

# game/chapters/3_day.rpy:456
translate Spanish chat2_day3_4c81fee7:

    # player "Most?"
    player "¿La mayoría?"

# game/chapters/3_day.rpy:457
translate Spanish chat2_day3_284ec013:

    # GR "most, yes."
    GR "la mayoría, sí."

# game/chapters/3_day.rpy:458
translate Spanish chat2_day3_0ae0d91a:

    # GR "some with a stronger connection to the beyond may have an aura with multiple colors."
    GR "algunos con una conexión más fuerte con el más allá pueden tener un aura con varios colores."

# game/chapters/3_day.rpy:459
translate Spanish chat2_day3_c39ca190:

    # GR "but the coloring is still solid. always."
    GR "pero el color siempre es uniforme. siempre."

# game/chapters/3_day.rpy:462
translate Spanish chat2_day3_9f1b6413:

    # player "Ah."
    player "Ah."

# game/chapters/3_day.rpy:465
translate Spanish chat2_day3_d8362c30:

    # player "I still don't understand."
    player "Sigo sin entender."

# game/chapters/3_day.rpy:468
translate Spanish chat2_day3_263510b2:

    # player "Do you have an eye condition?"
    player "¿Tienes algún problema de la vista?"

# game/chapters/3_day.rpy:469
translate Spanish chat2_day3_442fcb6f:

    # GR "what? no. you're not paying attention properly."
    GR "¿qué? no. no estás prestando atención correctamente."

# game/chapters/3_day.rpy:470
translate Spanish chat2_day3_233d35fa:

    # GR "just listen."
    GR "solo escucha."

# game/chapters/3_day.rpy:471
translate Spanish chat2_day3_d0098902:

    # GR "your aura..."
    GR "tu aura..."

# game/chapters/3_day.rpy:472
translate Spanish chat2_day3_8e7c5457:

    # GR "since we first spoke, i've been studying it."
    GR "desde que hablamos por primera vez, la he estado estudiando."

# game/chapters/3_day.rpy:473
translate Spanish chat2_day3_28bdc743:

    # GR "it does not resemble a living being's aura at all." id chat2_day3_28bdc743
    GR "no se parece en nada al aura de un ser vivo." id chat2_day3_28bdc743

# game/chapters/3_day.rpy:476
translate Spanish chat2_day3_ebae53f1:

    # player "Are you trying to tell me I'm dead?"
    player "¿Estás tratando de decirme que estoy muert[letra]?"

# game/chapters/3_day.rpy:477
translate Spanish chat2_day3_e8c72615:

    # GR "you are not dead."
    GR "no estás muert[letra]."

# game/chapters/3_day.rpy:478
translate Spanish chat2_day3_ad195609:

    # GR "the aura of the dead is..."
    GR "el aura de los muertos es..."

# game/chapters/3_day.rpy:479
translate Spanish chat2_day3_4aeee040:

    # GR "like smoke, i suppose."
    GR "como el humo, supongo."

# game/chapters/3_day.rpy:480
translate Spanish chat2_day3_382d86f5:

    # GR "it has a strong stench and it is thick."
    GR "tiene un olor fuerte y es espeso."

# game/chapters/3_day.rpy:481
translate Spanish chat2_day3_c8114fee:

    # GR "yours is not like that either."
    GR "la tuya no es así tampoco."

# game/chapters/3_day.rpy:485
translate Spanish chat2_day3_e3d0561a:

    # player "So..."
    player "Entonces..."

# game/chapters/3_day.rpy:488
translate Spanish chat2_day3_e506527e:

    # player "Maybe you should invest in some glasses?"
    player "¿Y si mejor te compras unos lentes?"

# game/chapters/3_day.rpy:489
translate Spanish chat2_day3_1e26c371:

    # GR "my eyesight is immaculate."
    GR "mi vista es perfecta."

# game/chapters/3_day.rpy:490
translate Spanish chat2_day3_2573158c:

    # GR "like every single part of me."
    GR "como cada parte de mí."

# game/chapters/3_day.rpy:494
translate Spanish chat2_day3_a87d79f5:

    # player "I'm not sure about that..."
    player "Lo dudo..."

# game/chapters/3_day.rpy:498
translate Spanish chat2_day3_a146f2a2:

    # player "Let's say I believe you, hypothetically."
    player "Digamos que te creo, hipotéticamente."

# game/chapters/3_day.rpy:501
translate Spanish chat2_day3_e2494702:

    # player "This feels like the lead-in to a scam..."
    player "Esto se siente como la introducción a una estafa..."

# game/chapters/3_day.rpy:502
translate Spanish chat2_day3_456fae94:

    # GR "what? what kind of scam would this be?"
    GR "¿qué? ¿qué clase de estafa sería esa?"

# game/chapters/3_day.rpy:506
translate Spanish chat2_day3_1f554df2:

    # player "'Your soul is corrupted... but I have the miracle cure!'"
    player "'Tu alma está corrompida... ¡pero tengo la cura milagrosa!'"

# game/chapters/3_day.rpy:509
translate Spanish chat2_day3_b97f9e22:

    # player "'And all it will cost you is $59.99 (plus taxes)!'"
    player "'¡Y todo lo que costará es $59,99 (más impuestos)!'"

# game/chapters/3_day.rpy:511
translate Spanish chat2_day3_1089f401:

    # GR "to be honest, that seems like a decent price for fixing a corrupted soul."
    GR "para ser honesto, ese parece un precio decente para arreglar un alma corrompida."

# game/chapters/3_day.rpy:512
translate Spanish chat2_day3_8d56c75b:

    # GR "i would easily pay double for something so dire."
    GR "yo pagaría fácilmente el doble por algo tan grave."

# game/chapters/3_day.rpy:516
translate Spanish chat2_day3_58b28ba4:

    # player "You are a scam artist's favorite kind of person."
    player "Eres el tipo de persona favorito de un estafador."

# game/chapters/3_day.rpy:517
translate Spanish chat2_day3_11a6d014:

    # GR "that sounds like a compliment."
    GR "eso suena como un cumplido."

# game/chapters/3_day.rpy:521
translate Spanish chat2_day3_2fc682b3:

    # player "It is not."
    player "No lo es."

# game/chapters/3_day.rpy:523
translate Spanish chat2_day3_d659dc30:

    # player "Well, I... yeah, sure."
    player "Bueno, yo... sí, claro."

# game/chapters/3_day.rpy:527
translate Spanish chat2_day3_b7321e7c:

    # player "Anyway."
    player "En fin."

# game/chapters/3_day.rpy:531
translate Spanish chat2_day3_c343581b:

    # player "What is my soul like, then?" id chat2_day3_c343581b
    player "¿Cómo es mi alma entonces?" id chat2_day3_c343581b

# game/chapters/3_day.rpy:532
translate Spanish chat2_day3_61a901d2:

    # GR "like sunlight shining through a fog."
    GR "como la luz del sol atravesando una niebla."

# game/chapters/3_day.rpy:533
translate Spanish chat2_day3_80c27d60:

    # GR "but when i look closer, it's like a mirage."
    GR "pero cuando miro más de cerca, es como un espejismo."

# game/chapters/3_day.rpy:534
translate Spanish chat2_day3_1059dcaf:

    # GR "like it's there, but it's not. the colors are strong, yet empty."
    GR "como si estuviera allí, pero no. los colores son fuertes, pero vacíos."

# game/chapters/3_day.rpy:537
translate Spanish chat2_day3_3eb25362:

    # player "That seems like a contradiction to me."
    player "Eso me parece una contradicción."

# game/chapters/3_day.rpy:538
translate Spanish chat2_day3_987a5327:

    # GR "and that is why it is like a mirage."
    GR "y por eso es como un espejismo."

# game/chapters/3_day.rpy:539
translate Spanish chat2_day3_94841f59:

    # GR "it does not make sense."
    GR "no tiene sentido."

# game/chapters/3_day.rpy:540
translate Spanish chat2_day3_c9a3ee73:

    # GR "have you been cursed?"
    GR "¿has sido maldecid[letra]?"

# game/chapters/3_day.rpy:541
translate Spanish chat2_day3_52eeaf15:

    # GR "or maybe made a blood promise, then broke it?"
    GR "¿o tal vez hiciste una promesa de sangre y luego la rompiste?"

# game/chapters/3_day.rpy:544
translate Spanish chat2_day3_97344f7a:

    # player "A blood what now?!"
    player "¿¡Una qué de sangre!?"

# game/chapters/3_day.rpy:545
translate Spanish chat2_day3_f73a29bb:

    # GR "judging by your lack of understanding, i'd say not."
    GR "juzgando por tu falta de entendimiento, diría que no."

# game/chapters/3_day.rpy:546
translate Spanish chat2_day3_91071401:

    # GR "one cannot enter into a blood promise without understanding the consequences of breaking one."
    GR "uno no puede entrar en una promesa de sangre sin entender las consecuencias de romperla."

# game/chapters/3_day.rpy:547
translate Spanish chat2_day3_9b440a9f:

    # GR "and since you show no understanding of what one even is..."
    GR "y dado que no muestras ningún entendimiento de lo que siquiera es..."

# game/chapters/3_day.rpy:550
translate Spanish chat2_day3_a52de8c4:

    # player "Grim, I literally have no clue what all this is even about."
    player "Parca, literalmente no tengo ni idea de qué va todo esto."

# game/chapters/3_day.rpy:553
translate Spanish chat2_day3_bb113c9f:

    # player "Blood promises and curses? That stuff is out of fantasy books."
    player "¿Promesas de sangre y maldiciones? Eso es material de libros de fantasía."

# game/chapters/3_day.rpy:556
translate Spanish chat2_day3_f386f119:

    # player "Not real life..."
    player "No de la vida real..."

# game/chapters/3_day.rpy:557
translate Spanish chat2_day3_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/3_day.rpy:558
translate Spanish chat2_day3_d55d536a:

    # GR "that is entirely untrue."
    GR "eso es completamente falso."

# game/chapters/3_day.rpy:559
translate Spanish chat2_day3_3955ad60:

    # GR "you just haven't lived a life where you have witnessed nor participated in such things." id chat2_day3_3955ad60
    GR "simplemente no has vivido una vida en la que hayas presenciado ni participado en tales cosas." id chat2_day3_3955ad60

# game/chapters/3_day.rpy:560
translate Spanish chat2_day3_3d59a9e5:

    # GR "how exactly do i get you to understand?"
    GR "¿cómo exactamente logro que lo entiendas?"

# game/chapters/3_day.rpy:563
translate Spanish chat2_day3_ccd8dee7:

    # player "A curse... I don't think so?"
    player "¿Una maldición...? No lo creo."

# game/chapters/3_day.rpy:564
translate Spanish chat2_day3_62adb7d8:

    # GR "and you have made no promises vowed on blood?"
    GR "¿y no has hecho promesas juradas con sangre?"

# game/chapters/3_day.rpy:567
translate Spanish chat2_day3_9490a7a3:

    # player "I think I would remember if I had, so no...?"
    player "Creo que lo recordaría si lo hubiera hecho, así que ¿no...?"

# game/chapters/3_day.rpy:568
translate Spanish chat2_day3_a1fd0fc8:

    # GR "indeed you would know if you had, and the consequences of breaking them are severe."
    GR "en efecto, lo sabrías si lo hubieras hecho, y las consecuencias de romperlas son severas."

# game/chapters/3_day.rpy:569
translate Spanish chat2_day3_3cca7176:

    # GR "i will have to rule both of these out, then..."
    GR "tendré que descartar ambas posibilidades..."

# game/chapters/3_day.rpy:572
translate Spanish chat2_day3_5f59c40b:

    # player "Rule them out? Of what exactly?"
    player "¿Descartarlas de qué exactamente?"

# game/chapters/3_day.rpy:575
translate Spanish chat2_day3_71ba83e9:

    # player "Can you explain what you're talking about, Grim?"
    player "¿Puedes explicar de qué hablas, Parca?"

# game/chapters/3_day.rpy:578
translate Spanish chat2_day3_ccc55092:

    # player "All this talk of curses and blood promises is something out of fiction."
    player "Todo este asunto de maldiciones y promesas de sangre parece sacado de una historia de ficción."

# game/chapters/3_day.rpy:581
translate Spanish chat2_day3_9f7e7000:

    # player "Completely not real."
    player "Completamente irreal."

# game/chapters/3_day.rpy:582
translate Spanish chat2_day3_7772a27d_1:

    # GR "..."
    GR "..."

# game/chapters/3_day.rpy:583
translate Spanish chat2_day3_c4a57851:

    # GR "it is very real."
    GR "es muy real."

# game/chapters/3_day.rpy:584
translate Spanish chat2_day3_3955ad60_1:

    # GR "you just haven't lived a life where you have witnessed nor participated in such things." id chat2_day3_3955ad60_1
    GR "simplemente no has vivido una vida en la que hayas presenciado ni participado en tales cosas." id chat2_day3_3955ad60_1

# game/chapters/3_day.rpy:585
translate Spanish chat2_day3_3d59a9e5_1:

    # GR "how exactly do i get you to understand?"
    GR "¿cómo exactamente logro que lo entiendas?"

# game/chapters/3_day.rpy:588
translate Spanish chat2_day3_d26072a8:

    # player "Yes. I was cursed after breaking a blood promise six moons ago."
    player "Sí. Me maldijeron después de romper una promesa de sangre hace seis lunas."

# game/chapters/3_day.rpy:589
translate Spanish chat2_day3_cc21bd84:

    # GR "!!!"
    GR "!!!"

# game/chapters/3_day.rpy:590
translate Spanish chat2_day3_9cfe9247:

    # GR "this is crucial information, why would you withhold this?!"
    GR "esto es información crucial, ¡¿por qué la ocultarías?!"

# game/chapters/3_day.rpy:593
translate Spanish chat2_day3_70cde8cd:

    # player "The curse... will not allow me to say..."
    player "La maldición... no me permite decirlo..."

# game/chapters/3_day.rpy:596
translate Spanish chat2_day3_74d9f59f:

    # player "If I speak of the details, it will drain my life force away forever..."
    player "Si hablo de los detalles, drenará mi fuerza vital para siempre..."

# game/chapters/3_day.rpy:597
translate Spanish chat2_day3_5c414671:

    # GR "that would make sense..."
    GR "eso tendría sentido..."

# game/chapters/3_day.rpy:598
translate Spanish chat2_day3_79b520f0:

    # GR "and would explain some of the symptoms..."
    GR "y explicaría algunos de los síntomas..."

# game/chapters/3_day.rpy:601
translate Spanish chat2_day3_c811eea7:

    # player "And not only that..."
    player "Y no solo eso..."

# game/chapters/3_day.rpy:604
translate Spanish chat2_day3_7f3fe760:

    # player "My blood now bleeds black..."
    player "Ahora mi sangre es negra..."

# game/chapters/3_day.rpy:607
translate Spanish chat2_day3_4d2ba615:

    # player "As dark as the night sky."
    player "Tan oscura como el cielo nocturno."

# game/chapters/3_day.rpy:608
translate Spanish chat2_day3_7772a27d_2:

    # GR "..."
    GR "..."

# game/chapters/3_day.rpy:609
translate Spanish chat2_day3_9a4f433f:

    # GR "are you fooling around right now?"
    GR "¿estás bromeando ahora mismo?"

# game/chapters/3_day.rpy:612
translate Spanish chat2_day3_b39a65c3:

    # player "Obviously."
    player "Obviamente."

# game/chapters/3_day.rpy:615
translate Spanish chat2_day3_9e155145:

    # player "Seriously, Grim?"
    player "¿En serio, Parca?"

# game/chapters/3_day.rpy:618
translate Spanish chat2_day3_e0bb580b:

    # player "Blood promises? Curses?"
    player "¿Promesas de sangre? ¿Maldiciones?"

# game/chapters/3_day.rpy:621
translate Spanish chat2_day3_063ef2b8:

    # player "Have you gone insane... sorry, even more insane?"
    player "¿Te volviste loco...? Perdón, ¿aún más loco?"

# game/chapters/3_day.rpy:622
translate Spanish chat2_day3_38335c67:

    # GR "what am i supposed to do for you to understand?"
    GR "¿qué se supone que debo hacer para que entiendas?"

# game/chapters/3_day.rpy:626
translate Spanish chat2_day3_f6f27018:

    # player "If you start making sense, then I'll understand." id chat2_day3_f6f27018
    player "Si empiezas a hablar con sentido, entonces te entenderé." id chat2_day3_f6f27018

# game/chapters/3_day.rpy:627
translate Spanish chat2_day3_62b7ebf0:

    # GR "i have an idea."
    GR "tengo una idea."

# game/chapters/3_day.rpy:630
translate Spanish chat2_day3_96a83f7d:

    # player "You know what... "
    player "Sabes qué..."

# game/chapters/3_day.rpy:633
translate Spanish chat2_day3_e6d54f8d:

    # player "After this whole weird conversation..."
    player "Después de toda esta extraña conversación..."

# game/chapters/3_day.rpy:636
translate Spanish chat2_day3_2706a2b4:

    # player "I don't know if I like the thought of you having an 'idea'..."
    player "No sé si me agrada que se te haya ocurrido una 'idea'..."

# game/chapters/3_day.rpy:637
translate Spanish chat2_day3_9a10e46b:

    # GR "you still do not believe my words."
    GR "todavía no crees mis palabras."

# game/chapters/3_day.rpy:640
translate Spanish chat2_day3_e89fe68f:

    # player "It just makes no sense..."
    player "Simplemente no tiene sentido..."

# game/chapters/3_day.rpy:641
translate Spanish chat2_day3_8a7d0eb2:

    # GR "you will just have to try."
    GR "solo tendrás que intentarlo."

# game/chapters/3_day.rpy:642
translate Spanish chat2_day3_e3bd48b5:

    # GR "aren't humans these days supposed to be open minded?"
    GR "¿no se supone que los humanos de hoy en día deben tener una mente abierta?"

# game/chapters/3_day.rpy:644
translate Spanish chat2_day3_f95b5ab0:

    # player "I can try?"
    player "¿Puedo intentarlo?"

# game/chapters/3_day.rpy:645
translate Spanish chat2_day3_4acfcb18:

    # GR "i suppose it will have to do."
    GR "supongo que tendrá que bastar."

# game/chapters/3_day.rpy:648
translate Spanish chat2_day3_2cdaff6b:

    # player "So what is this 'idea' of yours, then?"
    player "Entonces, ¿cuál es esa 'idea' tuya?"

# game/chapters/3_day.rpy:649
translate Spanish chat2_day3_4b6fcc03:

    # GR "i am going to channel some of my life force into you."
    GR "voy a canalizar parte de mi fuerza vital hacia ti."

# game/chapters/3_day.rpy:652
translate Spanish chat2_day3_9d0cebaf:

    # player "WHAT?!"
    player "¿¡QUÉ!?"

# game/chapters/3_day.rpy:654
translate Spanish chat2_day3_f18cb3f3:

    # player "You've gone insane..."
    player "Te has vuelto loco..."

# game/chapters/3_day.rpy:656
translate Spanish chat2_day3_881b57ac:

    # player "Brilliant! Oh how I've {i}always{/i} dreamed of just that!"
    player "¡Brillante! ¡Oh, cómo he soñado {i}siempre{/i} con eso!"

# game/chapters/3_day.rpy:658
translate Spanish chat2_day3_06079dfd:

    # player "Soul babies...?"
    player "¿Bebés alma...?"

# game/chapters/3_day.rpy:659
translate Spanish chat2_day3_dd14a58b:

    # GR "no, not soul babies... what is with your obsession with that..."
    GR "no, no son bebés alma... ¿qué pasa con tu obsesión con eso...?"

# game/chapters/3_day.rpy:660
translate Spanish chat2_day3_414a9268:

    # GR "however, it is a means of... somewhat mixing our souls."
    GR "sin embargo, es una forma de... mezclar un poco nuestras almas."

# game/chapters/3_day.rpy:664
translate Spanish chat2_day3_2f6bb3ad:

    # player "That's pretty much soul baby territory."
    player "Eso ya es terreno de bebés alma."

# game/chapters/3_day.rpy:665
translate Spanish chat2_day3_ddade3eb:

    # GR "oh, for the love of..."
    GR "oh, por el amor de..."

# game/chapters/3_day.rpy:666
translate Spanish chat2_day3_8454e8d9:

    # GR "it's not soul babies! soul babies are not real!"
    GR "¡no son bebés alma! ¡los bebés alma no son reales!"

# game/chapters/3_day.rpy:667
translate Spanish chat2_day3_9e9d131c:

    # GR "but mixing our souls IS real."
    GR "pero mezclar nuestras almas SÍ es real."

# game/chapters/3_day.rpy:668
translate Spanish chat2_day3_03aa3ef8:

    # GR "perhaps then you will understand."
    GR "quizá entonces lo entenderás."

# game/chapters/3_day.rpy:671
translate Spanish chat2_day3_7b4c0f87:

    # GR "then maybe you will take me seriously."
    GR "entonces tal vez me tomarás en serio."

# game/chapters/3_day.rpy:672
translate Spanish chat2_day3_d4e062aa:

    # GR "as a reaper, it will pose no challenge to me."
    GR "como parca, no supondrá ningún reto para mí."

# game/chapters/3_day.rpy:673
translate Spanish chat2_day3_cefb12c3:

    # GR "in theory."
    GR "en teoría."

# game/chapters/3_day.rpy:676
translate Spanish chat2_day3_0f9e8159:

    # player "Um... er...?"
    player "¿Um... er...?"

# game/chapters/3_day.rpy:678
translate Spanish chat2_day3_bc07100e:

    # player "Uhhh..."
    player "Uhhh..."

# game/chapters/3_day.rpy:680
translate Spanish chat2_day3_3f0691ef:

    # player "Hmmmm..."
    player "Hmmmm..."

# game/chapters/3_day.rpy:683
translate Spanish chat2_day3_20f87ec7:

    # player "How exactly does one 'channel life force'?"
    player "¿Cómo exactamente se 'canaliza la fuerza vital'?"

# game/chapters/3_day.rpy:686
translate Spanish chat2_day3_c3b066c4:

    # player "And what exactly does that mean?"
    player "¿Y qué significa eso exactamente?"

# game/chapters/3_day.rpy:688
translate Spanish chat2_day3_9eaaab79:

    # player "What am I even asking you right now..."
    player "¿Qué te estoy preguntando siquiera...?"

# game/chapters/3_day.rpy:689
translate Spanish chat2_day3_038b87a8:

    # GR "how to channel life force."
    GR "cómo canalizar la fuerza vital."

# game/chapters/3_day.rpy:690
translate Spanish chat2_day3_953fd846:

    # GR "you literally just asked me. how can you not know what you asked?"
    GR "literalmente me acabas de preguntar. ¿cómo puedes no saber lo que preguntaste?"

# game/chapters/3_day.rpy:694
translate Spanish chat2_day3_579510c9:

    # player "I know I've been playing along with your whole Grim Reaper thing..."
    player "Sé que he estado siguiéndote el juego con todo ese cuento de la Parca..."

# game/chapters/3_day.rpy:698
translate Spanish chat2_day3_b59767f5:

    # player "But you've just gotten a buttload stranger."
    player "Pero te has vuelto muchísimo más raro."

# game/chapters/3_day.rpy:700
translate Spanish chat2_day3_3e820e46:

    # GR "i have not lied to you even once since we met."
    GR "no te he mentido ni una sola vez desde que nos conocimos."

# game/chapters/3_day.rpy:701
translate Spanish chat2_day3_405912e4:

    # GR "if you want to prove that, then look into my eyes."
    GR "si quieres probarlo, entonces mírame a los ojos."

# game/chapters/3_day.rpy:702
translate Spanish chat2_day3_b0524994:

    # GR "i will form a connection between us."
    GR "formaré una conexión entre nosotros."

# game/chapters/3_day.rpy:705
translate Spanish chat2_day3_7c991d67:

    # player "Am I on one of those prank shows?"
    player "¿Estoy en uno de esos programas de bromas?"

# game/chapters/3_day.rpy:708
translate Spanish chat2_day3_59c8ec18:

    # player "The camera crew will jump out any second now, right?"
    player "El equipo de cámaras va a aparecer en cualquier momento, ¿verdad?"

# game/chapters/3_day.rpy:711
translate Spanish chat2_day3_0e6e8836:

    # player "They'll be like 'haha you fell for it'."
    player "Dirán 'jaja, caíste'."

# game/chapters/3_day.rpy:712
translate Spanish chat2_day3_cc36dcaa:

    # GR "you will look into my eyes, and i will form a connection between us."
    GR "me mirarás a los ojos, y yo formaré una conexión entre nosotros."

# game/chapters/3_day.rpy:715
translate Spanish chat2_day3_10966c91:

    # player "Cool cool. Not a prank then?"
    player "Genial, genial. ¿Entonces no es una broma?"

# game/chapters/3_day.rpy:716
translate Spanish chat2_day3_fa3ad712:

    # GR "no. not a prank then."
    GR "no. no es una broma."

# game/chapters/3_day.rpy:717
translate Spanish chat2_day3_d288451d:

    # GR "why would i waste my time like that?"
    GR "¿por qué perdería mi tiempo así?"

# game/chapters/3_day.rpy:721
translate Spanish chat2_day3_b47ff063:

    # player "Right... right, I see..."
    player "Cierto... cierto, ya veo..."

# game/chapters/3_day.rpy:722
translate Spanish chat2_day3_03a448f4:

    # GR "the eyes can be seen as a gateway to ones soul."
    GR "los ojos pueden verse como una puerta al alma de uno."

# game/chapters/3_day.rpy:723
translate Spanish chat2_day3_1143c83f:

    # GR "and it is necessary to form the bridge between us."
    GR "y es necesario para formar el puente entre nosotros."

# game/chapters/3_day.rpy:726
translate Spanish chat2_day3_99bbda33:

    # player "A bridge, of course..."
    player "Un puente, claro..."

# game/chapters/3_day.rpy:729
translate Spanish chat2_day3_2a1f257b:

    # player "Can it be a pretty bridge?"
    player "¿Puede ser un puente bonito?"

# game/chapters/3_day.rpy:730
translate Spanish chat2_day3_8dbe6068:

    # GR "if that makes you happy, sure. it's a pretty bridge."
    GR "si eso te hace feliz, claro. es un puente bonito."

# game/chapters/3_day.rpy:732
translate Spanish chat2_day3_3b85adea:

    # player "Can't say a guy's ever wanted to make a mind bridge with me before." id chat2_day3_3b85adea
    player "No puedo decir que un chico haya querido hacer un puente mental conmigo antes." id chat2_day3_3b85adea

# game/chapters/3_day.rpy:733
translate Spanish chat2_day3_9d7beb81:

    # GR "then i'm glad to be your first and only."
    GR "entonces me alegra ser el primero y el único."

# game/chapters/3_day.rpy:736
translate Spanish chat2_day3_98075d84:

    # GR "yes, this should work."
    GR "sí, esto debería funcionar."

# game/chapters/3_day.rpy:737
translate Spanish chat2_day3_c1dd67ac:

    # GR "once a connection is formed, i will transfer a part of my conscience to you."
    GR "una vez que se forme la conexión, transferiré una parte de mi conciencia a ti."

# game/chapters/3_day.rpy:741
translate Spanish chat2_day3_9ddc7146:

    # player "You'll WHAT?"
    player "¿¡Transferirás QUÉ!?"

# game/chapters/3_day.rpy:743
translate Spanish chat2_day3_37ed84d1:

    # player "Oh, brilliant."
    player "Oh, brillante."

# game/chapters/3_day.rpy:746
translate Spanish chat2_day3_7cad1d60:

    # player "This is so totally normal."
    player "Esto es totalmente normal."

# game/chapters/3_day.rpy:747
translate Spanish chat2_day3_4f4c1161:

    # GR "it is not an ability many have."
    GR "no es una habilidad que muchos tengan."

# game/chapters/3_day.rpy:748
translate Spanish chat2_day3_d506c52c:

    # GR "so normal it is not."
    GR "así que normal no es."

# game/chapters/3_day.rpy:751
translate Spanish chat2_day3_f4beb2ed:

    # player "Will it hurt?"
    player "¿Va a doler?"

# game/chapters/3_day.rpy:752
translate Spanish chat2_day3_08690817:

    # GR "if you resist it will."
    GR "si te resistes, sí."

# game/chapters/3_day.rpy:753
translate Spanish chat2_day3_ac55b2c8:

    # GR "the connection will become unstable."
    GR "la conexión se volverá inestable."

# game/chapters/3_day.rpy:754
translate Spanish chat2_day3_f78587cc:

    # GR "and your mind will fight me like the body would fight an infection."
    GR "y tu mente luchará contra mí como el cuerpo lucha contra una infección."

# game/chapters/3_day.rpy:755
translate Spanish chat2_day3_38c583ed:

    # GR "but know that i am stronger, so it is likely your mind would fracture if it were to resist against me."
    GR "pero ten en cuenta que yo soy más fuerte, entonces es probable que tu mente se fracture si intentas resistirte."

# game/chapters/3_day.rpy:758
translate Spanish chat2_day3_03775ec8:

    # player "..."
    player "..."

# game/chapters/3_day.rpy:761
translate Spanish chat2_day3_d95b86db:

    # player "Can I say no?"
    player "¿Puedo decir que no?"

# game/chapters/3_day.rpy:762
translate Spanish chat2_day3_f0d37f25:

    # GR "if you are going to say no, then do so now."
    GR "si vas a decir que no, hazlo ahora."

# game/chapters/3_day.rpy:763
translate Spanish chat2_day3_e77d0b22:

    # GR "because once the connection is formed you will be unable to do so without dire consequences."
    GR "porque una vez que se forme la conexión no podrás hacerlo sin graves consecuencias."

# game/chapters/3_day.rpy:767
translate Spanish chat2_day3_6da45eed:

    # player "What would happen if I wanted to stop afterwards?"
    player "¿Qué pasaría si quisiera detenerlo después?"

# game/chapters/3_day.rpy:768
translate Spanish chat2_day3_1ad436c3:

    # GR "...in that case your mind would fight against me."
    GR "...en ese caso tu mente lucharía contra mí."

# game/chapters/3_day.rpy:769
translate Spanish chat2_day3_ca89ea55:

    # GR "it would try to remove me from your conscience like your body would fight an infection."
    GR "intentaría expulsarme de tu conciencia como tu cuerpo lucharía contra una infección."

# game/chapters/3_day.rpy:770
translate Spanish chat2_day3_5fbdc85a:

    # GR "but because i am stronger, your body would be unable to repell me and it would likely fracture."
    GR "pero como soy más fuerte, tu cuerpo no podría repelerme y probablemente se fracturaría."

# game/chapters/3_day.rpy:773
translate Spanish chat2_day3_03775ec8_1:

    # player "..."
    player "..."

# game/chapters/3_day.rpy:776
translate Spanish chat2_day3_1c4ca8bd:

    # player "Is this like a demonic possession?"
    player "¿Esto es como una posesión demoníaca?"

# game/chapters/3_day.rpy:777
translate Spanish chat2_day3_0a728e26:

    # GR "truthfully?"
    GR "¿la verdad?"

# game/chapters/3_day.rpy:778
translate Spanish chat2_day3_4114d5aa:

    # GR "i suppose so, yes. they are quite similar."
    GR "supongo que sí, son bastante parecidas."

# game/chapters/3_day.rpy:781
translate Spanish chat2_day3_1b98eb03:

    # player "Well..."
    player "Bueno..."

# game/chapters/3_day.rpy:783
translate Spanish chat2_day3_c5fa355c:

    # player "That's... comforting."
    player "Eso es... tranquilizador."

# game/chapters/3_day.rpy:786
translate Spanish chat2_day3_abca771a:

    # player "There is a first time for everything, I guess..."
    player "Siempre hay una primera vez para todo, supongo..."

# game/chapters/3_day.rpy:789
translate Spanish chat2_day3_b51d1e67:

    # player "Lets say you're not lying. What will happen to me?"
    player "Digamos que no estás mintiendo. ¿Qué me pasará?"

# game/chapters/3_day.rpy:790
translate Spanish chat2_day3_9fcc0461:

    # GR "Nothing bad will happen unless you resist me once a connection is made."
    GR "Nada malo pasará a menos que te resistas una vez hecha la conexión."

# game/chapters/3_day.rpy:793
translate Spanish chat2_day3_c299a139:

    # player "And if I do resist?"
    player "¿Y si me resisto?"

# game/chapters/3_day.rpy:794
translate Spanish chat2_day3_fec684e7:

    # GR "your mind will simply break apart and fracture."
    GR "tu mente simplemente se romperá y se fracturará."

# game/chapters/3_day.rpy:795
translate Spanish chat2_day3_791659a8:

    # GR "i am stronger, and your mind will not be able to fight back against me."
    GR "soy más fuerte, y tu mente no podrá luchar contra mí."

# game/chapters/3_day.rpy:798
translate Spanish chat2_day3_03775ec8_2:

    # player "..."
    player "..."

# game/chapters/3_day.rpy:801
translate Spanish chat2_day3_4bf9be1d:

    # player "This IS the soul baby thing again!"
    player "¡Esto SÍ es lo de los bebés alma otra vez!"

# game/chapters/3_day.rpy:802
translate Spanish chat2_day3_5cbd03cc:

    # GR "what...?"
    GR "¿qué...?"

# game/chapters/3_day.rpy:803
translate Spanish chat2_day3_85fa399e:

    # GR "why are you bringing up soul babies again..."
    GR "por qué vuelves a sacar el tema de los bebés alma..."

# game/chapters/3_day.rpy:806
translate Spanish chat2_day3_72221a36:

    # player "If you connect to me via your weird magic..."
    player "Si te conectas a mí a través de tu magia rara..."

# game/chapters/3_day.rpy:809
translate Spanish chat2_day3_b28328a0:

    # player "Seems a little soul baby...y."
    player "Suena un poquito a... bebés alma."

# game/chapters/3_day.rpy:812
translate Spanish chat2_day3_ccdf9f54:

    # player "Don't you think?"
    player "¿No crees?"

# game/chapters/3_day.rpy:813
translate Spanish chat2_day3_5d364529:

    # GR "no."
    GR "no."

# game/chapters/3_day.rpy:814
translate Spanish chat2_day3_3ba28da5:

    # GR "no i do not think so."
    GR "no, no lo creo."

# game/chapters/3_day.rpy:815
translate Spanish chat2_day3_c290d129:

    # GR "no one is having any soul babies."
    GR "nadie está teniendo bebés alma."

# game/chapters/3_day.rpy:816
translate Spanish chat2_day3_9844f214:

    # GR "whatever that means."
    GR "lo que sea que eso signifique."

# game/chapters/3_day.rpy:817
translate Spanish chat2_day3_67dbf160:

    # GR "but you must take this seriously."
    GR "pero debes tomártelo en serio."

# game/chapters/3_day.rpy:818
translate Spanish chat2_day3_d9f63104:

    # GR "if you resist after a connection is formed, then your mind will fracture."
    GR "si te resistes después de que se forma una conexión, entonces tu mente se fracturará."

# game/chapters/3_day.rpy:819
translate Spanish chat2_day3_67841704:

    # GR "you may never be the same again - if you even live."
    GR "puede que nunca vuelvas a ser la misma persona - si es que sigues con vida."

# game/chapters/3_day.rpy:822
translate Spanish chat2_day3_fe835dd1:

    # player "Fracture...?"
    player "¿Fracturar...?"

# game/chapters/3_day.rpy:825
translate Spanish chat2_day3_21b003b6:

    # player "What does that mean?"
    player "¿Qué significa eso?"

# game/chapters/3_day.rpy:826
translate Spanish chat2_day3_7216a76a:

    # GR "your mind would fall apart."
    GR "tu mente se desmoronaría."

# game/chapters/3_day.rpy:827
translate Spanish chat2_day3_7049a667:

    # GR "you will lose the ability to understand life."
    GR "perderás la capacidad de entender la vida."

# game/chapters/3_day.rpy:828
translate Spanish chat2_day3_8e2db5c3:

    # GR "essentially, you will lose yourself."
    GR "básicamente, perderás tu identidad."

# game/chapters/3_day.rpy:831
translate Spanish chat2_day3_476cfad3:

    # player "I wouldn't be me anymore?"
    player "¿Ya no sería yo?"

# game/chapters/3_day.rpy:832
translate Spanish chat2_day3_5d364529_1:

    # GR "no."
    GR "no."

# game/chapters/3_day.rpy:833
translate Spanish chat2_day3_f0a7e89f:

    # GR "you would be a husk. an empty shell of yourself."
    GR "serías un cascarón. un caparazón vacío sin tu esencia."

# game/chapters/3_day.rpy:834
translate Spanish chat2_day3_3bfd8b9f:

    # GR "typically a perfect vessel for a demon to inhabit."
    GR "normalmente un recipiente perfecto para que un demonio lo habite."

# game/chapters/3_day.rpy:835
translate Spanish chat2_day3_bb801d35:

    # GR "and they really are a hassle to deal with, so let's not do that, yeah?"
    GR "y la verdad es que son un fastidio con el que lidiar, así que mejor no lo hagas, ¿sí?"

# game/chapters/3_day.rpy:838
translate Spanish chat2_day3_3c99754b:

    # player "So this is a consensual possession huh..."
    player "Así que esto es una posesión consensuada, eh..."

# game/chapters/3_day.rpy:841
translate Spanish chat2_day3_973caf23:

    # player "And if I change my mind..."
    player "Y si cambio de opinión..."

# game/chapters/3_day.rpy:844
translate Spanish chat2_day3_ae4afc4a:

    # player "Boom, demon time."
    player "Boom, hora de demonios."

# game/chapters/3_day.rpy:845
translate Spanish chat2_day3_3f2a25a6:

    # GR "...when you put it like that, it makes it sound like i am doing something forbidden."
    GR "...cuando lo dices así, parece que estoy haciendo algo prohibido."

# game/chapters/3_day.rpy:848
translate Spanish chat2_day3_5e0ab539:

    # player "Possession sounds pretty forbidden, ngl."
    player "La posesión suena bastante prohibida, no voy a mentir."

# game/chapters/3_day.rpy:849
translate Spanish chat2_day3_7179b856:

    # GR "it doesn't really fall under the classification of possession unless i forcibly take control of your body."
    GR "en realidad no entra en la clasificación de posesión a menos que yo tome el control de tu cuerpo por la fuerza."

# game/chapters/3_day.rpy:852
translate Spanish chat2_day3_bf09947e:

    # player "So you aren't breaking any Underworld rules or anything, then?"
    player "Entonces no estás rompiendo ninguna regla del Inframundo ni nada, ¿verdad?"

# game/chapters/3_day.rpy:853
translate Spanish chat2_day3_7772a27d_3:

    # GR "..."
    GR "..."

# game/chapters/3_day.rpy:856
translate Spanish chat2_day3_560e757d:

    # player "Grim?"
    player "¿Parca?"

# game/chapters/3_day.rpy:857
translate Spanish chat2_day3_46b3437e:

    # GR "shall we begin?"
    GR "¿comenzamos?"

# game/chapters/3_day.rpy:859
translate Spanish chat2_day3_6fde1de2:

    # player "Are you not going to answer me?"
    player "¿No me vas a responder?"

# game/chapters/3_day.rpy:860
translate Spanish chat2_day3_46b3437e_1:

    # GR "shall we begin?"
    GR "¿comenzamos?"

# game/chapters/3_day.rpy:862
translate Spanish chat2_day3_463f62e6:

    # player "You naughty boy."
    player "Chico travieso."

# game/chapters/3_day.rpy:865
translate Spanish chat2_day3_735c599c:

    # player "How many rules are you about to break?"
    player "¿Cuántas reglas estás a punto de romper?"

# game/chapters/3_day.rpy:867
translate Spanish chat2_day3_2a0dd936:

    # GR "does it matter?"
    GR "¿importa?"

# game/chapters/3_day.rpy:868
translate Spanish chat2_day3_acc26cec:

    # GR "also, when you call me a 'naughty boy' it gives me a strange feeling."
    GR "además, cuando me llamas 'chico travieso' me da una sensación extraña."

# game/chapters/3_day.rpy:869
translate Spanish chat2_day3_deac2224:

    # GR "i am unsure if it is a good one or not..."
    GR "no estoy seguro si es buena o no..."

# game/chapters/3_day.rpy:870
translate Spanish chat2_day3_fec30ed0:

    # GR "a... anyway... shall we begin?"
    GR "e... en fin... ¿comenzamos?"

# game/chapters/3_day.rpy:905
translate Spanish call2_day3_bb81093d:

    # GRC "Ugh. I suppose it is needed."
    GRC "Ugh. Supongo que es necesario."

# game/chapters/3_day.rpy:906
translate Spanish call2_day3_909b07d3:

    # GRC "Fine, whatever."
    GRC "Está bien, como sea."

# game/chapters/3_day.rpy:915
translate Spanish call2_day3_d888a238:

    # GRC "... Happy now?"
    GRC "... ¿Feliz ahora?"

# game/chapters/3_day.rpy:922
translate Spanish call2_day3_f7507b35:

    # GRC "What?"
    GRC "¿Qué?"

# game/chapters/3_day.rpy:927
translate Spanish call2_day3_48189bee:

    # GRC "It is not something visible to the eye."
    GRC "No es algo visible para el ojo."

# game/chapters/3_day.rpy:928
translate Spanish call2_day3_67d6997c:

    # GRC "Nor is it anything for you to think heavily on. So, no need to bring it up."
    GRC "Ni es algo en lo que debas pensar demasiado. Así que no hay necesidad de mencionarlo."

# game/chapters/3_day.rpy:940
translate Spanish call2_day3_93893336:

    # GRC "It is simply my... mind..."
    GRC "Es simplemente mi... mente..."

# game/chapters/3_day.rpy:955
translate Spanish call2_day3_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/3_day.rpy:960
translate Spanish call2_day3_b35d329c:

    # GRC "I suppose that would be the sensible thing to do."
    GRC "Supongo que eso sería lo sensato."

# game/chapters/3_day.rpy:962
translate Spanish call2_day3_9633a042:

    # GRC "But it is nothing I haven't dealt with before."
    GRC "Pero no es nada con lo que no haya lidiado antes."

# game/chapters/3_day.rpy:963
translate Spanish call2_day3_1e13d6b8:

    # GRC "Let's go ahead with it." id call2_day3_1e13d6b8
    GRC "Sigamos adelante con esto." id call2_day3_1e13d6b8

# game/chapters/3_day.rpy:970
translate Spanish call2_day3_8a3f779b:

    # GRC "As long as I don't delve into your mind too deep, it will be fine."
    GRC "Mientras no me adentre demasiado en tu mente, estará bien."

# game/chapters/3_day.rpy:982
translate Spanish call2_day3_1f30677b:

    # GRC "Just..."
    GRC "Solo..."

# game/chapters/3_day.rpy:989
translate Spanish call2_day3_ff23f32b:

    # GRC "Don't look away until the connection is formed."
    GRC "No apartes la mirada hasta que la conexión se forme."

# game/chapters/3_day.rpy:996
translate Spanish call2_day3_95b8f436:

    # GRC "You will feel it."
    GRC "La sentirás."

# game/chapters/3_day.rpy:998
translate Spanish call2_day3_8e3be946:

    # GRC "And I shall tell you, of course."
    GRC "Y yo te lo diré, por supuesto."

# game/chapters/3_day.rpy:1003
translate Spanish call2_day3_103bf42b:

    # GRC "Once I've connected to you, my conscience will merge with yours."
    GRC "Una vez que me haya conectado a ti, mi conciencia se fusionará con la tuya."

# game/chapters/3_day.rpy:1005
translate Spanish call2_day3_37fa96e7:

    # GRC "You should feel me around you... just don't try to push me away."
    GRC "Deberías sentirme a tu alrededor... solo no intentes apartarme."

# game/chapters/3_day.rpy:1007
translate Spanish call2_day3_fc97b3af:

    # GRC "If you try to force me out, it will cause an imbalance in our connection."
    GRC "Si intentas forzarme a salir, causará un desequilibrio en nuestra conexión."

# game/chapters/3_day.rpy:1016
translate Spanish call2_day3_7f878fca:

    # GRC "Don't be ridiculous. This isn't some party trick."
    GRC "No digas tonterías. Esto no es un truco de feria."

# game/chapters/3_day.rpy:1017
translate Spanish call2_day3_cf6321a0:

    # GRC "You want me to prove I'm serious."
    GRC "Quieres que te demuestre que hablo en serio."

# game/chapters/3_day.rpy:1019
translate Spanish call2_day3_88f3303c:

    # GRC "And I want answers."
    GRC "Y yo quiero respuestas."

# game/chapters/3_day.rpy:1020
translate Spanish call2_day3_d0854dd6:

    # GRC "This is mutually beneficial."
    GRC "Esto es mutuamente beneficioso."

# game/chapters/3_day.rpy:1026
translate Spanish call2_day3_f1f51354:

    # GRC "Look for said answers."
    GRC "Buscar dichas respuestas."

# game/chapters/3_day.rpy:1038
translate Spanish call2_day3_ad3eb625:

    # GRC "Nine hells, you ask so many questions."
    GRC "Por los nueve infiernos, haces tantas preguntas."

# game/chapters/3_day.rpy:1050
translate Spanish call2_day3_af5245db:

    # GRC "I am going to examine your aura. Feel it. Smell it."
    GRC "Voy a examinar tu aura. Sentirla. Olerla."

# game/chapters/3_day.rpy:1060
translate Spanish call2_day3_761346b4:

    # GRC "And maybe it will give me answers on what is stopping me from completing this godforsaken task."
    GRC "Y quizá me dé respuestas sobre qué me impide completar esta maldita tarea."

# game/chapters/3_day.rpy:1077
translate Spanish call2_day3_156be910:

    # GRC "Hmm. I suppose that's a fair comment."
    GRC "Hmm. Supongo que es un comentario justo."

# game/chapters/3_day.rpy:1079
translate Spanish call2_day3_b70e0b2f:

    # GRC "I will do nothing to harm you. You can trust me."
    GRC "No haré nada para hacerte daño. Puedes confiar en mí."

# game/chapters/3_day.rpy:1086
translate Spanish call2_day3_78364dbf:

    # GRC "I cannot lie. I will not touch a single hair on your head."
    GRC "No puedo mentir. No tocaré ni un solo cabello de tu cabeza."

# game/chapters/3_day.rpy:1095
translate Spanish call2_day3_c7886767:

    # GRC "Well, are you prepared?"
    GRC "Bueno, ¿estás list[letra]?"

# game/chapters/3_day.rpy:1104
translate Spanish call2_day3_b96d24a7:

    # GRC "That's a lot of trust."
    GRC "Eso es mucha confianza."

# game/chapters/3_day.rpy:1119
translate Spanish call2_day3_76462a84:

    # GRC "Stay still, and prepare yourself."
    GRC "No te muevas y prepárate."

# game/chapters/3_day.rpy:1120
translate Spanish call2_day3_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/3_day.rpy:1124
translate Spanish call2_day3_0bac6bac:

    # GRC "......."
    GRC "......."

# game/chapters/3_day.rpy:1126
translate Spanish call2_day3_8382cae1:

    # GRC ".....Nearly... there...."
    GRC ".....Ya... casi...."

# game/chapters/3_day.rpy:1134
translate Spanish call2_day3_817b3c07:

    # GRC "...Shh. Don't break my concentration."
    GRC "...Shh. No rompas mi concentración."

# game/chapters/3_day.rpy:1139
translate Spanish call2_day3_daca2608:

    # GRC "Stop wiggling. You will cause irreparable damage, and it will be your fault entirely. I will not feel sorry for you."
    GRC "Deja de moverte. Causarás daños irreparables, y será enteramente tu culpa. No sentiré lástima por ti."

# game/chapters/3_day.rpy:1141
translate Spanish call2_day3_4ccae361:

    # GRC "Just keep your eyes on me."
    GRC "Solo mantén tus ojos en mí."

# game/chapters/3_day.rpy:1149
translate Spanish call2_day3_0d38c0cd:

    # GRC "There you are."
    GRC "Ahí estás."

# game/chapters/3_day.rpy:1171
translate Spanish call2_day3_e030fb39:

    # GRC "The connection is stable. Which is lucky, by the way, because of all of your wiggling."
    GRC "La conexión es estable. Lo cual es una suerte, por cierto, porque no paras de moverte."

# game/chapters/3_day.rpy:1193
translate Spanish call2_day3_042240ac:

    # GRC "There's no tricks. You and I are now linked - even you can tell that."
    GRC "No hay trucos. Tú y yo ahora estamos vinculados - incluso tú puedes sentirlo."

# game/chapters/3_day.rpy:1194
translate Spanish call2_day3_f7e58670:

    # GRC "Would a regular mortal be able to do that?"
    GRC "¿Un mortal común podría hacer eso?"

# game/chapters/3_day.rpy:1201
translate Spanish call2_day3_de5784ca:

    # GRC "Even you could tell how extraordinary I am. That makes sense."
    GRC "Incluso tú podrías notar lo extraordinario que soy. Tiene sentido."

# game/chapters/3_day.rpy:1204
translate Spanish call2_day3_c76e14ce:

    # GRC "Thank you."
    GRC "Gracias."

# game/chapters/3_day.rpy:1215
translate Spanish call2_day3_07ab7154:

    # GRC "...What?"
    GRC "...¿Qué?"

# game/chapters/3_day.rpy:1217
translate Spanish call2_day3_42a4fd20:

    # GRC "I'm cold?"
    GRC "¿Soy frío?"

# game/chapters/3_day.rpy:1222
translate Spanish call2_day3_2c8639a4:

    # GRC "I'm surprised you can feel that."
    GRC "Me sorprende que puedas sentir eso."

# game/chapters/3_day.rpy:1224
translate Spanish call2_day3_d7d7625e:

    # GRC "Our connection is stable, sure, but—"
    GRC "Nuestra conexión es estable, claro, pero—"

# game/chapters/3_day.rpy:1246
translate Spanish call2_day3_32f44438:

    # GRC "Yes."
    GRC "Sí."

# game/chapters/3_day.rpy:1248
translate Spanish call2_day3_71206a6e:

    # GRC "As I have been telling you this entire time."
    GRC "Como te he estado diciendo todo este tiempo."

# game/chapters/3_day.rpy:1249
translate Spanish call2_day3_c4781c90:

    # GRC "I am always truthful. It seems that you'll finally start to believe me."
    GRC "Siempre digo la verdad. Parece que por fin empezarás a creerme."

# game/chapters/3_day.rpy:1255
translate Spanish call2_day3_6cf100e9:

    # GRC "That is a question bigger than you or I."
    GRC "Esa es una pregunta más grande que tú y yo."

# game/chapters/3_day.rpy:1256
translate Spanish call2_day3_a3e5da16:

    # GRC "It simply is."
    GRC "Simplemente lo es."

# game/chapters/3_day.rpy:1258
translate Spanish call2_day3_5514a0c7:

    # GRC "Anyway, do you feel that?"
    GRC "En fin, ¿sientes eso?"

# game/chapters/3_day.rpy:1266
translate Spanish call2_day3_25eaff11:

    # GRC "Uh, not that feeling."
    GRC "Eh, esa no es la sensación."

# game/chapters/3_day.rpy:1267
translate Spanish call2_day3_9ca17487:

    # GRC "That's just an itch."
    GRC "Eso es solo una picazón."

# game/chapters/3_day.rpy:1268
translate Spanish call2_day3_11e426f8:

    # GRC "The connection, you moron."
    GRC "La conexión, idiota."

# game/chapters/3_day.rpy:1274
translate Spanish call2_day3_8baf5f41:

    # GRC "Good."
    GRC "Bien."

# game/chapters/3_day.rpy:1277
translate Spanish call2_day3_5188dba1:

    # GRC "Not until I transfer a part of my conscience into you."
    GRC "No hasta que transfiera una parte de mi conciencia en ti."

# game/chapters/3_day.rpy:1281
translate Spanish call2_day3_6fbe03f4:

    # GRC "No."
    GRC "No."

# game/chapters/3_day.rpy:1282
translate Spanish call2_day3_82a25e07:

    # GRC "All I've done is link us together. Think of it as a bond, of sorts."
    GRC "Todo lo que he hecho es enlazarnos. Piénsalo como un vínculo, por así decirlo."

# game/chapters/3_day.rpy:1284
translate Spanish call2_day3_3cb55cfa:

    # GRC "Part of myself will flow through your aura, and then my conscience will be inside you. Then I could, technically, see through your eyes."
    GRC "Parte de mí fluirá a través de tu aura, y entonces mi conciencia estará dentro de ti. Entonces podría, técnicamente, ver a través de tus ojos."

# game/chapters/3_day.rpy:1287
translate Spanish call2_day3_03a57a79:

    # GRC "It makes perfect sense."
    GRC "Tiene perfecto sentido."

# game/chapters/3_day.rpy:1296
translate Spanish call2_day3_7bed9a38:

    # GRC "More sarcasm! How fascinating."
    GRC "¡Más sarcasmo! Fascinante."

# game/chapters/3_day.rpy:1302
translate Spanish call2_day3_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/3_day.rpy:1304
translate Spanish call2_day3_9a965323:

    # GRC "That depends what kind of questionable things you mean."
    GRC "Eso depende del tipo de cosas cuestionables que quieras decir."

# game/chapters/3_day.rpy:1305
translate Spanish call2_day3_f2188eda:

    # GRC "Sort through your soul? Sure, I'll do that."
    GRC "¿Revisar tu alma? Claro, haré eso."

# game/chapters/3_day.rpy:1307
translate Spanish call2_day3_4a22ef0a:

    # GRC "If you mean... other... things... ahem..."
    GRC "Si te refieres a... otras... cosas... ejem..."

# game/chapters/3_day.rpy:1308
translate Spanish call2_day3_50ef4161:

    # GRC "That is something... I would... uh..."
    GRC "Eso es algo... que yo... eh..."

# game/chapters/3_day.rpy:1310
translate Spanish call2_day3_f85ac0fe:

    # GRC "Do only... with permission. Ahem."
    GRC "Haría solo... con permiso. Ejem."

# game/chapters/3_day.rpy:1315
translate Spanish call2_day3_e75ef172:

    # GRC "Anyway! No, I won't be doing that!"
    GRC "¡En fin! ¡No, no haré eso!"

# game/chapters/3_day.rpy:1316
translate Spanish call2_day3_cafba14d:

    # GRC "I am a Grim Reaper! You are a mortal! That would be way, way outside of my job description. So far out I would likely be fired."
    GRC "¡Soy una Parca! ¡Tú eres un mortal! Eso estaría muy, muy fuera de mi descripción de trabajo. Tan fuera que probablemente me despedirían."

# game/chapters/3_day.rpy:1321
translate Spanish call2_day3_7db04a0b:

    # GRC "I don't think I'll ever understand you."
    GRC "Creo que nunca te entenderé."

# game/chapters/3_day.rpy:1322
translate Spanish call2_day3_5dfa15c6:

    # GRC "You flirt with death for your own amusement."
    GRC "Coqueteas con la muerte para tu propia diversión."

# game/chapters/3_day.rpy:1330
translate Spanish call2_day3_9467829c:

    # GRC "....."
    GRC "....."

# game/chapters/3_day.rpy:1331
translate Spanish call2_day3_77dc5b2c:

    # GRC "S... souls! We were talking about souls!"
    GRC "¡A... almas! ¡Estábamos hablando de almas!"

# game/chapters/3_day.rpy:1333
translate Spanish call2_day3_a82c2aab:

    # GRC "Nine hells, I think this connection is getting to me already..."
    GRC "Por los nueve infiernos, creo que esta conexión ya me está afectando..."

# game/chapters/3_day.rpy:1335
translate Spanish call2_day3_a2a69de4:

    # GRC "Suddenly it's far too hot in here..."
    GRC "De repente hace demasiado calor aquí..."

# game/chapters/3_day.rpy:1338
translate Spanish call2_day3_b02531c5:

    # GRC "Perhaps you should find a tamer hobby."
    GRC "Quizás deberías encontrar un pasatiempo más tranquilo."

# game/chapters/3_day.rpy:1339
translate Spanish call2_day3_0a1fe0ce:

    # GRC "Gardening, perhaps. Baking."
    GRC "Jardinería, quizá. Repostería."

# game/chapters/3_day.rpy:1340
translate Spanish call2_day3_f67ff381:

    # GRC "This is a very serious situation we're in, you know."
    GRC "Estamos en una situación muy seria, ¿sabes?"

# game/chapters/3_day.rpy:1341
translate Spanish call2_day3_be695808:

    # GRC "Let's... concentrate on that, for the moment."
    GRC "Concentrémonos... en eso, por el momento."

# game/chapters/3_day.rpy:1345
translate Spanish call2_day3_62a8368c:

    # GRC "Per... perhaps..."
    GRC "Qui... quizás..."

# game/chapters/3_day.rpy:1347
translate Spanish call2_day3_54105e5e:

    # GRC "I mean, no! There... can't be any relationship other than what we have. The cat, and the mouse."
    GRC "Quiero decir, ¡no! No... no puede haber ninguna relación distinta a la que tenemos. El gato y el ratón."

# game/chapters/3_day.rpy:1349
translate Spanish call2_day3_fa5cb2ea:

    # GRC "Let's... concentrate on the very serious situation we're in, rather than this strange flirting-teasing thing you're doing."
    GRC "Concentrémonos en la grave situación en la que nos encontramos, en lugar de en este extraño coqueteo que estás haciendo."

# game/chapters/3_day.rpy:1357
translate Spanish call2_day3_d7ae7e2b:

    # GRC "Yes?"
    GRC "¿Sí?"

# game/chapters/3_day.rpy:1364
translate Spanish call2_day3_07bbcd70:

    # GRC "You will be fine."
    GRC "Estarás bien."

# game/chapters/3_day.rpy:1366
translate Spanish call2_day3_3aa0971f:

    # GRC "The bridge between us is quite stable."
    GRC "El puente entre nosotros es bastante estable."

# game/chapters/3_day.rpy:1367
translate Spanish call2_day3_ca8c436a:

    # GRC "It seems you and I are quite suited to each other."
    GRC "Parece que tú y yo somos bastante compatibles."

# game/chapters/3_day.rpy:1370
translate Spanish call2_day3_9c9b6d2a:

    # GRC "You disagree?"
    GRC "¿No estás de acuerdo?"

# game/chapters/3_day.rpy:1380
translate Spanish call2_day3_dbd8c7a5:

    # GRC "I... also don't know."
    GRC "Yo... tampoco lo sé."

# game/chapters/3_day.rpy:1381
translate Spanish call2_day3_502f3300:

    # GRC "Maybe we'll find out together."
    GRC "Quizá lo descubramos juntos."

# game/chapters/3_day.rpy:1384
translate Spanish call2_day3_457b73e6:

    # GRC "Good. This is the start of a... partnership between the two of us."
    GRC "Bien. Este es el comienzo de una... asociación entre los dos."

# game/chapters/3_day.rpy:1389
translate Spanish call2_day3_9174e19a:

    # GRC "It means you can keep it today. Is that good enough?"
    GRC "Significa que hoy puedes quedártela. ¿Eso es suficiente?"

# game/chapters/3_day.rpy:1396
translate Spanish call2_day3_d7bcf2a0:

    # GRC "What a fantastic base for a partnership!"
    GRC "¡Qué base tan fantástica para una asociación!"

# game/chapters/3_day.rpy:1401
translate Spanish call2_day3_d51f4a07:

    # GRC "I'm trying to help you pass on. I'd say that's just SLIGHTLY nicer than murder."
    GRC "Estoy intentando ayudarte a pasar al otro lado. Diría que eso es SOLO un POQUITO más amable que asesinar."

# game/chapters/3_day.rpy:1406
translate Spanish call2_day3_3642f779:

    # GRC "Of course not. This duty belongs to me alone."
    GRC "Por supuesto que no. Este deber me pertenece solo a mí."

# game/chapters/3_day.rpy:1417
translate Spanish call2_day3_008afe10_3:

    # GRC "..."
    GRC "..."

# game/chapters/3_day.rpy:1418
translate Spanish call2_day3_cfbabf5f:

    # GRC "You truly do worry me."
    GRC "Realmente me preocupas."

# game/chapters/3_day.rpy:1419
translate Spanish call2_day3_92c4a18d:

    # GRC "You shouldn't trust random people from the internet."
    GRC "No deberías confiar en personas al azar de internet."

# game/chapters/3_day.rpy:1421
translate Spanish call2_day3_922c1d16:

    # GRC "Least of all ones that seek your death." id call2_day3_922c1d16
    GRC "Y menos aún en quienes buscan tu muerte." id call2_day3_922c1d16

# game/chapters/3_day.rpy:1436
translate Spanish call2_day3_22fa2871:

    # GRC "Yes, well, I somewhat felt it too."
    GRC "Sí, bueno, yo también lo sentí un poco."

# game/chapters/3_day.rpy:1437
translate Spanish call2_day3_9d77998f:

    # GRC "It is the connection between the living and the dead, perhaps."
    GRC "Es la conexión entre los vivos y los muertos, quizá."

# game/chapters/3_day.rpy:1438
translate Spanish call2_day3_85207a95:

    # GRC "But for now, we can put aside thought of hunted and hunter, and just be two people bound together for a possession based investigation."
    GRC "Pero por ahora, podemos dejar a un lado la idea de cazador y presa, y ser solo dos personas unidas para una investigación basada en la posesión."

# game/chapters/3_day.rpy:1449
translate Spanish call2_day3_75fbbae3:

    # GRC "Picture our connection—a bridge."
    GRC "Imagina nuestra conexión—un puente."

# game/chapters/3_day.rpy:1457
translate Spanish call2_day3_72472818:

    # GRC "Very impressive. Congratulations."
    GRC "Muy impresionante. Felicitaciones."

# game/chapters/3_day.rpy:1459
translate Spanish call2_day3_82bc55b0:

    # GRC "One side is yours, and the other side is mine."
    GRC "Un lado es tuyo, y el otro lado es mío."

# game/chapters/3_day.rpy:1461
translate Spanish call2_day3_95f2abf0:

    # GRC "I am simply going to walk across the bridge with part of my conscience."
    GRC "Simplemente voy a cruzar el puente con parte de mi conciencia."

# game/chapters/3_day.rpy:1470
translate Spanish call2_day3_340f028e:

    # GRC "When I tell you to, you simply close your eyes."
    GRC "Cuando te lo diga, simplemente cierra los ojos."

# game/chapters/3_day.rpy:1471
translate Spanish call2_day3_e3e770ca:

    # GRC "But hold tight to the handles, okay? That is the 'pull' of my mind."
    GRC "Pero agárrate bien a las manijas, ¿okey? Ese es el 'tirón' de mi mente."

# game/chapters/3_day.rpy:1475
translate Spanish call2_day3_f52edd4f:

    # GRC "Then you can say bye-bye to your mind as you know it."
    GRC "Entonces podrás decirle adiós a tu mente tal y como la conoces."

# game/chapters/3_day.rpy:1483
translate Spanish call2_day3_4becea21:

    # GRC "Do not let go, for crying out loud."
    GRC "No te sueltes, por el amor de Dios."

# game/chapters/3_day.rpy:1494
translate Spanish call2_day3_1e5c3891:

    # GRC "I would pull out of your mind."
    GRC "Yo saldría de tu mente."

# game/chapters/3_day.rpy:1495
translate Spanish call2_day3_54a9a1ff:

    # GRC "No doubt pulling parts of you out when I do so."
    GRC "Sin duda arrancando partes de ti cuando lo haga."

# game/chapters/3_day.rpy:1503
translate Spanish call2_day3_cee37a28:

    # GRC "Good choice."
    GRC "Buena elección."

# game/chapters/3_day.rpy:1511
translate Spanish call2_day3_8baf5f41_1:

    # GRC "Good."
    GRC "Bien."

# game/chapters/3_day.rpy:1512
translate Spanish call2_day3_536114c8:

    # GRC "Make sure you do."
    GRC "Asegúrate de hacerlo."

# game/chapters/3_day.rpy:1514
translate Spanish call2_day3_17d9d022:

    # GRC "I don't want to deal with the consequences of any... unfortunate accidents."
    GRC "No quiero lidiar con las consecuencias de... accidentes desafortunados."

# game/chapters/3_day.rpy:1515
translate Spanish call2_day3_4dc65b25:

    # GRC "Though, as you said, it would make my job a little easier."
    GRC "Aunque, como dijiste, eso haría mi trabajo un poco más fácil."

# game/chapters/3_day.rpy:1521
translate Spanish call2_day3_8f08b604:

    # GRC "That would only happen if the connection became unstable."
    GRC "Eso solo pasaría si la conexión se volviera inestable."

# game/chapters/3_day.rpy:1522
translate Spanish call2_day3_3fc20621:

    # GRC "And if that happens, it would be too late."
    GRC "Y si eso pasa, sería demasiado tarde."

# game/chapters/3_day.rpy:1524
translate Spanish call2_day3_0c2b81d0:

    # GRC "The fracturing would have begun."
    GRC "La fractura ya habría comenzado."

# game/chapters/3_day.rpy:1531
translate Spanish call2_day3_0c84ca80:

    # GRC "As long as you don't push me away, yes."
    GRC "Mientras no me rechaces, sí."

# game/chapters/3_day.rpy:1539
translate Spanish call2_day3_8baf5f41_2:

    # GRC "Good."
    GRC "Bien."

# game/chapters/3_day.rpy:1543
translate Spanish call2_day3_ec005d67:

    # GRC "Phew..."
    GRC "Uf..."

# game/chapters/3_day.rpy:1544
translate Spanish call2_day3_7c6374f6:

    # GRC "I'm going to begin crossing. Take a deep breath and remain calm."
    GRC "Voy a empezar a cruzar. Respira hondo y mantén la calma."

# game/chapters/3_day.rpy:1553
translate Spanish call2_day3_ed252907:

    # GRC "Shush."
    GRC "Shh."

# game/chapters/3_day.rpy:1556
translate Spanish call2_day3_96d53414:

    # GRC "You're already distracting me..."
    GRC "Ya me estás distrayendo..."

# game/chapters/3_day.rpy:1557
translate Spanish call2_day3_06722590:

    # GRC "This is honestly the stupidest idea I've ever had..."
    GRC "Honestamente, esta es la idea más estúpida que he tenido jamás..."

# game/chapters/3_day.rpy:1559
translate Spanish call2_day3_5be08171:

    # GRC "Also, what is with this 'babygirl' thing? How am I 'babygirl'?"
    GRC "Además, ¿qué es eso de 'babygirl'? ¿Cómo que soy 'babygirl'?"

# game/chapters/3_day.rpy:1564
translate Spanish call2_day3_d5608f39:

    # GRC "Pathetic... but cute..."
    GRC "Patético... pero lindo..."

# game/chapters/3_day.rpy:1565
translate Spanish call2_day3_77e53b52:

    # GRC "I have a history of accomplishments, I'm an overachiever, and yet you call me pathetic..."
    GRC "Tengo un historial de logros, soy una persona de alto rendimiento, y aun así me llamas patético..."

# game/chapters/3_day.rpy:1566
translate Spanish call2_day3_37405e56:

    # GRC "...Let's just... get back to the whole soul thing..."
    GRC "...Volvamos... al tema del alma..."

# game/chapters/3_day.rpy:1568
translate Spanish call2_day3_832183f4:

    # GRC "'Malewife'?"
    GRC "¿'Malewife'?"

# game/chapters/3_day.rpy:1570
translate Spanish call2_day3_1e98daca:

    # GRC "Again and again you use these words that don't make sense to me."
    GRC "Una y otra vez usas esas palabras que no tienen sentido para mí."

# game/chapters/3_day.rpy:1574
translate Spanish call2_day3_063b53f3:

    # GRC "Fine... then I'll be the greatest malewife in all of history."
    GRC "Bien... entonces seré el mejor malewife de toda la historia."

# game/chapters/3_day.rpy:1575
translate Spanish call2_day3_c8a42292:

    # GRC "Anyway, back to the matter at hand."
    GRC "En fin, volvamos al asunto en cuestión."

# game/chapters/3_day.rpy:1579
translate Spanish call2_day3_20ba1990:

    # GRC "What were you about to say?"
    GRC "¿Qué estabas a punto de decir?"

# game/chapters/3_day.rpy:1580
translate Spanish call2_day3_5c410cb2:

    # GRC "Submissive and what?"
    GRC "¿Sumiso y qué?"

# game/chapters/3_day.rpy:1583
translate Spanish call2_day3_642ba8e2:

    # GRC "Now I'm worried about it!"
    GRC "¡Ahora sí me preocupa!"

# game/chapters/3_day.rpy:1585
translate Spanish call2_day3_5046cc95:

    # GRC "We can come back to this later. For now, let's just worry about not getting either of us killed."
    GRC "Podemos volver a esto más tarde. Por ahora, preocupémonos solo de que no nos maten a ninguno de los dos."

# game/chapters/3_day.rpy:1588
translate Spanish call2_day3_0e06ec48:

    # GRC "Close your eyes."
    GRC "Cierra los ojos."

# game/chapters/3_day.rpy:1594
translate Spanish call2_day3_cc38fc20:

    # GRC "When I've made it across, you can open them again."
    GRC "Cuando haya cruzado, puedes abrirlos de nuevo."

# game/chapters/3_day.rpy:1597
translate Spanish call2_day3_008afe10_4:

    # GRC "..."
    GRC "..."

# game/chapters/3_day.rpy:1602
translate Spanish call2_day3_d1cec93b:

    # GRC "........."
    GRC "........."

# game/chapters/3_day.rpy:1607
translate Spanish call2_day3_73b2cd1f:

    # GRC "Huh... that doesn't make sense..."
    GRC "Eh... eso no tiene sentido..."

# game/chapters/3_day.rpy:1608
translate Spanish call2_day3_ad439b6e:

    # GRC "Interesting."
    GRC "Interesante."

# game/chapters/3_day.rpy:1609
translate Spanish call2_day3_0bac6bac_1:

    # GRC "......."
    GRC "......."

# game/chapters/3_day.rpy:1626
translate Spanish call2_day3_08479fca:

    # GRC "Mortal, calm down."
    GRC "Mortal, cálmate."

# game/chapters/3_day.rpy:1627
translate Spanish call2_day3_85f17563:

    # GRC "Stop worrying so much. As long as you stay calm, then nothing will go wrong."
    GRC "Deja de preocuparte tanto. Mientras estés en calma, nada saldrá mal."

# game/chapters/3_day.rpy:1637
translate Spanish call2_day3_ad4cfaa1:

    # GRC "...That was too close."
    GRC "...Eso estuvo demasiado cerca."

# game/chapters/3_day.rpy:1638
translate Spanish call2_day3_7c0482d2:

    # GRC "You seriously know how to stress me out..."
    GRC "De verdad sabes cómo estresarme..."

# game/chapters/3_day.rpy:1645
translate Spanish call2_day3_2ef2fbda:

    # GRC "I'm nearly there. Stay composed for a little longer."
    GRC "Ya casi estoy. Mantén la calma un poco más."

# game/chapters/3_day.rpy:1649
translate Spanish call2_day3_1dc1b57f:

    # GRC "[playerfirstname]."
    GRC "[playerfirstname]."

# game/chapters/3_day.rpy:1658
translate Spanish call2_day3_66d15173:

    # GRC "Stop it, immediately!"
    GRC "¡Detente, inmediatamente!"

# game/chapters/3_day.rpy:1659
translate Spanish call2_day3_48020b0b:

    # GRC "If you do this, then everything will be lost. Everything."
    GRC "Si haces esto, entonces todo se perderá. Todo."

# game/chapters/3_day.rpy:1668
translate Spanish call2_day3_3109da83:

    # GRC "Listen to me. Hear my words clearly."
    GRC "Escúchame. Oye mis palabras con claridad."

# game/chapters/3_day.rpy:1669
translate Spanish call2_day3_84741030:

    # GRC "I am not your enemy. I have never been your enemy."
    GRC "No soy tu enemigo. Nunca he sido tu enemigo."

# game/chapters/3_day.rpy:1670
translate Spanish call2_day3_d160e9d4:

    # GRC "I do not lie. You can trust me. I will do nothing to harm you with this."
    GRC "No miento. Puedes confiar en mí. No haré nada para dañarte con esto."

# game/chapters/3_day.rpy:1674
translate Spanish call2_day3_ec744a5b:

    # GRC "If this is supposed to be trying, I wouldn't want to see what the opposite of that is to you!"
    GRC "¡Si esto es tu esfuerzo, no quiero ni imaginar cómo es lo contrario para ti!"

# game/chapters/3_day.rpy:1675
translate Spanish call2_day3_2050c58e:

    # GRC "If you want to die, congratulations. You're well on your way."
    GRC "Si quieres morir, felicidades. Vas muy bien encaminad[letra]."

# game/chapters/3_day.rpy:1679
translate Spanish call2_day3_61010b1b:

    # GRC "Then CALM yourself!"
    GRC "¡Entonces CÁLMATE!"

# game/chapters/3_day.rpy:1680
translate Spanish call2_day3_afb53797:

    # GRC "Picture my hand reaching out to you!"
    GRC "¡Imagina mi mano extendiéndose hacia ti!"

# game/chapters/3_day.rpy:1685
translate Spanish call2_day3_0663108b:

    # GRC "Grab it!"
    GRC "¡Agárrala!"

# game/chapters/3_day.rpy:1692
translate Spanish call2_day3_6a6ed550:

    # GRC "Mortal, you nearly... ugh."
    GRC "Mortal, estuviste a punto de... ugh."

# game/chapters/3_day.rpy:1693
translate Spanish call2_day3_0964b9fa:

    # GRC "Do not let go until I tell you to."
    GRC "No la sueltes hasta que yo te lo diga."

# game/chapters/3_day.rpy:1700
translate Spanish call2_day3_cde14dca:

    # GRC "... I've got you."
    GRC "... Te tengo."

# game/chapters/3_day.rpy:1712
translate Spanish call2_day3_b1599809:

    # GRC "[playerfirstname]!"
    GRC "¡[playerfirstname]!"

# game/chapters/3_day.rpy:1719
translate Spanish call2_day3_eadf4ace:

    # GRC "Then calm! I will leave, but calm first!"
    GRC "¡Entonces calma! Me iré, pero ¡cálmate primero!"

# game/chapters/3_day.rpy:1724
translate Spanish call2_day3_23a4aab5:

    # GRC "If you don't stop, you will be dead before I can leave!"
    GRC "¡Si no te detienes, morirás antes de que yo pueda irme!"

# game/chapters/3_day.rpy:1730
translate Spanish call2_day3_892ad15d:

    # GRC "Sunshine...!"
    GRC "¡Solecito...!"

# game/chapters/3_day.rpy:1740
translate Spanish call2_day3_dd0da2cc:

    # GRC "{sc=2}No... it's... too.. late...{/sc}"
    GRC "{sc=2}No... es... demasiado... tarde...{/sc}"

# game/chapters/3_day.rpy:1741
translate Spanish call2_day3_b8fee30c:

    # GRC "{sc=2}Sun... shine...{/sc}"
    GRC "{sc=2}Sole... cito...{/sc}"

# game/chapters/3_day.rpy:1742
translate Spanish call2_day3_b36274b8:

    # GRC "{sc=2}Can.... hear... me...?{/sc}"
    GRC "{sc=2}¿Pue...des... oír...me...?{/sc}"

# game/chapters/3_day.rpy:1756
translate Spanish call2_day3_47730d3f:

    # GRC "...I'm across."
    GRC "...Ya crucé."

# game/chapters/3_day.rpy:1760
translate Spanish call2_day3_52a3c839:

    # GRC "Open your eyes, mortal."
    GRC "Abre los ojos, mortal."

# game/chapters/3_day.rpy:1778
translate Spanish call2_day3_e719c40d:

    # GRC "How do you feel?"
    GRC "¿Cómo te sientes?"

# game/chapters/3_day.rpy:1782
translate Spanish call2_day3_c631c25b:

    # GRC "That is normal."
    GRC "Eso es normal."

# game/chapters/3_day.rpy:1784
translate Spanish call2_day3_2e7bc074:

    # GRC "Well... you have a little more 'soul' than usual in you, right now."
    GRC "Bueno... ahora tienes un poco más de 'alma' de lo usual en ti."

# game/chapters/3_day.rpy:1786
translate Spanish call2_day3_100fe4d5:

    # GRC "Well, that's good to hear."
    GRC "Bueno, me alegra oír eso."

# game/chapters/3_day.rpy:1788
translate Spanish call2_day3_63772fbd:

    # GRC "Now, let's take a look at that aura of yours up close..."
    GRC "Ahora, echemos un vistazo de cerca a esa aura..."

# game/chapters/3_day.rpy:1790
translate Spanish call2_day3_8c2662a7:

    # GRC "Ah..."
    GRC "Ah..."

# game/chapters/3_day.rpy:1795
translate Spanish call2_day3_f73da733:

    # GRC "How did you...? How could that..."
    GRC "¿Cómo hiciste...? ¿Cómo es posible que eso...?"

# game/chapters/3_day.rpy:1804
translate Spanish call2_day3_32f44438_1:

    # GRC "Yes."
    GRC "Sí."

# game/chapters/3_day.rpy:1805
translate Spanish call2_day3_73e350bc:

    # GRC "I should have mentioned that this connection has... benefits and drawbacks."
    GRC "Debí haber mencionado que esta conexión tiene... beneficios y desventajas."

# game/chapters/3_day.rpy:1806
translate Spanish call2_day3_08bce0c7:

    # GRC "It is not permanent."
    GRC "No es permanente."

# game/chapters/3_day.rpy:1809
translate Spanish call2_day3_382ffa8a:

    # GRC "There are worse voices to hear in your head, I'm sure."
    GRC "Hay peores voces que escuchar en tu cabeza, estoy seguro."

# game/chapters/3_day.rpy:1810
translate Spanish call2_day3_97584ee2:

    # GRC "Like your own."
    GRC "Como la tuya propia."

# game/chapters/3_day.rpy:1811
translate Spanish call2_day3_8723a57d:

    # GRC "You should be thankful that you are graced with mine."
    GRC "Deberías agradecer que estés bendecid[letra] con la mía."

# game/chapters/3_day.rpy:1821
translate Spanish call2_day3_997a6b3e:

    # GRC "Hah!"
    GRC "¡Ja!"

# game/chapters/3_day.rpy:1822
translate Spanish call2_day3_9af3419e:

    # GRC "If anything, you should be thanking me."
    GRC "Si acaso, deberías estarme agradeciendo a mí."

# game/chapters/3_day.rpy:1823
translate Spanish call2_day3_c66b93cf:

    # GRC "You get to experience my voice in a way no one else has before."
    GRC "Puedes experimentar mi voz de una forma que nadie más lo ha hecho antes."

# game/chapters/3_day.rpy:1828
translate Spanish call2_day3_c6747a89:

    # GRC "My talents are amazing, yes. Thank you for noticing."
    GRC "Mis talentos son increíbles, sí. Gracias por notarlo."

# game/chapters/3_day.rpy:1834
translate Spanish call2_day3_de02d5b2:

    # GRC "Yes. Thanks to my talents."
    GRC "Sí. Gracias a mis talentos."

# game/chapters/3_day.rpy:1838
translate Spanish call2_day3_af1c3070:

    # GRC "I am very talented, after all. Talented and amazing and all of that."
    GRC "Soy muy talentoso, después de todo. Talentoso e increíble y todo eso."

# game/chapters/3_day.rpy:1844
translate Spanish call2_day3_008afe10_5:

    # GRC "..."
    GRC "..."

# game/chapters/3_day.rpy:1846
translate Spanish call2_day3_ed38f64c:

    # GRC "And those situations would be...?"
    GRC "¿Y esas situaciones serían...?"

# game/chapters/3_day.rpy:1850
translate Spanish call2_day3_82c987e0:

    # GRC "Uh huh. And could I trust you had the correct answers?"
    GRC "Ajá. ¿Y podría confiar en que tú tendrías las respuestas correctas?"

# game/chapters/3_day.rpy:1854
translate Spanish call2_day3_efedd22d:

    # GRC "Well, I appreciate the confidence, at the very least."
    GRC "Bueno, al menos aprecio la confianza."

# game/chapters/3_day.rpy:1857
translate Spanish call2_day3_a7fab301:

    # GRC "Somehow unsurprising."
    GRC "De algún modo, nada sorprendente."

# game/chapters/3_day.rpy:1860
translate Spanish call2_day3_6b622caf:

    # GRC "Either way, I have never been to one of these 'schools'. I doubt I could tell you any correct answers."
    GRC "De cualquier modo, nunca he estado en una de esas 'escuelas'. Dudo que pudiera darte respuestas correctas."

# game/chapters/3_day.rpy:1865
translate Spanish call2_day3_d715e253:

    # GRC "There... is no reaper school. There is training, but nothing like what you would imagine."
    GRC "No... no hay escuela para parcas. Hay entrenamiento, pero nada como lo que imaginas."

# game/chapters/3_day.rpy:1870
translate Spanish call2_day3_4b1395b2:

    # GRC "Kids?"
    GRC "¿Niños?"

# game/chapters/3_day.rpy:1871
translate Spanish call2_day3_332f53ea:

    # GRC "There are no children here."
    GRC "No hay niños aquí."

# game/chapters/3_day.rpy:1878
translate Spanish call2_day3_06ec0e1d:

    # GRC "Yes, maybe so."
    GRC "Sí, quizá sea así."

# game/chapters/3_day.rpy:1880
translate Spanish call2_day3_2d07fb99:

    # GRC "Don't you want to know about your aura?"
    GRC "¿No quieres saber sobre tu aura?"

# game/chapters/3_day.rpy:1884
translate Spanish call2_day3_64943e24:

    # GRC "Oh, goody."
    GRC "Oh, genial."

# game/chapters/3_day.rpy:1885
translate Spanish call2_day3_868f264f:

    # GRC "I can't think of anything I'd enjoy more!"
    GRC "¡No se me ocurre nada que me guste más!"

# game/chapters/3_day.rpy:1889
translate Spanish call2_day3_c58447d5:

    # GRC "Why would I?"
    GRC "¿Por qué habría de hacerlo?"

# game/chapters/3_day.rpy:1893
translate Spanish call2_day3_8f4d323f:

    # GRC "I talk to you plenty already."
    GRC "Ya hablo contigo bastante."

# game/chapters/3_day.rpy:1901
translate Spanish call2_day3_62cbf972:

    # GRC "What's a bedtime talk?"
    GRC "¿Qué es una charla antes de dormir?"

# game/chapters/3_day.rpy:1902
translate Spanish call2_day3_45743d11:

    # GRC "It sounds pointless."
    GRC "Suena inútil."

# game/chapters/3_day.rpy:1910
translate Spanish call2_day3_d9e4c369:

    # GRC "Throw one of these questions at me, then."
    GRC "Lánzame una de esas preguntas, entonces."

# game/chapters/3_day.rpy:1916
translate Spanish call2_day3_a9d73e5a:

    # GRC "Socks and sandals?"
    GRC "¿Sandalias con medias?"

# game/chapters/3_day.rpy:1917
translate Spanish call2_day3_220ae60f:

    # GRC "Why does that matter?"
    GRC "¿Por qué importa eso?"

# game/chapters/3_day.rpy:1921
translate Spanish call2_day3_83675cc2:

    # GRC "Hmm."
    GRC "Hmm."

# game/chapters/3_day.rpy:1922
translate Spanish call2_day3_b6b8703e:

    # GRC "My instincts drive me to say 'why would you wear socks and sandals?'"
    GRC "Mis instintos me llevan a decir '¿por qué usarías sandalias con medias?'"

# game/chapters/3_day.rpy:1923
translate Spanish call2_day3_185436b4:

    # GRC "However..."
    GRC "Sin embargo..."

# game/chapters/3_day.rpy:1924
translate Spanish call2_day3_7f7839d8:

    # GRC "I believe with the right outfit, perhaps it could be... ahem... alright... on you."
    GRC "Creo que con el atuendo adecuado, quizás podría ser... ejem... aceptable... en ti."

# game/chapters/3_day.rpy:1933
translate Spanish call2_day3_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/3_day.rpy:1934
translate Spanish call2_day3_0fe699e1:

    # GRC "Misspoke."
    GRC "Me equivoqué al hablar."

# game/chapters/3_day.rpy:1936
translate Spanish call2_day3_9643fc40:

    # GRC "It would likely look horrendous and absolutely horrible on you."
    GRC "Probablemente se vería horrible y absolutamente espantoso en ti."

# game/chapters/3_day.rpy:1943
translate Spanish call2_day3_008afe10_6:

    # GRC "..."
    GRC "..."

# game/chapters/3_day.rpy:1945
translate Spanish call2_day3_3e47e60e:

    # GRC "Forget I said anything."
    GRC "Olvida que dije algo."

# game/chapters/3_day.rpy:1946
translate Spanish call2_day3_2e8e693c:

    # GRC "How about we just talk about your soul already..."
    GRC "¿Qué tal si hablamos de tu alma de una vez...?"

# game/chapters/3_day.rpy:1950
translate Spanish call2_day3_fa5c77f7:

    # GRC "Your mind is in the gutter once again!"
    GRC "¡Otra vez con esa mente sucia!"

# game/chapters/3_day.rpy:1952
translate Spanish call2_day3_c3132977:

    # GRC "Mortals can be truly filthy." id call2_day3_c3132977
    GRC "Los mortales pueden ser realmente sucios." id call2_day3_c3132977

# game/chapters/3_day.rpy:1953
translate Spanish call2_day3_fe6e2e82:

    # GRC "Yes, I imagine for certain acts it would be quite... enjoyable for both parties."
    GRC "Sí, imagino que para ciertos actos podría ser bastante... placentero para ambas partes."

# game/chapters/3_day.rpy:1957
translate Spanish call2_day3_31d1bd8b:

    # GRC "I have not."
    GRC "No, nunca."

# game/chapters/3_day.rpy:1962
translate Spanish call2_day3_65122790_1:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/3_day.rpy:1963
translate Spanish call2_day3_285b1772:

    # GRC "Uh... ahem..."
    GRC "Uh... ejem..."

# game/chapters/3_day.rpy:1965
translate Spanish call2_day3_b12d2689:

    # GRC "Like..."
    GRC "Como..."

# game/chapters/3_day.rpy:1972
translate Spanish call2_day3_8da23161:

    # GRC "...."
    GRC "...."

# game/chapters/3_day.rpy:1975
translate Spanish call2_day3_65122790_2:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/3_day.rpy:1977
translate Spanish call2_day3_7ae5344f:

    # GRC "How can you be so forward..."
    GRC "¿Cómo puedes ser tan direct[letra]...?"

# game/chapters/3_day.rpy:1991
translate Spanish call2_day3_64a1d184:

    # GRC "You and your dirty mind."
    GRC "Tú y tu mente sucia."

# game/chapters/3_day.rpy:1999
translate Spanish call2_day3_526406ad:

    # GRC "I can see it, yes."
    GRC "Puedo verla, sí."

# game/chapters/3_day.rpy:2000
translate Spanish call2_day3_34b81205:

    # GRC "Mind you, I could see it before, too."
    GRC "Ten en cuenta que ya podía verla antes, también."

# game/chapters/3_day.rpy:2001
translate Spanish call2_day3_cc47a23e:

    # GRC "Now I can... feel it, I suppose."
    GRC "Ahora puedo... sentirla, supongo."

# game/chapters/3_day.rpy:2003
translate Spanish call2_day3_d0e87b3b:

    # GRC "It feels.... hmmm. Sparse?"
    GRC "Se siente... hmmm. ¿Escasa?"

# game/chapters/3_day.rpy:2006
translate Spanish call2_day3_15a43d79:

    # GRC "Hmmm."
    GRC "Mmmm."

# game/chapters/3_day.rpy:2007
translate Spanish call2_day3_aa6ca8db:

    # GRC "I... am unsure, at the moment."
    GRC "Yo... no estoy seguro, por el momento."

# game/chapters/3_day.rpy:2010
translate Spanish call2_day3_4d3947ec:

    # GRC "It's... I don't know what it means."
    GRC "Es... no sé qué significa."

# game/chapters/3_day.rpy:2012
translate Spanish call2_day3_e8ce6f40:

    # GRC "I said your aura was sparse, not you."
    GRC "Dije que tu aura era escasa, no tú."

# game/chapters/3_day.rpy:2013
translate Spanish call2_day3_fcbad5e8:

    # GRC "And pretty? Come on. I'm sure you could think of a better descriptive word for me."
    GRC "¿Y bonito? Vamos. Estoy seguro de que podrías pensar en una palabra mejor para describirme."

# game/chapters/3_day.rpy:2014
translate Spanish call2_day3_3593cd17:

    # GRC "Anyway."
    GRC "En fin."

# game/chapters/3_day.rpy:2015
translate Spanish call2_day3_a9c0ab34:

    # GRC "It's not necessarily bad, but it's... unusual."
    GRC "No es necesariamente malo, pero es... inusual."

# game/chapters/3_day.rpy:2016
translate Spanish call2_day3_071fc1b5:

    # GRC "I can't say I know what it means."
    GRC "No puedo decir que sepa qué significa."

# game/chapters/3_day.rpy:2023
translate Spanish call2_day3_95158d63:

    # GRC "Wha—ugly?!"
    GRC "¡¿Qu—fea?!"

# game/chapters/3_day.rpy:2024
translate Spanish call2_day3_cc5ca1ad:

    # GRC "I'm far from ugly!"
    GRC "¡Estoy muy lejos de ser feo!"

# game/chapters/3_day.rpy:2027
translate Spanish call2_day3_2518aef2:

    # GRC "What is that?"
    GRC "¿Qué es eso?"

# game/chapters/3_day.rpy:2033
translate Spanish call2_day3_e855d36a:

    # GRC "Wha-"
    GRC "¿Qu—"

# game/chapters/3_day.rpy:2034
translate Spanish call2_day3_25e1be5b:

    # GRC "I can ensure you my face is bordering on heavenly. There is no 'bitch face'."
    GRC "Puedo asegurarte que mi rostro roza lo celestial. No es una 'cara de pocos amigos'."

# game/chapters/3_day.rpy:2038
translate Spanish call2_day3_a24a639d:

    # GRC "What do you mean?"
    GRC "¿Qué quieres decir?"

# game/chapters/3_day.rpy:2045
translate Spanish call2_day3_4aa86442:

    # GRC "What the..."
    GRC "¿Qué demonios...?"

# game/chapters/3_day.rpy:2046
translate Spanish call2_day3_48f674b6:

    # GRC "My pipes are {i}just fine{/i}, thank you!"
    GRC "¡Mis tuberías están {i}perfectamente bien{/i}, gracias!"

# game/chapters/3_day.rpy:2054
translate Spanish call2_day3_b52a9e47:

    # GRC "It's... bright. {i}You're{/i} bright."
    GRC "Es... brillante. {i}Tú{/i} eres brillante."

# game/chapters/3_day.rpy:2056
translate Spanish call2_day3_0bfaafbf:

    # GRC "I've told you this already. Pay more attention."
    GRC "Ya te lo he dicho antes. Presta más atención."

# game/chapters/3_day.rpy:2070
translate Spanish call2_day3_6eed491a:

    # GRC "What? No."
    GRC "¿Qué? No."

# game/chapters/3_day.rpy:2072
translate Spanish call2_day3_8fcb6105:

    # GRC "It just..."
    GRC "Es solo que..."

# game/chapters/3_day.rpy:2081
translate Spanish call2_day3_396dd9e6:

    # GRC "It hurts my eyes to look too closely, that's all."
    GRC "Me duele la vista al mirarte demasiado de cerca, eso es todo."

# game/chapters/3_day.rpy:2090
translate Spanish call2_day3_1a2fd01c:

    # GRC "Fantastic advice, except I must look closely if I am to work out what exactly is wrong with you."
    GRC "Consejo fantástico, excepto que debo mirar de cerca si quiero averiguar qué está mal contigo exactamente."

# game/chapters/3_day.rpy:2095
translate Spanish call2_day3_6b7e1bfa:

    # GRC "I'll deal with it."
    GRC "Lo soportaré."

# game/chapters/3_day.rpy:2100
translate Spanish call2_day3_91fc049e:

    # GRC "No. I need to look to understand what's going on with you, so I will."
    GRC "No. Necesito mirar para entender qué te pasa, así que lo haré."

# game/chapters/3_day.rpy:2106
translate Spanish call2_day3_37147c06:

    # GRC "It's no big deal. A minor annoyance, at most."
    GRC "No es gran cosa. Una molestia menor, como mucho."

# game/chapters/3_day.rpy:2107
translate Spanish call2_day3_6b7e1bfa_1:

    # GRC "I'll deal with it."
    GRC "Lo soportaré."

# game/chapters/3_day.rpy:2121
translate Spanish call2_day3_f5c4dc63:

    # GRC "Sometimes. Souls can shine or glow, like yours. It's rare, but not unheard of."
    GRC "A veces. Las almas pueden brillar o resplandecer, como la tuya. Es raro, pero no es desconocido."

# game/chapters/3_day.rpy:2123
translate Spanish call2_day3_04656156:

    # GRC "But, hmm... yours doesn't look the same, nor feel the same, as anyone else's." id call2_day3_04656156
    GRC "Pero, hmm... la tuya no se ve igual, ni se siente igual, que la de nadie más." id call2_day3_04656156

# game/chapters/3_day.rpy:2133
translate Spanish call2_day3_7d344154:

    # GRC "It has no scent."
    GRC "No tiene olor."

# game/chapters/3_day.rpy:2138
translate Spanish call2_day3_37865b03:

    # GRC "Uh... yeah, we can both be thankful that was not the case."
    GRC "Eh... sí, ambos podemos estar agradecidos de que no fuera el caso."

# game/chapters/3_day.rpy:2141
translate Spanish call2_day3_16ed2e1c:

    # GRC "What the lack of smell tells us is that you are indeed not cursed."
    GRC "Lo que la falta de olor nos dice es que, de hecho, no estás maldit[letra]."

# game/chapters/3_day.rpy:2151
translate Spanish call2_day3_f7eec323:

    # GRC "Which is good, but it still doesn't explain anything."
    GRC "Lo cual es bueno, pero aún no explica nada."

# game/chapters/3_day.rpy:2153
translate Spanish call2_day3_c206c729:

    # GRC "Close your eyes again. It helps me to concentrate."
    GRC "Cierra los ojos otra vez. Me ayuda a concentrarme."

# game/chapters/3_day.rpy:2161
translate Spanish call2_day3_f034338d:

    # GRC "Hmm..."
    GRC "Hmm..."

# game/chapters/3_day.rpy:2162
translate Spanish call2_day3_4aa86442_1:

    # GRC "What the..."
    GRC "¿Qué demonios...?"

# game/chapters/3_day.rpy:2167
translate Spanish call2_day3_9467829c_1:

    # GRC "....."
    GRC "....."

# game/chapters/3_day.rpy:2175
translate Spanish call2_day3_482808a3:

    # GRC "Open."
    GRC "Ábrelos."

# game/chapters/3_day.rpy:2199
translate Spanish call2_day3_0f573407:

    # GRC "In all of my years, I've never seen anything like this before."
    GRC "En todos mis años, nunca había visto algo así antes."

# game/chapters/3_day.rpy:2207
translate Spanish call2_day3_1b64a1b0:

    # GRC "It's... you?"
    GRC "¿Eres... tú?"

# game/chapters/3_day.rpy:2212
translate Spanish call2_day3_09dad8ac:

    # GRC "Close your eyes again."
    GRC "Cierra los ojos otra vez."

# game/chapters/3_day.rpy:2219
translate Spanish call2_day3_b3e71eff:

    # GRC "Just do as you're told." id call2_day3_b3e71eff
    GRC "Solo haz lo que se te dice." id call2_day3_b3e71eff

# game/chapters/3_day.rpy:2222
translate Spanish call2_day3_4972f08c:

    # GRC "You don't mind."
    GRC "No te molesta."

# game/chapters/3_day.rpy:2230
translate Spanish call2_day3_90e725a6:

    # GRC "Please."
    GRC "Por favor."

# game/chapters/3_day.rpy:2235
translate Spanish call2_day3_9467829c_2:

    # GRC "....."
    GRC "....."

# game/chapters/3_day.rpy:2241
translate Spanish call2_day3_15c85e52:

    # GRC "I am the best of the best."
    GRC "Soy el mejor de los mejores."

# game/chapters/3_day.rpy:2251
translate Spanish call2_day3_bf40d4fd:

    # GRC "It is an undisputable fact. "
    GRC "Es un hecho indiscutible."

# game/chapters/3_day.rpy:2252
translate Spanish call2_day3_9968281f:

    # GRC "Yet... I can't make any sense of this."
    GRC "Y aun así... no puedo entender esto."

# game/chapters/3_day.rpy:2258
translate Spanish call2_day3_8882d87a:

    # GRC "Nonsense. That is not an option."
    GRC "Disparates. Esa no es una opción."

# game/chapters/3_day.rpy:2259
translate Spanish call2_day3_f84d2824:

    # GRC "If anything, this is a problem with you, not me."
    GRC "Si acaso, este es un problema contigo, no conmigo."

# game/chapters/3_day.rpy:2265
translate Spanish call2_day3_2615699f:

    # GRC "Your... aura, it..."
    GRC "Tu... aura, ella... eh..."

# game/chapters/3_day.rpy:2266
translate Spanish call2_day3_decab51e:

    # GRC "It pulses and ebbs."
    GRC "Pulsa y mengua."

# game/chapters/3_day.rpy:2270
translate Spanish call2_day3_fb0a9d50:

    # GRC "When you close your eyes, yes. It pulses."
    GRC "Cuando cierras los ojos, sí. Pulsa."

# game/chapters/3_day.rpy:2271
translate Spanish call2_day3_0f62f842:

    # GRC "Open them again for me."
    GRC "Ábrelos otra vez para mí."

# game/chapters/3_day.rpy:2281
translate Spanish call2_day3_481d8ac0:

    # GRC "Now it ripples."
    GRC "Ahora ondula."

# game/chapters/3_day.rpy:2283
translate Spanish call2_day3_785c8a66:

    # GRC "The colors flow like oil on water."
    GRC "Los colores fluyen como aceite sobre el agua."

# game/chapters/3_day.rpy:2292
translate Spanish call2_day3_99235e30:

    # GRC "Is there something you need protection from?"
    GRC "¿Hay algo de lo que necesites protección?"

# game/chapters/3_day.rpy:2303
translate Spanish call2_day3_9947dfb8:

    # GRC "I won't harm you."
    GRC "No te haré daño."

# game/chapters/3_day.rpy:2304
translate Spanish call2_day3_85338ed7:

    # GRC "I've told you such."
    GRC "Ya te lo he dicho."

# game/chapters/3_day.rpy:2312
translate Spanish call2_day3_07283614:

    # GRC "Correct."
    GRC "Correcto."

# game/chapters/3_day.rpy:2314
translate Spanish call2_day3_a9a8f5d5:

    # GRC "But not today. I am still... not at my full strength."
    GRC "Pero no hoy. Aún no estoy... al máximo de mis fuerzas."

# game/chapters/3_day.rpy:2319
translate Spanish call2_day3_7d2e0b47:

    # GRC "That is... fair."
    GRC "Eso es... justo."

# game/chapters/3_day.rpy:2324
translate Spanish call2_day3_bf39f8da:

    # GRC "You can't rush perfection."
    GRC "No puedes apresurar la perfección."

# game/chapters/3_day.rpy:2329
translate Spanish call2_day3_a893cf64:

    # GRC "...I will look into it more later."
    GRC "...Lo investigaré más tarde."

# game/chapters/3_day.rpy:2331
translate Spanish call2_day3_636c5bcf:

    # GRC "There must be something mentioned in a tome somewhere..."
    GRC "Debe haber algo mencionado en algún tomo en algún lugar..."

# game/chapters/3_day.rpy:2333
translate Spanish call2_day3_30917f45:

    # GRC "Pulsating auras... and then there's your... other issue."
    GRC "Auras pulsantes... y luego está tu... otro asunto."

# game/chapters/3_day.rpy:2338
translate Spanish call2_day3_846b9f2e:

    # GRC "Until I understand what's going on, it's best you don't ask questions."
    GRC "Hasta que entienda lo que está pasando, es mejor que no hagas preguntas."

# game/chapters/3_day.rpy:2340
translate Spanish call2_day3_c5bb4b74:

    # GRC "I know, I know, that will be difficult for you."
    GRC "Lo sé, lo sé, eso será difícil para ti."

# game/chapters/3_day.rpy:2341
translate Spanish call2_day3_c098a47d:

    # GRC "Out of all the mortals in existence, you must be the one who asks the most questions."
    GRC "De todos los mortales que existen, debes ser quien más preguntas hace."

# game/chapters/3_day.rpy:2346
translate Spanish call2_day3_93ce4e3f:

    # GRC "Would you look at that, another question."
    GRC "Mira nada más, otra pregunta."

# game/chapters/3_day.rpy:2351
translate Spanish call2_day3_5f838062:

    # GRC "Haa..."
    GRC "Haa..."

# game/chapters/3_day.rpy:2352
translate Spanish call2_day3_2040ee1c:

    # GRC "Knowledge is dangerous."
    GRC "El conocimiento es peligroso."

# game/chapters/3_day.rpy:2354
translate Spanish call2_day3_eef46d10:

    # GRC "Especially if it is wrong."
    GRC "Especialmente si es erróneo."

# game/chapters/3_day.rpy:2359
translate Spanish call2_day3_a9bd588f:

    # GRC "Perhaps. Maybe if you behave... or beg."
    GRC "Quizás. Tal vez si te comportas... o suplicas."

# game/chapters/3_day.rpy:2362
translate Spanish call2_day3_95bb8be6:

    # GRC "Then perhaps I'd rather not tell you."
    GRC "Entonces quizá prefiera no decírtelo."

# game/chapters/3_day.rpy:2366
translate Spanish call2_day3_fc74f80e:

    # GRC "The only—"
    GRC "Lo único—"

# game/chapters/3_day.rpy:2371
translate Spanish call2_day3_6ed45582:

    # GRC "Okay. Very funny."
    GRC "Okey. Muy gracioso."

# game/chapters/3_day.rpy:2374
translate Spanish call2_day3_f6770f47:

    # GRC "I mean, you don't {i}have{/i} to do anything."
    GRC "Quiero decir, no {i}tienes{/i} que hacer nada."

# game/chapters/3_day.rpy:2375
translate Spanish call2_day3_1370ed02:

    # GRC "But if you want to know..."
    GRC "Pero si quieres saber..."

# game/chapters/3_day.rpy:2380
translate Spanish call2_day3_008afe10_7:

    # GRC "..."
    GRC "..."

# game/chapters/3_day.rpy:2384
translate Spanish call2_day3_4aa86442_2:

    # GRC "What the..."
    GRC "Qué demo..."

# game/chapters/3_day.rpy:2386
translate Spanish call2_day3_67f9c849:

    # GRC "Why are you talking like that?"
    GRC "¿Por qué estás hablando así?"

# game/chapters/3_day.rpy:2391
translate Spanish call2_day3_5445bb2b:

    # GRC "The... that voice!"
    GRC "¡Esa... esa voz!"

# game/chapters/3_day.rpy:2396
translate Spanish call2_day3_6d832692:

    # GRC "Stop it. "
    GRC "Detente."

# game/chapters/3_day.rpy:2403
translate Spanish call2_day3_008afe10_8:

    # GRC "..."
    GRC "..."

# game/chapters/3_day.rpy:2405
translate Spanish call2_day3_64125625:

    # GRC "I am going to ignore your existence entirely now."
    GRC "Voy a ignorar por completo tu existencia ahora."

# game/chapters/3_day.rpy:2411
translate Spanish call2_day3_f0367c09:

    # GRC "I think it's time for me to go. Time is ticking."
    GRC "Creo que es hora de irme. El tiempo corre."

# game/chapters/3_day.rpy:2416
translate Spanish call2_day3_0355bc36:

    # GRC "I need rest, and I need answers. The answers will be coming first."
    GRC "Necesito descansar, y necesito respuestas. Las respuestas vendrán primero."

# game/chapters/3_day.rpy:2421
translate Spanish call2_day3_008afe10_9:

    # GRC "..."
    GRC "..."

# game/chapters/3_day.rpy:2428
translate Spanish call2_day3_79a350ac:

    # GRC "My wellbeing comes second to my responsibility."
    GRC "Mi bienestar viene en segundo lugar frente a mi responsabilidad."

# game/chapters/3_day.rpy:2433
translate Spanish call2_day3_a8288d66:

    # GRC "That is correct."
    GRC "Eso es correcto."

# game/chapters/3_day.rpy:2447
translate Spanish call2_day3_e015fab8:

    # GRC "I can be plenty threatening when I want to be."
    GRC "Puedo ser bastante amenazante cuando quiero."

# game/chapters/3_day.rpy:2449
translate Spanish call2_day3_28c4dee1:

    # GRC "You just haven't seen that side of me yet."
    GRC "Simplemente no has visto ese lado de mí aún."

# game/chapters/3_day.rpy:2453
translate Spanish call2_day3_9dc6ee2f:

    # GRC "Not today."
    GRC "No hoy."

# game/chapters/3_day.rpy:2458
translate Spanish call2_day3_e7a44ca4:

    # GRC "Mortal, I do not lie."
    GRC "Mortal, no miento."

# game/chapters/3_day.rpy:2468
translate Spanish call2_day3_008afe10_10:

    # GRC "..."
    GRC "..."

# game/chapters/3_day.rpy:2469
translate Spanish call2_day3_55b7abe0:

    # GRC "I'm hanging up now."
    GRC "Voy a colgar ahora."

# game/chapters/3_day.rpy:2471
translate Spanish call2_day3_ddc4e3c5:

    # GRC "Try not to miss gazing into my eyes too much."
    GRC "Intenta no extrañar demasiado mirarme a los ojos."

# game/chapters/3_day.rpy:2476
translate Spanish call2_day3_dac3093a:

    # GRC "Indeed. But you stared long after you needed to. You're always staring at me, aren't you?"
    GRC "En efecto. Pero te quedaste mirándome mucho después de lo necesario. Siempre me estás observando, ¿no es así?"

# game/chapters/3_day.rpy:2484
translate Spanish call2_day3_6efbd0a7:

    # GRC "Your eyes bore into me like flames."
    GRC "Tus ojos se clavan en mí como llamas."

# game/chapters/3_day.rpy:2485
translate Spanish call2_day3_676c03ed:

    # GRC "Do you like my face that much?"
    GRC "¿Te gusta tanto mi rostro?"

# game/chapters/3_day.rpy:2486
translate Spanish call2_day3_40f0ee55:

    # GRC "It would be understandable. My face is quite perfect."
    GRC "Sería comprensible. Mi rostro es bastante perfecto."

# game/chapters/3_day.rpy:2488
translate Spanish call2_day3_606d4adc:

    # GRC "You don't even need to answer. How could you not?"
    GRC "Ni siquiera necesitas responder. ¿Cómo no podría gustarte?"

# game/chapters/3_day.rpy:2493
translate Spanish call2_day3_3fad2680:

    # GRC "My skin is flawless. I am without flaw."
    GRC "Mi piel es impecable. Estoy sin defecto."

# game/chapters/3_day.rpy:2498
translate Spanish call2_day3_bcf28c7e:

    # GRC "I am not everyone."
    GRC "Yo no soy todo el mundo."

# game/chapters/3_day.rpy:2503
translate Spanish call2_day3_b40dd5d3:

    # GRC "Still making fun of my title, huh?"
    GRC "¿Sigues burlándote de mi título, eh?"

# game/chapters/3_day.rpy:2517
translate Spanish call2_day3_a0104e16:

    # GRC "Heh. I've got you wrapped around my finger, little mortal."
    GRC "Je. Te tengo envuelt[letra] alrededor de mi dedo, mortalcit[letra]."

# game/chapters/3_day.rpy:2521
translate Spanish call2_day3_58c6deb0:

    # GRC "I would say that you are making a mistake, obviously."
    GRC "Diría que estás cometiendo un error, obviamente."

# game/chapters/3_day.rpy:2523
translate Spanish call2_day3_b4210d61:

    # GRC "The only place I will lead you to is your doom. Remember that."
    GRC "El único lugar al que te llevaré es a tu perdición. Recuérdalo."

# game/chapters/3_day.rpy:2530
translate Spanish call2_day3_852f028e:

    # GRC "...You should watch what you say. It could be misunderstood."
    GRC "...Deberías cuidar lo que dices. Podría malinterpretarse."

# game/chapters/3_day.rpy:2532
translate Spanish call2_day3_06680bc6:

    # GRC "Either way, you could not handle being 'wrapped' around me for long."
    GRC "De cualquier manera, no podrías soportar estar 'envuelt[letra]' a mi alrededor por mucho tiempo."

# game/chapters/3_day.rpy:2536
translate Spanish call2_day3_618a05b4:

    # GRC "In your dreams, Sunshine."
    GRC "En tus sueños, Solecito."

# game/chapters/3_day.rpy:2539
translate Spanish call2_day3_d80e0b84:

    # GRC "And how did you come to that conclusion?"
    GRC "¿Y cómo llegaste a esa conclusión?"

# game/chapters/3_day.rpy:2543
translate Spanish call2_day3_8da23161_1:

    # GRC "...."
    GRC "...."

# game/chapters/3_day.rpy:2545
translate Spanish call2_day3_e129e436:

    # GRC "So you wish to collar me. Understandable. I would look fantastic in a collar."
    GRC "Así que deseas ponerme un collar. Comprensible. Me vería fantástico con un collar."

# game/chapters/3_day.rpy:2559
translate Spanish call2_day3_008afe10_11:

    # GRC "..."
    GRC "..."

# game/chapters/3_day.rpy:2567
translate Spanish call2_day3_934fc6d7:

    # GRC "It does not."
    GRC "No me da vergüenza."

# game/chapters/3_day.rpy:2572
translate Spanish call2_day3_7d516a1c:

    # GRC "I'm too tired to deal with this..."
    GRC "Estoy demasiado cansado para lidiar con esto..."

# game/chapters/3_day.rpy:2575
translate Spanish call2_day3_5d36a02e:

    # GRC "I'm leaving now. Try not to get up to too much trouble while I'm gone."
    GRC "Me voy ahora. Intenta no meterte en demasiados problemas mientras estoy fuera."

# game/chapters/3_day.rpy:2580
translate Spanish call2_day3_43acf054:

    # GRC "You could at least {i}try{/i} to sound a little scared..."
    GRC "Al menos podrías {i}intentar{/i} sonar un poco asustad[letra]..."

# game/chapters/3_day.rpy:2599
translate Spanish chat3_day3_a8521ebb:

    # player "By the way..."
    player "Por cierto..."

# game/chapters/3_day.rpy:2602
translate Spanish chat3_day3_ad8809d6:

    # player "I am assuming I can't tell people about you?"
    player "Supongo que no puedo contarle a la gente sobre ti, ¿verdad?"

# game/chapters/3_day.rpy:2603
translate Spanish chat3_day3_6f74a0bb:

    # GR "absolutely not."
    GR "absolutamente no."

# game/chapters/3_day.rpy:2604
translate Spanish chat3_day3_6e707a93:

    # GR "if i find out you have told others of this..."
    GR "si me entero de que les has contado esto a otros..."

# game/chapters/3_day.rpy:2605
translate Spanish chat3_day3_bc8a0ea7:

    # GR "there {i}will{/i} be hell to pay!"
    GR "¡lo pagarás {i}muy caro{/i}!"

# game/chapters/3_day.rpy:2608
translate Spanish chat3_day3_4c871446:

    # player "Like anyone at all?"
    player "¿A nadie en absoluto?"

# game/chapters/3_day.rpy:2609
translate Spanish chat3_day3_fa60aec6:

    # GR "do you really have a death wish?"
    GR "¿de verdad quieres morir?"

# game/chapters/3_day.rpy:2612
translate Spanish chat3_day3_d6b0644e:

    # player "Of course not."
    player "Por supuesto que no."

# game/chapters/3_day.rpy:2613
translate Spanish chat3_day3_c2b5ae26:

    # GR "then do not do it."
    GR "entonces no lo hagas."

# game/chapters/3_day.rpy:2616
translate Spanish chat3_day3_30a77a14:

    # player "And if I said yes?"
    player "¿Y si dijera que sí?"

# game/chapters/3_day.rpy:2617
translate Spanish chat3_day3_fef0bd97:

    # GR "uh... then I might be somewhat worried about you."
    GR "eh... entonces podría estar algo preocupado por ti."

# game/chapters/3_day.rpy:2620
translate Spanish chat3_day3_7615cde1:

    # player "It shouldn't matter to you, right?"
    player "No debería importarte, ¿verdad?"

# game/chapters/3_day.rpy:2623
translate Spanish chat3_day3_7cbc28e6:

    # player "You're after my soul."
    player "Estás tras mi alma."

# game/chapters/3_day.rpy:2624
translate Spanish chat3_day3_1e0e786f:

    # GR "...we can talk about it later."
    GR "...podemos hablarlo más tarde."

# game/chapters/3_day.rpy:2627
translate Spanish chat3_day3_1cc32279:

    # player "Maybe I just like pushing your buttons?"
    player "¿Quizás solo me gusta provocarte?"

# game/chapters/3_day.rpy:2628
translate Spanish chat3_day3_5810b31d:

    # GR "You are truly infuriating."
    GR "eres verdaderamente exasperante."

# game/chapters/3_day.rpy:2631
translate Spanish chat3_day3_943f3f4c:

    # player "Thank you :D"
    player "Gracias :D"

# game/chapters/3_day.rpy:2635
translate Spanish chat3_day3_8bd048bd:

    # player "btw I can't believe you changed your pfp to that."
    player "Por cierto, no puedo creer que hayas cambiado tu foto de perfil a eso."

# game/chapters/3_day.rpy:2639
translate Spanish chat3_day3_86011acd:

    # player "You and your edgy teenager-like ass."
    player "Tú y tu actitud de adolescente edgy."

# game/chapters/3_day.rpy:2641
translate Spanish chat3_day3_7f12d0b8:

    # GR "i do not see what is funny about it."
    GR "no veo qué tiene de gracioso."

# game/chapters/3_day.rpy:2642
translate Spanish chat3_day3_564ce207:

    # GR "i did not want to be contacted."
    GR "no quería ser contactado."

# game/chapters/3_day.rpy:2643
translate Spanish chat3_day3_cf1366c2:

    # GR "a solid black picture seemed to convey that."
    GR "una imagen completamente negra parecía transmitir eso."

# game/chapters/3_day.rpy:2647
translate Spanish chat3_day3_306d950b:

    # player "Hahahahah."
    player "Jajajajaja."

# game/chapters/3_day.rpy:2649
translate Spanish chat3_day3_5295d3bf:

    # player "It definitely did, lmao."
    player "Definitivamente lo transmitía, jajaja."

# game/chapters/3_day.rpy:2651
translate Spanish chat3_day3_95151b2c:

    # GR "....."
    GR "....."

# game/chapters/3_day.rpy:2652
translate Spanish chat3_day3_1a106107:

    # GR "i feel you are being sarcastic, but i will allow it this once."
    GR "siento que estás hablando con sarcasmo, pero lo permitiré esta vez."

# game/chapters/3_day.rpy:2656
translate Spanish chat3_day3_6e12e8c5:

    # GR "anyway... tomorrow, we will talk about what happened."
    GR "de todos modos... mañana hablaremos de lo que pasó."

# game/chapters/3_day.rpy:2657
translate Spanish chat3_day3_1c5c214f:

    # GR "what nearly happened, that is. you could have died."
    GR "de lo que casi pasó, mejor dicho. podrías haber muerto."

# game/chapters/3_day.rpy:2660
translate Spanish chat3_day3_49838c21:

    # player "Okay..."
    player "Okey..."

# game/chapters/3_day.rpy:2663
translate Spanish chat3_day3_f9a5deae:

    # player "Would've made life easier for you, though..."
    player "Habría hecho tu vida más fácil, sin embargo..."

# game/chapters/3_day.rpy:2665
translate Spanish chat3_day3_fcdc48eb:

    # GR "go, rest."
    GR "ve, descansa."

# game/chapters/3_day.rpy:2666
translate Spanish chat3_day3_03c627f1:

    # GR "you may not feel it, but your mind will need it after what happened."
    GR "puede que no lo sientas, pero tu mente lo necesitará después de lo que pasó."

# game/chapters/3_day.rpy:2669
translate Spanish chat3_day3_038b6058:

    # player "Nice to know you care."
    player "Qué bueno saber que te importa."

# game/chapters/3_day.rpy:2670
translate Spanish chat3_day3_31d8b41f:

    # GR "or don't, and suffer for it later."
    GR "o no, y sufre por ello después."

# game/chapters/3_day.rpy:2671
translate Spanish chat3_day3_a6f63efb:

    # GR "your choice."
    GR "tu elección."

# game/chapters/3_day.rpy:2672
translate Spanish chat3_day3_c8b6e49b:

    # GR "i don't care either way."
    GR "no me importa de ninguna manera."

# game/chapters/3_day.rpy:2675
translate Spanish chat3_day3_d44fb971:

    # player "Such heartwarming support. Thank you."
    player "Qué apoyo tan conmovedor. Gracias."

# game/chapters/3_day.rpy:2678
translate Spanish chat3_day3_290b2848:

    # player "I suppose I'll take it to heart this one time."
    player "Supongo que lo guardaré en mi corazón por esta vez."

# game/chapters/3_day.rpy:2679
translate Spanish chat3_day3_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/3_day.rpy:2680
translate Spanish chat3_day3_e319258b:

    # GR "i will take it eventually."
    GR "yo me lo llevaré, tarde o temprano."

# game/chapters/3_day.rpy:2683
translate Spanish chat3_day3_78255f04:

    # player "My heart?"
    player "¿Mi corazón?"

# game/chapters/3_day.rpy:2684
translate Spanish chat3_day3_eea2aeda:

    # GR "your heart. your soul. you, entirely."
    GR "tu corazón. tu alma. tú, completamente."

# game/chapters/3_day.rpy:2687
translate Spanish chat3_day3_f9b3cd27:

    # player "That's a bold claim!"
    player "¡Qué afirmación tan atrevida!"

# game/chapters/3_day.rpy:2688
translate Spanish chat3_day3_7528abe1:

    # GR "no other shall have you."
    GR "ningún otro te tendrá."

# game/chapters/3_day.rpy:2689
translate Spanish chat3_day3_3e84d928:

    # GR "goodnight, sunshine."
    GR "buenas noches, solecito."

translate Spanish strings:

    # game/chapters/3_day.rpy:27
    old "1. Keep walking."
    new "1. Seguir caminando."

    # game/chapters/3_day.rpy:33
    old "2. Wait where you are."
    new "2. Esperar donde estás."

    # game/chapters/3_day.rpy:47
    old "leave me alone."
    new "déjame en paz."

    # game/chapters/3_day.rpy:89
    old "2. <Steve?>"
    new "2. <¿Steve?>"

    # game/chapters/3_day.rpy:91
    old "3. <Edgy Reaper Boy?>"
    new "3. <¿Chico Parca Edgy?>"

    # game/chapters/3_day.rpy:93
    old "4. <Babygirl?> {font=gui/starthings.ttf}a{/font}"
    new "4. <¿Babygirl?> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/3_day.rpy:96
    old "1. <Hellooooo?>"
    new "1. <¿Holaaaaaa?>"

    # game/chapters/3_day.rpy:100
    old "2. <This just makes me want to send MORE messages...>"
    new "2. <Esto solo hace que quiera mandar MÁS mensajes...>"

    # game/chapters/3_day.rpy:104
    old "3. <Your app is brooooken...>"
    new "3. <Tu app está rooooota...>"

    # game/chapters/3_day.rpy:108
    old "4. <{i}Turn it off and on again.{/i}> {font=gui/starthings.ttf}a{/font}"
    new "4. <{i}Apagar el portátil y volver a encenderlo.{/i}> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/3_day.rpy:116
    old "1. <Is it fixed?>"
    new "1. <¿Ya se arregló?>"

    # game/chapters/3_day.rpy:122
    old "1. <I know it says message not sent...>"
    new "1. <Sé que dice mensaje no enviado...>"

    # game/chapters/3_day.rpy:126
    old "1. <But can you read this anyway, Grim?>"
    new "1. <Pero ¿puedes leer esto aun así, Parca?>"

    # game/chapters/3_day.rpy:130
    old "1. <You're cute.>"
    new "1. <Eres lindo.>"

    # game/chapters/3_day.rpy:133
    old "2. <You smell.>"
    new "2. <Apestas.>"

    # game/chapters/3_day.rpy:194
    old "1. <...Why is your camera off?>"
    new "1. <...¿Por qué está apagada tu cámara?>"

    # game/chapters/3_day.rpy:197
    old "1. <And what did you do to my computer?>"
    new "1. <¿Y qué le hiciste a mi computadora?>"

    # game/chapters/3_day.rpy:212
    old "2. <I see.>"
    new "2. <Ya veo.>"

    # game/chapters/3_day.rpy:219
    old "1. <Technically, I didn't.>"
    new "1. <Técnicamente, no lo hice.>"

    # game/chapters/3_day.rpy:222
    old "1. <I only messaged you.>"
    new "1. <Solo te envié mensajes.>"

    # game/chapters/3_day.rpy:225
    old "1. <And they didn't even send!>"
    new "1. <¡Y ni siquiera se enviaron!>"

    # game/chapters/3_day.rpy:228
    old "1. <Why did that happen?>"
    new "1. <¿Por qué pasó eso?>"

    # game/chapters/3_day.rpy:230
    old "2. <Is something wrong?>"
    new "2. <¿Pasa algo?>"

    # game/chapters/3_day.rpy:232
    old "3. <Finally decided to block me?> {font=gui/starthings.ttf}a{/font}"
    new "3. <¿Finalmente decidiste bloquearme?> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/3_day.rpy:248
    old "1. <Okay, but why?>"
    new "1. <Okey, pero ¿por qué?>"

    # game/chapters/3_day.rpy:253
    old "1. <Does this have something to do with your \ncamera being off?>"
    new "1. <¿Tiene esto algo que ver con que tu cámara esté apagada?>"

    # game/chapters/3_day.rpy:255
    old "2. <Why are you being extra edgy right now?>"
    new "2. <¿Por qué estás siendo extra edgy ahora?>"

    # game/chapters/3_day.rpy:257
    old "3. <Is everything alright?>"
    new "3. <¿Está todo bien?>"

    # game/chapters/3_day.rpy:263
    old "1. <Are you okay?>"
    new "1. <¿Estás bien?>"

    # game/chapters/3_day.rpy:269
    old "1. <What happened?>"
    new "1. <¿Qué pasó?>"

    # game/chapters/3_day.rpy:271
    old "2. <You can tell me if there's a problem.>"
    new "2. <Puedes decirme si hay algún problema.>"

    # game/chapters/3_day.rpy:279
    old "1. <You say that, and yet you've called me anyway.>"
    new "1. <Eso dices, pero aun así me llamaste.>"

    # game/chapters/3_day.rpy:282
    old "1. <So it makes me think something happened.>"
    new "1. <Por eso pienso que algo pasó.>"

    # game/chapters/3_day.rpy:288
    old "1. <So? What's wrong?>"
    new "1. <¿Entonces? ¿Qué pasa?>"

    # game/chapters/3_day.rpy:294
    old "1. <Will you turn your camera on?>"
    new "1. <¿Vas a encender tu cámara?>"

    # game/chapters/3_day.rpy:296
    old "2. <Somehow I miss your face, you know.>"
    new "2. <De algún modo extraño tu cara, ¿sabes?>"

    # game/chapters/3_day.rpy:298
    old "1. <How about turning your camera on?>"
    new "1. <¿Qué tal si enciendes tu cámara?>"

    # game/chapters/3_day.rpy:308
    old "1. <What's that supposed to mean?>"
    new "1. <¿Qué se supone que significa eso?>"

    # game/chapters/3_day.rpy:311
    old "1. <Are you hurt?>"
    new "1. <¿Estás herido?>"

    # game/chapters/3_day.rpy:317
    old "1. <!!!>"
    new "1. <!!!>"

    # game/chapters/3_day.rpy:319
    old "2. <Really?!>"
    new "2. <¿¡En serio!?>"

    # game/chapters/3_day.rpy:322
    old "1. <Grim...!>"
    new "1. <¡Parca...!>"

    # game/chapters/3_day.rpy:329
    old "1. <Your... mind?>"
    new "1. <¿Tu... mente?>"

    # game/chapters/3_day.rpy:338
    old "2. <Your sass hasn't been hurt, I see.>"
    new "2. <Veo que tu sarcasmo sigue intacto.>"

    # game/chapters/3_day.rpy:344
    old "1. <That I {i}can{/i} understand.>"
    new "1. <Eso sí lo {i}puedo{/i} entender.>"

    # game/chapters/3_day.rpy:348
    old "1. <You should have a nap.>"
    new "1. <Deberías tomar una siesta.>"

    # game/chapters/3_day.rpy:351
    old "2. <You should eat something.>"
    new "2. <Deberías comer algo.>"

    # game/chapters/3_day.rpy:354
    old "3. <Maybe you should have a relaxing bath?>"
    new "3. <¿Quizás deberías tomar un baño relajante?>"

    # game/chapters/3_day.rpy:366
    old "1. <...To rebalance?>"
    new "1. <...¿Para reequilibrarte?>"

    # game/chapters/3_day.rpy:372
    old "1. <What does that even mean?>"
    new "1. <¿Qué significa eso siquiera?>"

    # game/chapters/3_day.rpy:374
    old "2. <Not going to lie, I have no clue what \nyou're talking about.>"
    new "2. <Para serte sincer[letra], no tengo ni idea de qué hablas.>"

    # game/chapters/3_day.rpy:376
    old "3. <Right, your soul. Uh huh.>"
    new "3. <Cierto, tu alma. Ajá.>"

    # game/chapters/3_day.rpy:380
    old "1. <Um, oka—>"
    new "1. <Um, está b—>"

    # game/chapters/3_day.rpy:404
    old "1. <Too bright?>"
    new "1. <¿Demasiado brillante?>"

    # game/chapters/3_day.rpy:409
    old "1. <I can't decide if you mean that as a compliment or an insult.>"
    new "1. <No sé si tomármelo como un cumplido o como un insulto.>"

    # game/chapters/3_day.rpy:417
    old "1. <Um...?>"
    new "1. <¿Um...?>"

    # game/chapters/3_day.rpy:419
    old "2. <What are you talking about...?>"
    new "2. <¿De qué estás hablando...?>"

    # game/chapters/3_day.rpy:425
    old "1. <I am so confused right now.>"
    new "1. <Estoy muy confundid[letra] ahora mismo.>"

    # game/chapters/3_day.rpy:429
    old "2. <You say a lot of crazy things, but...>"
    new "2. <Dices muchas cosas locas, pero...>"

    # game/chapters/3_day.rpy:433
    old "1. <You're being extra strange today.>"
    new "1. <Hoy estás extra raro.>"

    # game/chapters/3_day.rpy:438
    old "1. <What do you mean by my aura...?>"
    new "1. <¿Qué quieres decir con mi aura...?>"

    # game/chapters/3_day.rpy:444
    old "1. <I... see?>"
    new "1. <Ya... ¿entiendo?>"

    # game/chapters/3_day.rpy:450
    old "2. <Uh... right?>"
    new "2. <Eh... ¿ah, sí?>"

    # game/chapters/3_day.rpy:455
    old "1. <Most?>"
    new "1. <¿La mayoría?>"

    # game/chapters/3_day.rpy:464
    old "1. <I still don't understand.>"
    new "1. <Sigo sin entender.>"

    # game/chapters/3_day.rpy:467
    old "1. <Do you have an eye condition?>"
    new "1. <¿Tienes algún problema de la vista?>"

    # game/chapters/3_day.rpy:475
    old "1. <Are you trying to tell me I'm dead?>"
    new "1. <¿Estás tratando de decirme que estoy muert[letra]?>"

    # game/chapters/3_day.rpy:487
    old "2. <Maybe you should invest in some glasses?>"
    new "2. <¿Y si mejor te compras unos lentes?>"

    # game/chapters/3_day.rpy:493
    old "1. <I'm not sure about that...>"
    new "1. <Lo dudo...>"

    # game/chapters/3_day.rpy:497
    old "1. <Let's say I believe you, hypothetically.>"
    new "1. <Digamos que te creo, hipotéticamente.>"

    # game/chapters/3_day.rpy:500
    old "3. <This feels like the lead-in to a scam...> {font=gui/starthings.ttf}a{/font}"
    new "3. <Esto se siente como la introducción a una estafa...> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/3_day.rpy:505
    old "1. <'Your soul is corrupted... but I have the miracle cure!'>"
    new "1. <'Tu alma está corrompida... ¡pero tengo la cura milagrosa!'>"

    # game/chapters/3_day.rpy:508
    old "1. <'And all it will cost you is $59.99 (plus taxes)!'>"
    new "1. <'¡Y todo lo que costará es $59,99 (más impuestos)!'>"

    # game/chapters/3_day.rpy:515
    old "1. <You are a scam artist's favorite kind of person.>"
    new "1. <Eres el tipo de persona favorito de un estafador.>"

    # game/chapters/3_day.rpy:520
    old "1. <It is not.>"
    new "1. <No lo es.>"

    # game/chapters/3_day.rpy:522
    old "2. <Well, I... yeah, sure.>"
    new "2. <Bueno, yo... sí, claro.>"

    # game/chapters/3_day.rpy:526
    old "1. <Anyway.>"
    new "1. <En fin.>"

    # game/chapters/3_day.rpy:530
    old "1. <What is my soul like, then?>"
    new "1. <¿Cómo es mi alma entonces?>"

    # game/chapters/3_day.rpy:536
    old "1. <That seems like a contradiction to me.>"
    new "1. <Eso me parece una contradicción.>"

    # game/chapters/3_day.rpy:543
    old "1. <A blood what now?!>"
    new "1. <¿¡Una qué de sangre!?>"

    # game/chapters/3_day.rpy:549
    old "1. <Grim, I literally have no clue what all this is even about.>"
    new "1. <Parca, literalmente no tengo ni idea de qué va todo esto.>"

    # game/chapters/3_day.rpy:552
    old "1. <Blood promises and curses? That stuff is out of fantasy books.>"
    new "1. <¿Promesas de sangre y maldiciones? Eso es material de libros de fantasía.>"

    # game/chapters/3_day.rpy:555
    old "1. <Not real life...>"
    new "1. <No de la vida real...>"

    # game/chapters/3_day.rpy:562
    old "2. <A curse... I don't think so?>"
    new "2. <¿Una maldición...? No lo creo.>"

    # game/chapters/3_day.rpy:566
    old "1. <I think I would remember if I had, so no...?>"
    new "1. <Creo que lo recordaría si lo hubiera hecho, así que ¿no...?>"

    # game/chapters/3_day.rpy:571
    old "1. <Rule them out? Of what exactly?>"
    new "1. <¿Descartarlas de qué exactamente?>"

    # game/chapters/3_day.rpy:574
    old "1. <Can you explain what you're talking about, Grim?>"
    new "1. <¿Puedes explicar de qué hablas, Parca?>"

    # game/chapters/3_day.rpy:577
    old "1. <All this talk of curses and blood promises is something out of fiction.>"
    new "1. <Todo este asunto de maldiciones y promesas de sangre parece sacado de una historia de ficción.>"

    # game/chapters/3_day.rpy:580
    old "1. <Completely not real.>"
    new "1. <Completamente irreal.>"

    # game/chapters/3_day.rpy:587
    old "3. <Yes. I was cursed after breaking a \nblood promise six moons ago.> {font=gui/starthings.ttf}a{/font}"
    new "3. <Sí. Me maldijeron después de romper una promesa de sangre hace seis lunas.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/3_day.rpy:592
    old "1. <The curse... will not allow me to say...>"
    new "1. <La maldición... no me permite decirlo...>"

    # game/chapters/3_day.rpy:595
    old "1. <If I speak of the details, it will drain my life force away forever...>"
    new "1. <Si hablo de los detalles, drenará mi fuerza vital para siempre...>"

    # game/chapters/3_day.rpy:600
    old "1. <And not only that...>"
    new "1. <Y no solo eso...>"

    # game/chapters/3_day.rpy:603
    old "1. <My blood now bleeds black...>"
    new "1. <Ahora mi sangre es negra...>"

    # game/chapters/3_day.rpy:606
    old "1. <As dark as the night sky.>"
    new "1. <Tan oscura como el cielo nocturno.>"

    # game/chapters/3_day.rpy:611
    old "1. <Obviously.>"
    new "1. <Obviamente.>"

    # game/chapters/3_day.rpy:614
    old "1. <Seriously, Grim?>"
    new "1. <¿En serio, Parca?>"

    # game/chapters/3_day.rpy:617
    old "1. <Blood promises? Curses?>"
    new "1. <¿Promesas de sangre? ¿Maldiciones?>"

    # game/chapters/3_day.rpy:620
    old "1. <Have you gone insane... sorry, even more insane?>"
    new "1. <¿Te volviste loco...? Perdón, ¿aún más loco?>"

    # game/chapters/3_day.rpy:625
    old "1. <If you start making sense, then I'll understand.>"
    new "1. <Si empiezas a hablar con sentido, entonces te entenderé.>"

    # game/chapters/3_day.rpy:629
    old "1. <You know what...>"
    new "1. <Sabes qué...>"

    # game/chapters/3_day.rpy:632
    old "1. <After this whole weird conversation...>"
    new "1. <Después de toda esta extraña conversación...>"

    # game/chapters/3_day.rpy:635
    old "1. <I don't know if I like the thought of you having an 'idea'...>"
    new "1. <No sé si me agrada que se te haya ocurrido una 'idea'...>"

    # game/chapters/3_day.rpy:639
    old "1. <It just makes no sense...>"
    new "1. <Simplemente no tiene sentido...>"

    # game/chapters/3_day.rpy:643
    old "2. <I can try?>"
    new "2. <¿Puedo intentarlo?>"

    # game/chapters/3_day.rpy:647
    old "1. <So what is this 'idea' of yours, then?>"
    new "1. <Entonces, ¿cuál es esa 'idea' tuya?>"

    # game/chapters/3_day.rpy:653
    old "2. <You've gone insane...>"
    new "2. <Te has vuelto loco...>"

    # game/chapters/3_day.rpy:655
    old "3. <Brilliant! Oh how I've {i}always{/i} dreamed of just that!>"
    new "3. <¡Brillante! ¡Oh, cómo he soñado {i}siempre{/i} con eso!>"

    # game/chapters/3_day.rpy:657
    old "4. <Soul babies...?> {font=gui/starthings.ttf}a{/font}"
    new "4. <¿Bebés alma...?> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/3_day.rpy:663
    old "1. <That's pretty much soul baby territory.>"
    new "1. <Eso ya es terreno de bebés alma.>"

    # game/chapters/3_day.rpy:675
    old "1. <Um... er...?>"
    new "1. <¿Um... er...?>"

    # game/chapters/3_day.rpy:677
    old "2. <Uhhh...>"
    new "2. <Uhhh...>"

    # game/chapters/3_day.rpy:679
    old "3. <Hmmmm...>"
    new "3. <Hmmmm...>"

    # game/chapters/3_day.rpy:682
    old "1. <How exactly does one 'channel life force'?>"
    new "1. <¿Cómo exactamente se 'canaliza la fuerza vital'?>"

    # game/chapters/3_day.rpy:685
    old "1. <And what exactly does that mean?>"
    new "1. <¿Y qué significa eso exactamente?>"

    # game/chapters/3_day.rpy:687
    old "2. <What am I even asking you right now...>"
    new "2. <¿Qué te estoy preguntando siquiera...?>"

    # game/chapters/3_day.rpy:693
    old "1. <I know I've been playing along with your whole Grim Reaper thing...>"
    new "1. <Sé que he estado siguiéndote el juego con todo ese cuento de la Parca...>"

    # game/chapters/3_day.rpy:697
    old "1. <But you've just gotten a buttload stranger.>"
    new "1. <Pero te has vuelto muchísimo más raro.>"

    # game/chapters/3_day.rpy:704
    old "2. <Am I on one of those prank shows?>"
    new "2. <¿Estoy en uno de esos programas de bromas?>"

    # game/chapters/3_day.rpy:707
    old "1. <The camera crew will jump out any second now, right?>"
    new "1. <El equipo de cámaras va a aparecer en cualquier momento, ¿verdad?>"

    # game/chapters/3_day.rpy:710
    old "1. <They'll be like 'haha you fell for it'.>"
    new "1. <Dirán 'jaja, caíste'.>"

    # game/chapters/3_day.rpy:714
    old "1. <Cool cool. Not a prank then?>"
    new "1. <Genial genial. ¿No es una broma entonces?>"

    # game/chapters/3_day.rpy:720
    old "1. <Right... right, I see...>"
    new "1. <Cierto... cierto, ya veo...>"

    # game/chapters/3_day.rpy:725
    old "1. <A bridge, of course...>"
    new "1. <Un puente, claro...>"

    # game/chapters/3_day.rpy:728
    old "1. <Can it be a pretty bridge?>"
    new "1. <¿Puede ser un puente bonito?>"

    # game/chapters/3_day.rpy:731
    old "2. <Can't say a guy's ever wanted to make a mind bridge with me before.>"
    new "2. <No puedo decir que un chico haya querido hacer un puente mental conmigo antes.>"

    # game/chapters/3_day.rpy:740
    old "1. <You'll WHAT?>"
    new "1. <¿¡Transferirás QUÉ!?>"

    # game/chapters/3_day.rpy:742
    old "2. <Oh, brilliant.>"
    new "2. <Oh, brillante.>"

    # game/chapters/3_day.rpy:745
    old "1. <This is so totally normal.>"
    new "1. <Esto es totalmente normal.>"

    # game/chapters/3_day.rpy:750
    old "1. <Will it hurt?>"
    new "1. <¿Va a doler?>"

    # game/chapters/3_day.rpy:760
    old "2. <Can I say no?>"
    new "2. <¿Puedo decir que no?>"

    # game/chapters/3_day.rpy:766
    old "1. <What would happen if I wanted to stop afterwards?>"
    new "1. <¿Qué pasaría si quisiera detenerlo después?>"

    # game/chapters/3_day.rpy:775
    old "3. <Is this like a demonic possession?>"
    new "3. <¿Esto es como una posesión demoníaca?>"

    # game/chapters/3_day.rpy:782
    old "2. <That's... comforting.>"
    new "2. <Eso es... tranquilizador.>"

    # game/chapters/3_day.rpy:785
    old "1. <There is a first time for everything, I guess...>"
    new "1. <Siempre hay una primera vez para todo, supongo...>"

    # game/chapters/3_day.rpy:788
    old "1. <Lets say you're not lying. What will happen to me?>"
    new "1. <Digamos que no estás mintiendo. ¿Qué me pasará?>"

    # game/chapters/3_day.rpy:792
    old "1. <And if I do resist?>"
    new "1. <¿Y si me resisto?>"

    # game/chapters/3_day.rpy:800
    old "4. <This IS the soul baby thing again!>"
    new "4. <¡Esto SÍ es lo de los bebés alma otra vez!>"

    # game/chapters/3_day.rpy:805
    old "1. <If you connect to me via your weird magic...>"
    new "1. <Si te conectas a mí a través de tu magia rara...>"

    # game/chapters/3_day.rpy:808
    old "1. <Seems a little soul baby...y.>"
    new "1. <Suena un poquito a... bebés alma.>"

    # game/chapters/3_day.rpy:821
    old "1. <Fracture...?>"
    new "1. <¿Fracturar...?>"

    # game/chapters/3_day.rpy:824
    old "1. <What does that mean?>"
    new "1. <¿Qué significa eso?>"

    # game/chapters/3_day.rpy:830
    old "1. <I wouldn't be me anymore?>"
    new "1. <¿Ya no sería yo?>"

    # game/chapters/3_day.rpy:837
    old "1. <So this is a consensual possession huh...>"
    new "1. <Así que esto es una posesión consensuada, eh...>"

    # game/chapters/3_day.rpy:840
    old "1. <And if I change my mind...>"
    new "1. <Y si cambio de opinión...>"

    # game/chapters/3_day.rpy:843
    old "1. <Boom, demon time.>"
    new "1. <Boom, hora de demonios.>"

    # game/chapters/3_day.rpy:847
    old "1. <Possession sounds pretty forbidden, ngl.>"
    new "1. <La posesión suena bastante prohibida, no voy a mentir.>"

    # game/chapters/3_day.rpy:851
    old "1. <So you aren't breaking any Underworld rules or anything, then?>"
    new "1. <Entonces no estás rompiendo ninguna regla del Inframundo ni nada, ¿verdad?>"

    # game/chapters/3_day.rpy:858
    old "2. <Are you not going to answer me?>"
    new "2. <¿No me vas a responder?>"

    # game/chapters/3_day.rpy:861
    old "3. <You naughty boy.> {font=gui/starthings.ttf}a{/font}"
    new "3. <Chico travieso.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/3_day.rpy:864
    old "1. <How many rules are you about to break?>"
    new "1. <¿Cuántas reglas estás a punto de romper?>"

    # game/chapters/3_day.rpy:900
    old "1. <Still no camera? Really?>"
    new "1. <¿Aún sin cámara? ¿En serio?>"

    # game/chapters/3_day.rpy:902
    old "2. <Wow, I love talking to a blank screen.>"
    new "2. <Wow, me encanta hablarle a una pantalla oscura.>"

    # game/chapters/3_day.rpy:917
    old "1. <You don't look very hurt.>"
    new "1. <No pareces estar muy herido.>"

    # game/chapters/3_day.rpy:919
    old "2. <Where are these injuries, then?>"
    new "2. <¿Dónde están esas heridas, entonces?>"

    # game/chapters/3_day.rpy:924
    old "1. <You said—>"
    new "1. <Dijiste—>"

    # game/chapters/3_day.rpy:930
    old "1. <Can't you just tell me?>"
    new "1. <¿No puedes simplemente decírmelo?>"

    # game/chapters/3_day.rpy:933
    old "1. <I'll worry otherwise.>"
    new "1. <De lo contrario me preocuparé.>"

    # game/chapters/3_day.rpy:935
    old "2. <The anticipation of not knowing is too much!>"
    new "2. <¡La anticipación de no saber es demasiado!>"

    # game/chapters/3_day.rpy:937
    old "3. <I don't like thinking you're hurt and not \nunderstanding how.>"
    new "3. <No me gusta pensar que estás herido y no entender cómo.>"

    # game/chapters/3_day.rpy:942
    old "1. <Your mind... ?>"
    new "1. <¿Tu mente...?>"

    # game/chapters/3_day.rpy:945
    old "1. <Should this mind-connection-joiny-thing not \nwait, then?>"
    new "1. <¿No debería esta cosa de conectar mentes esperar, entonces?>"

    # game/chapters/3_day.rpy:948
    old "1. <You know, until you've recovered?>"
    new "1. <Ya sabes, ¿hasta que te hayas recuperado?>"

    # game/chapters/3_day.rpy:957
    old "1. <Won't it make it worse?>"
    new "1. <¿No lo empeorará?>"

    # game/chapters/3_day.rpy:966
    old "1. <Is this not dangerous for your health?>"
    new "1. <¿Esto no es peligroso para tu salud?>"

    # game/chapters/3_day.rpy:972
    old "1. <Well, if you say so...>"
    new "1. <Bueno, si tú lo dices...>"

    # game/chapters/3_day.rpy:974
    old "2. <I guess none of this is real, but I still feel bad...>"
    new "2. <Supongo que nada de esto es real, pero aun así me siento mal...>"

    # game/chapters/3_day.rpy:978
    old "1. <Okay, so I just look at you?>"
    new "1. <Okey, ¿entonces solo te miro?>"

    # game/chapters/3_day.rpy:985
    old "1. <Yes..?>"
    new "1. <¿Sí...?>"

    # game/chapters/3_day.rpy:992
    old "1. <How will I know when it's formed?>"
    new "1. <¿Cómo sabré cuando esté formada?>"

    # game/chapters/3_day.rpy:1000
    old "1. <What about that... 'resistance'?>"
    new "1. <¿Y qué hay de esa... 'resistencia'?>"

    # game/chapters/3_day.rpy:1010
    old "1. <You aren't going to make me do weird things, right...?>"
    new "1. <No vas a hacerme hacer cosas raras, ¿verdad...?>"

    # game/chapters/3_day.rpy:1012
    old "2. <Are you going to take control of my body?>"
    new "2. <¿Vas a tomar control de mi cuerpo?>"

    # game/chapters/3_day.rpy:1023
    old "1. <So once you're in, you're going to do what exactly?>"
    new "1. <Entonces, una vez que estés dentro, ¿qué vas a hacer exactamente?>"

    # game/chapters/3_day.rpy:1031
    old "2. <Which means...?>"
    new "2. <¿Lo que significa...?>"

    # game/chapters/3_day.rpy:1040
    old "1. <I'm about to hypothetically let you into my mind! \nOf course I'm going to have questions!>"
    new "1. <¡Estoy a punto de dejarte entrar hipotéticamente en mi mente! ¡Por supuesto que voy a tener preguntas!>"

    # game/chapters/3_day.rpy:1043
    old "1. <I almost sound like I really believe you...>"
    new "1. <Casi sueno como si de verdad te creyera...>"

    # game/chapters/3_day.rpy:1046
    old "1. <Maybe {i}I'm{/i} the real crazy one...>"
    new "1. <Quizás {i}yo{/i} soy [arti] verdader[letra] loc[letra]...>"

    # game/chapters/3_day.rpy:1053
    old "1. <Uhhh...>"
    new "1. <Uhhh...>"

    # game/chapters/3_day.rpy:1055
    old "2. <That almost sounds gross.>"
    new "2. <Eso casi suena asqueroso.>"

    # game/chapters/3_day.rpy:1057
    old "3. <Surely you could've phrased that a little better.>"
    new "3. <Seguro podrías haberlo dicho un poco mejor.>"

    # game/chapters/3_day.rpy:1065
    old "2. <Woah, stop right there.>"
    new "2. <Guau, detente justo ahí.>"

    # game/chapters/3_day.rpy:1068
    old "1. <Seeing as you keep mentioning that you \nwant to... you know... kill me...>"
    new "1. <Viendo que sigues mencionando que quieres... ya sabes... matarme...>"

    # game/chapters/3_day.rpy:1071
    old "1. <How do I know this isn't a trick?>"
    new "1. <¿Cómo sé que esto no es una trampa?>"

    # game/chapters/3_day.rpy:1073
    old "2. <Is this actually a ploy for you to take my soul?>"
    new "2. <¿Esto es en realidad un plan para quedarte con mi alma?>"

    # game/chapters/3_day.rpy:1081
    old "1. <Trust the guy wanting to take my soul, right...>"
    new "1. <Confiar en el tipo que quiere tomar mi alma, ¿verdad...?>"

    # game/chapters/3_day.rpy:1083
    old "2. <It's a little hard to trust that...>"
    new "2. <Es un poco difícil confiar en eso...>"

    # game/chapters/3_day.rpy:1089
    old "1. <...Fine. I believe you.>"
    new "1. <...Bien. Te creo.>"

    # game/chapters/3_day.rpy:1091
    old "2. <I don't know if I believe you, but... let's do it anyway.>"
    new "2. <No sé si creerte, pero... hagámoslo de todos modos.>"

    # game/chapters/3_day.rpy:1097
    old "1. <As prepared as I'll ever be...>"
    new "1. <Tan preparad[letra] como lo estaré alguna vez...>"

    # game/chapters/3_day.rpy:1099
    old "2. <Come at me, Grim.>"
    new "2. <Ven a por mí, Parca.>"

    # game/chapters/3_day.rpy:1101
    old "3. <Yeah, I'm excited!>"
    new "3. <¡Sí, qué emoción!>"

    # game/chapters/3_day.rpy:1103
    old "4. <...I trust you with my soul, Grim.> {font=gui/starthings.ttf}a{/font}"
    new "4. <...Confío en ti con mi alma, Parca.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/3_day.rpy:1106
    old "1. <Well, you have the professional experience \nwith souls, huh?>"
    new "1. <Bueno, tienes experiencia profesional con las almas, ¿eh?>"

    # game/chapters/3_day.rpy:1109
    old "1. <You're probably one of the most trustworthy \npeople to look after a soul.>"
    new "1. <Probablemente seas de las personas más confiables para cuidar un alma.>"

    # game/chapters/3_day.rpy:1112
    old "1. <...Or something. I don't know.>"
    new "1. <...O algo así. No lo sé.>"

    # game/chapters/3_day.rpy:1131
    old "1. <Grim...?>"
    new "1. <¿Parca...?>"

    # game/chapters/3_day.rpy:1136
    old "1. <Are you sure this is—>"
    new "1. <¿Estás seguro de que esto es—>"

    # game/chapters/3_day.rpy:1143
    old "1. <I am—>"
    new "1. <Yo estoy—>"

    # game/chapters/3_day.rpy:1158
    old "1. <Ah...!>"
    new "1. <¡Ah...!>"

    # game/chapters/3_day.rpy:1165
    old "1. <It... something feels strange...>"
    new "1. <Esto... algo se siente extraño...>"

    # game/chapters/3_day.rpy:1173
    old "1. <What the... I... you...>"
    new "1. <Qué demonios... yo... tú...>"

    # game/chapters/3_day.rpy:1175
    old "1. <How is this... possible?>"
    new "1. <¿Cómo es esto... posible?>"

    # game/chapters/3_day.rpy:1178
    old "2. <Dude, what is going on?!>"
    new "2. <¡¿Amigo, qué está pasando?!>"

    # game/chapters/3_day.rpy:1180
    old "1. <I... huh?>"
    new "1. <Yo... ¿eh?>"

    # game/chapters/3_day.rpy:1183
    old "3. <You... were serious about the whole \npossession thing...> {font=gui/starthings.ttf}a{/font}"
    new "3. <Tú... hablabas en serio sobre lo de la posesión...> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/3_day.rpy:1185
    old "1. <I think I'm going to faint.>"
    new "1. <Creo que me voy a desmayar.>"

    # game/chapters/3_day.rpy:1188
    old "1. <How is this possible...?>"
    new "1. <¿Cómo es posible esto...?>"

    # game/chapters/3_day.rpy:1191
    old "1. <This isn't a trick, is it? I mean, I can't even \nthink of a way you WOULD trick me...>"
    new "1. <Esto no es un truco, ¿verdad? Quiero decir, ni siquiera puedo pensar en una forma en que PUDIERAS engañarme...>"

    # game/chapters/3_day.rpy:1196
    old "1. <Wait a second, I never claimed you were {i}normal{/i}.>"
    new "1. <Espera un segundo, nunca dije que fueras {i}normal{/i}.>"

    # game/chapters/3_day.rpy:1199
    old "1. <That much was obvious.>"
    new "1. <Eso era bastante obvio.>"

    # game/chapters/3_day.rpy:1203
    old "1. <You're good at making compliments out of \nthings that aren't compliments.>"
    new "1. <Eres bueno convirtiendo en cumplidos cosas que no lo son.>"

    # game/chapters/3_day.rpy:1206
    old "1. <By the way...>"
    new "1. <Por cierto...>"

    # game/chapters/3_day.rpy:1211
    old "1. <It feels... cold. {i}You{/i} feel cold.>"
    new "1. <Se siente... frío. {i}Tú{/i} me transmites frío.>"

    # game/chapters/3_day.rpy:1219
    old "1. <That's you, right? That cold feeling...>"
    new "1. <Eres tú, ¿verdad? Esa sensación de frío...>"

    # game/chapters/3_day.rpy:1227
    old "1. <You really were... serious this whole time?>"
    new "1. <¿De verdad habías estado... hablando en serio todo este tiempo?>"

    # game/chapters/3_day.rpy:1233
    old "1. <You're...>"
    new "1. <Tú eres...>"

    # game/chapters/3_day.rpy:1236
    old "1. <Actually the Grim Reaper?>"
    new "1. <¿Realmente la Parca?>"

    # game/chapters/3_day.rpy:1251
    old "1. <How... how could that be possible...?>"
    new "1. <¿Cómo... cómo podría ser posible...?>"

    # game/chapters/3_day.rpy:1263
    old "1. <The connection...>"
    new "1. <La conexión...>"

    # game/chapters/3_day.rpy:1265
    old "2. <Feels... itchy.>"
    new "2. <Se siente... como una picazón.>"

    # game/chapters/3_day.rpy:1270
    old "1. <I feel it... like a pull.>"
    new "1. <Lo siento... como un tirón.>"

    # game/chapters/3_day.rpy:1276
    old "1. <Can you... see through my eyes? How does this work?>"
    new "1. <¿Puedes... ver a través de mis ojos? ¿Cómo funciona esto?>"

    # game/chapters/3_day.rpy:1279
    old "1. <You haven't done that yet?>"
    new "1. <¿Aún no has hecho eso?>"

    # game/chapters/3_day.rpy:1286
    old "1. <That makes... absolutely no sense.>"
    new "1. <Eso no tiene... absolutamente ningún sentido.>"

    # game/chapters/3_day.rpy:1288
    old "2. <Of course, it makes perfect sense.>"
    new "2. <Por supuesto, tiene todo el sentido.>"

    # game/chapters/3_day.rpy:1290
    old "1. <Obviously....>"
    new "1. <Obviamente...>"

    # game/chapters/3_day.rpy:1293
    old "1. <So much sense.>"
    new "1. <Tiene mucho sentido.>"

    # game/chapters/3_day.rpy:1298
    old "2. <Is this where you start doing questionable \nthings with my body...> {font=gui/starthings.ttf}a{/font}"
    new "2. <¿Es aquí donde empiezas a hacer cosas cuestionables con mi cuerpo...?> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/3_day.rpy:1325
    old "1. <Actually I flirt because I kinda like you.>"
    new "1. <En realidad coqueteo porque me gustas un poco.>"

    # game/chapters/3_day.rpy:1336
    old "2. <Yeah, it is amusing.>"
    new "2. <Sí, es divertido.>"

    # game/chapters/3_day.rpy:1343
    old "2. <Maybe next time, then.>"
    new "2. <Quizás la próxima vez, entonces.>"

    # game/chapters/3_day.rpy:1353
    old "1. <...Grim?>"
    new "1. <...¿Parca?>"

    # game/chapters/3_day.rpy:1359
    old "1. <What if my mind...>"
    new "1. <¿Y si mi mente...?>"

    # game/chapters/3_day.rpy:1361
    old "2. <If I accidentally—>"
    new "2. <Si accidentalmente—>"

    # game/chapters/3_day.rpy:1369
    old "1. <If you say so...>"
    new "1. <Si tú lo dices...>"

    # game/chapters/3_day.rpy:1372
    old "1. <Not exactly.>"
    new "1. <No exactamente.>"

    # game/chapters/3_day.rpy:1374
    old "1. <I do feel like we're... suited for each other, \nlike you said.>"
    new "1. <Sí siento que estamos... hechos el uno para el otro, como dijiste.>"

    # game/chapters/3_day.rpy:1377
    old "1. <I'm just unsure about what it means to be \nsuited to... death, literally.>"
    new "1. <No tengo claro lo que significa estar hech[letra] para... la muerte, literalmente.>"

    # game/chapters/3_day.rpy:1383
    old "2. <Okay... I believe you.>"
    new "2. <Okey... te creo.>"

    # game/chapters/3_day.rpy:1386
    old "1. <Does that mean I get to keep my soul?>"
    new "1. <¿Eso significa que puedo quedarme con mi alma?>"

    # game/chapters/3_day.rpy:1391
    old "1. <I suppose...>"
    new "1. <Supongo...>"

    # game/chapters/3_day.rpy:1394
    old "3. <I don't trust you, but let's do it anyway.>"
    new "3. <No confío en ti, pero hagámoslo de todos modos.>"

    # game/chapters/3_day.rpy:1398
    old "1. <In my defense, you are trying to kill me.>"
    new "1. <En mi defensa, estás intentando matarme.>"

    # game/chapters/3_day.rpy:1404
    old "4. <...I wouldn't do this with anyone other than you.> {font=gui/starthings.ttf}a{/font}"
    new "4. <...No haría esto con nadie más que contigo.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/3_day.rpy:1408
    old "1. <Even if it became someone else's duty.>"
    new "1. <Aunque se convirtiera en el deber de otra persona.>"

    # game/chapters/3_day.rpy:1411
    old "1. <I trust... you.>"
    new "1. <Confío... en ti.>"

    # game/chapters/3_day.rpy:1423
    old "1. <Well, yeah...>"
    new "1. <Bueno, sí...>"

    # game/chapters/3_day.rpy:1427
    old "1. <Still.>"
    new "1. <Aun así.>"

    # game/chapters/3_day.rpy:1430
    old "1. <Even before this connection thing, I felt like...>"
    new "1. <Incluso antes de esta cosa de la conexión, sentía que...>"

    # game/chapters/3_day.rpy:1433
    old "1. <You and I have an innate bond, as \nweird as that sounds.>"
    new "1. <Tú y yo tenemos un vínculo innato, por más raro que suene.>"

    # game/chapters/3_day.rpy:1441
    old "1. <That's very specific.>"
    new "1. <Eso es muy específico.>"

    # game/chapters/3_day.rpy:1445
    old "1. <Anyway, how do we do this?>"
    new "1. <En fin, ¿cómo hacemos esto?>"

    # game/chapters/3_day.rpy:1451
    old "1. <Okay, I can imagine a bridge.>"
    new "1. <Okey, puedo imaginar un puente.>"

    # game/chapters/3_day.rpy:1453
    old "2. <Oh yeah, it's a huuuuge bridge.>"
    new "2. <Oh sí, es un puente enooorme.>"

    # game/chapters/3_day.rpy:1455
    old "3. <It's just a little bridge. Smol thing.>"
    new "3. <Es solo un pequeño puente. Una cosita.>"

    # game/chapters/3_day.rpy:1464
    old "1. <What do I do?>"
    new "1. <¿Qué hago?>"

    # game/chapters/3_day.rpy:1466
    old "2. <Sounds simple enough.>"
    new "2. <Suena lo bastante simple.>"

    # game/chapters/3_day.rpy:1473
    old "1. <What happens if I let go?>"
    new "1. <¿Qué pasa si me suelto?>"

    # game/chapters/3_day.rpy:1477
    old "1. <...That doesn't sound ideal.>"
    new "1. <...Eso no suena ideal.>"

    # game/chapters/3_day.rpy:1479
    old "2. <Ooookay. Let's try to avoid that, then.>"
    new "2. <Oooookey. Intentemos evitar eso, entonces.>"

    # game/chapters/3_day.rpy:1485
    old "1. <Gotcha. Don't let go.>"
    new "1. <Entendido. No soltarme.>"

    # game/chapters/3_day.rpy:1488
    old "1. <...What would happen to you, though?>"
    new "1. <...¿Pero qué te pasaría a ti?>"

    # game/chapters/3_day.rpy:1491
    old "1. <Like, hypothetically.>"
    new "1. <Como, hipotéticamente.>"

    # game/chapters/3_day.rpy:1500
    old "1. <I'll hold on tight.>"
    new "1. <Me sujetaré fuerte.>"

    # game/chapters/3_day.rpy:1505
    old "2. <Okay, I can do that.>"
    new "2. <Okey, puedo hacer eso.>"

    # game/chapters/3_day.rpy:1518
    old "3. <What happens if I don't feel this... 'pull' anymore?>"
    new "3. <¿Qué pasa si ya no siento este... 'tirón'?>"

    # game/chapters/3_day.rpy:1527
    old "1. <Then that shouldn't be a worry, right?>"
    new "1. <Entonces eso no debería ser una preocupación, ¿verdad?>"

    # game/chapters/3_day.rpy:1535
    old "2. <Got it, Boss.>"
    new "2. <Entendido, Jefe.>"

    # game/chapters/3_day.rpy:1546
    old "1. <Okay...>"
    new "1. <Okey...>"

    # game/chapters/3_day.rpy:1548
    old "2. <I'll try my best.>"
    new "2. <Haré mi mejor esfuerzo.>"

    # game/chapters/3_day.rpy:1550
    old "3. <I'll be as cool as a cucumber.>"
    new "3. <Estaré tan fresc[letra] como una lechuga.>"

    # game/chapters/3_day.rpy:1552
    old "1. <A particuarly cool one.>"
    new "1. <Una particularmente fresca.>"

    # game/chapters/3_day.rpy:1554
    old "4. <I'm cheering for you, babygirl.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Estoy animándote, babygirl.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/3_day.rpy:1562
    old "1. <You're pathetic but cute.>"
    new "1. <Eres patético pero lindo.>"

    # game/chapters/3_day.rpy:1567
    old "2. <You just give off malewife vibes. Sorry.>"
    new "2. <Simplemente das vibras de 'malewife'. Perdón.>"

    # game/chapters/3_day.rpy:1572
    old "1. <It's a compliment.>"
    new "1. <Es un cumplido.>"

    # game/chapters/3_day.rpy:1577
    old "3. <Submissive and breed—I mean you're just \nsweet like that.>"
    new "3. <Sumiso y reproduc—digo, es que eres tierno así.>"

    # game/chapters/3_day.rpy:1582
    old "1. <Don't worry about it.>"
    new "1. <No te preocupes por eso.>"

    # game/chapters/3_day.rpy:1605
    old "1. <............>"
    new "1. <............>"

    # game/chapters/3_day.rpy:1618
    old "2. <Grim... ma—maybe this is a bad idea...>"
    new "2. <Parca... ta—tal vez esto sea una mala idea...>"

    # game/chapters/3_day.rpy:1620
    old "1. <What if I... what if I accidentally...>"
    new "1. <¿Y si yo... y si accidentalmente...?>"

    # game/chapters/3_day.rpy:1622
    old "2. <I'm worried about hurting you...>"
    new "2. <Me preocupa hacerte daño...>"

    # game/chapters/3_day.rpy:1624
    old "3. <I'm scared that if I...>"
    new "3. <Me da miedo que si yo...>"

    # game/chapters/3_day.rpy:1629
    old "1. <Sorry... I'm calm...>"
    new "1. <Perdón... me estoy calmando...>"

    # game/chapters/3_day.rpy:1631
    old "1. <Phew... yeah, I'm fine.>"
    new "1. <Uf... sí, estoy bien.>"

    # game/chapters/3_day.rpy:1634
    old "1. <I trust you.>"
    new "1. <Confío en ti.>"

    # game/chapters/3_day.rpy:1640
    old "1. <Sorry... I can be an anxious person.>"
    new "1. <Perdón... puedo ser una persona ansiosa.>"

    # game/chapters/3_day.rpy:1642
    old "2. <I'm better now. Sorry.>"
    new "2. <Estoy mejor ahora. Perdón.>"

    # game/chapters/3_day.rpy:1647
    old "2. <I... I think something's wrong... this doesn't feel right...>"
    new "2. <Yo... yo creo que algo está mal... esto no se siente bien...>"

    # game/chapters/3_day.rpy:1652
    old "1. <I... I don't know if I can do this...>"
    new "1. <Yo... no sé si puedo hacer esto...>"

    # game/chapters/3_day.rpy:1656
    old "1. <I can... feel that 'pull'... but it scares me...>"
    new "1. <Puedo... sentir ese 'tirón'... pero me asusta...>"

    # game/chapters/3_day.rpy:1662
    old "1. <But... but what if you're tricking me after all...?>"
    new "1. <Pero... pero ¿y si al final me estás engañando...?>"

    # game/chapters/3_day.rpy:1666
    old "1. <What if I'm just... just letting \nmyself be lead into a trap...?>"
    new "1. <¿Y si solo... solo me estoy dejando llevar hacia una trampa...?>"

    # game/chapters/3_day.rpy:1673
    old "1. <I... I'm trying...!>"
    new "1. <Yo... ¡lo estoy intentando...!>"

    # game/chapters/3_day.rpy:1677
    old "1. <No! No, I don't want to die!>"
    new "1. <¡No! ¡No, no quiero morir!>"

    # game/chapters/3_day.rpy:1682
    old "1. <Your hand...>"
    new "1. <Tu mano...>"

    # game/chapters/3_day.rpy:1688
    old "1. <I've got it...>"
    new "1. <La tengo...>"

    # game/chapters/3_day.rpy:1695
    old "1. <Grim... I'm sorry...>"
    new "1. <Parca... lo siento...>"

    # game/chapters/3_day.rpy:1697
    old "2. <My bad...>"
    new "2. <Mi error....>"

    # game/chapters/3_day.rpy:1703
    old "2. <Please... stop...>"
    new "2. <Por favor... detente...>"

    # game/chapters/3_day.rpy:1710
    old "1.<It... it hurts...>"
    new "1. <Me... me duele...>"

    # game/chapters/3_day.rpy:1714
    old "1. <Please, let me go. I can't do this...>"
    new "1. <Por favor, suéltame. No puedo hacer esto...>"

    # game/chapters/3_day.rpy:1717
    old "1. <I... I can't...>"
    new "1. <Yo... no puedo...>"

    # game/chapters/3_day.rpy:1721
    old "1. <Please....>"
    new "1. <Por favor....>"

    # game/chapters/3_day.rpy:1727
    old "1. <Make it stop...>"
    new "1. <Haz que se detenga...>"

    # game/chapters/3_day.rpy:1732
    old "1. <It's really warm...>"
    new "1. <Hace mucho calor...>"

    # game/chapters/3_day.rpy:1735
    old "1. <Like... fire...>"
    new "1. <Como... fuego...>"

    # game/chapters/3_day.rpy:1738
    old "1. <It... burns...>"
    new "1. <Esto... quema...>"

    # game/chapters/3_day.rpy:1750
    old "1. <{i}Fall into the nothingness...{/i}>"
    new "1. <{i}Caer en la nada...{/i}>"

    # game/chapters/3_day.rpy:1772
    old "1. <........>"
    new "1. <........>"

    # game/chapters/3_day.rpy:1781
    old "1. <Strange...>"
    new "1. <Extrañ[letra]...>"

    # game/chapters/3_day.rpy:1783
    old "2. <Kind of... full?>"
    new "2. <¿Un poco... llen[letra]?>"

    # game/chapters/3_day.rpy:1785
    old "3. <Never been better, actually.>"
    new "3. <Nunca he estado mejor, de hecho.>"

    # game/chapters/3_day.rpy:1797
    old "1. <Wait a second—>"
    new "1. <Espera un segundo—>"

    # game/chapters/3_day.rpy:1800
    old "1. <I can hear you! In my head!>"
    new "1. <¡Puedo oírte! ¡En mi cabeza!>"

    # game/chapters/3_day.rpy:1808
    old "1. <It's a little... weird.>"
    new "1. <Es un poco... raro.>"

    # game/chapters/3_day.rpy:1813
    old "2. <It's kinda scary...>"
    new "2. <Es un poco aterrador...>"

    # game/chapters/3_day.rpy:1815
    old "1. <Like, hearing you through my headphones \nwas bad enough...>"
    new "1. <O sea, escucharte por mis audífonos ya era bastante malo...>"

    # game/chapters/3_day.rpy:1825
    old "3. <...Amazing.>"
    new "3. <...Increíble.>"

    # game/chapters/3_day.rpy:1830
    old "1. <No, not your 'talents'. It's amazing this is possible.>"
    new "1. <No, no tus 'talentos'. Es increíble que esto sea posible.>"

    # game/chapters/3_day.rpy:1840
    old "4. <Damn, I can think of a lot of situations \nthis would be fun in.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Maldición, puedo pensar en muchas situaciones donde esto sería divertido.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/3_day.rpy:1849
    old "1. <If we were at school, we could tell each \nother the answers to a test.>"
    new "1. <Si estuviéramos en la escuela, podríamos decirnos las respuestas de un examen.>"

    # game/chapters/3_day.rpy:1856
    old "2. <Absolutely not.>"
    new "2. <Absolutamente no.>"

    # game/chapters/3_day.rpy:1863
    old "1. <Really? You never went to, like... reaper school?>"
    new "1. <¿En serio? ¿Nunca fuiste como a... la escuela de parcas?>"

    # game/chapters/3_day.rpy:1868
    old "1. <Huh. What do all of the reaper kids do, then?>"
    new "1. <¿Eh? ¿Entonces qué hacen todos los niños parca?>"

    # game/chapters/3_day.rpy:1874
    old "1. <But surely you...>"
    new "1. <Pero seguramente tú...>"

    # game/chapters/3_day.rpy:1877
    old "1. <Maybe this is a conversation for another time.>"
    new "1. <Quizás esta es una conversación para otro momento.>"

    # game/chapters/3_day.rpy:1883
    old "2. <If I was trying to sleep, but I couldn't, then I could just talk to you!>"
    new "2. <¡Si estuviera intentando dormir y no pudiera, podría simplemente hablar contigo!>"

    # game/chapters/3_day.rpy:1887
    old "1. <You're being sarcastic, but I bet you really \nwould enjoy that, wouldn't you?>"
    new "1. <Estás siendo sarcástico, pero apuesto a que en verdad te encantaría eso, ¿o no?>"

    # game/chapters/3_day.rpy:1892
    old "1. <'Cause you get to talk to me even more.>"
    new "1. <Porque así puedes hablar conmigo aún más.>"

    # game/chapters/3_day.rpy:1896
    old "1. <Yeah, but we could have bedtime talks.>"
    new "1. <Sí, pero podríamos tener charlas antes de dormir.>"

    # game/chapters/3_day.rpy:1905
    old "1. <Well, they're pointless questions.>"
    new "1. <Bueno, son preguntas sin sentido.>"

    # game/chapters/3_day.rpy:1908
    old "1. <But they're fun.>"
    new "1. <Pero son divertidas.>"

    # game/chapters/3_day.rpy:1912
    old "1. <Alright.>"
    new "1. <Está bien.>"

    # game/chapters/3_day.rpy:1915
    old "1. <What do you think of socks and sandals?>"
    new "1. <¿Qué opinas de las sandalias con medias?>"

    # game/chapters/3_day.rpy:1919
    old "1. <It doesn't.>"
    new "1. <No importa.>"

    # game/chapters/3_day.rpy:1927
    old "1. <On me?>"
    new "1. <¿En mí?>"

    # game/chapters/3_day.rpy:1931
    old "1. <I never said on me.>"
    new "1. <Nunca dije en mí.>"

    # game/chapters/3_day.rpy:1939
    old "1. <The 180 of the century!>"
    new "1. <¡El giro de 180 del siglo!>"

    # game/chapters/3_day.rpy:1948
    old "3. <If you want this conversation to stay PG, I can't say.>"
    new "3. <Si quieres que esta conversación sea apta para todos los públicos, no puedo decirlo.>"

    # game/chapters/3_day.rpy:1956
    old "1. <Have you ever heard anyone talk about that?>"
    new "1. <¿Alguna vez has oído a alguien hablar de eso?>"

    # game/chapters/3_day.rpy:1960
    old "1. <Perhaps, for science, we could try it out one day.>"
    new "1. <Quizás, por la ciencia, podríamos probarlo algún día.>"

    # game/chapters/3_day.rpy:1970
    old "1. <I just enjoy messing with you.>"
    new "1. <Solo disfruto molestarte.>"

    # game/chapters/3_day.rpy:1974
    old "2. <Keep it in mind for next time, huh?>"
    new "2. <Recuérdalo para la próxima, ¿eh?>"

    # game/chapters/3_day.rpy:1981
    old "2. <I just know what I want.>"
    new "2. <Solo sé lo que quiero.>"

    # game/chapters/3_day.rpy:1983
    old "3. <You're fun to tease, sorry.>"
    new "3. <Es divertido molestarte, lo siento.>"

    # game/chapters/3_day.rpy:1989
    old "2. <That's a shame. It sounds fascinating.>"
    new "2. <Qué lástima. Suena fascinante.>"

    # game/chapters/3_day.rpy:1995
    old "1. <So, can you see my aura?>"
    new "1. <Entonces, ¿puedes ver mi aura?>"

    # game/chapters/3_day.rpy:2005
    old "1. <Is that... bad?>"
    new "1. <¿Eso es... malo?>"

    # game/chapters/3_day.rpy:2011
    old "2. <Not exactly what I'd want a pretty \nman to call me, but okay.>"
    new "2. <No es exactamente como quisiera que me llamara un chico bonito, pero está bien.>"

    # game/chapters/3_day.rpy:2021
    old "1. <Hey, why are you pulling that kinda ugly face?>"
    new "1. <Oye, ¿por qué pones esa cara medio fea?>"

    # game/chapters/3_day.rpy:2026
    old "2. <You have some serious RBF right now.>"
    new "2. <Tienes una terrible CPA ahora mismo.>"

    # game/chapters/3_day.rpy:2029
    old "1. <Resting bitch face.>"
    new "1. <Cara de pocos amigos.>"

    # game/chapters/3_day.rpy:2036
    old "3. <You look kinda... built up right now.>"
    new "3. <Te ves un poco... estreñido ahora mismo.>"

    # game/chapters/3_day.rpy:2041
    old "1. <They have pills to help you clear out \nthe ol' pipes, you know?>"
    new "1. <Hay pastillas para ayudarte a destapar las tuberías, ¿sabes?>"

    # game/chapters/3_day.rpy:2050
    old "1. <Fine. But what's with the face?>"
    new "1. <Bueno, está bien. Pero ¿qué pasa con esa cara?>"

    # game/chapters/3_day.rpy:2059
    old "1. <What's wrong with bright things, anyway?>"
    new "1. <¿Y qué tiene de malo lo brillante, de todas formas?>"

    # game/chapters/3_day.rpy:2061
    old "2. <Right, you don't like the light, do you?>"
    new "2. <Cierto, no te gusta la luz, ¿verdad?>"

    # game/chapters/3_day.rpy:2064
    old "1. <Do you sparkle in the sunlight like that \nvampire from that movie?>"
    new "1. <¿Brillas con el sol como ese vampiro de esa película?>"

    # game/chapters/3_day.rpy:2066
    old "2. <Does it actually hurt you?>"
    new "2. <¿En serio te hace daño?>"

    # game/chapters/3_day.rpy:2085
    old "1. <Be careful not to damage your eyes, then.>"
    new "1. <Entonces ten cuidado de no dañar tus ojos.>"

    # game/chapters/3_day.rpy:2087
    old "1. <Don't look too close, alright?>"
    new "1. <No mires tan de cerca, ¿okey?>"

    # game/chapters/3_day.rpy:2092
    old "1. <But it hurts you. That makes me feel kinda bad.>"
    new "1. <Pero te duele. Eso me hace sentir un poco mal.>"

    # game/chapters/3_day.rpy:2097
    old "2. <Er... maybe you shouldn't do this, then.>"
    new "2. <Eh... quizás no deberías hacer esto, entonces.>"

    # game/chapters/3_day.rpy:2102
    old "1. <But... doesn't it hurt?>"
    new "1. <Pero... ¿no duele?>"

    # game/chapters/3_day.rpy:2110
    old "1. <So... are souls supposed to be that bright?>"
    new "1. <Entonces... ¿se supone que las almas son así de brillantes?>"

    # game/chapters/3_day.rpy:2126
    old "1. <Maybe you should try smelling it.>"
    new "1. <Quizás deberías intentar olerla.>"

    # game/chapters/3_day.rpy:2129
    old "1. <You did say you were going to do that, right?>"
    new "1. <Dijiste que ibas a hacer eso, ¿verdad?>"

    # game/chapters/3_day.rpy:2135
    old "1. <That honestly sounds like a good thing.>"
    new "1. <Sinceramente, eso suena bien.>"

    # game/chapters/3_day.rpy:2137
    old "2. <Phew. I was worried it would smell like \nthe eggs I ate last night.>"
    new "2. <Uf. Me preocupaba que oliera a los huevos que comí anoche.>"

    # game/chapters/3_day.rpy:2157
    old "2. <Looking into my eyes is that distracting, huh...>"
    new "2. <Mirarme a los ojos distrae tanto, ¿eh...? >"

    # game/chapters/3_day.rpy:2164
    old "1. <What is it now?>"
    new "1. <¿Qué es ahora?>"

    # game/chapters/3_day.rpy:2172
    old "2. <Heeelloooo?>"
    new "2. <¿Holaaaa?>"

    # game/chapters/3_day.rpy:2196
    old "2. <Give me the diagnosis, doc.>"
    new "2. <Dame el diagnóstico, doc.>"

    # game/chapters/3_day.rpy:2203
    old "2. <Are you gonna tell me what's wrong?>"
    new "2. <¿Vas a decirme qué está mal?>"

    # game/chapters/3_day.rpy:2215
    old "1. <What? No, start explaining.>"
    new "1. <¿Qué? No, empieza a explicarlo.>"

    # game/chapters/3_day.rpy:2221
    old "1. <So bossy...>"
    new "1. <Tan mandón...>"

    # game/chapters/3_day.rpy:2224
    old "1. <I wouldn't say that... but fine.>"
    new "1. <No diría eso... pero está bien.>"

    # game/chapters/3_day.rpy:2226
    old "2. <I do kind of enjoy it. Alright.>"
    new "2. <La verdad lo disfruto un poco. Está bien.>"

    # game/chapters/3_day.rpy:2229
    old "2. <You could say please, you know.>"
    new "2. <Podrías decir por favor, ¿sabes?>"

    # game/chapters/3_day.rpy:2246
    old "2. <That's kinda out of nowhere...>"
    new "2. <Eso salió un poco de la nada...>"

    # game/chapters/3_day.rpy:2248
    old "3. <I like the positivity.>"
    new "3. <Me gusta esa positividad.>"

    # game/chapters/3_day.rpy:2255
    old "1. <Maybe you're not the best of the best, then.>"
    new "1. <Entonces quizás no eres el mejor de los mejores.>"

    # game/chapters/3_day.rpy:2263
    old "2. <Ouch...>"
    new "2. <Ouch...>"

    # game/chapters/3_day.rpy:2268
    old "1. <Pulses?>"
    new "1. <¿Pulsa?>"

    # game/chapters/3_day.rpy:2279
    old "1. <And now?>"
    new "1. <¿Y ahora?>"

    # game/chapters/3_day.rpy:2286
    old "1. <Maybe it's like a shield!>"
    new "1. <¡Quizás es como un escudo!>"

    # game/chapters/3_day.rpy:2288
    old "2. <Maybe something is protecting me?>"
    new "2. <¿Quizás algo me está protegiendo?>"

    # game/chapters/3_day.rpy:2295
    old "1. <Well, uh...>"
    new "1. <Bueno, eh...>"

    # game/chapters/3_day.rpy:2297
    old "2. <That would be...>"
    new "2. <Eso sería...>"

    # game/chapters/3_day.rpy:2306
    old "1. <Yeah, you won't harm me this time.>"
    new "1. <Sí, no me harás daño esta vez.>"

    # game/chapters/3_day.rpy:2309
    old "1. <But you're still after my soul, right?>"
    new "1. <Pero aún vas tras mi alma, ¿verdad?>"

    # game/chapters/3_day.rpy:2316
    old "1. <And I believe you. For now.>"
    new "1. <Y te creo. Por ahora.>"

    # game/chapters/3_day.rpy:2318
    old "2. <I'm not quite sure I believe you... \nbut for now, let's pretend I do.>"
    new "2. <No sé si te creo... pero por ahora, finjamos que lo hago.>"

    # game/chapters/3_day.rpy:2321
    old "1. <So, no answers?>"
    new "1. <Entonces, ¿sin respuestas?>"

    # game/chapters/3_day.rpy:2326
    old "1. <No, but I can rush you.>"
    new "1. <No, pero puedo apurarte.>"

    # game/chapters/3_day.rpy:2335
    old "1. <Other issue?>"
    new "1. <¿Otro problema?>"

    # game/chapters/3_day.rpy:2343
    old "1. <Why can't I ask questions?>"
    new "1. <¿Por qué no puedo hacer preguntas?>"

    # game/chapters/3_day.rpy:2356
    old "1. <So, you'll tell me once you know more?>"
    new "1. <Entonces, ¿me lo dirás cuando sepas más?>"

    # game/chapters/3_day.rpy:2361
    old "1. <I'd rather not.>"
    new "1. <Preferiría que no.>"

    # game/chapters/3_day.rpy:2364
    old "1. <That's not fair.>"
    new "1. <Eso no es justo.>"

    # game/chapters/3_day.rpy:2368
    old "1. <—Thing fair in life is death.>"
    new "1. <—Justo en la vida es la muerte.>"

    # game/chapters/3_day.rpy:2373
    old "2. <Do I really have to beg...?>"
    new "2. <¿De verdad tengo que suplicar...?>"

    # game/chapters/3_day.rpy:2377
    old "1. <Maybe if you begged me first.>"
    new "1. <Quizás si me lo suplicaras primero.>"

    # game/chapters/3_day.rpy:2382
    old "3. <Pwetty pwease?> {font=gui/starthings.ttf}a{/font}"
    new "3. <¿Pooo fiii?> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/3_day.rpy:2388
    old "1. <Lwike what?>"
    new "1. <¿Kumo khe?>"

    # game/chapters/3_day.rpy:2393
    old "1. <Pwetty pwease?>"
    new "1. <¿Pooo fiii?>"

    # game/chapters/3_day.rpy:2398
    old "1. <Pwetty....>"
    new "1. <¿Pooo....>"

    # game/chapters/3_day.rpy:2401
    old "1. <Pwease...?>"
    new "1. <Fiii...?>"

    # game/chapters/3_day.rpy:2407
    old "1. <You're no fun, Grim.>"
    new "1. <No eres divertido, Parca.>"

    # game/chapters/3_day.rpy:2413
    old "1. <Now? So suddenly?>"
    new "1. <¿Ahora? ¿Así de repente?>"

    # game/chapters/3_day.rpy:2418
    old "1. <...Take care of yourself, okay?>"
    new "1. <...Cuídate, ¿okey?>"

    # game/chapters/3_day.rpy:2420
    old "2. <Do you think you could perhaps be a workaholic?>"
    new "2. <¿Crees que podrías ser un adicto al trabajo?>"

    # game/chapters/3_day.rpy:2430
    old "1. <The... responsibility of being the Grim Reaper?>"
    new "1. <¿La... responsabilidad de ser la Parca?>"

    # game/chapters/3_day.rpy:2435
    old "1. <I still can't believe it...>"
    new "1. <Aún no puedo creerlo...>"

    # game/chapters/3_day.rpy:2438
    old "1. <I feel like I should be worried for my soul, but...>"
    new "1. <Siento que debería preocuparme por mi alma, pero...>"

    # game/chapters/3_day.rpy:2441
    old "1. <You're not very threatening.>"
    new "1. <No eres muy amenazante.>"

    # game/chapters/3_day.rpy:2451
    old "1. <Then show it to me.>"
    new "1. <Entonces muéstramelo.>"

    # game/chapters/3_day.rpy:2455
    old "1. <Then I don't believe you.>"
    new "1. <Entonces no te creo.>"

    # game/chapters/3_day.rpy:2460
    old "1. <So you've said.>"
    new "1. <Eso ya lo dijiste.>"

    # game/chapters/3_day.rpy:2462
    old "2. <If you say so.>"
    new "2. <Si tú lo dices.>"

    # game/chapters/3_day.rpy:2464
    old "3. <Everyone lies at some point.>"
    new "3. <Todos mienten en algún momento.>"

    # game/chapters/3_day.rpy:2466
    old "4. <That's exactly what a liar would say.>"
    new "4. <Eso es exactamente lo que diría un mentiroso.>"

    # game/chapters/3_day.rpy:2473
    old "1. <You told me I had to!>"
    new "1. <¡Tú me dijiste que tenía que hacerlo!>"

    # game/chapters/3_day.rpy:2480
    old "2. <Wha... what...>"
    new "2. <¿Qué... qué...?>"

    # game/chapters/3_day.rpy:2483
    old "1. <I absolutely did not stare, and never have.>"
    new "1. <Definitivamente no miré, y nunca lo he hecho.>"

    # game/chapters/3_day.rpy:2490
    old "1. <I'm sure you have a flaw somewhere \non that body of yours.>"
    new "1. <Seguro que tienes algún defecto en ese cuerpo tuyo.>"

    # game/chapters/3_day.rpy:2495
    old "1. <Everyone has flaws.>"
    new "1. <Todos tienen defectos.>"

    # game/chapters/3_day.rpy:2500
    old "1. <That is... very evident, Mister Grim Reaper.>"
    new "1. <Eso es... muy evidente, Señor Parca.>"

    # game/chapters/3_day.rpy:2509
    old "1. <You {i}actually{/i} being the Grim Reaper \ndoesn't mean you're not cringe.>"
    new "1. <Que seas {i}de verdad{/i} la Parca no significa que no des cringe.>"

    # game/chapters/3_day.rpy:2511
    old "2. <That'll never stop.>"
    new "2. <Eso nunca va a parar.>"

    # game/chapters/3_day.rpy:2515
    old "2. <And what if I said yes?>"
    new "2. <¿Y qué pasaría si dijera que sí?>"

    # game/chapters/3_day.rpy:2519
    old "1. <And... what if I said I didn't mind that?>"
    new "1. <Y... ¿qué pasaría si dijera que no me importa?>"

    # game/chapters/3_day.rpy:2525
    old "1. <Well, as long as that comes after me being \nwrapped around your...>"
    new "1. <Bueno, siempre y cuando eso pase después de que yo esté envuelt[letra] alrededor de tu...>"

    # game/chapters/3_day.rpy:2527
    old "1. <Your finger, that is.>"
    new "1. <Tu dedo, claro.>"

    # game/chapters/3_day.rpy:2534
    old "1. <We shall see.>"
    new "1. <Ya veremos.>"

    # game/chapters/3_day.rpy:2537
    old "2. <If anything, I'd say I have you wrapped around \nMY finger.>"
    new "2. <Si acaso, diría que yo te tengo envuelto alrededor de MI dedo.>"

    # game/chapters/3_day.rpy:2541
    old "1. <You're like a little puppy that I'm \nleading around by the collar.>"
    new "1. <Eres como un cachorrito al que llevo por ahí del collar.>"

    # game/chapters/3_day.rpy:2548
    old "1. <I bet you would.>"
    new "1. <Apuesto a que sí.>"

    # game/chapters/3_day.rpy:2551
    old "3. <You told me to focus on the pull! {i}You{/i} are the pull!>"
    new "3. <¡Me dijiste que me concentrara en el tirón! ¡{i}Tú{/i} eres el tirón!>"

    # game/chapters/3_day.rpy:2553
    old "1. <You literally told me to watch you.>"
    new "1. <Literalmente me dijiste que te mirara.>"

    # game/chapters/3_day.rpy:2557
    old "1. <Of course I focused on you!>"
    new "1. <¡Claro que me concentré en ti!>"

    # game/chapters/3_day.rpy:2561
    old "1. <Oh, I see how it is.>"
    new "1. <Ah, ya veo cómo va la cosa.>"

    # game/chapters/3_day.rpy:2564
    old "1. <You act all tough, but the thought of being watched so intently makes you shy, doesn't it?>"
    new "1. <Te haces el rudo, pero la idea de que te miren con tanta atención te da vergüenza, ¿verdad?>"

    # game/chapters/3_day.rpy:2569
    old "1. <It does!>"
    new "1. <¡Sí te da!>"

    # game/chapters/3_day.rpy:2577
    old "1. <Night night, Mister Grim Reaper.>"
    new "1. <Buenas noches, Señor Parca.>"

    # game/chapters/3_day.rpy:2601
    old "1. <I am assuming I can't tell people about you?>"
    new "1. <Supongo que no puedo contarle a la gente sobre ti, ¿verdad?>"

    # game/chapters/3_day.rpy:2607
    old "1. <Like anyone at all?>"
    new "1. <¿A nadie en absoluto?>"

    # game/chapters/3_day.rpy:2611
    old "1. <Of course not.>"
    new "1. <Por supuesto que no.>"

    # game/chapters/3_day.rpy:2615
    old "2. <And if I said yes?>"
    new "2. <¿Y si dijera que sí?>"

    # game/chapters/3_day.rpy:2619
    old "1. <It shouldn't matter to you, right?>"
    new "1. <No debería importarte, ¿verdad?>"

    # game/chapters/3_day.rpy:2622
    old "1. <You're after my soul.>"
    new "1. <Estás tras mi alma.>"

    # game/chapters/3_day.rpy:2626
    old "3. <Maybe I just like pushing your buttons?>"
    new "3. <¿Quizás solo me gusta provocarte?>"

    # game/chapters/3_day.rpy:2630
    old "1. <Thank you :D>"
    new "1. <Gracias :D>"

    # game/chapters/3_day.rpy:2634
    old "1. <btw I can't believe you changed your pfp to that.>"
    new "1. <Por cierto, no puedo creer que cambiaras tu foto de perfil por eso.>"

    # game/chapters/3_day.rpy:2638
    old "1. <You and your edgy teenager-like ass.>"
    new "1. <Tú y tu actitud de adolescente edgy.>"

    # game/chapters/3_day.rpy:2646
    old "1. <Hahahahah.>"
    new "1. <Jajajajaja.>"

    # game/chapters/3_day.rpy:2648
    old "2. <It definitely did, lmao.>"
    new "2. <Definitivamente lo transmitía, jajaja.>"

    # game/chapters/3_day.rpy:2662
    old "1. <Would've made life easier for you, though...>"
    new "1. <Habría hecho tu vida más fácil, sin embargo...>"

    # game/chapters/3_day.rpy:2668
    old "1. <Nice to know you care.>"
    new "1. <Qué bueno saber que te importa.>"

    # game/chapters/3_day.rpy:2674
    old "1. <Such heartwarming support. Thank you.>"
    new "1. <Qué apoyo tan conmovedor. Gracias.>"

    # game/chapters/3_day.rpy:2677
    old "1. <I suppose I'll take it to heart this one time.>"
    new "1. <Supongo que lo guardaré en mi corazón por esta vez.>"

    # game/chapters/3_day.rpy:2682
    old "1. <My heart?>"
    new "1. <¿Mi corazón?>"

    # game/chapters/3_day.rpy:2686
    old "1. <That's a bold claim!>"
    new "1. <¡Qué afirmación tan atrevida!>"

