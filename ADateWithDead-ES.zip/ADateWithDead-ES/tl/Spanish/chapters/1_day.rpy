# TODO: Translation updated at 2026-10-15 18:36

# game/chapters/1_day.rpy:36
translate Spanish day1_start_c614cc05:

    # GR "Foolish Mortal, You Shall Evade Me No More!"
    GR "¡Neci[letra] Mortal, No Volverás A Escaparte De Mí!"

# game/chapters/1_day.rpy:37
translate Spanish day1_start_1b087129:

    # GR "I Have Had Enough Of You Fiddling Around In Your Room And Ignoring Me."
    GR "¡Ya He Tenido Suficiente De Que Andes Perdiendo El Tiempo En Tu Habitación E Ignorándome!"

# game/chapters/1_day.rpy:38
translate Spanish day1_start_91ccecbe:

    # GR "I Have Come To Reap Your Soul."
    GR "He Venido A Segar Tu Alma."

# game/chapters/1_day.rpy:39
translate Spanish day1_start_67bdcd6b:

    # GR "That Is Far More Important."
    GR "Eso Es Mucho Más Importante."

# game/chapters/1_day.rpy:40
translate Spanish day1_start_4447c314:

    # GR "Hand It Over Willingly, For I Am Not Here To Play Games."
    GR "Entrégala Voluntariamente, Porque No He Venido A Jugar."

# game/chapters/1_day.rpy:41
translate Spanish day1_start_55656cbf:

    # GR "Answer Me At Once!"
    GR "¡Respóndeme Ahora Mismo!"

# game/chapters/1_day.rpy:42
translate Spanish day1_start_4ec1e4b0:

    # GR "...Hello?"
    GR "...¿Hola?"

# game/chapters/1_day.rpy:43
translate Spanish day1_start_aae5c74e:

    # GR "I See You Wish To Ignore My Demands! Foolish."
    GR "¡Veo Que Deseas Ignorar Mis Exigencias! Neci[letra]."

# game/chapters/1_day.rpy:44
translate Spanish day1_start_12023737:

    # GR "Incredibly Foolish."
    GR "Increíblemente Neci[letra]."

# game/chapters/1_day.rpy:45
translate Spanish day1_start_a2195401:

    # GR "Please Respond."
    GR "Por Favor, Responde."

# game/chapters/1_day.rpy:46
translate Spanish day1_start_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpy:47
translate Spanish day1_start_c4694050:

    # GR "Does It Not Work After All?"
    GR "¿Después De Todo No Funciona?"

# game/chapters/1_day.rpy:48
translate Spanish day1_start_d160e261:

    # GR "Well, This Is Quite Embarrassing..."
    GR "Bueno, Esto Es Bastante Vergonzoso..."

# game/chapters/1_day.rpy:49
translate Spanish day1_start_9324da6b:

    # GR "Testing. Testing 123. Hello? Testing."
    GR "Probando. Probando 123. ¿Hola? Probando."

# game/chapters/1_day.rpy:50
translate Spanish day1_start_6b7fe2f9:

    # GR "Fuck Me."
    GR "Que Me Jodan."

# game/chapters/1_day.rpy:53
translate Spanish day1_start_2d44b69f:

    # player "Is that an offer?"
    player "¿Eso es una oferta?"

# game/chapters/1_day.rpy:54
translate Spanish day1_start_2463ef52:

    # GR "An Offer? An Offer For What?"
    GR "¿Una Oferta? ¿Una Oferta Para Qué?"

# game/chapters/1_day.rpy:57
translate Spanish day1_start_bcd19cdc:

    # player "Uh... if you don't get it, don't worry about it."
    player "Eh... si no lo captas, no te preocupes."

# game/chapters/1_day.rpy:58
translate Spanish day1_start_a46c17da:

    # GR "Tell Me At Once!"
    GR "¡Dímelo Ahora Mismo!"

# game/chapters/1_day.rpy:61
translate Spanish day1_start_817aed81:

    # player "An offer for what you said—"
    player "Una oferta por lo que dijiste—"

# game/chapters/1_day.rpy:64
translate Spanish day1_start_4e9f1c53:

    # player "You know what, nevermind."
    player "¿Sabes qué? Olvídalo."

# game/chapters/1_day.rpy:65
translate Spanish day1_start_0013230d:

    # GR "No, That Is Not How This Works."
    GR "No, Así No Es Como Funciona Esto."

# game/chapters/1_day.rpy:66
translate Spanish day1_start_eb761f1b:

    # GR "You Cannot Tease Something Then Not Explain What It Means."
    GR "No Puedes Insinuar Algo Y Luego No Explicar Lo Que Significa."

# game/chapters/1_day.rpy:70
translate Spanish day1_start_9a54bb21:

    # player "Or what?"
    player "¿O qué?"

# game/chapters/1_day.rpy:71
translate Spanish day1_start_ce076eea:

    # GR "Or... Or..."
    GR "O... O..."

# game/chapters/1_day.rpy:72
translate Spanish day1_start_af2cca0b:

    # GR "Or I Shall Take Your Soul At Once!"
    GR "¡O Te Arrancaré El Alma Ahora Mismo!"

# game/chapters/1_day.rpy:75
translate Spanish day1_start_57f0fb30:

    # player "Isn't that what you threatened me with anyway?"
    player "¿No es con eso con lo que me amenazaste de todas formas?"

# game/chapters/1_day.rpy:79
translate Spanish day1_start_9629808c:

    # player "What is this app...?"
    player "¿Qué es esta aplicación...?"

# game/chapters/1_day.rpy:80
translate Spanish day1_start_2e352636:

    # GR "A Means For Discussing Our Business."
    GR "Un Medio Para Discutir Nuestro Asunto."

# game/chapters/1_day.rpy:82
translate Spanish day1_start_5010927b:

    # GR "I Created It Myself."
    GR "La Creé Yo Mismo."

# game/chapters/1_day.rpy:83
translate Spanish day1_start_d497d532:

    # GR "Appreciate The Lengths I Had To Go To For You."
    GR "Aprecia El Esfuerzo Que Tuve Que Hacer Por Ti."

# game/chapters/1_day.rpy:86
translate Spanish day1_start_2aa27b3b:

    # player "For... me?"
    player "¿Por... mí?"

# game/chapters/1_day.rpy:89
translate Spanish day1_start_ac33080e:

    # player "Kinda creepy, ngl..."
    player "Un poco espeluznante, no lo voy a negar..."

# game/chapters/1_day.rpy:90
translate Spanish day1_start_708d8bf6:

    # GR "Creepy? It Is Not Creepy."
    GR "¿Espeluznante? No Es Espeluznante."

# game/chapters/1_day.rpy:91
translate Spanish day1_start_70c5a546:

    # GR "Since When Is Going To Some Degree Of Effort Creepy?"
    GR "¿Desde Cuándo Esforzarse Un Poco Es Espeluznante?"

# game/chapters/1_day.rpy:94
translate Spanish day1_start_542c96df:

    # player "Since you installed it on my computer illegally."
    player "Desde que la instalaste ilegalmente en mi computadora."

# game/chapters/1_day.rpy:95
translate Spanish day1_start_ec573932:

    # GR "That Is Of Little Consequence."
    GR "Eso Es Irrelevante."

# game/chapters/1_day.rpy:96
translate Spanish day1_start_21733e74:

    # GR "Mortal Laws Mean Little To Me."
    GR "Las Leyes Mortales Significan Poco Para Mí."

# game/chapters/1_day.rpy:100
translate Spanish day1_start_9ebcae9c:

    # player "Well, I guess that does sound like a lot of effort."
    player "Bueno, supongo que eso sí parece mucho esfuerzo."

# game/chapters/1_day.rpy:103
translate Spanish day1_start_01a2933e:

    # player "Nice job."
    player "Buen trabajo."

# game/chapters/1_day.rpy:104
translate Spanish day1_start_2c51ffa0:

    # GR "Oh."
    GR "Oh."

# game/chapters/1_day.rpy:105
translate Spanish day1_start_5e5a7ee8:

    # GR "Thanks."
    GR "Gracias."

# game/chapters/1_day.rpy:106
translate Spanish day1_start_1dcaa4de:

    # GR "I Didn't Think You Would Appreciate It, Honestly."
    GR "No Pensé Que Lo Apreciarías, Honestamente."

# game/chapters/1_day.rpy:109
translate Spanish day1_start_e2716c3b:

    # player "But still..."
    player "Pero aun así..."

# game/chapters/1_day.rpy:114
translate Spanish day1_start_6d768dfd:

    # player "Uh... hello to you, too."
    player "Eh... hola a ti también."

# game/chapters/1_day.rpy:117
translate Spanish day1_start_63c111a9:

    # player "That was one hell of an introduction."
    player "Vaya presentación."

# game/chapters/1_day.rpy:118
translate Spanish day1_start_5125efe5:

    # GR "About Time You Made Your Way Here. You Have Kept Me Waiting Long Enough."
    GR "Ya Era Hora De Que Llegaras Aquí. Me Has Hecho Esperar Demasiado."

# game/chapters/1_day.rpy:121
translate Spanish day1_start_f6c68f17:

    # player "Er, what?"
    player "Eh, ¿qué?"

# game/chapters/1_day.rpy:124
translate Spanish day1_start_4a577e07:

    # player "I don't even know you."
    player "Ni siquiera te conozco."

# game/chapters/1_day.rpy:125
translate Spanish day1_start_c9369ce4:

    # GR "Are My Words Not Simple Enough For You?"
    GR "¿Mis Palabras No Te Parecen Lo Suficientemente Sencillas?"

# game/chapters/1_day.rpy:126
translate Spanish day1_start_0c2fdd0f:

    # GR "I Have Waited Far Too Long. Far Too Long."
    GR "He Esperado Muchísimo Tiempo. Muchísimo."

# game/chapters/1_day.rpy:129
translate Spanish day1_start_917ca64f:

    # player "Right...."
    player "Cierto...."

# game/chapters/1_day.rpy:130
translate Spanish day1_start_91d6ace1:

    # GR "Yes, It Is Right."
    GR "Sí, Es Correcto."

# game/chapters/1_day.rpy:131
translate Spanish day1_start_a2648958:

    # GR "Everything I Say Is Always Correct."
    GR "Todo Lo Que Digo Siempre Es Correcto."

# game/chapters/1_day.rpy:135
translate Spanish day1_start_a40a7902:

    # player "I mean, it was like... five minutes."
    player "Quiero decir, fue como... cinco minutos."

# game/chapters/1_day.rpy:136
translate Spanish day1_start_7c2f90ac:

    # GR "Five Minutes Too Long!"
    GR "¡Cinco Minutos Es Demasiado!"

# game/chapters/1_day.rpy:137
translate Spanish day1_start_557adcae:

    # GR "I Am A Busy Man. A Very Busy Man."
    GR "Soy Un Hombre Ocupado. Un Hombre Muy Ocupado."

# game/chapters/1_day.rpy:140
translate Spanish day1_start_e03da0f5:

    # player "Well, don't let me take up your precious time!"
    player "Bueno, ¡no dejes que te quite tu precioso tiempo!"

# game/chapters/1_day.rpy:143
translate Spanish day1_start_b7d57d74:

    # player "Off you go!"
    player "¡Vete!"

# game/chapters/1_day.rpy:144
translate Spanish day1_start_230dec51:

    # GR "...."
    GR "...."

# game/chapters/1_day.rpy:145
translate Spanish day1_start_ff242f17:

    # GR "No."
    GR "No."

# game/chapters/1_day.rpy:146
translate Spanish day1_start_38aea315:

    # GR "I Cannot Go Until My Job Here Is Fulfilled."
    GR "No Puedo Irme Hasta Que Mi Trabajo Aquí Esté Terminado."

# game/chapters/1_day.rpy:150
translate Spanish day1_start_0a0f3fd0:

    # player "You shouldn't have blown up my notifications."
    player "No deberías haber reventado mis notificaciones."

# game/chapters/1_day.rpy:153
translate Spanish day1_start_aaaafc64:

    # player "That makes me want to ignore you."
    player "Eso me da ganas de ignorarte."

# game/chapters/1_day.rpy:154
translate Spanish day1_start_fb3dcf92:

    # GR "Then You Should Have Replied Faster."
    GR "Entonces Deberías Haber Respondido Más Rápido."

# game/chapters/1_day.rpy:157
translate Spanish day1_start_dde0acba:

    # player "Too bad. You were too eager."
    player "Qué pena. Estabas demasiado ansioso."

# game/chapters/1_day.rpy:158
translate Spanish day1_start_71abf724:

    # GR "That Makes No Sense."
    GR "Eso No Tiene Sentido."

# game/chapters/1_day.rpy:159
translate Spanish day1_start_33d94d44:

    # GR "Why Are Mortals So Confusing?"
    GR "¿Por Qué Son Tan Confusos Los Mortales?"

# game/chapters/1_day.rpy:160
translate Spanish day1_start_bad0eec8:

    # GR "You Play These Games I Do Not Understand."
    GR "Juegas A Esos Juegos Que Yo No Entiendo."

# game/chapters/1_day.rpy:163
translate Spanish day1_start_123e2a10:

    # player "There's unspoken rules to texting people."
    player "Hay reglas no escritas para enviarle mensajes a la gente."

# game/chapters/1_day.rpy:166
translate Spanish day1_start_21c18686:

    # player "Or in this case, messaging them through suspicious apps."
    player "O, en este caso, para enviarles mensajes a través de apps sospechosas."

# game/chapters/1_day.rpy:167
translate Spanish day1_start_4d770ae6:

    # GR "Well, Can You Please Speak Them?"
    GR "Bueno, ¿Puedes Decírmelas, Por Favor?"

# game/chapters/1_day.rpy:170
translate Spanish day1_start_93666768:

    # player "Nope."
    player "Nop."

# game/chapters/1_day.rpy:171
translate Spanish day1_start_9b1f8a4f:

    # GR "You Are Being Unfair."
    GR "Estás Siendo Injust[letra]."

# game/chapters/1_day.rpy:173
translate Spanish day1_start_e4a6b9d8:

    # player "Don't spam and don't get mad if you don't get an instant response, mostly."
    player "Principalmente, no hagas spam y no te enojes si no obtienes una respuesta instantánea."

# game/chapters/1_day.rpy:174
translate Spanish day1_start_2c0ce039:

    # GR "I'm Going To Choose To Ignore Those Foolish Rules."
    GR "Elijo Ignorar Esas Reglas Tontas."

# game/chapters/1_day.rpy:175
translate Spanish day1_start_38c63bb6:

    # GR "Whoever Made Them Should Be Ashamed."
    GR "Quien Las Haya Creado Debería Sentirse Avergonzado."

# game/chapters/1_day.rpy:178
translate Spanish day1_start_8f651b1e:

    # player "Sure... anyway..."
    player "Claro... en fin..."

# game/chapters/1_day.rpy:188
translate Spanish reinstall_1_6b99a6f0:

    # GR "Now That Is Just Plain Rude."
    GR "Eso Ya Es Simplemente Grosero."

# game/chapters/1_day.rpy:189
translate Spanish reinstall_1_740afe40:

    # GR "The Utter Disrespect... Mortals These Days..."
    GR "El Desprecio Absoluto... Los Mortales Hoy En Día..."

# game/chapters/1_day.rpy:198
translate Spanish reinstall_2_7928190e:

    # GR "Wait!"
    GR "¡Espera!"

# game/chapters/1_day.rpy:199
translate Spanish reinstall_2_28c74d24:

    # GR "Do Not Delete It Any More! You Will Cause Serious Damage. And I Will Also Be Very Sad..."
    GR "¡No Lo Borres Más! Causarás Daños Graves. Y Yo También Estaré Muy Triste..."

# game/chapters/1_day.rpy:208
translate Spanish reinstall_3_049884f8:

    # GR "Please. Stop Deleting My App!"
    GR "Por Favor. ¡Deja De Borrar Mi App!"

# game/chapters/1_day.rpy:211
translate Spanish reinstall_3_69375c1f:

    # player "Your order total is $641.30."
    player "El total de su pedido es $641.30."

# game/chapters/1_day.rpy:214
translate Spanish reinstall_3_ca2cb026:

    # player "To finalize your order, please hit 1."
    player "Para finalizar su pedido, por favor presione 1."

# game/chapters/1_day.rpy:217
translate Spanish reinstall_3_4668d49e:

    # player "To cancel your order, please hit 2."
    player "Para cancelar su pedido, por favor presione 2."

# game/chapters/1_day.rpy:218
translate Spanish reinstall_3_7360268c:

    # GR "What... I Ordered No Such Thing!"
    GR "¿Qué...? ¡No He Pedido Tal Cosa!"

# game/chapters/1_day.rpy:219
translate Spanish reinstall_3_65ff3087:

    # GR "2. 2!"
    GR "¡2. 2!"

# game/chapters/1_day.rpy:222
translate Spanish reinstall_3_9b731788:

    # player "Thank you for your purchase. Your order is now being finalized."
    player "Gracias por su compra. Su pedido se está finalizando."

# game/chapters/1_day.rpy:223
translate Spanish reinstall_3_e93f5105:

    # GR "No! I Have Not Clicked That Response, You Stupid Machine!"
    GR "¡No! ¡No He Pulsado Esa Respuesta, Estúpida Máquina!"

# game/chapters/1_day.rpy:226
translate Spanish reinstall_3_f6b157a9:

    # player "To order again, please select YES."
    player "Para realizar un nuevo pedido, por favor seleccione SÍ."

# game/chapters/1_day.rpy:227
translate Spanish reinstall_3_978e41a1:

    # GR "Why Is There Only One Option?!"
    GR "¡¿Por Qué Solo Hay Una Opción?!"

# game/chapters/1_day.rpy:228
translate Spanish reinstall_3_5adf8d3a:

    # GR "No. No, I Do Not Want To Order Again!"
    GR "¡No. No Quiero Pedir De Nuevo!"

# game/chapters/1_day.rpy:231
translate Spanish reinstall_3_f6b157a9_1:

    # player "To order again, please select YES."
    player "Para realizar un nuevo pedido, por favor seleccione SÍ."

# game/chapters/1_day.rpy:232
translate Spanish reinstall_3_c8467448:

    # GR "No, Thank You. I Refuse."
    GR "No, Gracias. Me Niego."

# game/chapters/1_day.rpy:235
translate Spanish reinstall_3_f6b157a9_2:

    # player "To order again, please select YES."
    player "Para realizar un nuevo pedido, por favor seleccione SÍ."

# game/chapters/1_day.rpy:236
translate Spanish reinstall_3_9937af4f:

    # GR "Yes."
    GR "Sí."

# game/chapters/1_day.rpy:239
translate Spanish reinstall_3_48bb00db:

    # player "Thank you for your order. Your account has been charged a total of $3491.60."
    player "Gracias por su pedido. Se ha realizado un cargo de $3491.60 a su cuenta."

# game/chapters/1_day.rpy:240
translate Spanish reinstall_3_dee96f95:

    # GR "Holy Fuck."
    GR "Maldita Sea."

# game/chapters/1_day.rpy:241
translate Spanish reinstall_3_ff242f17:

    # GR "No."
    GR "No."

# game/chapters/1_day.rpy:242
translate Spanish reinstall_3_64607f72:

    # GR "Please, No!"
    GR "¡Por Favor, No!"

# game/chapters/1_day.rpy:245
translate Spanish reinstall_3_778b7e57:

    # player "Idiot."
    player "Idiota."

# game/chapters/1_day.rpy:247
translate Spanish reinstall_3_60078eb9:

    # player "You're a moron."
    player "Eres un imbécil."

# game/chapters/1_day.rpy:249
translate Spanish reinstall_3_241afdf4:

    # GR "Mortal!"
    GR "¡Mortal!"

# game/chapters/1_day.rpy:250
translate Spanish reinstall_3_11d483d2:

    # GR "How Dare You Fool Me In Such A Manner... How Unbecoming Of One Such As Me..."
    GR "Cómo Te Atreves A Engañarme De Tal Manera... Qué Poco Propio De Alguien Como Yo..."

# game/chapters/1_day.rpy:254
translate Spanish reinstall_3_2679f73b:

    # player "It's not my fault you're so easily fooled."
    player "No es mi culpa que te dejes engañar tan fácilmente."

# game/chapters/1_day.rpy:260
translate Spanish day1_afterfirstchoice_ad41d889:

    # player "Seriously, is this a virus or something...?"
    player "En serio, ¿esto es un virus o algo...?"

# game/chapters/1_day.rpy:261
translate Spanish day1_afterfirstchoice_1326653e:

    # GR "A Virus? No, Do Not Be Absurd."
    GR "¿Un Virus? No Seas Absurd[letra]."

# game/chapters/1_day.rpy:262
translate Spanish day1_afterfirstchoice_c0b9df2f:

    # GR "This Is An Application That I Have Created."
    GR "Esta Es Una Aplicación Que He Creado."

# game/chapters/1_day.rpy:264
translate Spanish day1_afterfirstchoice_4fe91091:

    # GR "Like I Already Told You."
    GR "Como Ya Te Lo Dije."

# game/chapters/1_day.rpy:265
translate Spanish day1_afterfirstchoice_a0107c4d:

    # GR "Please Pay More Attention."
    GR "Por Favor, Presta Más Atención."

# game/chapters/1_day.rpy:268
translate Spanish day1_afterfirstchoice_82b4ab40:

    # player "Okay, but..."
    player "Okey, pero..."

# game/chapters/1_day.rpy:273
translate Spanish day1_afterfirstchoice_c237b9ba:

    # player "...?"
    player "...?"

# game/chapters/1_day.rpy:276
translate Spanish day1_afterfirstchoice_32e17079:

    # player "For...?"
    player "¿Para...?"

# game/chapters/1_day.rpy:277
translate Spanish day1_afterfirstchoice_b43e5c33:

    # GR "Messaging You."
    GR "Para Enviarte Mensajes."

# game/chapters/1_day.rpy:280
translate Spanish day1_afterfirstchoice_2920d744:

    # player "Why?"
    player "¿Por qué?"

# game/chapters/1_day.rpy:283
translate Spanish day1_afterfirstchoice_abd9bf45:

    # player "I don't even know who you are."
    player "Ni siquiera sé quién eres."

# game/chapters/1_day.rpy:286
translate Spanish day1_afterfirstchoice_be6b41ba:

    # player "It's a little strange to message a random [girl] out of nowhere."
    player "Es un poco raro escribirle de la nada a [arti_2] [girl!t] al azar."

# game/chapters/1_day.rpy:287
translate Spanish day1_afterfirstchoice_a4144670:

    # GR "Random? There Is No Element Of 'Randomness' At Play Here."
    GR "¿Al Azar? No Hay Ningún Elemento De 'Aleatoriedad' En Juego Aquí."

# game/chapters/1_day.rpy:288
translate Spanish day1_afterfirstchoice_a7983f34:

    # GR "You Are Not Some 'Random' [Girl]. You Are A Very Specific [Girl]."
    GR "Tú No Eres Cualquier [Girl!t] 'Al Azar'. Eres [arti_2!c] [Girl!t] Muy Específic[letra]."

# game/chapters/1_day.rpy:291
translate Spanish day1_afterfirstchoice_c46595ec:

    # player "Okay, getting creepier."
    player "Okey, esto se pone cada vez más espeluznante."

# game/chapters/1_day.rpy:294
translate Spanish day1_afterfirstchoice_1ad5758e:

    # player "Do I know you from somewhere, then?"
    player "¿Te conozco de algún lado, entonces?"

# game/chapters/1_day.rpy:297
translate Spanish day1_afterfirstchoice_decdfd5d:

    # player "Wait, are you a bot?"
    player "Espera, ¿eres un bot?"

# game/chapters/1_day.rpy:298
translate Spanish day1_afterfirstchoice_19f0567e:

    # GR "A What?"
    GR "¿Un Qué?"

# game/chapters/1_day.rpy:301
translate Spanish day1_afterfirstchoice_044cc49f:

    # player "You know. A bot."
    player "Ya sabes. Un bot."

# game/chapters/1_day.rpy:304
translate Spanish day1_afterfirstchoice_f90c139b:

    # player "Beep beep."
    player "Bip bip."

# game/chapters/1_day.rpy:305
translate Spanish day1_afterfirstchoice_d4a6823c:

    # GR "A Robot?"
    GR "¿Un Robot?"

# game/chapters/1_day.rpy:306
translate Spanish day1_afterfirstchoice_1dbae1d4:

    # GR "Don't Be Absurd."
    GR "No Seas Absurd[letra]."

# game/chapters/1_day.rpy:307
translate Spanish day1_afterfirstchoice_1faf8eab:

    # GR "Robots Anywhere Near My Level Of Charisma, Charm And Good Looks Are Not Possible."
    GR "No Existen Robots Que Se Acerquen Siquiera A Mi Nivel De Carisma, Encanto Y Buena Apariencia."

# game/chapters/1_day.rpy:310
translate Spanish day1_afterfirstchoice_959233b3:

    # player "Sounds like something a bot would say."
    player "Suena como algo que diría un bot."

# game/chapters/1_day.rpy:311
translate Spanish day1_afterfirstchoice_9849172b:

    # GR "I Am Not A Robot!"
    GR "¡No Soy Un Robot!"

# game/chapters/1_day.rpy:314
translate Spanish day1_afterfirstchoice_580d4153:

    # player "Robot say huh?"
    player "¿El robot dice eh?"

# game/chapters/1_day.rpy:315
translate Spanish day1_afterfirstchoice_ce06d0b6:

    # GR "Huh?"
    GR "¿Eh?"

# game/chapters/1_day.rpy:318
translate Spanish day1_afterfirstchoice_81aa9d54:

    # player "Gotcha."
    player "Te atrapé."

# game/chapters/1_day.rpy:319
translate Spanish day1_afterfirstchoice_230dec51:

    # GR "...."
    GR "...."

# game/chapters/1_day.rpy:320
translate Spanish day1_afterfirstchoice_cb8ce665:

    # GR "I Have Not Come Here To Play Your Games, Mortal."
    GR "No He Venido Aquí Para Jugar Tus Juegos, Mortal."

# game/chapters/1_day.rpy:323
translate Spanish day1_afterfirstchoice_63730f27:

    # player "Why are you here then?"
    player "¿Entonces por qué estás aquí?"

# game/chapters/1_day.rpy:326
translate Spanish day1_afterfirstchoice_064e0e51:

    # GR "I Told You, I Have Come To Reap Your Soul!"
    GR "Te Lo Dije, ¡He Venido A Segar Tu Alma!"

# game/chapters/1_day.rpy:330
translate Spanish day1_afterfirstchoice_735ff648:

    # player "Yeah, you said that once or twice..."
    player "Sí, eso lo dijiste una o dos veces..."

# game/chapters/1_day.rpy:333
translate Spanish day1_afterfirstchoice_1f233525:

    # player "Is this a call for help?"
    player "¿Es esto una llamada de auxilio?"

# game/chapters/1_day.rpy:335
translate Spanish day1_afterfirstchoice_45c35ef6:

    # player "I'm actually starting to feel sorry for you..."
    player "De verdad que estoy empezando a sentir lástima por ti..."

# game/chapters/1_day.rpy:338
translate Spanish day1_afterfirstchoice_56967313:

    # player "Wait, what did you come here for?"
    player "Espera, ¿para qué viniste aquí?"

# game/chapters/1_day.rpy:339
translate Spanish day1_afterfirstchoice_6d91d452:

    # GR "To... To Reap Your Soul!"
    GR "¡Para... Para Segar Tu Alma!"

# game/chapters/1_day.rpy:342
translate Spanish day1_afterfirstchoice_4b0a89fa:

    # player "Sorry, one more time? You're cutting out."
    player "Perdón, ¿otra vez? Se corta la señal."

# game/chapters/1_day.rpy:343
translate Spanish day1_afterfirstchoice_fd4fcff0:

    # GR "I Said To Reap Your Soul!"
    GR "¡Dije Que Venía A Segar Tu Alma!"

# game/chapters/1_day.rpy:346
translate Spanish day1_afterfirstchoice_2cc2d9d3:

    # player "Man, really bad reception here."
    player "Vaya, qué mala señal hay aquí."

# game/chapters/1_day.rpy:349
translate Spanish day1_afterfirstchoice_a6db9b1c:

    # player "Can't make out what you're saying at all."
    player "No entiendo nada de lo que dices."

# game/chapters/1_day.rpy:353
translate Spanish day1_afterfirstchoice_14a8f01b:

    # GR "Do Not Belittle Me!"
    GR "¡No Me Menosprecies!"

# game/chapters/1_day.rpy:354
translate Spanish day1_afterfirstchoice_af8202be:

    # GR "I Am Coming For What Is Owed To Me, That Is All."
    GR "Vengo Por Lo Que Se Me Debe, Eso Es Todo."

# game/chapters/1_day.rpy:355
translate Spanish day1_afterfirstchoice_7274de47:

    # GR "It Would Do You Well To Not Get In My Way."
    GR "Te Convendría No Ponerte En Mi Camino."

# game/chapters/1_day.rpy:358
translate Spanish day1_afterfirstchoice_4f0ac427:

    # player "Are you trying to threaten me or something?"
    player "¿Intentas amenazarme o algo?"

# game/chapters/1_day.rpy:359
translate Spanish day1_afterfirstchoice_713c064d:

    # GR "Do You Feel Threatened By Me?"
    GR "¿Te Sientes Amenazad[letra] Por Mí?"

# game/chapters/1_day.rpy:360
translate Spanish day1_afterfirstchoice_06788dab:

    # GR "If So, Then I Am Doing My Job Correctly. This Bodes Well."
    GR "Si Es Así, Entonces Estoy Haciendo Bien Mi Trabajo. Es Una Buena Señal."

# game/chapters/1_day.rpy:363
translate Spanish day1_afterfirstchoice_16f2c812:

    # player "I don't owe you anything."
    player "No te debo nada."

# game/chapters/1_day.rpy:364
translate Spanish day1_afterfirstchoice_75ccc57e:

    # GR "You Do. You Just Do Not Know It."
    GR "Sí Me Debes. Simplemente No Lo Sabes."

# game/chapters/1_day.rpy:365
translate Spanish day1_afterfirstchoice_0ae0aac1:

    # GR "It Is My Job To Know It For You."
    GR "Es Mi Trabajo Saberlo Por Ti."

# game/chapters/1_day.rpy:366
translate Spanish day1_afterfirstchoice_ba55d7c6:

    # GR "There Is No Need To Be Afraid. It Is A Natural Process."
    GR "No Hay Necesidad De Temer. Es Un Proceso Natural."

# game/chapters/1_day.rpy:370
translate Spanish day1_afterfirstchoice_61b4f8fe:

    # player "Uh, and this job is...?"
    player "Eh, ¿y este trabajo es...?"

# game/chapters/1_day.rpy:371
translate Spanish day1_afterfirstchoice_6f3d4279:

    # GR "Thank You For Finally Asking."
    GR "Gracias Por Finalmente Preguntar."

# game/chapters/1_day.rpy:372
translate Spanish day1_afterfirstchoice_fef248cf:

    # GR "Beg Me To Tell You."
    GR "Suplícame Que Te Lo Cuente."

# game/chapters/1_day.rpy:375
translate Spanish day1_afterfirstchoice_c1736e0b:

    # player "I don't care that much..."
    player "No me importa tanto..."

# game/chapters/1_day.rpy:376
translate Spanish day1_afterfirstchoice_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpy:377
translate Spanish day1_afterfirstchoice_fbfdf365:

    # GR "Really?"
    GR "¿De Verdad?"

# game/chapters/1_day.rpy:378
translate Spanish day1_afterfirstchoice_0e8e60bf:

    # GR "Oh..."
    GR "Oh..."

# game/chapters/1_day.rpy:381
translate Spanish day1_afterfirstchoice_a40e5258:

    # player "...Fine, please tell me."
    player "...Está bien, por favor dime."

# game/chapters/1_day.rpy:384
translate Spanish day1_afterfirstchoice_eb67bac3:

    # player "Now I feel bad. You can tell me."
    player "Ahora me siento mal. Puedes decírmelo."

# game/chapters/1_day.rpy:387
translate Spanish day1_afterfirstchoice_8fa378d0:

    # player "Pretty please?"
    player "¿Porfis?"

# game/chapters/1_day.rpy:388
translate Spanish day1_afterfirstchoice_7772a27d_1:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpy:389
translate Spanish day1_afterfirstchoice_fc20dd93:

    # GR "To Be Honest, I Wasn't Expecting You To Actually..."
    GR "Para Ser Honesto, No Esperaba Que Realmente..."

# game/chapters/1_day.rpy:390
translate Spanish day1_afterfirstchoice_8e2543be:

    # GR "Ahem."
    GR "Ejem."

# game/chapters/1_day.rpy:394
translate Spanish day1_afterfirstchoice_a689c120:

    # player "Yeah, I'm terrified."
    player "Sí, tengo mucho miedo."

# game/chapters/1_day.rpy:395
translate Spanish day1_afterfirstchoice_da91a2a4:

    # GR "Really? Hah! Good. Your Instincts Serve You Well."
    GR "¿De Verdad? ¡Ja! Bien. Tus Instintos Te Sirven Bien."

# game/chapters/1_day.rpy:398
translate Spanish day1_afterfirstchoice_3b69f14e:

    # player "Nah, not really. I'm just messing with you."
    player "No, en realidad no. Solo te estoy tomando el pelo."

# game/chapters/1_day.rpy:400
translate Spanish day1_afterfirstchoice_815b6f08:

    # player "Yep. Really really scared atm."
    player "Síp. Realmente tengo mucho miedo en este momento."

# game/chapters/1_day.rpy:403
translate Spanish day1_afterfirstchoice_bd1732d3:

    # player ":D"
    player ":D"

# game/chapters/1_day.rpy:405
translate Spanish day1_afterfirstchoice_45430097:

    # player ":3"
    player ":3"

# game/chapters/1_day.rpy:407
translate Spanish day1_afterfirstchoice_7772a27d_2:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpy:408
translate Spanish day1_afterfirstchoice_df7bd05e:

    # GR "You Will Not Mess With Me Any Longer When You Find Out My True Form."
    GR "Ya No Te Burlarás De Mí Cuando Descubras Mi Verdadera Forma."

# game/chapters/1_day.rpy:409
translate Spanish day1_afterfirstchoice_4573c435:

    # GR "You Will Cower In Fear. You Will Beg Me To Release You."
    GR "Te Encogerás De Miedo. Me Suplicarás Que Te Libere."

# game/chapters/1_day.rpy:412
translate Spanish day1_afterfirstchoice_4b4bad2f:

    # player "Uh huh. Sure I will."
    player "Eh ajá. Seguro que sí."

# game/chapters/1_day.rpy:415
translate Spanish day1_afterfirstchoice_02fae16c:

    # player "And this true form is...?"
    player "¿Y esa verdadera forma es...?"

# game/chapters/1_day.rpy:418
translate Spanish day1_afterfirstchoice_30e047df:

    # GR "I Am The Grim Reaper, And I Have Come To Claim Your Soul."
    GR "Soy La Parca, Y He Venido A Reclamar Tu Alma."

# game/chapters/1_day.rpy:421
translate Spanish day1_afterfirstchoice_f8495abb:

    # player "Right."
    player "Cierto."

# game/chapters/1_day.rpy:424
translate Spanish day1_afterfirstchoice_6544652c:

    # player "Riiiight."
    player "Cieeeerto."

# game/chapters/1_day.rpy:427
translate Spanish day1_afterfirstchoice_f622fe25:

    # player "Riiiiiiiiiight."
    player "Cieeeeeeeeeerto."

# game/chapters/1_day.rpy:431
translate Spanish day1_afterfirstchoice_b0604f14:

    # player "Cool."
    player "Genial."

# game/chapters/1_day.rpy:434
translate Spanish day1_afterfirstchoice_710759d4:

    # player "Very normal."
    player "Muy normal."

# game/chapters/1_day.rpy:437
translate Spanish day1_afterfirstchoice_652e6662:

    # player "Totally reasonable thing to say to someone."
    player "Algo totalmente razonable para decirle a alguien."

# game/chapters/1_day.rpy:438
translate Spanish day1_afterfirstchoice_2a86e101:

    # GR "You Make It Sound Unreasonable."
    GR "Haces Que Suene Irrazonable."

# game/chapters/1_day.rpy:439
translate Spanish day1_afterfirstchoice_a5b65982:

    # GR "Why?"
    GR "¿Por Qué?"

# game/chapters/1_day.rpy:442
translate Spanish day1_afterfirstchoice_e70a0812:

    # player "Um."
    player "Um."

# game/chapters/1_day.rpy:445
translate Spanish day1_afterfirstchoice_d03ac851:

    # player "Maybe because it is?"
    player "¿Quizás porque lo es?"

# game/chapters/1_day.rpy:448
translate Spanish day1_afterfirstchoice_505fe973:

    # player "I don't give my soul to just anyone, you know."
    player "No entrego mi alma a cualquiera, ¿sabes?"

# game/chapters/1_day.rpy:449
translate Spanish day1_afterfirstchoice_9fe7d46a:

    # GR "Fortunately, I Am Not Just Anyone."
    GR "Afortunadamente, No Soy Cualquiera."

# game/chapters/1_day.rpy:450
translate Spanish day1_afterfirstchoice_399e8990:

    # GR "I Am The Grim Reaper."
    GR "Soy La Parca."

# game/chapters/1_day.rpy:451
translate Spanish day1_afterfirstchoice_74158f33:

    # GR "Pulling The Soul From Your Body And Leaving You An Empty Husk Is Literally In My Job Description."
    GR "Arrancar El Alma De Tu Cuerpo Y Dejarte Como Un Cascarón Vacío Está Literalmente En La Descripción De Mi Trabajo."

# game/chapters/1_day.rpy:454
translate Spanish day1_afterfirstchoice_27390844:

    # player "I had that in my job description once, too."
    player "Yo también tuve eso en mi descripción de trabajo una vez."

# game/chapters/1_day.rpy:455
translate Spanish day1_afterfirstchoice_fbfdf365_1:

    # GR "Really?"
    GR "¿De Verdad?"

# game/chapters/1_day.rpy:456
translate Spanish day1_afterfirstchoice_0ab50158:

    # GR "You Were A Grim Reaper?"
    GR "¿Fuiste Una Parca?"

# game/chapters/1_day.rpy:459
translate Spanish day1_afterfirstchoice_b74020bd:

    # player "No, I just worked retail."
    player "No, yo solo trabajaba en una tienda."

# game/chapters/1_day.rpy:460
translate Spanish day1_afterfirstchoice_2c51ffa0:

    # GR "Oh."
    GR "Oh."

# game/chapters/1_day.rpy:461
translate Spanish day1_afterfirstchoice_662bc54d:

    # GR "I Hadn't Realized Mortals Also Dealt In Souls."
    GR "No Me Había Dado Cuenta De Que Los Mortales También Tratan Con Almas."

# game/chapters/1_day.rpy:462
translate Spanish day1_afterfirstchoice_ce4cae60:

    # GR "But That Is Beside The Point."
    GR "Pero Eso Es Irrelevante."

# game/chapters/1_day.rpy:463
translate Spanish day1_afterfirstchoice_fe5f39f8:

    # GR "Your Soul."
    GR "Tu Alma."

# game/chapters/1_day.rpy:466
translate Spanish day1_afterfirstchoice_c0afbf2b:

    # player "ngl not the weirdest scam someone's tried on me."
    player "No voy a mentir, no es la estafa más rara que alguien me haya intentado hacer."

# game/chapters/1_day.rpy:469
translate Spanish day1_afterfirstchoice_1cc1421c:

    # player "There was this one time when I got a message from a 'time-traveling astronaut'."
    player "Hubo una vez en que recibí un mensaje de un 'astronauta viajero del tiempo'."

# game/chapters/1_day.rpy:472
translate Spanish day1_afterfirstchoice_ee1a2c16:

    # player "Said I had to wire them money to preserve the space-time continuum."
    player "Decía que tenía que transferirles dinero para preservar el continuo espacio-tiempo."

# game/chapters/1_day.rpy:474
translate Spanish day1_afterfirstchoice_0e5914a0:

    # GR "Uh... Did You Send Them Money?"
    GR "Eh... ¿Les Enviaste Dinero?"

# game/chapters/1_day.rpy:475
translate Spanish day1_afterfirstchoice_c00f17d0:

    # GR "That Sounds Important..."
    GR "Eso Suena Importante..."

# game/chapters/1_day.rpy:478
translate Spanish day1_afterfirstchoice_59e64330:

    # player "Somehow I'm not surprised that you would fall for that."
    player "De alguna manera no me sorprende que hayas caído en eso."

# game/chapters/1_day.rpy:479
translate Spanish day1_afterfirstchoice_7dccc9fe:

    # GR "What? It Was A Lie?"
    GR "¿Qué? ¿Era Una Mentira?"

# game/chapters/1_day.rpy:482
translate Spanish day1_afterfirstchoice_e7564ac0:

    # player "Well, I hope it was..."
    player "Bueno, eso espero..."

# game/chapters/1_day.rpy:483
translate Spanish day1_afterfirstchoice_e69eb3a7:

    # GR "Now You're Making Me Worry. Time Is Not Something To Mess With."
    GR "Ahora Me Estás Haciendo Preocupar. El Tiempo No Es Algo Con Lo Que Se Deba Jugar."

# game/chapters/1_day.rpy:486
translate Spanish day1_afterfirstchoice_53cffdf2:

    # player "I'll keep that in mind."
    player "Lo tendré en cuenta."

# game/chapters/1_day.rpy:487
translate Spanish day1_afterfirstchoice_6d708bc8:

    # GR "Good. Even A Mortal Must Realize That Playing With Time Rarely Leads To Happy Results."
    GR "Bien. Incluso Un Mortal Debe Darse Cuenta De Que Jugar Con El Tiempo Rara Vez Conduce A Resultados Felices."

# game/chapters/1_day.rpy:488
translate Spanish day1_afterfirstchoice_067b5ec4:

    # GR "But, You're Trying To Distract Me, Aren't You?"
    GR "Pero, Estás Intentando Distraerme, ¿Verdad?"

# game/chapters/1_day.rpy:489
translate Spanish day1_afterfirstchoice_83533abf:

    # GR "Your Soul, Now."
    GR "Tu Alma, Ahora."

# game/chapters/1_day.rpy:491
translate Spanish day1_afterfirstchoice_1ecbfcbc:

    # player "You're kind of babygirl coded."
    player "Tienes un aire de Babygirl."

# game/chapters/1_day.rpy:492
translate Spanish day1_afterfirstchoice_eed7aeef:

    # GR "What? What Does That... What?"
    GR "¿Qué? ¿Qué Significa Eso... Qué?"

# game/chapters/1_day.rpy:493
translate Spanish day1_afterfirstchoice_c9d052b2:

    # GR "Stop Trying To Distract Me From The Matter At Hand!"
    GR "¡Deja De Intentar Distraerme Del Asunto Que Nos Ocupa!"

# game/chapters/1_day.rpy:494
translate Spanish day1_afterfirstchoice_fe5f39f8_1:

    # GR "Your Soul."
    GR "Tu Alma."

# game/chapters/1_day.rpy:496
translate Spanish day1_afterfirstchoice_b3e59447:

    # GR "You Will Hand It Over?"
    GR "¿La Entregarás?"

# game/chapters/1_day.rpy:499
translate Spanish day1_afterfirstchoice_77b4784a:

    # player "I have to ask, is this a roleplay?"
    player "Tengo una pregunta, ¿esto es un roleplay?"

# game/chapters/1_day.rpy:500
translate Spanish day1_afterfirstchoice_103605ad:

    # GR "A 'Roleplay'? What Is A 'Roleplay'?"
    GR "¿Un 'Roleplay'? ¿Qué Es Un 'Roleplay'?"

# game/chapters/1_day.rpy:503
translate Spanish day1_afterfirstchoice_5f4ffbb2:

    # player "Like, you're pretending to be the grim reaper..."
    player "Como si estuvieras fingiendo ser la parca..."

# game/chapters/1_day.rpy:506
translate Spanish day1_afterfirstchoice_568fcef3:

    # player "And you want me to be..."
    player "Y quieres que yo sea..."

# game/chapters/1_day.rpy:509
translate Spanish day1_afterfirstchoice_55ba2e8f:

    # player "Your enemies-to-lovers sweetheart?"
    player "¿Tu pareja de 'enemies-to-lovers'?"

# game/chapters/1_day.rpy:511
translate Spanish day1_afterfirstchoice_8756a3a3:

    # player "A pizza delivery [woman]."
    player "[arti_2!c] [woman!t] que reparte pizzas."

# game/chapters/1_day.rpy:513
translate Spanish day1_afterfirstchoice_352ba6a5:

    # player "Your mortal enemy. Mwhahahaha."
    player "Tu enemig[letra] mortal. Mwhahahaha."

# game/chapters/1_day.rpy:514
translate Spanish day1_afterfirstchoice_d7eadc64:

    # GR "What? No. I Am The Grim Reaper. This Is No Game Of Make Believe."
    GR "¿Qué? No. Soy La Parca. Esto No Es Un Juego De Ficción."

# game/chapters/1_day.rpy:515
translate Spanish day1_afterfirstchoice_e9dc5df8:

    # GR "This Is A Matter Of Utmost Seriousness."
    GR "Esto Es Un Asunto De Máxima Seriedad."

# game/chapters/1_day.rpy:518
translate Spanish day1_afterfirstchoice_d9d06db6:

    # player "That's a shame."
    player "Qué lástima."

# game/chapters/1_day.rpy:521
translate Spanish day1_afterfirstchoice_d4916534:

    # player "I used to be one hell of a roleplayer, back in the day."
    player "Solía ser una máquina del roleplay, en mis tiempos."

# game/chapters/1_day.rpy:522
translate Spanish day1_afterfirstchoice_47edd3fa:

    # GR "I'm Sure You Were..."
    GR "Seguro Que Lo Fuiste..."

# game/chapters/1_day.rpy:525
translate Spanish day1_afterfirstchoice_47dbf850:

    # player "It's a little hard to take you seriously."
    player "Es un poco difícil tomarte en serio."

# game/chapters/1_day.rpy:526
translate Spanish day1_afterfirstchoice_a5b65982_1:

    # GR "Why?"
    GR "¿Por Qué?"

# game/chapters/1_day.rpy:529
translate Spanish day1_afterfirstchoice_b2438c3c:

    # player "Maybe because you're literally a stranger on the internet?"
    player "¿Quizá porque literalmente eres un desconocido de internet?"

# game/chapters/1_day.rpy:530
translate Spanish day1_afterfirstchoice_493ae1f1:

    # GR "Everyone Is A Stranger Before You Meet Them."
    GR "Todos Son Desconocidos Antes De Que Los Conozcas."

# game/chapters/1_day.rpy:533
translate Spanish day1_afterfirstchoice_51c29c4b:

    # player "But most people don't claim to be a mythological creature."
    player "Pero la mayoría de la gente no afirma ser una criatura mitológica."

# game/chapters/1_day.rpy:534
translate Spanish day1_afterfirstchoice_57c3340b:

    # GR "Because They Are Not. I Am."
    GR "Porque Ellos No Lo Son. Yo Sí."

# game/chapters/1_day.rpy:539
translate Spanish day1_afterfirstchoice_ba7fafde:

    # player "Are you... okay?"
    player "¿Estás... bien?"

# game/chapters/1_day.rpy:540
translate Spanish day1_afterfirstchoice_ec0f9d4b:

    # GR "Okay? Why Do You Want To Know My Condition?"
    GR "¿Okey? ¿Por Qué Quieres Saber Sobre Mi Estado?"

# game/chapters/1_day.rpy:543
translate Spanish day1_afterfirstchoice_f651aa8c:

    # player "Well, you're spouting all of this nonsense."
    player "Bueno, estás diciendo todas estas tonterías."

# game/chapters/1_day.rpy:546
translate Spanish day1_afterfirstchoice_26d99d1a:

    # player "I thought it might be a call for help...?"
    player "Pensé que podría ser un llamado de auxilio... ¿no?"

# game/chapters/1_day.rpy:547
translate Spanish day1_afterfirstchoice_fd47c6ed:

    # GR "You Can Help Me By Giving Up Your Soul Already."
    GR "Puedes Ayudarme Entregando Ya Tu Alma."

# game/chapters/1_day.rpy:551
translate Spanish day1_afterfirstchoice_9511dbed:

    # player "Mmm, not really a fan..."
    player "Mmm, no es que me convenza mucho..."

# game/chapters/1_day.rpy:552
translate Spanish day1_afterfirstchoice_992d6061:

    # GR "What? That Doesn't Matter. All That Matters Is That You Give It Over."
    GR "¿Qué? Eso No Importa. Lo Único Que Importa Es Que La Entregues."

# game/chapters/1_day.rpy:555
translate Spanish day1_afterfirstchoice_4ad10f17:

    # player "And if I said no?"
    player "¿Y si digo que no?"

# game/chapters/1_day.rpy:556
translate Spanish day1_afterfirstchoice_631eb0e5:

    # GR "I Would Laugh At One Who Would Defy Me So Openly."
    GR "Me Reiría De Alguien Que Me Desafiara Tan Abiertamente."

# game/chapters/1_day.rpy:559
translate Spanish day1_afterfirstchoice_78c5fdf3:

    # player "Being laughed at, or losing my soul..."
    player "Que se rían de mí o perder mi alma..."

# game/chapters/1_day.rpy:562
translate Spanish day1_afterfirstchoice_cda30e23:

    # player "Tough decision."
    player "Difícil decisión."

# game/chapters/1_day.rpy:565
translate Spanish day1_afterfirstchoice_e7002d63:

    # player "You know..."
    player "Sabes..."

# game/chapters/1_day.rpy:570
translate Spanish day1_afterfirstchoice_f5e66196:

    # player "Is this one of those scams?"
    player "¿Es esta una de esas estafas?"

# game/chapters/1_day.rpy:571
translate Spanish day1_afterfirstchoice_4f0c1452:

    # GR "...Scams?"
    GR "...¿Estafas?"

# game/chapters/1_day.rpy:573
translate Spanish day1_afterfirstchoice_44b375ff:

    # GR "Are We Really Back To Talking About Scams Again?"
    GR "¿De Verdad Volvemos A Hablar De Estafas Otra Vez?"

# game/chapters/1_day.rpy:574
translate Spanish day1_afterfirstchoice_9b3fa767:

    # GR "I'm Not A Time-Traveling Astronaut. I Am Simply A Grim Reaper With A Job."
    GR "No Soy Un Astronauta Que Viaja En El Tiempo. Simplemente Soy Una Parca Con Un Trabajo."

# game/chapters/1_day.rpy:575
translate Spanish day1_afterfirstchoice_2893e221:

    # GR "Go On, Then. Tell Me What My 'Scam' Is."
    GR "Adelante, Entonces. Dime Cuál Es Mi 'Estafa'."

# game/chapters/1_day.rpy:578
translate Spanish day1_afterfirstchoice_f456c163:

    # player "{i}You owe $5000 in taxes... payment taken in gift cards.{/i}"
    player "{i}Debes $5000 en impuestos... pago aceptado en tarjetas de regalo.{/i}"

# game/chapters/1_day.rpy:579
translate Spanish day1_afterfirstchoice_99a09e69:

    # GR "I Owe You Nothing. I Pay My Taxes."
    GR "No Te Debo Nada. Pago Mis Impuestos."

# game/chapters/1_day.rpy:582
translate Spanish day1_afterfirstchoice_990d0494:

    # player "No, dumbo, that's the scam."
    player "No, bobo, esa es la estafa."

# game/chapters/1_day.rpy:583
translate Spanish day1_afterfirstchoice_31c4b3ec:

    # GR "So You're A Scammer Now?"
    GR "¿Así Que Ahora Te Dedicas A Estafar?"

# game/chapters/1_day.rpy:586
translate Spanish day1_afterfirstchoice_189f1d4b:

    # player "If I was, I'd be rich off you alone."
    player "Si lo fuera, me haría ric[letra] solo contigo."

# game/chapters/1_day.rpy:587
translate Spanish day1_afterfirstchoice_69b49e8c:

    # GR "You Could Not Scam Me That Easily."
    GR "No Podrías Estafarme Tan Fácilmente."

# game/chapters/1_day.rpy:590
translate Spanish day1_afterfirstchoice_48a0b670:

    # player "But I was serious about your taxes."
    player "Pero hablaba en serio sobre tus impuestos."

# game/chapters/1_day.rpy:593
translate Spanish day1_afterfirstchoice_6f742096:

    # player "The tax agency sent me."
    player "La agencia tributaria me envió."

# game/chapters/1_day.rpy:596
translate Spanish day1_afterfirstchoice_51ca90e3:

    # player "Send me your cc number and the three whacky numbers on the back, quick."
    player "Envíame tu número de tarjeta de crédito y los tres números raros de atrás, rápido."

# game/chapters/1_day.rpy:599
translate Spanish day1_afterfirstchoice_9bbafef8:

    # player "Or you're going to prison, buddy."
    player "O vas a ir a la cárcel, amigo."

# game/chapters/1_day.rpy:600
translate Spanish day1_afterfirstchoice_b7c0240b:

    # GR "Wait, Are You Serious Right Now?"
    GR "Espera, ¿Hablas En Serio Ahora?"

# game/chapters/1_day.rpy:603
translate Spanish day1_afterfirstchoice_f6d2f879:

    # player "Dead serious."
    player "Completamente en serio."

# game/chapters/1_day.rpy:604
translate Spanish day1_afterfirstchoice_58e934a1:

    # GR "Shit."
    GR "Mierda."

# game/chapters/1_day.rpy:605
translate Spanish day1_afterfirstchoice_f4dec5ab:

    # GR "Okay. It's One-Five-Four-Nine..."
    GR "Okey. Es Uno-Cinco-Cuatro-Nueve..."

# game/chapters/1_day.rpy:608
translate Spanish day1_afterfirstchoice_b23a4a23:

    # player "WOAH..." id day1_afterfirstchoice_b23a4a23
    player "UY..." id day1_afterfirstchoice_b23a4a23

# game/chapters/1_day.rpy:611
translate Spanish day1_afterfirstchoice_cd14baf9:

    # player "Okay I don't actually want your details."
    player "Okey, en realidad no quiero tus datos."

# game/chapters/1_day.rpy:614
translate Spanish day1_afterfirstchoice_e6033ac4:

    # player "I was joking."
    player "Estaba bromeando."

# game/chapters/1_day.rpy:618
translate Spanish day1_afterfirstchoice_e5c1ff04:

    # player "No, I'm messing with you again."
    player "No, te estoy tomando el pelo otra vez."

# game/chapters/1_day.rpy:619
translate Spanish day1_afterfirstchoice_2c51ffa0_1:

    # GR "Oh."
    GR "Oh."

# game/chapters/1_day.rpy:622
translate Spanish day1_afterfirstchoice_d770e46b:

    # player "But you believed me, didn't you?"
    player "Pero me creíste, ¿no?"

# game/chapters/1_day.rpy:623
translate Spanish day1_afterfirstchoice_c9841cb5:

    # GR "Nope. I Did Not, Not In The Slightest."
    GR "Nop. No Lo Hice, Ni En Lo Más Mínimo."

# game/chapters/1_day.rpy:626
translate Spanish day1_afterfirstchoice_97e824f3:

    # player "Look, as fun as messing with you is..."
    player "Mira, por muy divertido que sea molestarte..."

# game/chapters/1_day.rpy:633
translate Spanish day1_afterfirstchoice_9ee47d17:

    # player "Of course, it's all yours!"
    player "¡Por supuesto, es toda tuya!"

# game/chapters/1_day.rpy:634
translate Spanish day1_afterfirstchoice_d60ca591:

    # GR "Finally! "
    GR "¡Por Fin!"

# game/chapters/1_day.rpy:635
translate Spanish day1_afterfirstchoice_dc1b7dce:

    # GR "I Have Waited Long Enough."
    GR "He Esperado Lo Suficiente."

# game/chapters/1_day.rpy:636
translate Spanish day1_afterfirstchoice_389a516e:

    # GR "Honestly, I Should Have Contacted You Sooner If It Was Going To Be This Easy."
    GR "Honestamente, Debería Haberte Contactado Antes Si Iba A Ser Tan Fácil."

# game/chapters/1_day.rpy:639
translate Spanish day1_afterfirstchoice_6a0c6ec9:

    # player "Should I post it via mail?"
    player "¿Debería enviarla por correo?"

# game/chapters/1_day.rpy:640
translate Spanish day1_afterfirstchoice_44f4ac4e:

    # GR "What? You Cannot Send A Soul In The Post!"
    GR "¿Qué? ¡No Puedes Enviar Un Alma Por Correo!"

# game/chapters/1_day.rpy:644
translate Spanish day1_afterfirstchoice_9631ba19:

    # player "Trust me, you can."
    player "Créeme, sí se puede."

# game/chapters/1_day.rpy:645
translate Spanish day1_afterfirstchoice_28414721:

    # GR "You Cannot!"
    GR "¡No Puedes!"

# game/chapters/1_day.rpy:646
translate Spanish day1_afterfirstchoice_e8b39989:

    # GR "How Would You Even Know?"
    GR "¿Cómo Lo Sabrías?"

# game/chapters/1_day.rpy:649
translate Spanish day1_afterfirstchoice_eb9d7318:

    # player "I send souls all the time."
    player "Envío almas todo el tiempo."

# game/chapters/1_day.rpy:650
translate Spanish day1_afterfirstchoice_f15f8f95:

    # GR "Well... Okay."
    GR "Bueno... Okey."

# game/chapters/1_day.rpy:651
translate Spanish day1_afterfirstchoice_23f67256:

    # GR "I Am Unsure If Mortal Post Services Can Reach Me, However."
    GR "Sin Embargo, No Estoy Seguro De Si Los Servicios Postales Mortales Pueden Alcanzarme."

# game/chapters/1_day.rpy:655
translate Spanish day1_afterfirstchoice_8215467d:

    # player "You'll just have to wait and see."
    player "Tendrás que esperar y ver."

# game/chapters/1_day.rpy:656
translate Spanish day1_afterfirstchoice_230dec51_1:

    # GR "...."
    GR "...."

# game/chapters/1_day.rpy:657
translate Spanish day1_afterfirstchoice_25b01499:

    # GR "I Believe You Are Attempting To Trick Me."
    GR "Creo Que Estás Intentando Engañarme."

# game/chapters/1_day.rpy:661
translate Spanish day1_afterfirstchoice_58fa5b66:

    # player "What gave me away?"
    player "¿Qué me delató?"

# game/chapters/1_day.rpy:662
translate Spanish day1_afterfirstchoice_17e02691:

    # GR "So It IS A Trick!"
    GR "¡Así Que SÍ Es Un Truco!"

# game/chapters/1_day.rpy:665
translate Spanish day1_afterfirstchoice_7a1c0710:

    # player "Honestly..."
    player "Honestamente..."

# game/chapters/1_day.rpy:669
translate Spanish day1_afterfirstchoice_7885e49f:

    # player "I'll email it to you. What's your email?"
    player "Te lo enviaré por correo electrónico. ¿Cuál es tu correo?"

# game/chapters/1_day.rpy:670
translate Spanish day1_afterfirstchoice_beaa032a:

    # GR "Huh? Souls Cannot Be Transferred Digitally." id day1_afterfirstchoice_beaa032a
    GR "¿Eh? Las Almas No Pueden Ser Transferidas Digitalmente." id day1_afterfirstchoice_beaa032a

# game/chapters/1_day.rpy:674
translate Spanish day1_afterfirstchoice_3491c1eb:

    # player "Are you sure about that?"
    player "¿Estás seguro de eso?"

# game/chapters/1_day.rpy:675
translate Spanish day1_afterfirstchoice_286edd35:

    # GR "Yes, I Am Certain."
    GR "Sí, Estoy Seguro."

# game/chapters/1_day.rpy:678
translate Spanish day1_afterfirstchoice_4cf203e4:

    # player "But have you ever tried?"
    player "¿Pero alguna vez lo intentaste?"

# game/chapters/1_day.rpy:679
translate Spanish day1_afterfirstchoice_5714f8c4:

    # GR "Well, No..."
    GR "Pues No..."

# game/chapters/1_day.rpy:680
translate Spanish day1_afterfirstchoice_fd29a9e9:

    # GR "Fine. My Electronic Mail Address Is TheGrimReaper123abc@reaper.org"
    GR "Está Bien. Mi Dirección De Correo Electrónico Es TheGrimReaper123abc@reaper.org"

# game/chapters/1_day.rpy:683
translate Spanish day1_afterfirstchoice_da3d0b34:

    # player "Pffffft...."
    player "Puajajaja...."

# game/chapters/1_day.rpy:684
translate Spanish day1_afterfirstchoice_d7e42504:

    # GR "What? What Is So Funny?"
    GR "¿Qué? ¿Qué Tiene De Gracioso?"

# game/chapters/1_day.rpy:687
translate Spanish day1_afterfirstchoice_ff95e3fc:

    # player "Your email..."
    player "Tu correo..."

# game/chapters/1_day.rpy:688
translate Spanish day1_afterfirstchoice_17033cd4:

    # GR "It Is A Normal 'Email'."
    GR "Es Un 'Correo' Normal."

# game/chapters/1_day.rpy:691
translate Spanish day1_afterfirstchoice_aa75ffb7:

    # player "Sure..."
    player "Claro..."

# game/chapters/1_day.rpy:695
translate Spanish day1_afterfirstchoice_73fdde63:

    # player "Okay, I just emailed my soul over."
    player "Okey, acabo de enviar mi alma por correo."

# game/chapters/1_day.rpy:696
translate Spanish day1_afterfirstchoice_258aee4f:

    # GR "I Do Not See It In My Inbox."
    GR "No La Veo En Mi Bandeja De Entrada."

# game/chapters/1_day.rpy:699
translate Spanish day1_afterfirstchoice_03dcb181:

    # player "Maybe you're having internet issues."
    player "Quizás tengas problemas de Internet."

# game/chapters/1_day.rpy:703
translate Spanish day1_afterfirstchoice_d88378dd:

    # player "Restart your computer?"
    player "¿Y si reinicias tu computadora?"

# game/chapters/1_day.rpy:704
translate Spanish day1_afterfirstchoice_1a6c2434:

    # GR "If I Was Having Internet Issues, Then Why Can I Still Message You?"
    GR "Si Tuviera Problemas De Internet, ¿Por Qué Podría Seguir Enviándote Mensajes?"

# game/chapters/1_day.rpy:705
translate Spanish day1_afterfirstchoice_25b01499_1:

    # GR "I Believe You Are Attempting To Trick Me."
    GR "Creo Que Estás Intentando Engañarme."

# game/chapters/1_day.rpy:709
translate Spanish day1_afterfirstchoice_58fa5b66_1:

    # player "What gave me away?"
    player "¿Qué me delató?"

# game/chapters/1_day.rpy:710
translate Spanish day1_afterfirstchoice_17e02691_1:

    # GR "So It IS A Trick!"
    GR "¡Así Que SÍ Es Un Truco!"

# game/chapters/1_day.rpy:713
translate Spanish day1_afterfirstchoice_7a1c0710_1:

    # player "Honestly..."
    player "Honestamente..."

# game/chapters/1_day.rpy:719
translate Spanish day1_afterfirstchoice_f971498c:

    # player "I don't usually respond to spam messages like this."
    player "Normalmente no respondo a mensajes de spam como este."

# game/chapters/1_day.rpy:722
translate Spanish day1_afterfirstchoice_683514f2:

    # player "Now I'm thinking I should?"
    player "¿Ahora estoy pensando que debería hacerlo?"

# game/chapters/1_day.rpy:725
translate Spanish day1_afterfirstchoice_3a5a8d0f:

    # player "Anyway, do you seriously think you're the 'grim reaper'?"
    player "De todos modos, ¿de verdad te crees 'La Parca'?"

# game/chapters/1_day.rpy:726
translate Spanish day1_afterfirstchoice_1ab8e8a9:

    # GR "Excuse Me?"
    GR "¿Perdón?"

# game/chapters/1_day.rpy:729
translate Spanish day1_afterfirstchoice_00f33488:

    # player "It's funny, at least...?"
    player "¿Es gracioso, al menos...?"

# game/chapters/1_day.rpy:732
translate Spanish day1_afterfirstchoice_71a6b5a3:

    # player "You've made me laugh, so that's nice."
    player "Me has hecho reír, así que está bien."

# game/chapters/1_day.rpy:733
translate Spanish day1_afterfirstchoice_fc74651a:

    # GR "I Am Not Trying To Make You Laugh..."
    GR "No Intento Hacerte Reír..."

# game/chapters/1_day.rpy:736
translate Spanish day1_afterfirstchoice_ed32a176:

    # player "You should try being less funny then, lol"
    player "Entonces deberías intentar ser menos gracioso, lol"

# game/chapters/1_day.rpy:737
translate Spanish day1_afterfirstchoice_e5374b5d:

    # GR "What About Me Is Funny?"
    GR "¿Qué Hay De Gracioso En Mí?"

# game/chapters/1_day.rpy:740
translate Spanish day1_afterfirstchoice_480bc117:

    # player "Pretty much everything."
    player "Prácticamente todo."

# game/chapters/1_day.rpy:743
translate Spanish day1_afterfirstchoice_27eee40c:

    # player "Mister 'Grim Reaper' (lol)"
    player "Señor 'Parca' (lol)"

# game/chapters/1_day.rpy:744
translate Spanish day1_afterfirstchoice_7772a27d_3:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpy:747
translate Spanish day1_afterfirstchoice_144b60bf:

    # player "It's kinda... cringe."
    player "Es algo... cringe."

# game/chapters/1_day.rpy:748
translate Spanish day1_afterfirstchoice_2a81301f:

    # GR "Cringe...?"
    GR "¿Cringe...?"

# game/chapters/1_day.rpy:749
translate Spanish day1_afterfirstchoice_9f9672c6:

    # GR "I Do Not Even Know What That Means."
    GR "Ni Siquiera Sé Qué Significa Eso."

# game/chapters/1_day.rpy:750
translate Spanish day1_afterfirstchoice_596bef9f:

    # GR "Does It Mean 'Cool'? 'Amazing'?"
    GR "¿Significa 'Genial'? ¿'Increíble'?"

# game/chapters/1_day.rpy:753
translate Spanish day1_afterfirstchoice_6f8872d7:

    # player "No... embarrassing, and annoying."
    player "No... vergonzoso y molesto."

# game/chapters/1_day.rpy:754
translate Spanish day1_afterfirstchoice_cc21bd84:

    # GR "!!!"
    GR "!!!"

# game/chapters/1_day.rpy:755
translate Spanish day1_afterfirstchoice_7f11309b:

    # GR "Annoying? The Annoying One Is You!"
    GR "¿Molesto? ¡La Molestia Eres Tú!"

# game/chapters/1_day.rpy:756
translate Spanish day1_afterfirstchoice_af0d42a4:

    # GR "Well, I Do Not Mind If You See Me That Way."
    GR "Bueno, No Me Importa Que Me Veas Así."

# game/chapters/1_day.rpy:757
translate Spanish day1_afterfirstchoice_0b027599:

    # GR "Your Opinion Of Me Has Little Bearing."
    GR "Tu Opinión Sobre Mí Tiene Poca Relevancia."

# game/chapters/1_day.rpy:759
translate Spanish day1_afterfirstchoice_717b27af:

    # player "Er... yes, that's what it means."
    player "Eh... sí, eso significa."

# game/chapters/1_day.rpy:760
translate Spanish day1_afterfirstchoice_02a9656a:

    # GR "Oh. Thanks, Then."
    GR "Oh. Gracias, Entonces."

# game/chapters/1_day.rpy:763
translate Spanish day1_afterfirstchoice_afff8718:

    # player "But who just installs a program on someones computer like that?"
    player "¿Pero quién instala un programa en la computadora de alguien así como así?"

# game/chapters/1_day.rpy:766
translate Spanish day1_afterfirstchoice_3ea80c91:

    # player "Are you that desperate for attention?"
    player "¿Tan desesperado estás por llamar la atención?"

# game/chapters/1_day.rpy:769
translate Spanish day1_afterfirstchoice_40657a45:

    # player "It makes me feel sad for you."
    player "Me da pena por ti."

# game/chapters/1_day.rpy:770
translate Spanish day1_afterfirstchoice_21c33e1c:

    # GR "...Your Brain Truly Is Tiny."
    GR "...Tu Cerebro Realmente Es Diminuto."

# game/chapters/1_day.rpy:771
translate Spanish day1_afterfirstchoice_7e794ff8:

    # GR "Small And Completely Smooth."
    GR "Pequeño Y Completamente Liso."

# game/chapters/1_day.rpy:772
translate Spanish day1_afterfirstchoice_769b627b:

    # GR "This Is My Job. You Are A Difficult Task, Nothing More."
    GR "Este Es Mi Trabajo. Eres Una Tarea Difícil, Nada Más."

# game/chapters/1_day.rpy:776
translate Spanish day1_afterfirstchoice_a6549763:

    # player "Dude..."
    player "Amigo..."

# game/chapters/1_day.rpy:779
translate Spanish day1_afterfirstchoice_e2b222f8:

    # player "You're the one harrassing me."
    player "Tú eres el que me está acosando."

# game/chapters/1_day.rpy:782
translate Spanish day1_afterfirstchoice_16141bad:

    # player "Nobody is forcing you to be here."
    player "Nadie te obliga a estar aquí."

# game/chapters/1_day.rpy:783
translate Spanish day1_afterfirstchoice_3b508ccf:

    # GR "I Have Little Choice In The Matter, There are Issues That Must Be Resolved."
    GR "Tengo Poca Elección En El Asunto, Hay Asuntos Que Deben Ser Resueltos."

# game/chapters/1_day.rpy:784
translate Spanish day1_afterfirstchoice_b8f234d6:

    # GR "So Until You Stop This Ridiculous Charade, I Will Be Here."
    GR "Así Que Hasta Que No Detengas Esta Ridícula Farsa, Estaré Aquí."

# game/chapters/1_day.rpy:787
translate Spanish day1_afterfirstchoice_0dad0745:

    # player "Forever?"
    player "¿Para siempre?"

# game/chapters/1_day.rpy:788
translate Spanish day1_afterfirstchoice_d65f78b8:

    # GR "If That's What It Takes."
    GR "Si Eso Es Lo Que Se Necesita."

# game/chapters/1_day.rpy:791
translate Spanish day1_afterfirstchoice_7db48f30:

    # player "Forever and ever?"
    player "¿Siempre y para siempre?"

# game/chapters/1_day.rpy:792
translate Spanish day1_afterfirstchoice_86d56fc8:

    # GR "I Already Said Yes."
    GR "Ya Dije Que Sí."

# game/chapters/1_day.rpy:795
translate Spanish day1_afterfirstchoice_d781f2c3:

    # player "You know I can just leave this chat whenever I want, right?"
    player "Sabes que puedo salir de este chat cuando quiera, ¿verdad?"

# game/chapters/1_day.rpy:798
translate Spanish day1_afterfirstchoice_2939677b:

    # player "Then you'd be sitting in chat all alone."
    player "Entonces estarías chateando completamente solo."

# game/chapters/1_day.rpy:801
translate Spanish day1_afterfirstchoice_27eee40c_1:

    # player "Mister 'Grim Reaper' (lol)"
    player "Señor 'Parca' (lol)"

# game/chapters/1_day.rpy:804
translate Spanish day1_afterfirstchoice_0d26ac90:

    # player "It's a little cute..."
    player "Es un poco lindo..."

# game/chapters/1_day.rpy:805
translate Spanish day1_afterfirstchoice_016cb970:

    # GR "C... Cute...?!"
    GR "¡¿L... Lindo...?!"

# game/chapters/1_day.rpy:808
translate Spanish day1_afterfirstchoice_d898dab5:

    # player "Yeah. In a weird way."
    player "Sí. De una forma rara."

# game/chapters/1_day.rpy:812
translate Spanish day1_afterfirstchoice_3728832e:

    # player "You're totally delusional, but it's kinda sweet."
    player "Estás completamente fuera de la realidad, pero es algo tierno."

# game/chapters/1_day.rpy:813
translate Spanish day1_afterfirstchoice_96fa627b:

    # GR "Why Won't You Take Me Seriously?"
    GR "¿Por Qué No Me Tomas En Serio?"

# game/chapters/1_day.rpy:817
translate Spanish day1_afterfirstchoice_9ffe0490:

    # player "Well, it could be that you keep saying things like..."
    player "Bueno, podría ser que sigas diciendo cosas como..."

# game/chapters/1_day.rpy:820
translate Spanish day1_afterfirstchoice_d72ce11a:

    # player "I Have Come To Eat Your Soul!"
    player "¡He Venido A Devorar Tu Alma!"

# game/chapters/1_day.rpy:822
translate Spanish day1_afterfirstchoice_80fa48fd:

    # player "I Am So Edgy And Dark!"
    player "¡Soy Tan Edgy Y Tenebroso!"

# game/chapters/1_day.rpy:824
translate Spanish day1_afterfirstchoice_049a5c43:

    # player "I Am Darkness Incarnate!"
    player "¡Soy La Oscuridad Encarnada!"

# game/chapters/1_day.rpy:826
translate Spanish day1_afterfirstchoice_1dae217b:

    # GR "I... I Never Said That...!"
    GR "¡Y... Yo Nunca Dije Eso...!"

# game/chapters/1_day.rpy:830
translate Spanish day1_afterfirstchoice_111fcb5b:

    # player "You did."
    player "Lo hiciste."

# game/chapters/1_day.rpy:831
translate Spanish day1_afterfirstchoice_3a473189:

    # GR "I Did Not!"
    GR "¡Yo No Lo Hice!"

# game/chapters/1_day.rpy:832
translate Spanish day1_afterfirstchoice_b51be2e9:

    # GR "You Have No Proof!"
    GR "¡No Tienes Pruebas!"

# game/chapters/1_day.rpy:835
translate Spanish day1_afterfirstchoice_d41d8cd9:

    # nvl clear
    nvl clear

# game/chapters/1_day.rpy:839
translate Spanish day1_afterfirstchoice_0526e426:

    # player "Neither do you, little mister grim reaper."
    player "Tú tampoco, señorito Parca."

# game/chapters/1_day.rpy:842
translate Spanish day1_afterfirstchoice_6a226e02:

    # player "Wait, {b}I'M{/b} the Grim Reaper..."
    player "Espera, {b}YO SOY{/b} La Parca..."

# game/chapters/1_day.rpy:843
translate Spanish day1_afterfirstchoice_a3edffcb:

    # GR "Um... No You Aren't."
    GR "Em... No Lo Eres."

# game/chapters/1_day.rpy:846
translate Spanish day1_afterfirstchoice_f218ae39:

    # player "Are you trying to steal my job?"
    player "¿Estás tratando de robarme mi trabajo?"

# game/chapters/1_day.rpy:849
translate Spanish day1_afterfirstchoice_d182f31b:

    # player "That is super {i}not{/i} cool."
    player "Es súper {i}no{/i} cool."

# game/chapters/1_day.rpy:850
translate Spanish day1_afterfirstchoice_28898917:

    # GR "You Are Not A Grim Reaper!"
    GR "¡No Eres Una Parca!"

# game/chapters/1_day.rpy:853
translate Spanish day1_afterfirstchoice_c37279db:

    # player "I Am The Grim Reaper!"
    player "¡Yo Soy La Parca!"

# game/chapters/1_day.rpy:854
translate Spanish day1_afterfirstchoice_2d8b5be4:

    # GR "You Are Not!"
    GR "¡Tú No Lo Eres!"

# game/chapters/1_day.rpy:855
translate Spanish day1_afterfirstchoice_e228c045:

    # GR "I Know Each And Every Grim Reaper In This Plane And Beyond."
    GR "Conozco A Cada Parca En Este Plano Y Más Allá."

# game/chapters/1_day.rpy:856
translate Spanish day1_afterfirstchoice_e06514fd:

    # GR "You Are Not One Of Them!"
    GR "¡Tú No Eres Una De Ellas!"

# game/chapters/1_day.rpy:860
translate Spanish day1_afterfirstchoice_20392fd7:

    # player "No, You Are Not!"
    player "¡No, Tú No Lo Eres!"

# game/chapters/1_day.rpy:861
translate Spanish day1_afterfirstchoice_f3b1f875:

    # GR "......"
    GR "......"

# game/chapters/1_day.rpy:862
translate Spanish day1_afterfirstchoice_41289f45:

    # GR "Okay."
    GR "Okey."

# game/chapters/1_day.rpy:863
translate Spanish day1_afterfirstchoice_8f63e698:

    # GR "If You Are Truly A Grim Reaper, Then Tell Me The First Rule Of Taking A Soul."
    GR "Si Realmente Eres Una Parca, Entonces Dime La Primera Regla De Tomar Un Alma."

# game/chapters/1_day.rpy:867
translate Spanish day1_afterfirstchoice_223c305b:

    # player "The 1st rule of Grim Reaper club - don't talk about Grim Reaper club."
    player "La primera regla del club de las Parcas: no hablar del club de las Parcas."

# game/chapters/1_day.rpy:869
translate Spanish day1_afterfirstchoice_724640b7:

    # player "Make sure they didn't leave the oven on."
    player "Asegúrate de que no hayan dejado el horno encendido."

# game/chapters/1_day.rpy:871
translate Spanish day1_afterfirstchoice_ab295699:

    # player "If they win in rock paper scissors, they get a free pass."
    player "Si ganan en piedra, papel o tijera, obtienen un pase gratuito."

# game/chapters/1_day.rpy:873
translate Spanish day1_afterfirstchoice_91cfd2b3:

    # GR "No, No, No!"
    GR "¡No, No, No!"

# game/chapters/1_day.rpy:874
translate Spanish day1_afterfirstchoice_567e8c43:

    # GR "You Have Absolutely No Clue!"
    GR "¡No Tienes Ni La Más Mínima Idea!"

# game/chapters/1_day.rpy:875
translate Spanish day1_afterfirstchoice_8ad3ddce:

    # GR "The First Rule Is: Ensure A Peaceful Passage."
    GR "La Primera Regla Es: Asegurar Un Tránsito Pacífico."

# game/chapters/1_day.rpy:876
translate Spanish day1_afterfirstchoice_9f28cdf7:

    # GR "No Unnecessary Suffering Or Fear Should Accompany The Transition."
    GR "No Debe Acompañar La Transición Ningún Sufrimiento O Miedo Innecesario."

# game/chapters/1_day.rpy:880
translate Spanish day1_afterfirstchoice_93513e90:

    # player "How reasonable of you."
    player "Qué razonable de tu parte."

# game/chapters/1_day.rpy:883
translate Spanish day1_afterfirstchoice_43ac18a9:

    # player "That's boring. Cause a little pain, why don't you?"
    player "Eso es aburrido. Causa un poco de dolor, ¿por qué no?"

# game/chapters/1_day.rpy:887
translate Spanish day1_afterfirstchoice_8f56b631:

    # player "You're a funny little 'grim reaper' lol" id day1_afterfirstchoice_8f56b631
    player "Eres una 'parquita' divertida, lol" id day1_afterfirstchoice_8f56b631

# game/chapters/1_day.rpy:891
translate Spanish day1_afterfirstchoice_eee101f4:

    # GR "You... You Mock My Title Now?!"
    GR "¡¿Tú... Te Mofas De Mi Título Ahora?!"

# game/chapters/1_day.rpy:895
translate Spanish day1_afterfirstchoice_0e832a4c:

    # player "It's, well... a little embarrassing."
    player "Es, bueno... un poco vergonzoso."

# game/chapters/1_day.rpy:897
translate Spanish day1_afterfirstchoice_01bade75:

    # player "Is there anyone who wouldn't?"
    player "¿Hay alguien que no lo haría?"

# game/chapters/1_day.rpy:899
translate Spanish day1_afterfirstchoice_bc1f7f69:

    # player "It's less mocking, more... light teasing."
    player "No es tanto burlarse, sino más bien... una broma inofensiva."

# game/chapters/1_day.rpy:901
translate Spanish day1_afterfirstchoice_96c8cc18:

    # player "Yeah, sorry."
    player "Sí, lo siento."

# game/chapters/1_day.rpy:904
translate Spanish day1_afterfirstchoice_f6d98ad8:

    # player "Wait, wait, wait, quick question."
    player "Espera, espera, espera, pregunta rápida."

# game/chapters/1_day.rpy:907
translate Spanish day1_afterfirstchoice_5192d67b:

    # player "Do you walk around being like '{i}I AM DEATH{/i}'? in real life, too?"
    player "¿Acaso caminas por ahí diciendo '{i}YO SOY LA MUERTE{/i}'? ¿En la vida real también?"

# game/chapters/1_day.rpy:908
translate Spanish day1_afterfirstchoice_4c380e69:

    # GR "What...?"
    GR "¿Qué...?"

# game/chapters/1_day.rpy:911
translate Spanish day1_afterfirstchoice_96a2bde7:

    # player "'{i}Bow down to me...! Your soul is mine...!{/i}'"
    player "'{i}¡Inclínate ante mí...! ¡Tu alma es mía...!{/i}'"

# game/chapters/1_day.rpy:913
translate Spanish day1_afterfirstchoice_b2b4acdf:

    # player "'{i}I am the Grim Reaper! Death and darkness!{/i}'"
    player "'{i}¡Soy La Parca! ¡Muerte y oscuridad!{/i}'"

# game/chapters/1_day.rpy:916
translate Spanish day1_afterfirstchoice_950a76e8:

    # player "You do, don't you?"
    player "¿Lo haces, verdad?"

# game/chapters/1_day.rpy:917
translate Spanish day1_afterfirstchoice_7772a27d_4:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpy:920
translate Spanish day1_afterfirstchoice_97051f90:

    # player "Stunned silence?"
    player "¿Silencio absoluto?"

# game/chapters/1_day.rpy:921
translate Spanish day1_afterfirstchoice_7772a27d_5:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpy:924
translate Spanish day1_afterfirstchoice_a3034a9c:

    # player "Is your hair as dark as night? Do you hide behind long bangs?"
    player "¿Tu cabello es tan oscuro como la noche? ¿Te escondes detrás de un flequillo largo?"

# game/chapters/1_day.rpy:926
translate Spanish day1_afterfirstchoice_c0253e00:

    # player "You give off 'dresses in all black' vibes."
    player "Das la vibra de 'se viste todo de negro'."

# game/chapters/1_day.rpy:929
translate Spanish day1_afterfirstchoice_61faefca:

    # player "I can relate to that, at least."
    player "Al menos, puedo identificarme con eso."

# game/chapters/1_day.rpy:931
translate Spanish day1_afterfirstchoice_f29a0155:

    # player "Not my thing, but you do you, buddy."
    player "No es lo mío, pero tú haz lo que quieras, amigo."

# game/chapters/1_day.rpy:934
translate Spanish day1_afterfirstchoice_7faa6bcf:

    # player "I think I can imagine you completely."
    player "Creo que puedo imaginarte perfectamente."

# game/chapters/1_day.rpy:937
translate Spanish day1_afterfirstchoice_a115179a:

    # player "It's a funny thought... hehe."
    player "Es una idea divertida... jeje."

# game/chapters/1_day.rpy:939
translate Spanish day1_afterfirstchoice_c7b1042b:

    # player "If only we could meet to confirm my suspicions."
    player "Ojalá pudiéramos vernos para confirmar mis sospechas."

# game/chapters/1_day.rpy:942
translate Spanish day1_afterfirstchoice_f6627dc0:

    # GR "You... You..."
    GR "Tú... Tú..."

# game/chapters/1_day.rpy:943
translate Spanish day1_afterfirstchoice_da1e5321:

    # GR "I Will Not Be Mocked By A Mortal...!"
    GR "¡No Permitiré Que [arti_2!c] Mortal Se Burle De Mí...!"

# game/chapters/1_day.rpy:946
translate Spanish day1_afterfirstchoice_10d28b01:

    # player "'{i}Give me your soul! Your soul is mine for the harvesting!{/i}'"
    player "'{i}¡Dame tu alma! ¡Tu alma es mía para cosecharla!{/i}'"

# game/chapters/1_day.rpy:949
translate Spanish day1_afterfirstchoice_5fc173bd:

    # player "'{i}It will be a three course meal!{/i}'."
    player "'{i}¡Será una comida de tres platos!{/i}'"

# game/chapters/1_day.rpy:950
translate Spanish day1_afterfirstchoice_5e2588e9:

    # GR "You... You...!"
    GR "¡Tú... Tú...!"

# game/chapters/1_day.rpy:953
translate Spanish day1_afterfirstchoice_d97f4de4:

    # player "Did I hurt the scammer's feelings?"
    player "¿Herí los sentimientos del estafador?"

# game/chapters/1_day.rpy:954
translate Spanish day1_afterfirstchoice_7718795e:

    # GR "When Did I Scam You...? "
    GR "¿Cuándo Te Estafé...?"

# game/chapters/1_day.rpy:955
translate Spanish day1_afterfirstchoice_700bb465:

    # GR "Why Do You Keep Calling Me A Scammer....?"
    GR "¿Por Qué Sigues Llamándome Estafador....?"

# game/chapters/1_day.rpy:956
translate Spanish day1_afterfirstchoice_ff6f1cb2:

    # GR "You're Giving Me A Complex Over Here..."
    GR "Me Estás Creando Un Complejo..."

# game/chapters/1_day.rpy:959
translate Spanish day1_afterfirstchoice_7e69006b:

    # player "Have I hurt your little dead heart?"
    player "¿He herido a tu corazoncito muerto?"

# game/chapters/1_day.rpy:960
translate Spanish day1_afterfirstchoice_d532596c:

    # GR "What Makes You Assume I Am Dead?"
    GR "¿Qué Te Lleva A Suponer Que Estoy Muerto?"

# game/chapters/1_day.rpy:963
translate Spanish day1_afterfirstchoice_50d81008:

    # player "The grim reaper is like..."
    player "La parca es como..."

# game/chapters/1_day.rpy:967
translate Spanish day1_afterfirstchoice_eb24cb23:

    # player "A skeleton, right?"
    player "Un esqueleto, ¿no?"

# game/chapters/1_day.rpy:969
translate Spanish day1_afterfirstchoice_6f912713:

    # player "Dead, right?"
    player "Muerto, ¿verdad?"

# game/chapters/1_day.rpy:971
translate Spanish day1_afterfirstchoice_5eb272b8:

    # GR "Another Foolish Assumption."
    GR "Otra Suposición Necia."

# game/chapters/1_day.rpy:972
translate Spanish day1_afterfirstchoice_fe792b1c:

    # GR "Know This."
    GR "Debes Saber Esto."

# game/chapters/1_day.rpy:973
translate Spanish day1_afterfirstchoice_56052453:

    # GR "I Shall Make It As Painful As I Can For You."
    GR "Haré Que Sea Tan Doloroso Como Pueda Para Ti."

# game/chapters/1_day.rpy:974
translate Spanish day1_afterfirstchoice_294093b9:

    # GR "Your Disrespect Has Been Noted."
    GR "Tu Falta De Respeto Ha Sido Anotada."

# game/chapters/1_day.rpy:978
translate Spanish day1_afterfirstchoice_100463e7:

    # player "Hey..."
    player "Oye..."

# game/chapters/1_day.rpy:981
translate Spanish day1_afterfirstchoice_6e6c9f4c:

    # player "Since reaping souls is your job and all, I have a question."
    player "Ya que tu trabajo consiste en segar almas, tengo una pregunta."

# game/chapters/1_day.rpy:984
translate Spanish day1_afterfirstchoice_ad5b5e53:

    # player "Do you..."
    player "¿Tú..."

# game/chapters/1_day.rpy:987
translate Spanish day1_afterfirstchoice_fbacb205:

    # player "Make a killing? :)"
    player "¿Ganas una fortuna... matando? :)"

# game/chapters/1_day.rpy:988
translate Spanish day1_afterfirstchoice_73410440:

    # GR "I Hate You. I Hate You So Much."
    GR "Te Odio. Te Odio Tanto."

# game/chapters/1_day.rpy:989
translate Spanish day1_afterfirstchoice_94c53a90:

    # GR "Stupid Mortal. "
    GR "Estúpid[letra] Mortal."

# game/chapters/1_day.rpy:990
translate Spanish day1_afterfirstchoice_cb46c63f:

    # GR "You Would Quiver Under My Gaze Before I Granted You Death."
    GR "Temblarías Bajo Mi Mirada Antes De Que Te Concediera La Muerte."

# game/chapters/1_day.rpy:993
translate Spanish day1_afterfirstchoice_4931e5f0:

    # player "I'm quivering just thinking about it."
    player "Estoy temblando solo de pensarlo."

# game/chapters/1_day.rpy:996
translate Spanish day1_afterfirstchoice_c16351ac:

    # player "Not in a weird way."
    player "No de una manera extraña."

# game/chapters/1_day.rpy:999
translate Spanish day1_afterfirstchoice_39d501a2:

    # player "Using the word 'quiver' was certainly a choice."
    player "Usar la palabra 'temblar' fue sin duda una elección deliberada."

# game/chapters/1_day.rpy:1002
translate Spanish day1_afterfirstchoice_a2ede373:

    # GR "I Would Like To See You Try To Insult Me To My Face!"
    GR "¡Me Gustaría Verte Intentar Insultarme A La Cara!"

# game/chapters/1_day.rpy:1006
translate Spanish day1_afterfirstchoice_ac3b3355:

    # player "Fine."
    player "Está bien."

# game/chapters/1_day.rpy:1009
translate Spanish day1_afterfirstchoice_079539a6:

    # player "Video call me, then."
    player "Hazme una videollamada, entonces."

# game/chapters/1_day.rpy:1012
translate Spanish day1_afterfirstchoice_0403cc8c:

    # player "Unless the little '{i}weaper{/i}' is too scared?"
    player "A menos que la '{i}parquita{/i}' tenga demasiado miedo..."

# game/chapters/1_day.rpy:1013
translate Spanish day1_afterfirstchoice_cc21bd84_1:

    # GR "!!!"
    GR "!!!"

# game/chapters/1_day.rpy:1014
translate Spanish day1_afterfirstchoice_5ce11c6d:

    # GR "I Am Never 'Scared'!"
    GR "¡Nunca Estoy 'Asustado'!"

# game/chapters/1_day.rpy:1017
translate Spanish day1_afterfirstchoice_9261d0ff:

    # player "You do type like that, though."
    player "Es que escribes así."

# game/chapters/1_day.rpy:1018
translate Spanish day1_afterfirstchoice_e9ab6f59:

    # GR "How So?"
    GR "¿De Qué Manera?"

# game/chapters/1_day.rpy:1021
translate Spanish day1_afterfirstchoice_9e50f511:

    # player "It's all kind of... edgy."
    player "Es todo como... edgy."

# game/chapters/1_day.rpy:1024
translate Spanish day1_afterfirstchoice_9bbc7309:

    # player "Every single thing you say."
    player "Cada una de tus palabras."

# game/chapters/1_day.rpy:1025
translate Spanish day1_afterfirstchoice_c798cc2d:

    # GR "I Am Not Edgy. I Am Death."
    GR "No Soy Edgy. Soy La Muerte."

# game/chapters/1_day.rpy:1028
translate Spanish day1_afterfirstchoice_e8a190d6:

    # player "See!"
    player "¡Mira!"

# game/chapters/1_day.rpy:1030
translate Spanish day1_afterfirstchoice_5ebd81f9:

    # player "You're just proving my point."
    player "Solo estás confirmando mi punto."

# game/chapters/1_day.rpy:1033
translate Spanish day1_afterfirstchoice_8a48bc20:

    # player "This is not how you pick up people, you know."
    player "Así no es como se seduce a la gente, ¿sabes?"

# game/chapters/1_day.rpy:1034
translate Spanish day1_afterfirstchoice_248749d0:

    # GR "I Am Picking Up Nobody!"
    GR "¡No Estoy Coqueteando Con Nadie!"

# game/chapters/1_day.rpy:1037
translate Spanish day1_afterfirstchoice_fab8dd6d:

    # player "Exactly."
    player "Exacto."

# game/chapters/1_day.rpy:1039
translate Spanish day1_afterfirstchoice_cd62d4de:

    # player "The fact that you admitted it..."
    player "El hecho de que lo hayas admitido..."

# game/chapters/1_day.rpy:1040
translate Spanish day1_afterfirstchoice_ac0f5412:

    # GR "The Only Thing I Wish to Pick Up Is Your Soul."
    GR "Lo Único Que Deseo Recoger Es Tu Alma."

# game/chapters/1_day.rpy:1043
translate Spanish day1_afterfirstchoice_ba592091:

    # player "I dunno... I'm kinda attached to it."
    player "No sé... Le tengo cierto cariño."

# game/chapters/1_day.rpy:1046
translate Spanish day1_afterfirstchoice_771d01cd:

    # player "Can't you take someone else's?" id day1_afterfirstchoice_771d01cd
    player "¿No puedes tomar la de otra persona?" id day1_afterfirstchoice_771d01cd

# game/chapters/1_day.rpy:1049
translate Spanish day1_afterfirstchoice_a8a44847:

    # player "Sorry, I'm gonna have to pass."
    player "Lo siento, voy a tener que pasar."

# game/chapters/1_day.rpy:1050
translate Spanish day1_afterfirstchoice_ee6f35b3:

    # GR "Passing Is Not An Option."
    GR "Pasar No Es Una Opción."

# game/chapters/1_day.rpy:1053
translate Spanish day1_afterfirstchoice_b586dc49:

    # player "What are you going to do about it?"
    player "¿Qué vas a hacer al respecto?"

# game/chapters/1_day.rpy:1054
translate Spanish day1_afterfirstchoice_7772a27d_6:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpy:1055
translate Spanish day1_afterfirstchoice_cc331cd9:

    # GR "It Seems You Aren't Understanding Exactly What's At Stake Here."
    GR "Parece Que No Estás Entendiendo Exactamente Lo Que Está En Juego Aquí."

# game/chapters/1_day.rpy:1056
translate Spanish day1_afterfirstchoice_86a416fc:

    # GR "Answer This At Once."
    GR "Responde A Esto Ahora Mismo."

# game/chapters/1_day.rpy:1090
translate Spanish call1_day1_2c346477:

    # GRC "Well?"
    GRC "¿Y bien?"

# game/chapters/1_day.rpy:1093
translate Spanish call1_day1_1b0379f8:

    # GRC "Anything to say for yourself?"
    GRC "¿Tienes algo que decir en tu defensa?"

# game/chapters/1_day.rpy:1103
translate Spanish call1_day1_99b5930d:

    # GRC "I am anything but 'scared' of facing a mortal such as yourself."
    GRC "No estoy en absoluto 'asustado' de enfrentarme a [arti_2] mortal como tú."

# game/chapters/1_day.rpy:1111
translate Spanish call1_day1_3243f032:

    # GRC "A lovely face, yet such a dirty mouth."
    GRC "Un rostro encantador, pero una boca tan sucia."

# game/chapters/1_day.rpy:1114
translate Spanish call1_day1_df7c292d:

    # GRC "Not only that, either. It seems you're all bark and no bite."
    GRC "Y no solo eso. Parece que ladras pero no muerdes."

# game/chapters/1_day.rpy:1118
translate Spanish call1_day1_85510b7d:

    # GRC "You're speechless."
    GRC "Te has quedado sin palabras."

# game/chapters/1_day.rpy:1119
translate Spanish call1_day1_52dbfbf9:

    # GRC "With a reaction like that, it seems my beauty has instantly captured you."
    GRC "Con una reacción como esa, parece que mi belleza te ha cautivado al instante."

# game/chapters/1_day.rpy:1121
translate Spanish call1_day1_aecd1113:

    # GRC "A fair reaction, I must admit. Mortals regularly desire that which they cannot have."
    GRC "Una reacción razonable, debo admitir. Los mortales suelen desear aquello que no pueden tener."

# game/chapters/1_day.rpy:1125
translate Spanish call1_day1_49675e11:

    # GRC "I don't remember saying that."
    GRC "No recuerdo haber dicho eso."

# game/chapters/1_day.rpy:1129
translate Spanish call1_day1_71d06dfb:

    # GRC "Unlikely. Take one look at yourself."
    GRC "Lo dudo. Mírate un poco."

# game/chapters/1_day.rpy:1136
translate Spanish call1_day1_f578e64e:

    # GRC "Hah."
    GRC "Ja."

# game/chapters/1_day.rpy:1151
translate Spanish call1_day1_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:1155
translate Spanish call1_day1_1bf24ed6:

    # GRC "I seem to have taken your breath away."
    GRC "Parece que te he dejado sin aliento."

# game/chapters/1_day.rpy:1157
translate Spanish call1_day1_42ba0254:

    # GRC "That much can be expected, I suppose."
    GRC "Es lo que se puede esperar, supongo."

# game/chapters/1_day.rpy:1158
translate Spanish call1_day1_9eef5e15:

    # GRC "I have often been called irresistible by your kind."
    GRC "A menudo los de tu especie me han llamado irresistible."

# game/chapters/1_day.rpy:1160
translate Spanish call1_day1_b21d53cf:

    # GRC "Before their souls are taken, of course."
    GRC "Antes de que les quite el alma, por supuesto."

# game/chapters/1_day.rpy:1165
translate Spanish call1_day1_b91ce0f9:

    # GRC "Oh, they talk? How quaint."
    GRC "Oh, ¿sabes hablar? Qué curioso."

# game/chapters/1_day.rpy:1167
translate Spanish call1_day1_42ad7dee:

    # GRC "And what {i}did{/i} you expect?"
    GRC "¿Y qué {i}esperabas{/i}?"

# game/chapters/1_day.rpy:1180
translate Spanish call1_day1_2f7744af:

    # GRC "Shadows and darkness... do you take me for a creature out of a fairytale?"
    GRC "Sombras y oscuridad... ¿me tomas por un personaje de cuento de hadas?"

# game/chapters/1_day.rpy:1186
translate Spanish call1_day1_d7ae7e2b:

    # GRC "Yes?"
    GRC "¿Sí?"

# game/chapters/1_day.rpy:1193
translate Spanish call1_day1_eeb77df2:

    # GRC "Excuse me?"
    GRC "¿Perdón?"

# game/chapters/1_day.rpy:1194
translate Spanish call1_day1_a73d403c:

    # GRC "Cute is {i}not{/i} a word I would use to describe myself."
    GRC "Lindo {i}no{/i} es una palabra que utilizaría para describirme."

# game/chapters/1_day.rpy:1195
translate Spanish call1_day1_a78c30c7:

    # GRC "Kittens are cute. Puppies are cute."
    GRC "Los gatitos son lindos. Los cachorros son lindos."

# game/chapters/1_day.rpy:1196
translate Spanish call1_day1_0d635938:

    # GRC "I am {i}not{/i} cute."
    GRC "Yo {i}no{/i} soy lindo."

# game/chapters/1_day.rpy:1200
translate Spanish call1_day1_6b17f8aa:

    # GRC "Devilishly handsome. Immaculate. Gorgeous."
    GRC "Diabólicamente guapo. Inmaculado. Precioso."

# game/chapters/1_day.rpy:1202
translate Spanish call1_day1_04cc0178:

    # GRC "Simply use your eyes and you'll see for yourself."
    GRC "Simplemente usa tus ojos y lo verás por ti mism[letra]."

# game/chapters/1_day.rpy:1205
translate Spanish call1_day1_70363630:

    # GRC "Obviously."
    GRC "Obviamente."

# game/chapters/1_day.rpy:1213
translate Spanish call1_day1_12b2a619:

    # GRC "Why would I waste my time doing that?"
    GRC "¿Por qué iba a perder el tiempo haciendo eso?"

# game/chapters/1_day.rpy:1216
translate Spanish call1_day1_5620369d:

    # GRC "Of course. Don't apply human logic to that which you don't understand."
    GRC "Por supuesto. No apliques la lógica humana a aquello que no entiendes."

# game/chapters/1_day.rpy:1218
translate Spanish call1_day1_30922fc5:

    # GRC "Or can you not help yourself? Perhaps your eyes cannot leave me."
    GRC "¿O no puedes evitarlo? Quizás tus ojos no pueden apartarse de mí."

# game/chapters/1_day.rpy:1222
translate Spanish call1_day1_89489d40:

    # GRC "I... am not cute!"
    GRC "¡Yo... no soy lindo!"

# game/chapters/1_day.rpy:1225
translate Spanish call1_day1_11da517e:

    # GRC "You are incorrect."
    GRC "Estás equivocad[letra]."

# game/chapters/1_day.rpy:1230
translate Spanish call1_day1_6fbe03f4:

    # GRC "No."
    GRC "No."

# game/chapters/1_day.rpy:1233
translate Spanish call1_day1_143e5704:

    # GRC "I never promised I would be fun."
    GRC "Nunca prometí que sería divertido."

# game/chapters/1_day.rpy:1237
translate Spanish call1_day1_f6f191bc:

    # GRC "As I said, you probably cannot help it."
    GRC "Como dije, probablemente no puedas evitarlo."

# game/chapters/1_day.rpy:1247
translate Spanish call1_day1_eeb77df2_1:

    # GRC "Excuse me?"
    GRC "¿Perdón?"

# game/chapters/1_day.rpy:1251
translate Spanish call1_day1_10fae8c3:

    # GRC "Mortal."
    GRC "Mortal."

# game/chapters/1_day.rpy:1252
translate Spanish call1_day1_382c29f1:

    # GRC "'Your' little reaper?"
    GRC "¿'Tu' parquita?"

# game/chapters/1_day.rpy:1253
translate Spanish call1_day1_8f3c9513:

    # GRC "Death belongs to no one, and everyone."
    GRC "La muerte no pertenece a nadie, y es de todos."

# game/chapters/1_day.rpy:1264
translate Spanish call1_day1_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:1265
translate Spanish call1_day1_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/1_day.rpy:1267
translate Spanish call1_day1_24970499:

    # GRC "Ahem."
    GRC "Ejem."

# game/chapters/1_day.rpy:1279
translate Spanish call1_day1_eeb77df2_2:

    # GRC "Excuse me?"
    GRC "¿Disculpa?"

# game/chapters/1_day.rpy:1286
translate Spanish call1_day1_8370d0dc:

    # GRC "As if a mortal could comprehend something as advanced as an aura."
    GRC "Como si un mortal pudiera comprender algo tan avanzado como un aura."

# game/chapters/1_day.rpy:1287
translate Spanish call1_day1_0719d3a8:

    # GRC "You're interesting, {i}human{/i}."
    GRC "Eres [arti_2] {i}human[letra]{/i} interesante."

# game/chapters/1_day.rpy:1288
translate Spanish call1_day1_a82fa2c2:

    # GRC "Interesting, but completely and utterly incorrect."
    GRC "Interesante, pero estás total y absolutamente equivocad[letra]."

# game/chapters/1_day.rpy:1292
translate Spanish call1_day1_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:1293
translate Spanish call1_day1_4fd5f215:

    # GRC "Stop saying that..."
    GRC "Deja de decir eso..."

# game/chapters/1_day.rpy:1294
translate Spanish call1_day1_abfdd9c4:

    # GRC "Anyway. Even if I was human, my aura would not be lacking."
    GRC "De todos modos, aunque fuera humano, mi aura no sería deficiente."

# game/chapters/1_day.rpy:1298
translate Spanish call1_day1_d88c721c:

    # GRC "Admit what?"
    GRC "¿Admitir qué?"

# game/chapters/1_day.rpy:1316
translate Spanish call1_day1_008afe10_3:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:1318
translate Spanish call1_day1_d19378d9:

    # GRC "How many times do I have to tell yo—"
    GRC "¿Cuántas veces tengo que decirte—"

# game/chapters/1_day.rpy:1331
translate Spanish call1_day1_0a2c4bf7:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/1_day.rpy:1340
translate Spanish call1_day1_85901163:

    # GRC "I'm simply surprised that you could be so naive."
    GRC "Simplemente me sorprende que puedas ser tan ingenu[letra]."

# game/chapters/1_day.rpy:1342
translate Spanish call1_day1_9ce19477:

    # GRC "I am the Grim Reaper, in charge of ferrying souls to their rightful afterlife."
    GRC "Soy la Parca, encargado de trasladar las almas al más allá que les corresponde."

# game/chapters/1_day.rpy:1361
translate Spanish call1_day1_be201dba:

    # GRC "You are truly insufferable."
    GRC "Eres realmente insufrible."

# game/chapters/1_day.rpy:1363
translate Spanish call1_day1_97b2df1d:

    # GRC "I am here for the sole purpose of harvesting your soul."
    GRC "Estoy aquí con el único propósito de segar tu alma."

# game/chapters/1_day.rpy:1364
translate Spanish call1_day1_9c2020df:

    # GRC "Your opinion on the matter hardly matters to me."
    GRC "Tu opinión sobre el tema me importa muy poco."

# game/chapters/1_day.rpy:1365
translate Spanish call1_day1_e3d9ae04:

    # GRC "Think what you want about me and my role."
    GRC "Piensa lo que quieras sobre mí y mi función."

# game/chapters/1_day.rpy:1366
translate Spanish call1_day1_f4a3fecc:

    # GRC "It changes nothing."
    GRC "No cambia nada."

# game/chapters/1_day.rpy:1378
translate Spanish call1_day1_008afe10_4:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:1379
translate Spanish call1_day1_9cafa0c7:

    # GRC "Desperate times call for desperate measures."
    GRC "Momentos desesperados requieren medidas desesperadas."

# game/chapters/1_day.rpy:1397
translate Spanish call1_day1_0673ce9a:

    # GRC "Romantic? I suppose it is."
    GRC "¿Romántico? Supongo que sí."

# game/chapters/1_day.rpy:1400
translate Spanish call1_day1_94722f37:

    # GRC "I would say there is something inherently romantic about death."
    GRC "Yo diría que hay algo intrínsecamente romántico en la muerte."

# game/chapters/1_day.rpy:1410
translate Spanish call1_day1_1bdfbe01:

    # GRC "Don't look at me like that."
    GRC "No me mires así."

# game/chapters/1_day.rpy:1417
translate Spanish call1_day1_346d4a1d:

    # GRC "It's not like I chose this fate for you."
    GRC "No es que yo haya elegido este destino para ti."

# game/chapters/1_day.rpy:1420
translate Spanish call1_day1_137b3463:

    # GRC "I'm just here to do the dirty work. Unfortunately."
    GRC "Solo estoy aquí para hacer el trabajo sucio. Por desgracia."

# game/chapters/1_day.rpy:1421
translate Spanish call1_day1_3df0ee5b:

    # GRC "Don't shoot the messenger, and all that."
    GRC "No culpes al mensajero, y esas cosas."

# game/chapters/1_day.rpy:1427
translate Spanish call1_day1_3be9a8ab:

    # GRC "What...?"
    GRC "¿Qué...?"

# game/chapters/1_day.rpy:1428
translate Spanish call1_day1_fd8760e1:

    # GRC "There is nothing to 'give up'."
    GRC "No hay nada a lo que 'rendirse'."

# game/chapters/1_day.rpy:1429
translate Spanish call1_day1_e4692631:

    # GRC "If anyone has something to give up, it is you."
    GRC "Si alguien tiene que rendirse, eres tú."

# game/chapters/1_day.rpy:1430
translate Spanish call1_day1_c08d1f06:

    # GRC "You need to work on your ability to listen, I believe."
    GRC "Creo que necesitas trabajar tu capacidad para escuchar."

# game/chapters/1_day.rpy:1433
translate Spanish call1_day1_d25edd0d:

    # GRC "I've been completely honest with you about what I want."
    GRC "He sido completamente honesto contigo sobre lo que quiero."

# game/chapters/1_day.rpy:1434
translate Spanish call1_day1_b07a0ba3:

    # GRC "You just refuse to listen."
    GRC "Simplemente te niegas a escuchar."

# game/chapters/1_day.rpy:1435
translate Spanish call1_day1_3d46595c:

    # GRC "Perhaps listening is a skill you could work on in the afterlife."
    GRC "Quizás escuchar sea una habilidad en la que podrías trabajar en la otra vida."

# game/chapters/1_day.rpy:1445
translate Spanish call1_day1_008afe10_5:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:1449
translate Spanish call1_day1_3b8e33af:

    # GRC "It would be unnecessary."
    GRC "Sería innecesario."

# game/chapters/1_day.rpy:1453
translate Spanish call1_day1_10bdcfdc:

    # GRC "It seems you do have some common sense \nburied in that head of yours."
    GRC "Parece que sí tienes algo de sentido común \nescondido en esa cabeza tuya."

# game/chapters/1_day.rpy:1467
translate Spanish call1_day1_6a5fc456:

    # GRC "Dear Lord, why did I get forced to deal with this one..."
    GRC "Dios mío, ¿por qué me obligaron a lidiar con alguien como tú...?"

# game/chapters/1_day.rpy:1471
translate Spanish call1_day1_6d2e0c42:

    # GRC "I have been one hundred percent truthful to you."
    GRC "He sido cien por ciento sincero contigo."

# game/chapters/1_day.rpy:1480
translate Spanish call1_day1_1942b5e4:

    # GRC "Sarcasm! Here I thought that was above your \nmortal mind."
    GRC "¡Sarcasmo! Y yo que pensaba que eso estaba por \nencima de tu mente mortal."

# game/chapters/1_day.rpy:1482
translate Spanish call1_day1_144fbf78:

    # GRC "Well done. I'm so impressed."
    GRC "Bien hecho. Estoy muy impresionado."

# game/chapters/1_day.rpy:1485
translate Spanish call1_day1_040d2302:

    # GRC "Really? How did you notice?"
    GRC "¿En serio? ¿Cómo te diste cuenta?"

# game/chapters/1_day.rpy:1486
translate Spanish call1_day1_e14a0f29:

    # GRC "You are truly infuriating, did you know that?"
    GRC "Eres realmente irritante, ¿lo sabías?"

# game/chapters/1_day.rpy:1490
translate Spanish call1_day1_372cfe9d:

    # GRC "It was not a compliment. Not even slightly."
    GRC "No era un cumplido. Ni siquiera un poco."

# game/chapters/1_day.rpy:1497
translate Spanish call1_day1_008afe10_6:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:1498
translate Spanish call1_day1_4b920f92:

    # GRC "How did I get lumped in with someone so annoying..."
    GRC "¿Cómo terminé con alguien tan molesto...?"

# game/chapters/1_day.rpy:1502
translate Spanish call1_day1_9810cdfa:

    # GRC "Bedroom eyes? Is that what you call that?"
    GRC "¿Ojos seductores? ¿Así es como lo llaman?"

# game/chapters/1_day.rpy:1504
translate Spanish call1_day1_97274eff:

    # GRC "Stop wiggling your eyebrows."
    GRC "Deja de mover las cejas."

# game/chapters/1_day.rpy:1505
translate Spanish call1_day1_a2e936bd:

    # GRC "You're just embarrassing yourself. I don't see how those are supposed to be bedroom eyes."
    GRC "Solo estás haciendo el ridículo. No veo cómo se supone que esa es una mirada seductora."

# game/chapters/1_day.rpy:1514
translate Spanish call1_day1_990cc387:

    # GRC "Heh."
    GRC "Je."

# game/chapters/1_day.rpy:1521
translate Spanish call1_day1_9d56cd5b:

    # GRC "You longingly gaze into your death? A soul after my own heart, it seems."
    GRC "¿Contemplas con anhelo tu muerte? Parece que tenemos algo en común."

# game/chapters/1_day.rpy:1526
translate Spanish call1_day1_ea99ec02:

    # GRC "Is that what that was supposed to be?"
    GRC "¿Eso era lo que intentabas hacer?"

# game/chapters/1_day.rpy:1530
translate Spanish call1_day1_6a21dccb:

    # GRC "Haaaa..."
    GRC "Haaaa..."

# game/chapters/1_day.rpy:1532
translate Spanish call1_day1_f44d9a82:

    # GRC "What did I do wrong in my past life to get stuck with you?"
    GRC "¿Qué hice mal en mi vida pasada para quedarme atrapado contigo?"

# game/chapters/1_day.rpy:1537
translate Spanish call1_day1_f2376f40:

    # GRC "You were supposed to."
    GRC "Se suponía que debías hacerlo."

# game/chapters/1_day.rpy:1541
translate Spanish call1_day1_f51c4738:

    # GRC "I didn't whisper it, did I?"
    GRC "No lo susurré, ¿verdad?"

# game/chapters/1_day.rpy:1558
translate Spanish call1_day1_9238e1d9:

    # GRC "What is {i}weird ass{/i} about my typing?"
    GRC "¿Qué tiene de {i}rara{/i} mi forma de escribir?"

# game/chapters/1_day.rpy:1562
translate Spanish call1_day1_938b1a85:

    # GRC "Explain yourself."
    GRC "Explícate."

# game/chapters/1_day.rpy:1569
translate Spanish call1_day1_0808f84a:

    # GRC "Yes, I know what capital letters are. I am not brainless, like yourself."
    GRC "Sí, sé lo que son las letras mayúsculas. No soy tonto, como tú."

# game/chapters/1_day.rpy:1570
translate Spanish call1_day1_59505b78:

    # GRC "I was using them, was I not?"
    GRC "Las estaba usando, ¿o no?"

# game/chapters/1_day.rpy:1577
translate Spanish call1_day1_3be8bce7:

    # GRC "What are you talking about, mortal?"
    GRC "¿De qué estás hablando, mortal?"

# game/chapters/1_day.rpy:1584
translate Spanish call1_day1_008afe10_7:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:1588
translate Spanish call1_day1_ae7b5860:

    # GRC "What in the nine circles of hell is a homestuck?"
    GRC "¿Por los nueve círculos del infierno, qué es un Homestuck?"

# game/chapters/1_day.rpy:1595
translate Spanish call1_day1_b2ff9d9b:

    # GRC "What is it? I demand an answer."
    GRC "¿Qué es eso? Exijo una respuesta."

# game/chapters/1_day.rpy:1602
translate Spanish call1_day1_0f4cb13c:

    # GRC "What about my typing is so confusing to you?"
    GRC "¿Qué tiene de confuso mi forma de escribir?"

# game/chapters/1_day.rpy:1609
translate Spanish call1_day1_0c480906:

    # GRC "Is that not common?"
    GRC "¿Acaso eso es normal?"

# game/chapters/1_day.rpy:1616
translate Spanish call1_day1_ffd43f9f:

    # GRC "You mean to tell me..."
    GRC "Quieres decirme..."

# game/chapters/1_day.rpy:1623
translate Spanish call1_day1_e9261f9c:

    # GRC "...I do not type correctly..."
    GRC "...Que no escribo correctamente..."

# game/chapters/1_day.rpy:1637
translate Spanish call1_day1_8b295c59:

    # GRC "How embarrassing..."
    GRC "Qué vergüenza..."

# game/chapters/1_day.rpy:1639
translate Spanish call1_day1_e9261f9c_1:

    # GRC "...I do not type correctly..."
    GRC "...No escribo bien..."

# game/chapters/1_day.rpy:1657
translate Spanish chat2_day1_e65f67ea:

    # player "What? What did you hang up for?"
    player "¿Qué? ¿Por qué colgaste?"

# game/chapters/1_day.rpy:1660
translate Spanish chat2_day1_864e88dc:

    # player "Hello?"
    player "¿Hola?"

# game/chapters/1_day.rpy:1662
translate Spanish chat2_day1_f2b91653:

    # player "Little reaper?"
    player "¿Parquita?"

# game/chapters/1_day.rpy:1665
translate Spanish chat2_day1_dfb65ca6:

    # player "Come on, I was finally having fun."
    player "Vamos, por fin me estaba divirtiendo."

# game/chapters/1_day.rpy:1666
translate Spanish chat2_day1_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpy:1669
translate Spanish chat2_day1_79edb30e:

    # player "Why'd you leave the call?"
    player "¿Por qué colgaste la llamada?"

# game/chapters/1_day.rpy:1670
translate Spanish chat2_day1_f51cd733:

    # GR "there is no particular reason."
    GR "no hay ninguna razón en particular."

# game/chapters/1_day.rpy:1671
translate Spanish chat2_day1_884d288e:

    # GR "none whatsoever."
    GR "ninguna en absoluto."

# game/chapters/1_day.rpy:1674
translate Spanish chat2_day1_f47f0c8b:

    # player "Um... I'm not trying to make fun of you or anything, but..."
    player "Um... No estoy tratando de burlarme de ti ni nada, pero..."

# game/chapters/1_day.rpy:1677
translate Spanish chat2_day1_fa420041:

    # player "It's still not right (lol)..."
    player "Sigue sin estar bien (lol)..."

# game/chapters/1_day.rpy:1678
translate Spanish chat2_day1_7772a27d_1:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpy:1679
translate Spanish chat2_day1_7772a27d_2:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpy:1681
translate Spanish chat2_day1_8a4f36a0:

    # player "That's wrong, too..."
    player "Eso también está mal..."

# game/chapters/1_day.rpy:1682
translate Spanish chat2_day1_7772a27d_3:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpy:1683
translate Spanish chat2_day1_7772a27d_4:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpy:1686
translate Spanish chat2_day1_5b8d36a4:

    # player "I guess I'll go, then."
    player "Supongo que me iré, entonces."

# game/chapters/1_day.rpy:1688
translate Spanish chat2_day1_315e1a38:

    # player "Well if you have nothing to say..."
    player "Bueno, si no tienes nada que decir..."

# game/chapters/1_day.rpy:1691
translate Spanish chat2_day1_209ae5db:

    # player "Guess I'll head to bed."
    player "Creo que me voy a la cama."

# game/chapters/1_day.rpy:1693
translate Spanish chat2_day1_3fcaecaf:

    # player "Don't Wanna Chat With Me Anymore, Little Reaper?"
    player "¿Ya No Quieres Charlar Conmigo, Parquita?"

# game/chapters/1_day.rpy:1694
translate Spanish chat2_day1_383a19ee:

    # GR "i have no clue why you're typing like that."
    GR "no tengo ni idea de por qué escribes así."

# game/chapters/1_day.rpy:1695
translate Spanish chat2_day1_775963c1:

    # GR "it is obviously incorrect."
    GR "obviamente es incorrecto."

# game/chapters/1_day.rpy:1696
translate Spanish chat2_day1_70f76c7e:

    # GR "who would type with so many capital letters? absurd."
    GR "¿quién escribiría con tantas letras mayúsculas? es absurdo."

# game/chapters/1_day.rpy:1697
translate Spanish chat2_day1_215eda05:

    # GR "you should be embarrassed."
    GR "deberías sentir vergüenza."

# game/chapters/1_day.rpy:1698
translate Spanish chat2_day1_0b16bee0:

    # GR "ahem."
    GR "ejem."

# game/chapters/1_day.rpy:1726
translate Spanish call2_day1_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:1750
translate Spanish call2_day1_a6295b63:

    # GRC "I... am not 'little'."
    GRC "Yo... no soy 'pequeño'."

# game/chapters/1_day.rpy:1751
translate Spanish call2_day1_f3da69c8:

    # GRC "No part of me is!"
    GRC "¡Ninguna parte de mí lo es!"

# game/chapters/1_day.rpy:1756
translate Spanish call2_day1_0bac6bac:

    # GRC "......."
    GRC "......."

# game/chapters/1_day.rpy:1764
translate Spanish call2_day1_0f3a0c34:

    # GRC "Shut up..."
    GRC "Cállate..."

# game/chapters/1_day.rpy:1766
translate Spanish call2_day1_8cf301cb:

    # GRC "The way I type is unimportant to the matter at hand."
    GRC "La forma en la que escribo no es relevante para el tema que nos ocupa."

# game/chapters/1_day.rpy:1767
translate Spanish call2_day1_9e51cc19:

    # GRC "Just hand over the soul so we can be done with this."
    GRC "Solo entrega tu alma para que podamos terminar con esto."

# game/chapters/1_day.rpy:1771
translate Spanish call2_day1_0f2bae23:

    # GRC "No, mortal."
    GRC "No, mortal."

# game/chapters/1_day.rpy:1773
translate Spanish call2_day1_1efebc26:

    # GRC "There is no moving on until the deed is done."
    GRC "No se puede seguir adelante mientras no se haga lo que hay que hacer."

# game/chapters/1_day.rpy:1800
translate Spanish call2_day1_625791f5:

    # GRC "Do I look like a myth to you?"
    GRC "¿Parezco un mito para ti?"

# game/chapters/1_day.rpy:1811
translate Spanish call2_day1_793bf1ae:

    # GRC "And I'm telling you, I'm quite literally—"
    GRC "Y te lo digo, soy literalmente—"

# game/chapters/1_day.rpy:1828
translate Spanish call2_day1_d274607d:

    # GRC "A bet?"
    GRC "¿Una apuesta?"

# game/chapters/1_day.rpy:1831
translate Spanish call2_day1_f2abe32e:

    # GRC "You have my attention."
    GRC "Tienes mi atención."

# game/chapters/1_day.rpy:1840
translate Spanish call2_day1_dc34c302:

    # GRC "Continue."
    GRC "Continúa."

# game/chapters/1_day.rpy:1847
translate Spanish call2_day1_804c1377:

    # GRC "Correct. I have taken many souls."
    GRC "Correcto. He tomado muchas almas."

# game/chapters/1_day.rpy:1851
translate Spanish call2_day1_d7b7a711:

    # GRC "Oh? Intriguing."
    GRC "¿Oh? Intrigante."

# game/chapters/1_day.rpy:1878
translate Spanish call2_day1_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:1891
translate Spanish call2_day1_282f4779:

    # GRC "And take it I shall."
    GRC "Y la tomaré."

# game/chapters/1_day.rpy:1910
translate Spanish call2_day1_6890af83:

    # GRC "A week? You shouldn't underestimate me."
    GRC "¿Una semana? No deberías subestimarme."

# game/chapters/1_day.rpy:1912
translate Spanish call2_day1_c3cb5ac3:

    # GRC "I need only a day. An hour."
    GRC "Solo necesito un día. Una hora."

# game/chapters/1_day.rpy:1927
translate Spanish call2_day1_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:1928
translate Spanish call2_day1_25eec6b4:

    # GRC "Fine."
    GRC "Está bien."

# game/chapters/1_day.rpy:1930
translate Spanish call2_day1_68caee4c:

    # GRC "A week it shall be."
    GRC "Será una semana."

# game/chapters/1_day.rpy:1931
translate Spanish call2_day1_4bf74016:

    # GRC "I am honor bound by my very soul to accept the outcome of such a deal." id call2_day1_4bf74016
    GRC "Me siento obligado por mi honor y mi alma a aceptar el resultado de tal acuerdo." id call2_day1_4bf74016

# game/chapters/1_day.rpy:1938
translate Spanish call2_day1_6853ac46:

    # GRC "That remains to be seen."
    GRC "Eso está por verse."

# game/chapters/1_day.rpy:1945
translate Spanish call2_day1_e9acf97b:

    # GRC "What do you ask for?"
    GRC "¿Qué pides?"

# game/chapters/1_day.rpy:1953
translate Spanish call2_day1_da27a049:

    # GRC "My... soul?"
    GRC "¿Mi... alma?"

# game/chapters/1_day.rpy:1954
translate Spanish call2_day1_8a9d8e97:

    # GRC "I suppose... that makes it fair."
    GRC "Supongo... que eso lo hace justo."

# game/chapters/1_day.rpy:1955
translate Spanish call2_day1_6a0293cc:

    # GRC "I hadn't expected that anyone would ever come after my own soul, I must admit."
    GRC "Debo admitir que nunca imaginé que alguien vendría por mi alma."

# game/chapters/1_day.rpy:1961
translate Spanish call2_day1_d0db0967:

    # GRC "My... what?"
    GRC "¿Mi... qué?"

# game/chapters/1_day.rpy:1962
translate Spanish call2_day1_f383e2a2:

    # GRC "Why in the hells would you want that?"
    GRC "¿Por qué demonios ibas a querer eso?"

# game/chapters/1_day.rpy:1966
translate Spanish call2_day1_e47cd8b0:

    # GRC "Er, yes."
    GRC "Eh, sí."

# game/chapters/1_day.rpy:1970
translate Spanish call2_day1_d9c46b02:

    # GRC "Um... yes, I guess so...?"
    GRC "Um... ¿sí, supongo que sí...?"

# game/chapters/1_day.rpy:1987
translate Spanish call2_day1_3a37b31e:

    # GRC "That... seems fair."
    GRC "Eso... parece justo."

# game/chapters/1_day.rpy:1993
translate Spanish call2_day1_f578e64e:

    # GRC "Hah."
    GRC "Ja."

# game/chapters/1_day.rpy:1994
translate Spanish call2_day1_e96d36a8:

    # GRC "Mortal, I am scared of nothing."
    GRC "Mortal, no le temo a nada."

# game/chapters/1_day.rpy:2001
translate Spanish call2_day1_008afe10_3:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:2003
translate Spanish call2_day1_53f67e0c:

    # GRC "Ahem!"
    GRC "¡Ejem!"

# game/chapters/1_day.rpy:2005
translate Spanish call2_day1_47d3e691:

    # GRC "I agree to your deal."
    GRC "Acepto tu trato."

# game/chapters/1_day.rpy:2006
translate Spanish call2_day1_4eab4017:

    # GRC "If I cannot take your soul in the next week, then my soul shall belong to you."
    GRC "Si no puedo tomar tu alma en la próxima semana, entonces mi alma te pertenecerá."

# game/chapters/1_day.rpy:2013
translate Spanish call2_day1_43fe0693:

    # GRC "...Out of interest, what do you plan to do with it...?"
    GRC "...Por curiosidad, ¿qué piensas hacer con ella...?"

# game/chapters/1_day.rpy:2020
translate Spanish call2_day1_a07ae720:

    # GRC "Eat it?!"
    GRC "¡¿Comértela?!"

# game/chapters/1_day.rpy:2027
translate Spanish call2_day1_19908011:

    # GRC "That is a {i}cat{/i} you are thinking of."
    GRC "En lo que estás pensando es en un {i}gato{/i}."

# game/chapters/1_day.rpy:2031
translate Spanish call2_day1_7dd3bdba:

    # GRC "Why do humans make such ridiculous assumptions?"
    GRC "¿Por qué los humanos hacen suposiciones tan ridículas?"

# game/chapters/1_day.rpy:2041
translate Spanish call2_day1_008afe10_4:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:2042
translate Spanish call2_day1_dff64f19:

    # GRC "{i}You{/i} cannot even see a soul, let alone turn one into some kind of..."
    GRC "{i}Tú{/i} ni siquiera puedes ver un alma, y mucho menos convertirla en una especie de..."

# game/chapters/1_day.rpy:2044
translate Spanish call2_day1_7182bc03:

    # GRC "Soul smoothie."
    GRC "Batido de almas."

# game/chapters/1_day.rpy:2045
translate Spanish call2_day1_a52808cf:

    # GRC "I shouldn't have bothered asking you, honestly."
    GRC "Sinceramente, no debería haberme molestado en preguntarte."

# game/chapters/1_day.rpy:2047
translate Spanish call2_day1_07f23401:

    # GRC "I feel like that's on me."
    GRC "Siento que eso es culpa mía."

# game/chapters/1_day.rpy:2055
translate Spanish call2_day1_7572788b:

    # GRC "What nonsense are you spouting now?"
    GRC "¿Qué tonterías estás diciendo ahora?"

# game/chapters/1_day.rpy:2059
translate Spanish call2_day1_c732b942:

    # GRC "I heard what you said."
    GRC "Oí lo que dijiste."

# game/chapters/1_day.rpy:2061
translate Spanish call2_day1_7d556020:

    # GRC "I was honestly hoping I heard you wrong."
    GRC "Sinceramente, esperaba haberte escuchado mal."

# game/chapters/1_day.rpy:2065
translate Spanish call2_day1_2243608f:

    # GRC "Putting aside the fact that what you said is impossible..."
    GRC "Dejando de lado el hecho de que lo que dices es imposible..."

# game/chapters/1_day.rpy:2067
translate Spanish call2_day1_b39aca54:

    # GRC "I am {i}not{/i} ready to be a father."
    GRC "{i}No{/i} estoy listo para ser padre."

# game/chapters/1_day.rpy:2074
translate Spanish call2_day1_e8a6b4ce:

    # GRC "We absolutely will not be doing that."
    GRC "Definitivamente no haremos eso."

# game/chapters/1_day.rpy:2076
translate Spanish call2_day1_4d91f639:

    # GRC "It is of little concern, seeing as you will soon be yielding your soul to me."
    GRC "No tiene mayor importancia, considerando que pronto me entregarás tu alma."

# game/chapters/1_day.rpy:2083
translate Spanish call2_day1_b0775fc2:

    # GRC "For some reason that is just as strange."
    GRC "Por alguna razón, eso es igual de extraño."

# game/chapters/1_day.rpy:2087
translate Spanish call2_day1_8a4d38cc:

    # GRC "I suppose it's of little consequence."
    GRC "Supongo que no tiene mucha importancia."

# game/chapters/1_day.rpy:2089
translate Spanish call2_day1_a7dd6d6a:

    # GRC "You won't be getting it."
    GRC "No la vas a obtener."

# game/chapters/1_day.rpy:2092
translate Spanish call2_day1_9462be29:

    # GRC "Are you really that dim?"
    GRC "¿De verdad eres tan lent[letra]?"

# game/chapters/1_day.rpy:2094
translate Spanish call2_day1_cca579cd:

    # GRC "Of course I do. You have no hope."
    GRC "Claro que sí. No tienes ninguna esperanza."

# game/chapters/1_day.rpy:2096
translate Spanish call2_day1_44eedd45:

    # GRC "Perhaps you should save us all some time and give up already."
    GRC "Quizás deberías ahorrarnos tiempo a todos y rendirte ya."

# game/chapters/1_day.rpy:2107
translate Spanish call2_day1_c86a5b29:

    # GRC "Keep telling yourself that, mortal."
    GRC "Sigue repitiéndote eso, mortal."

# game/chapters/1_day.rpy:2109
translate Spanish call2_day1_8001ee91:

    # GRC "Your soul will be my ultimate prize."
    GRC "Tu alma será mi mayor recompensa."

# game/chapters/1_day.rpy:2110
translate Spanish call2_day1_a13b939f:

    # GRC "It will yield itself to me, and it will be beautiful."
    GRC "Se entregará a mí por voluntad propia, y será algo hermoso."

# game/chapters/1_day.rpy:2114
translate Spanish call2_day1_937991e6:

    # GRC "Taking a soul is never morbid."
    GRC "Apoderarse de un alma nunca es algo perturbador."

# game/chapters/1_day.rpy:2124
translate Spanish call2_day1_07ab7154:

    # GRC "...What?"
    GRC "...¿Qué?"

# game/chapters/1_day.rpy:2135
translate Spanish call2_day1_0e8fbc1b:

    # GRC "It's not a date!"
    GRC "¡No es una cita!"

# game/chapters/1_day.rpy:2142
translate Spanish call2_day1_6028f2d1:

    # GRC "I never lose."
    GRC "Nunca pierdo."

# game/chapters/1_day.rpy:2153
translate Spanish call2_day1_389380ee:

    # GRC "So, the human has a sadistic streak."
    GRC "Así que [arti] human[letra] tiene una faceta sádica."

# game/chapters/1_day.rpy:2161
translate Spanish call2_day1_a1b92933:

    # GRC "You really know how to get under my skin."
    GRC "Realmente sabes cómo sacarme de quicio."

# game/chapters/1_day.rpy:2165
translate Spanish call2_day1_91330efa:

    # GRC "Ugh..."
    GRC "Ugh..."

# game/chapters/1_day.rpy:2169
translate Spanish call2_day1_92077c20:

    # GRC "Just... stop talking, please."
    GRC "Solo... deja de hablar, por favor."

# game/chapters/1_day.rpy:2171
translate Spanish call2_day1_b9e66a0d:

    # GRC "Your voice is beginning to grate me."
    GRC "Tu voz está empezando a molestarme."

# game/chapters/1_day.rpy:2185
translate Spanish call2_day1_008afe10_5:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:2187
translate Spanish call2_day1_e48115d3:

    # GRC "You are the bane of my existence."
    GRC "Eres la pesadilla de mi vida."

# game/chapters/1_day.rpy:2191
translate Spanish call2_day1_4bd7a111:

    # GRC "You are... nothing special whatsoever!"
    GRC "¡No eres... nada especial en absoluto!"

# game/chapters/1_day.rpy:2195
translate Spanish call2_day1_ac37972a:

    # GRC "We will not."
    GRC "No lo haremos."

# game/chapters/1_day.rpy:2199
translate Spanish call2_day1_85fe5a7f:

    # GRC "Stop twisting my words to suit yourself, mortal."
    GRC "Deja de tergiversar mis palabras para que te convengan, mortal."

# game/chapters/1_day.rpy:2203
translate Spanish call2_day1_6716afc7:

    # GRC "How did it come to this..."
    GRC "¿Cómo terminé en esta situación...?"

# game/chapters/1_day.rpy:2213
translate Spanish call2_day1_64d5125b:

    # GRC "This would have taken much less time if you had done as you were told."
    GRC "Esto habría llevado mucho menos tiempo si hubieras hecho lo que se te dijo."

# game/chapters/1_day.rpy:2217
translate Spanish call2_day1_32f44438:

    # GRC "Yes."
    GRC "Sí."

# game/chapters/1_day.rpy:2221
translate Spanish call2_day1_f24fdf68:

    # GRC "Well, perhaps you should."
    GRC "Bueno, quizás deberías."

# game/chapters/1_day.rpy:2224
translate Spanish call2_day1_b4ce3d52:

    # GRC "Somehow I doubt that."
    GRC "De alguna manera lo dudo."

# game/chapters/1_day.rpy:2225
translate Spanish call2_day1_1e5beb9b:

    # GRC "Next time, be a little more cooperative."
    GRC "La próxima vez, sé tan amable de cooperar un poco más."

# game/chapters/1_day.rpy:2231
translate Spanish call2_day1_b261ab05:

    # GRC "And if I asked you to hand over your soul again...?"
    GRC "¿Y si te pidiera que me entregaras tu alma otra vez...?"

# game/chapters/1_day.rpy:2242
translate Spanish call2_day1_c3dd6370:

    # GRC "Is this more of your so-called flirting?"
    GRC "¿Es esto más de tu supuesto coqueteo?"

# game/chapters/1_day.rpy:2243
translate Spanish call2_day1_083562fa:

    # GRC "It is lacking."
    GRC "Es insuficiente."

# game/chapters/1_day.rpy:2247
translate Spanish call2_day1_b7094880:

    # GRC "Mortal, you know nothing about me."
    GRC "Mortal, no sabes nada sobre mí."

# game/chapters/1_day.rpy:2248
translate Spanish call2_day1_119c12db:

    # GRC "And it shall stay that way."
    GRC "Y así seguirá siendo."

# game/chapters/1_day.rpy:2256
translate Spanish call2_day1_40b57ed9:

    # GRC "I {i}am{/i} the reaper. And that is all you will find out."
    GRC "Yo {i}soy{/i} la parca. Y eso es todo lo que sabrás."

# game/chapters/1_day.rpy:2260
translate Spanish call2_day1_0c459089:

    # GRC "No we will not."
    GRC "No, no lo haremos."

# game/chapters/1_day.rpy:2264
translate Spanish call2_day1_f6e68b39:

    # GRC "Of course I would, that's what I just told you."
    GRC "Por supuesto que sí, eso es lo que acabo de decirte."

# game/chapters/1_day.rpy:2270
translate Spanish call2_day1_3c1fd32e:

    # GRC "What is there to be confused about?"
    GRC "¿Qué tiene de confuso?"

# game/chapters/1_day.rpy:2272
translate Spanish call2_day1_ae5c1d5c:

    # GRC "Oh. Right."
    GRC "Oh. Cierto."

# game/chapters/1_day.rpy:2273
translate Spanish call2_day1_ec3c55be:

    # GRC "I see your mind has wandered into mortal fantasies."
    GRC "Veo que tu mente se ha perdido en fantasías mortales."

# game/chapters/1_day.rpy:2280
translate Spanish call2_day1_cdbc37f5:

    # GRC "I'm simply stating it would make my job easier."
    GRC "Simplemente digo que me facilitaría el trabajo."

# game/chapters/1_day.rpy:2287
translate Spanish call2_day1_ccf8442b:

    # GRC "Dealing with you certainly isn't."
    GRC "Tratar contigo ciertamente no lo es."

# game/chapters/1_day.rpy:2291
translate Spanish call2_day1_758b546f:

    # GRC "I disagree."
    GRC "No estoy de acuerdo."

# game/chapters/1_day.rpy:2295
translate Spanish call2_day1_b65da2d2:

    # GRC "I very strongly disagree."
    GRC "Estoy muy en desacuerdo."

# game/chapters/1_day.rpy:2299
translate Spanish call2_day1_3eb0aeda:

    # GRC "I'm disagreeing so hard that I could win some \nkind of award for the most someone has ever disagreed with a statement."
    GRC "Estoy tan en desacuerdo que podría ganar algún \ntipo de premio al mayor desacuerdo jamás expresado con respecto a una afirmación."

# game/chapters/1_day.rpy:2309
translate Spanish call2_day1_a01d3d13:

    # GRC "Absolutely not."
    GRC "Absolutamente no."

# game/chapters/1_day.rpy:2313
translate Spanish call2_day1_f4e2e0dd:

    # GRC "Somehow I knew you would respond like that."
    GRC "De alguna manera sabía que responderías así."

# game/chapters/1_day.rpy:2314
translate Spanish call2_day1_7a7dc1c8:

    # GRC "You really are ever so difficult."
    GRC "Eres realmente muy difícil."

# game/chapters/1_day.rpy:2319
translate Spanish call2_day1_f21effae:

    # GRC "Or you could refrain from being so... troublesome."
    GRC "O podrías dejar de crear tantos... problemas."

# game/chapters/1_day.rpy:2322
translate Spanish call2_day1_8007eaa2:

    # GRC "My job is never easy."
    GRC "Mi trabajo nunca es fácil."

# game/chapters/1_day.rpy:2324
translate Spanish call2_day1_ebc82d37:

    # GRC "Though it is also not usually this difficult."
    GRC "Aunque tampoco suele ser tan difícil como esto."

# game/chapters/1_day.rpy:2328
translate Spanish call2_day1_a6be069a:

    # GRC "Don't flatter yourself."
    GRC "No te hagas ilusiones."

# game/chapters/1_day.rpy:2329
translate Spanish call2_day1_d590c85c:

    # GRC "Being difficult does not make you important."
    GRC "Ser difícil no te hace importante."

# game/chapters/1_day.rpy:2333
translate Spanish call2_day1_6d74b146:

    # GRC "Special? You? That remains to be seen."
    GRC "¿Especial? ¿Tú? Eso aún está por verse."

# game/chapters/1_day.rpy:2334
translate Spanish call2_day1_900c7156:

    # GRC "At the moment you are just a pain in my side."
    GRC "En este momento solo eres un dolor de cabeza para mí."

# game/chapters/1_day.rpy:2339
translate Spanish call2_day1_008afe10_6:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:2340
translate Spanish call2_day1_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/1_day.rpy:2347
translate Spanish call2_day1_b637bcf9:

    # GRC "Preposterous."
    GRC "¡Absurdo!"

# game/chapters/1_day.rpy:2351
translate Spanish call2_day1_0a2c4bf7:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/1_day.rpy:2352
translate Spanish call2_day1_f0503631:

    # GRC "I... I definitely am not agreeing!"
    GRC "¡Yo... definitivamente no estoy de acuerdo!"

# game/chapters/1_day.rpy:2355
translate Spanish call2_day1_e650137a:

    # GRC "What makes you think I want someone to boss me around?"
    GRC "¿Qué te hace pensar que quiero que alguien me dé órdenes?"

# game/chapters/1_day.rpy:2359
translate Spanish call2_day1_87a7d50d:

    # GRC "Lost... puppy vibes?"
    GRC "¿Vibra de cachorro perdido?"

# game/chapters/1_day.rpy:2360
translate Spanish call2_day1_1a2b5d27:

    # GRC "How so?"
    GRC "¿A qué te refieres?"

# game/chapters/1_day.rpy:2374
translate Spanish call2_day1_0c2759da:

    # GRC "The... the WHAT?"
    GRC "¿El... el QUÉ?"

# game/chapters/1_day.rpy:2375
translate Spanish call2_day1_65122790_1:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/1_day.rpy:2376
translate Spanish call2_day1_9b7d4b85:

    # GRC "I am... a Grim Reaper. A GRIM REAPER."
    GRC "Soy... una Parca. ¡UNA PARCA!"

# game/chapters/1_day.rpy:2378
translate Spanish call2_day1_a607ee7b:

    # GRC "What about that makes me submissive?!"
    GRC "¿¡Qué hay en eso que me hace sumiso?!"

# game/chapters/1_day.rpy:2379
translate Spanish call2_day1_dd112d3b:

    # GRC "I am literally domineering! It is in my job description!"
    GRC "¡Soy literalmente dominante! ¡Está en la descripción de mi trabajo!"

# game/chapters/1_day.rpy:2390
translate Spanish call2_day1_0b084266:

    # GRC "And what if I don't do what you tell me to do?"
    GRC "¿Y si no hago lo que me dices que haga?"

# game/chapters/1_day.rpy:2404
translate Spanish call2_day1_55bdc250:

    # GRC "......"
    GRC "......"

# game/chapters/1_day.rpy:2409
translate Spanish call2_day1_403d04be:

    # GRC "You know what?"
    GRC "¿Sabes qué?"

# game/chapters/1_day.rpy:2410
translate Spanish call2_day1_4e502785:

    # GRC "Mortal, you are dismissed."
    GRC "Mortal, puedes retirarte."

# game/chapters/1_day.rpy:2419
translate Spanish call2_day1_a52dcb2a:

    # GRC "Do you not understand the word?"
    GRC "¿No entiendes la palabra?"

# game/chapters/1_day.rpy:2420
translate Spanish call2_day1_4508fa37:

    # GRC "You can go. Please."
    GRC "Puedes irte. Por favor."

# game/chapters/1_day.rpy:2424
translate Spanish call2_day1_356f27bd:

    # GRC "Yes, I usually have that effect on people."
    GRC "Sí, suelo causar ese efecto en la gente."

# game/chapters/1_day.rpy:2426
translate Spanish call2_day1_e987ea49:

    # GRC "But it is time for you to get your due rest."
    GRC "Pero es hora de que te tomes el descanso que te mereces."

# game/chapters/1_day.rpy:2429
translate Spanish call2_day1_cc50bc1a:

    # GRC "Then we could sit here all night chatting."
    GRC "Entonces podríamos quedarnos aquí toda la noche charlando."

# game/chapters/1_day.rpy:2430
translate Spanish call2_day1_68a9f86f:

    # GRC "I'm sure you would enjoy that."
    GRC "Estoy seguro de que lo disfrutarías."

# game/chapters/1_day.rpy:2433
translate Spanish call2_day1_43baa420:

    # GRC "Good. It is time for you to rest."
    GRC "Bien. Es hora de que descanses."

# game/chapters/1_day.rpy:2439
translate Spanish call2_day1_4ac61850:

    # GRC "You'll need your rest, else our competition won't be as fun."
    GRC "Necesitarás descansar, de lo contrario nuestra competencia no será tan divertida."

# game/chapters/1_day.rpy:2443
translate Spanish call2_day1_008afe10_7:

    # GRC "..."
    GRC "..."

# game/chapters/1_day.rpy:2447
translate Spanish call2_day1_f79678dc:

    # GRC "Sleep well, [playerfirstname]."
    GRC "Duerme bien, [playerfirstname]."

# game/chapters/1_day.rpy:2469
translate Spanish chat3_day1_755c70f2:

    # player "Hey, wait a second..."
    player "Oye, espera un segundo..."

# game/chapters/1_day.rpy:2472
translate Spanish chat3_day1_ebb4b119:

    # player "How did you know my name?"
    player "¿Cómo supiste mi nombre?"

# game/chapters/1_day.rpy:2473
translate Spanish chat3_day1_1e97ab72:

    # GR "how indeed."
    GR "quién sabe."

# game/chapters/1_day.rpy:2476
translate Spanish chat3_day1_c2d7dd9c:

    # player "I never told you!"
    player "¡Nunca te lo dije!"

# game/chapters/1_day.rpy:2477
translate Spanish chat3_day1_5d7104e6:

    # GR "wow, i wonder how exactly i could have known, then."
    GR "wow, me pregunto cómo exactamente podría haberlo sabido."

# game/chapters/1_day.rpy:2478
translate Spanish chat3_day1_2114d1c4:

    # GR "it's not like i have a big list sitting in front of me with your name circled at the bottom."
    GR "no es que tenga una gran lista delante de mí con tu nombre marcado con un círculo al final."

# game/chapters/1_day.rpy:2481
translate Spanish chat3_day1_54eadd4a:

    # player "Aw, you circled it?"
    player "Aw, ¿lo marcaste con un círculo?"

# game/chapters/1_day.rpy:2482
translate Spanish chat3_day1_5124b3f0:

    # GR "good. night."
    GR "bien. buenas noches."

# game/chapters/1_day.rpy:2485
translate Spanish chat3_day1_725cd3d2:

    # player "Night!"
    player "¡Buenas noches!"

# game/chapters/1_day.rpy:2488
translate Spanish chat3_day1_104f4b19:

    # player "Sleep well, grimmy :)"
    player "Duerme bien, Parquita :)"

# game/chapters/1_day.rpy:2491
translate Spanish chat3_day1_7a684a72:

    # player "Oh, wait, can I change my username?"
    player "Oh, espera, ¿puedo cambiar mi nombre de usuario?"

# game/chapters/1_day.rpy:2492
translate Spanish chat3_day1_9fd9a76d:

    # GR "why?"
    GR "¿por qué?"

# game/chapters/1_day.rpy:2495
translate Spanish chat3_day1_bbbf5b0d:

    # player "I just want to."
    player "Porque quiero."

# game/chapters/1_day.rpy:2496
translate Spanish chat3_day1_ed39b66e:

    # GR "hm. yes, i suppose you can."
    GR "hm. sí, supongo que puedes."

# game/chapters/1_day.rpy:2499
translate Spanish chat3_day1_8d438dd7:

    # player "Wow, easier to convince than I expected."
    player "Wow, más fácil de convencer de lo que esperaba."

# game/chapters/1_day.rpy:2500
translate Spanish chat3_day1_2773bb6d:

    # GR "did you want me to say no or something...?"
    GR "¿querías que dijera que no o algo...?"

# game/chapters/1_day.rpy:2503
translate Spanish chat3_day1_a81bb0d1:

    # player "This one is kinda lame."
    player "Este es un poco patético."

# game/chapters/1_day.rpy:2504
translate Spanish chat3_day1_3b2dd9f7:

    # GR "lame? it is not lame."
    GR "¿patético? no es patético."

# game/chapters/1_day.rpy:2505
translate Spanish chat3_day1_cbee77fc:

    # GR "it represents how many souls i claimed before yours."
    GR "representa cuántas almas reclamé antes que la tuya."

# game/chapters/1_day.rpy:2506
translate Spanish chat3_day1_5f29e88a:

    # GR "it is a badge of honor."
    GR "es una insignia de honor."

# game/chapters/1_day.rpy:2509
translate Spanish chat3_day1_8bfe1463:

    # player "But can I change it or not?"
    player "¿Pero puedo cambiarlo o no?"

# game/chapters/1_day.rpy:2510
translate Spanish chat3_day1_55690088:

    # GR "...fine."
    GR "...está bien."

# game/chapters/1_day.rpy:2513
translate Spanish chat3_day1_d671ed7e:

    # player "What about my picture?"
    player "¿Y mi foto?"

# game/chapters/1_day.rpy:2514
translate Spanish chat3_day1_f1cf95b6:

    # GR "you're a needy little thing, aren't you?"
    GR "eres una cosita necesitada, ¿no?"

# game/chapters/1_day.rpy:2517
translate Spanish chat3_day1_8f517da0:

    # player "Just for you ;)"
    player "Solo por ti ;)"

# game/chapters/1_day.rpy:2518
translate Spanish chat3_day1_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/1_day.rpy:2519
translate Spanish chat3_day1_600c02d1:

    # GR "...fine. i have turned on the feature for you."
    GR "...está bien. he activado la función para ti."

# game/chapters/1_day.rpy:2522
translate Spanish chat3_day1_e62511d6:

    # player "Aren't these basic messaging app features?"
    player "¿No son esas las funciones básicas de una aplicación de mensajería?"

# game/chapters/1_day.rpy:2523
translate Spanish chat3_day1_3f7ad2f6:

    # GR "oh."
    GR "oh."

# game/chapters/1_day.rpy:2524
translate Spanish chat3_day1_39581029:

    # GR "then yes, of course you can."
    GR "entonces sí, por supuesto que puedes."

# game/chapters/1_day.rpy:2525
translate Spanish chat3_day1_d2e7cd19:

    # GR "obviously. this program lacks in absolutely no ways."
    GR "obviamente. a este programa no le falta nada."

# game/chapters/1_day.rpy:2534
translate Spanish chat4_day1_f13f595c:

    # player "Thanks grimmy. Night night!"
    player "Gracias Parquita. ¡Buenas noches!"

# game/chapters/1_day.rpy:2536
translate Spanish chat4_day1_425ac1e8:

    # GR "you can click your little picture to change it whenever now."
    GR "puedes hacer clic en tu foto para cambiarla cuando quieras."

# game/chapters/1_day.rpy:2537
translate Spanish chat4_day1_3e685698:

    # GR "yes, i work that quickly. you may be impressed."
    GR "sí, trabajo así de rápido. quizás te sorprenda."

# game/chapters/1_day.rpy:2538
translate Spanish chat4_day1_216bd8ec:

    # GR "enjoy."
    GR "disfruta."

# game/chapters/1_day.rpy:2542
translate Spanish chat4_day1_8a01d354:

    # GR "night."
    GR "buenas noches."

translate Spanish strings:

    # game/chapters/1_day.rpy:52
    old "1. <Is that an offer?>"
    new "1. <¿Eso es una oferta?>"

    # game/chapters/1_day.rpy:56
    old "1. <Uh... if you don't get it, don't worry about it.>"
    new "1. <Eh... si no lo captas, no te preocupes.>"

    # game/chapters/1_day.rpy:60
    old "2. <An offer for what you said—>"
    new "2. <Una oferta por lo que dijiste—>"

    # game/chapters/1_day.rpy:63
    old "1. <You know what, nevermind.>"
    new "1. <¿Sabes qué? Olvídalo.>"

    # game/chapters/1_day.rpy:69
    old "1. <Or what?>"
    new "1. <¿O qué?>"

    # game/chapters/1_day.rpy:74
    old "1. <Isn't that what you threatened me with anyway?>"
    new "1. <¿No es eso con lo que me amenazaste de todas formas?>"

    # game/chapters/1_day.rpy:78
    old "2. <What is this app...?>"
    new "2. <¿Qué es esta aplicación...?>"

    # game/chapters/1_day.rpy:85
    old "1. <For... me?>"
    new "1. <¿Por... mí?>"

    # game/chapters/1_day.rpy:88
    old "1. <Kinda creepy, ngl...>"
    new "1. <Un poco espeluznante, no lo voy a negar...>"

    # game/chapters/1_day.rpy:93
    old "1. <Since you installed it on my computer illegally.>"
    new "1. <Desde que la instalaste ilegalmente en mi computadora.>"

    # game/chapters/1_day.rpy:99
    old "2. <Well, I guess that does sound like a lot of effort.>"
    new "2. <Bueno, supongo que eso sí parece mucho esfuerzo.>"

    # game/chapters/1_day.rpy:102
    old "1. <Nice job.>"
    new "1. <Buen trabajo.>"

    # game/chapters/1_day.rpy:108
    old "1. <But still...>"
    new "1. <Pero aun así...>"

    # game/chapters/1_day.rpy:113
    old "3. <Uh... hello to you, too.>"
    new "3. <Eh... hola a ti también.>"

    # game/chapters/1_day.rpy:116
    old "1. <That was one hell of an introduction.>"
    new "1. <Vaya presentación.>"

    # game/chapters/1_day.rpy:120
    old "1. <Er, what?>"
    new "1. <Eh, ¿qué?>"

    # game/chapters/1_day.rpy:123
    old "1. <I don't even know you.>"
    new "1. <Ni siquiera te conozco.>"

    # game/chapters/1_day.rpy:128
    old "1. <Right....>"
    new "1. <Cierto....>"

    # game/chapters/1_day.rpy:134
    old "2. <I mean, it was like... five minutes.>"
    new "2. <Quiero decir, fue como... cinco minutos.>"

    # game/chapters/1_day.rpy:139
    old "1. <Well, don't let me take up your precious time!>"
    new "1. <Bueno, ¡no dejes que te quite tu precioso tiempo!>"

    # game/chapters/1_day.rpy:142
    old "1. <Off you go!>"
    new "1. <¡Vete!>"

    # game/chapters/1_day.rpy:149
    old "2. <You shouldn't have blown up my notifications.>"
    new "2. <No deberías haber reventado mis notificaciones.>"

    # game/chapters/1_day.rpy:152
    old "1. <That makes me want to ignore you.>"
    new "1. <Eso me da ganas de ignorarte.>"

    # game/chapters/1_day.rpy:156
    old "1. <Too bad. You were too eager.>"
    new "1. <Qué pena. Estabas demasiado ansioso.>"

    # game/chapters/1_day.rpy:162
    old "1. <There's unspoken rules to texting people.>"
    new "1. <Hay reglas no escritas para enviarle mensajes a la gente.>"

    # game/chapters/1_day.rpy:165
    old "1. <Or in this case, messaging them through suspicious apps.>"
    new "1. <O, en este caso, para enviarles mensajes a través de apps sospechosas.>"

    # game/chapters/1_day.rpy:172
    old "2. <Don't spam and don't get mad if you don't get an instant response, mostly.>"
    new "2. <Principalmente, no hagas spam y no te enojes si no obtienes una respuesta instantánea.>"

    # game/chapters/1_day.rpy:177
    old "1. <Sure... anyway...>"
    new "1. <Claro... en fin...>"

    # game/chapters/1_day.rpy:181
    old "4. <{i}Delete the app.{/i}> {font=gui/starthings.ttf}a{/font}"
    new "4. <{i}Eliminar la aplicación.{/i}> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/1_day.rpy:191
    old "1. <{i}Delete the app... again.{/i}>"
    new "1. <{i}Eliminar la aplicación... otra vez.{/i}>"

    # game/chapters/1_day.rpy:201
    old "1. <{i}Delete. The. App.{/i}>"
    new "1. <{i}Eliminar. La. Aplicación.{/i}>"

    # game/chapters/1_day.rpy:210
    old "1. <Your order total is $641.30.>"
    new "1. <El total de su pedido es $641.30.>"

    # game/chapters/1_day.rpy:213
    old "1. <To finalize your order, please hit 1.>"
    new "1. <Para finalizar su pedido, por favor presione 1.>"

    # game/chapters/1_day.rpy:216
    old "1. <To cancel your order, please hit 2.>"
    new "1. <Para cancelar su pedido, por favor presione 2.>"

    # game/chapters/1_day.rpy:221
    old "1. <Thank you for your purchase. Your order is now being finalized.>"
    new "1. <Gracias por su compra. Su pedido se está finalizando.>"

    # game/chapters/1_day.rpy:225
    old "1. <To order again, please select YES.>"
    new "1. <Para realizar un nuevo pedido, por favor seleccione SÍ.>"

    # game/chapters/1_day.rpy:238
    old "1. <Thank you for your order. Your account has been charged a total of $3491.60.>"
    new "1. <Gracias por su pedido. Su cuenta ha sido cargada con un total de $3491.60.>"

    # game/chapters/1_day.rpy:244
    old "1. <Idiot.>"
    new "1. <Idiota.>"

    # game/chapters/1_day.rpy:246
    old "2. <You're a moron.>"
    new "2. <Eres un imbécil.>"

    # game/chapters/1_day.rpy:253
    old "1. <It's not my fault you're so easily fooled.>"
    new "1. <No es mi culpa que te dejes engañar tan fácilmente.>"

    # game/chapters/1_day.rpy:259
    old "1. <Seriously, is this a virus or something...?>"
    new "1. <En serio, ¿esto es un virus o algo...?>"

    # game/chapters/1_day.rpy:267
    old "1. <Okay, but...>"
    new "1. <Okey, pero...>"

    # game/chapters/1_day.rpy:275
    old "1. <For...?>"
    new "1. <¿Para...?>"

    # game/chapters/1_day.rpy:282
    old "1. <I don't even know who you are.>"
    new "1. <Ni siquiera sé quién eres.>"

    # game/chapters/1_day.rpy:285
    old "1. <It's a little strange to message a random [girl] out of nowhere.>"
    new "1. <Es un poco raro escribirle de la nada a [arti_2] [girl!t] al azar.>"

    # game/chapters/1_day.rpy:290
    old "1. <Okay, getting creepier.>"
    new "1. <Okey, esto se pone cada vez más espeluznante.>"

    # game/chapters/1_day.rpy:293
    old "1. <Do I know you from somewhere, then?>"
    new "1. <¿Te conozco de algún lado, entonces?>"

    # game/chapters/1_day.rpy:296
    old "2. <Wait, are you a bot?>"
    new "2. <Espera, ¿eres un bot?>"

    # game/chapters/1_day.rpy:300
    old "1. <You know. A bot.>"
    new "1. <Ya sabes. Un bot.>"

    # game/chapters/1_day.rpy:303
    old "1. <Beep beep.>"
    new "1. <Bip bip.>"

    # game/chapters/1_day.rpy:309
    old "1. <Sounds like something a bot would say.>"
    new "1. <Suena como algo que diría un bot.>"

    # game/chapters/1_day.rpy:313
    old "1. <Robot say huh?>"
    new "1. <¿El Robot dice eh?>"

    # game/chapters/1_day.rpy:322
    old "1. <Why are you here then?>"
    new "1. <¿Entonces por qué estás aquí?>"

    # game/chapters/1_day.rpy:329
    old "1. <Yeah, you said that once or twice...>"
    new "1. <Sí, eso lo dijiste una o dos veces...>"

    # game/chapters/1_day.rpy:332
    old "1. <Is this a call for help?>"
    new "1. <¿Es esto una llamada de ayuda?>"

    # game/chapters/1_day.rpy:334
    old "2. <I'm actually starting to feel sorry for you...>"
    new "2. <De verdad que estoy empezando a sentir lástima por ti...>"

    # game/chapters/1_day.rpy:337
    old "2. <Wait, what did you come here for?>"
    new "2. <Espera, ¿para qué viniste aquí?>"

    # game/chapters/1_day.rpy:341
    old "1. <Sorry, one more time? You're cutting out.>"
    new "1. <Perdón, ¿otra vez? Se corta la señal.>"

    # game/chapters/1_day.rpy:345
    old "1. <Man, really bad reception here.>"
    new "1. <Vaya, qué mala señal hay aquí.>"

    # game/chapters/1_day.rpy:348
    old "1. <Can't make out what you're saying at all.>"
    new "1. <No entiendo nada de lo que dices.>"

    # game/chapters/1_day.rpy:357
    old "1. <Are you trying to threaten me or something?>"
    new "1. <¿Intentas amenazarme o algo?>"

    # game/chapters/1_day.rpy:362
    old "2. <I don't owe you anything.>"
    new "2. <No te debo nada.>"

    # game/chapters/1_day.rpy:369
    old "1. <Uh, and this job is...?>"
    new "1. <Eh, ¿y este trabajo es...?>"

    # game/chapters/1_day.rpy:374
    old "1. <I don't care that much...>"
    new "1. <No me importa tanto...>"

    # game/chapters/1_day.rpy:380
    old "1. <...Fine, please tell me.>"
    new "1. <...Está bien, por favor dime.>"

    # game/chapters/1_day.rpy:383
    old "2. <Now I feel bad. You can tell me.>"
    new "2. <Ahora me siento mal. Puedes decírmelo.>"

    # game/chapters/1_day.rpy:386
    old "2. <Pretty please?>"
    new "2. <¿Porfis?>"

    # game/chapters/1_day.rpy:393
    old "2. <Yeah, I'm terrified.>"
    new "2. <Sí, tengo mucho miedo.>"

    # game/chapters/1_day.rpy:397
    old "1. <Nah, not really. I'm just messing with you.>"
    new "1. <Nah, no realmente. Solo te estoy tomando el pelo.>"

    # game/chapters/1_day.rpy:399
    old "2. <Yep. Really really scared atm.>"
    new "2. <Síp. Realmente tengo mucho miedo en este momento.>"

    # game/chapters/1_day.rpy:402
    old "1. <:D>"
    new "1. <:D>"

    # game/chapters/1_day.rpy:404
    old "2. <:3>"
    new "2. <:3>"

    # game/chapters/1_day.rpy:411
    old "1. <Uh huh. Sure I will.>"
    new "1. <Eh ajá. Seguro que sí.>"

    # game/chapters/1_day.rpy:414
    old "1. <And this true form is...?>"
    new "1. <¿Y esa verdadera forma es...?>"

    # game/chapters/1_day.rpy:423
    old "2. <Riiiight.>"
    new "2. <Cieeeerto.>"

    # game/chapters/1_day.rpy:426
    old "3. <Riiiiiiiiiight.>"
    new "3. <Cieeeeeeeeeerto.>"

    # game/chapters/1_day.rpy:430
    old "1. <Cool.>"
    new "1. <Genial.>"

    # game/chapters/1_day.rpy:433
    old "2. <Very normal.>"
    new "2. <Muy normal.>"

    # game/chapters/1_day.rpy:436
    old "1. <Totally reasonable thing to say to someone.>"
    new "1. <Algo totalmente razonable para decirle a alguien.>"

    # game/chapters/1_day.rpy:444
    old "1. <Maybe because it is?>"
    new "1. <¿Quizás porque lo es?>"

    # game/chapters/1_day.rpy:447
    old "1. <I don't give my soul to just anyone, you know.>"
    new "1. <No entrego mi alma a cualquiera, ¿sabes?>"

    # game/chapters/1_day.rpy:453
    old "1. <I had that in my job description once, too.>"
    new "1. <Yo también tuve eso en mi descripción de trabajo una vez.>"

    # game/chapters/1_day.rpy:458
    old "1. <No, I just worked retail.>"
    new "1. <No, yo solo trabajaba en una tienda.>"

    # game/chapters/1_day.rpy:465
    old "2. <ngl not the weirdest scam someone's tried on me.>"
    new "2. <No voy a mentir, no es la estafa más rara que alguien me haya intentado hacer.>"

    # game/chapters/1_day.rpy:468
    old "1. <There was this one time when I got a message from a 'time-traveling astronaut'.>"
    new "1. <Hubo una vez en que recibí un mensaje de un 'astronauta viajero del tiempo'.>"

    # game/chapters/1_day.rpy:471
    old "1. <Said I had to wire them money to preserve the space-time continuum.>"
    new "1. <Decía que tenía que transferirles dinero para preservar el continuo espacio-tiempo.>"

    # game/chapters/1_day.rpy:477
    old "1. <Somehow I'm not surprised that you would fall for that.>"
    new "1. <De alguna manera no me sorprende que hayas caído en eso.>"

    # game/chapters/1_day.rpy:481
    old "1. <Well, I hope it was...>"
    new "1. <Bueno, eso espero...>"

    # game/chapters/1_day.rpy:485
    old "1. <I'll keep that in mind.>"
    new "1. <Lo tendré en cuenta.>"

    # game/chapters/1_day.rpy:490
    old "2. <You're kind of babygirl coded.>"
    new "2. <Tienes un aire de Babygirl.>"

    # game/chapters/1_day.rpy:498
    old "1. <I have to ask, is this a roleplay?>"
    new "1. <Tengo una pregunta, ¿esto es un roleplay?>"

    # game/chapters/1_day.rpy:502
    old "1. <Like, you're pretending to be the grim reaper...>"
    new "1. <Como si estuvieras fingiendo ser la parca...>"

    # game/chapters/1_day.rpy:505
    old "1. <And you want me to be...>"
    new "1. <Y quieres que yo sea...>"

    # game/chapters/1_day.rpy:508
    old "1. <Your enemies-to-lovers sweetheart?>"
    new "1. <¿Tu pareja de 'enemies-to-lovers'?>"

    # game/chapters/1_day.rpy:510
    old "2. <A pizza delivery [woman].>"
    new "2. <[arti_2!c] [woman!t] que reparte pizzas.>"

    # game/chapters/1_day.rpy:512
    old "3. <Your mortal enemy. Mwhahahaha.>"
    new "3. <Tu enemig[letra] mortal. Mwhahahaha.>"

    # game/chapters/1_day.rpy:517
    old "1. <That's a shame.>"
    new "1. <Qué lástima.>"

    # game/chapters/1_day.rpy:520
    old "1. <I used to be one hell of a roleplayer, back in the day.>"
    new "1. <Solía ser una máquina del roleplay, en mis tiempos.>"

    # game/chapters/1_day.rpy:524
    old "2. <It's a little hard to take you seriously.>"
    new "2. <Es un poco difícil tomarte en serio.>"

    # game/chapters/1_day.rpy:528
    old "1. <Maybe because you're literally a stranger on the internet?>"
    new "1. <¿Quizá porque literalmente eres un desconocido de internet?>"

    # game/chapters/1_day.rpy:532
    old "1. <But most people don't claim to be a mythological creature.>"
    new "1. <Pero la mayoría de la gente no afirma ser una criatura mitológica.>"

    # game/chapters/1_day.rpy:538
    old "2. <Are you... okay?>"
    new "2. <¿Estás... bien?>"

    # game/chapters/1_day.rpy:542
    old "1. <Well, you're spouting all of this nonsense.>"
    new "1. <Bueno, estás diciendo todas estas tonterías.>"

    # game/chapters/1_day.rpy:545
    old "1. <I thought it might be a call for help...?>"
    new "1. <Pensé que podría ser un llamado de auxilio... ¿no?>"

    # game/chapters/1_day.rpy:550
    old "1. <Mmm, not really a fan...>"
    new "1. <Mmm, no es que me convenza mucho...>"

    # game/chapters/1_day.rpy:554
    old "1. <And if I said no?>"
    new "1. <¿Y si digo que no?>"

    # game/chapters/1_day.rpy:558
    old "1. <Being laughed at, or losing my soul...>"
    new "1. <Que se rían de mí o perder mi alma...>"

    # game/chapters/1_day.rpy:561
    old "1. <Tough decision.>"
    new "1. <Difícil decisión>"

    # game/chapters/1_day.rpy:569
    old "3. <Is this one of those scams?>"
    new "3. <¿Es esta una de esas estafas?>"

    # game/chapters/1_day.rpy:577
    old "1. <{i}You owe $5000 in taxes... payment taken in gift cards.{/i}>"
    new "1. <{i}Debes $5000 en impuestos... pago aceptado en tarjetas de regalo.{/i}>"

    # game/chapters/1_day.rpy:581
    old "1. <No, dumbo, that's the scam.>"
    new "1. <No, bobo, esa es la estafa.>"

    # game/chapters/1_day.rpy:585
    old "1. <If I was, I'd be rich off you alone.>"
    new "1. <Si lo fuera, tendría millones solo contigo.>"

    # game/chapters/1_day.rpy:589
    old "1. <But I was serious about your taxes.>"
    new "1. <Pero hablaba en serio sobre tus impuestos.>"

    # game/chapters/1_day.rpy:592
    old "1. <The tax agency sent me.>"
    new "1. <La agencia tributaria me envió.>"

    # game/chapters/1_day.rpy:595
    old "1. <Send me your cc number and the three whacky numbers on the back, quick.>"
    new "1. <Envíame tu número de tarjeta de crédito y los tres números raros de atrás, rápido.>"

    # game/chapters/1_day.rpy:598
    old "1. <Or you're going to prison, buddy.>"
    new "1. <O vas a ir a la cárcel, amigo.>"

    # game/chapters/1_day.rpy:602
    old "1. <Dead serious.>"
    new "1. <Completamente en serio.>"

    # game/chapters/1_day.rpy:607
    old "1. <WOAH...>"
    new "1. <UY...>"

    # game/chapters/1_day.rpy:610
    old "1. <Okay I don't actually want your details.>"
    new "1. <Okey, en realidad no quiero tus datos.>"

    # game/chapters/1_day.rpy:613
    old "1. <I was joking.>"
    new "1. <Estaba bromeando.>"

    # game/chapters/1_day.rpy:617
    old "2. <No, I'm messing with you again.>"
    new "2. <No, te estoy tomando el pelo otra vez.>"

    # game/chapters/1_day.rpy:621
    old "1. <But you believed me, didn't you?>"
    new "1. <Pero me creíste, ¿no?>"

    # game/chapters/1_day.rpy:625
    old "1. <Look, as fun as messing with you is...>"
    new "1. <Mira, por muy divertido que sea molestarte...>"

    # game/chapters/1_day.rpy:632
    old "4. <Of course, it's all yours!> {font=gui/starthings.ttf}a{/font}"
    new "4. <¡Por supuesto, es toda tuya!> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/1_day.rpy:638
    old "1. <Should I post it via mail?>"
    new "1. <¿Debería enviarla por correo?>"

    # game/chapters/1_day.rpy:643
    old "1. <Trust me, you can.>"
    new "1. <Créeme, sí se puede>"

    # game/chapters/1_day.rpy:648
    old "1. <I send souls all the time.>"
    new "1. <Envío almas todo el tiempo.>"

    # game/chapters/1_day.rpy:654
    old "1. <You'll just have to wait and see.>"
    new "1. <Tendrás que esperar y ver.>"

    # game/chapters/1_day.rpy:660
    old "1. <What gave me away?>"
    new "1. <¿Qué me delató?>"

    # game/chapters/1_day.rpy:664
    old "1. <Honestly...>"
    new "1. <Honestamente...>"

    # game/chapters/1_day.rpy:668
    old "2. <I'll email it to you. What's your email?>"
    new "2. <Te lo enviaré por correo electrónico. ¿Cuál es tu correo?>"

    # game/chapters/1_day.rpy:673
    old "1. <Are you sure about that?>"
    new "1. <¿Estás seguro de eso?>"

    # game/chapters/1_day.rpy:677
    old "1. <But have you ever tried?>"
    new "1. <¿Pero alguna vez lo intentaste?>"

    # game/chapters/1_day.rpy:682
    old "1. <Pffffft....>"
    new "1. <Puajajaja....>"

    # game/chapters/1_day.rpy:686
    old "1. <Your email...>"
    new "1. <Tu correo...>"

    # game/chapters/1_day.rpy:690
    old "1. <Sure...>"
    new "1. <Claro...>"

    # game/chapters/1_day.rpy:694
    old "1. <Okay, I just emailed my soul over.>"
    new "1. <Okey, acabo de enviar mi alma por correo.>"

    # game/chapters/1_day.rpy:698
    old "1. <Maybe you're having internet issues.>"
    new "1. <Quizás tengas problemas de Internet.>"

    # game/chapters/1_day.rpy:702
    old "1. <Restart your computer?>"
    new "1. <¿Y si reinicias tu computadora?>"

    # game/chapters/1_day.rpy:718
    old "1. <I don't usually respond to spam messages like this.>"
    new "1. <Normalmente no respondo a mensajes de spam como este.>"

    # game/chapters/1_day.rpy:721
    old "1. <Now I'm thinking I should?>"
    new "1. <¿Ahora pienso que debería hacerlo?>"

    # game/chapters/1_day.rpy:724
    old "1. <Anyway, do you seriously think you're the 'grim reaper'?>"
    new "1. <De todos modos, ¿de verdad te crees 'La Parca'?>"

    # game/chapters/1_day.rpy:728
    old "1. <It's funny, at least...?>"
    new "1. <¿Es gracioso, al menos...?>"

    # game/chapters/1_day.rpy:731
    old "1. <You've made me laugh, so that's nice.>"
    new "1. <Me has hecho reír, así que está bien.>"

    # game/chapters/1_day.rpy:735
    old "1. <You should try being less funny then, lol>"
    new "1. <Entonces deberías intentar ser menos gracioso, lol>"

    # game/chapters/1_day.rpy:739
    old "1. <Pretty much everything.>"
    new "1. <Prácticamente todo.>"

    # game/chapters/1_day.rpy:742
    old "1. <Mister 'Grim Reaper' (lol)>"
    new "1. <Señor 'Parca' (lol)>"

    # game/chapters/1_day.rpy:746
    old "2. <It's kinda... cringe.>"
    new "2. <Es algo... cringe.>"

    # game/chapters/1_day.rpy:752
    old "1. <No... embarrassing, and annoying.>"
    new "1. <No... vergonzoso y molesto.>"

    # game/chapters/1_day.rpy:758
    old "2. <Er... yes, that's what it means.>"
    new "2. <Eh... sí, eso significa.>"

    # game/chapters/1_day.rpy:762
    old "1. <But who just installs a program on someones computer like that?>"
    new "1. <¿Pero quién instala un programa en la computadora de alguien así como así?>"

    # game/chapters/1_day.rpy:765
    old "1. <Are you that desperate for attention?>"
    new "1. <¿Tan desesperado estás por llamar la atención?>"

    # game/chapters/1_day.rpy:768
    old "1. <It makes me feel sad for you.>"
    new "1. <Me da pena por ti.>"

    # game/chapters/1_day.rpy:775
    old "1. <Dude...>"
    new "1. <Amigo...>"

    # game/chapters/1_day.rpy:778
    old "1. <You're the one harrassing me.>"
    new "1. <Tú eres el que me está acosando.>"

    # game/chapters/1_day.rpy:781
    old "1. <Nobody is forcing you to be here.>"
    new "1. <Nadie te obliga a estar aquí.>"

    # game/chapters/1_day.rpy:786
    old "1. <Forever?>"
    new "1. <¿Para siempre?>"

    # game/chapters/1_day.rpy:790
    old "1. <Forever and ever?>"
    new "1. <¿Siempre y para siempre?>"

    # game/chapters/1_day.rpy:794
    old "1. <You know I can just leave this chat whenever I want, right?>"
    new "1. <Sabes que puedo salir de este chat cuando quiera, ¿verdad?>"

    # game/chapters/1_day.rpy:797
    old "1. <Then you'd be sitting in chat all alone.>"
    new "1. <Entonces estarías chateando completamente solo.>"

    # game/chapters/1_day.rpy:803
    old "3. <It's a little cute...>"
    new "3. <Es un poco lindo...>"

    # game/chapters/1_day.rpy:807
    old "1. <Yeah. In a weird way.>"
    new "1. <Sí. De una forma rara.>"

    # game/chapters/1_day.rpy:811
    old "2. <You're totally delusional, but it's kinda sweet.>"
    new "2. <Estás completamente fuera de la realidad, pero es algo tierno.>"

    # game/chapters/1_day.rpy:816
    old "1. <Well, it could be that you keep saying things like...>"
    new "1. <Bueno, podría ser que sigas diciendo cosas como...>"

    # game/chapters/1_day.rpy:819
    old "1. <I Have Come To Eat Your Soul!>"
    new "1. <¡He Venido A Devorar Tu Alma!>"

    # game/chapters/1_day.rpy:821
    old "2. <I Am So Edgy And Dark!>"
    new "2. <¡Soy Tan Edgy Y Tenebroso!>"

    # game/chapters/1_day.rpy:823
    old "3. <I Am Darkness Incarnate!>"
    new "3. <¡Soy La Oscuridad Encarnada!>"

    # game/chapters/1_day.rpy:829
    old "1. <You did.>"
    new "1. <Lo hiciste.>"

    # game/chapters/1_day.rpy:834
    old "1. <{i}Delete Chatlog{/i}>"
    new "1. <{i}Eliminar historial de chat{/i}>"

    # game/chapters/1_day.rpy:838
    old "1. <Neither do you, little mister grim reaper.>"
    new "1. <Tú tampoco, señorito Parca>"

    # game/chapters/1_day.rpy:841
    old "4. <Wait, {b}I'M{/b} the Grim Reaper...> {font=gui/starthings.ttf}a{/font}"
    new "4. <Espera, {b}YO SOY{/b} La Parca...> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/1_day.rpy:845
    old "1. <Are you trying to steal my job?>"
    new "1. <¿Estás tratando de robarme mi trabajo?>"

    # game/chapters/1_day.rpy:848
    old "1. <That is super {i}not{/i} cool.>"
    new "1. <Es súper {i}no{/i} cool.>"

    # game/chapters/1_day.rpy:852
    old "1. <I Am The Grim Reaper!>"
    new "1. <¡Yo Soy La Parca!>"

    # game/chapters/1_day.rpy:859
    old "1. <No, You Are Not!>"
    new "1. <¡No, Tú No Lo Eres!>"

    # game/chapters/1_day.rpy:866
    old "1. <The 1st rule of Grim Reaper club - don't talk about Grim Reaper club.>"
    new "1. <La primera regla del club de las Parcas: no hablar del club de las Parcas.>"

    # game/chapters/1_day.rpy:868
    old "2. <Make sure they didn't leave the oven on.>"
    new "2. <Asegúrate de que no hayan dejado el horno encendido.>"

    # game/chapters/1_day.rpy:870
    old "3. <If they win in rock paper scissors, they get a free pass.>"
    new "3. <Si ganan en piedra, papel o tijera, obtienen un pase gratuito.>"

    # game/chapters/1_day.rpy:879
    old "1. <How reasonable of you.>"
    new "1. <Qué razonable de tu parte.>"

    # game/chapters/1_day.rpy:882
    old "2. <That's boring. Cause a little pain, why don't you?>"
    new "2. <Eso es aburrido. Causa un poco de dolor, ¿por qué no?>"

    # game/chapters/1_day.rpy:886
    old "1. <You're a funny little 'grim reaper' lol>"
    new "1. <Eres una 'Parquita' divertida, lol>"

    # game/chapters/1_day.rpy:894
    old "1. <It's, well... a little embarrassing.>"
    new "1. <Es, bueno... un poco vergonzoso.>"

    # game/chapters/1_day.rpy:896
    old "2. <Is there anyone who wouldn't?>"
    new "2. <¿Hay alguien que no lo haría?>"

    # game/chapters/1_day.rpy:898
    old "3. <It's less mocking, more... light teasing.>"
    new "3. <No es tanto burlarse, sino más bien... una broma inofensiva.>"

    # game/chapters/1_day.rpy:900
    old "4. <Yeah, sorry.>"
    new "4. <Sí, lo siento.>"

    # game/chapters/1_day.rpy:903
    old "1. <Wait, wait, wait, quick question.>"
    new "1. <Espera, espera, espera, pregunta rápida.>"

    # game/chapters/1_day.rpy:906
    old "1. <Do you walk around being like '{i}I AM DEATH{/i}'? in real life, too?>"
    new "1. <¿Acaso caminas por ahí diciendo '{i}YO SOY LA MUERTE{/i}'? ¿En la vida real también?>"

    # game/chapters/1_day.rpy:910
    old "1. <'{i}Bow down to me...! Your soul is mine...!{/i}'>"
    new "1. <'{i}¡Inclínate ante mí...! ¡Tu alma es mía...!{/i}'>"

    # game/chapters/1_day.rpy:912
    old "2. <'{i}I am the Grim Reaper! Death and darkness!{/i}'>"
    new "2. <'{i}¡Soy La Parca! ¡Muerte y oscuridad!{/i}'>"

    # game/chapters/1_day.rpy:915
    old "1. <You do, don't you?>"
    new "1. <¿Lo haces, verdad?>"

    # game/chapters/1_day.rpy:919
    old "1. <Stunned silence?>"
    new "1. <¿Silencio absoluto?>"

    # game/chapters/1_day.rpy:923
    old "1. <Is your hair as dark as night? Do you hide behind long bangs?>"
    new "1. <¿Tu cabello es tan oscuro como la noche? ¿Te escondes detrás de un flequillo largo?>"

    # game/chapters/1_day.rpy:925
    old "2. <You give off 'dresses in all black' vibes.>"
    new "2. <Das la vibra de 'se viste todo de negro'.>"

    # game/chapters/1_day.rpy:928
    old "1. <I can relate to that, at least.>"
    new "1. <Al menos, puedo identificarme con eso.>"

    # game/chapters/1_day.rpy:930
    old "2. <Not my thing, but you do you, buddy.>"
    new "2. <No es lo mío, pero tú haz lo que quieras, amigo.>"

    # game/chapters/1_day.rpy:933
    old "1. <I think I can imagine you completely.>"
    new "1. <Creo que puedo imaginarte perfectamente.>"

    # game/chapters/1_day.rpy:936
    old "1. <It's a funny thought... hehe.>"
    new "1. <Es una idea divertida... jeje.>"

    # game/chapters/1_day.rpy:938
    old "2. <If only we could meet to confirm my suspicions.>"
    new "2. <Ojalá pudiéramos vernos para confirmar mis sospechas.>"

    # game/chapters/1_day.rpy:945
    old "1. <'{i}Give me your soul! Your soul is mine for the harvesting!{/i}'>"
    new "1. <'{i}¡Dame tu alma! ¡Tu alma es mía para cosecharla!{/i}'>"

    # game/chapters/1_day.rpy:948
    old "1. <'{i}It will be a three course meal!{/i}'.>"
    new "1. <'{i}¡Será una comida de tres platos!{/i}'>"

    # game/chapters/1_day.rpy:952
    old "1. <Did I hurt the scammer's feelings?>"
    new "1. <¿Herí los sentimientos del estafador?>"

    # game/chapters/1_day.rpy:958
    old "1. <Have I hurt your little dead heart?>"
    new "1. <¿He herido a tu corazoncito muerto?>"

    # game/chapters/1_day.rpy:962
    old "1. <The grim reaper is like...>"
    new "1. <La parca es como...>"

    # game/chapters/1_day.rpy:965
    old "1. <A skeleton, right?>"
    new "1. <Un esqueleto, ¿no?>"

    # game/chapters/1_day.rpy:968
    old "2. <Dead, right?>"
    new "2. <Muerte, ¿verdad?>"

    # game/chapters/1_day.rpy:977
    old "1. <Hey...>"
    new "1. <Oye...>"

    # game/chapters/1_day.rpy:980
    old "1. <Since reaping souls is your job and all, I have a question.>"
    new "1. <Ya que tu trabajo consiste en segar almas, tengo una pregunta.>"

    # game/chapters/1_day.rpy:983
    old "1. <Do you...>"
    new "1. <¿Tú...>"

    # game/chapters/1_day.rpy:986
    old "1. <Make a killing? :)>"
    new "1. <¿Ganas una fortuna... matando? :)>"

    # game/chapters/1_day.rpy:992
    old "1. <I'm quivering just thinking about it.>"
    new "1. <Estoy temblando solo de pensarlo.>"

    # game/chapters/1_day.rpy:995
    old "1. <Not in a weird way.>"
    new "1. <No de una manera extraña.>"

    # game/chapters/1_day.rpy:998
    old "2. <Using the word 'quiver' was certainly a choice.>"
    new "2. <Usar la palabra 'temblar' fue sin duda una elección deliberada.>"

    # game/chapters/1_day.rpy:1008
    old "1. <Video call me, then.>"
    new "1. <Hazme una videollamada, entonces.>"

    # game/chapters/1_day.rpy:1011
    old "1. <Unless the little '{i}weaper{/i}' is too scared?>"
    new "1. <A menos que la '{i}parquita{/i}' tenga demasiado miedo...>"

    # game/chapters/1_day.rpy:1016
    old "2. <You do type like that, though.>"
    new "2. <Es que escribes así.>"

    # game/chapters/1_day.rpy:1020
    old "1. <It's all kind of... edgy.>"
    new "1. <Es todo como... edgy.>"

    # game/chapters/1_day.rpy:1023
    old "1. <Every single thing you say.>"
    new "1. <Cada una de tus palabras.>"

    # game/chapters/1_day.rpy:1027
    old "1. <See!>"
    new "1. <¡Mira!>"

    # game/chapters/1_day.rpy:1029
    old "2. <You're just proving my point.>"
    new "2. <Solo estás confirmando mi punto.>"

    # game/chapters/1_day.rpy:1032
    old "1. <This is not how you pick up people, you know.>"
    new "1. <Así no es como se seduce a la gente, ¿sabes?>"

    # game/chapters/1_day.rpy:1036
    old "1. <Exactly.>"
    new "1. <Exacto.>"

    # game/chapters/1_day.rpy:1038
    old "2. <The fact that you admitted it...>"
    new "2. <El hecho de que lo hayas admitido...>"

    # game/chapters/1_day.rpy:1042
    old "1. <I dunno... I'm kinda attached to it.>"
    new "1. <No sé... Le tengo cierto cariño.>"

    # game/chapters/1_day.rpy:1045
    old "2. <Can't you take someone else's?>"
    new "2. <¿No puedes tomar la de otra persona?>"

    # game/chapters/1_day.rpy:1048
    old "1. <Sorry, I'm gonna have to pass.>"
    new "1. <Lo siento, voy a tener que pasar.>"

    # game/chapters/1_day.rpy:1052
    old "1. <What are you going to do about it?>"
    new "1. <¿Qué vas a hacer al respecto?>"

    # game/chapters/1_day.rpy:1106
    old "1. <Oh shit.>"
    new "1. <Oh, mierda.>"

    # game/chapters/1_day.rpy:1116
    old "1. <Who said I had no bite?>"
    new "1. <¿Quién dijo que no mordía?>"

    # game/chapters/1_day.rpy:1123
    old "1. <You're the one that said I had a lovely face.>"
    new "1. <Tú eres quien dijo que mi rostro era encantador.>"

    # game/chapters/1_day.rpy:1127
    old "1. <You did!>"
    new "1. <¡Lo hiciste!>"

    # game/chapters/1_day.rpy:1131
    old "1. <Oh, I just did.>"
    new "1. <Ah, ya lo hice.>"

    # game/chapters/1_day.rpy:1134
    old "1. <Yep, still hot.>"
    new "1. <Síp, sigo siendo sexy.>"

    # game/chapters/1_day.rpy:1138
    old "1. <But you really don't look at all like I pictured.>"
    new "1. <Pero realmente no te pareces en nada a lo que me imaginaba.>"

    # game/chapters/1_day.rpy:1141
    old "1. <Your hair is... as white as snow.>"
    new "1. <Tu cabello es... tan blanco como la nieve.>"

    # game/chapters/1_day.rpy:1144
    old "1. <It doesn't exactly scream '{i}I am the reaper, \ngive me your soul{/i}'.>"
    new "1. <No es que grite precisamente '{i}Soy la Parca, dame tu alma{/i}'.>"

    # game/chapters/1_day.rpy:1162
    old "1. You are... definitely not what I was expecting.>"
    new "1. <Tú... definitivamente no eres lo que esperaba.>"

    # game/chapters/1_day.rpy:1169
    old "1. <Shadows?>"
    new "1. <¿Sombras?>"

    # game/chapters/1_day.rpy:1172
    old "1. <Darkness?>"
    new "1. <¿Oscuridad?>"

    # game/chapters/1_day.rpy:1175
    old "1. <Evilness?>"
    new "1. <¿Maldad?>"

    # game/chapters/1_day.rpy:1178
    old "1. <That sorta thing, I suppose.>"
    new "1. <Algo así, supongo.>"

    # game/chapters/1_day.rpy:1182
    old "1. <Well, no, cause...>"
    new "1. <Bueno, no, porque...>"

    # game/chapters/1_day.rpy:1185
    old "1. <How do I say this...>"
    new "1. <Cómo decirlo...>"

    # game/chapters/1_day.rpy:1188
    old "3. <Well... you certainly are cuter than I expected.>"
    new "3. <Bueno... sin duda eres más lindo de lo que esperaba.>"

    # game/chapters/1_day.rpy:1198
    old "1. <No? What word would you use then?>"
    new "1. <¿No? ¿Qué palabra usarías entonces?>"

    # game/chapters/1_day.rpy:1204
    old "1. <Someone seems to be very sure of himself.>"
    new "1. <Alguien parece estar muy seguro de sí mismo.>"

    # game/chapters/1_day.rpy:1207
    old "1. <I {i}really{/i} was picturing jet black hair, though.>"
    new "1. <Sin embargo, {i}realmente{/i} me imaginaba un cabello negro azabache.>"

    # game/chapters/1_day.rpy:1211
    old "1. <Is it usually black? Do you bleach it or something?>"
    new "1. <¿Normalmente es negro? ¿Te lo decoloras o algo así?>"

    # game/chapters/1_day.rpy:1215
    old "1. <So that's all... natural?>"
    new "1. <¿Entonces todo eso es... natural?>"

    # game/chapters/1_day.rpy:1220
    old "1. <Well, you are cute!>"
    new "1. <¡Vaya, qué lindo eres!>"

    # game/chapters/1_day.rpy:1224
    old "1. <I think you're plenty cute.>"
    new "1. <Creo que eres muy lindo.>"

    # game/chapters/1_day.rpy:1226
    old "2. <There's not much else to look at.>"
    new "2. <No hay mucho más que ver.>"

    # game/chapters/1_day.rpy:1229
    old "1. <Move over and I'll look at your room instead.>"
    new "1. <Hazte a un lado y veré tu habitación.>"

    # game/chapters/1_day.rpy:1232
    old "1. <You're no fun.>"
    new "1. <No eres nada divertido.>"

    # game/chapters/1_day.rpy:1235
    old "1. <Then I'll just have to sit here and inspect you.>"
    new "1. <Entonces tendré que sentarme aquí y inspeccionarte.>"

    # game/chapters/1_day.rpy:1239
    old "1. <Well, you aren't exactly {i}reaper{/i} like, are you?>"
    new "1. <Bueno, no eres exactamente como {i}la Parca{/i}, ¿verdad?>"

    # game/chapters/1_day.rpy:1242
    old "1. <Let me rephrase.>"
    new "1. <Déjame reformularlo.>"

    # game/chapters/1_day.rpy:1245
    old "1. <You don't look like a grim reaper, at all.>"
    new "1. <No pareces la parca, en absoluto.>"

    # game/chapters/1_day.rpy:1249
    old "4. <Hello, my little Reaper.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Hola, mi parquita.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/1_day.rpy:1255
    old "1. <Which means...>"
    new "1. <Lo que significa...>"

    # game/chapters/1_day.rpy:1258
    old "1. <You belong to me too, right?>"
    new "1. <Que también eres mío, ¿verdad?>"

    # game/chapters/1_day.rpy:1262
    old "1. <I don't mind sharing.>"
    new "1. <No me importa compartir.>"

    # game/chapters/1_day.rpy:1269
    old "1. <No need to be flustered.>"
    new "1. <No te pongas nervioso.>"

    # game/chapters/1_day.rpy:1277
    old "1. <You don't really have an aura of death \nsurrounding you.>"
    new "1. <La verdad, no tienes esa aura de muerte a tu alrededor.>"

    # game/chapters/1_day.rpy:1281
    old "1. <Your {i}deathly{/i} aura, so to speak, is lacking.>"
    new "1. <Te falta tu aura {i}macabra{/i}, por así decirlo.>"

    # game/chapters/1_day.rpy:1284
    old "1. <I feel like that's something a {i}reaper{/i} would have.>"
    new "1. <Siento que eso es algo que tendría {i}la Parca{/i}.>"

    # game/chapters/1_day.rpy:1290
    old "1. <Thanks, my little Reaper.>"
    new "1. <Gracias, mi Parquita>"

    # game/chapters/1_day.rpy:1296
    old "1. <So, you admit it?>"
    new "1. <¿Entonces lo admites?>"

    # game/chapters/1_day.rpy:1301
    old "1. <You...>{#day1you}"
    new "1. <Tú...>{#day1you}"

    # game/chapters/1_day.rpy:1311
    old "1. <Are just a normal dude.>"
    new "1. <Eres un tipo normal.>"

    # game/chapters/1_day.rpy:1320
    old "1. <That you're the grim reaper?>"
    new "1. <¿Que eres la Parca?>"

    # game/chapters/1_day.rpy:1323
    old "1. <The thing is... I don't believe you.>"
    new "1. <El caso es que... no te creo.>"

    # game/chapters/1_day.rpy:1325
    old "2. <You keep saying that, but it's not true.>"
    new "2. <Sigues diciendo eso, pero no es cierto.>"

    # game/chapters/1_day.rpy:1333
    old "1. <Why are you acting so surprised?>"
    new "1. <¿Por qué te sorprendes tanto?>"

    # game/chapters/1_day.rpy:1335
    old "2. <Okay, no need for that face.>"
    new "2. <Okey, no hace falta que pongas esa cara.>"

    # game/chapters/1_day.rpy:1338
    old "1. <Of course I'm not gonna believe you.>"
    new "1. <Claro que no te voy a creer.>"

    # game/chapters/1_day.rpy:1346
    old "2. <You're still saying it, really?>"
    new "2. <¿Todavía sigues diciendo eso, en serio?>"

    # game/chapters/1_day.rpy:1349
    old "1. <Are you trying to make me laugh?>"
    new "1. <¿Estás tratando de hacerme reír?>"

    # game/chapters/1_day.rpy:1352
    old "2. <I really can't tell if you're being serious or not.>"
    new "2. <Realmente no sé si lo dices en serio o no.>"

    # game/chapters/1_day.rpy:1356
    old "1. <I'm not really interested in being whisked off \ninto the afterlife, or whatever you're offering.>"
    new "1. <No me interesa mucho que me lleven al más allá, o lo que sea que estés ofreciendo.>"

    # game/chapters/1_day.rpy:1359
    old "1. <Nor am I interested in entertaining your \nstrange fantasy.>"
    new "1. <Tampoco me interesa entretener tu extraña fantasía.>"

    # game/chapters/1_day.rpy:1368
    old "1. <Hypothetically speaking...>"
    new "1. <Hipotéticamente hablando...>"

    # game/chapters/1_day.rpy:1370
    old "2. <Just a quick question...>"
    new "2. <Solo una pregunta rápida...>"

    # game/chapters/1_day.rpy:1373
    old "1. <Aren't people meant to be, ya know, dead...>"
    new "1. <¿No se supone que las personas deben estar, ya sabes, muertas...?>"

    # game/chapters/1_day.rpy:1376
    old "1. <For the reaper to come after them?>"
    new "1. <¿Para que la Parca venga a buscarlos?>"

    # game/chapters/1_day.rpy:1381
    old "1. <Right. Okay. Makes total sense.>"
    new "1. <Claro. Okey. Tiene mucho sentido.>"

    # game/chapters/1_day.rpy:1384
    old "2. <Thanks for the explanation.>"
    new "2. <Gracias por la explicación.>"

    # game/chapters/1_day.rpy:1387
    old "3. <Great. Now I completely understand.>"
    new "3. <Genial. Ahora lo entiendo perfectamente.>"

    # game/chapters/1_day.rpy:1390
    old "4. <Well, isn't that just lovely.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Bueno, eso es encantador.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/1_day.rpy:1392
    old "1. <Nothing sweeps a [girl] off [her2] feet more than... \n'{i}Hi, I just met you, but I need you to die for me{/i}'>"
    new "1. <Nada enamora más a [arti_2] [girl!t] que... '{i}Hola, acabo de conocerte, pero necesito que mueras por mí{/i}'>"

    # game/chapters/1_day.rpy:1396
    old "1. <Very romantic and normal.>"
    new "1. <Muy romántico y normal.>"

    # game/chapters/1_day.rpy:1402
    old "1. <Even if that were true...>"
    new "1. <Aunque eso fuera cierto...>"

    # game/chapters/1_day.rpy:1405
    old "1. <You're not making the best first impression here.>"
    new "1. <No estás causando la mejor primera impresión.>"

    # game/chapters/1_day.rpy:1423
    old "1. <I'm giving you this {i}look{/i} because you are full of shit.>"
    new "1. <Te estoy {i}mirando{/i} así porque estás diciendo puras tonterías.>"

    # game/chapters/1_day.rpy:1425
    old "1. <Give it up already.>"
    new "1. <Ya ríndete.>"

    # game/chapters/1_day.rpy:1431
    old "2. <At this point, I'm just really curious what you \nactually want.>"
    new "2. <En este momento, tengo mucha curiosidad por saber qué es lo que realmente quieres.>"

    # game/chapters/1_day.rpy:1438
    old "1. <Look, other than being {i}death{/i} or whatever, \ndo you have any other personality traits?>"
    new "1. <Mira, aparte de ser la {i}muerte{/i} o lo que sea, ¿tienes algún otro rasgo de personalidad?>"

    # game/chapters/1_day.rpy:1441
    old "2. <Let me guess, your social life consists of \ncounting the sand grains in an hourglass, right?>"
    new "2. <Déjame adivinar, tu vida social consiste en contar los granos de arena de un reloj de arena, ¿verdad?>"

    # game/chapters/1_day.rpy:1447
    old "1. <You should work on that.>"
    new "1. <Deberías trabajar en eso.>"

    # game/chapters/1_day.rpy:1451
    old "1. <'{i}The only thing necessary for me is claiming \nthe souls of the damned!{/i}'>"
    new "1. <'{i}¡Lo único que necesito es reclamar las almas de los condenados!{/i}'>"

    # game/chapters/1_day.rpy:1455
    old "1. <And it seems you are severely lacking in it.>"
    new "1. <Y parece que te falta mucho.>"

    # game/chapters/1_day.rpy:1458
    old "2. <Unlike some.>"
    new "2. <A diferencia de algunos.>"

    # game/chapters/1_day.rpy:1462
    old "1. <I feel kinda bad for you.>"
    new "1. <Me das un poco de pena.>"

    # game/chapters/1_day.rpy:1464
    old "2. <If I knocked on your head, I'd hear an echo, I bet.>"
    new "2. <Si te diera un golpe en la cabeza, seguro que oiría un eco.>"

    # game/chapters/1_day.rpy:1469
    old "2. <You mean this one? Where I look at you \nlike you've lost your mind?>"
    new "2. <¿Te refieres a esta? ¿En la que te miro como si hubieras perdido la cabeza?>"

    # game/chapters/1_day.rpy:1473
    old "1. <Of course you have.>"
    new "1. <Por supuesto que sí.>"

    # game/chapters/1_day.rpy:1475
    old "2. <Who wouldn't believe a stranger on the internet?>"
    new "2. <¿Quién no creería a un desconocido en Internet?>"

    # game/chapters/1_day.rpy:1478
    old "1. <Yes, the man video calling me is definitely \nthe grim reaper here to take my soul. For sure.>"
    new "1. <Sí, el hombre que me llama por videollamada es sin duda la Parca, que ha venido a llevarse mi alma. Seguro.>"

    # game/chapters/1_day.rpy:1484
    old "1. <It seems you know a thing or two \nabout sarcasm as well.>"
    new "1. <Parece que tú también sabes un par de cosas sobre el sarcasmo.>"

    # game/chapters/1_day.rpy:1492
    old "1. <You really are so sweet.>"
    new "1. <Realmente eres muy amable.>"

    # game/chapters/1_day.rpy:1494
    old "2. <You know how to make a [girl] smile.>"
    new "2. <Sabes cómo hacer sonreír a [arti_2] [girl!t].>"

    # game/chapters/1_day.rpy:1500
    old "3. <Oh, these are my bedroom eyes.>"
    new "3. <Oh, estos son mis ojos seductores.>"

    # game/chapters/1_day.rpy:1509
    old "2. <Come on...>"
    new "2. <Vamos...>"

    # game/chapters/1_day.rpy:1512
    old "1. <Are you serious? Can't you see my longing gaze?>"
    new "1. <¿En serio? ¿No ves mi mirada anhelante?>"

    # game/chapters/1_day.rpy:1516
    old "1. <Did you just scoff at me...>"
    new "1. <¿Te acabas de burlar de mí...?>"

    # game/chapters/1_day.rpy:1523
    old "1. <That is {i}not{/i} where I thought this was going...>"
    new "1. <Definitivamente {i}no{/i} esperaba que esto terminara así...>"

    # game/chapters/1_day.rpy:1525
    old "2. <Here I was trying to flirt...>"
    new "2. <Y yo que estaba intentando coquetear...>"

    # game/chapters/1_day.rpy:1528
    old "1. <I don't plan to die any time soon, sorry.>"
    new "1. <No pienso morir pronto, lo siento.>"

    # game/chapters/1_day.rpy:1535
    old "1. <I heard that!>"
    new "1. <¡Lo escuché!>"

    # game/chapters/1_day.rpy:1546
    old "1. <Whatever.>"
    new "1. <Como sea.>"

    # game/chapters/1_day.rpy:1549
    old "1. <More like I'm stuck with you, anyway.>"
    new "1. <Más bien, estoy atrapad[letra] contigo.>"

    # game/chapters/1_day.rpy:1552
    old "1. <You and your weird ass typing.>"
    new "1. <Tú y tu extraña forma de escribir.>"

    # game/chapters/1_day.rpy:1556
    old "1. <Why do you type like that, anyway?>"
    new "1. <Por cierto, ¿por qué escribes así?>"

    # game/chapters/1_day.rpy:1560
    old "1. <Wait, it's not on purpose?>"
    new "1. <Espera, ¿no es a propósito?>"

    # game/chapters/1_day.rpy:1564
    old "1. <The capital letters.>"
    new "1. <Las letras mayúsculas.>"

    # game/chapters/1_day.rpy:1572
    old "1. <Yeah... that's the thing.>"
    new "1. <Sí... esa es la cuestión.>"

    # game/chapters/1_day.rpy:1575
    old "1. <You use them too often. Way too often.>"
    new "1. <Las usas demasiado. Muchísimo.>"

    # game/chapters/1_day.rpy:1579
    old "1. <You were using them on every single word.>"
    new "1. <Las usabas en cada palabra.>"

    # game/chapters/1_day.rpy:1582
    old "1. <You're really not supposed to do that.>"
    new "1. <En realidad, no deberías hacer eso.>"

    # game/chapters/1_day.rpy:1586
    old "2. <You're one of those things. A homestuck.>"
    new "2. <Eres de esos raritos. Un fan de Homestuck.>"

    # game/chapters/1_day.rpy:1590
    old "1. <Oh, you really don't know?>"
    new "1. <¿En serio no lo sabes?>"

    # game/chapters/1_day.rpy:1593
    old "1. <The all-knowing Grim Reaper has \nnever heard of homestuck?>"
    new "1. <¿La omnisciente Parca nunca ha oído hablar de Homestuck?>"

    # game/chapters/1_day.rpy:1597
    old "1. <No, no, if you don't know, it's way funnier.>"
    new "1. <No, no, si no lo sabes, es mucho más divertido.>"

    # game/chapters/1_day.rpy:1600
    old "1. <Why do you type like that, though?>"
    new "1. <¿Por qué escribes así?>"

    # game/chapters/1_day.rpy:1604
    old "1. <The weird capitalization.>"
    new "1. <Ese extraño uso de las mayúsculas.>"

    # game/chapters/1_day.rpy:1607
    old "1. <Like, on every single word?>"
    new "1. <O sea, ¿en cada palabra?>"

    # game/chapters/1_day.rpy:1611
    old "1. <Not at all.>"
    new "1. <Para nada.>"

    # game/chapters/1_day.rpy:1614
    old "1. <I thought you were doing it as part \nof the weird reaper get up.>"
    new "1. <Pensé que lo hacías como parte del extraño atuendo de la Parca.>"

    # game/chapters/1_day.rpy:1632
    old "1. <That's exactly what I'm telling you.>"
    new "1. <Eso es exactamente lo que te estoy diciendo.>"

    # game/chapters/1_day.rpy:1634
    old "2. <Not correctly at all.>"
    new "2. <No es correcto en absoluto.>"

    # game/chapters/1_day.rpy:1656
    old "1. <What? What did you hang up for?>"
    new "1. <¿Qué? ¿Por qué colgaste?>"

    # game/chapters/1_day.rpy:1659
    old "1. <Hello?>"
    new "1. <¿Hola?>"

    # game/chapters/1_day.rpy:1661
    old "2. <Little reaper?>"
    new "2. <¿Parquita?>"

    # game/chapters/1_day.rpy:1664
    old "1. <Come on, I was finally having fun.>"
    new "1. <Vamos, por fin me estaba divirtiendo.>"

    # game/chapters/1_day.rpy:1668
    old "1. <Why'd you leave the call?>"
    new "1. <¿Por qué colgaste la llamada?>"

    # game/chapters/1_day.rpy:1673
    old "1. <Um... I'm not trying to make fun of you or anything, but...>"
    new "1. <Um... No estoy tratando de burlarme de ti ni nada, pero...>"

    # game/chapters/1_day.rpy:1676
    old "1. <It's still not right (lol)...>"
    new "1. <Sigue sin estar bien (lol)...>"

    # game/chapters/1_day.rpy:1680
    old "2. <That's wrong, too...>"
    new "2. <Eso también está mal...>"

    # game/chapters/1_day.rpy:1685
    old "1. <I guess I'll go, then.>"
    new "1. <Supongo que me iré, entonces.>"

    # game/chapters/1_day.rpy:1687
    old "2. <Well if you have nothing to say...>"
    new "2. <Bueno, si no tienes nada que decir...>"

    # game/chapters/1_day.rpy:1690
    old "1. <Guess I'll head to bed.>"
    new "1. <Creo que me voy a la cama.>"

    # game/chapters/1_day.rpy:1692
    old "3. <Don't Wanna Chat With Me Anymore, Little Reaper?> {font=gui/starthings.ttf}a{/font}"
    new "3. <¿Ya No Quieres Charlar Conmigo, Parquita?> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/1_day.rpy:1728
    old "1. <Are you... embarrassed?>"
    new "1. <¿Estás... avergonzado?>"

    # game/chapters/1_day.rpy:1731
    old "1. <Okay, that's kinda cute.>"
    new "1. <Okey, eso es bastante lindo.>"

    # game/chapters/1_day.rpy:1733
    old "2. <This is definitely not giving 'grim reaper'.>"
    new "2. <Esto definitivamente no da una imagen de 'la parca'.>"

    # game/chapters/1_day.rpy:1736
    old "2. <You're blushing so hard right now.>"
    new "2. <Te estás sonrojando mucho en este momento.>"

    # game/chapters/1_day.rpy:1738
    old "1. <I'm gonna take a screenshot.>"
    new "1. <Voy a hacer una captura de pantalla.>"

    # game/chapters/1_day.rpy:1740
    old "3. <No need to overreact.>"
    new "3. <No hay necesidad de exagerar.>"

    # game/chapters/1_day.rpy:1742
    old "1. <Then again, I'm not complaining.>"
    new "1. <Aunque, pensándolo bien, no me quejo.>"

    # game/chapters/1_day.rpy:1745
    old "1. <I can use this against you later.>"
    new "1. <Puedo usar esto en tu contra más tarde.>"

    # game/chapters/1_day.rpy:1747
    old "2. <You do actually look cute right now.>"
    new "2. <De verdad que ahora mismo te ves lindo.>"

    # game/chapters/1_day.rpy:1749
    old "4. <There he is! My little reaper.> {font=gui/starthings.ttf}a{/font}"
    new "4. <¡Ahí está! Mi pequeña parca.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/1_day.rpy:1754
    old "1. <Oh? Good to know.>"
    new "1. <¿Ah, sí? Bueno saberlo.>"

    # game/chapters/1_day.rpy:1759
    old "1. <I thought the way you typed was cute, by the way.>"
    new "1. <Por cierto, me pareció lindo cómo escribías.>"

    # game/chapters/1_day.rpy:1769
    old "1. <I thought we were moving past the whole soul thing...>"
    new "1. <Pensé que ya habíamos dejado atrás lo de las almas...>"

    # game/chapters/1_day.rpy:1775
    old "1. <You said that once or twice already.>"
    new "1. <Ya lo dijiste una o dos veces.>"

    # game/chapters/1_day.rpy:1778
    old "2. <Too bad. It's my soul.>"
    new "2. <Qué lástima. Es mi alma.>"

    # game/chapters/1_day.rpy:1782
    old "1. <And like I said, I don't believe you.>"
    new "1. <Y como dije, no te creo.>"

    # game/chapters/1_day.rpy:1786
    old "1. <I mean, it's been fun messing with you, but...>"
    new "1. <Quiero decir, ha sido divertido fastidiarte, pero...>"

    # game/chapters/1_day.rpy:1788
    old "2. <This has been amusing, but...>"
    new "2. <Ha sido divertido, pero...>"

    # game/chapters/1_day.rpy:1791
    old "1. <The 'Grim Reaper' isn't real.>"
    new "1. <La 'Parca' no es real.>"

    # game/chapters/1_day.rpy:1795
    old "1. <It's a myth.>"
    new "1. <Es un mito.>"

    # game/chapters/1_day.rpy:1802
    old "1. <No, you look like a very pretty stranger.>"
    new "1. <No, pareces un desconocido bastante bonito.>"

    # game/chapters/1_day.rpy:1805
    old "2. <Honestly, you do a little.>"
    new "2. <Honestamente, un poco sí.>"

    # game/chapters/1_day.rpy:1809
    old "1. <But the grim reaper isn't real.>"
    new "1. <Pero la parca no es real.>"

    # game/chapters/1_day.rpy:1813
    old "1. <Yeah, okay, okay. I get it.>"
    new "1. <Sí, okey, okey. Lo entiendo.>"

    # game/chapters/1_day.rpy:1816
    old "1. <I feel like we'll keep going in circles at this rate, so...>"
    new "1. <Siento que seguiremos dando vueltas a este ritmo, así que...>"

    # game/chapters/1_day.rpy:1819
    old "1. <How about a bet?>"
    new "1. <¿Qué tal una apuesta?>"

    # game/chapters/1_day.rpy:1830
    old "1. <Or maybe more like a deal.>"
    new "1. <O quizás más bien un trato.>"

    # game/chapters/1_day.rpy:1842
    old "1. <So, if what you claim is true...>"
    new "1. <Entonces, si lo que dices es cierto...>"

    # game/chapters/1_day.rpy:1845
    old "1. <Then you should have no problem taking \na soul, right?>"
    new "1. <No deberías tener ningún problema en llevarte un alma, ¿verdad?>"

    # game/chapters/1_day.rpy:1849
    old "1. <I'll allow you a free pass to my soul.>"
    new "1. <Te daré libre acceso a mi alma.>"

    # game/chapters/1_day.rpy:1853
    old "1. <If you can take it...>"
    new "1. <Si puedes llevártela...>"

    # game/chapters/1_day.rpy:1856
    old "1. <I'll allow it.>"
    new "1. <Lo permitiré.>"

    # game/chapters/1_day.rpy:1859
    old "1. <I won't even fight you for it.>"
    new "1. <Ni siquiera voy a pelear contigo por eso.>"

    # game/chapters/1_day.rpy:1861
    old "2. <I'll hand it over, happily.>"
    new "2. <Te la entregaré con mucho gusto.>"

    # game/chapters/1_day.rpy:1863
    old "1. <No fight.>"
    new "1. <Sin pelea.>"

    # game/chapters/1_day.rpy:1867
    old "1. <I'll present it to you on a silver platter.>"
    new "1. <Te la pondré  en bandeja de plata.>"

    # game/chapters/1_day.rpy:1870
    old "3. <I'll let you, and I'll only put up a {i}small{/i} fight.>"
    new "3. <Te dejaré hacerlo, y solo opondré una {i}pequeña{/i} resistencia.>"

    # game/chapters/1_day.rpy:1873
    old "1. <Just a little one. I promise.>"
    new "1. <Solo un poquito. Lo prometo.>"

    # game/chapters/1_day.rpy:1876
    old "4. <Which, obviously, you won't be able to do...> {font=gui/starthings.ttf}a{/font}"
    new "4. <Aunque, obviamente, no podrás hacerlo...> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/1_day.rpy:1880
    old "1. <What you claim to be doesn't exist, so of \ncourse you can't take it.>"
    new "1. <Lo que dices que eres no existe, así que, por supuesto, no puedes llevártela.>"

    # game/chapters/1_day.rpy:1883
    old "1. <But I... 'admire' your dedication to your role.>"
    new "1. <Pero yo... 'admiro' tu dedicación a tu trabajo.>"

    # game/chapters/1_day.rpy:1887
    old "1. <So, I'll humor you, and you can try.>"
    new "1. <Bueno, te haré el favor y puedes intentarlo.>"

    # game/chapters/1_day.rpy:1900
    old "1. <We will see about that.>"
    new "1. <Ya lo veremos.>"

    # game/chapters/1_day.rpy:1902
    old "2. <I'm glad you're confident.>"
    new "2. <Me alegra que tengas confianza en ti mismo.>"

    # game/chapters/1_day.rpy:1905
    old "1. <I'll give you a week.>"
    new "1. <Te daré una semana.>"

    # game/chapters/1_day.rpy:1908
    old "1. <That should be no problem for the grim reaper, no?>"
    new "1. <Eso no debería ser ningún problema para la Parca, ¿no?>"

    # game/chapters/1_day.rpy:1917
    old "1. <If you only need a day, why did you \nbother with all this?>"
    new "1. <Si solo necesitas un día, ¿para qué te tomaste tantas molestias?>"

    # game/chapters/1_day.rpy:1919
    old "2. <Then why are we both here?>"
    new "2. <Entonces, ¿por qué estamos aquí los dos?>"

    # game/chapters/1_day.rpy:1922
    old "1. <Are you perhaps... struggling?>"
    new "1. <¿Acaso estás... pasándola mal?>"

    # game/chapters/1_day.rpy:1933
    old "1. <And I am... uh...>"
    new "1. <Y yo estoy... eh...>"

    # game/chapters/1_day.rpy:1936
    old "1. <Not honor bound but you can trust me.>"
    new "1. <No estoy obligad[letra] por honor, pero puedes confiar en mí.>"

    # game/chapters/1_day.rpy:1943
    old "1. <If you can't...>"
    new "1. <Si no puedes...>"

    # game/chapters/1_day.rpy:1951
    old "1. <Your soul.>"
    new "1. <Tu alma.>"

    # game/chapters/1_day.rpy:1956
    old "2. <Your hand in marriage.>"
    new "2. <Tu mano en matrimonio.>"

    # game/chapters/1_day.rpy:1964
    old "1. <Do you own the house you're in?>"
    new "1. <¿Eres dueño de la casa en la que vives?>"

    # game/chapters/1_day.rpy:1968
    old "1. <So you've got a secure job, your own place, \nand you're handsome...>"
    new "1. <Así que tienes un trabajo seguro, tu propia casa y eres guapo...>"

    # game/chapters/1_day.rpy:1972
    old "1. <Husband material, I think.>"
    new "1. <Creo que eres un buen candidato para esposo.>"

    # game/chapters/1_day.rpy:1975
    old "1. <I'm kidding.>"
    new "1. <Estoy bromeando.>"

    # game/chapters/1_day.rpy:1982
    old "1. <How about your soul, instead?>"
    new "1. <¿Y qué hay de tu alma?>"

    # game/chapters/1_day.rpy:1985
    old "1. <Then it's an even bet.>"
    new "1. <Entonces es una apuesta justa.>"

    # game/chapters/1_day.rpy:1991
    old "1. <Scared?>"
    new "1. <¿Asustado?>"

    # game/chapters/1_day.rpy:1996
    old "1. <Except for typing incorrectly.>"
    new "1. <Excepto a escribir mal.>"

    # game/chapters/1_day.rpy:2015
    old "1. <Eat it, probably.>"
    new "1. <Comérmela. Probablemente.>"

    # game/chapters/1_day.rpy:2022
    old "1. <I wonder how nutritious it is...?>"
    new "1. <Me pregunto qué tan nutritivo será...>"

    # game/chapters/1_day.rpy:2025
    old "1. <Will I get an extra eight lives?>"
    new "1. <¿Tendré ocho vidas extra?>"

    # game/chapters/1_day.rpy:2029
    old "1. <Meow.>"
    new "1. <Miau.>"

    # game/chapters/1_day.rpy:2033
    old "1. <If I consume a bunch of souls, will I live forever?>"
    new "1. <Si consumo un montón de almas, ¿viviré para siempre?>"

    # game/chapters/1_day.rpy:2036
    old "1. <Would I be like a god?>"
    new "1. <¿Sería como un dios?>"

    # game/chapters/1_day.rpy:2039
    old "1. <Or maybe a demon? That seems cooler than a god.>"
    new "1. <¿O tal vez un demonio? Eso parece más interesante que un dios.>"

    # game/chapters/1_day.rpy:2049
    old "2. <We could mix our souls and make some \nkind of... soul baby.>"
    new "2. <Podríamos mezclar nuestras almas y crear una especie de... bebé alma.>"

    # game/chapters/1_day.rpy:2057
    old "1. <You know, a soul baby.>"
    new "1. <Ya sabes, un bebé alma.>"

    # game/chapters/1_day.rpy:2063
    old "1. <What's the issue then?>"
    new "1. <¿Cuál es el problema entonces?>"

    # game/chapters/1_day.rpy:2069
    old "1. <Guess I'll just hold onto the soul for now, then.>"
    new "1. <Supongo que por ahora me quedaré con el alma.>"

    # game/chapters/1_day.rpy:2072
    old "1. <We can revisit the soul baby thing later.>"
    new "1. <Podemos volver a hablar del tema del bebé alma más tarde.>"

    # game/chapters/1_day.rpy:2078
    old "1. <Fine, if not a soul baby...>"
    new "1. <Está bien, si no es un bebé alma...>"

    # game/chapters/1_day.rpy:2081
    old "1. <I guess I'll make a necklace out of it or something...>"
    new "1. <Supongo que haré un collar con eso o algo así...>"

    # game/chapters/1_day.rpy:2085
    old "3. <I haven't decided yet.>"
    new "3. <Aún no lo he decidido.>"

    # game/chapters/1_day.rpy:2091
    old "1. <You don't know that!>"
    new "1. <¡Eso no lo sabes!>"

    # game/chapters/1_day.rpy:2098
    old "1. <Hah. You wish it was that easy.>"
    new "1. <Ja. Ya quisieras que fuera tan fácil.>"

    # game/chapters/1_day.rpy:2101
    old "1. <I'll win for sure.>"
    new "1. <Seguro que ganaré.>"

    # game/chapters/1_day.rpy:2103
    old "2. <I don't lose.>"
    new "2. <Yo no pierdo.>"

    # game/chapters/1_day.rpy:2112
    old "1. <Uh. That's kinda morbid.>"
    new "1. <Eh... Eso es un poco perturbador.>"

    # game/chapters/1_day.rpy:2116
    old "1. <So...>"
    new "1. <Entonces...>"

    # game/chapters/1_day.rpy:2119
    old "1. <Say you do win...>"
    new "1. <Digamos que ganas...>"

    # game/chapters/1_day.rpy:2122
    old "1. <Will we make a special date of it?>"
    new "1. <¿Podríamos convertirlo en una cita especial?>"

    # game/chapters/1_day.rpy:2126
    old "1. <Well, if it's going to be beautiful...>"
    new "1. <Bueno, si va a ser algo hermoso...>"

    # game/chapters/1_day.rpy:2129
    old "1. <We could start the night with a movie...>"
    new "1. <Podríamos empezar la noche con una película...>"

    # game/chapters/1_day.rpy:2133
    old "1. <Some wine...>"
    new "1. <Un poco de vino...>"

    # game/chapters/1_day.rpy:2137
    old "1. <Damn, that's a shame.>"
    new "1. <Vaya, qué lástima.>"

    # game/chapters/1_day.rpy:2140
    old "4. <Sounds like you know I'm going to win.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Por lo visto, sabes que voy a ganar.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/1_day.rpy:2144
    old "1. <There's a first time for everything, I suppose!>"
    new "1. <¡Supongo que siempre hay una primera vez para todo!>"

    # game/chapters/1_day.rpy:2147
    old "1. <I guess I'll be your first.>"
    new "1. <Parece que voy a ser tu primer[letra].>"

    # game/chapters/1_day.rpy:2151
    old "1. <This is gonna be fun.>"
    new "1. <Esto va a ser divertido.>"

    # game/chapters/1_day.rpy:2155
    old "1. <Wouldn't a reaper also be sadistic?>"
    new "1. <¿Una parca no sería también sádica?>"

    # game/chapters/1_day.rpy:2159
    old "1. <Kinda hypocritical, no?>"
    new "1. <Un poco hipócrita, ¿no?>"

    # game/chapters/1_day.rpy:2163
    old "1. <Happy to hear it.>"
    new "1. <Me alegra saberlo.>"

    # game/chapters/1_day.rpy:2167
    old "1. <My poor little reaper. It must be awful.>"
    new "1. <Mi pobre parquita. Debe de ser horrible.>"

    # game/chapters/1_day.rpy:2173
    old "1. <Stop talking?>"
    new "1. <¿Dejar de hablar?>"

    # game/chapters/1_day.rpy:2176
    old "1. <I'd like to draw your attention to that fact \nthat {i}you{/i} called {i}me{/i}.>"
    new "1. <Me gustaría señalar el hecho de que {i}tú{/i} me llamaste {i}a mí{/i}.>"

    # game/chapters/1_day.rpy:2180
    old "1. <{i}You{/i} messaged {i}me{/i}.>"
    new "1. <{i}Tú{/i} me enviaste un mensaje {i}a mí{/i}.>"

    # game/chapters/1_day.rpy:2183
    old "1. <Seems pointless if you don't WANT me to talk to you.>"
    new "1. <No tiene mucho sentido si no QUIERES que te hable.>"

    # game/chapters/1_day.rpy:2189
    old "1. <I must be reaaaaal important to you, huh?>"
    new "1. <Debo ser taaaaan importante para ti, ¿eh?>"

    # game/chapters/1_day.rpy:2193
    old "1. <Mmhm. We'll see.>"
    new "1. <Mmhm. Ya veremos.>"

    # game/chapters/1_day.rpy:2197
    old "1. <So you admit there is a 'we'.>"
    new "1. <Así que admites que existe un 'nosotros'.>"

    # game/chapters/1_day.rpy:2201
    old "1. <But it's so fun!>"
    new "1. <¡Pero es tan divertido!>"

    # game/chapters/1_day.rpy:2205
    old "1. <Anyway, as fun as this is...>"
    new "1. <De todos modos, por muy divertido que sea esto...>"

    # game/chapters/1_day.rpy:2208
    old "1. <It's getting kinda late.>"
    new "1. <Se está haciendo tarde.>"

    # game/chapters/1_day.rpy:2211
    old "1. <We can't all waste our time messaging \nrandom people on the internet.>"
    new "1. <No podemos perder el tiempo enviando mensajes a personas al azar en Internet.>"

    # game/chapters/1_day.rpy:2215
    old "1. <Done as I was told?>"
    new "1. <¿Hacer lo que me dijeron?>"

    # game/chapters/1_day.rpy:2219
    old "1. <I don't usually follow orders from strangers.>"
    new "1. <Normalmente no sigo las órdenes de desconocidos.>"

    # game/chapters/1_day.rpy:2222
    old "2. <People usually do what {i}I{/i} tell them to do.>"
    new "2. <La gente suele hacer lo que {i}yo{/i} les pido que hagan.>"

    # game/chapters/1_day.rpy:2227
    old "1. <My, you're very forward, aren't you?>"
    new "1. <Vaya, eres muy atrevido, ¿no?>"

    # game/chapters/1_day.rpy:2229
    old "1. <What are you going to order me to do next?>"
    new "1. <¿Qué me vas a ordenar que haga ahora?>"

    # game/chapters/1_day.rpy:2236
    old "2. <No chance, sorry.>"
    new "2. <Ni hablar, lo siento.>"

    # game/chapters/1_day.rpy:2240
    old "1. <I'm sure you can come up with something \nmore interesting to ask for.>"
    new "1. <Seguro que se te ocurre algo más interesante que pedir.>"

    # game/chapters/1_day.rpy:2245
    old "1. <Guess I'll just store away 'the grim reaper likes \nto order people around' for a later time.>"
    new "1. <Supongo que guardaré 'a la parca le gusta dar órdenes a la gente' para más adelante.>"

    # game/chapters/1_day.rpy:2250
    old "1. <I know you're a self proclaimed {i}grim reaper{/i}.>"
    new "1. <Sé que te autoproclamas {i}la Parca{/i}.>"

    # game/chapters/1_day.rpy:2254
    old "1. <Doesn't that count?>"
    new "1. <¿Eso no cuenta?>"

    # game/chapters/1_day.rpy:2258
    old "1. <We'll see about that.>"
    new "1. <Ya lo veremos.>"

    # game/chapters/1_day.rpy:2262
    old "2. <You do seem like the type to enjoy bossing \npeople around.>"
    new "2. <Pareces de los que disfrutan mandando a los demás.>"

    # game/chapters/1_day.rpy:2268
    old "2. <You admit it so readily...>"
    new "2. <Lo admites tan fácilmente...>"

    # game/chapters/1_day.rpy:2275
    old "1. <I'd argue that this is {i}your{/i} fantasy.>"
    new "1. <Yo diría que esa es {i}tu{/i} fantasía.>"

    # game/chapters/1_day.rpy:2278
    old "1. <You were the one who brought up \nme following your 'orders'.>"
    new "1. <Fuiste tú quien sacó el tema de que yo siguiera tus 'órdenes'.>"

    # game/chapters/1_day.rpy:2282
    old "1. <Sadly not everything is easy in life.>"
    new "1. <Por desgracia, no todo es fácil en la vida.>"

    # game/chapters/1_day.rpy:2285
    old "1. <Or death, in this case.>"
    new "1. <O la muerte, en este caso.>"

    # game/chapters/1_day.rpy:2289
    old "1. <You like talking to me.>"
    new "1. <Te gusta hablar conmigo.>"

    # game/chapters/1_day.rpy:2293
    old "1. <I know you do.>"
    new "1. <Sé que te gusta.>"

    # game/chapters/1_day.rpy:2297
    old "1. <You like it so much.>"
    new "1. <Te gusta mucho.>"

    # game/chapters/1_day.rpy:2301
    old "1. <Maybe it's like...>"
    new "1. <Quizás sea algo como...>"

    # game/chapters/1_day.rpy:2304
    old "1. <So many negatives added together \nit's become a positive.>"
    new "1. <Se han juntado tantas cosas negativas que terminaron convirtiéndose en algo positivo.>"

    # game/chapters/1_day.rpy:2307
    old "1. <So you actually agree.>"
    new "1. <Entonces, en realidad estás de acuerdo.>"

    # game/chapters/1_day.rpy:2311
    old "3. <I'll pass, actually.>"
    new "3. <De hecho, paso.>"

    # game/chapters/1_day.rpy:2317
    old "1. <It's part of my charm, you'll have to get \nused to it.>"
    new "1. <Es parte de mi encanto, tendrás que acostumbrarte.>"

    # game/chapters/1_day.rpy:2321
    old "1. <That would make your job too easy.>"
    new "1. <Eso haría que tu trabajo fuera demasiado fácil.>"

    # game/chapters/1_day.rpy:2326
    old "1. <Stop it, you're making me feel important.>"
    new "1. <Ya basta, me estás haciendo sentir importante.>"

    # game/chapters/1_day.rpy:2331
    old "2. <I guess I'm that special.>"
    new "2. <Supongo que soy así de especial.>"

    # game/chapters/1_day.rpy:2337
    old "4. <Maybe you should follow my orders, little reaper.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Quizás deberías seguir mis órdenes, parquita.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/1_day.rpy:2342
    old "1. <Oh? No arguments?>"
    new "1. <¿Ah, sí? ¿Sin objeciones?>"

    # game/chapters/1_day.rpy:2345
    old "1. <Perhaps you'd like that after all?>"
    new "1. <¿Quizás te gustaría eso después de todo?>"

    # game/chapters/1_day.rpy:2349
    old "1. <Again with the lack of disagreement.>"
    new "1. <Otra vez sin llevarme la contraria.>"

    # game/chapters/1_day.rpy:2354
    old "1. <Whatever helps you sleep at night, my little reaper.>"
    new "1. <Lo que te ayude a dormir por las noches, mi parquita.>"

    # game/chapters/1_day.rpy:2358
    old "1. <You kind of give 'lost puppy' vibes.>"
    new "1. <Das una especie de vibra de cachorro perdido.>"

    # game/chapters/1_day.rpy:2363
    old "1. <I think it's the little pout you get sometimes.>"
    new "1. <Creo que es ese pequeño puchero que haces a veces.>"

    # game/chapters/1_day.rpy:2366
    old "1. <It makes me both want to bully you and look after you.>"
    new "1. <Me dan ganas tanto de intimidarte como de cuidarte.>"

    # game/chapters/1_day.rpy:2369
    old "2. <You seem like the submissive type.>"
    new "2. <Pareces del tipo sumiso.>"

    # game/chapters/1_day.rpy:2382
    old "1. <It's cute when you act all tough like that.>"
    new "1. <Es lindo cuando te haces el rudo así.>"

    # game/chapters/1_day.rpy:2385
    old "1. <Especially when your cheeks are pink.>"
    new "1. <Especialmente cuando tus mejillas están rosadas.>"

    # game/chapters/1_day.rpy:2389
    old "3. <There's something attractive about telling a \nhandsome man what to do.>"
    new "3. <Hay algo atractivo en decirle a un hombre guapo lo que tiene que hacer.>"

    # game/chapters/1_day.rpy:2393
    old "1. <Then you'll be in troooouble.>"
    new "1. <Entonces estarás en problemas.>"

    # game/chapters/1_day.rpy:2397
    old "1. <You might get disciplined.>"
    new "1. <Es posible que te castiguen.>"

    # game/chapters/1_day.rpy:2401
    old "1. <But maybe you'd like that.>"
    new "1. <Pero tal vez eso te gustaría.>"

    # game/chapters/1_day.rpy:2417
    old "1. <Dismissed...?>"
    new "1. <¿Retirarme...?>"

    # game/chapters/1_day.rpy:2422
    old "1. <Aw, but I was having so much fun.>"
    new "1. <Aw, pero me estaba divirtiendo tanto.>"

    # game/chapters/1_day.rpy:2427
    old "2. <What if I say no?>"
    new "2. <¿Y si digo que no?>"

    # game/chapters/1_day.rpy:2432
    old "1. <Okay, I've changed my mind.>"
    new "1. <Okey, cambié de opinión.>"

    # game/chapters/1_day.rpy:2437
    old "1. <Woah, you're acting like you care.>"
    new "1. <Uy, actúas como si te importara>"

    # game/chapters/1_day.rpy:2441
    old "1. <You can just say 'sleep well', you know.>"
    new "1. <Puedes decir simplemente 'que duermas bien', ya sabes.>"

    # game/chapters/1_day.rpy:2445
    old "1. <G'night, little reaper.>"
    new "1. <Buenas noches, parquita.>"

    # game/chapters/1_day.rpy:2468
    old "1. <Hey, wait a second...>"
    new "1. <Oye, espera un momento...>"

    # game/chapters/1_day.rpy:2471
    old "1. <How did you know my name?>"
    new "1. <¿Cómo supiste mi nombre?>"

    # game/chapters/1_day.rpy:2475
    old "1. <I never told you!>"
    new "1. <¡Nunca te lo dije!>"

    # game/chapters/1_day.rpy:2480
    old "1. <Aw, you circled it?>"
    new "1. <Aw, ¿lo marcaste con un círculo?>"

    # game/chapters/1_day.rpy:2484
    old "1. <Night!>"
    new "1. <¡Buenas noches!>"

    # game/chapters/1_day.rpy:2487
    old "1. <Sleep well, grimmy :)>"
    new "1. <Duerme bien, Parquita :)>"

    # game/chapters/1_day.rpy:2490
    old "1. <Oh, wait, can I change my username?>"
    new "1. <Oh, espera, ¿puedo cambiar mi nombre de usuario?>"

    # game/chapters/1_day.rpy:2494
    old "1. <I just want to.>"
    new "1. <Porque quiero.>"

    # game/chapters/1_day.rpy:2498
    old "1. <Wow, easier to convince than I expected.>"
    new "1. <Wow, más fácil de convencer de lo que esperaba.>"

    # game/chapters/1_day.rpy:2502
    old "2. <This one is kinda lame.>"
    new "2. <Este es un poco patético.>"

    # game/chapters/1_day.rpy:2508
    old "1. <But can I change it or not?>"
    new "1. <¿Pero puedo cambiarlo o no?>"

    # game/chapters/1_day.rpy:2512
    old "1. <What about my picture?>"
    new "1. <¿Y mi foto?>"

    # game/chapters/1_day.rpy:2516
    old "1. <Just for you ;)>"
    new "1. <Solo por ti ;)>"

    # game/chapters/1_day.rpy:2521
    old "2. <Aren't these basic messaging app features?>"
    new "2. <¿No son esas las funciones básicas de una aplicación de mensajería?>"

    # game/chapters/1_day.rpy:2533
    old "1. <Thanks grimmy. Night night!>"
    new "1. <Gracias Parquita. ¡Buenas noches!>"

