# TODO: Translation updated at 2026-10-15 18:36

# game/chapters/3_roomexplore.rpy:219
translate Spanish bed_hub3_97529fad:

    # "Your favorite bed."
    "Tu cama favorita."

# game/chapters/3_roomexplore.rpy:220
translate Spanish bed_hub3_61271b0b:

    # "It also happens to be your only bed, but that doesn't matter."
    "También resulta ser tu única cama, pero eso no importa."

# game/chapters/3_roomexplore.rpy:221
translate Spanish bed_hub3_de6f9362:

    # "Your soft [bed_color] bedding sits against pristine sheets."
    "Tu suave ropa de cama de color [bed_color!t] descansa sobre unas sábanas impecables."

# game/chapters/3_roomexplore.rpy:222
translate Spanish bed_hub3_ed106b76:

    # "You sit down on the edge of the bed and look around your room."
    "Te sientas en el borde de la cama y miras alrededor de tu habitación."

# game/chapters/3_roomexplore.rpy:223
translate Spanish bed_hub3_088975bf:

    # "It makes you smile - your style has changed a lot over the years, but you're very proud of how it looks right now."
    "Sonríes al verlo. Tu estilo ha cambiado mucho con los años, pero estás muy orgullos[letra] de cómo luce ahora."

# game/chapters/3_roomexplore.rpy:224
translate Spanish bed_hub3_0bdbf32b:

    # "Before, it was..."
    "Antes, era..."

# game/chapters/3_roomexplore.rpy:229
translate Spanish bed_hub3_0bafb250:

    # "You have always been a collector. That hasn't changed, though you're waiting to unpack all of your anime merch when you have more space."
    "Siempre te ha gustado coleccionar cosas. Eso no ha cambiado, aunque estás esperando a tener más espacio para sacar todas tus figuras y artículos de anime."

# game/chapters/3_roomexplore.rpy:232
translate Spanish bed_hub3_65b7ac93:

    # "White walls, white bedding, minimal decor. You like the new color."
    "Paredes blancas, ropa de cama blanca, decoración minimalista. Te gusta el nuevo color."

# game/chapters/3_roomexplore.rpy:235
translate Spanish bed_hub3_7e095f57:

    # "Rainbows everywhere you looked! You've always loved bright colors and lots of decor."
    "¡Había arcoíris por todas partes! Siempre te han encantado los colores vivos y tener muchísima decoración."

# game/chapters/3_roomexplore.rpy:238
translate Spanish bed_hub3_f6de5aab:

    # "You shared your room with a sibling growing up, so this is the first time you've got to make a space your own."
    "Cuando eras pequeñ[letra], compartías tu habitación con un hermano o hermana, así que esta es la primera vez que tienes un espacio propio."

# game/chapters/3_roomexplore.rpy:241
translate Spanish bed_hub3_b0feba74:

    # "You can't wait to see how your style will continue to change into the future."
    "Te emociona pensar en cómo seguirá evolucionando tu estilo con el paso del tiempo."

# game/chapters/3_roomexplore.rpy:249
translate Spanish door_hub3_48c0cf48:

    # "The door leads out to the hallway beyond."
    "La puerta da al pasillo que hay más allá."

# game/chapters/3_roomexplore.rpy:250
translate Spanish door_hub3_e22b0a30:

    # "Luckily, you bought groceries on the way home from work, so you don't really have anywhere to go at this time of day."
    "Por suerte, compraste comida al volver del trabajo, así que no tienes ningún sitio al que ir a estas horas del día."

# game/chapters/3_roomexplore.rpy:251
translate Spanish door_hub3_4b602cf0:

    # "However, perhaps now is a good chance to hear more from your mysterious neighbors..."
    "Sin embargo, quizás ahora sea una buena oportunidad para escuchar más de tus misteriosos vecinos..."

# game/chapters/3_roomexplore.rpy:257
translate Spanish door_hub3_44109577:

    # "You hear the creak of someone ascending the staircase in the hall outside of your apartment."
    "Oyes el crujido de unos pasos mientras alguien sube las escaleras del pasillo, fuera de tu apartamento."

# game/chapters/3_roomexplore.rpy:258
translate Spanish door_hub3_67d930cc:

    # "You put your ear to the door, straining to hear more, when the sound of someone's phone ringing echoes through the hall."
    "Pegas el oído a la puerta, esforzándote por escuchar algo más, cuando el sonido de un teléfono resuena por el pasillo."

# game/chapters/3_roomexplore.rpy:259
translate Spanish door_hub3_2a016a86:

    # "A deeper voice answers."
    "Una voz profunda contesta."

# game/chapters/3_roomexplore.rpy:260
translate Spanish door_hub3_75b43268:

    # "'Hello?'"
    "'¿Hola?'"

# game/chapters/3_roomexplore.rpy:261
translate Spanish door_hub3_dfe8d11b:

    # "There's a pause as, you assume, the person on the other end of the line replies."
    "Hay una pausa mientras la persona al otro lado de la línea responde, supones."

# game/chapters/3_roomexplore.rpy:262
translate Spanish door_hub3_a6ebe003:

    # "'I'm... working on it. Yes, I'm here. I rented an apartment.'"
    "'Estoy... trabajando en ello. Sí, estoy aquí. Alquilé un apartamento.'"

# game/chapters/3_roomexplore.rpy:263
translate Spanish door_hub3_1771ec9e:

    # "'I know it's not necessary, but... let me just do things the way I want to do them, okay?'"
    "'Sé que no es necesario, pero... déjame hacer las cosas a mi manera, ¿sí?'"

# game/chapters/3_roomexplore.rpy:264
translate Spanish door_hub3_02e7fe74:

    # "There's an even longer pause. The deep voice lowers in reply."
    "Hay una pausa aún más larga. La voz profunda baja al responder."

# game/chapters/3_roomexplore.rpy:265
translate Spanish door_hub3_c367e7dc:

    # "'Let me just have this. Please. I know this is meant to be a punishment, but give me a little longer.'"
    "'Déjame disfrutar de esto. Por favor. Sé que se supone que esto es un castigo, pero dame un poco más de tiempo.'"

# game/chapters/3_roomexplore.rpy:266
translate Spanish door_hub3_d4ebcfa5:

    # "'Let me just pretend for a little longer.'"
    "'Déjame fingir un poco más.'"

# game/chapters/3_roomexplore.rpy:267
translate Spanish door_hub3_8dc8f83d:

    # "You hear a sigh as the footsteps begin again. One of the two people on that call hung up, and you think it was probably the other person."
    "Oyes un suspiro y los pasos comienzan a escucharse de nuevo. Una de las dos personas colgó la llamada, y supones que fue la otra."

# game/chapters/3_roomexplore.rpy:268
translate Spanish door_hub3_c24beb0e:

    # "You then hear a knock. It almost makes you jump, but it's next door."
    "Luego escuchas un golpe. Casi te hace saltar, pero es en la puerta de al lado."

# game/chapters/3_roomexplore.rpy:269
translate Spanish door_hub3_7a667c52:

    # "A voice both light and airy calls out. It reminds you a little of a warm summer breeze."
    "Una voz suave y ligera llama desde el otro lado. Te recuerda un poco a una cálida brisa de verano."

# game/chapters/3_roomexplore.rpy:270
translate Spanish door_hub3_99c4dba1:

    # "'You're early!'"
    "'¡Llegaste temprano!'"

# game/chapters/3_roomexplore.rpy:271
translate Spanish door_hub3_d0995a4b:

    # "The deeper voice - like a cool winter night - responds."
    "La voz más grave —como una fría noche de invierno— responde."

# game/chapters/3_roomexplore.rpy:272
translate Spanish door_hub3_e6d14dd8:

    # "'What can I say? I can't stay away. I mean, I might have ulterior motives... you did say you were baking today, right?'"
    "'¿Qué puedo decir? No puedo resistirme a venir. Bueno, puede que tenga otros motivos... Dijiste que hoy ibas a preparar algo al horno, ¿verdad?'"

# game/chapters/3_roomexplore.rpy:273
translate Spanish door_hub3_2c095858:

    # "The light voice laughs."
    "La voz ligera ríe."

# game/chapters/3_roomexplore.rpy:274
translate Spanish door_hub3_3cff3b64:

    # "'So you're just after my cookies!'"
    "'¡Así que solo vienes por mis galletas!'"

# game/chapters/3_roomexplore.rpy:275
translate Spanish door_hub3_5b53be15:

    # "'You caught me. Sorry.'"
    "'Me descubriste. Lo siento.'"

# game/chapters/3_roomexplore.rpy:276
translate Spanish door_hub3_606a5fa9:

    # "'Come in. We can eat some before we go. Luckily I saved you a couple, huh?'"
    "'Entra. Podemos comer algunas antes de irnos. Por suerte te guardé un par, ¿eh?'"

# game/chapters/3_roomexplore.rpy:277
translate Spanish door_hub3_7203a66f:

    # "The voices then become muffled as a door closes."
    "Las voces se oyen cada vez más apagadas hasta que se cierra una puerta."

# game/chapters/3_roomexplore.rpy:278
translate Spanish door_hub3_b4e14e5a:

    # "That seems to be all you'll hear for today."
    "Eso parece ser todo lo que escucharás por hoy."

# game/chapters/3_roomexplore.rpy:292
translate Spanish door_hub3_44109577_1:

    # "You hear the creak of someone ascending the staircase in the hall outside of your apartment."
    "Oyes el crujido de unos pasos mientras alguien sube las escaleras del pasillo, fuera de tu apartamento."

# game/chapters/3_roomexplore.rpy:293
translate Spanish door_hub3_67d930cc_1:

    # "You put your ear to the door, straining to hear more, when the sound of someone's phone ringing echoes through the hall."
    "Pegas el oído a la puerta, esforzándote por escuchar algo más, cuando el sonido de un teléfono resuena por el pasillo."

# game/chapters/3_roomexplore.rpy:294
translate Spanish door_hub3_2a016a86_1:

    # "A deeper voice answers."
    "Una voz profunda contesta."

# game/chapters/3_roomexplore.rpy:295
translate Spanish door_hub3_75b43268_1:

    # "'Hello?'"
    "'¿Hola?'"

# game/chapters/3_roomexplore.rpy:296
translate Spanish door_hub3_dfe8d11b_1:

    # "There's a pause as, you assume, the person on the other end of the line replies."
    "Hay una pausa mientras la persona al otro lado de la línea responde, supones."

# game/chapters/3_roomexplore.rpy:297
translate Spanish door_hub3_a6ebe003_1:

    # "'I'm... working on it. Yes, I'm here. I rented an apartment.'"
    "'Estoy... trabajando en ello. Sí, estoy aquí. Alquilé un apartamento.'"

# game/chapters/3_roomexplore.rpy:298
translate Spanish door_hub3_1771ec9e_1:

    # "'I know it's not necessary, but... let me just do things the way I want to do them, okay?'"
    "'Sé que no es necesario, pero... déjame hacer las cosas a mi manera, ¿sí?'"

# game/chapters/3_roomexplore.rpy:299
translate Spanish door_hub3_02e7fe74_1:

    # "There's an even longer pause. The deep voice lowers in reply."
    "Hay una pausa aún más larga. La voz profunda baja al responder."

# game/chapters/3_roomexplore.rpy:300
translate Spanish door_hub3_c367e7dc_1:

    # "'Let me just have this. Please. I know this is meant to be a punishment, but give me a little longer.'"
    "'Déjame disfrutar de esto. Por favor. Sé que se supone que esto es un castigo, pero dame un poco más de tiempo.'"

# game/chapters/3_roomexplore.rpy:301
translate Spanish door_hub3_d4ebcfa5_1:

    # "'Let me just pretend for a little longer.'"
    "'Déjame fingir un poco más.'"

# game/chapters/3_roomexplore.rpy:302
translate Spanish door_hub3_8dc8f83d_1:

    # "You hear a sigh as the footsteps begin again. One of the two people on that call hung up, and you think it was probably the other person."
    "Oyes un suspiro y los pasos comienzan a escucharse de nuevo. Una de las dos personas colgó la llamada, y supones que fue la otra."

# game/chapters/3_roomexplore.rpy:303
translate Spanish door_hub3_c24beb0e_1:

    # "You then hear a knock. It almost makes you jump, but it's next door."
    "Luego escuchas un golpe. Casi te hace saltar, pero es en la puerta de al lado."

# game/chapters/3_roomexplore.rpy:304
translate Spanish door_hub3_7a667c52_1:

    # "A voice both light and airy calls out. It reminds you a little of a warm summer breeze."
    "Una voz suave y ligera llama desde el otro lado. Te recuerda un poco a una cálida brisa de verano."

# game/chapters/3_roomexplore.rpy:305
translate Spanish door_hub3_99c4dba1_1:

    # "'You're early!'"
    "'¡Llegaste temprano!'"

# game/chapters/3_roomexplore.rpy:306
translate Spanish door_hub3_d0995a4b_1:

    # "The deeper voice - like a cool winter night - responds."
    "La voz más grave —como una fría noche de invierno— responde."

# game/chapters/3_roomexplore.rpy:307
translate Spanish door_hub3_e6d14dd8_1:

    # "'What can I say? I can't stay away. I mean, I might have ulterior motives... you did say you were baking today, right?'"
    "'¿Qué puedo decir? No puedo resistirme a venir. Bueno, puede que tenga otros motivos... Dijiste que hoy ibas a preparar algo al horno, ¿verdad?'"

# game/chapters/3_roomexplore.rpy:308
translate Spanish door_hub3_2c095858_1:

    # "The light voice laughs."
    "La voz ligera ríe."

# game/chapters/3_roomexplore.rpy:309
translate Spanish door_hub3_3cff3b64_1:

    # "'So you're just after my cookies!'"
    "'¡Así que solo vienes por mis galletas!'"

# game/chapters/3_roomexplore.rpy:310
translate Spanish door_hub3_5b53be15_1:

    # "'You caught me. Sorry.'"
    "'Me descubriste. Lo siento.'"

# game/chapters/3_roomexplore.rpy:311
translate Spanish door_hub3_606a5fa9_1:

    # "'Come in. We can eat some before we go. Luckily I saved you a couple, huh?'"
    "'Entra. Podemos comer algunas antes de irnos. Por suerte te guardé un par, ¿eh?'"

# game/chapters/3_roomexplore.rpy:312
translate Spanish door_hub3_7203a66f_1:

    # "The voices then become muffled as a door closes."
    "Las voces se oyen cada vez más apagadas hasta que se cierra una puerta."

# game/chapters/3_roomexplore.rpy:313
translate Spanish door_hub3_b4e14e5a_1:

    # "That seems to be all you'll hear for today."
    "Eso parece ser todo lo que escucharás por hoy."

# game/chapters/3_roomexplore.rpy:325
translate Spanish door_hub3_3d403dd1:

    # "The hallway beyond is silent."
    "El pasillo de afuera está en silencio."

# game/chapters/3_roomexplore.rpy:326
translate Spanish door_hub3_84ccc16b:

    # "You'll have to wait until tomorrow to hear more about the two mysterious neighbors."
    "Tendrás que esperar hasta mañana para saber más de los dos misteriosos vecinos."

# game/chapters/3_roomexplore.rpy:340
translate Spanish snake_hub3_64ab1153:

    # "[pet_name] is having a little time out and about on your bed."
    "[pet_name] está pasando un rato en tu cama."

# game/chapters/3_roomexplore.rpy:341
translate Spanish snake_hub3_b10aa26c:

    # "[pet_She] spends a little (supervised) time each day exploring your room. Sometimes it makes you laugh - you pretty much baby-proofed your apartment just for [pet_name]."
    "[pet_She!t] pasa un rato cada día explorando tu habitación bajo tu supervisión. A veces te hace reír pensar que prácticamente adaptaste todo tu apartamento para que fuera seguro para [pet_name]."

# game/chapters/3_roomexplore.rpy:342
translate Spanish snake_hub3_0e1dee4e:

    # "Fortunately, you like keeping the apartment heated, so it's comfortable for both of you."
    "Por suerte, te gusta mantener el apartamento con calefacción, así que es cómodo para ambos."

# game/chapters/3_roomexplore.rpy:343
translate Spanish snake_hub3_164b5d50:

    # "You run your fingers down [pet_her]'s scales. Soon it will be time for [pet_her2] to go back into [pet_her] enclosure. For now, the two of you spend a little more time together."
    "Deslizas los dedos por las escamas de [pet_name]. Pronto llegará la hora de que vuelva a su terrario. Por ahora, ambos disfrutan un rato más juntos."

# game/chapters/3_roomexplore.rpy:348
translate Spanish snake_hub3_46376a45:

    # "You pull out your snake's favorite knitted tunnel and place it on the bed next to [pet_her2]."
    "Sacas el túnel tejido favorito de tu serpiente y lo colocas en la cama junto a [pet_she!t]."

# game/chapters/3_roomexplore.rpy:349
translate Spanish snake_hub3_5aeeb6ec:

    # "[pet_She] instantly slithers in."
    "[pet_She!t] se desliza dentro al instante."

# game/chapters/3_roomexplore.rpy:350
translate Spanish snake_hub3_0f5de544:

    # "You..."
    "Tú..."

# game/chapters/3_roomexplore.rpy:356
translate Spanish snake_hub3_4c068fc8:

    # "You're pretty good and knitting and crochet, and you make a lot of things for [pet_name] to play with."
    "Se te da muy bien tejer y hacer crochet, así que haces muchas cosas para que [pet_name] juegue."

# game/chapters/3_roomexplore.rpy:357
translate Spanish snake_hub3_7b5e647c:

    # "You're happy to have a good use of your skills."
    "Te alegra poder aprovechar tus habilidades."

# game/chapters/3_roomexplore.rpy:360
translate Spanish snake_hub3_5ac890bd:

    # "You're not very good at knitting, but there IS something you are good at - spending money." id snake_hub3_5ac890bd
    "No se te da muy bien tejer, pero hay ALGO que sí se te da de maravilla: gastar dinero." id snake_hub3_5ac890bd

# game/chapters/3_roomexplore.rpy:361
translate Spanish snake_hub3_9d65f49b:

    # "You bought this tunnel online from a local creator, and [pet_name] absolutely loves it."
    "Compraste este túnel en línea a un creador local, y a [pet_name] le encanta muchísimo."

# game/chapters/3_roomexplore.rpy:363
translate Spanish snake_hub3_4b49ffdc:

    # "You spend a while playing with [pet_name] before putting the tunnel away."
    "Pasas un rato jugando con [pet_name] antes de guardar el túnel."

# game/chapters/3_roomexplore.rpy:375
translate Spanish bingus_hub3_0faf5bc8:

    # "[pet_name] is hanging out on your bed, enjoying the last bit of sunlight coming through the window."
    "[pet_name] está descansando en tu cama, disfrutando los últimos rayos de sol que entran por la ventana."

# game/chapters/3_roomexplore.rpy:376
translate Spanish bingus_hub3_5ecc8062:

    # "You smile and give [pet_her2] a pat, skin like velvet under your touch."
    "Sonríes y le das una caricia a [pet_name], cuya piel es como terciopelo al tacto."

# game/chapters/3_roomexplore.rpy:377
translate Spanish bingus_hub3_1ed818a7:

    # "There's something people don't know about [pet_name]."
    "Hay algo que la gente no sabe sobre [pet_name]."

# game/chapters/3_roomexplore.rpy:378
translate Spanish bingus_hub3_34e9a83b:

    # "[pet_She] is the biggest baby in the entire world, in the absolute best way. You will never get over having such a precious pet in your life."
    "[pet_She!t] es [arti_pet] consentid[letra_pet] más grande del mundo entero, en el mejor sentido. Nunca superarás tener una mascota tan preciosa en tu vida."

# game/chapters/3_roomexplore.rpy:379
translate Spanish bingus_hub3_7837d7f6:

    # "You pull out your phone and take a picture of [pet_her2] relaxing in the sun."
    "Sacas tu teléfono y tomas una foto de [pet_she!t] relajándose al sol."

# game/chapters/3_roomexplore.rpy:380
translate Spanish bingus_hub3_e213d72c:

    # "It looks no different to the 1000 other ones you've taken of [pet_her2] in that exact spot."
    "No se diferencia de las otras mil fotos que le has tomado a [pet_she!t] en ese mismo lugar."

# game/chapters/3_roomexplore.rpy:381
translate Spanish bingus_hub3_1f6f46a3:

    # "That does not matter to you in the slightest."
    "Eso no te importa en lo más mínimo."

# game/chapters/3_roomexplore.rpy:386
translate Spanish bingus_hub3_d1977453:

    # "You pull out a laser pointer - [pet_name]'s sworn enemy."
    "Sacas un puntero láser: el enemigo jurado de [pet_name]."

# game/chapters/3_roomexplore.rpy:387
translate Spanish bingus_hub3_566bba32:

    # "Instantly upon turning it on, [pet_she] jumps to [pet_her] feet and begins to get low, then charges towards the light!"
    "En cuanto lo enciendes, [pet_she!t] se pone de pie, se agacha y ¡se lanza hacia la luz!"

# game/chapters/3_roomexplore.rpy:388
translate Spanish bingus_hub3_6550acc9:

    # "A battle of wits, strength and endurance follows. It is a battle well fought by both sides, but you come out on top."
    "Se desata una batalla de ingenio, fuerza y resistencia. Ambos luchan con todas sus fuerzas, pero al final tú sales ganando."

# game/chapters/3_roomexplore.rpy:389
translate Spanish bingus_hub3_486cf1a0:

    # "Tired, [pet_name] curls up on your bed again."
    "Cansad[letra_pet], [pet_name] se acurruca de nuevo en tu cama."

# game/chapters/3_roomexplore.rpy:401
translate Spanish bunny_hub3_a9ff8989:

    # "You check on [pet_name] who is currently laying on your bed."
    "Echas un vistazo a [pet_name], que en este momento está en tu cama."

# game/chapters/3_roomexplore.rpy:402
translate Spanish bunny_hub3_d182ccba:

    # "[pet_name] is both an inside rabbit and a freeroaming rabbit. You spent a very long time bunny-proofing your apartment to make sure it was safe."
    "[pet_name] es [arti_2_pet] conej[letra_pet] de interior que puede andar libremente por casa. Pasaste muchísimo tiempo adaptando tu apartamento para que fuera seguro para [pet_name]."

# game/chapters/3_roomexplore.rpy:403
translate Spanish bunny_hub3_e8e5d64f:

    # "And you wouldn't have it any other way - spending time with [pet_name] is the best time spent."
    "Y no lo cambiarías por nada del mundo: pasar tiempo con [pet_name] es la mejor forma de aprovechar el tiempo."

# game/chapters/3_roomexplore.rpy:408
translate Spanish bunny_hub3_97fc23a6:

    # "You pull out a small willow ball and push it towards [pet_name]."
    "Sacas una pequeña pelota de sauce y se la empujas a [pet_name]."

# game/chapters/3_roomexplore.rpy:409
translate Spanish bunny_hub3_934ce97c:

    # "This is [pet_her] favorite game - reverse fetch."
    "Este es su juego favorito: ir a buscar la pelota... pero al revés."

# game/chapters/3_roomexplore.rpy:410
translate Spanish bunny_hub3_98b29eea:

    # "[pet_She] picks up the ball with [pet_her] teeth and tosses it across the bed. With a smile, you reach over and retrieve it."
    "[pet_She!t] recoge la pelota con los dientes y la lanza al otro lado de la cama. Sonriendo, te estiras para recogerla."

# game/chapters/3_roomexplore.rpy:411
translate Spanish bunny_hub3_30de4e71:

    # "In this situation, who is the pet, and who is the owner?"
    "En esta situación, ¿quién es la mascota y quién es [arti] dueñ[letra]?"

# game/chapters/3_roomexplore.rpy:423
translate Spanish cat_hub3_0faf5bc8:

    # "[pet_name] is hanging out on your bed, enjoying the last bit of sunlight coming through the window."
    "[pet_name] está descansando en tu cama, disfrutando los últimos rayos de sol que entran por la ventana."

# game/chapters/3_roomexplore.rpy:424
translate Spanish cat_hub3_13b16071:

    # "Sitting in the sun is [pet_her] absolute favorite thing in the entire world - after you, of course."
    "Sentarse al sol es lo que más le gusta en el mundo entero, después de ti, por supuesto."

# game/chapters/3_roomexplore.rpy:425
translate Spanish cat_hub3_1efad518:

    # "[pet_She] purrs as you give [pet_her2] a bellyrub. Fortunately, [pet_name] LOVES belly rubs."
    "[pet_She!t] ronronea mientras le acaricias la barriga. Por suerte, a [pet_name] le ENCANTA que le acaricien la barriga."

# game/chapters/3_roomexplore.rpy:426
translate Spanish cat_hub3_ec935d54:

    # "Seeing how happy [pet_she] is makes you wish you were a cat napping in the sun all day."
    "Ver lo feliz que está [pet_she!t] te hace desear ser un gato echando la siesta al sol todo el día."

# game/chapters/3_roomexplore.rpy:431
translate Spanish cat_hub3_ebfd0bd0:

    # "You pull out [pet_name]'s favorite toy - a small mouse on a stick."
    "Sacas el juguete favorito de [pet_name]: un ratoncito en una varita."

# game/chapters/3_roomexplore.rpy:432
translate Spanish cat_hub3_cbed55a6:

    # "As soon as [pet_she] locks eyes on it, [pet_she] jumps to [pet_her] feet and gets down low, ready to pounce."
    "Tan pronto como [pet_she!t] fija la vista en él, salta sobre sus patas y se agacha, a punto de abalanzarse."

# game/chapters/3_roomexplore.rpy:433
translate Spanish cat_hub3_a05495eb:

    # "You spend a significant amount of time playing a game of cat and mouse with [pet_name]. Time well spent, in your books."
    "Pasas una buena cantidad de tiempo jugando al gato y al ratón con [pet_name]. Tiempo bien aprovechado, según tú."

# game/chapters/3_roomexplore.rpy:445
translate Spanish dog_hub3_4e85d183:

    # "[pet_name] is rolling around on your bed, enjoying the last traces of sunlight."
    "[pet_name] está revolcándose en tu cama, disfrutando los últimos rastros de sol."

# game/chapters/3_roomexplore.rpy:446
translate Spanish dog_hub3_52a2368f:

    # "[pet_She] looks a little tired after the walk you took together earlier."
    "[pet_She!t] parece un poco cansad[letra_pet] después del paseo que dieron más temprano."

# game/chapters/3_roomexplore.rpy:447
translate Spanish dog_hub3_89ede335:

    # "You happened to stumble upon a new dog park nearby, and spent the afternoon playing fetch."
    "Por casualidad encontraste un nuevo parque para perros cerca y pasaron la tarde jugando a la pelota."

# game/chapters/3_roomexplore.rpy:448
translate Spanish dog_hub3_58330f61:

    # "It was a great time for both of you."
    "Fue un gran momento para ustedes."

# game/chapters/3_roomexplore.rpy:453
translate Spanish dog_hub3_6fcb5dd9:

    # "You pull out one of [pet_name]'s favorites - three metal cups and a handful of dog treats."
    "Sacas uno de los juegos favoritos de [pet_name]: tres vasos de metal y un puñado de premios para perro."

# game/chapters/3_roomexplore.rpy:454
translate Spanish dog_hub3_d37ba9a2:

    # "[pet_She] instantly recognizes the game you're about to play and sits on the floor, waiting for it to begin."
    "[pet_She!t] reconoce al instante el juego que están a punto de jugar y se sienta en el suelo, esperando a que comience."

# game/chapters/3_roomexplore.rpy:455
translate Spanish dog_hub3_a38e3ca1:

    # "You place the treats under one cup then shuffle them around slowly. [pet_name]'s eyes follow the cup the entire time."
    "Colocas los premios debajo de un vaso y luego mueves los vasos lentamente de un lado a otro. Los ojos de [pet_name] siguen el vaso todo el tiempo."

# game/chapters/3_roomexplore.rpy:456
translate Spanish dog_hub3_ec55d422:

    # "[pet_She] is very good at this game, and correctly identifies the cup with the treats under it."
    "[pet_She!t] es muy [buen_pet] en este juego y señala correctamente el vaso que esconde los premios."

# game/chapters/3_roomexplore.rpy:457
translate Spanish dog_hub3_e94f11f6:

    # "[pet_She] munches them happily, and you prepare for another round."
    "[pet_She!t] se los come felizmente y tú te preparas para otra ronda."

# game/chapters/3_roomexplore.rpy:469
translate Spanish hamster_hub3_146456cc:

    # "[pet_name] is currently sitting on your bed."
    "[pet_name] está sentad[letra_pet] en tu cama."

# game/chapters/3_roomexplore.rpy:470
translate Spanish hamster_hub3_3648db40:

    # "[pet_She] spends a little (supervised) time each day out and about in your room with you. You find it's a nice time to bond."
    "[pet_She!t] pasa un rato cada día contigo en tu habitación, siempre bajo tu supervisión. Te parece una buena oportunidad para fortalecer el vínculo entre ustedes."

# game/chapters/3_roomexplore.rpy:471
translate Spanish hamster_hub3_60ba675a:

    # "However, you also keep a very nice enclosure for [pet_her2] in your apartment."
    "Sin embargo, también mantienes un muy buen recinto para [pet_she!t] en tu apartamento."

# game/chapters/3_roomexplore.rpy:472
translate Spanish hamster_hub3_0e0cc489:

    # "It's filled with bedding to burrow in, dried flowers and herbs to forage, wooden toys and tubes, a hamster wheel, and plenty of places to hide."
    "Está lleno de sustrato para excavar, flores y hierbas secas para buscar, juguetes y tubos de madera, una rueda de hámster y muchos lugares para esconderse."

# game/chapters/3_roomexplore.rpy:473
translate Spanish hamster_hub3_09b67ffd:

    # "Honestly, you're quite proud of [pet_her] enclosure, and you know [pet_she] enjoys it immensely."
    "La verdad, estás muy orgullos[letra] del recinto de [pet_name] y sabes que [pet_she!t] lo disfruta muchísimo."

# game/chapters/3_roomexplore.rpy:478
translate Spanish hamster_hub3_877e84e9:

    # "You quickly make a few tunnels and hills out of your comforter, and [pet_name] instantly burrows and begins to explore."
    "Rápidamente formas unos cuantos túneles y montículos con tu edredón, y [pet_name] enseguida se mete entre ellos y comienza a explorar."

# game/chapters/3_roomexplore.rpy:479
translate Spanish hamster_hub3_0794713e:

    # "This is probably one of [pet_name]'s favorite activities. [pet_She] loves exploring, and you're always happy to oblige."
    "Probablemente esta sea una de las actividades favoritas de [pet_name]. A [pet_she!t] le encanta explorar y tú siempre estás encantad[letra] de darle ese gusto."

# game/chapters/3_roomexplore.rpy:480
translate Spanish hamster_hub3_9a5c74f0:

    # "Soon enough [pet_she] will become tired from all of the exploration, and be ready to go back in [pet_her] enclosure."
    "Muy pronto [pet_she!t] se cansará de tanta exploración, y será momento de volver a su recinto."

# game/chapters/3_roomexplore.rpy:481
translate Spanish hamster_hub3_5dc2a222:

    # "Until then, you sit on the bed beside [pet_her2] and enjoy the time together."
    "Hasta entonces, te sientas en la cama junto a [pet_name] y disfrutas el tiempo con [pet_she!t]."

# game/chapters/3_roomexplore.rpy:502
translate Spanish plant_hub3_c1229c6a:

    # "You give your little sprout a big drink of water."
    "Le das a tu pequeño retoño un buen trago de agua."

# game/chapters/3_roomexplore.rpy:503
translate Spanish plant_hub3_c5de961c:

    # "Though you don't speak sprout, it seems to say thank you."
    "Aunque no hablas el idioma de los retoños, parece darte las gracias."

# game/chapters/3_roomexplore.rpy:505
translate Spanish plant_hub3_518e64fd:

    # "Your little sprout has grown some leaves!"
    "¡A tu pequeño retoño le han salido hojas!"

# game/chapters/3_roomexplore.rpy:506
translate Spanish plant_hub3_8036dce1:

    # "You can't help but feel proud as you give it a big drink of water."
    "No puedes evitar sentir orgullo mientras le das un gran trago de agua."

# game/chapters/3_roomexplore.rpy:508
translate Spanish plant_hub3_adaac543:

    # "Even more leaves have appeared now!"
    "¡Ahora han aparecido aún más hojas!"

# game/chapters/3_roomexplore.rpy:509
translate Spanish plant_hub3_a4970463:

    # "You water it generously and feel excited that, this time, you didn't kill your plant instantly."
    "La riegas abundantemente y te emociona comprobar que esta vez no has matado tu planta nada más empezar."

# game/chapters/3_roomexplore.rpy:524
translate Spanish plant_hub3_d8e47d30:

    # "Plants love water, right?"
    "A las plantas les encanta el agua, ¿no?"

# game/chapters/3_roomexplore.rpy:525
translate Spanish plant_hub3_766b643a:

    # "What could be better than even MORE water?"
    "¿Qué podría ser mejor que AÚN MÁS agua?"

# game/chapters/3_roomexplore.rpy:526
translate Spanish plant_hub3_6c6e2bd3:

    # "The idea makes perfect sense in your mind as the water pools up."
    "En tu cabeza, la idea tiene todo el sentido del mundo mientras el agua se acumula."

# game/chapters/3_roomexplore.rpy:536
translate Spanish plant_hub3_f47ce413:

    # "You start to wonder if you have a problem."
    "Empiezas a preguntarte si tienes un problema."

# game/chapters/3_roomexplore.rpy:539
translate Spanish plant_hub3_faab4b4d:

    # "Water overflows through your room, and you just decide to ignore it."
    "El agua se desborda por toda tu habitación y simplemente decides ignorarla."

# game/chapters/3_roomexplore.rpy:540
translate Spanish plant_hub3_f5c20cb6:

    # "It's like you are one with the water. You {i}are{/i} the water."
    "Es como si fueras un[letra] con el agua. Tú {i}eres{/i} el agua."

# game/chapters/3_roomexplore.rpy:541
translate Spanish plant_hub3_c1bce74d:

    # "It's only natural for it to be everywhere."
    "Es natural que esté en todas partes."

# game/chapters/3_roomexplore.rpy:542
translate Spanish plant_hub3_e6b93364:

    # "Eventually, you snap out of your strange trance to see water and soil all over the floor."
    "Finalmente sales de tu extraño trance y te das cuenta de que hay agua y tierra esparcidas por todo el suelo."

# game/chapters/3_roomexplore.rpy:543
translate Spanish plant_hub3_a29aee51:

    # "What a mess."
    "Qué desastre."

translate Spanish strings:

    # game/chapters/3_roomexplore.rpy:228
    old "1. Full of anime figures!"
    new "1. ¡Lleno de figuras de anime!"

    # game/chapters/3_roomexplore.rpy:231
    old "2. Very minimal."
    new "2. Muy minimalista."

    # game/chapters/3_roomexplore.rpy:234
    old "3. Rainbows! Everywhere!"
    new "3. ¡Arcoíris! ¡Por todas partes!"

    # game/chapters/3_roomexplore.rpy:237
    old "4. Shared with a sibling."
    new "4. Compartido con un hermano o hermana."

    # game/chapters/3_roomexplore.rpy:346
    old "Play with [pet_name]."
    new "Jugar con [pet_name]."

    # game/chapters/3_roomexplore.rpy:354
    old "1. Knitted it yourself."
    new "1. Lo tejiste tú."

    # game/chapters/3_roomexplore.rpy:358
    old "2. Bought it online."
    new "2. Lo compraste en línea."

    # game/chapters/3_roomexplore.rpy:566
    old "{i}Diary #1{/i}"
    new "{i}Diario #1{/i}"

    # game/chapters/3_roomexplore.rpy:583
    old "dear diaryz,"
    new "querido diariio,"

    # game/chapters/3_roomexplore.rpy:584
    old "did you know i turned 8 today?"
    new "¿sabías que hoy cumplí 8?"

    # game/chapters/3_roomexplore.rpy:585
    old "i guess you probably didn't coz i don't think diaries count as real people so you probably can't know things i don't tell you."
    new "supongo que no lo sabías porke no creo que los diarios cuenten como personas reales, así que seguro no puedes saber cosas que no te digo."

    # game/chapters/3_roomexplore.rpy:586
    old "but now you know so thats good ~~prolly~~."
    new "pero ahora lo sabes, así que está bien ~~probli~~."

    # game/chapters/3_roomexplore.rpy:587
    old "guess what, it snowed!"
    new "¡adivina qué, nevó!"

    # game/chapters/3_roomexplore.rpy:588
    old "and guess what again? that means i don't have skool!"
    new "¿y adivina qué otra vez? ¡eso significa que no tengo eskuela!"

    # game/chapters/3_roomexplore.rpy:589
    old "did you hear that? WE DON'T HAVE SKOOL!!!! YAAY!"
    new "¿escuchaste eso? ¡NO TENEMOS ESKUELA!! ¡YUUUJU!"

    # game/chapters/3_roomexplore.rpy:590
    old "i have to wait for my presents apparently. i want to open them NAO."
    new "aparentemente tengo que esperar mis regalos. quiero abrirlos AORA."

    # game/chapters/3_roomexplore.rpy:591
    old "when am i ever going to get my presents???"
    new "¿cuándo voy a recibir mis regalos???"

    # game/chapters/3_roomexplore.rpy:592
    old "ok i'm going to make a snowman now."
    new "ok, voy a hacer un muñeco de nieve ahora."

    # game/chapters/3_roomexplore.rpy:593
    old "i wonder how a snowman gets a skeleton. they have skeletons, right? that'd be soo cool."
    new "me pregunto cómo consigue un muñeco de nieve un esqueleto. tienen esqueleto, ¿verdad? sería taaaan genial."

    # game/chapters/3_roomexplore.rpy:594
    old "okay BYEEEE"
    new "okey ADIÓÓÓS"

    old "Profile"
    new "Perfil"

    old "blue"
    new "azul"

    old "pink"
    new "rosa"

    old "green"
    new "verde"

    old "yellow"
    new "amarillo"