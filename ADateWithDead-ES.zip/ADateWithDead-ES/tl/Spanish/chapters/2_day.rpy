# TODO: Translation updated at 2026-10-15 18:36

# game/chapters/2_day.rpy:2
translate Spanish day2_start_d41d8cd9:

    # nvl clear
    nvl clear

# game/chapters/2_day.rpy:15
translate Spanish day2_start_469d8b1f:

    # center_text "After a restless night's sleep, you wake up and head off to work."
    center_text "Tras una noche de sueño inquieto, te despiertas y te diriges al trabajo."

# game/chapters/2_day.rpy:16
translate Spanish day2_start_c233466b:

    # center_text "The day passes uneventfully, but you can't get your mind off the strange things that happened last night."
    center_text "El día transcurre sin incidentes, pero no puedes quitarte de la cabeza las cosas extrañas que ocurrieron anoche."

# game/chapters/2_day.rpy:17
translate Spanish day2_start_7d61dc6a:

    # center_text "That man certainly wasn't the Grim Reaper, but you can't deny that something felt special about him, either."
    center_text "Ciertamente ese hombre no era la Parca, pero tampoco puedes negar que había algo especial en él."

# game/chapters/2_day.rpy:18
translate Spanish day2_start_bd5d4884:

    # center_text "You're thinking about him as you begin to walk back to your apartment."
    center_text "Piensas en él mientras comienzas a caminar de regreso a tu apartamento."

# game/chapters/2_day.rpy:19
translate Spanish day2_start_7e357c6f:

    # center_text "It's dark out - you finished work later than usual today."
    center_text "Ya está oscuro: hoy terminaste de trabajar más tarde de lo habitual."

# game/chapters/2_day.rpy:20
translate Spanish day2_start_86b38fc1:

    # center_text "You believe that's why you didn't see the banana peel someone had left on the sidewalk."
    center_text "Crees que por eso no viste la cáscara de plátano que alguien dejó en la acera."

# game/chapters/2_day.rpy:21
translate Spanish day2_start_81fcccac:

    # center_text "You slip over just in time to see a heavy metal beam fall from a construction site directly overhead."
    center_text "Resbalas justo a tiempo para ver cómo una viga de metal pesada cae desde una obra en construcción directamente sobre ti."

# game/chapters/2_day.rpy:23
translate Spanish day2_start_02747766:

    # center_text "It falls towards you at a rapid pace."
    center_text "Cae hacia ti a gran velocidad."

# game/chapters/2_day.rpy:27
translate Spanish day2_start_2bab7ffb:

    # center_text "You roll to the side just in time."
    center_text "Ruedas hacia un lado justo a tiempo."

# game/chapters/2_day.rpy:29
translate Spanish day2_start_6f883f9d:

    # center_text "The metal beam clangs to the ground beside you."
    center_text "La viga de metal se estrella contra el suelo junto a ti."

# game/chapters/2_day.rpy:31
translate Spanish day2_start_e4e9df21:

    # center_text "It falls towards you faster and faster, before a powerful gust of wind pushes it to the side."
    center_text "Cae hacia ti cada vez más rápido, antes de que una poderosa ráfaga de viento la empuje hacia un lado."

# game/chapters/2_day.rpy:33
translate Spanish day2_start_a25aa845:

    # center_text "It clatters to the ground beside you."
    center_text "Se desploma contra el suelo junto a ti."

# game/chapters/2_day.rpy:35
translate Spanish day2_start_21488e78:

    # center_text "You blink a few times in surprise, then stand."
    center_text "Parpadeas varias veces por la sorpresa y luego te pones de pie."

# game/chapters/2_day.rpy:36
translate Spanish day2_start_ce3136a2:

    # center_text "Just another normal day, huh?"
    center_text "¿Otro día normal, eh?"

# game/chapters/2_day.rpy:37
translate Spanish day2_start_24a0c70d:

    # center_text "You walk for a little while longer, and finally arrive back at your apartment."
    center_text "Caminas un poco más y por fin llegas a tu apartamento."

# game/chapters/2_day.rpy:84
translate Spanish day2_start2_7c35c462:

    # player "You so hard at work you have no time to talk to me, Grim?"
    player "¿Tan ocupado estás que no puedes hablarme, Parca?"

# game/chapters/2_day.rpy:87
translate Spanish day2_start2_20e85a2c:

    # player "Poor Grim, slaving his life away."
    player "Pobre Parca, esclavizado toda su vida."

# game/chapters/2_day.rpy:90
translate Spanish day2_start2_da94f218:

    # player "What are you doing, anyway?"
    player "¿Qué estás haciendo, de todos modos?"

# game/chapters/2_day.rpy:93
translate Spanish day2_start2_5cb31561:

    # player "Hello, [playername] to Grim. [playername] to Grim."
    player "Hola, [playername] a Parca. [playername] a Parca."

# game/chapters/2_day.rpy:96
translate Spanish day2_start2_6820234b:

    # player "Come in Grim."
    player "Adelante, Parca."

# game/chapters/2_day.rpy:99
translate Spanish day2_start2_1f85faf1:

    # player "[playername] to Grim."
    player "[playername] a Parca."

# game/chapters/2_day.rpy:102
translate Spanish day2_start2_f760dc03:

    # player "Where are you, my little Grim?"
    player "¿Dónde estás, mi Parquita?"

# game/chapters/2_day.rpy:106
translate Spanish day2_start2_712c330b:

    # player "Found something more entertaining than talking to me?"
    player "¿Encontraste algo más entretenido que hablar conmigo?"

# game/chapters/2_day.rpy:109
translate Spanish day2_start2_80a8241f:

    # player "Probably impossible, tbh."
    player "Probablemente imposible, la verdad."

# game/chapters/2_day.rpy:112
translate Spanish day2_start2_c34837ee:

    # player "Hey, I had a crazy thought."
    player "Oye, tuve un pensamiento loco."

# game/chapters/2_day.rpy:115
translate Spanish day2_start2_018e1eeb:

    # player "Imagine if we just ran away and got married."
    player "Imagina que simplemente nos fugamos y nos casamos."

# game/chapters/2_day.rpy:118
translate Spanish day2_start2_5e2a3387:

    # player "We could have the reception here and the ceremony in super hell."
    player "Podríamos tener la recepción aquí y la ceremonia en el súper infierno."

# game/chapters/2_day.rpy:121
translate Spanish day2_start2_03775ec8:

    # player "..."
    player "..."

# game/chapters/2_day.rpy:124
translate Spanish day2_start2_b4d67f4f:

    # player "Even that isn't enough to get your attention?"
    player "¿Ni siquiera eso basta para llamar tu atención?"

# game/chapters/2_day.rpy:128
translate Spanish day2_start2_03775ec8_1:

    # player "..."
    player "..."

# game/chapters/2_day.rpy:131
translate Spanish day2_start2_3d6e2447:

    # player "I still have my soul, btw."
    player "Por cierto, todavía tengo mi alma."

# game/chapters/2_day.rpy:134
translate Spanish day2_start2_9c7dbaf5:

    # player "So much for 'I need only a day, an hour!'"
    player "Adiós a eso de '¡Solo necesito un día, una hora!'."

# game/chapters/2_day.rpy:135
translate Spanish day2_start2_d51f1d60:

    # GR "you do love to see yourself talk, don't you mortal... {font=gui/NotoSans-Light.ttf}(¬ _¬){/font}"
    GR "te encanta escucharte hablar, ¿no, mortal...? {font=gui/NotoSans-Light.ttf}(¬ _¬){/font}"

# game/chapters/2_day.rpy:138
translate Spanish day2_start2_33c2530b:

    # player "I saw you talking to yourself yesterday before I responded, you know."
    player "Te vi hablando solo ayer antes de que yo respondiera, ¿sabes?"

# game/chapters/2_day.rpy:139
translate Spanish day2_start2_99fea57b:

    # GR "i was simply testing if it worked."
    GR "yo solo estaba probando si funcionaba."

# game/chapters/2_day.rpy:140
translate Spanish day2_start2_d0ccd0e1:

    # GR "i was not talking to myself."
    GR "no estaba hablando solo."

# game/chapters/2_day.rpy:141
translate Spanish day2_start2_6ba33848:

    # GR "you are the one sitting here waiting for me."
    GR "tú eres quien está aquí esperándome."

# game/chapters/2_day.rpy:144
translate Spanish day2_start2_f407e033:

    # GR "also, what are you talking about??? marriage?????"
    GR "además, ¿¿¿de qué estás hablando??? ¿¿¿¿matrimonio?????"

# game/chapters/2_day.rpy:145
translate Spanish day2_start2_de296689:

    # GR "i am trying to have you KILLED.... and you're talking about getting MARRIED."
    GR "estoy intentando que te MATEN... y tú hablando de CASARTE."

# game/chapters/2_day.rpy:146
translate Spanish day2_start2_be9e4eb7:

    # GR "is your brain ok?"
    GR "¿tu cerebro está bien?"

# game/chapters/2_day.rpy:147
translate Spanish day2_start2_a6a75724:

    # GR "if not, it would explain many things."
    GR "si no, eso explicaría muchas cosas."

# game/chapters/2_day.rpy:150
translate Spanish day2_start2_c718994a:

    # player "I only said it to get your attention."
    player "Solo lo dije para llamar tu atención."

# game/chapters/2_day.rpy:151
translate Spanish day2_start2_2edbc68d:

    # GR "ok. that makes more sense, i suppose."
    GR "ok. eso tiene más sentido, supongo."

# game/chapters/2_day.rpy:153
translate Spanish day2_start2_41bcc3e8:

    # player "tbh I'd marry you."
    player "Sinceramente, me casaría contigo."

# game/chapters/2_day.rpy:154
translate Spanish day2_start2_09a0dec3:

    # GR "why??????"
    GR "¿¿¿¿¿¿por qué??????"

# game/chapters/2_day.rpy:157
translate Spanish day2_start2_29a9c3b8:

    # player "You are very handsome."
    player "Eres muy guapo."

# game/chapters/2_day.rpy:159
translate Spanish day2_start2_e71203c7:

    # player "You're funny."
    player "Eres gracioso."

# game/chapters/2_day.rpy:161
translate Spanish day2_start2_b1d81e84:

    # player "I want to tease you forever."
    player "Quiero molestarte para siempre."

# game/chapters/2_day.rpy:163
translate Spanish day2_start2_5305b487:

    # player "The heart wants what the heart wants."
    player "El corazón sabe lo que quiere."

# game/chapters/2_day.rpy:164
translate Spanish day2_start2_16bac02a:

    # GR "o... kay..."
    GR "b... ueno..."

# game/chapters/2_day.rpy:165
translate Spanish day2_start2_692cd768:

    # GR "as... nice as that sounds..."
    GR "por muy... agradable que suene..."

# game/chapters/2_day.rpy:166
translate Spanish day2_start2_0adf7b5d:

    # GR "i think i'll just stick to taking your soul and doing my job."
    GR "creo que me limitaré a tomar tu alma y hacer mi trabajo."

# game/chapters/2_day.rpy:167
translate Spanish day2_start2_84e884db:

    # GR "don't you have someone more... uh... human to marry?"
    GR "¿no tienes a alguien más... eh... humano para casarte?"

# game/chapters/2_day.rpy:171
translate Spanish day2_start2_984c7ec6:

    # player "Nope. I'm all alone."
    player "Nop. No tengo a nadie."

# game/chapters/2_day.rpy:173
translate Spanish day2_start2_4815eabf:

    # GR "lonely, are we?"
    GR "¿te sientes sol[letra], eh?"

# game/chapters/2_day.rpy:176
translate Spanish day2_start2_87e5f60a:

    # player "...Nope. Not at all"
    player "...Nop. Para nada."

# game/chapters/2_day.rpy:177
translate Spanish day2_start2_14e6d334:

    # GR "seems like you are lying to yourself, mortal."
    GR "parece que te estás engañando a ti mism[letra], mortal."

# game/chapters/2_day.rpy:178
translate Spanish day2_start2_d85a80f3:

    # GR "after all, how could you not be lonely while waiting for me to grace you with my presence." id day2_start2_d85a80f3
    GR "después de todo, ¿cómo no ibas a sentirte sol[letra] mientras esperas que yo te honre con mi presencia?" id day2_start2_d85a80f3

# game/chapters/2_day.rpy:181
translate Spanish day2_start2_e8d851c1:

    # player "I was {i}not{/i} lonely waiting for you!"
    player "¡{i}No{/i} me sentí sol[letra] mientras te esperaba!"

# game/chapters/2_day.rpy:182
translate Spanish day2_start2_fe28ce45:

    # GR "oh, but you were waiting for me, weren't you."
    GR "oh, pero sí me estabas esperando, ¿verdad?"

# game/chapters/2_day.rpy:183
translate Spanish day2_start2_4917858d:

    # GR "how could you not miss this handsome face."
    GR "¿cómo no ibas a extrañar este rostro tan atractivo?"

# game/chapters/2_day.rpy:184
translate Spanish day2_start2_a8a0dba2:

    # GR "it's impossible, after all. {font=gui/NotoSans-Light.ttf}({/font}{font=gui/LinLibertine_R.ttf}` ͜ʖ´{/font}{font=gui/NotoSans-Light.ttf}){/font}" id day2_start2_a8a0dba2
    GR "es imposible, después de todo. {font=gui/NotoSans-Light.ttf}({/font}{font=gui/LinLibertine_R.ttf}` ͜ʖ´{/font}{font=gui/NotoSans-Light.ttf}){/font}" id day2_start2_a8a0dba2

# game/chapters/2_day.rpy:185
translate Spanish day2_start2_c32dfa95:

    # GR "honestly, i should probably come with a warning. i'm too addictive."
    GR "la verdad, debería venir con una advertencia. soy demasiado adictivo."

# game/chapters/2_day.rpy:186
translate Spanish day2_start2_5907493a:

    # GR "don't you think?"
    GR "¿no lo crees?"

# game/chapters/2_day.rpy:187
translate Spanish day2_start2_80ff4898:

    # GR "hello?"
    GR "¿hola?"

# game/chapters/2_day.rpy:190
translate Spanish day2_start2_3538c673:

    # player "Now who's talking to himself?"
    player "Ahora, ¿quién habla solo?"

# game/chapters/2_day.rpy:191
translate Spanish day2_start2_5236f8dc:

    # GR "you messaged me first {font=gui/NotoSans-Light.ttf}(•̀ᴗ-){/font}{font=gui/JuliaMono-Black.ttf}✧{/font}"
    GR "tú me escribiste primero {font=gui/NotoSans-Light.ttf}(•̀ᴗ-){/font}{font=gui/JuliaMono-Black.ttf}✧{/font}"

# game/chapters/2_day.rpy:193
translate Spanish day2_start2_5f73ffe3:

    # player "Yeah okay I was a little lonely..."
    player "Sí, okey, me sentía un poquito sol[letra]..."

# game/chapters/2_day.rpy:194
translate Spanish day2_start2_3f7ad2f6:

    # GR "oh."
    GR "oh."

# game/chapters/2_day.rpy:195
translate Spanish day2_start2_7a7fc677:

    # GR "that is a little sad..."
    GR "eso es un poco triste..."

# game/chapters/2_day.rpy:196
translate Spanish day2_start2_15296e32:

    # GR "did you miss my handsome face? {font=gui/NotoSans-Light.ttf}({/font}{font=gui/LinLibertine_R.ttf}` ͜ʖ´{/font}{font=gui/NotoSans-Light.ttf}){/font}"
    GR "¿extrañaste mi atractivo rostro? {font=gui/NotoSans-Light.ttf}({/font}{font=gui/LinLibertine_R.ttf}` ͜ʖ´{/font}{font=gui/NotoSans-Light.ttf}){/font}"

# game/chapters/2_day.rpy:197
translate Spanish day2_start2_15bd3eaa:

    # GR "you did, didn't you?"
    GR "lo hiciste, ¿verdad?"

# game/chapters/2_day.rpy:198
translate Spanish day2_start2_3f86c3c2:

    # GR "you can tell me."
    GR "puedes decírmelo."

# game/chapters/2_day.rpy:201
translate Spanish day2_start2_3538c673_1:

    # player "Now who's talking to himself?"
    player "Ahora, ¿quién habla solo?"

# game/chapters/2_day.rpy:202
translate Spanish day2_start2_5236f8dc_1:

    # GR "you messaged me first {font=gui/NotoSans-Light.ttf}(•̀ᴗ-){/font}{font=gui/JuliaMono-Black.ttf}✧{/font}"
    GR "tú me escribiste primero {font=gui/NotoSans-Light.ttf}(•̀ᴗ-){/font}{font=gui/JuliaMono-Black.ttf}✧{/font}"

# game/chapters/2_day.rpy:205
translate Spanish day2_start2_1d29fca6:

    # player "Well kinda, actually."
    player "Bueno, sí, un poco, la verdad."

# game/chapters/2_day.rpy:206
translate Spanish day2_start2_cde636ce:

    # GR "oh. i wasn't expecting you to admit it, uh..."
    GR "oh. no esperaba que lo admitieras, eh..."

# game/chapters/2_day.rpy:207
translate Spanish day2_start2_03767585:

    # GR "i see."
    GR "ya veo."

# game/chapters/2_day.rpy:208
translate Spanish day2_start2_d8a7ceef:

    # GR "well worry not, mortal."
    GR "no te preocupes, mortal."

# game/chapters/2_day.rpy:209
translate Spanish day2_start2_337fb8af:

    # GR "[women] often tell me i am delightful company."
    GR "[las] [women!t] suelen decirme que soy una excelente compañía."

# game/chapters/2_day.rpy:212
translate Spanish day2_start2_fc8e70a2:

    # player "Of {i}course{/i} they do. I definitely believe that."
    player "Por {i}supuesto{/i} que sí. Sin duda lo creo."

# game/chapters/2_day.rpy:213
translate Spanish day2_start2_bbca5929:

    # GR "now that you have seen my good looks, you will find it impossible to stay away."
    GR "ahora que has visto mi buen aspecto, te resultará imposible mantenerte lejos."

# game/chapters/2_day.rpy:214
translate Spanish day2_start2_51ba7ae4:

    # GR "maybe if you're lucky, i'll let you look again {font=gui/NotoSans-Light.ttf}( ´{/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}◑{/font}{font=gui/NotoSans-Light.ttf}ω{/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}◐{/font}{font=gui/NotoSans-Light.ttf}`){/font}"
    GR "quizá, si tienes suerte, te deje mirarme otra vez {font=gui/NotoSans-Light.ttf}( ´{/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}◑{/font}{font=gui/NotoSans-Light.ttf}ω{/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}◐{/font}{font=gui/NotoSans-Light.ttf}`){/font}"

# game/chapters/2_day.rpy:217
translate Spanish day2_start2_03775ec8_2:

    # player "..."
    player "..."

# game/chapters/2_day.rpy:220
translate Spanish day2_start2_5c9eaa96:

    # player "tbh I can't lie, you are good looking..."
    player "Sinceramente, no puedo mentir, eres guapo..."

# game/chapters/2_day.rpy:222
translate Spanish day2_start2_64a3385c:

    # player "No comment. None at all."
    player "Sin comentarios. Ninguno en absoluto."

# game/chapters/2_day.rpy:225
translate Spanish day2_start2_414a718d:

    # GR "i knew you'd be sucked in by my charm."
    GR "sabía que te dejarías seducir por mi encanto."

# game/chapters/2_day.rpy:226
translate Spanish day2_start2_290e7317:

    # GR "how long were you sitting there waiting for me, mortal?"
    GR "¿cuánto tiempo llevas ahí esperándome, mortal?"

# game/chapters/2_day.rpy:227
translate Spanish day2_start2_f3375d14:

    # GR "were you hoping i'd show you my face once again?"
    GR "¿esperabas que te mostrara mi rostro una vez más?"

# game/chapters/2_day.rpy:229
translate Spanish day2_start2_e8c8a515:

    # player "Me, lonely?"
    player "¿Yo, sol[letra]?"

# game/chapters/2_day.rpy:232
translate Spanish day2_start2_922450d0:

    # player "You seem more like the lonely one."
    player "Tú pareces más bien el solitario."

# game/chapters/2_day.rpy:233
translate Spanish day2_start2_5a27f458:

    # GR "loneliness is {i}not{/i} something a reaper feels."
    GR "la soledad {i}no{/i} es algo que una parca sienta."

# game/chapters/2_day.rpy:234
translate Spanish day2_start2_30b2dfe4:

    # GR "a pointless emotion for one such as myself to hold onto {font=gui/NotoSans-Light.ttf}({/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}屮｀ ∀´{/font}{font=gui/NotoSans-Light.ttf}){/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}屮{/font}"
    GR "es una emoción inútil para alguien como yo {font=gui/NotoSans-Light.ttf}({/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}屮｀ ∀´{/font}{font=gui/NotoSans-Light.ttf}){/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}屮{/font}"

# game/chapters/2_day.rpy:237
translate Spanish day2_start2_bddf28c8:

    # player "Sounds like something a really lonely person would say."
    player "Suena a algo que diría una persona realmente sola."

# game/chapters/2_day.rpy:238
translate Spanish day2_start2_ab2115ff:

    # GR "foolish mortal. what you say is simply... foolish beyond words."
    GR "mortal neci[letra]. lo que dices es simplemente... insensato más allá de las palabras."

# game/chapters/2_day.rpy:239
translate Spanish day2_start2_91b3cb88:

    # GR "foolish words for foolish fools."
    GR "palabras necias para necios."

# game/chapters/2_day.rpy:240
translate Spanish day2_start2_b79bafc3:

    # GR "you are the one sitting there waiting for me."
    GR "tú eres quien está ahí esperándome."

# game/chapters/2_day.rpy:241
translate Spanish day2_start2_b94b3eaa:

    # GR "i'd say this makes you the lonely one, longing for my presence."
    GR "diría que eso te convierte en [arti] solitari[letra], anhelando mi presencia."

# game/chapters/2_day.rpy:242
translate Spanish day2_start2_28864468:

    # GR "hoping to lay eyes on me once again."
    GR "esperando volver a posar tus ojos en mí."

# game/chapters/2_day.rpy:243
translate Spanish day2_start2_2982e929:

    # GR "i am simply irresistible."
    GR "simplemente soy irresistible."

# game/chapters/2_day.rpy:246
translate Spanish day2_start2_3eb99252:

    # player "Am I not allowed to feel lonely while waiting for you?"
    player "¿Acaso no puedo sentirme sol[letra] mientras te espero?"

# game/chapters/2_day.rpy:247
translate Spanish day2_start2_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/2_day.rpy:248
translate Spanish day2_start2_afbcc1fa:

    # GR "i knew i was irresistible, but i didn't expect you to need for me so quickly, mortal..."
    GR "sabía que era irresistible, pero no esperaba que me necesitaras tan rápido, mortal..."

# game/chapters/2_day.rpy:251
translate Spanish day2_start2_9ffa2cdc:

    # player "I didn't say I needed you..."
    player "Yo no dije que te necesitara..."

# game/chapters/2_day.rpy:252
translate Spanish day2_start2_aa0ebc53:

    # GR "not yet."
    GR "todavía no."

# game/chapters/2_day.rpy:253
translate Spanish day2_start2_27ee4244:

    # GR "such a poor thing. imagine being caught in a web made by the one who is fated to take your soul."
    GR "pobre criatura. imagínate caer en la telaraña tejida por aquel que está destinado a llevarse tu alma."

# game/chapters/2_day.rpy:256
translate Spanish day2_start2_7246bd8e:

    # player "I'm not caught in your web, Grim."
    player "No estoy en tu telaraña, Parca."

# game/chapters/2_day.rpy:259
translate Spanish day2_start2_7ed9f674:

    # player "Plus, as far as I know, 'Grim Reapers' can't make webs."
    player "Además, que yo sepa, las 'Parcas' no pueden tejer telarañas."

# game/chapters/2_day.rpy:262
translate Spanish day2_start2_389a9c4e:

    # player "Next you're gonna be telling me you're part spider or something."
    player "Lo siguiente será que me digas que eres parte araña o algo así."

# game/chapters/2_day.rpy:265
translate Spanish day2_start2_dc9bcf0b:

    # player "Spider-Grim."
    player "Parca-Araña."

# game/chapters/2_day.rpy:266
translate Spanish day2_start2_b8948bef:

    # GR "don't be stupid."
    GR "no seas idiota."

# game/chapters/2_day.rpy:267
translate Spanish day2_start2_c475e965:

    # GR "it was simply a term of speech."
    GR "era simplemente un término retórico."

# game/chapters/2_day.rpy:270
translate Spanish day2_start2_b047a28a:

    # player "A... what?"
    player "¿Un... qué?"

# game/chapters/2_day.rpy:271
translate Spanish day2_start2_9fb5c209:

    # GR "a term of speech."
    GR "un término retórico."

# game/chapters/2_day.rpy:274
translate Spanish day2_start2_b691ec4b:

    # player "Do you mean... a figure of speech?"
    player "¿Te refieres a... una figura retórica?"

# game/chapters/2_day.rpy:275
translate Spanish day2_start2_7772a27d_1:

    # GR "..."
    GR "..."

# game/chapters/2_day.rpy:276
translate Spanish day2_start2_0b16bee0:

    # GR "ahem."
    GR "ejem."

# game/chapters/2_day.rpy:277
translate Spanish day2_start2_73124604:

    # GR "let's get back to the whole 'you miss me' talk, shall we?"
    GR "volvamos al tema de 'me extrañas', ¿te parece?"

# game/chapters/2_day.rpy:278
translate Spanish day2_start2_b650e23e:

    # GR "how long have you been waiting for me, mortal?"
    GR "¿cuánto tiempo llevas esperándome, mortal?"

# game/chapters/2_day.rpy:282
translate Spanish day2_start2_41444d4a:

    # player "I was just bored."
    player "Simplemente me aburría."

# game/chapters/2_day.rpy:284
translate Spanish day2_start2_15e7dd92:

    # player "Okay, I was kinda waiting for you."
    player "Okey, de cierto modo te estaba esperando."

# game/chapters/2_day.rpy:286
translate Spanish day2_start2_5c4757c5:

    # player "I was waiting for you for ages!"
    player "¡Te estuve esperando siglos!"

# game/chapters/2_day.rpy:289
translate Spanish day2_start2_9ead1a20:

    # player "What took you so long?"
    player "¿Qué te tomó tanto tiempo?"

# game/chapters/2_day.rpy:290
translate Spanish day2_start2_d0423de5:

    # GR "are you really that needy?"
    GR "¿de verdad eres tan necesitad[letra]?"

# game/chapters/2_day.rpy:291
translate Spanish day2_start2_16f2c6a5:

    # GR "i'm sure you are capable of entertaining yourself."
    GR "estoy seguro de que eres capaz de divertirte sin ayuda."

# game/chapters/2_day.rpy:294
translate Spanish day2_start2_02c22043:

    # player "Oh, I am."
    player "Oh, claro que sí."

# game/chapters/2_day.rpy:297
translate Spanish day2_start2_f8b28457:

    # player "But messing with you is the most fun."
    player "Pero molestarte es mucho más divertido."

# game/chapters/2_day.rpy:302
translate Spanish day2_start2_dec8dc4b:

    # player "I half expected someone to jump out at me all day."
    player "Pasé todo el día medio esperando que alguien saltara frente a mí."

# game/chapters/2_day.rpy:305
translate Spanish day2_start2_b023d5f8:

    # player "To, you know, 'steal my soul' or whatever."
    player "Para, ya sabes, 'robarme el alma' o lo que sea."

# game/chapters/2_day.rpy:308
translate Spanish day2_start2_affd6edb:

    # player "No sign of any reapers."
    player "Ni rastro de parcas."

# game/chapters/2_day.rpy:310
translate Spanish day2_start2_fc230e25:

    # GR "scared, are you?"
    GR "¿asustad[letra], eh?"

# game/chapters/2_day.rpy:311
translate Spanish day2_start2_edd65c43:

    # GR "always looking over your shoulder?"
    GR "¿mirando siempre por encima del hombro?"

# game/chapters/2_day.rpy:312
translate Spanish day2_start2_3ccfa35c:

    # GR "looking for me."
    GR "buscándome."

# game/chapters/2_day.rpy:313
translate Spanish day2_start2_7e2838ba:

    # GR "waiting for me {font=gui/NotoSans-Light.ttf}({/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}￣{/font}{font=gui/NotoSans-Light.ttf}ω{/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}￣{/font}{font=gui/NotoSans-Light.ttf}){/font}"
    GR "esperándome {font=gui/NotoSans-Light.ttf}({/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}￣{/font}{font=gui/NotoSans-Light.ttf}ω{/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}￣{/font}{font=gui/NotoSans-Light.ttf}){/font}"

# game/chapters/2_day.rpy:317
translate Spanish day2_start2_e93ac819:

    # player "Waiting to see you make a fool of yourself :D"
    player "Esperando verte hacer el ridículo :D"

# game/chapters/2_day.rpy:318
translate Spanish day2_start2_fe89c51a:

    # GR "you will be the one proven to be a fool, mortal."
    GR "tú serás quien quede en ridículo, mortal."

# game/chapters/2_day.rpy:321
translate Spanish day2_start2_865f974d:

    # player "Come up with your own insult."
    player "Inventa tu propio insulto."

# game/chapters/2_day.rpy:324
translate Spanish day2_start2_af688af9:

    # player "Or is copying a 'mortal' the best you can do?"
    player "¿O copiar a [arti_2] 'mortal' es lo mejor que puedes hacer?"

# game/chapters/2_day.rpy:325
translate Spanish day2_start2_95151b2c:

    # GR "....."
    GR "....."

# game/chapters/2_day.rpy:326
translate Spanish day2_start2_dac77ff5:

    # GR "i am plenty good at coming up with insults."
    GR "soy bastante bueno inventando insultos."

# game/chapters/2_day.rpy:329
translate Spanish day2_start2_e13c2def:

    # player "Oh yeah?"
    player "¿Ah, sí?"

# game/chapters/2_day.rpy:332
translate Spanish day2_start2_ac0bc8d6:

    # player "Try me."
    player "A ver, inténtalo."

# game/chapters/2_day.rpy:333
translate Spanish day2_start2_ad6c7f8d:

    # GR "fine."
    GR "bien."

# game/chapters/2_day.rpy:334
translate Spanish day2_start2_bbe03d5e:

    # GR "mortal, you..."
    GR "mortal, tú…"

# game/chapters/2_day.rpy:335
translate Spanish day2_start2_4229a73c:

    # GR "hm."
    GR "hm."

# game/chapters/2_day.rpy:336
translate Spanish day2_start2_54ae976f:

    # GR "give me a moment..."
    GR "dame un momento…"

# game/chapters/2_day.rpy:337
translate Spanish day2_start2_042582bc:

    # GR "okay, i've got one."
    GR "okey, ya tengo uno."

# game/chapters/2_day.rpy:338
translate Spanish day2_start2_d79e87a9:

    # GR "mortal, i've seen gravestones with more charisma than you."
    GR "mortal, he visto lápidas con más carisma que tú."

# game/chapters/2_day.rpy:341
translate Spanish day2_start2_61667f19:

    # player "Eh..."
    player "Eh..."

# game/chapters/2_day.rpy:343
translate Spanish day2_start2_870369f0:

    # player "Oh..."
    player "Oh…"

# game/chapters/2_day.rpy:345
translate Spanish day2_start2_f5206a43:

    # player "Hm..."
    player "Hm..."

# game/chapters/2_day.rpy:347
translate Spanish day2_start2_7e6168b3:

    # player "Uh..."
    player "Uh..."

# game/chapters/2_day.rpy:350
translate Spanish day2_start2_71d0874a:

    # player "Is that it...?"
    player "¿Eso es todo...?"

# game/chapters/2_day.rpy:351
translate Spanish day2_start2_2b8d4a95:

    # GR "what was not satisfactory about the insult?"
    GR "¿qué no te gustó del insulto?"

# game/chapters/2_day.rpy:352
translate Spanish day2_start2_fc29e8e5:

    # GR "i believe it was good."
    GR "yo creo que estuvo bien."

# game/chapters/2_day.rpy:356
translate Spanish day2_start2_ec6823d4:

    # player "You... tried your best."
    player "Tú... hiciste lo que pudiste."

# game/chapters/2_day.rpy:359
translate Spanish day2_start2_eec2f351:

    # player "Anyway... I'm just going to move on from that."
    player "En fin... mejor dejemos eso atrás."

# game/chapters/2_day.rpy:360
translate Spanish day2_start2_5fc147b8:

    # GR "hey..."
    GR "oye…"

# game/chapters/2_day.rpy:363
translate Spanish day2_start2_7a1f7a65:

    # player "I suppose we'll be fools together, then."
    player "Supongo que seremos ridículos juntos, entonces."

# game/chapters/2_day.rpy:364
translate Spanish day2_start2_a948ae31:

    # GR "no, it will be only you."
    GR "no, solo tú."

# game/chapters/2_day.rpy:367
translate Spanish day2_start2_06eb6e24:

    # player "Just two silly fools :)"
    player "Solo dos tontos :)"

# game/chapters/2_day.rpy:368
translate Spanish day2_start2_230dec51:

    # GR "...."
    GR "...."

# game/chapters/2_day.rpy:371
translate Spanish day2_start2_f105d6f0:

    # player "I didn't see you once. A shame."
    player "No te vi ni una vez. Una pena."

# game/chapters/2_day.rpy:372
translate Spanish day2_start2_6e41bbdf:

    # GR "yes, well, i was a little busy."
    GR "sí, bueno, estuve un poco ocupado."

# game/chapters/2_day.rpy:373
translate Spanish day2_start2_b01a6e2e:

    # GR "i could not put in the effort i had hoped to."
    GR "no pude poner el esfuerzo que esperaba."

# game/chapters/2_day.rpy:374
translate Spanish day2_start2_e055e179:

    # GR "still, the day is young."
    GR "aun así, el día es joven."

# game/chapters/2_day.rpy:377
translate Spanish day2_start2_91a61bf5:

    # player "You're gonna turn up at my place in the middle of the night?"
    player "¿Vas a aparecerte en mi casa en medio de la noche?"

# game/chapters/2_day.rpy:378
translate Spanish day2_start2_a4d15129:

    # GR "perhaps."
    GR "quizás."

# game/chapters/2_day.rpy:379
translate Spanish day2_start2_7c8bdce4:

    # GR "with a deal like ours on the line, anything could happen."
    GR "con un trato como el nuestro en juego, cualquier cosa podría pasar."

# game/chapters/2_day.rpy:380
translate Spanish day2_start2_43107cfe:

    # GR "prepare yourself."
    GR "prepárate."

# game/chapters/2_day.rpy:383
translate Spanish day2_start2_9808d85e:

    # player "I'll get myself dressed up all fancy, then."
    player "Entonces me arreglaré bien elegante."

# game/chapters/2_day.rpy:384
translate Spanish day2_start2_ac199885:

    # GR "huh??? no, that's not needed."
    GR "¿¿¿eh??? no, eso no es necesario."

# game/chapters/2_day.rpy:387
translate Spanish day2_start2_b3680d91:

    # player "We'll make a special night out of it."
    player "Haremos que sea una noche especial."

# game/chapters/2_day.rpy:388
translate Spanish day2_start2_887681dd:

    # GR "no, i don't think we should do that."
    GR "no, no creo que debamos hacer eso."

# game/chapters/2_day.rpy:389
translate Spanish day2_start2_3e80b141:

    # GR "or do you plan to let me win the bet that easily?"
    GR "¿o planeas dejarme ganar la apuesta tan fácilmente?"

# game/chapters/2_day.rpy:392
translate Spanish day2_start2_2fa23ba3:

    # player "Right, the bet."
    player "Cierto, la apuesta."

# game/chapters/2_day.rpy:395
translate Spanish day2_start2_0a70e076:

    # player "The one that's totally real."
    player "La que es totalmente real."

# game/chapters/2_day.rpy:398
translate Spanish day2_start2_60a9903b:

    # player "The bet I have with the literal Grim Reaper."
    player "La apuesta que tengo con la mismísima Parca."

# game/chapters/2_day.rpy:399
translate Spanish day2_start2_990b023c:

    # GR "yes, i am the grim reaper, and we have a bet."
    GR "sí, yo soy la parca, y tenemos una apuesta."

# game/chapters/2_day.rpy:400
translate Spanish day2_start2_8a5f6d5a:

    # GR "did you hit your head?"
    GR "¿te golpeaste la cabeza?"

# game/chapters/2_day.rpy:406
translate Spanish day2_start2_e722d802:

    # player "I can't wait, you know."
    player "No puedo esperar, ¿sabes?"

# game/chapters/2_day.rpy:407
translate Spanish day2_start2_a547fe18:

    # GR "for...?"
    GR "¿para...?"

# game/chapters/2_day.rpy:411
translate Spanish day2_start2_98a83f0b:

    # player "I can't wait for the day where you have to admit that you're a liar."
    player "No puedo esperar al día en que tengas que admitir que eres un mentiroso."

# game/chapters/2_day.rpy:415
translate Spanish day2_start2_678d5fd7:

    # player "That you, too, are just a 'poor mortal'."
    player "Que tú también eres solo un 'pobre mortal'."

# game/chapters/2_day.rpy:416
translate Spanish day2_start2_8ad77a5e:

    # GR "you would do best to remember your fate lies in {i}my{/i} hands."
    GR "harías bien en recordar que tu destino está en {i}mis{/i} manos."

# game/chapters/2_day.rpy:417
translate Spanish day2_start2_7f06721f:

    # GR "your life can come to an end at any moment."
    GR "tu vida puede terminar en cualquier momento."

# game/chapters/2_day.rpy:420
translate Spanish day2_start2_5fc18995:

    # player "Yeah? So why am I still here?"
    player "¿Ah, sí? ¿Entonces por qué sigo aquí?"

# game/chapters/2_day.rpy:421
translate Spanish day2_start2_2cfbaea0:

    # GR "well..."
    GR "bueno..."

# game/chapters/2_day.rpy:424
translate Spanish day2_start2_13d82dab:

    # player "Didn't you say you'd have my soul in an hour?"
    player "¿No dijiste que tendrías mi alma en una hora?"

# game/chapters/2_day.rpy:427
translate Spanish day2_start2_3007d11f:

    # player "Honestly, I'm surprised someone as powerful as you is taking so long."
    player "Sinceramente, me sorprende que alguien tan poderoso como tú esté tardando tanto."

# game/chapters/2_day.rpy:429
translate Spanish day2_start2_1b690567:

    # GR "i've simply decided to not rush."
    GR "simplemente he decidido no apresurarme."

# game/chapters/2_day.rpy:432
translate Spanish day2_start2_70198280:

    # player "What have you been doing today, then?"
    player "¿Qué has estado haciendo hoy, entonces?"

# game/chapters/2_day.rpy:435
translate Spanish day2_start2_20df67cb:

    # player "Stealing other poor mortal souls?"
    player "¿Robando las almas de otros pobres mortales?"

# game/chapters/2_day.rpy:438
translate Spanish day2_start2_680e468c:

    # player "Here I thought I was special..."
    player "Yo que pensaba que era especial..."

# game/chapters/2_day.rpy:439
translate Spanish day2_start2_7b1e48c5:

    # GR "interested in my day to day life, are we?"
    GR "¿interesad[letra] en mi día a día, eh?"

# game/chapters/2_day.rpy:442
translate Spanish day2_start2_6cd5d338:

    # player "Maybe. Maybe not."
    player "Tal vez sí. Tal vez no."

# game/chapters/2_day.rpy:445
translate Spanish day2_start2_3c992b94:

    # player "Could be. Or maybe I couldn't care less."
    player "Puede ser. O quizá me importe un comino."

# game/chapters/2_day.rpy:448
translate Spanish day2_start2_4b7655a9:

    # player "Actually, yes."
    player "En realidad, sí."

# game/chapters/2_day.rpy:451
translate Spanish day2_start2_a8b2108b:

    # player "Is that any real surprise?"
    player "¿Eso realmente te sorprende?"

# game/chapters/2_day.rpy:454
translate Spanish day2_start2_befdde6c:

    # player "You're the Grim Reaper. It's only natural, right?"
    player "Eres la Parca. Es lo natural, ¿no?"

# game/chapters/2_day.rpy:458
translate Spanish day2_start2_640d0f9c:

    # player "By the way, is that you in your pfp?"
    player "Por cierto, ¿ese eres tú en tu foto de perfil?"

# game/chapters/2_day.rpy:461
translate Spanish day2_start2_e1192163:

    # player "Is that a selfie?"
    player "¿Es un selfie?"

# game/chapters/2_day.rpy:463
translate Spanish day2_start2_886a214a:

    # GR "...so what if it is?"
    GR "...¿y qué si lo es?"

# game/chapters/2_day.rpy:467
translate Spanish day2_start2_c067a304:

    # player "You're so embarrassing."
    player "Qué vergüenza contigo."

# game/chapters/2_day.rpy:469
translate Spanish day2_start2_446b1c7d:

    # player "That's almost cute."
    player "Eso es hasta tierno."

# game/chapters/2_day.rpy:473
translate Spanish day2_start2_b42d6402:

    # player "I bet you took it just for me."
    player "Apuesto a que la tomaste solo para mí."

# game/chapters/2_day.rpy:477
translate Spanish day2_start2_6f7c5aa0:

    # player "You're pretty much obsessed with me, aren't you?"
    player "Estás bastante obsesionado conmigo, ¿no?"

# game/chapters/2_day.rpy:479
translate Spanish day2_start2_f94badc6:

    # GR "shut up."
    GR "cállate."

# game/chapters/2_day.rpy:480
translate Spanish day2_start2_25ce05cb:

    # GR "you are stupid and talk too much."
    GR "eres [arti_2] idiota y hablas demasiado."

# game/chapters/2_day.rpy:481
translate Spanish day2_start2_3f583c52:

    # GR "forget my picture. let's go back to talking about my day."
    GR "olvida mi foto. volvamos a hablar de mi día."

# game/chapters/2_day.rpy:482
translate Spanish day2_start2_bf8c00df:

    # GR "it was busy, as per usual."
    GR "estuvo ocupado, como siempre."

# game/chapters/2_day.rpy:483
translate Spanish day2_start2_d64549ff:

    # GR "and you, mortal?"
    GR "¿y tú, mortal?"

# game/chapters/2_day.rpy:484
translate Spanish day2_start2_195801f9:

    # GR "what takes your time during the days?"
    GR "¿en qué se te va el tiempo durante los días?"

# game/chapters/2_day.rpy:488
translate Spanish day2_start2_7a0119be:

    # player "Work, obviously."
    player "Trabajo, obviamente."

# game/chapters/2_day.rpy:490
translate Spanish day2_start2_32e71c1c:

    # player "The bills don't pay themselves."
    player "Las cuentas no se pagan solas."

# game/chapters/2_day.rpy:492
translate Spanish day2_start2_157f13d4:

    # player "Slaving away my life for other people..."
    player "Esclavizando mi vida para otros..."

# game/chapters/2_day.rpy:494
translate Spanish day2_start2_c3320fca:

    # GR "elaborate {font=gui/NotoSans-Light.ttf}({/font} {font=gui/NotoSansJP-VariableFont_wght.ttf}￣ー￣{/font}{font=gui/NotoSans-Light.ttf}){/font}"
    GR "explícate {font=gui/NotoSans-Light.ttf}({/font} {font=gui/NotoSansJP-VariableFont_wght.ttf}￣ー￣{/font}{font=gui/NotoSans-Light.ttf}){/font}"

# game/chapters/2_day.rpy:497
translate Spanish day2_start2_f097e4cb:

    # player "Who's interested in whose day to day life now?"
    player "¿Quién está interesado ahora en la vida cotidiana de quién?"

# game/chapters/2_day.rpy:501
translate Spanish day2_start2_494daa63:

    # player "I work as a mortician, actually..."
    player "En realidad, trabajo en una funeraria..."

# game/chapters/2_day.rpy:502
translate Spanish day2_start2_4626c80e:

    # GR "shit, really?"
    GR "mierda, ¿en serio?"

# game/chapters/2_day.rpy:505
translate Spanish day2_start2_0c081e71:

    # player "Yes."
    player "Sí."

# game/chapters/2_day.rpy:506
translate Spanish day2_start2_4a2077d6:

    # GR "that's kinda hilarious... {font=gui/NotoSansJP-VariableFont_wght.ttf}ヾ{/font}{font=gui/NotoSans-Light.ttf}( ˃ᴗ˂ ){/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}ツ • *{/font}{font=gui/Kelvinch-Roman.otf}✰{/font}"
    GR "eso es bastante gracioso... {font=gui/NotoSansJP-VariableFont_wght.ttf}ヾ{/font}{font=gui/NotoSans-Light.ttf}( ˃ᴗ˂ ){/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}ツ • *{/font}{font=gui/Kelvinch-Roman.otf}✰{/font}"

# game/chapters/2_day.rpy:509
translate Spanish day2_start2_f35c886d:

    # player "I'm so glad you find my profession hilarious..."
    player "Me alegra mucho que encuentres mi profesión graciosa..."

# game/chapters/2_day.rpy:510
translate Spanish day2_start2_b5e6b55f:

    # GR "i sure as hell do."
    GR "yo, desde luego, sí."

# game/chapters/2_day.rpy:512
translate Spanish day2_start2_67bcef60:

    # player "I have to admit, it's a little funny."
    player "Tengo que admitirlo, es un poco gracioso."

# game/chapters/2_day.rpy:513
translate Spanish day2_start2_2fde1787:

    # GR "it sure as hell is."
    GR "desde luego que lo es."

# game/chapters/2_day.rpy:515
translate Spanish day2_start2_706a88d4:

    # GR "what are the chances? a grim reaper and a mortician."
    GR "¿cuáles son las probabilidades? una parca y [arti_2] agente funerari[letra]."

# game/chapters/2_day.rpy:516
translate Spanish day2_start2_9c42fc60:

    # GR "it sounds like the start of a joke."
    GR "suena al comienzo de un chiste."

# game/chapters/2_day.rpy:517
translate Spanish day2_start2_9e50fb1d:

    # GR "two people who deal with death. very interesting indeed."
    GR "dos personas que lidian con la muerte. muy interesante, sin duda."

# game/chapters/2_day.rpy:521
translate Spanish day2_start2_549ad772:

    # player "Maybe we were fated to meet :)"
    player "Quizás estábamos destinados a encontrarnos :)"

# game/chapters/2_day.rpy:522
translate Spanish day2_start2_fdadfe19:

    # GR "perhaps so."
    GR "quizás sí."

# game/chapters/2_day.rpy:523
translate Spanish day2_start2_3a16c79d:

    # GR "fated to meet, then fated to be enemies."
    GR "destinados a encontrarnos, luego destinados a ser enemigos."

# game/chapters/2_day.rpy:525
translate Spanish day2_start2_bedec081:

    # player "One of us definitely does. I'm not sure about the other ;)"
    player "Uno de nosotros seguro que sí. No estoy tan segur[letra] del otro ;)"

# game/chapters/2_day.rpy:526
translate Spanish day2_start2_4214dc2d:

    # GR "what do you mean by that?"
    GR "¿qué quieres decir con eso?"

# game/chapters/2_day.rpy:527
translate Spanish day2_start2_635bb989:

    # GR "if you're trying to imply, once again, that i am not the grim reaper, then you are incorrect."
    GR "si intentas insinuar, una vez más, que yo no soy la parca, estás equivocad[letra]."

# game/chapters/2_day.rpy:534
translate Spanish day2_start2_3d2c9cd5:

    # player "I do freelance."
    player "Trabajo por cuenta propia."

# game/chapters/2_day.rpy:535
translate Spanish day2_start2_1512a7d1:

    # GR "you get to pick your own work hours?"
    GR "¿tú puedes elegir tu propio horario?"

# game/chapters/2_day.rpy:538
translate Spanish day2_start2_454484a8:

    # player "Yeah, most of the time."
    player "Sí, la mayor parte del tiempo."

# game/chapters/2_day.rpy:539
translate Spanish day2_start2_ab6fd09e:

    # GR "...lucky for some."
    GR "...qué suerte tienen algunos."

# game/chapters/2_day.rpy:542
translate Spanish day2_start2_e9a092c0:

    # player "Jealous?"
    player "¿Celoso?"

# game/chapters/2_day.rpy:543
translate Spanish day2_start2_a1e49292:

    # GR "...!"
    GR "...!"

# game/chapters/2_day.rpy:544
translate Spanish day2_start2_c9ac146b:

    # GR "i... ahem."
    GR "yo... ejem."

# game/chapters/2_day.rpy:545
translate Spanish day2_start2_d83d1e1e:

    # GR "i would never be jealous of a mortal."
    GR "jamás sentiría celos de un mortal."

# game/chapters/2_day.rpy:546
translate Spanish day2_start2_14202f3b:

    # GR "...never. never ever."
    GR "...jamás. nunca jamás."

# game/chapters/2_day.rpy:549
translate Spanish day2_start2_b81babd9:

    # player "Just admit it."
    player "Admítelo."

# game/chapters/2_day.rpy:550
translate Spanish day2_start2_c30211c0:

    # GR "i..."
    GR "yo..."

# game/chapters/2_day.rpy:551
translate Spanish day2_start2_b5c8065a:

    # GR "i am, perhaps, slightly envious. jealous would be an overstatement."
    GR "estoy, quizá, un poco envidioso. celoso sería exagerar."

# game/chapters/2_day.rpy:554
translate Spanish day2_start2_a8b3d922:

    # player "Sure ;)"
    player "Claro ;)"

# game/chapters/2_day.rpy:555
translate Spanish day2_start2_9341f14d:

    # GR "ugh..."
    GR "ugh..."

# game/chapters/2_day.rpy:559
translate Spanish day2_start2_2a0457dc:

    # player "You should try."
    player "Deberías intentarlo."

# game/chapters/2_day.rpy:560
translate Spanish day2_start2_a2013173:

    # GR "becoming a freelance reaper? don't be preposterous."
    GR "¿convertirme en una parca freelance? qué ridículo."

# game/chapters/2_day.rpy:561
translate Spanish day2_start2_8850e023:

    # GR "there is no such thing."
    GR "no existe tal cosa."

# game/chapters/2_day.rpy:562
translate Spanish day2_start2_7b15e228:

    # GR "the organization i belong to would never allow it."
    GR "la organización a la que pertenezco nunca lo permitiría."

# game/chapters/2_day.rpy:566
translate Spanish day2_start2_4c9aa5fd:

    # player "I work in fashion."
    player "Yo trabajo en el sector de la moda."

# game/chapters/2_day.rpy:567
translate Spanish day2_start2_7ccb8ecc:

    # GR "is that why you look like that?"
    GR "¿es por eso que te ves así?"

# game/chapters/2_day.rpy:570
translate Spanish day2_start2_f2c4fd88:

    # player "What's that supposed to mean..."
    player "¿Qué se supone que significa eso...?"

# game/chapters/2_day.rpy:571
translate Spanish day2_start2_47351f01:

    # GR "do you design your own clothes, mortal?"
    GR "¿diseñas tu propia ropa, mortal?"

# game/chapters/2_day.rpy:574
translate Spanish day2_start2_13507bf7:

    # player "Well, yeah?"
    player "Bueno, ¿sí?"

# game/chapters/2_day.rpy:576
translate Spanish day2_start2_3a2b853f:

    # player "No, but I picked it very carefully."
    player "No, pero la elegí con mucho cuidado."

# game/chapters/2_day.rpy:578
translate Spanish day2_start2_c2c0d712:

    # GR "so that is why you look like that."
    GR "así que por eso te ves así."

# game/chapters/2_day.rpy:579
translate Spanish day2_start2_59b665a4:

    # GR "interesting. mortals make such riveting decisions."
    GR "interesante. los mortales toman decisiones tan fascinantes."

# game/chapters/2_day.rpy:582
translate Spanish day2_start2_03775ec8_3:

    # player "..."
    player "..."

# game/chapters/2_day.rpy:585
translate Spanish day2_start2_93ef5b29:

    # player "Pot meet kettle."
    player "El burro hablando de orejas."

# game/chapters/2_day.rpy:587
translate Spanish day2_start2_4cf62b72:

    # player "Take a look in the mirror."
    player "Mírate en el espejo."

# game/chapters/2_day.rpy:592
translate Spanish day2_start2_0b4e68e5:

    # player "I work in a school, teaching."
    player "Yo trabajo en una escuela, enseñando."

# game/chapters/2_day.rpy:593
translate Spanish day2_start2_af9a4a27:

    # GR "teaching... children?"
    GR "¿enseñando... a niños?"

# game/chapters/2_day.rpy:594
translate Spanish day2_start2_db9bfb2a:

    # GR "you poor thing..."
    GR "pobre criatura..."

# game/chapters/2_day.rpy:597
translate Spanish day2_start2_9cea66f2:

    # player "I enjoy it, thank you very much."
    player "Lo disfruto mucho, muchas gracias."

# game/chapters/2_day.rpy:601
translate Spanish day2_start2_75e6a233:

    # player "Okay, I can understand the reaction."
    player "Okey, puedo entender la reacción."

# game/chapters/2_day.rpy:603
translate Spanish day2_start2_e486da0c:

    # GR "awful creatures."
    GR "criaturas horribles."

# game/chapters/2_day.rpy:604
translate Spanish day2_start2_a0a19a9e:

    # GR "absolutely abominable. detestable little things."
    GR "absolutamente abominables. detestables cositas."

# game/chapters/2_day.rpy:608
translate Spanish day2_start2_293872a5:

    # player "They are sweet! Mostly..."
    player "¡Son dulces! En su mayoría..."

# game/chapters/2_day.rpy:609
translate Spanish day2_start2_64797a48:

    # GR "they are messy little grubs who torture those that should be their superiors."
    GR "son pequeños bichos desordenados que torturan a quienes deberían ser sus superiores."

# game/chapters/2_day.rpy:611
translate Spanish day2_start2_b0762d61:

    # player "Yes, okay, fair."
    player "Sí, okey, tienes razón."

# game/chapters/2_day.rpy:612
translate Spanish day2_start2_07193f6a:

    # GR "you should consider a career change, with the little time you have left."
    GR "deberías considerar un cambio de carrera, con el poco tiempo que te queda."

# game/chapters/2_day.rpy:613
translate Spanish day2_start2_5a3adc47:

    # GR "there is no point in travelling to the afterlife in the pain i imagine you must be in."
    GR "no tiene sentido viajar al más allá con el dolor que imagino debes sentir."

# game/chapters/2_day.rpy:617
translate Spanish day2_start2_a6d96dbe:

    # player "I make computer games."
    player "Hago videojuegos."

# game/chapters/2_day.rpy:618
translate Spanish day2_start2_5962d79e:

    # GR "hmm, i suppose it suits you..."
    GR "hmm, supongo que va contigo..."

# game/chapters/2_day.rpy:621
translate Spanish day2_start2_3202412b:

    # player "It does?"
    player "¿Sí?"

# game/chapters/2_day.rpy:622
translate Spanish day2_start2_09234ac8:

    # GR "yep."
    GR "sí."

# game/chapters/2_day.rpy:624
translate Spanish day2_start2_0241335f:

    # player "Thank you...?"
    player "¿Gracias...?"

# game/chapters/2_day.rpy:625
translate Spanish day2_start2_287b2466:

    # GR "you are welcome...?"
    GR "¿de nada...?"

# game/chapters/2_day.rpy:628
translate Spanish day2_start2_7593cdf3:

    # player "I'm hoping that's a good thing..."
    player "Espero que eso sea algo bueno..."

# game/chapters/2_day.rpy:629
translate Spanish day2_start2_ba8decc3:

    # GR "think whatever you want."
    GR "piensa lo que quieras."

# game/chapters/2_day.rpy:630
translate Spanish day2_start2_bb7b5f81:

    # GR "my intentions shall remain a secret."
    GR "mis intenciones seguirán siendo un secreto."

# game/chapters/2_day.rpy:633
translate Spanish day2_start2_0ced4e41:

    # player "Aren't you going to ask if I've made anything you've played?"
    player "¿No vas a preguntar si he hecho algo que hayas jugado?"

# game/chapters/2_day.rpy:636
translate Spanish day2_start2_8a4dbec9:

    # player "That's usually someone's first question."
    player "Esa suele ser la primera pregunta de alguien."

# game/chapters/2_day.rpy:637
translate Spanish day2_start2_47f58bfa:

    # GR "why would i care?"
    GR "¿por qué me importaría?"

# game/chapters/2_day.rpy:638
translate Spanish day2_start2_b0fc3e3b:

    # GR "you create something with, i imagine, love and care."
    GR "creas algo con, imagino, amor y cuidado."

# game/chapters/2_day.rpy:639
translate Spanish day2_start2_593d533e:

    # GR "whether i know your creation or not, that makes little difference."
    GR "si conozco tu creación o no, eso importa poco."

# game/chapters/2_day.rpy:640
translate Spanish day2_start2_c0bb53cc:

    # GR "to create is admirable, and is an achievement itself."
    GR "crear es admirable, y ya es un logro en sí mismo."

# game/chapters/2_day.rpy:643
translate Spanish day2_start2_eaba0a47:

    # player "Oh."
    player "Oh."

# game/chapters/2_day.rpy:646
translate Spanish day2_start2_9ce5a5bc:

    # player "I... hadn't expected you to think that."
    player "Yo... no esperaba que pensaras eso."

# game/chapters/2_day.rpy:650
translate Spanish day2_start2_5a6e5dbf:

    # player "Thank you."
    player "Gracias."

# game/chapters/2_day.rpy:651
translate Spanish day2_start2_b7d4b195:

    # GR "there is nothing to thank me for."
    GR "no hay nada que agradecerme."

# game/chapters/2_day.rpy:655
translate Spanish day2_start2_dc07e2dd:

    # player "I'm an artist."
    player "Soy artista."

# game/chapters/2_day.rpy:656
translate Spanish day2_start2_d096584a:

    # GR "an artist? like one that draws and paints and such?"
    GR "¿artista? ¿como uno que dibuja y pinta y esas cosas?"

# game/chapters/2_day.rpy:657
translate Spanish day2_start2_2a8c23c2:

    # GR "i suppose i have become your newest muse."
    GR "supongo que me he convertido en tu musa más reciente."

# game/chapters/2_day.rpy:658
translate Spanish day2_start2_350d4f85:

    # GR "have you already drawn me, then stared at my figure longingly?"
    GR "¿ya me has dibujado y luego mirado mi figura con anhelo?"

# game/chapters/2_day.rpy:661
translate Spanish day2_start2_29113672:

    # player "No."
    player "No."

# game/chapters/2_day.rpy:664
translate Spanish day2_start2_33a625fa:

    # player "I think you're kinda obsessed with yourself, ngl."
    player "Creo que estás un poquito obsesionado contigo mismo, la verdad."

# game/chapters/2_day.rpy:665
translate Spanish day2_start2_e16f226c:

    # GR "obviously."
    GR "obviamente."

# game/chapters/2_day.rpy:666
translate Spanish day2_start2_a9883739:

    # GR "there is a lot to be obsessed with, don't you think?"
    GR "hay mucho de lo que obsesionarse, ¿no crees?"

# game/chapters/2_day.rpy:669
translate Spanish day2_start2_be89d1c0:

    # player "Not really..."
    player "La verdad no..."

# game/chapters/2_day.rpy:670
translate Spanish day2_start2_dc8668fc:

    # GR "...so you are choosing not to be honest with yourself."
    GR "...así que estás eligiendo no decirte la verdad."

# game/chapters/2_day.rpy:671
translate Spanish day2_start2_61f18d1a:

    # GR "fine. but i know you agree with me."
    GR "está bien. pero sé que estás de acuerdo conmigo."

# game/chapters/2_day.rpy:672
translate Spanish day2_start2_3cc79237:

    # GR "you longed to talk to me today, did you not?"
    GR "ansiabas hablar conmigo hoy, ¿no es así?"

# game/chapters/2_day.rpy:676
translate Spanish day2_start2_cea0a39b:

    # player "No answer."
    player "Sin comentarios."

# game/chapters/2_day.rpy:677
translate Spanish day2_start2_3dcb441c:

    # GR "uh huh. no answer."
    GR "eh ajá. sin respuesta."

# game/chapters/2_day.rpy:678
translate Spanish day2_start2_ccecd988:

    # GR "an admission of guilt as much as anything, i say."
    GR "una admisión de culpa más que otra cosa, diría yo."

# game/chapters/2_day.rpy:681
translate Spanish day2_start2_1d90de90:

    # player "I... was just bored."
    player "Yo... simplemente estaba aburrid[letra]."

# game/chapters/2_day.rpy:682
translate Spanish day2_start2_a326aec7:

    # GR "bored of your everyday life, yes?"
    GR "¿te aburre tu vida cotidiana, cierto?"

# game/chapters/2_day.rpy:683
translate Spanish day2_start2_d46cd7e4:

    # GR "especially when i was but a message away. someone beyond your wildest dreams."
    GR "más aún cuando yo estaba a un mensaje de distancia. alguien más allá de tus fantasías."

# game/chapters/2_day.rpy:686
translate Spanish day2_start2_1ccd33b8:

    # player "I, uh... maybe..."
    player "Yo, eh... tal vez..."

# game/chapters/2_day.rpy:687
translate Spanish day2_start2_7852b338:

    # GR "no need to play coy. it is a natural reaction that you're having."
    GR "no necesitas mostrar timidez. es una reacción natural la que estás teniendo."

# game/chapters/2_day.rpy:688
translate Spanish day2_start2_6e33b3f0:

    # GR "you gaze upon a man of immense beauty and supernatural power. it is obvious you would be obsessed."
    GR "contemplas a un hombre de inmensa belleza y poder sobrenatural. es obvio que te obsesionarías."

# game/chapters/2_day.rpy:692
translate Spanish day2_start2_6c3d8ddb:

    # player "Obsessed is a little much."
    player "Llamarlo obsesión es un poco exagerado."

# game/chapters/2_day.rpy:693
translate Spanish day2_start2_4d1b1b6c:

    # GR "but in this case, perhaps correct."
    GR "pero en este caso, tal vez sea correcto."

# game/chapters/2_day.rpy:694
translate Spanish day2_start2_157719eb:

    # GR "i do not fault you for it."
    GR "no te culpo por ello."

# game/chapters/2_day.rpy:695
translate Spanish day2_start2_85e50c52:

    # GR "at least when you meet your end, you will be graced with my presence."
    GR "al menos, cuando llegue tu final, tendrás el honor de estar en mi presencia."

# game/chapters/2_day.rpy:698
translate Spanish day2_start2_398403df:

    # player "Look, you are pretty, okay?"
    player "Mira, eres bonito, ¿ok?"

# game/chapters/2_day.rpy:699
translate Spanish day2_start2_7772a27d_2:

    # GR "..."
    GR "..."

# game/chapters/2_day.rpy:700
translate Spanish day2_start2_ae52b1db:

    # GR "huh?? wha... huh?"
    GR "¿¿eh?? ¿qué... eh?"

# game/chapters/2_day.rpy:701
translate Spanish day2_start2_7a6e733f:

    # GR "pretty..."
    GR "bonito..."

# game/chapters/2_day.rpy:702
translate Spanish day2_start2_739d741f:

    # GR "i am... far from pretty."
    GR "yo... estoy muy lejos de ser bonito."

# game/chapters/2_day.rpy:705
translate Spanish day2_start2_9e49f097:

    # player "Yeah. You do seem like a catch."
    player "Sí. La verdad es que pareces todo un partidazo."

# game/chapters/2_day.rpy:706
translate Spanish day2_start2_3f7ad2f6_1:

    # GR "oh."
    GR "oh."

# game/chapters/2_day.rpy:707
translate Spanish day2_start2_41187a30:

    # GR "um."
    GR "um."

# game/chapters/2_day.rpy:708
translate Spanish day2_start2_7820c210:

    # GR "...thanks."
    GR "...gracias."

# game/chapters/2_day.rpy:712
translate Spanish day2_start2_03775ec8_4:

    # player "..."
    player "..."

# game/chapters/2_day.rpy:713
translate Spanish day2_start2_62aa84b8:

    # GR "ah, an admission of guilt."
    GR "ah, una admisión de culpa."

# game/chapters/2_day.rpy:714
translate Spanish day2_start2_d1441072:

    # GR "go on, you can tell me of your sins."
    GR "vamos, puedes contarme tus pecados."

# game/chapters/2_day.rpy:718
translate Spanish day2_start2_cdf9b13d:

    # player "Fine, I drew you."
    player "Está bien, te dibujé."

# game/chapters/2_day.rpy:719
translate Spanish day2_start2_a6ff0551:

    # GR "i knew it."
    GR "lo sabía."

# game/chapters/2_day.rpy:720
translate Spanish day2_start2_bed157ee:

    # GR "i would like to see this artwork of yours."
    GR "me gustaría ver esa obra tuya."

# game/chapters/2_day.rpy:721
translate Spanish day2_start2_5b68fd4e:

    # GR "please send it."
    GR "por favor envíala."

# game/chapters/2_day.rpy:725
translate Spanish day2_start2_498331a1:

    # player "Well, that depends."
    player "Bueno, depende."

# game/chapters/2_day.rpy:726
translate Spanish day2_start2_b4d881db:

    # GR "depends on?"
    GR "¿depende de?"

# game/chapters/2_day.rpy:729
translate Spanish day2_start2_87ac9cca:

    # player "If you be a good boy."
    player "Si eres un buen chico."

# game/chapters/2_day.rpy:730
translate Spanish day2_start2_1570dbf4:

    # GR "a... a good boy?"
    GR "¿un... buen chico?"

# game/chapters/2_day.rpy:731
translate Spanish day2_start2_1d0dc1d1:

    # GR "i am not a dog!"
    GR "¡no soy un perro!"

# game/chapters/2_day.rpy:735
translate Spanish day2_start2_f1d03c35:

    # player "Now there's an idea."
    player "Esa sí que es una buena idea."

# game/chapters/2_day.rpy:739
translate Spanish day2_start2_b85cd9cd:

    # player "Say woof and I'll send it to you."
    player "Di 'guau' y te la envío."

# game/chapters/2_day.rpy:740
translate Spanish day2_start2_e14c8429:

    # GR "huh????"
    GR "¿¿¿eh???"

# game/chapters/2_day.rpy:741
translate Spanish day2_start2_0609439a:

    # GR "what???????????"
    GR "¿¿¿quéeeee???"

# game/chapters/2_day.rpy:745
translate Spanish day2_start2_54c10d63:

    # player "I'm kidding."
    player "Estoy bromeando."

# game/chapters/2_day.rpy:746
translate Spanish day2_start2_396764b3:

    # GR "...good. that would have been an illogical ask of someone like me."
    GR "...bien. eso habría sido una petición ilógica para alguien como yo."

# game/chapters/2_day.rpy:747
translate Spanish day2_start2_be6cf08a:

    # GR "i do not bark."
    GR "no ladro."

# game/chapters/2_day.rpy:751
translate Spanish day2_start2_0b4cfa5d:

    # player "Maybe for the right person ;)"
    player "Quizá por la persona indicada ;)"

# game/chapters/2_day.rpy:752
translate Spanish day2_start2_95151b2c_1:

    # GR "....."
    GR "....."

# game/chapters/2_day.rpy:753
translate Spanish day2_start2_0182f665:

    # GR "i am a grim reaper. grim reaper's do not bark."
    GR "soy la parca. la parca no ladra."

# game/chapters/2_day.rpy:756
translate Spanish day2_start2_c355a9a0:

    # player "Yet."
    player "Aún."

# game/chapters/2_day.rpy:757
translate Spanish day2_start2_e2342228:

    # GR "there will not come a time where i will bark."
    GR "no llegará un momento en el que ladre."

# game/chapters/2_day.rpy:758
translate Spanish day2_start2_6f74a0bb:

    # GR "absolutely not."
    GR "absolutamente no."

# game/chapters/2_day.rpy:761
translate Spanish day2_start2_862560ca:

    # player "I do. Woof."
    player "Yo sí. *Guau Guau*"

# game/chapters/2_day.rpy:762
translate Spanish day2_start2_849cd8fd:

    # GR "did... did you really just say woof?"
    GR "¿a... acabas de decir 'guau'?"

# game/chapters/2_day.rpy:763
translate Spanish day2_start2_14774a80:

    # GR "........"
    GR "........"

# game/chapters/2_day.rpy:764
translate Spanish day2_start2_86743294:

    # GR "humans are strange beyond words. I fear I may never truly understand them."
    GR "los humanos son extraños más allá de las palabras. me temo que nunca llegaré a comprenderlos."

# game/chapters/2_day.rpy:768
translate Spanish day2_start2_27186bd1:

    # player "No art for you, though."
    player "Pero tú no tendrás el dibujo."

# game/chapters/2_day.rpy:769
translate Spanish day2_start2_7772a27d_3:

    # GR "..."
    GR "..."

# game/chapters/2_day.rpy:770
translate Spanish day2_start2_da2e5d22:

    # GR "that is a shame. i was looking forward to seeing it."
    GR "es una lástima. tenía muchas ganas de verlo."

# game/chapters/2_day.rpy:771
translate Spanish day2_start2_e8786d9e:

    # GR "i will imagine it, then."
    GR "lo imaginaré, entonces."

# game/chapters/2_day.rpy:772
translate Spanish day2_start2_10d185c8:

    # GR "it is glorious, just as i am."
    GR "es glorioso, como yo."

# game/chapters/2_day.rpy:775
translate Spanish day2_start2_23d93737:

    # player "Back to the topic on hand, though..."
    player "Volviendo al tema que nos ocupa..."

# game/chapters/2_day.rpy:779
translate Spanish day2_start2_0ccecf9c:

    # player "Go on. Just one little bark."
    player "Vamos. Solo un ladrido."

# game/chapters/2_day.rpy:780
translate Spanish day2_start2_230dec51_1:

    # GR "...."
    GR "...."

# game/chapters/2_day.rpy:781
translate Spanish day2_start2_bfba7caa:

    # GR "w.... woof..."
    GR "g.... guau..."

# game/chapters/2_day.rpy:785
translate Spanish day2_start2_a80d4133:

    # player "You... you actually did it..."
    player "Tú... en serio lo hiciste..."

# game/chapters/2_day.rpy:786
translate Spanish day2_start2_fbdd2f5a:

    # GR "you told me to!"
    GR "¡tú me lo dijiste!"

# game/chapters/2_day.rpy:787
translate Spanish day2_start2_b4bb92a5:

    # GR "why i complied with your request, even i do not know..."
    GR "ni siquiera yo sé por qué accedí a tu petición..."

# game/chapters/2_day.rpy:788
translate Spanish day2_start2_0344729f:

    # GR "the art better be worth it."
    GR "más vale que el dibujo valga la pena."

# game/chapters/2_day.rpy:791
translate Spanish day2_start2_4698375b:

    # player "How do I send it, then?"
    player "¿Cómo te lo envío, entonces?"

# game/chapters/2_day.rpy:794
translate Spanish day2_start2_419807f5:

    # player "There doesn't seem to be a function for sending images."
    player "No parece haber una función para enviar imágenes."

# game/chapters/2_day.rpy:795
translate Spanish day2_start2_703264c4:

    # GR "ah..."
    GR "ah..."

# game/chapters/2_day.rpy:799
translate Spanish day2_start2_73dc7c38:

    # player "Don't tell me you forgot to put in such a key feature..."
    player "No me digas que olvidaste poner una característica tan importante..."

# game/chapters/2_day.rpy:800
translate Spanish day2_start2_1799b0de:

    # GR "........."
    GR "........."

# game/chapters/2_day.rpy:801
translate Spanish day2_start2_20e41447:

    # GR "i... i..."
    GR "yo... yo..."

# game/chapters/2_day.rpy:802
translate Spanish day2_start2_10e77bf1:

    # GR "i... cannot afford the hosting cost of images. obviously that's why."
    GR "yo... no puedo pagar el alojamiento de imágenes. obviamente por eso."

# game/chapters/2_day.rpy:803
translate Spanish day2_start2_022e45a9:

    # GR "post it somewhere else and i will see it."
    GR "súbelo a otro sitio y lo veré."

# game/chapters/2_day.rpy:807
translate Spanish day2_start2_08d4e37a:

    # player "Here I come, Twotter. #TheGrimReaperSmells."
    player "¡Allá voy, Twotter! #LaParcaHueleMal"

# game/chapters/2_day.rpy:808
translate Spanish day2_start2_d2817595:

    # GR "what."
    GR "¿qué?"

# game/chapters/2_day.rpy:809
translate Spanish day2_start2_71fc5702:

    # GR "that is untrue."
    GR "eso no es verdad."

# game/chapters/2_day.rpy:810
translate Spanish day2_start2_db7b8743:

    # GR "i smell good. fantastic, even."
    GR "huelo bien. fantástico, incluso."

# game/chapters/2_day.rpy:811
translate Spanish day2_start2_ab55ffb9:

    # GR "better than you, i'm sure."
    GR "mejor que tú, estoy seguro."

# game/chapters/2_day.rpy:812
translate Spanish day2_start2_03809736:

    # GR "but fine, i will accept your tribute. i will check for the image shortly."
    GR "pero está bien, aceptaré tu tributo. revisaré la imagen en breve."

# game/chapters/2_day.rpy:816
translate Spanish day2_start2_bae044a6:

    # player "Say pretty please and I'll send it to you."
    player "Di porfis y te la envío."

# game/chapters/2_day.rpy:817
translate Spanish day2_start2_7772a27d_4:

    # GR "..."
    GR "..."

# game/chapters/2_day.rpy:818
translate Spanish day2_start2_3638aa50:

    # GR "fine, then i will not ask to see it."
    GR "bien, entonces no te pediré que me la muestres."

# game/chapters/2_day.rpy:822
translate Spanish day2_start2_96119d37:

    # player "Aww, you don't want to see it?"
    player "Aww, ¿no quieres verla?"

# game/chapters/2_day.rpy:823
translate Spanish day2_start2_8a26d1ae:

    # GR "i did not say that. i said i will not ask to see it."
    GR "no dije eso. dije que no pediré verla."

# game/chapters/2_day.rpy:827
translate Spanish day2_start2_484e0fdf:

    # player "Well, if you change your mind, I'll post it on Twotter. #TheGrimReaperSmells."
    player "Bueno, si cambias de opinión, la subiré a Twotter. #LaParcaHueleMal."

# game/chapters/2_day.rpy:828
translate Spanish day2_start2_79a232c0:

    # GR "i do not smell! that is a lie. an untruth. you should not spread misinformation on the internet!"
    GR "¡yo no huelo mal! eso es una mentira. una falsedad. ¡no deberías difundir desinformación en internet!"

# game/chapters/2_day.rpy:832
translate Spanish day2_start2_bbb10dfe:

    # player "But it's so fun..."
    player "Pero es tan divertido..."

# game/chapters/2_day.rpy:833
translate Spanish day2_start2_5d85aad9:

    # GR "ugh...."
    GR "ugh...."

# game/chapters/2_day.rpy:836
translate Spanish day2_start2_d5921ae2:

    # player "I actually haven't drawn you. Yet."
    player "En realidad no te he dibujado. Aún."

# game/chapters/2_day.rpy:837
translate Spanish day2_start2_471de712:

    # GR "that makes no sense."
    GR "eso no tiene sentido."

# game/chapters/2_day.rpy:841
translate Spanish day2_start2_885500ed:

    # player "How so?"
    player "¿Cómo así?"

# game/chapters/2_day.rpy:842
translate Spanish day2_start2_b9a53c0f:

    # GR "what better muse would there be but i?"
    GR "¿qué mejor musa podrías tener que yo?"

# game/chapters/2_day.rpy:845
translate Spanish day2_start2_02dfe846:

    # player "I can think of one or two."
    player "Puedo pensar en una o dos."

# game/chapters/2_day.rpy:846
translate Spanish day2_start2_455e9986:

    # GR "come now."
    GR "vamos."

# game/chapters/2_day.rpy:847
translate Spanish day2_start2_ad1b718c:

    # GR "we both know that is untrue."
    GR "sabemos los dos que eso no es verdad."

# game/chapters/2_day.rpy:848
translate Spanish day2_start2_e6be4979:

    # GR "you are just embarrassing yourself."
    GR "solo te estás avergonzando."

# game/chapters/2_day.rpy:850
translate Spanish day2_start2_9cd54997:

    # player "Ask me nicely and I might do it."
    player "Pídemelo amablemente y quizá lo haga."

# game/chapters/2_day.rpy:851
translate Spanish day2_start2_ddbd2684:

    # GR "...ask you nicely?"
    GR "¿...que te lo pida amablemente?"

# game/chapters/2_day.rpy:852
translate Spanish day2_start2_a87c8e71:

    # GR "mortal, if anything you should be asking {i}me{/i} nicely."
    GR "mortal, si acaso deberías pedírmelo {i}a mí{/i} amablemente."

# game/chapters/2_day.rpy:853
translate Spanish day2_start2_d5108d14:

    # GR "it would be an honor beyond your understanding to draw a grim reaper."
    GR "sería un honor más allá de tu comprensión dibujar a una parca."

# game/chapters/2_day.rpy:854
translate Spanish day2_start2_c13bc4b4:

    # GR "one that no mortal before you had the privilege of."
    GR "un privilegio del que ningún mortal antes que tú había gozado."

# game/chapters/2_day.rpy:858
translate Spanish day2_start2_50a8be42:

    # player "I'm an animal attendant."
    player "Me dedico al cuidado de animales."

# game/chapters/2_day.rpy:859
translate Spanish day2_start2_96dc0156:

    # GR "ah yes, i assumed you liked animals."
    GR "ah sí, asumí que te gustaban los animales."

# game/chapters/2_day.rpy:860
translate Spanish day2_start2_e202a240:

    # GR "that much was obvious."
    GR "eso era obvio."

# game/chapters/2_day.rpy:863
translate Spanish day2_start2_90a39df0:

    # player "What, why?"
    player "¿Qué, por qué?"

# game/chapters/2_day.rpy:864
translate Spanish day2_start2_4b292d98:

    # GR "i saw one in your room yesterday."
    GR "vi uno en tu habitación ayer."

# game/chapters/2_day.rpy:865
translate Spanish day2_start2_0b4290d1:

    # GR "a little creature sitting upon your bed."
    GR "una pequeña criatura sentada sobre tu cama."

# game/chapters/2_day.rpy:868
translate Spanish day2_start2_02127592:

    # player "Oh! [pet_name]!"
    player "¡Oh! ¡[pet_name]!"

# game/chapters/2_day.rpy:871
translate Spanish day2_start2_58dd73ed:

    # player "[pet_She]'s just the cutest, don't you think?"
    player "[pet_She!t] es [arti_pet] más lind[letra_pet], ¿no crees?"

# game/chapters/2_day.rpy:872
translate Spanish day2_start2_971f8b61:

    # GR "i suppose."
    GR "supongo."

# game/chapters/2_day.rpy:873
translate Spanish day2_start2_bfd8a3c7:

    # GR "the 'cutest' may be a stretch. there's plenty of cute things in the world."
    GR "decir que es [arti_pet] más 'lind[letra_pet]' quizá sea exagerar. hay muchas cosas lindas en el mundo."

# game/chapters/2_day.rpy:876
translate Spanish day2_start2_25e16fd6:

    # player "And [pet_she] is the cutest of them all."
    player "Y [pet_she!t] es [arti_pet] más lind[letra_pet] de tod[letra_pet]s."

# game/chapters/2_day.rpy:877
translate Spanish day2_start2_66f03065:

    # GR "i believe that could be an exaggeration on your part."
    GR "creo que eso podría ser una exageración de tu parte."

# game/chapters/2_day.rpy:878
translate Spanish day2_start2_d3f29318:

    # GR "[pet_name] is not even the cutest type of animal."
    GR "[pet_name] ni siquiera es el tipo de animal más lindo."

# game/chapters/2_day.rpy:882
translate Spanish day2_start2_0e830f2d:

    # player "What is, then?"
    player "¿Entonces cuál es?"

# game/chapters/2_day.rpy:883
translate Spanish day2_start2_75a34e83:

    # GR "the axolotl, obviously."
    GR "el ajolote, obviamente."

# game/chapters/2_day.rpy:884
translate Spanish day2_start2_d12debb0:

    # GR "its stupid little face brings me much joy."
    GR "su carita tonta me da mucha alegría."

# game/chapters/2_day.rpy:888
translate Spanish day2_start2_f1bf1fbf:

    # player "Okay, they're pretty cute."
    player "Okey, son bastante lindos."

# game/chapters/2_day.rpy:889
translate Spanish day2_start2_9101e59e:

    # GR "see? i am always correct."
    GR "¿ves? siempre tengo razón."

# game/chapters/2_day.rpy:892
translate Spanish day2_start2_c6b999ee:

    # player "They're okay, but not as cute as [pet_name]."
    player "Son lindos, pero no tanto como [pet_name]."

# game/chapters/2_day.rpy:893
translate Spanish day2_start2_5ece47f5:

    # GR "incorrect."
    GR "incorrecto."

# game/chapters/2_day.rpy:894
translate Spanish day2_start2_45ec4feb:

    # GR "but you are not as wise as me."
    GR "pero no eres tan sabi[letra] como yo."

# game/chapters/2_day.rpy:895
translate Spanish day2_start2_1cb37e3e:

    # GR "you are allowed to be incorrect. such is the way with mortals."
    GR "se te permite estar equivocad[letra]. así es con los mortales."

# game/chapters/2_day.rpy:899
translate Spanish day2_start2_9308afc4:

    # player "Like you?"
    player "¿Como tú?"

# game/chapters/2_day.rpy:900
translate Spanish day2_start2_1f2cdefd:

    # GR "what????????"
    GR "¿¿¿¿¿¿¿qué???????"

# game/chapters/2_day.rpy:901
translate Spanish day2_start2_c398a0e7:

    # GR "no, not like me."
    GR "no, no como yo."

# game/chapters/2_day.rpy:902
translate Spanish day2_start2_7dd61a47:

    # GR "i am terrifying. i am the embodiment of death. i am not cute, by any means of the world."
    GR "soy aterrador. soy la encarnación de la muerte. no soy lindo bajo ningún concepto del mundo."

# game/chapters/2_day.rpy:906
translate Spanish day2_start2_2178c786:

    # player "Okay cutie :)"
    player "Okey, lindura :)"

# game/chapters/2_day.rpy:907
translate Spanish day2_start2_5c7c7f55:

    # GR "..........."
    GR "..........."

# game/chapters/2_day.rpy:908
translate Spanish day2_start2_a54643d0:

    # GR "you are far too brazen, mortal."
    GR "eres demasiado audaz, mortal."

# game/chapters/2_day.rpy:909
translate Spanish day2_start2_15f91b2f:

    # GR "far, far too brazen."
    GR "demasiado, demasiado audaz."

# game/chapters/2_day.rpy:913
translate Spanish day2_start2_230f68aa:

    # player "I'm an author, actually."
    player "En realidad, me dedico a la escritura."

# game/chapters/2_day.rpy:914
translate Spanish day2_start2_ef611a10:

    # GR "you write? books?"
    GR "¿escribes? ¿libros?"

# game/chapters/2_day.rpy:917
translate Spanish day2_start2_6ad429ae:

    # player "Uh huh. I grew up writing stories."
    player "Ajá. Crecí escribiendo historias."

# game/chapters/2_day.rpy:920
translate Spanish day2_start2_4b383907:

    # player "Kinda been a lifelong dream of mine."
    player "Ha sido uno de mis sueños desde siempre."

# game/chapters/2_day.rpy:921
translate Spanish day2_start2_e866586f:

    # GR "stories, huh..."
    GR "historias, eh..."

# game/chapters/2_day.rpy:922
translate Spanish day2_start2_260f01f3:

    # GR "you seem like the type."
    GR "tienes pinta de ser de esas personas"

# game/chapters/2_day.rpy:925
translate Spanish day2_start2_178ebaff:

    # player "Is that a good thing?"
    player "¿Eso es algo bueno?"

# game/chapters/2_day.rpy:926
translate Spanish day2_start2_4d615f9f:

    # GR "i would say so."
    GR "diría que sí."

# game/chapters/2_day.rpy:927
translate Spanish day2_start2_6cada29a:

    # GR "it takes a creative and disciplined person to write."
    GR "se necesita a una persona creativa y disciplinada para escribir."

# game/chapters/2_day.rpy:928
translate Spanish day2_start2_cddc345a:

    # GR "i could not achieve that."
    GR "yo no podría lograr eso."

# game/chapters/2_day.rpy:931
translate Spanish day2_start2_f1a258e9:

    # player "Wait, is that a compliment?"
    player "Espera, ¿eso es un cumplido?"

# game/chapters/2_day.rpy:932
translate Spanish day2_start2_a4d15129_1:

    # GR "perhaps."
    GR "quizás."

# game/chapters/2_day.rpy:933
translate Spanish day2_start2_021be736:

    # GR "just because you infuriate me, does not make your achievements unimpressive."
    GR "que me saques de quicio no hace que tus logros sean poco impresionantes."

# game/chapters/2_day.rpy:936
translate Spanish day2_start2_f2d7e186:

    # player "Why do you sound so surprised?"
    player "¿Por qué suenas tan sorprendido?"

# game/chapters/2_day.rpy:937
translate Spanish day2_start2_d7d93d91:

    # GR "i didn't peg you as a writer."
    GR "no te imaginaba como alguien que escribe."

# game/chapters/2_day.rpy:938
translate Spanish day2_start2_25af6d44:

    # GR "what do you write?"
    GR "¿qué escribes?"

# game/chapters/2_day.rpy:942
translate Spanish day2_start2_d95c8e60:

    # player "Fantasy."
    player "Fantasía."

# game/chapters/2_day.rpy:944
translate Spanish day2_start2_2c633dd2:

    # player "Romance."
    player "Romance."

# game/chapters/2_day.rpy:946
translate Spanish day2_start2_0f0f1d27:

    # player "Non-fiction."
    player "No ficción."

# game/chapters/2_day.rpy:948
translate Spanish day2_start2_b23fbc5d:

    # player "Murder mysteries." id day2_start2_b23fbc5d
    player "Misterios policiales." id day2_start2_b23fbc5d

# game/chapters/2_day.rpy:949
translate Spanish day2_start2_a1f3fde8:

    # GR "huh. interesting."
    GR "huh. interesante."

# game/chapters/2_day.rpy:950
translate Spanish day2_start2_84a17c0a:

    # GR "well, color me impressed."
    GR "vaya, me dejas impresionado."

# game/chapters/2_day.rpy:954
translate Spanish day2_start2_80805ce3:

    # player "Really?"
    player "¿En serio?"

# game/chapters/2_day.rpy:955
translate Spanish day2_start2_ebc9eb7a:

    # GR "yes."
    GR "sí."

# game/chapters/2_day.rpy:956
translate Spanish day2_start2_65835367:

    # GR "writing is a difficult and taxing job."
    GR "escribir es un trabajo difícil y agotador."

# game/chapters/2_day.rpy:957
translate Spanish day2_start2_8c301770:

    # GR "it is underappreciated."
    GR "está poco valorado."

# game/chapters/2_day.rpy:958
translate Spanish day2_start2_19f1bbc5:

    # GR "so, good job."
    GR "así que, buen trabajo."

# game/chapters/2_day.rpy:962
translate Spanish day2_start2_91bf1e8d:

    # player "Oh. Well, thanks."
    player "Oh. Bueno, gracias."

# game/chapters/2_day.rpy:963
translate Spanish day2_start2_6ca0b909:

    # GR "no problem."
    GR "no hay problema."

# game/chapters/2_day.rpy:968
translate Spanish day2_start2_e3d0561a:

    # player "So..."
    player "Entonces..."

# game/chapters/2_day.rpy:971
translate Spanish day2_start2_723e23bd:

    # player "And I'm guessing you'd just tell me your job was being 'the reaper' if I asked?"
    player "Y supongo que me dirías que tu trabajo es ser 'la parca' si te lo preguntara."

# game/chapters/2_day.rpy:972
translate Spanish day2_start2_0d653f64:

    # GR "at least you finally recognize it."
    GR "al menos por fin lo reconoces."

# game/chapters/2_day.rpy:973
translate Spanish day2_start2_e5bc5106:

    # GR "that is my job, yes. my job, my hobby, and my reason for living."
    GR "ese es mi trabajo, sí. mi trabajo, mi pasatiempo y mi razón de vivir."

# game/chapters/2_day.rpy:976
translate Spanish day2_start2_aa75ffb7:

    # player "Sure..."
    player "Claro..."

# game/chapters/2_day.rpy:979
translate Spanish day2_start2_af399e61:

    # player "That's... a little sad."
    player "Eso... suena un poco triste."

# game/chapters/2_day.rpy:983
translate Spanish day2_start2_eb6cdce5:

    # player "How do you do it, then?"
    player "¿Cómo lo haces, entonces?"

# game/chapters/2_day.rpy:986
translate Spanish day2_start2_6beebc3d:

    # player "Stick your hand into their chest and pull it right out?"
    player "¿Metes la mano en el pecho y la sacas de golpe?"

# game/chapters/2_day.rpy:989
translate Spanish day2_start2_9f6d4ea1:

    # player "Stick your teeth into their neck, vampire style?"
    player "¿Les clavas los dientes en el cuello, estilo vampiro?"

# game/chapters/2_day.rpy:990
translate Spanish day2_start2_dde94ca3:

    # GR "you sure have a wild imagination."
    GR "tienes sin duda una imaginación salvaje."

# game/chapters/2_day.rpy:991
translate Spanish day2_start2_ac1e63fb:

    # GR "and that is definitely {i}not{/i} how it is done."
    GR "y eso definitivamente {i}no{/i} es como se hace."

# game/chapters/2_day.rpy:992
translate Spanish day2_start2_6c498d69:

    # GR "though, i must admit, i would make a dashing vampire."
    GR "aunque debo admitir que sería un vampiro deslumbrante."

# game/chapters/2_day.rpy:996
translate Spanish day2_start2_a18ea783:

    # player "White haired vampires are {i}in{/i} right now."
    player "Los vampiros de pelo blanco están {i}de moda{/i} ahora."

# game/chapters/2_day.rpy:997
translate Spanish day2_start2_7399350e:

    # GR "they are?"
    GR "¿lo están?"

# game/chapters/2_day.rpy:1000
translate Spanish day2_start2_5da19828:

    # player "Super in."
    player "Super de moda."

# game/chapters/2_day.rpy:1003
translate Spanish day2_start2_974ebc0d:

    # player "Honestly, if you're looking for a profession change, I'd keep it in mind."
    player "Honestamente, si buscas un cambio de profesión, yo lo tendría en cuenta."

# game/chapters/2_day.rpy:1004
translate Spanish day2_start2_dcb00a0a:

    # GR "i... will consider it. thank you. that is very thoughtful of you."
    GR "lo... consideraré. gracias. es muy considerado de tu parte."

# game/chapters/2_day.rpy:1008
translate Spanish day2_start2_b8010b4a:

    # player "Then how {b}do{/b} you do it?"
    player "Entonces, ¿cómo lo {b}haces{/b}?"

# game/chapters/2_day.rpy:1009
translate Spanish day2_start2_d7fb05d8:

    # GR "it is a very beautiful experience."
    GR "es una experiencia muy hermosa."

# game/chapters/2_day.rpy:1010
translate Spanish day2_start2_d3a44034:

    # GR "you will undergo it soon enough. i will pull your very essence from your body."
    GR "la vivirás pronto. extraeré tu misma esencia de tu cuerpo."

# game/chapters/2_day.rpy:1011
translate Spanish day2_start2_c3cb9880:

    # GR "there will be cold, and heat, and love, and hate... it will be glorious."
    GR "habrá frío, y calor, y amor, y odio... será glorioso."

# game/chapters/2_day.rpy:1015
translate Spanish day2_start2_05ede2b8:

    # player "Not really feeling it, sorry."
    player "No me convence mucho, lo siento."

# game/chapters/2_day.rpy:1016
translate Spanish day2_start2_e44dd486:

    # GR "you have little say in the matter. i will win this bet of ours, and take your soul as my medal."
    GR "tienes poco que decir al respecto. ganaré nuestra apuesta, y tomaré tu alma como mi medalla."

# game/chapters/2_day.rpy:1019
translate Spanish day2_start2_a3b39a43:

    # player "We'll see about that."
    player "Ya veremos."

# game/chapters/2_day.rpy:1022
translate Spanish day2_start2_28931f28:

    # player "How about lust?"
    player "¿Y qué hay de la lujuria?"

# game/chapters/2_day.rpy:1023
translate Spanish day2_start2_fcfd33b1:

    # GR "lust?"
    GR "¿lujuria?"

# game/chapters/2_day.rpy:1024
translate Spanish day2_start2_7af3a39f:

    # GR "well, i suppose there would also be lust, if that is your desire."
    GR "bueno, supongo que también habría lujuria, si eso es lo que deseas."

# game/chapters/2_day.rpy:1025
translate Spanish day2_start2_0a1fbc67:

    # GR "lust is a natural thing, just like death."
    GR "la lujuria es algo natural, igual que la muerte."

# game/chapters/2_day.rpy:1028
translate Spanish day2_start2_d6570f3e:

    # player "Then I suppose I'll offer myself up to you."
    player "Entonces supongo que me ofreceré a ti."

# game/chapters/2_day.rpy:1029
translate Spanish day2_start2_29f30864:

    # GR "that would save me some time. shall i make my way over there now?"
    GR "eso me ahorraría algo de tiempo. ¿debo ir hasta allí ahora?"

# game/chapters/2_day.rpy:1032
translate Spanish day2_start2_26c4a37f:

    # player "I'm waiting :D"
    player "Estoy esperando :D"

# game/chapters/2_day.rpy:1033
translate Spanish day2_start2_8329547b:

    # GR "wait, seriously?"
    GR "espera, ¿en serio?"

# game/chapters/2_day.rpy:1034
translate Spanish day2_start2_235fa7c4:

    # GR "i am on my way. don't go anywhere."
    GR "voy en camino. no te muevas."

# game/chapters/2_day.rpy:1038
translate Spanish day2_start2_531a3c65:

    # player "Just kidding >:D"
    player "Es broma >:D"

# game/chapters/2_day.rpy:1039
translate Spanish day2_start2_230dec51_2:

    # GR "...."
    GR "...."

# game/chapters/2_day.rpy:1042
translate Spanish day2_start2_040e659d:

    # player "If I gave myself up that easily, then we wouldn't get to talk anymore :("
    player "Si me entregara tan fácilmente, entonces ya no podríamos hablar más :("

# game/chapters/2_day.rpy:1043
translate Spanish day2_start2_c2a7076b:

    # GR "that is the idea!!!"
    GR "¡¡¡esa es la idea!!!"

# game/chapters/2_day.rpy:1044
translate Spanish day2_start2_2e526ca0:

    # GR "i am not here to make friends with."
    GR "no estoy aquí para hacer amigos."

# game/chapters/2_day.rpy:1048
translate Spanish day2_start2_bf92945c:

    # player "If not friend, why friend-shaped?"
    player "Si no eres un amigo, ¿por qué tienes forma de amigo?"

# game/chapters/2_day.rpy:1049
translate Spanish day2_start2_08402110:

    # GR "i am not friend shaped!"
    GR "¡no tengo forma de amigo!"

# game/chapters/2_day.rpy:1050
translate Spanish day2_start2_b8fda522:

    # GR "if i was a shape, i would be something spiky."
    GR "si fuera una forma, sería algo puntiagudo."

# game/chapters/2_day.rpy:1051
translate Spanish day2_start2_0ebe0167:

    # GR "something with sharp edges. something dangerous."
    GR "algo con bordes afilados. algo peligroso."

# game/chapters/2_day.rpy:1052
translate Spanish day2_start2_29a85b69:

    # GR "i would poke your eye out."
    GR "te sacaría un ojo."

# game/chapters/2_day.rpy:1056
translate Spanish day2_start2_c1f1dd6d:

    # player "I think you're more like a circle :)"
    player "Yo creo que eres más como un círculo :)"

# game/chapters/2_day.rpy:1059
translate Spanish day2_start2_62e6845a:

    # player "It's like the endless cycle of life and death."
    player "Es como el ciclo interminable de la vida y la muerte."

# game/chapters/2_day.rpy:1060
translate Spanish day2_start2_22c60e35:

    # GR "huh. i did not consider that."
    GR "huh. no había considerado eso."

# game/chapters/2_day.rpy:1063
translate Spanish day2_start2_6b62888f:

    # player "You're a square!"
    player "¡Eres un cuadrado!"

# game/chapters/2_day.rpy:1066
translate Spanish day2_start2_11507398:

    # player "You seem very stable and ordered."
    player "Pareces muy estable y ordenado."

# game/chapters/2_day.rpy:1067
translate Spanish day2_start2_beb2f35e:

    # GR "hmm. i suppose that is true."
    GR "hmm. supongo que eso es cierto."

# game/chapters/2_day.rpy:1071
translate Spanish day2_start2_aab0f53d:

    # player "Then how about something more than friends?"
    player "Entonces, ¿qué tal algo más que amigos?"

# game/chapters/2_day.rpy:1072
translate Spanish day2_start2_2ec1cc3d:

    # GR "best friends?"
    GR "¿mejores amigos?"

# game/chapters/2_day.rpy:1076
translate Spanish day2_start2_56bb6b40:

    # player "I mean, that would be cool too."
    player "Quiero decir, eso también estaría bien."

# game/chapters/2_day.rpy:1077
translate Spanish day2_start2_9ba9c614:

    # GR "if you give up your soul, perhaps we can be best of friends in the afterlife."
    GR "si entregas tu alma, quizá podamos ser los mejores amigos en el más allá."

# game/chapters/2_day.rpy:1078
translate Spanish day2_start2_f70a0754:

    # GR "...i am not stupid mortal. you talk of romance, of love. those are not feelings for one such as i."
    GR "...no soy estúpido, mortal. hablas de romance, de amor. esos no son sentimientos para alguien como yo."

# game/chapters/2_day.rpy:1082
translate Spanish day2_start2_2029567a:

    # player "More again."
    player "Más que eso."

# game/chapters/2_day.rpy:1083
translate Spanish day2_start2_ebf2c17d:

    # GR "you speak of love and romance, i assume."
    GR "hablas de amor y romance, supongo."

# game/chapters/2_day.rpy:1085
translate Spanish day2_start2_60585765:

    # GR "i am destined to be alone forever. i am destined to cause loneliness to all that i touch."
    GR "estoy destinado a estar solo para siempre. estoy destinado a causar soledad a todo lo que toco."

# game/chapters/2_day.rpy:1089
translate Spanish day2_start2_d5276b1a:

    # player "That seems a little sad."
    player "Eso suena un poco triste."

# game/chapters/2_day.rpy:1090
translate Spanish day2_start2_7772a27d_5:

    # GR "..."
    GR "..."

# game/chapters/2_day.rpy:1091
translate Spanish day2_start2_62137b6d:

    # GR "i cannot miss something that i've not yet had, so there is no need to pity me."
    GR "no puedo extrañar algo que aún no he tenido, así que no hay necesidad de que me tengas lástima."

# game/chapters/2_day.rpy:1092
translate Spanish day2_start2_fad395a9:

    # GR "perhaps i will love eventually, but that would mean disaster for the other party."
    GR "quizás ame alguna vez, pero eso significaría desastre para la otra parte."

# game/chapters/2_day.rpy:1093
translate Spanish day2_start2_43aef4a6:

    # GR "it is better that i am left alone."
    GR "es mejor que me quede solo."

# game/chapters/2_day.rpy:1096
translate Spanish day2_start2_1c780ed6:

    # player "Maybe it'll change one day."
    player "Quizá cambie algún día."

# game/chapters/2_day.rpy:1101
translate Spanish day2_start2_d2523c5b:

    # player "I'd be happy to offer up my neck for you."
    player "Yo estaría feliz de ofrecerte mi cuello."

# game/chapters/2_day.rpy:1104
translate Spanish day2_start2_4570d934:

    # player "You would definitely make a good vampire."
    player "Definitivamente serías un buen vampiro."

# game/chapters/2_day.rpy:1106
translate Spanish day2_start2_dc99f2b2:

    # GR "i... do not understand humans' fascination with those creatures." id day2_start2_dc99f2b2
    GR "yo... no entiendo la fascinación de los humanos con esas criaturas." id day2_start2_dc99f2b2

# game/chapters/2_day.rpy:1111
translate Spanish day2_start2_15a133ee:

    # player "I mean, it's pretty simple."
    player "Quiero decir, es bastante simple."

# game/chapters/2_day.rpy:1114
translate Spanish day2_start2_897742b9:

    # player "Vampires are kinda hot."
    player "Los vampiros son bastante sexys."

# game/chapters/2_day.rpy:1115
translate Spanish day2_start2_e1d77883:

    # GR "then you believe that i, too, am 'kinda hot'?"
    GR "¿entonces crees que yo también soy 'bastante sexy'?"

# game/chapters/2_day.rpy:1116
translate Spanish day2_start2_4b07b82c:

    # GR "surely if i would make a good vampire, then i must be."
    GR "seguramente si sería un buen vampiro, entonces debo serlo."

# game/chapters/2_day.rpy:1120
translate Spanish day2_start2_9386d6aa:

    # player "Do you even need me to tell you?"
    player "¿De verdad necesitas que te lo diga?"

# game/chapters/2_day.rpy:1122
translate Spanish day2_start2_dfdffe0c:

    # GR "no, but i always enjoy ego boosts."
    GR "no, pero siempre disfruto cuando me alimentan el ego."

# game/chapters/2_day.rpy:1126
translate Spanish day2_start2_8e97181b:

    # player "Completely unsurprising."
    player "Completamente predecible."

# game/chapters/2_day.rpy:1130
translate Spanish day2_start2_b3a4ce95:

    # player "If you were a vampire, where would you bite me?"
    player "Si fueras un vampiro, ¿dónde me morderías?"

# game/chapters/2_day.rpy:1131
translate Spanish day2_start2_8152e312:

    # GR "uh..."
    GR "eh..."

# game/chapters/2_day.rpy:1132
translate Spanish day2_start2_6f4891a7:

    # GR "don't vampires go for the neck?"
    GR "¿no se supone que los vampiros muerden en el cuello?"

# game/chapters/2_day.rpy:1136
translate Spanish day2_start2_6bb02e6c:

    # player "Don't be so vanilla."
    player "No seas tan aburrido."

# game/chapters/2_day.rpy:1139
translate Spanish day2_start2_cd946410:

    # player "Fine, I'll pick for you."
    player "Bien, lo elegiré por ti."

# game/chapters/2_day.rpy:1142
translate Spanish day2_start2_73325cc9:

    # player "How about..."
    player "¿Qué tal...?"

# game/chapters/2_day.rpy:1145
translate Spanish day2_start2_e4fdbba5:

    # player "My collarbone?"
    player "¿Mi clavícula?"

# game/chapters/2_day.rpy:1147
translate Spanish day2_start2_cd647c97:

    # player "My wrist?"
    player "¿Mi muñeca?"

# game/chapters/2_day.rpy:1149
translate Spanish day2_start2_936e9849:

    # player "My thigh?"
    player "¿Mi muslo?"

# game/chapters/2_day.rpy:1150
translate Spanish day2_start2_22b97229:

    # GR "u... uh..."
    GR "e... eh..."

# game/chapters/2_day.rpy:1151
translate Spanish day2_start2_a700cf85:

    # GR "that's a little..."
    GR "eso es un poco..."

# game/chapters/2_day.rpy:1155
translate Spanish day2_start2_30c3c9b6:

    # player "Close and personal?"
    player "¿Íntimo y personal?"

# game/chapters/2_day.rpy:1156
translate Spanish day2_start2_ebc9eb7a_1:

    # GR "yes."
    GR "sí."

# game/chapters/2_day.rpy:1159
translate Spanish day2_start2_5ddddebb:

    # player "If you're a vampire, that's okay."
    player "Si eres un vampiro, está bien."

# game/chapters/2_day.rpy:1163
translate Spanish day2_start2_3d605eef:

    # player "Own your sexiness."
    player "Asume tu sensualidad."

# game/chapters/2_day.rpy:1164
translate Spanish day2_start2_7772a27d_6:

    # GR "..."
    GR "..."

# game/chapters/2_day.rpy:1165
translate Spanish day2_start2_fdebf69b:

    # GR "if i... if i had to pick... um..."
    GR "si yo... si tuviera que elegir... um..."

# game/chapters/2_day.rpy:1166
translate Spanish day2_start2_1bac7b43:

    # GR "maybe... the collarbone..."
    GR "quizá... la clavícula..."

# game/chapters/2_day.rpy:1169
translate Spanish day2_start2_2fd3993a:

    # player "Oho."
    player "Oho."

# game/chapters/2_day.rpy:1172
translate Spanish day2_start2_68541cb6:

    # player "If I was a vampire, I would bite you all over :D"
    player "Si yo fuera un vampiro, te mordería por todas partes :D"

# game/chapters/2_day.rpy:1176
translate Spanish day2_start2_c60bed95:

    # player "I'd leave little love marks everywhere."
    player "Te dejaría pequeñas marcas de amor por todos lados."

# game/chapters/2_day.rpy:1177
translate Spanish day2_start2_20e41447_1:

    # GR "i... i..."
    GR "yo... yo..."

# game/chapters/2_day.rpy:1180
translate Spanish day2_start2_684f48f2:

    # player "I mean, if that was okay with you."
    player "Quiero decir, si eso te pareciera bien."

# game/chapters/2_day.rpy:1181
translate Spanish day2_start2_230dec51_3:

    # GR "...."
    GR "...."

# game/chapters/2_day.rpy:1185
translate Spanish day2_start2_533a9717:

    # player "No?"
    player "¿No?"

# game/chapters/2_day.rpy:1186
translate Spanish day2_start2_80c992ed:

    # GR "i... i didn't say no..."
    GR "yo...  yo no dije que no... "

# game/chapters/2_day.rpy:1187
translate Spanish day2_start2_0b16bee0_1:

    # GR "ahem."
    GR "ejem."

# game/chapters/2_day.rpy:1188
translate Spanish day2_start2_eebdc640:

    # GR "weren't we talking about souls? let's go back to talking about souls!" id day2_start2_eebdc640
    GR "¿no estábamos hablando de almas? ¡volvamos a hablar de almas!" id day2_start2_eebdc640

# game/chapters/2_day.rpy:1192
translate Spanish day2_start2_426a43ac:

    # player "Anyway..."
    player "De todos modos..."

# game/chapters/2_day.rpy:1195
translate Spanish day2_start2_82336917:

    # player "Back to the matter at hand."
    player "Volvamos al asunto en cuestión."

# game/chapters/2_day.rpy:1199
translate Spanish day2_start2_255d700d:

    # player "Do you have a daily quota you have to fill, soul wise?"
    player "¿Tienes una cuota diaria que cumplir, de almas?"

# game/chapters/2_day.rpy:1203
translate Spanish day2_start2_936374db:

    # player "What if you don't get enough one day?"
    player "¿Qué pasa si un día no consigues suficientes?"

# game/chapters/2_day.rpy:1206
translate Spanish day2_start2_fae7f31a:

    # player "Pick a random human and they'll do?"
    player "¿Eliges a un humano al azar y ya?"

# game/chapters/2_day.rpy:1207
translate Spanish day2_start2_77d2508e:

    # GR "what????"
    GR "¿¿¿¿qué????"

# game/chapters/2_day.rpy:1208
translate Spanish day2_start2_bdf00aae:

    # GR "no! it's predetermined, obviously."
    GR "¡no! está predeterminado, obviamente."

# game/chapters/2_day.rpy:1209
translate Spanish day2_start2_7dcad8af:

    # GR "i have no hand in the matter. i am simply assigned jobs, and i complete them."
    GR "no tengo nada que ver con eso. simplemente me asignan trabajos, y los cumplo."

# game/chapters/2_day.rpy:1210
translate Spanish day2_start2_688bb201:

    # GR "usually, anyway. but here we are."
    GR "al menos, normalmente. pero aquí estamos."

# game/chapters/2_day.rpy:1213
translate Spanish day2_start2_d9969e6a:

    # player "Aww... so you didn't pick me out?"
    player "Aww... ¿entonces no me elegiste a mí?"

# game/chapters/2_day.rpy:1216
translate Spanish day2_start2_479239e2:

    # player "That's kinda sad :/"
    player "Eso es un poco triste :/"

# game/chapters/2_day.rpy:1219
translate Spanish day2_start2_1e98b2a9:

    # player "And here I thought I was special."
    player "Y yo que pensaba que era especial."

# game/chapters/2_day.rpy:1221
translate Spanish day2_start2_a8fd8be5:

    # GR "it's a job, i take it seriously."
    GR "es un trabajo, me lo tomo en serio."

# game/chapters/2_day.rpy:1222
translate Spanish day2_start2_7a71f683:

    # GR "i'm not going to go around taking souls at random."
    GR "no voy a andar tomando almas al azar."

# game/chapters/2_day.rpy:1226
translate Spanish day2_start2_7c9d8c58:

    # player "Why not? Would that not be more exciting for you, Grim?"
    player "¿Por qué no? ¿No sería más emocionante para ti, Parca?"

# game/chapters/2_day.rpy:1227
translate Spanish day2_start2_180d7fa5:

    # GR "you have a bad work ethic. is this a thing all mortals have?"
    GR "tienes una ética de trabajo pésima. ¿es eso algo de todos los mortales?"

# game/chapters/2_day.rpy:1230
translate Spanish day2_start2_9da75ca6:

    # player "Okay, I can understand why, but..."
    player "Okey, lo entiendo, pero..."

# game/chapters/2_day.rpy:1233
translate Spanish day2_start2_0acfe734:

    # player "If I was the grim reaper..."
    player "Si yo fuera la parca..."

# game/chapters/2_day.rpy:1236
translate Spanish day2_start2_e152c687:

    # player "I'd take all the souls. Mwahahahaha."
    player "Me quedaría con todas las almas. Muajajajaja."

# game/chapters/2_day.rpy:1239
translate Spanish day2_start2_e72b74d5:

    # player "I'd let everyone live extra long lives."
    player "Dejaría vivir a todos vidas extra largas."

# game/chapters/2_day.rpy:1242
translate Spanish day2_start2_407c6361:

    # player "I'd get a promotion and be your boss :)"
    player "Conseguiría un ascenso y sería tu jefe :)"

# game/chapters/2_day.rpy:1243
translate Spanish day2_start2_d95b13e1:

    # GR "hah!"
    GR "¡hah!"

# game/chapters/2_day.rpy:1246
translate Spanish day2_start2_0045e35b:

    # player "Bet you'd like that. Being bossed around by me :)"
    player "Apuesto a que te gustaría eso. Que yo te mandara :)"

# game/chapters/2_day.rpy:1247
translate Spanish day2_start2_99529d4b:

    # GR "stop it with that smiley face."
    GR "deja ya esa carita sonriente."

# game/chapters/2_day.rpy:1248
translate Spanish day2_start2_f00d589c:

    # GR "it taunts me."
    GR "me provoca."

# game/chapters/2_day.rpy:1251
translate Spanish day2_start2_951765af:

    # player "What do you mean? :)"
    player "¿Qué quieres decir? :)"

# game/chapters/2_day.rpy:1254
translate Spanish day2_start2_0d76a7bf:

    # player "Are you saying you wouldn't like it? :)"
    player "¿Estás diciendo que no te gustaría? :)"

# game/chapters/2_day.rpy:1255
translate Spanish day2_start2_3e0540f4:

    # GR "whether i would like it or not is none of your business!"
    GR "¡lo que me gustaría o no no es asunto tuyo!"

# game/chapters/2_day.rpy:1258
translate Spanish day2_start2_aee3d6a0:

    # player "Ooooh. That's basically a confession."
    player "Ooooh. Eso básicamente es una confesión."

# game/chapters/2_day.rpy:1260
translate Spanish day2_start2_08d5afd6:

    # GR "this is why you would never be a good grim reaper."
    GR "por eso nunca serías una buena parca."

# game/chapters/2_day.rpy:1263
translate Spanish day2_start2_db16241c:

    # player "'A' grim reaper seems to imply there are multiple."
    player "Decir 'una' parca implica que hay varias."

# game/chapters/2_day.rpy:1264
translate Spanish day2_start2_6dc52141:

    # GR "and you're speaking to the very best of them."
    GR "y estás hablando con la mejor de todas ellas."

# game/chapters/2_day.rpy:1265
translate Spanish day2_start2_61175ef8:

    # GR "obviously i do not work alone. i cannot be everywhere at once."
    GR "obviamente no trabajo solo. no puedo estar en todas partes a la vez."

# game/chapters/2_day.rpy:1266
translate Spanish day2_start2_519adb67:

    # GR "do you not know how many people die a day?"
    GR "¿no sabes cuántas personas mueren al día?"

# game/chapters/2_day.rpy:1267
translate Spanish day2_start2_b91179d4:

    # GR "150,000+. i am talented, but not that talented."
    GR "150,000+. soy talentoso, pero no tanto."

# game/chapters/2_day.rpy:1270
translate Spanish day2_start2_4f594426:

    # player "Hmm... but surely the very best..."
    player "Hmm... pero sin duda el mejor..."

# game/chapters/2_day.rpy:1273
translate Spanish day2_start2_ddc7c268:

    # player "Would have had my soul by now..."
    player "Ya tendría mi alma a estas alturas..."

# game/chapters/2_day.rpy:1274
translate Spanish day2_start2_7772a27d_7:

    # GR "..."
    GR "..."

# game/chapters/2_day.rpy:1275
translate Spanish day2_start2_31072bb2:

    # GR "you are a difficult one."
    GR "eres difícil."

# game/chapters/2_day.rpy:1276
translate Spanish day2_start2_57508ada:

    # GR "you wouldn't understand my struggles."
    GR "no entenderías por todo lo que tengo que pasar"

# game/chapters/2_day.rpy:1280
translate Spanish day2_start2_4d68bcc6:

    # player "Why don't you tell me about them, then?"
    player "¿Por qué no me cuentas cuáles son, entonces?"

# game/chapters/2_day.rpy:1283
translate Spanish day2_start2_8b47d1e2:

    # player "Oh! I'm a good listener. Lay them on me."
    player "¡Oh! Sé escuchar. ¡Cuéntamelo todo!"

# game/chapters/2_day.rpy:1286
translate Spanish day2_start2_95ea48e9:

    # player "I struggle plenty in life. You can tell me."
    player "Yo también tengo mis problemas. Puedes contármelos."

# game/chapters/2_day.rpy:1288
translate Spanish day2_start2_146289ec:

    # GR "YOU ARE THEM."
    GR "TÚ ERES ESOS PROBLEMAS."

# game/chapters/2_day.rpy:1291
translate Spanish day2_start2_efea6f29:

    # player "Woah, all caps."
    player "Uy, todo en mayúsculas."

# game/chapters/2_day.rpy:1292
translate Spanish day2_start2_3642e066:

    # GR "that is how dire the situation is."
    GR "así de grave es la situación."

# game/chapters/2_day.rpy:1293
translate Spanish day2_start2_7326ede1:

    # GR "and yet, you're sitting there, perfectly content to keep living."
    GR "y sin embargo, ahí estás, perfectamente feliz de seguir viviendo."

# game/chapters/2_day.rpy:1294
translate Spanish day2_start2_42b33503:

    # GR "despite that not working for me."
    GR "a pesar de que eso no me funciona a mí."

# game/chapters/2_day.rpy:1297
translate Spanish day2_start2_c2caa49c:

    # player "My bad, I didn't realize it would inconvenience you."
    player "Mi error, no me di cuenta de que te incomodaba."

# game/chapters/2_day.rpy:1300
translate Spanish day2_start2_87284646:

    # player "I {i}really{/i} am so very sorry, Mr Grim Reaper."
    player "Lo {i}siento{/i} muchísimo, Sr. Parca."

# game/chapters/2_day.rpy:1303
translate Spanish day2_start2_420bb16c:

    # player "Honestly, I do feel a little guilty. Sorry."
    player "En serio, me siento un poco culpable. Perdón."

# game/chapters/2_day.rpy:1305
translate Spanish day2_start2_a7dd6ad1:

    # GR "so you'll hand it over?"
    GR "¿así que me la entregarás?"

# game/chapters/2_day.rpy:1308
translate Spanish day2_start2_93666768:

    # player "Nope."
    player "Nop."

# game/chapters/2_day.rpy:1311
translate Spanish day2_start2_29113672_1:

    # player "No."
    player "No."

# game/chapters/2_day.rpy:1314
translate Spanish day2_start2_4b028405:

    # player "Absolutely not."
    player "Absolutamente no."

# game/chapters/2_day.rpy:1316
translate Spanish day2_start2_6377f35c:

    # GR "a thousand curses upon you."
    GR "mil maldiciones caigan sobre ti."

# game/chapters/2_day.rpy:1319
translate Spanish day2_start2_45c4281d:

    # player "Only a thousand?"
    player "¿Solo mil?"

# game/chapters/2_day.rpy:1322
translate Spanish day2_start2_6adf97fd:

    # player "Weak."
    player "Débil."

# game/chapters/2_day.rpy:1323
translate Spanish day2_start2_b3a0d942:

    # GR "nothing about me is weak."
    GR "nada en mí es débil."

# game/chapters/2_day.rpy:1326
translate Spanish day2_start2_5e614bd5:

    # player "Nothing?"
    player "¿Nada?"

# game/chapters/2_day.rpy:1327
translate Spanish day2_start2_e37281f0:

    # GR "nothing."
    GR "nada."

# game/chapters/2_day.rpy:1331
translate Spanish day2_start2_0747fe5f:

    # player "What about your love for me? ;)"
    player "¿Y tu amor por mí? ;)"

# game/chapters/2_day.rpy:1335
translate Spanish day2_start2_e5e631e3:

    # player "What about your want for me ;)"
    player "¿Y tu deseo por mí? ;)"

# game/chapters/2_day.rpy:1339
translate Spanish day2_start2_1a97ecc5:

    # player "You're saying that's not weak?"
    player "¿Dices que eso no es débil?"

# game/chapters/2_day.rpy:1342
translate Spanish day2_start2_7772a27d_8:

    # GR "..."
    GR "..."

# game/chapters/2_day.rpy:1343
translate Spanish day2_start2_b1ad7a44:

    # GR "mortal, you walk a fine line."
    GR "mortal, estás caminando sobre una cuerda floja."

# game/chapters/2_day.rpy:1344
translate Spanish day2_start2_56bcd79d:

    # GR "a very fine line."
    GR "una cuerda floja muy, muy delgada."

# game/chapters/2_day.rpy:1347
translate Spanish day2_start2_d1595347:

    # player "It's okay to admit you were wrong, you know."
    player "Está bien admitir que estabas equivocado, ¿sabes?"

# game/chapters/2_day.rpy:1348
translate Spanish day2_start2_7c85785f:

    # GR "i am never wrong!!!!!!!"
    GR "¡¡¡¡¡¡¡yo nunca me equivoco!!!!!!!"

# game/chapters/2_day.rpy:1351
translate Spanish day2_start2_6546d5ef:

    # player "Then your love for me must be..."
    player "Entonces tu amor por mí debe ser..."

# game/chapters/2_day.rpy:1354
translate Spanish day2_start2_f313f073:

    # player "Then your want for me must be..."
    player "Entonces tu deseo por mí debe ser..."

# game/chapters/2_day.rpy:1356
translate Spanish day2_start2_f4a35c00:

    # GR "that's enough of that."
    GR "basta ya."

# game/chapters/2_day.rpy:1357
translate Spanish day2_start2_350cff80:

    # GR "i'm already sick and tired of entertaining you."
    GR "ya estoy harto de entretenerte."

# game/chapters/2_day.rpy:1358
translate Spanish day2_start2_d75b422f:

    # GR "{font=gui/NotoSans-Light.ttf}({/font} {font=gui/NotoSansJP-VariableFont_wght.ttf}- 。－；{/font}{font=gui/NotoSans-Light.ttf}){/font}"
    GR "{font=gui/NotoSans-Light.ttf}({/font} {font=gui/NotoSansJP-VariableFont_wght.ttf}- 。－；{/font}{font=gui/NotoSans-Light.ttf}){/font}"

# game/chapters/2_day.rpy:1359
translate Spanish day2_start2_942b3b1e:

    # GR "got nobody else to talk to, huh?"
    GR "¿no tienes a nadie más con quién hablar, eh?"

# game/chapters/2_day.rpy:1364
translate Spanish day2_start2_03775ec8_5:

    # player "..."
    player "..."

# game/chapters/2_day.rpy:1367
translate Spanish day2_start2_2a99116e:

    # player "Of course I do!"
    player "¡Por supuesto que sí!"

# game/chapters/2_day.rpy:1368
translate Spanish day2_start2_3afa89c6:

    # GR "well, off you go then."
    GR "bueno, entonces vete."

# game/chapters/2_day.rpy:1369
translate Spanish day2_start2_db195a62:

    # GR "be a bother to them instead of me {font=gui/NotoSans-Light.ttf}({/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}づ￣ ³￣{/font}{font=gui/NotoSans-Light.ttf}){/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}づ{/font}"
    GR "molesta a ellos en vez de a mí {font=gui/NotoSans-Light.ttf}({/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}づ￣ ³￣{/font}{font=gui/NotoSans-Light.ttf}){/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}づ{/font}"

# game/chapters/2_day.rpy:1372
translate Spanish day2_start2_30daaab8:

    # player "Uh... well..."
    player "Uh... bueno..."

# game/chapters/2_day.rpy:1375
translate Spanish day2_start2_0ddef87b:

    # player "Why would I do that when it's so fun to bully you instead?"
    player "¿Por qué haría eso si es tan divertido molestarte a ti en su lugar?"

# game/chapters/2_day.rpy:1376
translate Spanish day2_start2_17622630:

    # GR "im bullying you, not the other way around."
    GR "yo soy quien te está molestando, no al revés."

# game/chapters/2_day.rpy:1379
translate Spanish day2_start2_d7330fd0:

    # player "Are you sure?"
    player "¿Estás seguro?"

# game/chapters/2_day.rpy:1380
translate Spanish day2_start2_d13723af:

    # GR "positive."
    GR "completamente."

# game/chapters/2_day.rpy:1381
translate Spanish day2_start2_306ebc14:

    # GR "anyway, now that i have your undivided attention... {font=gui/NotoSansJP-VariableFont_wght.ttf}（{/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}≧▽≦{/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}）{/font}"
    GR "en fin, ahora que tengo tu atención total... {font=gui/NotoSansJP-VariableFont_wght.ttf}（{/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}≧▽≦{/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}）{/font}"

# game/chapters/2_day.rpy:1384
translate Spanish day2_start2_ea3d0909:

    # player "Does that matter?!"
    player "¡¿Eso importa?!"

# game/chapters/2_day.rpy:1385
translate Spanish day2_start2_31c86270:

    # GR "i suppose not..."
    GR "supongo que no..."

# game/chapters/2_day.rpy:1386
translate Spanish day2_start2_828a8d6d:

    # GR "i don't mind holding all of your attention."
    GR "no me molesta tener toda tu atención."

# game/chapters/2_day.rpy:1387
translate Spanish day2_start2_960ac225:

    # GR "perhaps i'll charm you with my... well, my charm, and you will hand over what i desire."
    GR "quizá te encante con mi... bueno, mi encanto, y me entregues lo que deseo."

# game/chapters/2_day.rpy:1388
translate Spanish day2_start2_7aadd0ea:

    # GR "anyway, since i have your full attention now... {font=gui/NotoSansJP-VariableFont_wght.ttf}（{/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}≧▽≦{/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}）{/font}"
    GR "en fin, ya que tengo toda tu atención ahora... {font=gui/NotoSansJP-VariableFont_wght.ttf}（{/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}≧▽≦{/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}）{/font}"

# game/chapters/2_day.rpy:1391
translate Spanish day2_start2_a60ba8a9:

    # player "To be honest, I like talking to you."
    player "A decir verdad, me gusta hablar contigo."

# game/chapters/2_day.rpy:1394
translate Spanish day2_start2_09eb21c7:

    # player "It's hilarious."
    player "Es muy gracioso."

# game/chapters/2_day.rpy:1396
translate Spanish day2_start2_3132e039:

    # player "You're surprisingly fun."
    player "Eres sorprendentemente divertido."

# game/chapters/2_day.rpy:1398
translate Spanish day2_start2_0003a6e0:

    # player "Occasionally you're sweet." id day2_start2_0003a6e0
    player "A veces eres dulce." id day2_start2_0003a6e0

# game/chapters/2_day.rpy:1400
translate Spanish day2_start2_e0c59818:

    # GR "oh???"
    GR "¿¿¿oh???"

# game/chapters/2_day.rpy:1401
translate Spanish day2_start2_2fddecc2:

    # GR "falling for me already?"
    GR "¿ya te estás enamorando de mí?"

# game/chapters/2_day.rpy:1402
translate Spanish day2_start2_0a14f34e:

    # GR "i can understand that. i would fall for myself too."
    GR "puedo entenderlo. yo también me enamoraría de mí."

# game/chapters/2_day.rpy:1406
translate Spanish day2_start2_373810f5:

    # player "I think you fell for yourself a long time ago, Grim."
    player "Creo que tú te enamoraste de ti hace mucho tiempo, Parca."

# game/chapters/2_day.rpy:1407
translate Spanish day2_start2_19ca6c42:

    # GR "maybe."
    GR "quizá."

# game/chapters/2_day.rpy:1408
translate Spanish day2_start2_01cf7128:

    # GR "whenever i look in the mirror, my heart sings {font=gui/NotoSansJP-VariableFont_wght.ttf}ヾ{/font}{font=gui/NotoSans-Light.ttf}( ˃ᴗ˂ ){/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}ツ • *{/font}{font=gui/Kelvinch-Roman.otf}✰{/font}"
    GR "cada vez que me miro al espejo, mi corazón canta {font=gui/NotoSansJP-VariableFont_wght.ttf}ヾ{/font}{font=gui/NotoSans-Light.ttf}( ˃ᴗ˂ ){/font}{font=gui/NotoSansJP-VariableFont_wght.ttf}ツ • *{/font}{font=gui/Kelvinch-Roman.otf}✰{/font}"

# game/chapters/2_day.rpy:1409
translate Spanish day2_start2_aeb540eb:

    # GR "anyway, answer this immediately."
    GR "en fin, responde esto de inmediato."

# game/chapters/2_day.rpy:1438
translate Spanish call1_day2_00de503c:

    # GRC "This is mu-"
    GRC "Esto es mu-"

# game/chapters/2_day.rpy:1446
translate Spanish call1_day2_88990002:

    # GRC "...?"
    GRC "...?"

# game/chapters/2_day.rpy:1455
translate Spanish call1_day2_68b4f3eb:

    # GRC "This should be hilarious, I'm sure."
    GRC "Esto va a ser graciosísimo, estoy seguro."

# game/chapters/2_day.rpy:1472
translate Spanish call1_day2_e032d7af:

    # GRC "They are a mortal custom, no?"
    GRC "Son una costumbre mortal, ¿no?"

# game/chapters/2_day.rpy:1501
translate Spanish call1_day2_ad5fb9e7:

    # GRC "What?!"
    GRC "¡¿Qué?!"

# game/chapters/2_day.rpy:1502
translate Spanish call1_day2_00a2a788:

    # GRC "They are not!"
    GRC "¡No lo son!"

# game/chapters/2_day.rpy:1507
translate Spanish call1_day2_0e1a58c6:

    # GRC "According to the internet, emojis are frequently used in text chats!"
    GRC "¡Según internet, los emojis se usan con frecuencia en los chats!"

# game/chapters/2_day.rpy:1509
translate Spanish call1_day2_c69c91dd:

    # GRC "Someone on Yihoo Answers specifically said so!"
    GRC "¡Alguien en Yihoo Answers lo dijo específicamente!"

# game/chapters/2_day.rpy:1523
translate Spanish call1_day2_e77c9d9c:

    # GRC "Damn it..."
    GRC "Maldita sea..."

# game/chapters/2_day.rpy:1544
translate Spanish call1_day2_a0a74710:

    # GRC "I... does it even matter?"
    GRC "Yo... ¿en verdad importa?"

# game/chapters/2_day.rpy:1546
translate Spanish call1_day2_6a883955:

    # GRC "I shall refrain from using them further..."
    GRC "Me abstendré de usarlos más..."

# game/chapters/2_day.rpy:1553
translate Spanish call1_day2_b3c0e777:

    # GRC "Ugh... I wish I'd never called you."
    GRC "Ugh... Ojalá nunca te hubiera llamado."

# game/chapters/2_day.rpy:1564
translate Spanish call1_day2_6a4db002:

    # GRC "Nope. Not really."
    GRC "No. Para nada."

# game/chapters/2_day.rpy:1569
translate Spanish call1_day2_990cc387:

    # GRC "Heh."
    GRC "Je."

# game/chapters/2_day.rpy:1570
translate Spanish call1_day2_d5e71312:

    # GRC "I just wanted to see how quickly you'd answer."
    GRC "Solo quería ver qué tan rápido respondías."

# game/chapters/2_day.rpy:1574
translate Spanish call1_day2_255c8710:

    # GRC "I believe this is a new record."
    GRC "Creo que este es un nuevo récord."

# game/chapters/2_day.rpy:1579
translate Spanish call1_day2_6fbe03f4:

    # GRC "No."
    GRC "No."

# game/chapters/2_day.rpy:1585
translate Spanish call1_day2_737c7d23:

    # GRC "Of course you will."
    GRC "Por supuesto que sí."

# game/chapters/2_day.rpy:1587
translate Spanish call1_day2_b497a228:

    # GRC "You {i}are{/i} drawn to my charm, after all."
    GRC "{i}Sí{/i} te atrae mi encanto, después de todo."

# game/chapters/2_day.rpy:1595
translate Spanish call1_day2_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:1599
translate Spanish call1_day2_95e590f7:

    # GRC "Well."
    GRC "Bueno."

# game/chapters/2_day.rpy:1600
translate Spanish call1_day2_d167f919:

    # GRC "First thing first."
    GRC "Primero que nada."

# game/chapters/2_day.rpy:1602
translate Spanish call1_day2_11256f1d:

    # GRC "Self confidence is... as a mortal might say, hot. There is no point in arguing with me there, because I am correct, as per usual."
    GRC "La autoconfianza es... como diría un mortal, 'sexy'. No tiene sentido discutir conmigo sobre eso, porque tengo razón, como de costumbre."

# game/chapters/2_day.rpy:1604
translate Spanish call1_day2_2cc7ee5c:

    # GRC "Secondly... you keep saying Grim this, Grim that. My name is not Grim."
    GRC "En segundo lugar... sigues diciendo Parca esto, Parca aquello. Mi nombre no es Parca."

# game/chapters/2_day.rpy:1605
translate Spanish call1_day2_3eafa3e4:

    # GRC "Why would my name be Grim? Completely and utterly foolish."
    GRC "¿Por qué mi nombre sería Parca? Total y absolutamente ridículo."

# game/chapters/2_day.rpy:1615
translate Spanish call1_day2_e9df3496:

    # GRC "I'm sure you'd love to know, wouldn't you?"
    GRC "Estoy seguro de que te encantaría saberlo, ¿no?"

# game/chapters/2_day.rpy:1616
translate Spanish call1_day2_b247d421:

    # GRC "How you must desire my name to fall from your lips."
    GRC "Cuánto debes desear que mi nombre salga de tus labios."

# game/chapters/2_day.rpy:1626
translate Spanish call1_day2_3d95d4cb:

    # GRC "Hmph. If you say so."
    GRC "Hmph. Si tú lo dices."

# game/chapters/2_day.rpy:1630
translate Spanish call1_day2_d8bd562e:

    # GRC "Listen here."
    GRC "Escucha bien."

# game/chapters/2_day.rpy:1632
translate Spanish call1_day2_2d42c023:

    # GRC "My name is not for mortal ears. It is classified on all levels."
    GRC "Mi nombre no es para oídos mortales. Está clasificado a todos los niveles."

# game/chapters/2_day.rpy:1652
translate Spanish call1_day2_fb1e72fd:

    # GRC "I do."
    GRC "Sí, tengo."

# game/chapters/2_day.rpy:1656
translate Spanish call1_day2_23df40a1:

    # GRC "The reasoning for that is..."
    GRC "La razón de eso es..."

# game/chapters/2_day.rpy:1657
translate Spanish call1_day2_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:1659
translate Spanish call1_day2_5cbc14e1:

    # GRC "Classified."
    GRC "Clasificada."

# game/chapters/2_day.rpy:1684
translate Spanish call1_day2_c1230300:

    # GRC "Life is unfair. The only fairness is in death."
    GRC "La vida es injusta. La única justicia está en la muerte."

# game/chapters/2_day.rpy:1685
translate Spanish call1_day2_20053cf6:

    # GRC "Anyway, why wouldn't I know it? It is quite literally my job."
    GRC "En fin, ¿por qué no lo sabría? Es, literalmente, mi trabajo."

# game/chapters/2_day.rpy:1692
translate Spanish call1_day2_ccb97071:

    # GRC "If that's what you want to believe, be my guest."
    GRC "Si eso es lo que quieres creer, adelante."

# game/chapters/2_day.rpy:1708
translate Spanish call1_day2_3360a5d8:

    # GRC "I am a reaper. Not a ghost."
    GRC "Soy una Parca. No un fantasma."

# game/chapters/2_day.rpy:1709
translate Spanish call1_day2_94357fde:

    # GRC "There is a very big difference, not that I would expect you to understand the intricacies."
    GRC "Hay una gran diferencia, no es que espere que entiendas las sutilezas."

# game/chapters/2_day.rpy:1713
translate Spanish call1_day2_ba8275c4:

    # GRC "It is not. My hair is well taken care of, and not at all dead."
    GRC "No lo es. Mi cabello está bien cuidado, y para nada muerto."

# game/chapters/2_day.rpy:1717
translate Spanish call1_day2_b710bd3f:

    # GRC "Indeed it is."
    GRC "Así es, efectivamente."

# game/chapters/2_day.rpy:1724
translate Spanish call1_day2_4aa86442:

    # GRC "What the..."
    GRC "Pero qué..."

# game/chapters/2_day.rpy:1725
translate Spanish call1_day2_c41b290b:

    # GRC "Where does the lamb part come into it...?"
    GRC "¿Dónde entra la parte del cordero en todo esto...?"

# game/chapters/2_day.rpy:1729
translate Spanish call1_day2_b3f216f8:

    # GRC "If anything, I am more like a tiger than a {i}lamb{/i}."
    GRC "Si acaso, soy más como un tigre que como un {i}cordero{/i}."

# game/chapters/2_day.rpy:1733
translate Spanish call1_day2_3912c32b:

    # GRC "I am absolutely not asking you to do that."
    GRC "Definitivamente no te estoy pidiendo que hagas eso."

# game/chapters/2_day.rpy:1737
translate Spanish call1_day2_0269a621:

    # GRC "No!"
    GRC "¡No!"

# game/chapters/2_day.rpy:1741
translate Spanish call1_day2_5e09335b:

    # GRC "What the... that's something you would call a dog!"
    GRC "¿Qué...? ¡Eso es algo que le dirías a un perro!"

# game/chapters/2_day.rpy:1745
translate Spanish call1_day2_1f33184c:

    # GRC "No. You will not call me Snowball."
    GRC "No. No me vas a llamar Bola de Nieve."

# game/chapters/2_day.rpy:1754
translate Spanish call1_day2_ebe113d1:

    # GRC "...I... no. Just no."
    GRC "...Yo... no. Simplemente no."

# game/chapters/2_day.rpy:1758
translate Spanish call1_day2_4f89c80d:

    # GRC "...No."
    GRC "...No."

# game/chapters/2_day.rpy:1765
translate Spanish call1_day2_6eed491a:

    # GRC "What? No."
    GRC "¿Qué? No."

# game/chapters/2_day.rpy:1769
translate Spanish call1_day2_4ca4b0d6:

    # GRC "Ugh. No."
    GRC "Uf. No."

# game/chapters/2_day.rpy:1773
translate Spanish call1_day2_b42b049c:

    # GRC "What does that even mean?"
    GRC "¿Qué se supone que significa eso?"

# game/chapters/2_day.rpy:1776
translate Spanish call1_day2_407f09cb:

    # GRC "Who? What? If you have nothing good to say, then say nothing at all."
    GRC "¿Quién? ¿Qué? Si no tienes nada bueno que decir, mejor no digas nada."

# game/chapters/2_day.rpy:1779
translate Spanish call1_day2_b8cd16b7:

    # GRC "That doesn't suit me at all."
    GRC "Eso no me queda para nada."

# game/chapters/2_day.rpy:1782
translate Spanish call1_day2_a41d80c7:

    # GRC "Why would anyone want to be called that?"
    GRC "¿Por qué alguien iba a querer que lo llamaran así?"

# game/chapters/2_day.rpy:1789
translate Spanish call1_day2_4382cb72:

    # GRC "...Phantom?"
    GRC "...¿Espectro?"

# game/chapters/2_day.rpy:1798
translate Spanish call1_day2_91330efa:

    # GRC "Ugh..."
    GRC "Ugh..."

# game/chapters/2_day.rpy:1805
translate Spanish call1_day2_0269a621_1:

    # GRC "No!"
    GRC "¡No!"

# game/chapters/2_day.rpy:1808
translate Spanish call1_day2_bacca62b:

    # GRC "You know what?!"
    GRC "¡¿Sabes qué?!"

# game/chapters/2_day.rpy:1809
translate Spanish call1_day2_a1014a4e:

    # GRC "Grim will do just fine!"
    GRC "¡Parca me basta!"

# game/chapters/2_day.rpy:1816
translate Spanish call1_day2_b6c1de20:

    # GRC "Lord, please help me."
    GRC "Señor, por favor ayúdame."

# game/chapters/2_day.rpy:1820
translate Spanish call1_day2_a280de5a:

    # GRC "You."
    GRC "Tú."

# game/chapters/2_day.rpy:1824
translate Spanish call1_day2_5eb68b3e:

    # GRC "Yes, you. You are the only one here."
    GRC "Sí, tú. Solo tú estás aquí."

# game/chapters/2_day.rpy:1825
translate Spanish call1_day2_44aad9e0:

    # GRC "Your words make me want to wring your neck myself."
    GRC "Tus palabras me dan ganas de estrangularte yo mismo."

# game/chapters/2_day.rpy:1830
translate Spanish call1_day2_0f22bc9f:

    # GRC "What is rude is the fact you are forcing your stupid, ill-thought nicknames upon me."
    GRC "Lo que es grosero es que me estés imponiendo esos apodos estúpidos y mal pensados."

# game/chapters/2_day.rpy:1837
translate Spanish call1_day2_2b335536:

    # GRC "How about 'Grim Reaper, sir'."
    GRC "Qué tal 'Señor Parca'."

# game/chapters/2_day.rpy:1841
translate Spanish call1_day2_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:1845
translate Spanish call1_day2_3ced01a8:

    # GRC "What... I'm... it's not a kink thing!"
    GRC "¿Qué...? ¡Yo... no... no es por fetiche!"

# game/chapters/2_day.rpy:1848
translate Spanish call1_day2_2c9db13f:

    # GRC "It is not!"
    GRC "¡No lo es!"

# game/chapters/2_day.rpy:1850
translate Spanish call1_day2_84f6bece:

    # GRC "It is an act of frustration!"
    GRC "¡Es un acto de frustración!"

# game/chapters/2_day.rpy:1860
translate Spanish call1_day2_55aac151:

    # GRC "Where is the fun in that?"
    GRC "¿Dónde está la diversión en eso?"

# game/chapters/2_day.rpy:1861
translate Spanish call1_day2_beb95681:

    # GRC "Keep me in your mind, wondering."
    GRC "Tenme presente en tu mente, preguntándote."

# game/chapters/2_day.rpy:1865
translate Spanish call1_day2_5ec2fcaf:

    # GRC "Mark my words carefully. Commit them to your memory."
    GRC "Recuerda bien mis palabras. Grábalas en tu memoria."

# game/chapters/2_day.rpy:1866
translate Spanish call1_day2_309cbddb:

    # GRC "You {i}will{/i} get what is coming for you."
    GRC "Tú {i}recibirás{/i} lo que te corresponde."

# game/chapters/2_day.rpy:1876
translate Spanish call1_day2_a881606d:

    # GRC "Wait, why do you sound so excited?"
    GRC "Espera, ¿por qué hablas con tanta emoción?"

# game/chapters/2_day.rpy:1883
translate Spanish call1_day2_f578e64e:

    # GRC "Hah."
    GRC "Ja."

# game/chapters/2_day.rpy:1884
translate Spanish call1_day2_f22c2bf2:

    # GRC "You will meet me eventually."
    GRC "Tarde o temprano me conocerás."

# game/chapters/2_day.rpy:1886
translate Spanish call1_day2_84299021:

    # GRC "On the day of your death."
    GRC "El día de tu muerte."

# game/chapters/2_day.rpy:1893
translate Spanish call1_day2_11319ef0:

    # GRC "Sure, if that will make things easier for you to accept."
    GRC "Claro, si eso hace que te resulte más fácil aceptarlo."

# game/chapters/2_day.rpy:1894
translate Spanish call1_day2_d326b69d:

    # GRC "You will be the first mortal I bring flowers to."
    GRC "Serás el primer mortal al que le lleve flores."

# game/chapters/2_day.rpy:1902
translate Spanish call1_day2_d2f1c4e9:

    # GRC "I... have not, actually."
    GRC "En realidad... no lo he hecho."

# game/chapters/2_day.rpy:1905
translate Spanish call1_day2_cae8a691:

    # GRC "I suppose so."
    GRC "Supongo que sí."

# game/chapters/2_day.rpy:1909
translate Spanish call1_day2_12af75aa:

    # GRC "It usually just does not work."
    GRC "Normalmente simplemente no funciona."

# game/chapters/2_day.rpy:1910
translate Spanish call1_day2_25660094:

    # GRC "Mortals are forbidden, of course, and the rest of us are too busy working to take an interest in one another."
    GRC "Los mortales están prohibidos, por supuesto, y el resto de nosotros estamos demasiado ocupados trabajando para interesarnos unos en otros."

# game/chapters/2_day.rpy:1914
translate Spanish call1_day2_5614dd03:

    # GRC "Er..."
    GRC "Eh..."

# game/chapters/2_day.rpy:1915
translate Spanish call1_day2_55a817bf:

    # GRC "It's not that I... do not want to."
    GRC "No es que yo... no quiera."

# game/chapters/2_day.rpy:1916
translate Spanish call1_day2_30dc7cb6:

    # GRC "Who knows what will happen in the future."
    GRC "Quién sabe qué pasará en el futuro."

# game/chapters/2_day.rpy:1918
translate Spanish call1_day2_24c638e2:

    # GRC "Or if anyone can meet my standards."
    GRC "O si alguien podrá cumplir con mis estándares."

# game/chapters/2_day.rpy:1922
translate Spanish call1_day2_008afe10_3:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:1923
translate Spanish call1_day2_bd44cc12:

    # GRC "You and I are not compatible."
    GRC "Tú y yo no somos compatibles."

# game/chapters/2_day.rpy:1924
translate Spanish call1_day2_2ae573dc:

    # GRC "You are the hunted and I am the hunter."
    GRC "Tú eres la presa y yo soy el cazador."

# game/chapters/2_day.rpy:1926
translate Spanish call1_day2_8b4b1cf8:

    # GRC "Putting aside any thought of attraction between us, that fact will never not be true."
    GRC "Dejando de lado cualquier pensamiento de atracción entre nosotros, ese hecho nunca dejará de ser cierto."

# game/chapters/2_day.rpy:1930
translate Spanish call1_day2_2d337df5:

    # GRC "I... did I say that?"
    GRC "Yo... ¿dije eso?"

# game/chapters/2_day.rpy:1932
translate Spanish call1_day2_ba967123:

    # GRC "Why don't we go back to talking about my name? Yeah, great idea, me."
    GRC "¿Por qué no volvemos a hablar de mi nombre? Sí, gran idea, yo mismo."

# game/chapters/2_day.rpy:1937
translate Spanish call1_day2_87c5665f:

    # GRC "I disagree. I would fit anyone's standards."
    GRC "No estoy de acuerdo. Yo encajaría en los estándares de cualquiera."

# game/chapters/2_day.rpy:1938
translate Spanish call1_day2_ef7ff395:

    # GRC "Just as I assume I fit yours to a T."
    GRC "Así como asumo que encajo en los tuyos a la perfección."

# game/chapters/2_day.rpy:1942
translate Spanish call1_day2_7b93ba1b:

    # GRC "You admit to it readily!" id call1_day2_7b93ba1b
    GRC "¡Lo admites sin dudarlo!" id call1_day2_7b93ba1b

# game/chapters/2_day.rpy:1943
translate Spanish call1_day2_5e4e9c6c:

    # GRC "Desire me all you want, but what you really desire is your own demise."
    GRC "Deséame todo lo que quieras, pero lo que en realidad deseas es tu propia perdición."

# game/chapters/2_day.rpy:1944
translate Spanish call1_day2_8857ea25:

    # GRC "Poetic, really."
    GRC "Poético, en realidad."

# game/chapters/2_day.rpy:1945
translate Spanish call1_day2_14cbb985:

    # GRC "Anyway..."
    GRC "En fin..."

# game/chapters/2_day.rpy:1948
translate Spanish call1_day2_f173e27b:

    # GRC "You lie to yourself with such ease!"
    GRC "¡Te mientes con tanta facilidad!"

# game/chapters/2_day.rpy:1949
translate Spanish call1_day2_56cd7c0a:

    # GRC "What a skill to have."
    GRC "Qué habilidad tan increíble."

# game/chapters/2_day.rpy:1950
translate Spanish call1_day2_de1a94bf:

    # GRC "I can see the way your eyes trail over me. You can lie to yourself, but you cannot lie to me."
    GRC "Puedo ver cómo tus ojos me recorren. Puedes mentirte, pero no puedes mentirme a mí."

# game/chapters/2_day.rpy:1951
translate Spanish call1_day2_14cbb985_1:

    # GRC "Anyway..."
    GRC "En fin..."

# game/chapters/2_day.rpy:1961
translate Spanish call1_day2_204319ba:

    # GRC "Just call me Grim."
    GRC "Solo llámame Parca."

# game/chapters/2_day.rpy:1962
translate Spanish call1_day2_fed943be:

    # GRC "If I have to listen to even one more of your stupid nicknames, then I may combust on the spot."
    GRC "Si tengo que escuchar un solo apodo estúpido más, podría combustionar en el acto."

# game/chapters/2_day.rpy:1966
translate Spanish call1_day2_f7890ce1:

    # GRC "What about you what?"
    GRC "¿Qué de ti, qué?"

# game/chapters/2_day.rpy:1970
translate Spanish call1_day2_22923434:

    # GRC "Why would you need a nickname? I know your name perfectly well."
    GRC "¿Por qué necesitarías un apodo? Conozco perfectamente tu nombre."

# game/chapters/2_day.rpy:1972
translate Spanish call1_day2_1dc1b57f:

    # GRC "[playerfirstname]."
    GRC "[playerfirstname]."

# game/chapters/2_day.rpy:1973
translate Spanish call1_day2_6df6f0a3:

    # GRC "Perhaps you find yourself too flustered, hearing your name spoken by someone like me."
    GRC "Quizás te desconcierte escuchar tu nombre pronunciado por alguien como yo."

# game/chapters/2_day.rpy:1982
translate Spanish call1_day2_0207b1fb:

    # GRC "Oh, I love being unfair to mortals."
    GRC "Oh, me encanta ser injusto con los mortales."

# game/chapters/2_day.rpy:1992
translate Spanish call1_day2_6a29d20d:

    # GRC "Those pretty little ears work, after all."
    GRC "Esas bonitas orejitas sí funcionan, después de todo."

# game/chapters/2_day.rpy:1996
translate Spanish call1_day2_d71fe83e:

    # GRC "What? No—"
    GRC "¿Qué? No—"

# game/chapters/2_day.rpy:2003
translate Spanish call1_day2_12c28a4c:

    # GRC "I was trying to insult you!"
    GRC "¡Estaba intentando insultarte!"

# game/chapters/2_day.rpy:2011
translate Spanish call1_day2_0073591b:

    # GRC "Does it sound like one?"
    GRC "¿Suena como una?"

# game/chapters/2_day.rpy:2024
translate Spanish call1_day2_c15973db:

    # GRC "I do not get flustered by any mortal, let alone my targets."
    GRC "No me sonrojo por ningún mortal, y menos por mis objetivos."

# game/chapters/2_day.rpy:2034
translate Spanish call1_day2_742520f5:

    # GRC "I would say you were correct."
    GRC "Diría que tienes razón."

# game/chapters/2_day.rpy:2044
translate Spanish call1_day2_008afe10_4:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2051
translate Spanish call1_day2_008afe10_5:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2052
translate Spanish call1_day2_0c14e6d0:

    # GRC "Oh."
    GRC "Oh."

# game/chapters/2_day.rpy:2054
translate Spanish call1_day2_271e2e28:

    # GRC "Well, I wasn't expecting the honesty, but I appreciate it."
    GRC "Bueno, no esperaba tanta honestidad, pero la aprecio."

# game/chapters/2_day.rpy:2070
translate Spanish call1_day2_3afd8ad0:

    # GRC "Really? Then what's that dusting of pink on your cheeks?"
    GRC "¿En serio? Entonces, ¿qué es ese rubor rosado en tus mejillas?"

# game/chapters/2_day.rpy:2074
translate Spanish call1_day2_008afe10_6:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2078
translate Spanish call1_day2_29ea981e:

    # GRC "Uh..."
    GRC "Uh..."

# game/chapters/2_day.rpy:2080
translate Spanish call1_day2_3881d107:

    # GRC "And what would these matching nicknames be?"
    GRC "¿Y cuáles serían esos apodos a juego?"

# game/chapters/2_day.rpy:2084
translate Spanish call1_day2_6fbe03f4_1:

    # GRC "No."
    GRC "No."

# game/chapters/2_day.rpy:2088
translate Spanish call1_day2_8a62b2fe:

    # GRC "Denied."
    GRC "Denegado."

# game/chapters/2_day.rpy:2092
translate Spanish call1_day2_c51b225a:

    # GRC "Neither describe either of us."
    GRC "Ninguno nos describe."

# game/chapters/2_day.rpy:2096
translate Spanish call1_day2_d402cd36:

    # GRC "These are getting more absurd by the minute."
    GRC "Se están volviendo más absurdos por minuto."

# game/chapters/2_day.rpy:2098
translate Spanish call1_day2_ed552eab:

    # GRC "Why would I want to have a matching nickname with {i}you{/i}, anyway?"
    GRC "¿Por qué iba a querer un apodo a juego {i}contigo{/i}, de todos modos?"

# game/chapters/2_day.rpy:2105
translate Spanish call1_day2_997a6b3e:

    # GRC "Hah!"
    GRC "¡Ja!"

# game/chapters/2_day.rpy:2107
translate Spanish call1_day2_6b4ff622:

    # GRC "The only part of me that will be falling is my scythe upon your soul."
    GRC "La única parte de mí que caerá será mi guadaña sobre tu alma."

# game/chapters/2_day.rpy:2111
translate Spanish call1_day2_107c2dd7:

    # GRC "What? No..."
    GRC "¿Qué? No..."

# game/chapters/2_day.rpy:2115
translate Spanish call1_day2_008afe10_7:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2117
translate Spanish call1_day2_8d32dded:

    # GRC "Look. A nickname is unnecessary."
    GRC "Mira. Un apodo es innecesario."

# game/chapters/2_day.rpy:2126
translate Spanish call1_day2_f034338d:

    # GRC "Hmm..."
    GRC "Hmm..."

# game/chapters/2_day.rpy:2131
translate Spanish call1_day2_22867140:

    # GRC "Annoying? Irritating? Infuriating?"
    GRC "¿Fastidios[letra]? ¿Irritante? ¿Exasperante?"

# game/chapters/2_day.rpy:2136
translate Spanish call1_day2_ad8623b7:

    # GRC "My bad, I didn't realize we had the nickname police here."
    GRC "Mi error, no me di cuenta de que teníamos a la policía de los apodos aquí."

# game/chapters/2_day.rpy:2143
translate Spanish call1_day2_751c02c9:

    # GRC "No. Nicknames breed familiarity, and as hilarious as it would be, I don't want you to become attached to me."
    GRC "No. Los apodos engendran familiaridad y, por muy gracioso que sería, no quiero que te encariñes conmigo."

# game/chapters/2_day.rpy:2146
translate Spanish call1_day2_b4c5eb93:

    # GRC "...Fine. But don't come crying to me if you don't like it."
    GRC "...Está bien. Pero no vengas llorando a mí si no te gusta."

# game/chapters/2_day.rpy:2148
translate Spanish call1_day2_008afe10_8:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2152
translate Spanish call1_day2_e30a3715:

    # GRC "I have given it some thought."
    GRC "Lo he estado pensando."

# game/chapters/2_day.rpy:2162
translate Spanish call1_day2_93dc7f43:

    # GRC "Creativity is not something I lack."
    GRC "La creatividad no es algo que me falte."

# game/chapters/2_day.rpy:2164
translate Spanish call1_day2_345a1a75:

    # GRC "In fact, I do not {i}lack{/i}."
    GRC "De hecho, no me {i}falta{/i}."

# game/chapters/2_day.rpy:2171
translate Spanish call1_day2_008afe10_9:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2175
translate Spanish call1_day2_870e3a26:

    # GRC "...It's..."
    GRC "...Es..."

# game/chapters/2_day.rpy:2187
translate Spanish call1_day2_008afe10_10:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2188
translate Spanish call1_day2_2a831fcc:

    # GRC "I... might have thought up something."
    GRC "Yo... puede que haya pensado en algo."

# game/chapters/2_day.rpy:2200
translate Spanish call1_day2_c206f724:

    # GRC "Um..."
    GRC "Eh..."

# game/chapters/2_day.rpy:2202
translate Spanish call1_day2_84769674:

    # GRC "I... think I should pick another."
    GRC "Creo... que debería elegir otro."

# game/chapters/2_day.rpy:2209
translate Spanish call1_day2_008afe10_11:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2210
translate Spanish call1_day2_cd5f4444:

    # GRC "I suppose... it will do..."
    GRC "Supongo... que servirá..."

# game/chapters/2_day.rpy:2214
translate Spanish call1_day2_5614dd03_1:

    # GRC "Er..."
    GRC "Eh..."

# game/chapters/2_day.rpy:2215
translate Spanish call1_day2_be07ea6f:

    # GRC "Perhaps a... few years ago."
    GRC "Quizá... hace unos años."

# game/chapters/2_day.rpy:2222
translate Spanish call1_day2_e2b06223:

    # GRC "How funny."
    GRC "Qué gracioso."

# game/chapters/2_day.rpy:2223
translate Spanish call1_day2_214b82e2:

    # GRC "It's almost like you have been on my list for years."
    GRC "Es casi como si hubieras estado en mi lista durante años."

# game/chapters/2_day.rpy:2224
translate Spanish call1_day2_3c72ec11:

    # GRC "Anyway, it's..."
    GRC "En fin, es..."

# game/chapters/2_day.rpy:2232
translate Spanish call1_day2_eb5c87f3:

    # GRC "Sun... Sunshine."
    GRC "Sol... Solecito."

# game/chapters/2_day.rpy:2233
translate Spanish call1_day2_008afe10_12:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2241
translate Spanish call1_day2_008afe10_13:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2243
translate Spanish call1_day2_cd9e326d:

    # GRC "Sorry, I misspoke. I meant {i}nightmare{/i}."
    GRC "Perdón, fue un lapsus. Quise decir {i}pesadilla{/i}."

# game/chapters/2_day.rpy:2260
translate Spanish call1_day2_ac64bd4c:

    # GRC "Please, refrain from speaking any more."
    GRC "Por favor, abstente de seguir hablando."

# game/chapters/2_day.rpy:2262
translate Spanish call1_day2_997a529c:

    # GRC "It is rather grating."
    GRC "Es bastante irritante."

# game/chapters/2_day.rpy:2277
translate Spanish call1_day2_76175bd6:

    # GRC "And you are delusional."
    GRC "Y tú estás fuera de la realidad."

# game/chapters/2_day.rpy:2278
translate Spanish call1_day2_8c756ce7:

    # GRC "Completely and utterly."
    GRC "Completa y absolutamente."

# game/chapters/2_day.rpy:2283
translate Spanish call1_day2_f1b94ea2:

    # GRC "Haaa..."
    GRC "Haaa..."

# game/chapters/2_day.rpy:2296
translate Spanish call1_day2_6c28341a:

    # GRC "There is nothing I am more certain of in life. Or death, for that matter."
    GRC "No hay nada de lo que esté más seguro en la vida. Ni en la muerte, para el caso."

# game/chapters/2_day.rpy:2304
translate Spanish call1_day2_008afe10_14:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2327
translate Spanish call1_day2_1ccf3ba2:

    # GRC "It was a mistake."
    GRC "Fue un error."

# game/chapters/2_day.rpy:2331
translate Spanish call1_day2_0c14e6d0_1:

    # GRC "Oh."
    GRC "Oh."

# game/chapters/2_day.rpy:2332
translate Spanish call1_day2_e3271d70:

    # GRC "I, uh..."
    GRC "Yo, eh..."

# game/chapters/2_day.rpy:2333
translate Spanish call1_day2_c02b024e:

    # GRC "Nine hells, I'm not made for this kind of thing..."
    GRC "Por los nueve infiernos, no estoy hecho para este tipo de cosas..."

# game/chapters/2_day.rpy:2344
translate Spanish call1_day2_886f2727:

    # GRC "No. I refuse."
    GRC "No. Me niego."

# game/chapters/2_day.rpy:2347
translate Spanish call1_day2_4b8b042c:

    # GRC "No. Your begging will not convince me."
    GRC "No. Tus súplicas no me van a convencer."

# game/chapters/2_day.rpy:2352
translate Spanish call1_day2_c490405e:

    # GRC "Nope. Beg all you like."
    GRC "Nop. Ruega todo lo que quieras."

# game/chapters/2_day.rpy:2358
translate Spanish call1_day2_e9524c27:

    # GRC "That makes no sense. Why is there sugar on top?"
    GRC "Eso no tiene sentido. ¿Por qué con un poquito de azúcar?"

# game/chapters/2_day.rpy:2374
translate Spanish call1_day2_3a0c9a36:

    # GRC "Wha—swoon?!"
    GRC "¡¿Qué-suspirando de amor?!"

# game/chapters/2_day.rpy:2378
translate Spanish call1_day2_ccec634b:

    # GRC "You're bullshitting me."
    GRC "Me estás tomando el pelo."

# game/chapters/2_day.rpy:2387
translate Spanish call1_day2_a3d00a4d:

    # GRC "No. Nope. Absolutely not."
    GRC "No. Nop. Absolutamente no."

# game/chapters/2_day.rpy:2392
translate Spanish call1_day2_abf4e439:

    # GRC "You'd really do that?"
    GRC "¿De verdad harías eso?"

# game/chapters/2_day.rpy:2397
translate Spanish call1_day2_d93d9e26:

    # GRC "Then hand it over now."
    GRC "Entonces dámela ahora."

# game/chapters/2_day.rpy:2410
translate Spanish call1_day2_e6f8b846:

    # GRC "Ugh."
    GRC "Ugh."

# game/chapters/2_day.rpy:2417
translate Spanish call1_day2_89129c11:

    # GRC "Hah. Shy? You would call {i}me{/i} shy? I am anything but!"
    GRC "Ja. ¿Tímido? ¿Me llamarías {i}a mí{/i} tímido? ¡Soy cualquier cosa menos eso!"

# game/chapters/2_day.rpy:2422
translate Spanish call1_day2_490e0508:

    # GRC "I am NOT flustered! I can call you whatever I want!"
    GRC "¡NO estoy nervioso! ¡Puedo llamarte como yo quiera!"

# game/chapters/2_day.rpy:2442
translate Spanish call1_day2_008afe10_15:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2443
translate Spanish call1_day2_860ceddf:

    # GRC "I... I am the GRIM REAPER, for god's sake... I am NONE of those things!"
    GRC "Yo... yo soy la PARCA, por el amor de Dios...  ¡no soy NINGUNA de esas cosas!"

# game/chapters/2_day.rpy:2453
translate Spanish call1_day2_008afe10_16:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2454
translate Spanish call1_day2_91330efa_1:

    # GRC "Ugh..."
    GRC "Ugh..."

# game/chapters/2_day.rpy:2456
translate Spanish call1_day2_008afe10_17:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2458
translate Spanish call1_day2_0f7595e9:

    # GRC "Seriously... you are seriously hellspawn..."
    GRC "En serio... eres literalmente un engendro del infierno..."

# game/chapters/2_day.rpy:2460
translate Spanish call1_day2_bb9cd1e0:

    # GRC "...You... you're..."
    GRC "...Tú... eres..."

# game/chapters/2_day.rpy:2462
translate Spanish call1_day2_688b6d99:

    # GRC "Like sunshine... in the worst of ways."
    GRC "Como el sol... en el peor de los sentidos."

# game/chapters/2_day.rpy:2464
translate Spanish call1_day2_38cb0a37:

    # GRC "You are far too bright. I hate sunlight."
    GRC "Eres demasiado brillante. Odio la luz del sol."

# game/chapters/2_day.rpy:2468
translate Spanish call1_day2_2e87037f:

    # GRC "Please don't."
    GRC "Por favor, no lo hagas."

# game/chapters/2_day.rpy:2470
translate Spanish call1_day2_af509dce:

    # GRC "I doubt you can help your natural stupidity, either."
    GRC "Dudo que puedas evitar tu estupidez natural, tampoco."

# game/chapters/2_day.rpy:2476
translate Spanish call1_day2_eb2f2577:

    # GRC "What now!?"
    GRC "¡¿Ahora qué?!"

# game/chapters/2_day.rpy:2487
translate Spanish call1_day2_0a2c4bf7:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/2_day.rpy:2488
translate Spanish call1_day2_09528989:

    # GRC "You know what. My cat's on fire, I gotta go."
    GRC "Sabes qué. Mi gato está en llamas, tengo que irme."

# game/chapters/2_day.rpy:2493
translate Spanish call1_day2_ef6f8c97:

    # GRC "And I... I think I left my stove on... and my fridge open... and the front door unlocked."
    GRC "Y yo... creo que dejé la estufa encendida... y la nevera abierta... y la puerta principal sin seguro."

# game/chapters/2_day.rpy:2514
translate Spanish call1_day2_827ecbd2:

    # GRC "It's not a—"
    GRC "No es una—"

# game/chapters/2_day.rpy:2522
translate Spanish call1_day2_5462e7a7:

    # GRC "Wait? What's wrong with my personality?!"
    GRC "¡Espera! ¿Qué tiene de malo mi personalidad?"

# game/chapters/2_day.rpy:2530
translate Spanish call1_day2_008afe10_18:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2532
translate Spanish call1_day2_2c95b15c:

    # GRC "My personality is fine. Yours, on the other hand..."
    GRC "Mi personalidad está bien. La tuya, en cambio..."

# game/chapters/2_day.rpy:2534
translate Spanish call1_day2_1164c202:

    # GRC "Also, I didn't {i}illegally{/i} install anything. Your mortal laws don't apply to me."
    GRC "Además, yo no instalé nada {i}ilegalmente{/i}. Tus leyes mortales no se aplican a mí."

# game/chapters/2_day.rpy:2542
translate Spanish call1_day2_18c8a7fb:

    # GRC "They would never catch me, anyway."
    GRC "De todos modos, nunca me atraparían."

# game/chapters/2_day.rpy:2550
translate Spanish call1_day2_07ab7154:

    # GRC "...What?"
    GRC "...¿Qué?"

# game/chapters/2_day.rpy:2561
translate Spanish call1_day2_dbc639fb:

    # GRC "Wow."
    GRC "Wow."

# game/chapters/2_day.rpy:2562
translate Spanish call1_day2_ad775bfd:

    # GRC "You truly are {i}so{/i} funny."
    GRC "Qué {i}gracios[letra]{/i} eres."

# game/chapters/2_day.rpy:2563
translate Spanish call1_day2_874abd7f:

    # GRC "I'm laughing so hard."
    GRC "Me estoy riendo muchísimo."

# game/chapters/2_day.rpy:2564
translate Spanish call1_day2_c25614a0:

    # GRC "Ha. Ha. Ha."
    GRC "Ja. Ja. Ja."

# game/chapters/2_day.rpy:2570
translate Spanish call1_day2_008afe10_19:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2574
translate Spanish call1_day2_c0d1c586:

    # GRC "Track it all you like. You'd never be able to reach me, anyway."
    GRC "Rastrea todo lo que quieras. De todas maneras, nunca podrías alcanzarme."

# game/chapters/2_day.rpy:2579
translate Spanish call1_day2_f48b0c64:

    # GRC "Sunshine, I live in another {i}plane{/i} of existence."
    GRC "Solecito, yo vivo en otro {i}plano{/i} de existencia."

# game/chapters/2_day.rpy:2586
translate Spanish call1_day2_b5f7eb0c:

    # GRC "Wow, I was expecting a stupid answer coming from you, to be honest."
    GRC "Wow, para ser honesto, esperaba una respuesta estúpida viniendo de ti."

# game/chapters/2_day.rpy:2590
translate Spanish call1_day2_6f188733:

    # GRC "Pretty much every single time."
    GRC "Prácticamente cada vez."

# game/chapters/2_day.rpy:2592
translate Spanish call1_day2_b96907b4:

    # GRC "Honestly, it's rarer you answer me seriously."
    GRC "En realidad, es más raro que me contestes en serio."

# game/chapters/2_day.rpy:2593
translate Spanish call1_day2_f782b640:

    # GRC "I quite like it."
    GRC "Me gusta bastante."

# game/chapters/2_day.rpy:2600
translate Spanish call1_day2_bc9031d6:

    # GRC "Yes, that's why I said it."
    GRC "Sí, por eso lo dije."

# game/chapters/2_day.rpy:2601
translate Spanish call1_day2_853db2de:

    # GRC "I worry about you sometimes."
    GRC "A veces me preocupas."

# game/chapters/2_day.rpy:2605
translate Spanish call1_day2_41ad8068:

    # GRC "Huh? Why would there be anything else?"
    GRC "¿Eh? ¿Por qué habría algo más?"

# game/chapters/2_day.rpy:2612
translate Spanish call1_day2_47b0af8a:

    # GRC "WHAT?"
    GRC "¡¿QUÉ?!"

# game/chapters/2_day.rpy:2613
translate Spanish call1_day2_16042fa3:

    # GRC "Are you insane? You must be, to reach that conclusion."
    GRC "¿Estás loc[letra]? Debes estarlo para llegar a esa conclusión."

# game/chapters/2_day.rpy:2614
translate Spanish call1_day2_46a85aa4:

    # GRC "I am trying to have you {i}killed{/i}. What about that gives you the impression that I would have a crush on you?"
    GRC "Estoy intentando que te {i}maten{/i}. ¿Qué de eso te da la impresión de que tengo un crush contigo?"

# game/chapters/2_day.rpy:2619
translate Spanish call1_day2_4aa86442_1:

    # GRC "What the..."
    GRC "¿Qué demonios...?"

# game/chapters/2_day.rpy:2620
translate Spanish call1_day2_41084826:

    # GRC "That is a strange, strange opinion."
    GRC "Esa es una opinión muy, muy extraña."

# game/chapters/2_day.rpy:2621
translate Spanish call1_day2_87bba69c:

    # GRC "You really are a person after my own heart, aren't you?"
    GRC "De verdad eres alguien que piensa como yo, ¿no?"

# game/chapters/2_day.rpy:2623
translate Spanish call1_day2_e879a15e:

    # GRC "You should not look past that fact!"
    GRC "¡No deberías pasar por alto ese detalle!"

# game/chapters/2_day.rpy:2624
translate Spanish call1_day2_529ab5e7:

    # GRC "Mortal, I will be your demise. You would be wise to remember that."
    GRC "Mortal, yo seré tu perdición. Harías bien en recordarlo."

# game/chapters/2_day.rpy:2626
translate Spanish call1_day2_a9ad2050:

    # GRC "If not for the fact that you {i}won't just die{/i}, I would say you lack a sense of self-preservation."
    GRC "Si no fuera porque simplemente {i}no mueres{/i}, diría que careces de instinto de autoconservación."

# game/chapters/2_day.rpy:2628
translate Spanish call1_day2_aef0e968:

    # GRC "Anyway, that is all beside the point. Yes, I reside in the Underworld."
    GRC "De todos modos, eso no viene al caso. Sí, resido en el Inframundo."

# game/chapters/2_day.rpy:2631
translate Spanish call1_day2_0dc49ebd:

    # GRC "The best at what? Compared to whom?"
    GRC "¿Mejor en qué? ¿Comparado con quién?"

# game/chapters/2_day.rpy:2633
translate Spanish call1_day2_3533d753:

    # GRC "The best at being a nuisance to me? Yes, definitely."
    GRC "¿Mejor en fastidiarme a mí? Sí, definitivamente."

# game/chapters/2_day.rpy:2634
translate Spanish call1_day2_1a4049f7:

    # GRC "The best at avoiding something that should be unavoidable? Entirely."
    GRC "¿Mejor en evitar algo que debería ser inevitable? Completamente."

# game/chapters/2_day.rpy:2642
translate Spanish call1_day2_8da23161:

    # GRC "...."
    GRC "...."

# game/chapters/2_day.rpy:2643
translate Spanish call1_day2_0a3780a6:

    # GRC "I see very little mortals. I have near no one to compare you to."
    GRC "Veo muy pocos mortales. No tengo a casi nadie con quien compararte."

# game/chapters/2_day.rpy:2647
translate Spanish call1_day2_e1b95f83:

    # GRC "You..."
    GRC "Tú..."

# game/chapters/2_day.rpy:2649
translate Spanish call1_day2_cb3df8da:

    # GRC "Are not repulsive. Is that enough?"
    GRC "No eres desagradable. ¿Eso es suficiente?"

# game/chapters/2_day.rpy:2652
translate Spanish call1_day2_008afe10_20:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2654
translate Spanish call1_day2_d03c8fbc:

    # GRC "You abuse the fact that I must be honest..."
    GRC "Abusas del hecho de que debo ser honesto..."

# game/chapters/2_day.rpy:2655
translate Spanish call1_day2_859ef658:

    # GRC "...Fine. Yes, you are quite... interesting to look at. That is all I will say on the matter."
    GRC "...Está bien. Sí, eres bastante... interesante de mirar. Eso es todo lo que diré al respecto."

# game/chapters/2_day.rpy:2658
translate Spanish call1_day2_1d9998dc:

    # GRC "I have nothing more to say."
    GRC "No tengo nada más que decir."

# game/chapters/2_day.rpy:2662
translate Spanish call1_day2_0f959d12:

    # GRC "Lalala. I'm not listening."
    GRC "Lalala. No estoy escuchando."

# game/chapters/2_day.rpy:2665
translate Spanish call1_day2_8d0eb0b4:

    # GRC "Shut up, shut up, shut up."
    GRC "Cállate, cállate, cállate."

# game/chapters/2_day.rpy:2666
translate Spanish call1_day2_98d6933d:

    # GRC "I am going to ignore you now."
    GRC "Voy a ignorarte ahora."

# game/chapters/2_day.rpy:2671
translate Spanish call1_day2_4dd4b231:

    # GRC "Phew."
    GRC "Uf."

# game/chapters/2_day.rpy:2673
translate Spanish call1_day2_aef0e968_1:

    # GRC "Anyway, that is all beside the point. Yes, I reside in the Underworld."
    GRC "De todos modos, eso no viene al caso. Sí, resido en el Inframundo."

# game/chapters/2_day.rpy:2677
translate Spanish call1_day2_f9225973:

    # GRC "Well, you certainly are that."
    GRC "Bueno, sin duda eres eso."

# game/chapters/2_day.rpy:2678
translate Spanish call1_day2_1dddd48e:

    # GRC "An impressive talent. Bravo."
    GRC "Un talento impresionante. Bravo."

# game/chapters/2_day.rpy:2682
translate Spanish call1_day2_fca8843d:

    # GRC "That would be because I am!"
    GRC "¡Porque eso es exactamente lo que estoy haciendo!"

# game/chapters/2_day.rpy:2687
translate Spanish call1_day2_64bf084a:

    # GRC "Mind the pun, but my life is going to be a {i}living hell{/i} for as long as you walk the Earth."
    GRC "Con el juego de palabras y todo, mi vida va a ser un {i}infierno viviente{/i} mientras sigas caminando por la Tierra."

# game/chapters/2_day.rpy:2694
translate Spanish call1_day2_a0fe0fd9:

    # GRC "Yes!"
    GRC "¡Sí!"

# game/chapters/2_day.rpy:2695
translate Spanish call1_day2_e30d26e4:

    # GRC "I desire your soul more than I desire anything else in this cursed world!"
    GRC "¡Deseo tu alma más que cualquier otra cosa en este maldito mundo!"

# game/chapters/2_day.rpy:2705
translate Spanish call1_day2_008afe10_21:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2707
translate Spanish call1_day2_e4202d4d:

    # GRC "This hell continues, I see."
    GRC "Este infierno continúa, ya veo."

# game/chapters/2_day.rpy:2709
translate Spanish call1_day2_aef0e968_2:

    # GRC "Anyway, that is all beside the point. Yes, I reside in the Underworld."
    GRC "De todos modos, eso no viene al caso. Sí, resido en el Inframundo."

# game/chapters/2_day.rpy:2717
translate Spanish call1_day2_e07363c4:

    # GRC "Ultimate... frisbee?"
    GRC "¿Ultimate... frisbee?"

# game/chapters/2_day.rpy:2718
translate Spanish call1_day2_7b605675:

    # GRC "These are two words I did not think belonged together."
    GRC "Son dos palabras que jamás imaginé que pudieran ir juntas."

# game/chapters/2_day.rpy:2719
translate Spanish call1_day2_73d478c0:

    # GRC "You truly play ultimate frisbee?"
    GRC "¿De verdad juegas ultimate frisbee?"

# game/chapters/2_day.rpy:2724
translate Spanish call1_day2_c652c58d:

    # GRC "Color me impressed."
    GRC "Estoy impresionado."

# game/chapters/2_day.rpy:2725
translate Spanish call1_day2_cf12a965:

    # GRC "I did not know you possessed such a skill. Though I admit I do not know what this 'ultimate frisbee' actually is."
    GRC "No sabía que poseías tal habilidad. Aunque admito que no sé qué es realmente ese 'ultimate frisbee'."

# game/chapters/2_day.rpy:2729
translate Spanish call1_day2_019501c0:

    # GRC "I... I have no list!"
    GRC "Yo... ¡yo no tengo ninguna lista!"

# game/chapters/2_day.rpy:2733
translate Spanish call1_day2_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/2_day.rpy:2737
translate Spanish call1_day2_3d939b5e:

    # GRC "So what if I do?!"
    GRC "¡¿Y qué si lo tengo?!"

# game/chapters/2_day.rpy:2740
translate Spanish call1_day2_04a38d0e:

    # GRC "Of course I have! Here, let me read you some."
    GRC "¡Por supuesto que sí! Mira, déjame leerte unas cuantas."

# game/chapters/2_day.rpy:2742
translate Spanish call1_day2_be2daa20:

    # GRC "'My mortal stepped out of the way of the the piano. Truly, they become more of a problem each passing day.'"
    GRC "'Mi mortal se apartó del camino del piano. En verdad, cada día se convierte en un problema mayor.'"

# game/chapters/2_day.rpy:2743
translate Spanish call1_day2_003f2098:

    # GRC "'Today I thought I had them. They fell on the train tracks, then simply got back up as if nothing happened!'"
    GRC "'Hoy pensé que lo había conseguido. Cayó a las vías del tren, ¡y luego simplemente se levantó como si nada hubiera pasado!'"

# game/chapters/2_day.rpy:2744
translate Spanish call1_day2_ebaa1275:

    # GRC "You are mentioned in nearly every entry these days. Consider yourself lucky."
    GRC "Te menciono en casi cada entrada estos días. Considera que tienes suerte."

# game/chapters/2_day.rpy:2749
translate Spanish call1_day2_f3dbcc25:

    # GRC "What is there to be shy about?"
    GRC "¿Y qué motivo tendrías para avergonzarte?"

# game/chapters/2_day.rpy:2757
translate Spanish call1_day2_7c86bdfe:

    # GRC "God, strike me down now. Please."
    GRC "Dios, fulmíname ahora. Por favor."

# game/chapters/2_day.rpy:2758
translate Spanish call1_day2_ea728977:

    # GRC "Your head is thicker than a brick wall."
    GRC "Tu cabeza es más dura que un muro de ladrillo."

# game/chapters/2_day.rpy:2759
translate Spanish call1_day2_1bacade2:

    # GRC "I say 'I really want you to die'. You get out of it 'I write about you in my diary while laying on my bed and kicking my legs'."
    GRC "Yo digo 'Realmente quiero que mueras'. Tú entiendes 'Escribo sobre ti en mi diario mientras estoy acostado en la cama y muevo las piernas'."

# game/chapters/2_day.rpy:2767
translate Spanish call1_day2_008afe10_22:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:2769
translate Spanish call1_day2_1a94dcc2:

    # GRC "What I do or not do is BESIDE THE POINT."
    GRC "Lo que yo haga o deje de hacer NO VIENE AL CASO."

# game/chapters/2_day.rpy:2770
translate Spanish call1_day2_8aaa731c:

    # GRC "That is enough about me and the possiblity of me giggling while writing about you."
    GRC "Eso es suficiente sobre mí y la posibilidad de que me ría mientras escribo sobre ti."

# game/chapters/2_day.rpy:2771
translate Spanish call1_day2_e5058db1:

    # GRC "Back to the matter at hand."
    GRC "Volvamos al asunto en cuestión."

# game/chapters/2_day.rpy:2773
translate Spanish call1_day2_37ba0244:

    # GRC "Yes, I reside in the Underworld."
    GRC "Sí, resido en el Inframundo."

# game/chapters/2_day.rpy:2778
translate Spanish call1_day2_f99beed6:

    # GRC "Wait, really?"
    GRC "Espera, ¿en serio?"

# game/chapters/2_day.rpy:2784
translate Spanish call1_day2_c6d8aef9:

    # GRC "Just a passing mention?"
    GRC "¿Solo una mención pasajera?"

# game/chapters/2_day.rpy:2786
translate Spanish call1_day2_085ed375:

    # GRC "I can't help but feel disappointed."
    GRC "No puedo evitar sentirme decepcionado."

# game/chapters/2_day.rpy:2791
translate Spanish call1_day2_91a2745e:

    # GRC "I am the Grim Reaper."
    GRC "Yo soy la Parca."

# game/chapters/2_day.rpy:2792
translate Spanish call1_day2_2ad259ca:

    # GRC "No mortal has known me like you do, for good or for bad..."
    GRC "Ningún mortal me ha conocido como tú, para bien o para mal..."

# game/chapters/2_day.rpy:2794
translate Spanish call1_day2_78a08c1c:

    # GRC "I expected to be important enough for more than a mention in the footnotes."
    GRC "Esperaba ser lo bastante importante como para merecer algo más que una simple mención en las notas al pie."

# game/chapters/2_day.rpy:2800
translate Spanish call1_day2_b7cb2084:

    # GRC "I can only beg that there are no other mortals like you."
    GRC "Solo puedo rogar que no haya otros mortales como tú."

# game/chapters/2_day.rpy:2804
translate Spanish call1_day2_f0e14dac:

    # GRC "Yes, of course. You are obviously much cooler. Uh huh."
    GRC "Sí, por supuesto. Obviamente eres mucho más genial. Ajá."

# game/chapters/2_day.rpy:2805
translate Spanish call1_day2_33fd6ce9:

    # GRC "It is just so cool how you won't let me do my job, after all." id call1_day2_33fd6ce9
    GRC "Es tan genial que no me dejes hacer mi trabajo, después de todo." id call1_day2_33fd6ce9

# game/chapters/2_day.rpy:2809
translate Spanish call1_day2_a46efdbb:

    # GRC "Hell, I can only pray."
    GRC "Demonios, solo puedo rezar."

# game/chapters/2_day.rpy:2814
translate Spanish call1_day2_ed2fc435:

    # GRC "Like?"
    GRC "¿Como qué?"

# game/chapters/2_day.rpy:2819
translate Spanish call1_day2_83675cc2:

    # GRC "Hmm."
    GRC "Hmm."

# game/chapters/2_day.rpy:2820
translate Spanish call1_day2_1cbd6461:

    # GRC "What a strange, strange request."
    GRC "Qué petición tan, tan extraña."

# game/chapters/2_day.rpy:2822
translate Spanish call1_day2_d86d0057:

    # GRC "I will consider it, for the sole reason of wanting to consume your mind before I take your soul away."
    GRC "Lo consideraré, por la única razón de querer consumir tu mente antes de llevarme tu alma."

# game/chapters/2_day.rpy:2827
translate Spanish call1_day2_c968e166:

    # GRC "Karaoke night? What?"
    GRC "¿Noche de karaoke? ¿Qué?"

# game/chapters/2_day.rpy:2828
translate Spanish call1_day2_85270e0d:

    # GRC "Are you asking me to {i}karaoke{/i}?"
    GRC "¿Me estás pidiendo que haga {i}karaoke{/i}?"

# game/chapters/2_day.rpy:2831
translate Spanish call1_day2_e7bd1e97:

    # GRC "I will never understand what goes through that pretty little head of yours."
    GRC "Jamás entenderé lo que pasa por esa linda cabecita tuya."

# game/chapters/2_day.rpy:2832
translate Spanish call1_day2_286eb30f:

    # GRC "Fine. Perhaps before you pass away, we will perform one of these 'karaokes'."
    GRC "Está bien. Quizá antes de que mueras, hagamos uno de esos 'karaokes'."

# game/chapters/2_day.rpy:2834
translate Spanish call1_day2_a9ab8dd0:

    # GRC "Be warned that I am a spectacular singer, and I do not like losing."
    GRC "Pero ten cuidado: soy un cantante espectacular y no me gusta perder."

# game/chapters/2_day.rpy:2838
translate Spanish call1_day2_8baf5f41:

    # GRC "Good."
    GRC "Bien."

# game/chapters/2_day.rpy:2839
translate Spanish call1_day2_a4dabb3d:

    # GRC "Write about me all you wish. I have plenty of positive traits you can admire and speak about at length."
    GRC "Escribe sobre mí todo lo que quieras. Tengo muchas cualidades positivas que puedes admirar y sobre las que puedes hablar largo y tendido."

# game/chapters/2_day.rpy:2850
translate Spanish call1_day2_0a2c4bf7_1:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/2_day.rpy:2851
translate Spanish call1_day2_bf5a1c37:

    # GRC "There is nothing negative to write about me!"
    GRC "¡No hay nada negativo que escribir sobre mí!"

# game/chapters/2_day.rpy:2852
translate Spanish call1_day2_33f90def:

    # GRC "I am perfect in every sense of the word!"
    GRC "¡Soy perfecto en todos los sentidos de la palabra!"

# game/chapters/2_day.rpy:2855
translate Spanish call1_day2_bb96ebeb:

    # GRC "I shall do it with ease!"
    GRC "¡Lo haré con facilidad!"

# game/chapters/2_day.rpy:2857
translate Spanish call1_day2_27b4a6f2:

    # GRC "My hair, my skin, my taste in clothing, my work ethic, and my ability to cook cup noodles."
    GRC "Mi cabello, mi piel, mi gusto por la ropa, mi ética de trabajo y mi habilidad para cocinar fideos instantáneos."

# game/chapters/2_day.rpy:2861
translate Spanish call1_day2_677861bc:

    # GRC "Every cup of noodles I cook comes out perfectly. The perfect density, the perfect spread of flavor, the perfect aroma..."
    GRC "Cada vaso de fideos que preparo sale perfecto. La densidad perfecta, la distribución perfecta del sabor, el aroma perfecto..."

# game/chapters/2_day.rpy:2866
translate Spanish call1_day2_13b78785:

    # GRC "Now I'm making myself hungry."
    GRC "Ahora me estoy dando hambre."

# game/chapters/2_day.rpy:2870
translate Spanish call1_day2_a6fff477:

    # GRC "You are just jealous of my skills."
    GRC "Solo tienes celos de mis habilidades."

# game/chapters/2_day.rpy:2874
translate Spanish call1_day2_56812487:

    # GRC "There is no need to worry about me. They are plenty nourishing."
    GRC "No hay necesidad de preocuparse por mí. Son bastante nutritivos."

# game/chapters/2_day.rpy:2878
translate Spanish call1_day2_58b5f3b6:

    # GRC "You are correct to be impressed."
    GRC "Tienes razón en estar impresionad[letra]."

# game/chapters/2_day.rpy:2880
translate Spanish call1_day2_8b03d52e:

    # GRC "Many others do not share my skills. They create noodles far too soggy, far too tasteless."
    GRC "Muchos otros no comparten mis habilidades. Hacen fideos demasiado blandos, demasiado insípidos."

# game/chapters/2_day.rpy:2881
translate Spanish call1_day2_ce9d8a75:

    # GRC "That will never be me."
    GRC "Yo nunca seré así."

# game/chapters/2_day.rpy:2883
translate Spanish call1_day2_9fcb04ed:

    # GRC "You will never catch me faulting in the realm of cup noodles."
    GRC "Nunca me verás fallar en el reino de los fideos instantáneos."

# game/chapters/2_day.rpy:2885
translate Spanish call1_day2_aef0e968_3:

    # GRC "Anyway, that is all beside the point. Yes, I reside in the Underworld."
    GRC "De todos modos, eso no viene al caso. Sí, resido en el Inframundo."

# game/chapters/2_day.rpy:2890
translate Spanish call1_day2_351762fb:

    # GRC "What is your basis for claiming such a thing?"
    GRC "¿Cuál es tu base para afirmar algo así?"

# game/chapters/2_day.rpy:2891
translate Spanish call1_day2_d72fdb7a:

    # GRC "If you have never tried it, how could you possibly assume that?"
    GRC "Si nunca lo has intentado, ¿cómo podrías suponerlo?"

# game/chapters/2_day.rpy:2895
translate Spanish call1_day2_75e94845:

    # GRC "Right. Ultimate frisbee vibes."
    GRC "Cierto. Vibra de ultimate frisbee."

# game/chapters/2_day.rpy:2896
translate Spanish call1_day2_d23e58e8:

    # GRC "That makes total sense."
    GRC "Eso tiene todo el sentido."

# game/chapters/2_day.rpy:2898
translate Spanish call1_day2_dff9f8c1:

    # GRC "If that's the case, then I'm pretty good at chess! Darts, too. Not bad at sewing, either."
    GRC "Si ese es el caso, ¡entonces soy bastante bueno en ajedrez! También en dardos. Y no soy malo cosiendo, tampoco."

# game/chapters/2_day.rpy:2905
translate Spanish call1_day2_272adecb:

    # GRC "I was not being serious."
    GRC "No estaba hablando en serio."

# game/chapters/2_day.rpy:2910
translate Spanish call1_day2_1baec00d:

    # GRC "I suppose of all the things you could have said, that is a reasonable one."
    GRC "Supongo que, de todas las cosas que podrías haber dicho, esa es razonable."

# game/chapters/2_day.rpy:2911
translate Spanish call1_day2_869f599c:

    # GRC "Playing sports is not for me, but I appreciate the effort it takes."
    GRC "Practicar deportes no es lo mío, pero aprecio el esfuerzo que requiere."

# game/chapters/2_day.rpy:2913
translate Spanish call1_day2_84a30bef:

    # GRC "So, bravo. Enjoy your little ball games."
    GRC "Así que, bravo. Disfruta de tus pequeños juegos de pelota."

# game/chapters/2_day.rpy:2917
translate Spanish call1_day2_65122790_1:

    # GRC "I..."
    GRC "Yo..."

# game/chapters/2_day.rpy:2918
translate Spanish call1_day2_f980b590:

    # GRC "...Suppose that is as good a reason as I can expect from you."
    GRC "...Supongo que esa es la mejor razón que puedo esperar de ti."

# game/chapters/2_day.rpy:2920
translate Spanish call1_day2_75277057:

    # GRC "Yes, you definitely would be fantastic at ultimate frisbee. A master. A world champion."
    GRC "Sí, sin duda serías fantástic[letra] en ultimate frisbee. [arti_2!c] maestr[letra]. Como un campeón mundial."

# game/chapters/2_day.rpy:2921
translate Spanish call1_day2_163df27f:

    # GRC "You should take up the sport immediately and aim for the world stage."
    GRC "Deberías practicar ese deporte de inmediato y apuntar al escenario mundial."

# game/chapters/2_day.rpy:2925
translate Spanish call1_day2_aef0e968_4:

    # GRC "Anyway, that is all beside the point. Yes, I reside in the Underworld."
    GRC "De todos modos, eso no viene al caso. Sí, resido en el Inframundo."

# game/chapters/2_day.rpy:2930
translate Spanish call1_day2_40ff7087:

    # GRC "I hope your mortal eyes appreciate what none of your kind usually get to admire."
    GRC "Espero que tus ojos mortales aprecien lo que ninguno de los de tu especie suele admirar."

# game/chapters/2_day.rpy:2935
translate Spanish call1_day2_ad1eece2:

    # GRC "Why, do I look like an angel to you?"
    GRC "¿Por qué, acaso parezco un ángel para ti?"

# game/chapters/2_day.rpy:2939
translate Spanish call1_day2_f359414f:

    # GRC "I'll take it as a compliment, then."
    GRC "Lo tomaré como un cumplido, entonces."

# game/chapters/2_day.rpy:2940
translate Spanish call1_day2_7d7d1800:

    # GRC "Angels are usually quite beautiful."
    GRC "Los ángeles suelen ser bastante hermosos."

# game/chapters/2_day.rpy:2944
translate Spanish call1_day2_89fe4493:

    # GRC "Hmm. Well, if I had to place you somewhere in the hierarchy of heaven and hell..."
    GRC "Hmm. Bueno, si tuviera que ubicarte en algún lugar de la jerarquía del cielo y del infierno..."

# game/chapters/2_day.rpy:2946
translate Spanish call1_day2_730b0c9c:

    # GRC "You would be an incompetent and unimportant imp."
    GRC "Serías [arti_2] diablit[letra] incompetente e insignificante."

# game/chapters/2_day.rpy:2949
translate Spanish call1_day2_4d68d208:

    # GRC "How incredibly sad."
    GRC "Qué increíblemente triste."

# game/chapters/2_day.rpy:2951
translate Spanish call1_day2_7ae2d948:

    # GRC "Anyway, no, I am not in Heaven."
    GRC "En fin, no, no estoy en el Cielo."

# game/chapters/2_day.rpy:2953
translate Spanish call1_day2_2ac5b997:

    # GRC "I doubt they would let me in, either."
    GRC "Dudo que me dejaran entrar, tampoco."

# game/chapters/2_day.rpy:2957
translate Spanish call1_day2_c736d646:

    # GRC "What I do is a part of the natural cycle."
    GRC "Lo que hago es parte del ciclo natural."

# game/chapters/2_day.rpy:2958
translate Spanish call1_day2_a334237b:

    # GRC "When someone's time has come to an end, I simply help them along."
    GRC "Cuando el tiempo de alguien llega a su fin, simplemente le ayudo a continuar."

# game/chapters/2_day.rpy:2959
translate Spanish call1_day2_4dd59a61:

    # GRC "Regardless, it is far too dirty a job for an angel."
    GRC "De todas formas, es un trabajo demasiado sucio para un ángel."

# game/chapters/2_day.rpy:2962
translate Spanish call1_day2_30a8ee71:

    # GRC "The Underworld."
    GRC "El Inframundo."

# game/chapters/2_day.rpy:2968
translate Spanish call1_day2_17bd835a:

    # GRC "I... what?"
    GRC "Yo... ¿qué?"

# game/chapters/2_day.rpy:2969
translate Spanish call1_day2_af26aa84:

    # GRC "Australia?"
    GRC "¿Australia?"

# game/chapters/2_day.rpy:2973
translate Spanish call1_day2_a7df23db:

    # GRC "That... is a location on Earth, mortal."
    GRC "Eso... es un lugar en la Tierra, mortal."

# game/chapters/2_day.rpy:2980
translate Spanish call1_day2_a684177b:

    # GRC "Have you considered picking up a map?"
    GRC "¿Has considerado tomar un mapa?"

# game/chapters/2_day.rpy:2989
translate Spanish call1_day2_d7406a4b:

    # GRC "Huh. Maybe if I sent you to Australia, the wildlife would do my job for me."
    GRC "Huh. Quizá si te enviara a Australia, la fauna haría el trabajo por mí."

# game/chapters/2_day.rpy:2991
translate Spanish call1_day2_2eac7bf8:

    # GRC "No, you buffoon, I am in the Underworld."
    GRC "No, payas[letra], estoy en el Inframundo."

# game/chapters/2_day.rpy:2993
translate Spanish call1_day2_689c0150:

    # GRC "I thought that would be obvious..."
    GRC "Pensé que sería obvio..."

# game/chapters/2_day.rpy:3013
translate Spanish call1_day2_c8d69e2a:

    # GRC "You are not destined for the Underworld."
    GRC "No estás destinad[letra] al Inframundo."

# game/chapters/2_day.rpy:3017
translate Spanish call1_day2_ea10d11a:

    # GRC "I would rather perish than share my space."
    GRC "Preferiría perecer antes que compartir mi espacio."

# game/chapters/2_day.rpy:3021
translate Spanish call1_day2_b65f8aab:

    # GRC "Especially with you."
    GRC "Especialmente contigo."

# game/chapters/2_day.rpy:3029
translate Spanish call1_day2_85e77416:

    # GRC "A... a what?!"
    GRC "¡¿Q... qué?!"

# game/chapters/2_day.rpy:3039
translate Spanish call1_day2_78736dbc:

    # GRC "Excuse me?! I... do not need help {i}bathing{/i} of all things!"
    GRC "¡¿Perdón?! ¡Yo... no necesito ayuda para {i}bañarme{/i}, de todas las cosas!"

# game/chapters/2_day.rpy:3043
translate Spanish call1_day2_9b3be9a4:

    # GRC "I didn't... I didn't say that!"
    GRC "¡Yo no... yo no dije eso!"

# game/chapters/2_day.rpy:3047
translate Spanish call1_day2_a56ec1cc:

    # GRC "My... hair?"
    GRC "¿Mi... cabello?"

# game/chapters/2_day.rpy:3051
translate Spanish call1_day2_61623283:

    # GRC "H... huh?"
    GRC "¿H... huh?"

# game/chapters/2_day.rpy:3056
translate Spanish call1_day2_04286a61:

    # GRC "Of course there is hot water... that... is {i}not{/i} the point..."
    GRC "Por supuesto que hay agua caliente... ese... {i}no{/i} es el punto..."

# game/chapters/2_day.rpy:3071
translate Spanish call1_day2_66c9c806:

    # GRC "There will be no massaging, or cooking together, or sharing a house, do you understand?"
    GRC "No habrá masajes, ni cocinar juntos, ni compartir una casa, ¿entiendes?"

# game/chapters/2_day.rpy:3079
translate Spanish call1_day2_20638b71:

    # GRC "No, it absolutely is not!"
    GRC "¡No, para nada!"

# game/chapters/2_day.rpy:3083
translate Spanish call1_day2_bc409bab:

    # GRC "I assure you, I... I won't."
    GRC "Te aseguro que yo... yo no lo haré."

# game/chapters/2_day.rpy:3087
translate Spanish call1_day2_f1fc51f3:

    # GRC "If anyone's changing the subject, it's you."
    GRC "Si alguien está cambiando de tema, eres tú."

# game/chapters/2_day.rpy:3095
translate Spanish call1_day2_87630030:

    # GRC "What... no, don't be stupid. I learnt it myself."
    GRC "Qué... no, no seas idiota. Lo aprendí yo mismo."

# game/chapters/2_day.rpy:3099
translate Spanish call1_day2_e62456a0:

    # GRC "Yes. Got a problem with that?"
    GRC "Sí. ¿Tienes algún problema con eso?"

# game/chapters/2_day.rpy:3103
translate Spanish call1_day2_367e7fe9:

    # GRC "As you should be."
    GRC "Como deberías."

# game/chapters/2_day.rpy:3105
translate Spanish call1_day2_911ee89a:

    # GRC "My talents are plentiful and perfected."
    GRC "Mis talentos son abundantes y perfectos."

# game/chapters/2_day.rpy:3112
translate Spanish call1_day2_6b28227d:

    # GRC "Talk about from one extreme to another..."
    GRC "Habla de pasar de un extremo a otro..."

# game/chapters/2_day.rpy:3114
translate Spanish call1_day2_21f4aa6f:

    # GRC "Maybe if you actually had some form of security on your computer, it wouldn't have been as easy."
    GRC "Quizá si en realidad tuvieras algún tipo de seguridad en tu computadora, no habría sido tan fácil."

# game/chapters/2_day.rpy:3117
translate Spanish call1_day2_5db8b66b:

    # GRC "Yeah? What one?"
    GRC "¿Sí? ¿Cuál?"

# game/chapters/2_day.rpy:3124
translate Spanish call1_day2_6ccd41d8:

    # GRC "Right. It wasn't hard to get in at all."
    GRC "Cierto. No fue nada difícil entrar."

# game/chapters/2_day.rpy:3128
translate Spanish call1_day2_0f0fd999:

    # GRC "As if I'd have the time for nonsense like that." id call1_day2_0f0fd999
    GRC "Como si tuviera tiempo para tonterías como esa." id call1_day2_0f0fd999

# game/chapters/2_day.rpy:3129
translate Spanish call1_day2_30b820b0:

    # GRC "Reaping souls is hard work, you know?"
    GRC "Segar almas es un trabajo duro, ¿sabes?"

# game/chapters/2_day.rpy:3133
translate Spanish call1_day2_32e10d2e:

    # GRC "Do you expect me to be working 24/7?"
    GRC "¿Esperas que trabaje 24/7?"

# game/chapters/2_day.rpy:3143
translate Spanish call1_day2_a14a851a:

    # GRC "I have no reason to lie."
    GRC "No tengo razón para mentir."

# game/chapters/2_day.rpy:3150
translate Spanish call1_day2_9bea2456:

    # GRC "I did it all by myself."
    GRC "Lo hice todo yo solo."

# game/chapters/2_day.rpy:3152
translate Spanish call1_day2_31f0b5da:

    # GRC "You should be impressed."
    GRC "Deberías estar impresionad[letra]."

# game/chapters/2_day.rpy:3153
translate Spanish call1_day2_f8d16b33:

    # GRC "You couldn't make something like this, even if you tried."
    GRC "No podrías hacer algo así, aunque lo intentaras."

# game/chapters/2_day.rpy:3158
translate Spanish call1_day2_5a504ec1:

    # GRC "You don't even have reliable computer security."
    GRC "Ni siquiera tienes seguridad informática confiable."

# game/chapters/2_day.rpy:3161
translate Spanish call1_day2_35707a4f:

    # GRC "Idiot. I was in your system before you could even blink."
    GRC "Idiota. Ya estaba en tu sistema antes de que pudieras parpadear."

# game/chapters/2_day.rpy:3165
translate Spanish call1_day2_a8c7c800:

    # GRC "I have enough on my plate, I don't have the time to be a {i}creepy hacker{/i}."
    GRC "Ya tengo suficientes cosas de las que ocuparme, no tengo tiempo para ser un {i}hacker espeluznante{/i}."

# game/chapters/2_day.rpy:3166
translate Spanish call1_day2_84c69442:

    # GRC "Do you expect me to pull extra time out of my ass?"
    GRC "¿Esperas que saque tiempo extra de la nada?"

# game/chapters/2_day.rpy:3173
translate Spanish call1_day2_91330efa_2:

    # GRC "Ugh..."
    GRC "Ugh..."

# game/chapters/2_day.rpy:3182
translate Spanish call1_day2_da731570:

    # GRC "Like I have already said, yes."
    GRC "Como ya he dicho, sí."

# game/chapters/2_day.rpy:3186
translate Spanish call1_day2_d4dd7f31:

    # GRC "How? What a loaded question."
    GRC "¿Cómo? Vaya pregunta, con todo lo que implica."

# game/chapters/2_day.rpy:3187
translate Spanish call1_day2_944d34a7:

    # GRC "You wouldn't understand at all, trust me."
    GRC "No lo entenderías en absoluto, créeme."

# game/chapters/2_day.rpy:3198
translate Spanish call1_day2_fef75484:

    # GRC "...Point taken."
    GRC "...Punto para ti."

# game/chapters/2_day.rpy:3199
translate Spanish call1_day2_31ab929a:

    # GRC "I'm still not going to tell you."
    GRC "Aun así no voy a decírtelo."

# game/chapters/2_day.rpy:3202
translate Spanish call1_day2_6714777f:

    # GRC "Not that I'd tell you how, anyway."
    GRC "No es que te fuera a decir cómo, de todos modos."

# game/chapters/2_day.rpy:3208
translate Spanish call1_day2_96a7f740:

    # GRC "Are you an idiot? I said I made it. I do not lie."
    GRC "¿Eres idiota? Dije que lo hice yo. No miento."

# game/chapters/2_day.rpy:3210
translate Spanish call1_day2_0d546276:

    # GRC "But if you have to know... I did watch a tutorial."
    GRC "Pero si tanto quieres saberlo... sí, vi un tutorial."

# game/chapters/2_day.rpy:3215
translate Spanish call1_day2_d8f81e0f:

    # GRC "Uh... yeah."
    GRC "Uh... sí."

# game/chapters/2_day.rpy:3217
translate Spanish call1_day2_1cb5e54e:

    # GRC "I made use of the resources I had."
    GRC "Hice uso de los recursos que tenía."

# game/chapters/2_day.rpy:3219
translate Spanish call1_day2_90764e25:

    # GRC "Is that a problem for you?"
    GRC "¿Eso es un problema para ti?"

# game/chapters/2_day.rpy:3227
translate Spanish call1_day2_ff391bfc:

    # GRC "And what exactly does this list say, dare I ask?"
    GRC "¿Y qué dice exactamente esa lista, si me atrevo a preguntar?"

# game/chapters/2_day.rpy:3231
translate Spanish call1_day2_9027be48:

    # GRC "I am... near none of those things."
    GRC "No estoy... cerca de ninguna de esas cosas."

# game/chapters/2_day.rpy:3236
translate Spanish call1_day2_1254417a:

    # GRC "And again with calling me cute...?!"
    GRC "¡¿Y otra vez con lo de llamarme lindo...?!"

# game/chapters/2_day.rpy:3244
translate Spanish call1_day2_936c79f4:

    # GRC "I have exactly zero traits that relate to cuteness."
    GRC "No tengo absolutamente ningún rasgo que se relacione con lo lindo."

# game/chapters/2_day.rpy:3245
translate Spanish call1_day2_a7ae5664:

    # GRC "None whatsoever."
    GRC "Ninguno en absoluto."

# game/chapters/2_day.rpy:3249
translate Spanish call1_day2_75a8773c:

    # GRC "I am {b}The Grim Reaper{/b}. The Grim Reaper is not cute."
    GRC "Soy {b}La Parca{/b}. La Parca no es linda."

# game/chapters/2_day.rpy:3250
translate Spanish call1_day2_ee8c7f84:

    # GRC "How do you not understand something so elementary?"
    GRC "¿Cómo no entiendes algo tan elemental?"

# game/chapters/2_day.rpy:3252
translate Spanish call1_day2_dd1f76e0:

    # GRC "You should tremble."
    GRC "Deberías temblar."

# game/chapters/2_day.rpy:3256
translate Spanish call1_day2_32f44438:

    # GRC "Yes."
    GRC "Sí."

# game/chapters/2_day.rpy:3257
translate Spanish call1_day2_ae6bfc54:

    # GRC "You should be terrifi-"
    GRC "Deberías estar aterra-"

# game/chapters/2_day.rpy:3264
translate Spanish call1_day2_92c5b32a:

    # GRC "These are all negative traits."
    GRC "Todos esos son rasgos negativos."

# game/chapters/2_day.rpy:3271
translate Spanish call1_day2_e85786ce:

    # GRC "They {i}all{/i} miss the mark."
    GRC "{i}Todos{/i} fallan por completo."

# game/chapters/2_day.rpy:3272
translate Spanish call1_day2_7b0a1082:

    # GRC "Where's sexy? Handsome? What about my devilish charm? You could have at least mentioned my fantastic wit."
    GRC "¿Dónde está sexy? ¿Apuesto? ¿Qué hay de mi encanto diabólico? Al menos podrías haber mencionado mi ingenio fantástico."

# game/chapters/2_day.rpy:3276
translate Spanish call1_day2_dd081e19:

    # GRC "It is your bad, yes."
    GRC "Es tu culpa, sí."

# game/chapters/2_day.rpy:3278
translate Spanish call1_day2_edff728b:

    # GRC "Revise your list."
    GRC "Revisa tu lista."

# game/chapters/2_day.rpy:3285
translate Spanish call1_day2_6f1d0415:

    # GRC "That's bullsh-"
    GRC "Eso es una mie-"

# game/chapters/2_day.rpy:3289
translate Spanish call1_day2_3a42d8d5:

    # GRC "Oh? Well, I am sexy, but I'm surprised to hear you admitting it so readily."
    GRC "¿Oh? Bueno, soy sexy, pero me sorprende oírte admitirlo tan abiertamente."

# game/chapters/2_day.rpy:3296
translate Spanish call1_day2_d3d6fbc5:

    # GRC "And where exactly do I fall on this '{i}sexy scale{/i}'?"
    GRC "¿Y en dónde exactamente caigo en esa '{i}escala de sexy{/i}'?"

# game/chapters/2_day.rpy:3303
translate Spanish call1_day2_3f0950f5:

    # GRC "{i}Excuse me{/i}?"
    GRC "{i}¿Perdón?{/i}"

# game/chapters/2_day.rpy:3305
translate Spanish call1_day2_b90bb357:

    # GRC "How am I not a solid {i}ten{/i}!? One? You've got to be kidding me."
    GRC "¿Cómo es que no soy un sólido {i}diez{/i}? ¿Uno? Debes estar bromeando."

# game/chapters/2_day.rpy:3309
translate Spanish call1_day2_c716b486:

    # GRC "This is bullshit. You said I was sexy, and yet you rank me as 'not at all sexy'!"
    GRC "Esto es una estupidez. ¡Dijiste que era sexy y aun así me clasificas como 'para nada sexy'!"

# game/chapters/2_day.rpy:3311
translate Spanish call1_day2_cabfaa32:

    # GRC "I think someone is a liar."
    GRC "Creo que alguien está mintiendo."

# game/chapters/2_day.rpy:3318
translate Spanish call1_day2_b002a865:

    # GRC "{i}What{/i}? Two?!"
    GRC "¿{i}Qué{/i}? ¡¿Dos?!"

# game/chapters/2_day.rpy:3319
translate Spanish call1_day2_0d0d3234:

    # GRC "You've ranked me one above 'not at all sexy'?!"
    GRC "¡¿Me pusiste uno por encima de 'para nada sexy'?!"

# game/chapters/2_day.rpy:3323
translate Spanish call1_day2_b4e10806:

    # GRC "This is not funny!"
    GRC "¡Esto no es gracioso!"

# game/chapters/2_day.rpy:3327
translate Spanish call1_day2_61654bd1:

    # GRC "Of course you did."
    GRC "Por supuesto que lo hiciste."

# game/chapters/2_day.rpy:3329
translate Spanish call1_day2_fc6af3b3:

    # GRC "I see the way your eyes follow me."
    GRC "Veo cómo tus ojos me siguen."

# game/chapters/2_day.rpy:3336
translate Spanish call1_day2_42b2fded:

    # GRC "A three... three..."
    GRC "Un tres... tres..."

# game/chapters/2_day.rpy:3338
translate Spanish call1_day2_29a0459c:

    # GRC "That's too close to 'not at all sexy'."
    GRC "Eso está demasiado cerca de 'para nada sexy'."

# game/chapters/2_day.rpy:3341
translate Spanish call1_day2_bdb2c51a:

    # GRC "You said three! That is almost as bad!"
    GRC "Dijiste tres. ¡Eso es casi igual de malo!"

# game/chapters/2_day.rpy:3345
translate Spanish call1_day2_a70b181b:

    # GRC "You're lying."
    GRC "Estás mintiendo."

# game/chapters/2_day.rpy:3348
translate Spanish call1_day2_32f44438_1:

    # GRC "Yes."
    GRC "Sí."

# game/chapters/2_day.rpy:3352
translate Spanish call1_day2_e61c6cd9:

    # GRC "You obviously rank me as a ten, and are just too shy to admit to it."
    GRC "Obviamente me calificas con un diez y solo es tu timidez la que te impide admitirlo."

# game/chapters/2_day.rpy:3359
translate Spanish call1_day2_09c8bc76:

    # GRC "A {i}four{/i}?"
    GRC "¿Un {i}cuatro{/i}?"

# game/chapters/2_day.rpy:3366
translate Spanish call1_day2_0e4d6251:

    # GRC "You are definitely lying to me. I am not below half sexy."
    GRC "Definitivamente me estás mintiendo. No estoy por debajo de la mitad de sexy."

# game/chapters/2_day.rpy:3367
translate Spanish call1_day2_b9b057d6:

    # GRC "I am at least 99 percent sexy."
    GRC "Soy al menos un 99 por ciento sexy."

# game/chapters/2_day.rpy:3369
translate Spanish call1_day2_90f21039:

    # GRC "Are you blind?"
    GRC "¿Estás cieg[letra]?"

# game/chapters/2_day.rpy:3373
translate Spanish call1_day2_6f6b7109:

    # GRC "Oh I see how it is. You lie. Mortals, always lying."
    GRC "Ah, ya veo cómo es. Mientes. Los mortales, siempre mintiendo."

# game/chapters/2_day.rpy:3377
translate Spanish call1_day2_ce5f2bd7:

    # GRC "Too shy to tell me I'm a ten to my face, are you?"
    GRC "¿Te da demasiada vergüenza decirme en la cara que soy un diez?"

# game/chapters/2_day.rpy:3380
translate Spanish call1_day2_9d68961b:

    # GRC "It is obviously the case."
    GRC "Es obviamente el caso."

# game/chapters/2_day.rpy:3388
translate Spanish call1_day2_6bfef083:

    # GRC "Five... that's only half sexy..."
    GRC "Cinco... eso es solo medio sexy..."

# game/chapters/2_day.rpy:3392
translate Spanish call1_day2_2a4b65a4:

    # GRC "I am a solid ten. You are just too afraid to admit to it."
    GRC "Soy un sólido diez. Solo tienes demasiado miedo de admitirlo."

# game/chapters/2_day.rpy:3394
translate Spanish call1_day2_6a31a897:

    # GRC "You can just say you're attracted to me, and leave it at that..."
    GRC "Puedes simplemente decir que te atraigo, y dejarlo ahí..."

# game/chapters/2_day.rpy:3398
translate Spanish call1_day2_70363630:

    # GRC "Obviously."
    GRC "Obviamente."

# game/chapters/2_day.rpy:3399
translate Spanish call1_day2_d99d7508:

    # GRC "I see the way you're looking at me. Even now."
    GRC "Veo la forma en que me miras. Incluso ahora."

# game/chapters/2_day.rpy:3403
translate Spanish call1_day2_c3532cfd:

    # GRC "Let me know when you decide to tell the truth."
    GRC "Avísame cuando decidas decir la verdad."

# game/chapters/2_day.rpy:3407
translate Spanish call1_day2_7ddbce24:

    # GRC "I know you would."
    GRC "Sé que lo harías."

# game/chapters/2_day.rpy:3414
translate Spanish call1_day2_d56e4e50:

    # GRC "A six... why is it only just above half?"
    GRC "Un seis... ¿por qué solo un poco más de la mitad?"

# game/chapters/2_day.rpy:3418
translate Spanish call1_day2_41d07790:

    # GRC "I am a ten. There is no being, mortal or otherwise, higher up the scale than I."
    GRC "Soy un diez. No existe ser, mortal o no, más alto en la escala que yo."

# game/chapters/2_day.rpy:3422
translate Spanish call1_day2_edf2e680:

    # GRC "I see the way you look at me, I know you think I'm sexier than a six."
    GRC "Veo la forma en que me miras, sé que piensas que soy más sexy que un seis."

# game/chapters/2_day.rpy:3425
translate Spanish call1_day2_54b782f1:

    # GRC "With big, wide, curious eyes."
    GRC "Con ojos grandes, abiertos, curiosos."

# game/chapters/2_day.rpy:3427
translate Spanish call1_day2_f46e77dd:

    # GRC "With eyes that know I'm a ten."
    GRC "Con ojos que saben que soy un diez."

# game/chapters/2_day.rpy:3434
translate Spanish call1_day2_d0ecac65:

    # GRC "Seven...?"
    GRC "¿Siete...?"

# game/chapters/2_day.rpy:3438
translate Spanish call1_day2_9f82e643:

    # GRC "Not high enough. "
    GRC "No es lo bastante alto."

# game/chapters/2_day.rpy:3440
translate Spanish call1_day2_35d6f886:

    # GRC "Please, we both know I'm a ten."
    GRC "Por favor, ambos sabemos que soy un diez."

# game/chapters/2_day.rpy:3443
translate Spanish call1_day2_06e19cf6:

    # GRC "I can see it in your eyes."
    GRC "Lo veo en tus ojos."

# game/chapters/2_day.rpy:3444
translate Spanish call1_day2_0e57ed64:

    # GRC "Even now, I feel you stare."
    GRC "Incluso ahora, siento tu mirada."

# game/chapters/2_day.rpy:3447
translate Spanish call1_day2_24e7c66d:

    # GRC "The stare of a person that knows I am the most handsome man in existence."
    GRC "La mirada de alguien que sabe que soy el hombre más guapo de la existencia."

# game/chapters/2_day.rpy:3454
translate Spanish call1_day2_5a322255:

    # GRC "An eight? It is quite high, I suppose, but nice try. I know I am a ten in your eyes."
    GRC "¿Un ocho? Es bastante alto, supongo, pero buen intento. Sé que soy un diez a tus ojos."

# game/chapters/2_day.rpy:3458
translate Spanish call1_day2_3e070aa1:

    # GRC "I see the way your eyes always follow me."
    GRC "Veo cómo tus ojos siempre me siguen."

# game/chapters/2_day.rpy:3461
translate Spanish call1_day2_26fb7fff:

    # GRC "Even now. Your mouth lies, but your eyes tell the truth."
    GRC "Incluso ahora. Tu boca miente, pero tus ojos dicen la verdad."

# game/chapters/2_day.rpy:3468
translate Spanish call1_day2_d9b8c94e:

    # GRC "A nine?! Why not a ten?!"
    GRC "¡¿Un nueve?! ¡¿Por qué no un diez?!"

# game/chapters/2_day.rpy:3472
translate Spanish call1_day2_59cd83e1:

    # GRC "So what you're saying is I'm actually a ten."
    GRC "Así que lo que estás diciendo es que en realidad soy un diez."

# game/chapters/2_day.rpy:3473
translate Spanish call1_day2_95ada8ef:

    # GRC "But you are too shy to say so."
    GRC "Pero es tu timidez la que te impide decirlo."

# game/chapters/2_day.rpy:3477
translate Spanish call1_day2_e2304018:

    # GRC "You have high thoughts about yourself."
    GRC "Tienes una alta opinión de ti mism[letra]."

# game/chapters/2_day.rpy:3479
translate Spanish call1_day2_e2655622:

    # GRC "I respect that."
    GRC "Eso lo respeto."

# game/chapters/2_day.rpy:3486
translate Spanish call1_day2_2c346477:

    # GRC "Well?"
    GRC "¿Y bien?"

# game/chapters/2_day.rpy:3490
translate Spanish call1_day2_830098c5:

    # GRC "Wow. What a surprise."
    GRC "Wow. Qué sorpresa."

# game/chapters/2_day.rpy:3494
translate Spanish call1_day2_4e226b72:

    # GRC "With the way your eyes follow my every move, how could you not think I was a ten?"
    GRC "Con la forma en que tus ojos siguen cada uno de mis movimientos, ¿cómo podrías no pensar que soy un diez?"

# game/chapters/2_day.rpy:3498
translate Spanish call1_day2_2915df3f:

    # GRC "Even now, you're looking at me."
    GRC "Incluso ahora, me estás mirando."

# game/chapters/2_day.rpy:3499
translate Spanish call1_day2_9b26d9d3:

    # GRC "Always watching me, Sunshine?"
    GRC "¿Siempre vigilándome, Solecito?"

# game/chapters/2_day.rpy:3503
translate Spanish call1_day2_6a2165ba:

    # GRC "Entranced with my charm, perhaps. I don't hold it against you."
    GRC "Quizás te hechiza mi encanto. No te culpo."

# game/chapters/2_day.rpy:3506
translate Spanish call1_day2_86e3e1d8:

    # GRC "Please, we both know my charm could capture anyone."
    GRC "Por favor, ambos sabemos que mi encanto podría atrapar a cualquiera."

# game/chapters/2_day.rpy:3510
translate Spanish call1_day2_e1deb02a:

    # GRC "I'm simply a high achiever. Tens across the board."
    GRC "Simplemente soy un gran triunfador. Dieces en todos lados."

# game/chapters/2_day.rpy:3528
translate Spanish call1_day2_86f09c97:

    # GRC "What are you on about?"
    GRC "¿De qué hablas?"

# game/chapters/2_day.rpy:3544
translate Spanish call1_day2_0b9ec856:

    # GRC "WHAT?!"
    GRC "¡¿QUÉ?!"

# game/chapters/2_day.rpy:3545
translate Spanish call1_day2_85fbea63:

    # GRC "You did {i}not{/i} see that."
    GRC "{i}No{/i} viste eso."

# game/chapters/2_day.rpy:3546
translate Spanish call1_day2_9812c6d8:

    # GRC "Not a word about it. Do you understand?"
    GRC "Ni una palabra al respecto. ¿Entiendes?"

# game/chapters/2_day.rpy:3555
translate Spanish call1_day2_008afe10_23:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:3560
translate Spanish call1_day2_36251b35:

    # GRC "Why the hell would I give him a name?"
    GRC "¿Por qué demonios le pondría un nombre?"

# game/chapters/2_day.rpy:3565
translate Spanish call1_day2_9a89cdca:

    # GRC "Ah... shit."
    GRC "Ah... mierda."

# game/chapters/2_day.rpy:3576
translate Spanish call1_day2_e4e28fa5:

    # GRC "Stop talking."
    GRC "Deja de hablar."

# game/chapters/2_day.rpy:3584
translate Spanish call1_day2_6fbe03f4_2:

    # GRC "No."
    GRC "No."

# game/chapters/2_day.rpy:3588
translate Spanish call1_day2_6fbe03f4_3:

    # GRC "No."
    GRC "No."

# game/chapters/2_day.rpy:3593
translate Spanish call1_day2_2f34edd5:

    # GRC "His name is Azrael."
    GRC "Su nombre es Azrael."

# game/chapters/2_day.rpy:3597
translate Spanish call1_day2_008afe10_24:

    # GRC "..."
    GRC "..."

# game/chapters/2_day.rpy:3602
translate Spanish call1_day2_c3a970be:

    # GRC "And what's that supposed to mean?"
    GRC "¿Y qué se supone que significa eso?"

# game/chapters/2_day.rpy:3608
translate Spanish call1_day2_37ed0703:

    # GRC "Obviously I would call him that. You need but glance at him and he strikes fear into your heart."
    GRC "Obviamente lo llamaría así. Solo necesitas mirarlo y te infunde miedo en el corazón."

# game/chapters/2_day.rpy:3613
translate Spanish call1_day2_6b98e214:

    # GRC "It is much better than any of the godawful names I'm sure you were about to spout."
    GRC "Es mucho mejor que cualquiera de los horribles nombres que seguro estabas a punto de soltar."

# game/chapters/2_day.rpy:3624
translate Spanish call1_day2_d984bef1:

    # GRC "Well, he has a name."
    GRC "Bueno, tiene un nombre."

# game/chapters/2_day.rpy:3625
translate Spanish call1_day2_2b8536c8:

    # GRC "As great of a discussion this is—"
    GRC "Por muy buena que sea esta discusión—"

# game/chapters/2_day.rpy:3628
translate Spanish call1_day2_52a7cab1:

    # GRC "Duty calls."
    GRC "El deber llama."

# game/chapters/2_day.rpy:3633
translate Spanish call1_day2_c42647a5:

    # GRC "Mortal, death can call at any time."
    GRC "Mortal, la muerte puede llamarte en cualquier momento."

# game/chapters/2_day.rpy:3637
translate Spanish call1_day2_b588880a:

    # GRC "Talk later, little human."
    GRC "Hablamos luego, humanit[letra]."

# game/chapters/2_day.rpy:3642
translate Spanish call1_day2_28de8bad:

    # GRC "Yes. I suppose you shall."
    GRC "Sí. Supongo que así será."

# game/chapters/2_day.rpy:3643
translate Spanish call1_day2_38c8e936:

    # GRC "Look after yourself, [playerfirstname]."
    GRC "Cuídate, [playerfirstname]."

# game/chapters/2_day.rpy:3645
translate Spanish call1_day2_c0e6f60f:

    # GRC "Claiming your life belongs to me only."
    GRC "Reclamando que tu vida me pertenece solo a mí."

# game/chapters/2_day.rpy:3669
translate Spanish chat2_day2_03775ec8:

    # player "..."
    player "..."

# game/chapters/2_day.rpy:3672
translate Spanish chat2_day2_ed435310:

    # player "That almost sounded romantic!"
    player "¡Eso casi sonó romántico!"

# game/chapters/2_day.rpy:3673
translate Spanish chat2_day2_e6a70baf:

    # GR "death can be quite romantic, don't you think?"
    GR "la muerte puede ser bastante romántica, ¿no crees?"

# game/chapters/2_day.rpy:3674
translate Spanish chat2_day2_4f152678:

    # GR "have a good night, [playerfirstname]."
    GR "que tengas una buena noche, [playerfirstname]."

# game/chapters/2_day.rpy:3680
translate Spanish chat2_day2_75bc9beb:

    # GR "good luck avoiding me tomorrow."
    GR "buena suerte evitándome mañana."

translate Spanish strings:

    # game/chapters/2_day.rpy:26
    old "1. Roll to the side."
    new "1. Rodar hacia un lado."

    # game/chapters/2_day.rpy:30
    old "2. Wait and see what happens."
    new "2. Esperar y ver qué pasa."

    # game/chapters/2_day.rpy:52
    old "mortals are stupid."
    new "{size=18}los mortales son estúpidos.{/size}"

    # game/chapters/2_day.rpy:83
    old "1. <Are you so hard at work you have no time to talk to me, Grim?>"
    new "1. <¿Tan ocupado estás que no puedes hablarme, Parca?>"

    # game/chapters/2_day.rpy:86
    old "1. <Poor Grim, slaving his life away.>"
    new "1. <Pobre Parca, esclavizado toda su vida.>"

    # game/chapters/2_day.rpy:89
    old "1. <What are you doing, anyway?>"
    new "1. <¿Qué estás haciendo, de todos modos?>"

    # game/chapters/2_day.rpy:92
    old "2. <Hello, [playername] to Grim. [playername] to Grim.>"
    new "2. <Hola, [playername] a Parca. [playername] a Parca.>"

    # game/chapters/2_day.rpy:95
    old "1. <Come in Grim.>"
    new "1. <Adelante, Parca.>"

    # game/chapters/2_day.rpy:98
    old "1. <[playername] to Grim.>"
    new "1. <[playername] a Parca.>"

    # game/chapters/2_day.rpy:101
    old "3. <Where are you, my little Grim?> {font=gui/starthings.ttf}a{/font}"
    new "3. <¿Dónde estás, mi Parquita?> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/2_day.rpy:105
    old "1. <Found something more entertaining than talking to me?>"
    new "1. <¿Encontraste algo más entretenido que hablar conmigo?>"

    # game/chapters/2_day.rpy:108
    old "1. <Probably impossible, tbh.>"
    new "1. <Probablemente imposible, la verdad.>"

    # game/chapters/2_day.rpy:111
    old "1. <Hey, I had a crazy thought.>"
    new "1. <Oye, tuve un pensamiento loco.>"

    # game/chapters/2_day.rpy:114
    old "1. <Imagine if we just ran away and got married.>"
    new "1. <Imagina que simplemente nos fugamos y nos casamos.>"

    # game/chapters/2_day.rpy:117
    old "1. <We could have the reception here and the ceremony in super hell.>"
    new "1. <Podríamos tener la recepción aquí y la ceremonia en el súper infierno.>"

    # game/chapters/2_day.rpy:123
    old "1. <Even that isn't enough to get your attention?>"
    new "1. <¿Ni siquiera eso basta para llamar tu atención?>"

    # game/chapters/2_day.rpy:130
    old "1. <I still have my soul, btw.>"
    new "1. <Por cierto, todavía tengo mi alma.>"

    # game/chapters/2_day.rpy:133
    old "1. <So much for 'I need only a day, an hour!'>"
    new "1. <Adiós a eso de '¡Solo necesito un día, una hora!'.>"

    # game/chapters/2_day.rpy:137
    old "1. <I saw you talking to yourself yesterday before I responded, you know.>"
    new "1. <Te vi hablando solo ayer antes de que yo respondiera, ¿sabes?>"

    # game/chapters/2_day.rpy:149
    old "1. <I only said it to get your attention.>"
    new "1. <Solo lo dije para llamar tu atención.>"

    # game/chapters/2_day.rpy:152
    old "2. <tbh I'd marry you.>"
    new "2. <Sinceramente, me casaría contigo.>"

    # game/chapters/2_day.rpy:156
    old "1. <You are very handsome.>"
    new "1. <Eres muy guapo.>"

    # game/chapters/2_day.rpy:158
    old "2. <You're funny.>"
    new "2. <Eres gracioso.>"

    # game/chapters/2_day.rpy:160
    old "3. <I want to tease you forever.>"
    new "3. <Quiero molestarte para siempre.>"

    # game/chapters/2_day.rpy:162
    old "4. <The heart wants what the heart wants.>"
    new "4. <El corazón sabe lo que quiere.>"

    # game/chapters/2_day.rpy:170
    old "1. <Nope. I'm all alone.>"
    new "1. <Nop. No tengo a nadie.>"

    # game/chapters/2_day.rpy:175
    old "1. <...Nope. Not at all.>"
    new "1. <...Nop. Para nada.>"

    # game/chapters/2_day.rpy:180
    old "1. <I was {i}not{/i} lonely waiting for you!>"
    new "1. <¡{i}No{/i} me sentí sol[letra] mientras te esperaba!>"

    # game/chapters/2_day.rpy:189
    old "1. <Now who's talking to himself?>"
    new "1. <Ahora, ¿quién habla solo?>"

    # game/chapters/2_day.rpy:192
    old "2. <Yeah okay I was a little lonely...>"
    new "2. <Sí, okey, me sentía un poquito sol[letra]...>"

    # game/chapters/2_day.rpy:204
    old "2. <Well kinda, actually.>"
    new "2. <Bueno, sí, un poco, la verdad.>"

    # game/chapters/2_day.rpy:211
    old "1. <Of {i}course{/i} they do. I definitely believe that.>"
    new "1. <Por {i}supuesto{/i} que sí. Sin duda lo creo.>"

    # game/chapters/2_day.rpy:219
    old "2. <tbh I can't lie, you are good looking...>"
    new "2. <Sinceramente, no puedo mentir, eres guapo...>"

    # game/chapters/2_day.rpy:221
    old "3. <No comment. None at all.>"
    new "3. <Sin comentarios. Ninguno en absoluto.>"

    # game/chapters/2_day.rpy:228
    old "3. <Me, lonely?>"
    new "3. <¿Yo, sol[letra]?>"

    # game/chapters/2_day.rpy:231
    old "1. <You seem more like the lonely one.>"
    new "1. <Tú pareces más bien el solitario.>"

    # game/chapters/2_day.rpy:236
    old "1. <Sounds like something a really lonely person would say.>"
    new "1. <Suena a algo que diría una persona realmente sola.>"

    # game/chapters/2_day.rpy:245
    old "4. <Am I not allowed to feel lonely while waiting for you?> {font=gui/starthings.ttf}a{/font}"
    new "4. <¿Acaso no puedo sentirme sol[letra] mientras te espero?> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/2_day.rpy:250
    old "1. <I didn't say I needed you...>"
    new "1. <Yo no dije que te necesitara...>"

    # game/chapters/2_day.rpy:255
    old "1. <I'm not caught in your web, Grim.>"
    new "1. <No estoy en tu telaraña, Parca.>"

    # game/chapters/2_day.rpy:258
    old "1. <Plus, as far as I know, 'Grim Reapers' can't make webs.>"
    new "1. <Además, que yo sepa, las 'Parcas' no pueden tejer telarañas.>"

    # game/chapters/2_day.rpy:261
    old "1. <Next you're gonna be telling me you're part spider or something.>"
    new "1. <Lo siguiente será que me digas que eres parte araña o algo así.>"

    # game/chapters/2_day.rpy:264
    old "1. <Spider-Grim.>"
    new "1. <Parca-Araña.>"

    # game/chapters/2_day.rpy:269
    old "1. <A... what?>"
    new "1. <¿Un... qué?>"

    # game/chapters/2_day.rpy:273
    old "1. <Do you mean... a figure of speech?>"
    new "1. <¿Te refieres a... una figura retórica?>"

    # game/chapters/2_day.rpy:281
    old "1. <I was just bored.>"
    new "1. <Simplemente me aburría.>"

    # game/chapters/2_day.rpy:283
    old "2. <Okay, I was kinda waiting for you.>"
    new "2. <Okey, de cierto modo te estaba esperando.>"

    # game/chapters/2_day.rpy:285
    old "3. <I was waiting for you for ages!> {font=gui/starthings.ttf}a{/font}"
    new "3. <¡Te estuve esperando siglos!> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/2_day.rpy:288
    old "1. <What took you so long?>"
    new "1. <¿Qué te tomó tanto tiempo?>"

    # game/chapters/2_day.rpy:293
    old "1. <Oh, I am.>"
    new "1. <Oh, claro que sí.>"

    # game/chapters/2_day.rpy:296
    old "1. <But messing with you is the most fun.>"
    new "1. <Pero molestarte es mucho más divertido.>"

    # game/chapters/2_day.rpy:301
    old "1. <I half expected someone to jump out at me all day.>"
    new "1. <Pasé todo el día medio esperando que alguien saltara frente a mí.>"

    # game/chapters/2_day.rpy:304
    old "1. <To, you know, 'steal my soul' or whatever.>"
    new "1. <Para, ya sabes, 'robarme el alma' o lo que sea.>"

    # game/chapters/2_day.rpy:307
    old "1. <No sign of any reapers.>"
    new "1. <Ni rastro de parcas.>"

    # game/chapters/2_day.rpy:316
    old "1. <Waiting to see you make a fool of yourself :D>"
    new "1. <Esperando verte hacer el ridículo :D>"

    # game/chapters/2_day.rpy:320
    old "1. <Come up with your own insult.>"
    new "1. <Inventa tu propio insulto.>"

    # game/chapters/2_day.rpy:323
    old "1. <Or is copying a 'mortal' the best you can do?>"
    new "1. <¿O copiar a [arti_2] 'mortal' es lo mejor que puedes hacer?>"

    # game/chapters/2_day.rpy:328
    old "1. <Oh yeah?>"
    new "1. <¿Ah, sí?>"

    # game/chapters/2_day.rpy:331
    old "1. <Try me.>"
    new "1. <A ver, inténtalo.>"

    # game/chapters/2_day.rpy:342
    old "2. <Oh...>"
    new "2. <Oh...>"

    # game/chapters/2_day.rpy:344
    old "3. <Hm...>"
    new "3. <Hm...>"

    # game/chapters/2_day.rpy:346
    old "4. <Uh...>"
    new "4. <Uh...>"

    # game/chapters/2_day.rpy:349
    old "1. <Is that it...?>"
    new "1. <¿Eso es todo...?>"

    # game/chapters/2_day.rpy:355
    old "1. <You... tried your best.>"
    new "1. <Tú... hiciste lo que pudiste.>"

    # game/chapters/2_day.rpy:358
    old "1. <Anyway... I'm just going to move on from that.>"
    new "1. <En fin... mejor dejemos eso atrás.>"

    # game/chapters/2_day.rpy:362
    old "2. <I suppose we'll be fools together, then.>"
    new "2. <Supongo que seremos ridículos juntos, entonces.>"

    # game/chapters/2_day.rpy:366
    old "1. <Just two silly fools :)>"
    new "1. <Solo dos tontos :)>"

    # game/chapters/2_day.rpy:370
    old "2. <I didn't see you once. A shame.>"
    new "2. <No te vi ni una vez. Una pena.>"

    # game/chapters/2_day.rpy:376
    old "1. <You're gonna turn up at my place in the middle of the night?>"
    new "1. <¿Vas a aparecerte en mi casa en medio de la noche?>"

    # game/chapters/2_day.rpy:382
    old "1. <I'll get myself dressed up all fancy, then.>"
    new "1. <Entonces me arreglaré bien elegante.>"

    # game/chapters/2_day.rpy:386
    old "1. <We'll make a special night out of it.>"
    new "1. <Haremos que sea una noche especial.>"

    # game/chapters/2_day.rpy:391
    old "1. <Right, the bet.>"
    new "1. <Cierto, la apuesta.>"

    # game/chapters/2_day.rpy:394
    old "1. <The one that's totally real.>"
    new "1. <La que es totalmente real.>"

    # game/chapters/2_day.rpy:397
    old "1. <The bet I have with the literal Grim Reaper.>"
    new "1. <La apuesta que tengo con la mismísima Parca.>"

    # game/chapters/2_day.rpy:405
    old "1. <I can't wait, you know.>"
    new "1. <No puedo esperar, ¿sabes?>"

    # game/chapters/2_day.rpy:410
    old "1. <I can't wait for the day where you have to admit that you're a liar.>"
    new "1. <No puedo esperar al día en que tengas que admitir que eres un mentiroso.>"

    # game/chapters/2_day.rpy:414
    old "1. <That you, too, are just a 'poor mortal'.>"
    new "1. <Que tú también eres solo un 'pobre mortal'.>"

    # game/chapters/2_day.rpy:419
    old "1. <Yeah? So why am I still here?>"
    new "1. <¿Ah, sí? ¿Entonces por qué sigo aquí?>"

    # game/chapters/2_day.rpy:423
    old "1. <Didn't you say you'd have my soul in an hour?>"
    new "1. <¿No dijiste que tendrías mi alma en una hora?>"

    # game/chapters/2_day.rpy:426
    old "2. <Honestly, I'm surprised someone as powerful as you is taking so long.>"
    new "2. <Sinceramente, me sorprende que alguien tan poderoso como tú esté tardando tanto.>"

    # game/chapters/2_day.rpy:431
    old "1. <What have you been doing today, then?>"
    new "1. <¿Qué has estado haciendo hoy, entonces?>"

    # game/chapters/2_day.rpy:434
    old "1. <Stealing other poor mortal souls?>"
    new "1. <¿Robando las almas de otros pobres mortales?>"

    # game/chapters/2_day.rpy:437
    old "1. <Here I thought I was special...>"
    new "1. <Yo que pensaba que era especial...>"

    # game/chapters/2_day.rpy:441
    old "1. <Maybe. Maybe not.>"
    new "1. <Tal vez sí. Tal vez no.>"

    # game/chapters/2_day.rpy:444
    old "2. <Could be. Or maybe I couldn't care less.>"
    new "2. <Puede ser. O quizá me importe un comino.>"

    # game/chapters/2_day.rpy:447
    old "3. <Actually, yes.>"
    new "3. <En realidad, sí.>"

    # game/chapters/2_day.rpy:450
    old "4. <Is that any real surprise?>"
    new "4. <¿Eso realmente te sorprende?>"

    # game/chapters/2_day.rpy:453
    old "1. <You're the Grim Reaper. It's only natural, right?>"
    new "1. <Eres la Parca. Es lo natural, ¿no?>"

    # game/chapters/2_day.rpy:457
    old "1. <By the way, is that you in your pfp?>"
    new "1. <Por cierto, ¿ese eres tú en tu foto de perfil?>"

    # game/chapters/2_day.rpy:460
    old "1. <Is that a selfie?>"
    new "1. <¿Es un selfie?>"

    # game/chapters/2_day.rpy:466
    old "1. <You're so embarrassing.>"
    new "1. <Qué vergüenza contigo.>"

    # game/chapters/2_day.rpy:468
    old "2. <That's almost cute.>"
    new "2. <Eso es hasta tierno.>"

    # game/chapters/2_day.rpy:472
    old "1. <I bet you took it just for me.>"
    new "1. <Apuesto a que la tomaste solo para mí.>"

    # game/chapters/2_day.rpy:476
    old "1. <You're pretty much obsessed with me, aren't you?>"
    new "1. <Estás bastante obsesionado conmigo, ¿no?>"

    # game/chapters/2_day.rpy:487
    old "1. <Work, obviously.>"
    new "1. <Trabajo, obviamente.>"

    # game/chapters/2_day.rpy:489
    old "2. <The bills don't pay themselves.>"
    new "2. <Las cuentas no se pagan solas.>"

    # game/chapters/2_day.rpy:491
    old "3. <Slaving away my life for other people...>"
    new "3. <Esclavizando mi vida para otros...>"

    # game/chapters/2_day.rpy:496
    old "1. <Who's interested in whose day to day life now?>"
    new "1. <¿Quién está interesado ahora en la vida cotidiana de quién?>"

    # game/chapters/2_day.rpy:499
    old "1. <I work as a mortician, actually...>"
    new "1. <En realidad, trabajo en una funeraria...>"

    # game/chapters/2_day.rpy:508
    old "1. <I'm so glad you find my profession hilarious...>"
    new "1. <Me alegra mucho que encuentres mi profesión graciosa...>"

    # game/chapters/2_day.rpy:511
    old "2. <I have to admit, it's a little funny.>"
    new "2. <Tengo que admitirlo, es un poco gracioso.>"

    # game/chapters/2_day.rpy:520
    old "1. <Maybe we were fated to meet :)>"
    new "1. <Quizás estábamos destinados a encontrarnos :)>"

    # game/chapters/2_day.rpy:524
    old "2. <One of us definitely does. I'm not sure about the other ;)>"
    new "2. <Uno de nosotros seguro que sí. No estoy tan segur[letra] del otro ;)>"

    # game/chapters/2_day.rpy:532
    old "2. <I do freelance.>"
    new "2. <Trabajo por cuenta propia.>"

    # game/chapters/2_day.rpy:537
    old "1. <Yeah, most of the time.>"
    new "1. <Sí, la mayor parte del tiempo.>"

    # game/chapters/2_day.rpy:541
    old "1. <Jealous?>"
    new "1. <¿Celoso?>"

    # game/chapters/2_day.rpy:548
    old "1. <Just admit it.>"
    new "1. <Admítelo.>"

    # game/chapters/2_day.rpy:553
    old "1. <Sure ;)>"
    new "1. <Claro ;)>"

    # game/chapters/2_day.rpy:558
    old "2. <You should try.>"
    new "2. <Deberías intentarlo.>"

    # game/chapters/2_day.rpy:564
    old "3. <I work in fashion.>"
    new "3. <Yo trabajo en el sector de la moda.>"

    # game/chapters/2_day.rpy:569
    old "1. <What's that supposed to mean...>"
    new "1. <¿Qué se supone que significa eso...?>"

    # game/chapters/2_day.rpy:573
    old "1. <Well, yeah?>"
    new "1. <Bueno, ¿sí?>"

    # game/chapters/2_day.rpy:575
    old "2. <No, but I picked it very carefully.>"
    new "2. <No, pero la elegí con mucho cuidado.>"

    # game/chapters/2_day.rpy:586
    old "2. <Take a look in the mirror.>"
    new "2. <Mírate en el espejo.>"

    # game/chapters/2_day.rpy:590
    old "4. <I work in a school, teaching.>"
    new "4. <Yo trabajo en una escuela, enseñando.>"

    # game/chapters/2_day.rpy:596
    old "1. <I enjoy it, thank you very much.>"
    new "1. <Lo disfruto mucho, muchas gracias.>"

    # game/chapters/2_day.rpy:600
    old "2. <Okay, I can understand the reaction.>"
    new "2. <Okey, puedo entender la reacción.>"

    # game/chapters/2_day.rpy:607
    old "1. <They are sweet! Mostly...>"
    new "1. <¡Son dulces! En su mayoría...>"

    # game/chapters/2_day.rpy:610
    old "2. <Yes, okay, fair.>"
    new "2. <Sí, okey, tienes razón.>"

    # game/chapters/2_day.rpy:615
    old "5. <I make computer games.>"
    new "5. <Hago videojuegos.>"

    # game/chapters/2_day.rpy:620
    old "1. <It does?>"
    new "1. <¿Sí?>"

    # game/chapters/2_day.rpy:623
    old "2. <Thank you...?>"
    new "2. <¿Gracias...?>"

    # game/chapters/2_day.rpy:627
    old "1. <I'm hoping that's a good thing...>"
    new "1. <Espero que eso sea algo bueno...>"

    # game/chapters/2_day.rpy:632
    old "1. <Aren't you going to ask if I've made anything you've played?>"
    new "1. <¿No vas a preguntar si he hecho algo que hayas jugado?>"

    # game/chapters/2_day.rpy:635
    old "1. <That's usually someone's first question.>"
    new "1. <Esa suele ser la primera pregunta de alguien.>"

    # game/chapters/2_day.rpy:645
    old "1. <I... hadn't expected you to think that.>"
    new "1. <Yo... no esperaba que pensaras eso.>"

    # game/chapters/2_day.rpy:653
    old "6. <I'm an artist.>"
    new "6. <Soy artista.>"

    # game/chapters/2_day.rpy:663
    old "1. <I think you're kinda obsessed with yourself, ngl.>"
    new "1. <Creo que estás un poquito obsesionado contigo mismo, la verdad.>"

    # game/chapters/2_day.rpy:668
    old "1. <Not really...>"
    new "1. <La verdad no...>"

    # game/chapters/2_day.rpy:675
    old "1. <No answer.>"
    new "1. <Sin comentarios.>"

    # game/chapters/2_day.rpy:680
    old "2. <I... was just bored.>"
    new "2. <Yo... simplemente estaba aburrid[letra].>"

    # game/chapters/2_day.rpy:685
    old "2. <I, uh... maybe...>"
    new "2. <Yo, eh... tal vez...>"

    # game/chapters/2_day.rpy:691
    old "1. <Obsessed is a little much.>"
    new "1. <Llamarlo obsesión es un poco exagerado.>"

    # game/chapters/2_day.rpy:697
    old "2. <Look, you are pretty, okay?>"
    new "2. <Mira, eres bonito, ¿ok?>"

    # game/chapters/2_day.rpy:704
    old "3. <Yeah. You do seem like a catch.>"
    new "3. <Sí. La verdad es que pareces todo un partidazo.>"

    # game/chapters/2_day.rpy:717
    old "1. <Fine, I drew you.>"
    new "1. <Está bien, te dibujé.>"

    # game/chapters/2_day.rpy:724
    old "1. <Well, that depends.>"
    new "1. <Bueno, depende.>"

    # game/chapters/2_day.rpy:728
    old "1. <If you be a good boy.>"
    new "1. <Si eres un buen chico.>"

    # game/chapters/2_day.rpy:734
    old "1. <Now there's an idea.>"
    new "1. <Esa sí que es una buena idea.>"

    # game/chapters/2_day.rpy:738
    old "1. <Say woof and I'll send it to you.>"
    new "1. <Di 'guau' y te la envío.>"

    # game/chapters/2_day.rpy:750
    old "1. <Maybe for the right person ;)>"
    new "1. <Quizá por la persona indicada ;)>"

    # game/chapters/2_day.rpy:755
    old "2. <Yet.>"
    new "2. <Aún.>"

    # game/chapters/2_day.rpy:760
    old "3. <I do. Woof.>"
    new "3. <Yo sí. *Guau Guau*.>"

    # game/chapters/2_day.rpy:767
    old "4. <No art for you, though.>"
    new "4. <Pero tú no tendrás el dibujo.>"

    # game/chapters/2_day.rpy:774
    old "1. <Back to the topic on hand, though...>"
    new "1. <Volviendo al tema que nos ocupa...>"

    # game/chapters/2_day.rpy:778
    old "2. <Go on. Just one little bark.>"
    new "2. <Vamos. Solo un ladrido.>"

    # game/chapters/2_day.rpy:784
    old "1. <You... you actually did it...>"
    new "1. <Tú... en serio lo hiciste...>"

    # game/chapters/2_day.rpy:790
    old "1. <How do I send it, then?>"
    new "1. <¿Cómo te lo envío, entonces?>"

    # game/chapters/2_day.rpy:793
    old "1. <There doesn't seem to be a function for sending images.>"
    new "1. <No parece haber una función para enviar imágenes.>"

    # game/chapters/2_day.rpy:798
    old "1. <Don't tell me you forgot to put in such a key feature...>"
    new "1. <No me digas que olvidaste poner una característica tan importante...>"

    # game/chapters/2_day.rpy:806
    old "1. <Here I come, Twotter. #TheGrimReaperSmells.>"
    new "1. <¡Allá voy, Twotter! #LaParcaHueleMal>"

    # game/chapters/2_day.rpy:815
    old "2. <Say pretty please and I'll send it to you.>"
    new "2. <Di porfis y te la envío.>"

    # game/chapters/2_day.rpy:821
    old "1. <Aww, you don't want to see it?>"
    new "1. <Aww, ¿no quieres verla?>"

    # game/chapters/2_day.rpy:826
    old "1. <Well, if you change your mind, I'll post it on Twotter. #TheGrimReaperSmells.>"
    new "1. <Bueno, si cambias de opinión, la subiré a Twotter. #LaParcaHueleMal.>"

    # game/chapters/2_day.rpy:831
    old "1. <But it's so fun...>"
    new "1. <Pero es tan divertido...>"

    # game/chapters/2_day.rpy:835
    old "2. <I actually haven't drawn you. Yet.>"
    new "2. <En realidad no te he dibujado. Aún.>"

    # game/chapters/2_day.rpy:844
    old "1. <I can think of one or two.>"
    new "1. <Puedo pensar en una o dos.>"

    # game/chapters/2_day.rpy:849
    old "2. <Ask me nicely and I might do it.>"
    new "2. <Pídemelo amablemente y quizá lo haga.>"

    # game/chapters/2_day.rpy:856
    old "7. <I'm an animal attendant.>"
    new "7. <Me dedico al cuidado de animales.>"

    # game/chapters/2_day.rpy:862
    old "1. <What, why?>"
    new "1. <¿Qué, por qué?>"

    # game/chapters/2_day.rpy:867
    old "1. <Oh! [pet_name]!>"
    new "1. <¡Oh! ¡[pet_name]!>"

    # game/chapters/2_day.rpy:870
    old "1. <[pet_She]'s just the cutest, don't you think?>"
    new "1. <[pet_She!t] es [arti_pet] más lind[letra_pet], ¿no crees?>"

    # game/chapters/2_day.rpy:875
    old "1. <And [pet_she] is the cutest of them all.>"
    new "1. <Y [pet_she!t] es [arti_pet] más lind[letra_pet] de tod[letra_pet]s.>"

    # game/chapters/2_day.rpy:881
    old "1. <What is, then?>"
    new "1. <¿Entonces cuál es?>"

    # game/chapters/2_day.rpy:887
    old "1. <Okay, they're pretty cute.>"
    new "1. <Okey, son bastante lindos.>"

    # game/chapters/2_day.rpy:891
    old "2. <They're okay, but not as cute as [pet_name].>"
    new "2. <Son lindos, pero no tanto como [pet_name].>"

    # game/chapters/2_day.rpy:898
    old "2. <Like you?>"
    new "2. <¿Como tú?>"

    # game/chapters/2_day.rpy:905
    old "1. <Okay cutie :)>"
    new "1. <Okey, lindura :)>"

    # game/chapters/2_day.rpy:911
    old "8. <I'm an author, actually.>"
    new "8. <En realidad, me dedico a la escritura.>"

    # game/chapters/2_day.rpy:916
    old "1. <Uh huh. I grew up writing stories.>"
    new "1. <Uh ajá. Crecí escribiendo historias.>"

    # game/chapters/2_day.rpy:919
    old "1. <Kinda been a lifelong dream of mine.>"
    new "1. <Ha sido uno de mis sueños desde siempre.>"

    # game/chapters/2_day.rpy:924
    old "1. <Is that a good thing?>"
    new "1. <¿Eso es algo bueno?>"

    # game/chapters/2_day.rpy:930
    old "1. <Wait, is that a compliment?>"
    new "1. <Espera, ¿eso es un cumplido?>"

    # game/chapters/2_day.rpy:935
    old "2. <Why do you sound so surprised?>"
    new "2. <¿Por qué suenas tan sorprendido?>"

    # game/chapters/2_day.rpy:941
    old "1. <Fantasy.>"
    new "1. <Fantasía.>"

    # game/chapters/2_day.rpy:943
    old "2. <Romance.>"
    new "2. <Romance.>"

    # game/chapters/2_day.rpy:945
    old "3. <Non-fiction.>"
    new "3. <No ficción.>"

    # game/chapters/2_day.rpy:947
    old "4. <Murder mysteries.>"
    new "4. <Misterios policiales.>"

    # game/chapters/2_day.rpy:953
    old "1. <Really?>"
    new "1. <¿En serio?>"

    # game/chapters/2_day.rpy:961
    old "1. <Oh. Well, thanks.>"
    new "1. <Oh. Bueno, gracias.>"

    # game/chapters/2_day.rpy:970
    old "1. <I'm guessing you'd just tell me your job was being 'the reaper' if I asked?>"
    new "1. <Y supongo que me dirías que tu trabajo es ser 'la parca' si te lo preguntara.>"

    # game/chapters/2_day.rpy:978
    old "2. <That's... a little sad.>"
    new "2. <Eso... suena un poco triste.>"

    # game/chapters/2_day.rpy:982
    old "1. <How do you do it, then?>"
    new "1. <¿Cómo lo haces, entonces?>"

    # game/chapters/2_day.rpy:985
    old "1. <Stick your hand into their chest and pull it right out?>"
    new "1. <¿Metes la mano en el pecho y la sacas de golpe?>"

    # game/chapters/2_day.rpy:988
    old "1. <Stick your teeth into their neck, vampire style?>"
    new "1. <¿Les clavas los dientes en el cuello, estilo vampiro?>"

    # game/chapters/2_day.rpy:995
    old "1. <White haired vampires are {i}in{/i} right now.>"
    new "1. <Los vampiros de pelo blanco están {i}de moda{/i} ahora.>"

    # game/chapters/2_day.rpy:999
    old "1. <Super in.>"
    new "1. <Super de moda.>"

    # game/chapters/2_day.rpy:1002
    old "1. <Honestly, if you're looking for a profession change, I'd keep it in mind.>"
    new "1. <Honestamente, si buscas un cambio de profesión, yo lo tendría en cuenta.>"

    # game/chapters/2_day.rpy:1007
    old "2. <Then how {b}do{/b} you do it?>"
    new "2. <Entonces, ¿cómo lo {b}haces{/b}?>"

    # game/chapters/2_day.rpy:1014
    old "1. <Not really feeling it, sorry.>"
    new "1. <No me convence mucho, lo siento.>"

    # game/chapters/2_day.rpy:1018
    old "2. <We'll see about that.>"
    new "2. <Ya veremos.>"

    # game/chapters/2_day.rpy:1021
    old "2. <How about lust?>"
    new "2. <¿Y qué hay de la lujuria?>"

    # game/chapters/2_day.rpy:1027
    old "3. <Then I suppose I'll offer myself up to you.>"
    new "3. <Entonces supongo que me ofreceré a ti.>"

    # game/chapters/2_day.rpy:1031
    old "1. <I'm waiting :D>"
    new "1. <Estoy esperando :D>"

    # game/chapters/2_day.rpy:1037
    old "1. <Just kidding >:D>"
    new "1. <Es broma >:D>"

    # game/chapters/2_day.rpy:1041
    old "1. <If I gave myself up that easily, then we wouldn't get to talk anymore :(>"
    new "1. <Si me entregara tan fácilmente, entonces ya no podríamos hablar más :(>"

    # game/chapters/2_day.rpy:1047
    old "1. <If not friend, why friend-shaped?>"
    new "1. <Si no eres un amigo, ¿por qué tienes forma de amigo?>"

    # game/chapters/2_day.rpy:1055
    old "1. <I think you're more like a circle :)>"
    new "1. <Yo creo que eres más como un círculo :)>"

    # game/chapters/2_day.rpy:1058
    old "1. <It's like the endless cycle of life and death.>"
    new "1. <Es como el ciclo interminable de la vida y la muerte.>"

    # game/chapters/2_day.rpy:1062
    old "2. <You're a square!>"
    new "2. <¡Eres un cuadrado!>"

    # game/chapters/2_day.rpy:1065
    old "1. <You seem very stable and ordered.>"
    new "1. <Pareces muy estable y ordenado.>"

    # game/chapters/2_day.rpy:1070
    old "2. <Then how about something more than friends?>"
    new "2. <Entonces, ¿qué tal algo más que amigos?>"

    # game/chapters/2_day.rpy:1075
    old "1. <I mean, that would be cool too.>"
    new "1. <Quiero decir, eso también estaría bien.>"

    # game/chapters/2_day.rpy:1081
    old "2. <More again.>"
    new "2. <Más que eso.>"

    # game/chapters/2_day.rpy:1088
    old "1. <That seems a little sad.>"
    new "1. <Eso suena un poco triste.>"

    # game/chapters/2_day.rpy:1095
    old "1. <Maybe it'll change one day.>"
    new "1. <Quizá cambie algún día.>"

    # game/chapters/2_day.rpy:1100
    old "3. <I'd be happy to offer up my neck for you.> {font=gui/starthings.ttf}a{/font}"
    new "3. <Yo estaría feliz de ofrecerte mi cuello.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/2_day.rpy:1103
    old "1. <You would definitely make a good vampire.>"
    new "1. <Definitivamente serías un buen vampiro.>"

    # game/chapters/2_day.rpy:1110
    old "1. <I mean, it's pretty simple.>"
    new "1. <Quiero decir, es bastante simple.>"

    # game/chapters/2_day.rpy:1113
    old "1. <Vampires are kinda hot.>"
    new "1. <Los vampiros son bastante sexys.>"

    # game/chapters/2_day.rpy:1119
    old "1. <Do you even need me to tell you?>"
    new "1. <¿De verdad necesitas que te lo diga?>"

    # game/chapters/2_day.rpy:1125
    old "1. <Completely unsurprising.>"
    new "1. <Completamente predecible.>"

    # game/chapters/2_day.rpy:1129
    old "1. <If you were a vampire, where would you bite me?>"
    new "1. <Si fueras un vampiro, ¿dónde me morderías?>"

    # game/chapters/2_day.rpy:1135
    old "1. <Don't be so vanilla.>"
    new "1. <No seas tan aburrido.>"

    # game/chapters/2_day.rpy:1138
    old "1. <Fine, I'll pick for you.>"
    new "1. <Bien, lo elegiré por ti.>"

    # game/chapters/2_day.rpy:1144
    old "1. <My collarbone?>"
    new "1. <¿Mi clavícula?>"

    # game/chapters/2_day.rpy:1146
    old "2. <My wrist?>"
    new "2. <¿Mi muñeca?>"

    # game/chapters/2_day.rpy:1148
    old "3. <My thigh?>"
    new "3. <¿Mi muslo?>"

    # game/chapters/2_day.rpy:1154
    old "1. <Close and personal?>"
    new "1. <¿Íntimo y personal?>"

    # game/chapters/2_day.rpy:1158
    old "1. <If you're a vampire, that's okay.>"
    new "1. <Si eres un vampiro, está bien.>"

    # game/chapters/2_day.rpy:1162
    old "1. <Own your sexiness.>"
    new "1. <Asume tu sensualidad.>"

    # game/chapters/2_day.rpy:1171
    old "1. <If I was a vampire, I would bite you all over :D>"
    new "1. <Si yo fuera un vampiro, te mordería por todas partes :D>"

    # game/chapters/2_day.rpy:1175
    old "1. <I'd leave little love marks everywhere.>"
    new "1. <Te dejaría pequeñas marcas de amor por todos lados.>"

    # game/chapters/2_day.rpy:1179
    old "1. <I mean, if that was okay with you.>"
    new "1. <Quiero decir, si eso te pareciera bien.>"

    # game/chapters/2_day.rpy:1184
    old "1. <No?>"
    new "1. <¿No?>"

    # game/chapters/2_day.rpy:1194
    old "1. <Back to the matter at hand.>"
    new "1. <Volvamos al asunto en cuestión.>"

    # game/chapters/2_day.rpy:1198
    old "1. <Do you have a daily quota you have to fill, soul wise?>"
    new "1. <¿Tienes una cuota diaria que cumplir, de almas?>"

    # game/chapters/2_day.rpy:1202
    old "1. <What if you don't get enough one day?>"
    new "1. <¿Qué pasa si un día no consigues suficientes?>"

    # game/chapters/2_day.rpy:1205
    old "1. <Pick a random human and they'll do?>"
    new "1. <¿Eliges a un humano al azar y ya?>"

    # game/chapters/2_day.rpy:1212
    old "1. <Aww... so you didn't pick me out?>"
    new "1. <Aww... ¿entonces no me elegiste a mí?>"

    # game/chapters/2_day.rpy:1215
    old "1. <That's kinda sad :/>"
    new "1. <Eso es un poco triste :/>"

    # game/chapters/2_day.rpy:1218
    old "2. <And here I thought I was special.>"
    new "2. <Y yo que pensaba que era especial.>"

    # game/chapters/2_day.rpy:1225
    old "1. <Why not? Would that not be more exciting for you, Grim?>"
    new "1. <¿Por qué no? ¿No sería más emocionante para ti, Parca?>"

    # game/chapters/2_day.rpy:1229
    old "2. <Okay, I can understand why, but...>"
    new "2. <Okey, lo entiendo, pero...>"

    # game/chapters/2_day.rpy:1232
    old "1. <If I was the grim reaper...>"
    new "1. <Si yo fuera la parca...>"

    # game/chapters/2_day.rpy:1235
    old "1. <I'd take all the souls. Mwahahahaha.>"
    new "1. <Me quedaría con todas las almas. Muajajajaja.>"

    # game/chapters/2_day.rpy:1238
    old "2. <I'd let everyone live extra long lives.>"
    new "2. <Dejaría vivir a todos vidas extra largas.>"

    # game/chapters/2_day.rpy:1241
    old "3. <I'd get a promotion and be your boss :)> {font=gui/starthings.ttf}a{/font}"
    new "3. <Conseguiría un ascenso y sería tu jefe :)> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/2_day.rpy:1245
    old "1. <Bet you'd like that. Being bossed around by me :)>"
    new "1. <Apuesto a que te gustaría eso. Que yo te mandara :)>"

    # game/chapters/2_day.rpy:1250
    old "1. <What do you mean? :)>"
    new "1. <¿Qué quieres decir? :)>"

    # game/chapters/2_day.rpy:1253
    old "1. <Are you saying you wouldn't like it? :)>"
    new "1. <¿Estás diciendo que no te gustaría? :)>"

    # game/chapters/2_day.rpy:1257
    old "1. <Ooooh. That's basically a confession.>"
    new "1. <Ooooh. Eso básicamente es una confesión.>"

    # game/chapters/2_day.rpy:1262
    old "1. <'A' grim reaper seems to imply there are multiple.>"
    new "1. <Decir 'una' parca implica que hay varias.>"

    # game/chapters/2_day.rpy:1269
    old "1. <Hmm... but surely the very best...>"
    new "1. <Hmm... pero sin duda el mejor...>"

    # game/chapters/2_day.rpy:1272
    old "1. <Would have had my soul by now...>"
    new "1. <Ya tendría mi alma a estas alturas...>"

    # game/chapters/2_day.rpy:1279
    old "1. <Why don't you tell me about them, then?>"
    new "1. <¿Por qué no me cuentas cuáles son, entonces?>"

    # game/chapters/2_day.rpy:1282
    old "2. <Oh! I'm a good listener. Lay them on me.>"
    new "2. <¡Oh! Sé escuchar. ¡Cuéntamelo todo!>"

    # game/chapters/2_day.rpy:1285
    old "3. <I struggle plenty in life. You can tell me.>"
    new "3. <Yo también tengo mis problemas. Puedes contármelos.>"

    # game/chapters/2_day.rpy:1290
    old "1. <Woah, all caps.>"
    new "1. <Uy, todo en mayúsculas.>"

    # game/chapters/2_day.rpy:1296
    old "1. <My bad, I didn't realize it would inconvenience you.>"
    new "1. <Mi error, no me di cuenta de que te incomodaba.>"

    # game/chapters/2_day.rpy:1299
    old "2. <I {i}really{/i} am so very sorry, Mr Grim Reaper.>"
    new "2. <Lo {i}siento{/i} muchísimo, Sr. Parca.>"

    # game/chapters/2_day.rpy:1302
    old "3. <Honestly, I do feel a little guilty. Sorry.>"
    new "3. <En serio, me siento un poco culpable. Perdón.>"

    # game/chapters/2_day.rpy:1310
    old "2. <No.>"
    new "2. <No.>"

    # game/chapters/2_day.rpy:1313
    old "3. <Absolutely not.>"
    new "3. <Absolutamente no.>"

    # game/chapters/2_day.rpy:1318
    old "1. <Only a thousand?>"
    new "1. <¿Solo mil?>"

    # game/chapters/2_day.rpy:1321
    old "1. <Weak.>"
    new "1. <Débil.>"

    # game/chapters/2_day.rpy:1325
    old "1. <Nothing?>"
    new "1. <¿Nada?>"

    # game/chapters/2_day.rpy:1329
    old "1. <What about your love for me? ;)>"
    new "1. <¿Y tu amor por mí? ;)>"

    # game/chapters/2_day.rpy:1333
    old "2. <What about your want for me ;)>"
    new "2. <¿Y tu deseo por mí? ;)>"

    # game/chapters/2_day.rpy:1338
    old "1. <You're saying that's not weak?>"
    new "1. <¿Dices que eso no es débil?>"

    # game/chapters/2_day.rpy:1346
    old "1. <It's okay to admit you were wrong, you know.>"
    new "1. <Está bien admitir que estabas equivocado, ¿sabes?>"

    # game/chapters/2_day.rpy:1350
    old "1. <Then your love for me must be...>"
    new "1. <Entonces tu amor por mí debe ser...>"

    # game/chapters/2_day.rpy:1353
    old "2. <Then your want for me must be...>"
    new "2. <Entonces tu deseo por mí debe ser...>"

    # game/chapters/2_day.rpy:1366
    old "1. <Of course I do!>"
    new "1. <¡Por supuesto que sí!>"

    # game/chapters/2_day.rpy:1371
    old "1. <Uh... well...>"
    new "1. <Uh... bueno...>"

    # game/chapters/2_day.rpy:1374
    old "1. <Why would I do that when it's so fun to bully you instead?>"
    new "1. <¿Por qué haría eso si es tan divertido molestarte a ti en su lugar?>"

    # game/chapters/2_day.rpy:1383
    old "2. <Does that matter?!>"
    new "2. <¡¿Eso importa?!>"

    # game/chapters/2_day.rpy:1390
    old "3. <To be honest, I like talking to you.> {font=gui/starthings.ttf}a{/font}"
    new "3. <A decir verdad, me gusta hablar contigo.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/2_day.rpy:1393
    old "1. <It's hilarious.>"
    new "1. <Es muy gracioso.>"

    # game/chapters/2_day.rpy:1395
    old "2. <You're surprisingly fun.>"
    new "2. <Eres sorprendentemente divertido.>"

    # game/chapters/2_day.rpy:1397
    old "3. <Occasionally you're sweet.>"
    new "3. <A veces eres dulce.>"

    # game/chapters/2_day.rpy:1405
    old "1. <I think you fell for yourself a long time ago, Grim.>"
    new "1. <Creo que tú te enamoraste de ti hace mucho tiempo, Parca.>"

    # game/chapters/2_day.rpy:1448
    old "1. <Before you get into the weird grim reaper thing...>"
    new "1. <Antes de entrar en el tema raro de la Parca... >"

    # game/chapters/2_day.rpy:1451
    old "1. <I have a really important question.>"
    new "1. <Tengo una pregunta muy importante.>"

    # game/chapters/2_day.rpy:1457
    old "1. <What the hell are those emojis?>"
    new "1. <¿Qué diablos son esos emojis?>"

    # game/chapters/2_day.rpy:1459
    old "2. <I mean, they're cute... but why so suddenly...?>"
    new "2. <Quiero decir, son lindos... pero ¿por qué tan de repente...?>"

    # game/chapters/2_day.rpy:1461
    old "3. <Did you just discover emojis or something? \nThere were so many!>"
    new "3. <¿Acabas de descubrir los emojis o algo? ¡Había muchísimos!>"

    # game/chapters/2_day.rpy:1474
    old "1. <A custom?>"
    new "1. <¿Una costumbre?>"

    # game/chapters/2_day.rpy:1477
    old "1. <I mean people use them to chat...>"
    new "1. <Me refiero a que la gente los usa para chatear...>"

    # game/chapters/2_day.rpy:1480
    old "1. <But the ones you use are kinda...>"
    new "1. <Pero los que usas son un poco...>"

    # game/chapters/2_day.rpy:1488
    old "1. <Outdated?>"
    new "1. <¿Pasados de moda?>"

    # game/chapters/2_day.rpy:1490
    old "2. <Strange.>"
    new "2. <Extraños.>"

    # game/chapters/2_day.rpy:1492
    old "3. <Well they {i}are{/i} kinda cute, but...>"
    new "3. <Bueno, {i}sí{/i} son algo lindos, pero...>"

    # game/chapters/2_day.rpy:1494
    old "1. <They are also kinda weird.>"
    new "1. <También son un poco raros.>"

    # game/chapters/2_day.rpy:1504
    old "1. <They kinda are...>"
    new "1. <La verdad, un poco sí...>"

    # game/chapters/2_day.rpy:1511
    old "1. <Er, they are, but...>"
    new "1. <Eh, lo son, pero...>"

    # game/chapters/2_day.rpy:1514
    old "1. <Not those ones, usually.>"
    new "1. <No esos, normalmente.>"

    # game/chapters/2_day.rpy:1517
    old "1. <Or at that high of a frequency...>"
    new "1. <O a una frecuencia tan alta...>"

    # game/chapters/2_day.rpy:1520
    old "1. <Those are called kaomoji. \nThey're not really normal emotes.>"
    new "1. <Esos se llaman kaomoji. No son realmente emoticonos normales.>"

    # game/chapters/2_day.rpy:1525
    old "1. <You didn't use them yesterday, did you?>"
    new "1. <Ayer no los usaste, ¿verdad?>"

    # game/chapters/2_day.rpy:1527
    old "2. <Why the sudden change?>"
    new "2. <¿Por qué el cambio repentino?>"

    # game/chapters/2_day.rpy:1530
    old "1. <The entire way you type is different.>"
    new "1. <Toda la forma en que escribes es diferente.>"

    # game/chapters/2_day.rpy:1532
    old "2. <It's like a 180 degree flip.>"
    new "2. <Es como un giro de 180 grados.>"

    # game/chapters/2_day.rpy:1548
    old "1. <Awww, but they're so cute.>"
    new "1. <Awww, pero son tan lindos.>"

    # game/chapters/2_day.rpy:1550
    old "2. <Don't stop, I like laughing at them.>"
    new "2. <No pares, me gusta reírme de ellos.>"

    # game/chapters/2_day.rpy:1555
    old "1. <You're the one that wanted my full attention.>"
    new "1. <Tú eres quien quería toda mi atención.>"

    # game/chapters/2_day.rpy:1558
    old "1. <Was there something in particular you wanted to say?>"
    new "1. <¿Había algo en particular que querías decir?>"

    # game/chapters/2_day.rpy:1561
    old "2. <Did you miss me or something?>"
    new "2. <¿Me extrañaste o algo?>"

    # game/chapters/2_day.rpy:1566
    old "1. <Then why'd you call?>"
    new "1. <Entonces ¿por qué llamaste?>"

    # game/chapters/2_day.rpy:1576
    old "1. <Next time I won't answer at all...>"
    new "1. <La próxima vez no contestaré en absoluto...>"

    # game/chapters/2_day.rpy:1578
    old "2. <Do I get a trophy or something?>"
    new "2. <¿Recibo un trofeo o algo?>"

    # game/chapters/2_day.rpy:1581
    old "1. <Then I definitely won't pick up next time.>"
    new "1. <Entonces definitivamente no contestaré la próxima vez.>"

    # game/chapters/2_day.rpy:1589
    old "1. <I can't tell if you're just very self confident...>"
    new "1. <No puedo saber si eres muy seguro de ti mismo...>"

    # game/chapters/2_day.rpy:1592
    old "1. <Or completely full of yourself.>"
    new "1. <O completamente engreído.>"

    # game/chapters/2_day.rpy:1597
    old "1. <What?>"
    new "1. <¿Qué?>"

    # game/chapters/2_day.rpy:1607
    old "1. <I dunno, it just kinda suits you.>"
    new "1. <No sé, es divertido.>"

    # game/chapters/2_day.rpy:1609
    old "2. <You look like a 'Grim'.>"
    new "2. <Es que haces muy bien el roleplay de 'Parca'.>"

    # game/chapters/2_day.rpy:1612
    old "1. <What {i}is{/i} your name, then?>"
    new "1. <¿Cuál {i}es{/i} tu nombre, entonces?>"

    # game/chapters/2_day.rpy:1618
    old "1. <No, not really.>"
    new "1. <No, la verdad no.>"

    # game/chapters/2_day.rpy:1620
    old "2. <Huh?>"
    new "2. <¿Eh?>"

    # game/chapters/2_day.rpy:1623
    old "1. <The only one desiring that is you.>"
    new "1. <El único que desea eso eres tú.>"

    # game/chapters/2_day.rpy:1628
    old "1. <You're not disagreeing with me, I see.>"
    new "1. <No me estás contradiciendo, ya veo.>"

    # game/chapters/2_day.rpy:1634
    old "1. <...How the hell can a name be classified?>"
    new "1. <...¿Cómo demonios puede clasificarse un nombre?>"

    # game/chapters/2_day.rpy:1636
    old "2. <That doesn't make any sense.>"
    new "2. <Eso no tiene ningún sentido.>"

    # game/chapters/2_day.rpy:1638
    old "3. <You really are full of secrets, little reaper.> {font=gui/starthings.ttf}a{/font}"
    new "3. <Realmente estás lleno de secretos, parquita.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/2_day.rpy:1640
    old "1. <I suppose a little bit of secretism is attractive.>"
    new "1. <Supongo que un poco de secretismo es atractivo.>"

    # game/chapters/2_day.rpy:1642
    old "1. <Why bother keeping it a secret, though?>"
    new "1. <Pero, ¿por qué molestarse en mantenerlo en secreto?>"

    # game/chapters/2_day.rpy:1645
    old "2. <I wonder what else you're keeping from me?>"
    new "2. <Me pregunto qué más me ocultas.>"

    # game/chapters/2_day.rpy:1647
    old "1. <I mean, what reason is there for keeping your name a secret?>"
    new "1. <Quiero decir, ¿qué razón hay para mantener tu nombre en secreto?>"

    # game/chapters/2_day.rpy:1649
    old "3. <I wonder if you have a name at all?>"
    new "3. <Me pregunto si tienes nombre siquiera.>"

    # game/chapters/2_day.rpy:1651
    old "1. <Maybe you don't?>"
    new "1. <¿Quizá no tengas uno?>"

    # game/chapters/2_day.rpy:1654
    old "1. <Why keep it from me, then?>"
    new "1. <¿Por qué me lo ocultas, entonces?>"

    # game/chapters/2_day.rpy:1661
    old "1. <Seriously...?>"
    new "1. <¿En serio...?>"

    # game/chapters/2_day.rpy:1663
    old "1. <Of course it is...>"
    new "1. <Por supuesto que sí...>"

    # game/chapters/2_day.rpy:1665
    old "2. <Oh. Of course it is.>"
    new "2. <Oh. Por supuesto que sí.>"

    # game/chapters/2_day.rpy:1667
    old "1. <I should've guessed, really.>"
    new "1. <Debería haberlo adivinado, de verdad.>"

    # game/chapters/2_day.rpy:1669
    old "3. <Somehow I knew you would say that...>"
    new "3. <De algún modo sabía que dirías eso...>"

    # game/chapters/2_day.rpy:1672
    old "1. <But this is suuuper unfair.>"
    new "1. <Pero esto es suuuper injusto.>"

    # game/chapters/2_day.rpy:1675
    old "1. <You know my name!>"
    new "1. <¡Sabes mi nombre!>"

    # game/chapters/2_day.rpy:1687
    old "1. <More like you hacked into my computer when you installed this virus-riddled program.>"
    new "1. <Más bien hackeaste mi computadora cuando instalaste este programa lleno de virus.>"

    # game/chapters/2_day.rpy:1690
    old "1. <Then you stole my information.>"
    new "1. <Luego robaste mi información.>"

    # game/chapters/2_day.rpy:1694
    old "1. <I'll just stick with Grim, then.>"
    new "1. <Me quedaré con Parca, entonces.>"

    # game/chapters/2_day.rpy:1697
    old "1. <Or maybe I should come up with another nickname...>"
    new "1. <O tal vez debería inventar otro apodo...>"

    # game/chapters/2_day.rpy:1703
    old "1. <How about {i}'Ghost.'{/i}>"
    new "1. <¿Qué tal {i}'Fantasma'{/i}?>"

    # game/chapters/2_day.rpy:1711
    old "1. <But your hair is kinda... ghostly.>"
    new "1. <Pero tu cabello es como... fantasmal.>"

    # game/chapters/2_day.rpy:1715
    old "1. <So Ghost is a no?>"
    new "1. <¿Así que Fantasma es un no?>"

    # game/chapters/2_day.rpy:1719
    old "2. <How about... {i}'Little Lamb'{/i}?>"
    new "2. <¿Qué tal... {i}'Corderito'{/i}?>"

    # game/chapters/2_day.rpy:1727
    old "1. <You have that fluffy, white hair.>"
    new "1. <Tienes ese cabello esponjoso y blanco.>"

    # game/chapters/2_day.rpy:1731
    old "1. <Are you asking me to call you kitten?>"
    new "1. <¿Me estás pidiendo que te llame gatito?>"

    # game/chapters/2_day.rpy:1738
    old "3. <Hmm... {i}'Snowball'{/i}?>"
    new "3. <Hmm... {i}'Bola de Nieve'{/i}?>"

    # game/chapters/2_day.rpy:1747
    old "1. <I thought it was kinda cute.>"
    new "1. <Pensé que era un poco lindo.>"

    # game/chapters/2_day.rpy:1750
    old "1. <And you are also {i}kinda{/i} cute, so...>"
    new "1. <Y tú también eres {i}algo{/i} lindo, así que...>"

    # game/chapters/2_day.rpy:1752
    old "1. <I think it's a good fit.>"
    new "1. <Creo que encaja bien.>"

    # game/chapters/2_day.rpy:1760
    old "1. <You're a little picky, aren't you? Then, how about...>"
    new "1. <Eres un poco quisquilloso, ¿no? Entonces, ¿qué tal...?>"

    # game/chapters/2_day.rpy:1763
    old "1. <Hmm, you're bright like the moon. Luna? Moonlight?>"
    new "1. <Hmm, eres brillante como la luna. ¿Luna? ¿Lunita?>"

    # game/chapters/2_day.rpy:1767
    old "1. <Storm.>"
    new "1. <Tormenta.>"

    # game/chapters/2_day.rpy:1771
    old "1. <Generic white haired anime boy?>"
    new "1. <¿Chico genérico de anime de pelo blanco?>"

    # game/chapters/2_day.rpy:1774
    old "2. <Nagito Komaeda.>"
    new "2. <Nagito Komaeda.>"

    # game/chapters/2_day.rpy:1777
    old "3. <Mr. Bones!>"
    new "3. <¡Sr. Huesos!>"

    # game/chapters/2_day.rpy:1780
    old "4. <Q-Tip?>"
    new "4. <¿Q-Tip?>"

    # game/chapters/2_day.rpy:1784
    old "1. <Hmm. I thought that was a good one.>"
    new "1. <Hmm. Pensé que ese era bueno.>"

    # game/chapters/2_day.rpy:1787
    old "1. <Phantom?>"
    new "1. <¿Espectro?>"

    # game/chapters/2_day.rpy:1791
    old "1. <God, what else is white...>"
    new "1. <Dios, qué más es blanco...>"

    # game/chapters/2_day.rpy:1793
    old "2. <I can't think of anything else kinda edgy...>"
    new "2. <No se me ocurre nada más medio edgy...>"

    # game/chapters/2_day.rpy:1796
    old "1. <Ice...?>"
    new "1. <¿Hielo...?>"

    # game/chapters/2_day.rpy:1800
    old "1. <Steve.>"
    new "1. <Steve.>"

    # game/chapters/2_day.rpy:1807
    old "1. <Then->"
    new "1. <Entonces->"

    # game/chapters/2_day.rpy:1818
    old "1. <No need to overreact, Grim.>"
    new "1. <No exageres, Parca.>"

    # game/chapters/2_day.rpy:1828
    old "1. <Wow, that's kinda rude.>"
    new "1. <Wow, qué grosero de tu parte.>"

    # game/chapters/2_day.rpy:1832
    old "1. <You're the one that won't tell me your name.>"
    new "1. <Eres tú quien no quiere decirme tu nombre.>"

    # game/chapters/2_day.rpy:1835
    old "1. <I have to call you something.>"
    new "1. <Tengo que llamarte de alguna forma.>"

    # game/chapters/2_day.rpy:1839
    old "1. <Look, it's Grim or Steve, you pick.>"
    new "1. <Mira, es Parca o Steve, tú eliges.>"

    # game/chapters/2_day.rpy:1843
    old "2. <Huh, I dunno if I'm into that kind of thing.>"
    new "2. <Eh, no sé si me gusta ese tipo de cosas.>"

    # game/chapters/2_day.rpy:1847
    old "1. <It is.>"
    new "1. <Lo es.>"

    # game/chapters/2_day.rpy:1852
    old "1. <Hey, I'm equally frustrated over here.>"
    new "1. <Oye, yo también me estoy frustrando. >"

    # game/chapters/2_day.rpy:1855
    old "1. <I just want to know the name of the \nman who wants to kill me.>"
    new "1. <Solo quiero saber el nombre del hombre que quiere matarme.>"

    # game/chapters/2_day.rpy:1858
    old "1. <Wouldn't anyone?>"
    new "1. <¿No lo iba a querer cualquiera?>"

    # game/chapters/2_day.rpy:1863
    old "3. <Through a computer screen? Good luck.>"
    new "3. <¿A través de una pantalla? Buena suerte.>"

    # game/chapters/2_day.rpy:1868
    old "1. <Oh, now I'm excited.>"
    new "1. <Oh, ahora estoy emocionad[letra].>"

    # game/chapters/2_day.rpy:1871
    old "1. <I wonder what's coming for me?>"
    new "1. <Me pregunto qué vendrá por mí.>"

    # game/chapters/2_day.rpy:1874
    old "4. <Alright, I'm down.> {font=gui/starthings.ttf}a{/font}"
    new "4. <Está bien, me animo.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/2_day.rpy:1878
    old "1. <Well, you'll have to come see me in person \nto do it, right?>"
    new "1. <Bueno, tendrás que venir a verme en persona para hacerlo, ¿no?>"

    # game/chapters/2_day.rpy:1881
    old "1. <I wouldn't mind meeting up with you for \nthe right reason.>"
    new "1. <No me importaría reunirme contigo por la razón correcta.>"

    # game/chapters/2_day.rpy:1888
    old "1. <Hurry it up, then.>"
    new "1. <Apúrate, entonces.>"

    # game/chapters/2_day.rpy:1891
    old "1. <You better bring flowers, too.>"
    new "1. <Será mejor que también traigas flores.>"

    # game/chapters/2_day.rpy:1897
    old "1. <The first 'mortal'?>"
    new "1. <¿El primer 'mortal'?>"

    # game/chapters/2_day.rpy:1900
    old "1. <Have you given flowers to someone not mortal before?>"
    new "1. <¿Has dado flores a alguien no mortal antes?>"

    # game/chapters/2_day.rpy:1904
    old "1. <I suppose I'm extra special, then.>"
    new "1. <Supongo que soy extra especial, entonces.>"

    # game/chapters/2_day.rpy:1907
    old "1. <How does Grim Reaper dating work, anyway?>"
    new "1. <¿Cómo funcionan las citas entre parcas, de todos modos?>"

    # game/chapters/2_day.rpy:1912
    old "1. <But do you want to date someone?>"
    new "1. <¿Pero quieres salir con alguien?>"

    # game/chapters/2_day.rpy:1920
    old "1. <I wouldn't mind trying.>"
    new "1. <No me importaría intentarlo.>"

    # game/chapters/2_day.rpy:1929
    old "1. <So you're attracted to me?>"
    new "1. <¿Así que te atraigo?>"

    # game/chapters/2_day.rpy:1935
    old "2. <With an attitude like yours, you'll be lucky to find someone whose standards YOU meet.>"
    new "2. <Con esa actitud, tendrás suerte de encontrar a alguien cuyos estándares TÚ cumplas.>"

    # game/chapters/2_day.rpy:1941
    old "1. <And what if I said you did?>"
    new "1. <¿Y si dijera que sí?>"

    # game/chapters/2_day.rpy:1947
    old "2. <Nice try, but I don't think so.>"
    new "2. <Buen intento, pero no lo creo.>"

    # game/chapters/2_day.rpy:1968
    old "1. <Do I get a nickname?>"
    new "1. <¿Yo tengo apodo?>"

    # game/chapters/2_day.rpy:1975
    old "1. <I just think nicknames are fun.>"
    new "1. <Solo pienso que los apodos son divertidos.>"

    # game/chapters/2_day.rpy:1977
    old "1. <And you get one, so I should get one too.>"
    new "1. <Y tú tienes uno, así que yo también debería tenerlo.>"

    # game/chapters/2_day.rpy:1980
    old "1. <You wouldn't want to be unfair, would you?>"
    new "1. <No vas a ser injusto, ¿o sí?>"

    # game/chapters/2_day.rpy:1984
    old "1. <'{i}Life is unfair. The only fairness is in death.{/i}'>"
    new "1. <'{i}La vida es injusta. La única justicia está en la muerte.{/i}'>"

    # game/chapters/2_day.rpy:1994
    old "1. <You think they're pretty?>"
    new "1. <¿Crees que son bonitas?>"

    # game/chapters/2_day.rpy:1998
    old "1. <But you just said it!>"
    new "1. <¡Pero acabas de decirlo!>"

    # game/chapters/2_day.rpy:2001
    old "1. <Pretty little ears!>"
    new "1. <¡Orejas bonitas!>"

    # game/chapters/2_day.rpy:2005
    old "1. <Weird insult, buddy.>"
    new "1. <Insulto raro, amigo.>"

    # game/chapters/2_day.rpy:2007
    old "2. <Flustered? By you?>"
    new "2. <¿Sonrojarme? ¿Por ti?>"

    # game/chapters/2_day.rpy:2009
    old "1. <Is that a joke?>"
    new "1. <¿Es una broma?>"

    # game/chapters/2_day.rpy:2016
    old "1. <There's nothing to be flustered over.>"
    new "1. <No hay nada de qué sonrojarse.>"

    # game/chapters/2_day.rpy:2019
    old "1. <If anything, the real reason you \nwon't tell me your name...>"
    new "1. <Si acaso, la verdadera razón por la que no me dices tu nombre...>"

    # game/chapters/2_day.rpy:2022
    old "1. <...Is because I would fluster YOU!>"
    new "1. <...Es porque ¡yo te pondría nervioso a TI!>"

    # game/chapters/2_day.rpy:2029
    old "1. <What if I called you... handsome?>"
    new "1. <¿Y si te llamara... guapo?>"

    # game/chapters/2_day.rpy:2032
    old "1. <Gorgeous, stunning, sexy?>"
    new "1. <¿Hermoso, impresionante, sexy?>"

    # game/chapters/2_day.rpy:2039
    old "1. <How about cute?>"
    new "1. <¿Qué tal lindo?>"

    # game/chapters/2_day.rpy:2046
    old "3. <What if I am?>"
    new "3. <¿Y si lo estoy?>"

    # game/chapters/2_day.rpy:2056
    old "1. <Just kidding!>"
    new "1. <¡Es broma!>"

    # game/chapters/2_day.rpy:2059
    old "1. <You make me the opposite of flustered.>"
    new "1. <Tú me haces sentir todo lo contrario a los nervios.>"

    # game/chapters/2_day.rpy:2062
    old "1. <I'm so calm and unbothered by you I \nenter a state of serenity.>"
    new "1. <Estoy tan tranquil[letra] y me alteras tan poco que entro en un estado de serenidad.>"

    # game/chapters/2_day.rpy:2065
    old "1. <My mind transcends space and time \nwhenever you speak.>"
    new "1. <Mi mente trasciende espacio y tiempo cada vez que hablas.>"

    # game/chapters/2_day.rpy:2068
    old "1. <That's how relaxed I am.>"
    new "1. <Así es mi nivel de relajación.>"

    # game/chapters/2_day.rpy:2072
    old "1. <You must be looking in a mirror.>"
    new "1. <Debes estar mirándote en un espejo.>"

    # game/chapters/2_day.rpy:2076
    old "4. <We could have matching nicknames!> {font=gui/starthings.ttf}a{/font}"
    new "4. <¡Podríamos tener apodos a juego!> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/2_day.rpy:2082
    old "1. <You be Grim, I can be Reaper?>"
    new "1. <Tú serás Parca, ¿yo puedo ser Guadaña?>"

    # game/chapters/2_day.rpy:2086
    old "1. <You be honey, and I can be bun?>"
    new "1. <Tú serás Dulzura y yo seré Pastelito.>"

    # game/chapters/2_day.rpy:2090
    old "1. <How about... Sugar and Spice?>"
    new "1. <¿Qué tal... Dulce y Picante?>"

    # game/chapters/2_day.rpy:2094
    old "1. <Mac and Cheese?>"
    new "1. <¿Macarrones y Queso?>"

    # game/chapters/2_day.rpy:2100
    old "1. <It'll be cute when you eventually fall for me.>"
    new "1. <Será lindo cuando al final te enamores de mí.>"

    # game/chapters/2_day.rpy:2103
    old "1. <Since that's inevitable and all.>"
    new "1. <Ya que eso es inevitable y todo.>"

    # game/chapters/2_day.rpy:2109
    old "1. <...Your scythe is a part of you?>"
    new "1. <...¿Tu guadaña es parte de ti?>"

    # game/chapters/2_day.rpy:2113
    old "1. <Then why did you say it?>"
    new "1. <¿Entonces por qué lo dijiste?>"

    # game/chapters/2_day.rpy:2120
    old "1. <But if you had to pick one...>"
    new "1. <Pero si tuvieras que elegir uno...>"

    # game/chapters/2_day.rpy:2123
    old "1. <What would you pick?>"
    new "1. <¿Cuál elegirías?>"

    # game/chapters/2_day.rpy:2133
    old "1. <Those are adjectives!>"
    new "1. <¡Esos son adjetivos!>"

    # game/chapters/2_day.rpy:2141
    old "1. <Give me a proper nickname!>"
    new "1. <¡Dame un apodo de verdad!>"

    # game/chapters/2_day.rpy:2145
    old "1. <C'mon, don't be such a downer.>"
    new "1. <Vamos, no seas aguafiestas.>"

    # game/chapters/2_day.rpy:2150
    old "1. <...Well? Are you going to tell me or not?>"
    new "1. <...Bueno ¿vas a decírmelo o no?>"

    # game/chapters/2_day.rpy:2154
    old "1. <Aaaand?>"
    new "1. <¿Yyyy?>"

    # game/chapters/2_day.rpy:2157
    old "1. <Grim, don't leave a [girl] hanging.>"
    new "1. <Parca, no dejes a [arti_2] [girl!t] con la intriga.>"

    # game/chapters/2_day.rpy:2160
    old "2. <Seems like someone isn't creative, huh.>"
    new "2. <Parece que alguien no es creativo, ¿eh?>"

    # game/chapters/2_day.rpy:2169
    old "1. <Lay it on me then, Grim.>"
    new "1. <Dímelo entonces, Parca.>"

    # game/chapters/2_day.rpy:2173
    old "1. <Well?>"
    new "1. <¿Y bien?>"

    # game/chapters/2_day.rpy:2177
    old "1. <I'm waiting!>"
    new "1. <¡Estoy esperando!>"

    # game/chapters/2_day.rpy:2180
    old "1. <What did your {i}creative{/i} mind come up with?>"
    new "1. <¿Qué ideó tu mente {i}creativa{/i}?>"

    # game/chapters/2_day.rpy:2183
    old "3. <Don't tell me you're too shy to tell me?> {font=gui/starthings.ttf}a{/font}"
    new "3. <¿No me digas que eres demasiado tímido para decírmelo?> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/2_day.rpy:2185
    old "1. <You look like you already have one in mind.>"
    new "1. <Parece que ya tienes uno en mente.>"

    # game/chapters/2_day.rpy:2193
    old "1. <You already had a pet name picked out for me?>"
    new "1. <¿Ya tenías un apodo para mí?>"

    # game/chapters/2_day.rpy:2199
    old "1. <Lay it on me, then.>"
    new "1. <Entonces dímelo.>"

    # game/chapters/2_day.rpy:2207
    old "1. <I want to know the one you already had picked out!>"
    new "1. <¡Quiero saber el que ya tenías pensado!>"

    # game/chapters/2_day.rpy:2212
    old "1. <How long ago did you pick it?>"
    new "1. <¿Hace cuánto lo elegiste?>"

    # game/chapters/2_day.rpy:2217
    old "1. <A few years ago?!>"
    new "1. <¿¡Hace unos años!?>"

    # game/chapters/2_day.rpy:2220
    old "1. <We just met!>"
    new "1. <¡Si apenas nos conocimos!>"

    # game/chapters/2_day.rpy:2235
    old "1. <Sunshine?>"
    new "1. <¿Solecito?>"

    # game/chapters/2_day.rpy:2238
    old "1. <You think I'm like sunshine?>"
    new "1. <¿Crees que soy como un rayo de sol?>"

    # game/chapters/2_day.rpy:2245
    old "1. <You absolutely did not misspeak!>"
    new "1. <¡Definitivamente no fue un lapsus!>"

    # game/chapters/2_day.rpy:2247
    old "2. <I think you meant it, actually.>"
    new "2. <En realidad, creo que lo dijiste en serio.>"

    # game/chapters/2_day.rpy:2250
    old "1. <I don't mind being your Sunshine.>"
    new "1. <No me importa ser tu Solecito.>"

    # game/chapters/2_day.rpy:2272
    old "1. <You're sweet, Grim.>"
    new "1. <Eres dulce, Parca.>"

    # game/chapters/2_day.rpy:2274
    old "2. <You're {i}so{/i} nice, Grim.>"
    new "2. <Eres {i}tan{/i} amable, Parca.>"

    # game/chapters/2_day.rpy:2285
    old "1. <You don't seem so sure.>"
    new "1. <No pareces muy seguro.>"

    # game/chapters/2_day.rpy:2287
    old "2. <Your face screams 'uncertain'.>"
    new "2. <Tu cara grita 'inseguro'.>"

    # game/chapters/2_day.rpy:2298
    old "1. <Fine. Then I'm completely and utterly delusional.>"
    new "1. <Bien. Entonces estoy completa y absolutamente fuera de la realidad.>"

    # game/chapters/2_day.rpy:2301
    old "1. <But also you think I'm like sunshine, \nso I have that going for me.>"
    new "1. <Pero también piensas que soy como un rayo de sol, así que tengo eso a mi favor.>"

    # game/chapters/2_day.rpy:2306
    old "1. <You really do seem kind of adorable sometimes, \nyou know?>"
    new "1. <Realmente pareces algo adorable a veces, ¿sabes?>"

    # game/chapters/2_day.rpy:2308
    old "1. <You have that awful attitude, yet you came up \nwith such a cute nickname.>"
    new "1. <Tienes esa actitud horrible, y aun así pensaste en un apodo tan tierno.>"

    # game/chapters/2_day.rpy:2311
    old "1. <I think you should say it again.>"
    new "1. <Creo que deberías decirlo otra vez.>"

    # game/chapters/2_day.rpy:2313
    old "2. <I kind of want to hear it a second time.>"
    new "2. <Quiero oírlo una segunda vez.>"

    # game/chapters/2_day.rpy:2316
    old "2. <When you look at me like that, I want to tease you.>"
    new "2. <Cuando me miras así, me dan ganas de burlarme de ti.>"

    # game/chapters/2_day.rpy:2318
    old "1. <Really badly.>"
    new "1. <Con muchas ganas.>"

    # game/chapters/2_day.rpy:2321
    old "1. <Such a grumpy reaper, yet you thought \nup such a cute nickname.>"
    new "1. <Una parca gruñona, pero que inventa un apodo tan tierno.>"

    # game/chapters/2_day.rpy:2324
    old "3. <You must think about me a lot, to pick out \na nickname like that.> {font=gui/starthings.ttf}a{/font}"
    new "3. <Debes pensar mucho en mí, para elegir un apodo como ese.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/2_day.rpy:2326
    old "1. <That's... actually pretty cute.>"
    new "1. <Eso es... en realidad bastante lindo.>"

    # game/chapters/2_day.rpy:2329
    old "1. <Well... it's a mistake that's made me happy?>"
    new "1. <Bueno... ¿es un error que me hizo feliz?>"

    # game/chapters/2_day.rpy:2336
    old "1. <Look at me, Grim.>"
    new "1. <Mírame, Parca.>"

    # game/chapters/2_day.rpy:2339
    old "1. <Say it ooooone more time.>"
    new "1. <Dilo una veeeez más.>"

    # game/chapters/2_day.rpy:2341
    old "2. <Go on, call me Sunshine again.>"
    new "2. <Vamos, llámame Solecito otra vez.>"

    # game/chapters/2_day.rpy:2346
    old "1. <Pleaseeeeee?>"
    new "1. <¿Poooor favor?>"

    # game/chapters/2_day.rpy:2349
    old "1. <Come on, pretty please?>"
    new "1. <Vamos, ¿porfis?>"

    # game/chapters/2_day.rpy:2351
    old "2. <Pretty pleaseeeeee?>"
    new "2. <¿Porfiiiiiis?>"

    # game/chapters/2_day.rpy:2354
    old "1. <Pretty, pretty, pretty please?>"
    new "1. <Porfis, porfis, porfis.>"

    # game/chapters/2_day.rpy:2356
    old "3. <Pretty pleaseeeeeee, with sugar on top?>"
    new "3. <¿Porfiiiiiis, con un poquito de azúcar?>"

    # game/chapters/2_day.rpy:2360
    old "1. <Forget the sugar.>"
    new "1. <Olvida el azúcar.>"

    # game/chapters/2_day.rpy:2362
    old "1. <Come on, pretttty pleaaaseee...>"
    new "1. <Vamos, pooorfiiis>"

    # game/chapters/2_day.rpy:2364
    old "4. <Look deep into my eyes...> {font=gui/starthings.ttf}a{/font}"
    new "4. <Mírame profundamente a los ojos...> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/2_day.rpy:2366
    old "1. <Deep, deep into them...>"
    new "1. <Profundo, muy profundo en ellos...>"

    # game/chapters/2_day.rpy:2369
    old "1. <And call me sunshine.>"
    new "1. <Y llámame solecito.>"

    # game/chapters/2_day.rpy:2372
    old "1. <Ah! I can't help but swoon!>"
    new "1. <¡Ah! ¡Me tienes suspirando de amor!>"

    # game/chapters/2_day.rpy:2376
    old "1. <Yes, I am definitely, totally swooning right now.>"
    new "1. <Sí, definitivamente estoy suspirando de amor ahora mismo.>"

    # game/chapters/2_day.rpy:2380
    old "1. <I would never. Come on, say it again.>"
    new "1. <Jamás lo haría. Anda, dilo otra vez.>"

    # game/chapters/2_day.rpy:2382
    old "2. <Who, me? I wouldn't dare.>"
    new "2. <¿Quién, yo? No me atrevería.>"

    # game/chapters/2_day.rpy:2384
    old "1. <C'mon though, say it again.>"
    new "1. <Vamos, dilo otra vez.>"

    # game/chapters/2_day.rpy:2389
    old "1. <What if I hand over my soul for it?>"
    new "1. <¿Y si te entrego mi alma por ello?>"

    # game/chapters/2_day.rpy:2394
    old "1. <No, but I do want you to say it again.>"
    new "1. <No, pero sí quiero que lo digas otra vez.>"

    # game/chapters/2_day.rpy:2396
    old "2. <I absolutely will.>"
    new "2. <Claro que lo haré.>"

    # game/chapters/2_day.rpy:2399
    old "1. <Okay, I actually don't want to.>"
    new "1. <Okey, en realidad no quiero.>"

    # game/chapters/2_day.rpy:2402
    old "1. <But I do want you to say it again.>"
    new "1. <Pero quiero que lo repitas.>"

    # game/chapters/2_day.rpy:2412
    old "1. <Really, you can only blame yourself for \ncoming up with such a cute nickname.>"
    new "1. <En serio, solo puedes culparte a ti mismo por inventar un apodo tan tierno.>"

    # game/chapters/2_day.rpy:2414
    old "1. <There's no reason to be so shy, my little reaper.>"
    new "1. <No tienes por qué ser tan tímido, mi parquita.>"

    # game/chapters/2_day.rpy:2419
    old "1. <Mmhmm. That's why you're so flustered right now.>"
    new "1. <Mmhmm. Por eso estás tan nervioso ahora.>"

    # game/chapters/2_day.rpy:2424
    old "1. <So timid. So shy. So hesitant. Adorable.>"
    new "1. <Tan tímido. Tan cohibido. Tan indeciso. Qué adorable.>"

    # game/chapters/2_day.rpy:2426
    old "1. <I like that about you.>"
    new "1. <Eso me gusta de ti.>"

    # game/chapters/2_day.rpy:2428
    old "2. <You're just way too easy to tease.>"
    new "2. <Es que eres demasiado fácil de molestar.>"

    # game/chapters/2_day.rpy:2431
    old "2. <There's nothing to be embarrassed about.>"
    new "2. <No hay nada de qué avergonzarse.>"

    # game/chapters/2_day.rpy:2433
    old "1. <You're just a little bit shy. That's okay.>"
    new "1. <Eres solo un poquito tímido. Está bien.>"

    # game/chapters/2_day.rpy:2435
    old "2. <Your pink face gives away your secret timidness.>"
    new "2. <Tu rostro sonrosado delata tu timidez secreta.>"

    # game/chapters/2_day.rpy:2445
    old "1. <Then prove it.>"
    new "1. <Entonces demuéstralo.>"

    # game/chapters/2_day.rpy:2448
    old "1. <Don't worry, I can wait. Let me get my popcorn.>"
    new "1. <No te preocupes, puedo esperar. Déjame sacar las palomitas.>"

    # game/chapters/2_day.rpy:2450
    old "2. <Take your time. I can wait.>"
    new "2. <Tómate tu tiempo. Puedo esperar.>"

    # game/chapters/2_day.rpy:2466
    old "1. <I don't mind casting some of my rays down at you.>"
    new "1. <No me importa arrojar algunos de mis rayos sobre ti.>"

    # game/chapters/2_day.rpy:2469
    old "2. <I can't help it if I'm naturally radiant.>"
    new "2. <No puedo evitar ser naturalmente radiante.>"

    # game/chapters/2_day.rpy:2473
    old "1. <Grim.>"
    new "1. <Parca.>"

    # game/chapters/2_day.rpy:2478
    old "1. <You're blushing.>"
    new "1. <Estás sonrojado.>"

    # game/chapters/2_day.rpy:2480
    old "2. <If you blush like that, you make me \nwant to tease you more.>"
    new "2. <Si te sonrojas así, me dan más ganas de molestarte.>"

    # game/chapters/2_day.rpy:2482
    old "3. <You really are cute.>"
    new "3. <De verdad eres lindo.>"

    # game/chapters/2_day.rpy:2484
    old "1. <It makes me forget that you're just some scammer.>"
    new "1. <Eso me hace olvidar que eres solo un estafador.>"

    # game/chapters/2_day.rpy:2490
    old "1. <Your {i}what{/i}?>"
    new "1. <¿Tu {i}qué{/i}?>"

    # game/chapters/2_day.rpy:2495
    old "1. <Running away just like that, huh?>"
    new "1. <¿Huyendo así nada más, huh?>"

    # game/chapters/2_day.rpy:2497
    old "1. <But I like talking to you.>"
    new "1. <Pero me gusta hablar contigo.>"

    # game/chapters/2_day.rpy:2500
    old "2. <I think I've used those excuses before too.>"
    new "2. <Creo que yo también he usado esas excusas antes.>"

    # game/chapters/2_day.rpy:2502
    old "1. <But I don't want you to go yet.>"
    new "1. <Pero no quiero que te vayas todavía.>"

    # game/chapters/2_day.rpy:2505
    old "1. <It's actually kinda fun, in a weird way.>"
    new "1. <Es algo divertido, de una forma rara.>"

    # game/chapters/2_day.rpy:2508
    old "1. <Just gotta look past the grim reaper cosplay \nthing you have going on.>"
    new "1. <Solo tengo que mirar más allá del cosplay de parca que llevas.>"

    # game/chapters/2_day.rpy:2511
    old "1. <And the fact that you illegally installed this \napp on my computer, of course.>"
    new "1. <Y del hecho de que instalaste esta app ilegalmente en mi computadora, por supuesto.>"

    # game/chapters/2_day.rpy:2516
    old "1. <And even if your personality is kinda...>"
    new "1. <E incluso si tu personalidad es algo...>"

    # game/chapters/2_day.rpy:2524
    old "1. <I didn't say there was anything wrong with it, Grim.>"
    new "1. <No dije que hubiera algo malo en eso, Parca.>"

    # game/chapters/2_day.rpy:2527
    old "1. <But if the shoe fits...>"
    new "1. <Pero si el saco te queda...>"

    # game/chapters/2_day.rpy:2536
    old "1. <Really? I wonder what the court would think \nif I sued you for invasion of privacy.>"
    new "1. <¿En serio? Me pregunto qué pensaría el tribunal si te demandara por invasión de la privacidad.>"

    # game/chapters/2_day.rpy:2544
    old "1. <Ahah. That's where you're wrong.>"
    new "1. <Ajaja. Ahí es donde te equivocas.>"

    # game/chapters/2_day.rpy:2547
    old "1. <I'm tracking your location right now.>"
    new "1. <Estoy rastreando tu ubicación ahora mismo.>"

    # game/chapters/2_day.rpy:2552
    old "1. <Just kidding.>"
    new "1. <Es broma.>"

    # game/chapters/2_day.rpy:2555
    old "1. <...Or am I?>"
    new "1. <...¿O no?>"

    # game/chapters/2_day.rpy:2557
    old "2. <Unless....?>"
    new "2. <¿A menos que...?>"

    # game/chapters/2_day.rpy:2559
    old "3. <Or maybe I am {i}deadly{/i} serious.> {font=gui/starthings.ttf}a{/font}"
    new "3. <O tal vez lo digo {i}mortalmente{/i} en serio.> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/2_day.rpy:2566
    old "1. <I can literally see you, you dork. >"
    new "1. <Puedo literalmente verte, torpe.>"

    # game/chapters/2_day.rpy:2568
    old "1. <You aren't laughing.>"
    new "1. <No te estás riendo.>"

    # game/chapters/2_day.rpy:2576
    old "1. <Why? Do you live in another country?>"
    new "1. <¿Por qué? ¿Vives en otro país?>"

    # game/chapters/2_day.rpy:2581
    old "1. <Let me guess...>"
    new "1. <Déjame adivinar...>"

    # game/chapters/2_day.rpy:2584
    old "1. <The Underworld?>"
    new "1. <¿El Inframundo?>"

    # game/chapters/2_day.rpy:2588
    old "1. <When have I ever answered you sarcastically \nor stupidly?>"
    new "1. <¿Cuándo te he respondido con sarcasmo o estupidez?>"

    # game/chapters/2_day.rpy:2595
    old "1. <Do you now?>"
    new "1. <¿Ah sí?>"

    # game/chapters/2_day.rpy:2604
    old "1. <What else do you like about me?>"
    new "1. <¿Qué más te gusta de mí?>"

    # game/chapters/2_day.rpy:2607
    old "1. <Because you have a secret crush on me.>"
    new "1. <Porque tienes un crush secreto conmigo.>"

    # game/chapters/2_day.rpy:2617
    old "1. <I don't mind the whole 'I want to kill you' \nthing we have going on.>"
    new "1. <No me molesta todo eso de 'quiero matarte' que tenemos.>"

    # game/chapters/2_day.rpy:2622
    old "2. <I'm looking past the fact you want to kill me.>"
    new "2. <Estoy pasando por alto que quieras matarme.>"

    # game/chapters/2_day.rpy:2630
    old "2. <Because I'm just the best.>"
    new "2. <Porque simplemente soy de lo mejor.>"

    # game/chapters/2_day.rpy:2637
    old "1. <How about the best looking mortal you've ever seen?>"
    new "1. <¿Qué tal [arti] mortal más atractiv[letra] que hayas visto?>"

    # game/chapters/2_day.rpy:2646
    old "1. <Surely that means I automatically win.>"
    new "1. <Eso significa que gano automáticamente.>"

    # game/chapters/2_day.rpy:2651
    old "1. <Nope. Am I the most [pretty] mortal you've seen?>"
    new "1. <Nop. ¿Soy [arti] mortal más [pretty!t] que has visto?>"

    # game/chapters/2_day.rpy:2657
    old "1. <Is that what you like about me, then?>"
    new "1. <¿Es eso lo que te gusta de mí, entonces?>"

    # game/chapters/2_day.rpy:2661
    old "1. <Heh. You think I'm [pretty].>"
    new "1. <Je. Crees que soy [pretty!t].>"

    # game/chapters/2_day.rpy:2664
    old "1. <The most [pretty] mortal in the ENTIRE world. Wow!>"
    new "1. <¡[arti!c] mortal más [pretty!t] de TODO el mundo! ¡Wow!>"

    # game/chapters/2_day.rpy:2676
    old "2. <I'll take 'best at annoying you'.>"
    new "2. <Me quedo con 'quien mejor te fastidia'.>"

    # game/chapters/2_day.rpy:2680
    old "1. <You sound sarcastic.>"
    new "1. <Suenas sarcástico.>"

    # game/chapters/2_day.rpy:2689
    old "1. <Aww. You really want me that badly?>"
    new "1. <Aww. ¿Me quieres tanto?>"

    # game/chapters/2_day.rpy:2698
    old "1. <This is all going a little fast.>"
    new "1. <Todo esto está yendo un poco rápido.>"

    # game/chapters/2_day.rpy:2700
    old "2. <Hey, this works for me, but...>"
    new "2. <Oye, a mí me sirve, pero...>"

    # game/chapters/2_day.rpy:2704
    old "1. <Ask a [girl] out to dinner first, won't ya?>"
    new "1. <Invita a [arti_2] [girl!t] a cenar primero, ¿no?>"

    # game/chapters/2_day.rpy:2712
    old "3. <I'm pretty dang good at ultimate frisbee.>"
    new "3. <Se me da bastante bien el ultimate frisbee.>"

    # game/chapters/2_day.rpy:2722
    old "1. <Yeah, I was in a few national championships.>"
    new "1. <Sí, estuve en algunos campeonatos nacionales.>"

    # game/chapters/2_day.rpy:2727
    old "1. <Is that something you like about me to add \nto your list, then?>"
    new "1. <¿Entonces es algo que te gusta de mí y que puedes añadir a tu lista?>"

    # game/chapters/2_day.rpy:2731
    old "1. <Your diary, then?>"
    new "1. <¿Tu diario, entonces?>"

    # game/chapters/2_day.rpy:2735
    old "1. <Wait, you actually have a diary?>"
    new "1. <Espera, ¿en serio tienes un diario?>"

    # game/chapters/2_day.rpy:2739
    old "1. <That's adorable. Have you ever written about me?>"
    new "1. <Eso es adorable. ¿Alguna vez has escrito sobre mí?>"

    # game/chapters/2_day.rpy:2747
    old "1. <Now you're making me shy.>"
    new "1. <Ahora me estás haciendo sonrojar.>"

    # game/chapters/2_day.rpy:2752
    old "1. <You write about me so much!>"
    new "1. <¡Escribes tanto sobre mí!>"

    # game/chapters/2_day.rpy:2755
    old "1. <You really do have a thing for me.>"
    new "1. <Realmente sientes algo por mí.>"

    # game/chapters/2_day.rpy:2762
    old "1. <Is that what you do?>"
    new "1. <¿Eso es lo que haces?>"

    # game/chapters/2_day.rpy:2776
    old "2. <You're in my diary, too.>"
    new "2. <Tú también apareces en mi diario.>"

    # game/chapters/2_day.rpy:2781
    old "1. <Yeah, I write about everything.>"
    new "1. <Sí, escribo sobre todo.>"

    # game/chapters/2_day.rpy:2783
    old "1. <So you get a passing mention, too.>"
    new "1. <Así que también te menciono por encima.>"

    # game/chapters/2_day.rpy:2797
    old "1. <Better luck with the next mortal, I guess.>"
    new "1. <Más suerte con el próximo mortal, supongo.>"

    # game/chapters/2_day.rpy:2802
    old "1. <There aren't. I'm cooler than them, obviously.>"
    new "1. <No los hay. Yo soy más genial que ellos, obviamente.>"

    # game/chapters/2_day.rpy:2807
    old "2. <I'm one of a kind.>"
    new "2. <Soy irrepetible.>"

    # game/chapters/2_day.rpy:2812
    old "2. <Maybe you should give me a reason to \nwrite about you more, then.>"
    new "2. <Quizás deberías darme una razón para escribir más sobre ti.>"

    # game/chapters/2_day.rpy:2817
    old "1. <Perhaps a grand romantic gesture I'll never forget.>"
    new "1. <Quizás un gran gesto romántico que nunca olvidaré.>"

    # game/chapters/2_day.rpy:2825
    old "2. <Two words. Karaoke. Night.>"
    new "2. <Dos palabras. Noche. De Karaoke.>"

    # game/chapters/2_day.rpy:2830
    old "1. <So what if I am?>"
    new "1. <¿Y qué si te lo estoy pidiendo?>"

    # game/chapters/2_day.rpy:2836
    old "2. <But I feel like I'm going to write about you a lot.>"
    new "2. <Pero siento que voy a escribir mucho sobre ti.>"

    # game/chapters/2_day.rpy:2841
    old "1. <Wait, you wanted it to be positive?>"
    new "1. <Espera, ¿querías que fuera positivo?>"

    # game/chapters/2_day.rpy:2844
    old "1. <Whoops.>"
    new "1. <Uuups.>"

    # game/chapters/2_day.rpy:2854
    old "1. <Really? Name five perfect things about you.>"
    new "1. <¿En serio? Nombra cinco cosas perfectas sobre ti.>"

    # game/chapters/2_day.rpy:2859
    old "1. <Wait, what's with that last one?>"
    new "1. <Espera, ¿qué pasa con ese último?>"

    # game/chapters/2_day.rpy:2869
    old "1. <That's... very sad.>"
    new "1. <Eso es... muy triste.>"

    # game/chapters/2_day.rpy:2872
    old "1. <I hope you eat more than cup noodles.>"
    new "1. <Espero que comas más que fideos instantáneos.>"

    # game/chapters/2_day.rpy:2876
    old "2. <Okay, color me impressed.>"
    new "2. <Okey, me impresionas.>"

    # game/chapters/2_day.rpy:2888
    old "2. <No, but if I tried it I bet I'd be really good.>"
    new "2. <No, pero si lo intentara apuesto a que sería muy buen[letra].>"

    # game/chapters/2_day.rpy:2894
    old "1. <I'm going purely off vibes.>"
    new "1. <Me guío exclusivamente por mis sensaciones.>"

    # game/chapters/2_day.rpy:2900
    old "1. <That's great.>"
    new "1. <Eso es genial.>"

    # game/chapters/2_day.rpy:2903
    old "1. <Those are nice skills to have.>"
    new "1. <Esas son habilidades muy útiles.>"

    # game/chapters/2_day.rpy:2908
    old "2. <I play a lot of other sports.>"
    new "2. <Practico muchos otros deportes.>"

    # game/chapters/2_day.rpy:2915
    old "3. <To be honest, I'm completely delusional.>"
    new "3. <A decir verdad, estoy completamente fuera de la realidad.>"

    # game/chapters/2_day.rpy:2933
    old "2. <Heaven.>"
    new "2. <El Cielo.>"

    # game/chapters/2_day.rpy:2937
    old "1. <You look more like an angel than a grim reaper, yeah.>"
    new "1. <Te ves más como un ángel que como una parca, sí.>"

    # game/chapters/2_day.rpy:2942
    old "1. <Not to come back to your personality, but \nthat {i}definitely{/i} doesn't suit an angel.>"
    new "1. <No es por volver a tu personalidad, pero eso {i}definitivamente{/i} no le queda a un ángel.>"

    # game/chapters/2_day.rpy:2948
    old "1. <That's the best compliment I've ever gotten.>"
    new "1. <Es el mejor cumplido que me han hecho nunca.>"

    # game/chapters/2_day.rpy:2955
    old "1. <You do kinda harass and kill people. Apparently.>"
    new "1. <En cierto modo, acosas y matas a la gente. Al parecer.>"

    # game/chapters/2_day.rpy:2961
    old "1. <So where {i}do{/i} you live, then?>"
    new "1. <Entonces, ¿dónde {i}vives{/i} tú?>"

    # game/chapters/2_day.rpy:2963
    old "3. <Australia?>"
    new "3. <¿Australia?>"

    # game/chapters/2_day.rpy:2971
    old "1. <Yeah. Australia.>"
    new "1. <Sí. Australia.>"

    # game/chapters/2_day.rpy:2975
    old "1. <Is it really, though?>"
    new "1. <¿En serio?>"

    # game/chapters/2_day.rpy:2978
    old "1. <Is there really any proof it's on Earth?>"
    new "1. <¿Hay alguna prueba real de que está en la Tierra?>"

    # game/chapters/2_day.rpy:2982
    old "1. <What if the maps are lying?>"
    new "1. <¿Y si los mapas mienten?>"

    # game/chapters/2_day.rpy:2985
    old "1. <I mean, Australia's got all those spiders and \nanimals that want to kill you...>"
    new "1. <Digo, Australia tiene todas esas arañas y animales que quieren matarte...>"

    # game/chapters/2_day.rpy:2987
    old "1. <Seems like a different dimension to me.>"
    new "1. <A mí me parece otra dimensión.>"

    # game/chapters/2_day.rpy:2995
    old "1. <Yeah, I'm just messing with you.>"
    new "1. <Sí, solo te estoy tomando el pelo.>"

    # game/chapters/2_day.rpy:2998
    old "1. <Mostly. Australia might be a hoax.>"
    new "1. <Sobre todo. Australia podría ser un engaño.>"

    # game/chapters/2_day.rpy:3001
    old "1. <Since when do they have WiFi in \nThe Underworld, anyway?>"
    new "1. <¿Desde cuándo tienen WiFi en El Inframundo, de todos modos?>"

    # game/chapters/2_day.rpy:3004
    old "1. <Or computers, or posters... nice posters, \nby the way.>"
    new "1. <O computadoras, o pósters... lindos pósters, por cierto.>"

    # game/chapters/2_day.rpy:3007
    old "1. <The Underworld seems to have it all.>"
    new "1. <El Inframundo parece tenerlo todo.>"

    # game/chapters/2_day.rpy:3010
    old "1. <Do you think I should make the move?>"
    new "1. <¿Crees que debería dar el paso?>"

    # game/chapters/2_day.rpy:3015
    old "1. <No? Don't fancy a roommate?>"
    new "1. <¿No? ¿No te gusta compartir habitación?>"

    # game/chapters/2_day.rpy:3019
    old "1. <Awww, even with me?>"
    new "1. <Awww, ¿ni siquiera conmigo?>"

    # game/chapters/2_day.rpy:3023
    old "1. <Shame, I think I'd make a great house [wife].>"
    new "1. <Qué pena, creo que sería [arti_2] excelente [wife!t].>"

    # game/chapters/2_day.rpy:3031
    old "1. <I could help you cook, clean... bathe, \nif you asked me nicely.>"
    new "1. <Podría ayudarte a cocinar, limpiar... bañarte, si me lo pides amablemente.>"

    # game/chapters/2_day.rpy:3041
    old "1. <You don't want me to wash your back, Grim? Shame.>"
    new "1. <¿No quieres que te lave la espalda, Parca? Qué pena.>"

    # game/chapters/2_day.rpy:3045
    old "2. <I could even wash your hair for you.>"
    new "2. <Hasta podría lavarte el pelo.>"

    # game/chapters/2_day.rpy:3049
    old "3. <I think I could offer a good full body scrub.>"
    new "3. <Creo que podría darte una buena exfoliación de cuerpo completo.>"

    # game/chapters/2_day.rpy:3053
    old "1. <Do you not have hot water in the Underworld?>"
    new "1. <¿No tienen agua caliente en el Inframundo?>"

    # game/chapters/2_day.rpy:3058
    old "1. <Perfect, then it all works out.>"
    new "1. <Perfecto, entonces todo encaja.>"

    # game/chapters/2_day.rpy:3061
    old "1. <Maybe I'll even throw in a massage!>"
    new "1. <¡Quizás hasta incluya un masaje!>"

    # game/chapters/2_day.rpy:3064
    old "1. <If you give me one, too.>"
    new "1. <Si tú me das uno, también.>"

    # game/chapters/2_day.rpy:3066
    old "2. <If you pay.>"
    new "2. <Si tú pagas.>"

    # game/chapters/2_day.rpy:3068
    old "3. <If you beg.>"
    new "3. <Si suplicas.>"

    # game/chapters/2_day.rpy:3073
    old "1. <But the bathing is still on the table, eh?>"
    new "1. <Pero el baño sigue pendiente, ¿no?>"

    # game/chapters/2_day.rpy:3081
    old "1. <Well, if you ever change your mind...>"
    new "1. <Bueno, si alguna vez cambias de opinión...>"

    # game/chapters/2_day.rpy:3085
    old "1. <Anyway, you're changing the topic.>"
    new "1. <De todos modos, estás cambiando el tema.>"

    # game/chapters/2_day.rpy:3089
    old "1. <How did you even learn to install \nthis virus on my computer?>"
    new "1. <¿Cómo aprendiste siquiera a instalar este virus en mi computadora?>"

    # game/chapters/2_day.rpy:3092
    old "1. <Did you take an advanced Underworld \nhacking class, Grim?>"
    new "1. <¿Tomaste una clase avanzada de hacking del Inframundo, Parca?>"

    # game/chapters/2_day.rpy:3097
    old "1. <All on your own?>"
    new "1. <¿Todo por tu cuenta?>"

    # game/chapters/2_day.rpy:3101
    old "1. <Not gonna lie, I'm impressed.>"
    new "1. <No voy a mentir, me impresionas.>"

    # game/chapters/2_day.rpy:3107
    old "1. <Actually, I've changed my mind!>"
    new "1. <¡De hecho, he cambiado de opinión!>"

    # game/chapters/2_day.rpy:3110
    old "1. <I've decided I'm appalled instead! \nAbsolutely disgusted.>"
    new "1. <¡He decidido que esto me horroriza! Esto es absolutamente indignante.>"

    # game/chapters/2_day.rpy:3116
    old "1. <I have security!>"
    new "1. <¡Tengo seguridad!>"

    # game/chapters/2_day.rpy:3119
    old "1. <Whatever one came with the computer.>"
    new "1. <Cualquiera que viniera con la computadora.>"

    # game/chapters/2_day.rpy:3126
    old "1. <Are you sure you aren't some super hacker?>"
    new "1. <¿Seguro que no eres algún súper hacker?>"

    # game/chapters/2_day.rpy:3131
    old "1. <Is it? I mean, every time we talk \nyou're just sitting in your room>"
    new "1. <¿En serio? Digo, cada vez que hablamos solo estás sentado en tu habitación.>"

    # game/chapters/2_day.rpy:3135
    old "1. <As a Grim Reaper? Yeah, kinda.>"
    new "1. <¿Como la Parca? Sí, algo así.>"

    # game/chapters/2_day.rpy:3141
    old "2. <Sounds like bullshit to me.>"
    new "2. <A mí me parece una tontería.>"

    # game/chapters/2_day.rpy:3145
    old "1. <I bet you had someone do it for you.>"
    new "1. <Apuesto a que alguien lo hizo por ti.>"

    # game/chapters/2_day.rpy:3148
    old "1. <You don't seem like the computer literate type.>"
    new "1. <No pareces del tipo que sabe de computadoras.>"

    # game/chapters/2_day.rpy:3156
    old "1. <I absolutely could!>"
    new "1. <¡Claro que podría!>"

    # game/chapters/2_day.rpy:3160
    old "1. <I do!>"
    new "1. <¡Lo hago!>"

    # game/chapters/2_day.rpy:3163
    old "1. <Getting creepy hacker vibes, not gonna lie.>"
    new "1. <Me das vibras de hacker raro, no voy a mentir.>"

    # game/chapters/2_day.rpy:3168
    old "1. <Could you? I'd like a few more hours in the day.>"
    new "1. <¿Podrías? Me gustaría tener unas horas más en el día.>"

    # game/chapters/2_day.rpy:3179
    old "1. <So you really just made up this whole \nprogram yourself?>"
    new "1. <¿Así que realmente inventaste todo este programa tú solo?>"

    # game/chapters/2_day.rpy:3184
    old "1. <How?>"
    new "1. <¿Cómo?>"

    # game/chapters/2_day.rpy:3190
    old "1. <Uh... I think I would understand \njust fine.>"
    new "1. <Uh... Creo que lo entendería perfectamente.>"

    # game/chapters/2_day.rpy:3193
    old "1. <I literally make games for a living.>"
    new "1. <Literalmente hago juegos para ganarme la vida.>"

    # game/chapters/2_day.rpy:3196
    old "1. <I'm sure I can understand at least some of your 'code'."
    new "1. <Sé que puedo entender al menos parte de tu 'código'.>"

    # game/chapters/2_day.rpy:3205
    old "1. <Did you pay someone else to make it?>"
    new "1. <¿Le pagaste a alguien para que lo hiciera?>"

    # game/chapters/2_day.rpy:3212
    old "1. <A tutorial? Like a... video? On programming?>"
    new "1. <¿Un tutorial? ¿Como un... video? ¿De programación?>"

    # game/chapters/2_day.rpy:3221
    old "1. <Not at all. Very resourceful of you.>"
    new "1. <Para nada. Muy ingenioso de tu parte.>"

    # game/chapters/2_day.rpy:3224
    old "1. <I shall add this to the list of attributes \nI associate you with.>"
    new "1. <Agregaré esto a la lista de atributos con los que te asocio.>"

    # game/chapters/2_day.rpy:3229
    old "1. <Annoying, creepy, weird, kinda cute, \nvery resourceful.>"
    new "1. <Molesto, espeluznante, raro, algo lindo, muy ingenioso.>"

    # game/chapters/2_day.rpy:3233
    old "1. <You are {i}all{/i} of these things.>"
    new "1. <Eres {i}todas{/i} estas cosas.>"

    # game/chapters/2_day.rpy:3239
    old "1. <Especially the cute part.>"
    new "1. <Especialmente la parte de lindo.>"

    # game/chapters/2_day.rpy:3241
    old "2. <You're not too bad looking.>"
    new "2. <No estás tan mal.>"

    # game/chapters/2_day.rpy:3247
    old "1. <Not true.>"
    new "1. <No es cierto.>"

    # game/chapters/2_day.rpy:3254
    old "1. <Tremble?>"
    new "1. <¿Temblar?>"

    # game/chapters/2_day.rpy:3259
    old "2. <Annoying, creepy, weird, weird again, weird for \na third time, just because why not.>"
    new "2. <Molesto, espeluznante, raro, raro otra vez, raro por tercera vez, porque sí.>"

    # game/chapters/2_day.rpy:3266
    old "1. <I think they capture you quite well.>"
    new "1. <Creo que te capturan bastante bien.>"

    # game/chapters/2_day.rpy:3269
    old "1. <None of them miss the mark.>"
    new "1. <Ninguno se queda corto.>"

    # game/chapters/2_day.rpy:3274
    old "1. <My bad, I must've missed those ones off somehow.>"
    new "1. <Mi error, de alguna manera se me olvidó incluirlos.>"

    # game/chapters/2_day.rpy:3280
    old "1. <I have revised it. Annnnnnnd...>"
    new "1. <La he revisado. Yyyyyy...>"

    # game/chapters/2_day.rpy:3283
    old "1. <I have decided to not change it.>"
    new "1. <He decidido no cambiarla.>"

    # game/chapters/2_day.rpy:3287
    old "3. <Annoying, creepy, weird, strangely sexy?> {font=gui/starthings.ttf}a{/font}"
    new "3. <¿Molesto, espeluznante, raro, extrañamente sexy?> {font=gui/starthings.ttf}a{/font}"

    # game/chapters/2_day.rpy:3291
    old "1. <But then you open your mouth.>"
    new "1. <Pero luego abres la boca.>"

    # game/chapters/2_day.rpy:3294
    old "1. <So you go down a notch on the sexy scale.>"
    new "1. <Así que bajas un punto en la escala sexy.>"

    # game/chapters/2_day.rpy:3298
    old "1. <With 1 being 'not at all sexy' and 10 being \n'the sexiest man alive', I'd say....>"
    new "1. <Con 1 siendo 'nada sexy en absoluto' y 10 siendo 'el hombre más sexy vivo', yo diría...>"

    # game/chapters/2_day.rpy:3301
    old "1. <A solid... one.>"
    new "1. <Un sólido... uno.>"

    # game/chapters/2_day.rpy:3313
    old "1. <You'll never know.>"
    new "1. <Nunca lo sabrás.>"

    # game/chapters/2_day.rpy:3316
    old "2. <A solid... two!>"
    new "2. <Un sólido... ¡dos!>"

    # game/chapters/2_day.rpy:3321
    old "1. <Hahaha... it seems so.>"
    new "1. <Jajaja... parece que sí.>"

    # game/chapters/2_day.rpy:3325
    old "1. <Maybe I lied?>"
    new "1. <¿Quizás mentí?>"

    # game/chapters/2_day.rpy:3331
    old "1. <I'm just making sure you're not up to anything shifty.>"
    new "1. <Solo me aseguro de que no estés haciendo nada turbio.>"

    # game/chapters/2_day.rpy:3334
    old "3. <A solid three!>"
    new "3. <¡Un sólido tres!>"

    # game/chapters/2_day.rpy:3340
    old "1. <At least I didn't say one.>"
    new "1. <Al menos no dije uno.>"

    # game/chapters/2_day.rpy:3343
    old "1. <Hahaha.>"
    new "1. <Jajaja.>"

    # game/chapters/2_day.rpy:3347
    old "1. <Whaaaaat? Nooo...>"
    new "1. <¿Quéeee? Nooo...>"

    # game/chapters/2_day.rpy:3350
    old "1. <Maybeeeeee.>"
    new "1. <Quizáaaaa.>"

    # game/chapters/2_day.rpy:3354
    old "1. <If you say so, Grim.>"
    new "1. <Si tú lo dices, Parca.>"

    # game/chapters/2_day.rpy:3357
    old "4. <A solid four, I would say!>"
    new "4. <¡Un sólido cuatro, diría yo!>"

    # game/chapters/2_day.rpy:3361
    old "1. <A four, yes!>"
    new "1. <Un cuatro, ¡sí!>"

    # game/chapters/2_day.rpy:3364
    old "1. <Aren't you pleased?>"
    new "1. <¿No estás contento?>"

    # game/chapters/2_day.rpy:3375
    old "1. <Me? Neveeeeer...>"
    new "1. <¿Yo? Nuuuunca...>"

    # game/chapters/2_day.rpy:3379
    old "1. <Is that what you think?>"
    new "1. <¿Eso es lo que piensas?>"

    # game/chapters/2_day.rpy:3382
    old "1. <Think what you want to think, Grim.>"
    new "1. <Piensa lo que quieras, Parca.>"

    # game/chapters/2_day.rpy:3385
    old "5. <A solid... five!>"
    new "5. <¡Un sólido... cinco!>"

    # game/chapters/2_day.rpy:3390
    old "1. <Hey, half sexy is pretty good.>"
    new "1. <Oye, medio sexy ya es bastante bueno.>"

    # game/chapters/2_day.rpy:3401
    old "1. <Wha—>"
    new "1. <¿Qué—?>"

    # game/chapters/2_day.rpy:3405
    old "1. <I wouldn't lie to you, mister Grim Reaper.>"
    new "1. <No te mentiría, señor Parca.>"

    # game/chapters/2_day.rpy:3412
    old "6. <A solid six!>"
    new "6. <¡Un sólido seis!>"

    # game/chapters/2_day.rpy:3416
    old "1. <I'd say six is pretty solid, no?>"
    new "1. <Yo diría que seis es bastante sólido, ¿no?>"

    # game/chapters/2_day.rpy:3420
    old "1. <You sure are confident.>"
    new "1. <Vaya que eres confiado.>"

    # game/chapters/2_day.rpy:3424
    old "1. <What?! And how exactly do I look at you?!>"
    new "1. <¡¿Qué?! ¡¿Y exactamente cómo te miro?!>"

    # game/chapters/2_day.rpy:3432
    old "7. <A solid seven!>"
    new "7. <¡Un sólido siete!>"

    # game/chapters/2_day.rpy:3436
    old "1. <Pretty high, no?>"
    new "1. <Bastante alto, ¿no?>"

    # game/chapters/2_day.rpy:3442
    old "1. <{i}You{/i} might think that.>"
    new "1. <Puede que {i}tú{/i} lo pienses.>"

    # game/chapters/2_day.rpy:3449
    old "1. <...If you say so, Grim.>"
    new "1. <...Si tú lo dices, Parca.>"

    # game/chapters/2_day.rpy:3452
    old "8. <A solid eight!>"
    new "8. <¡Un sólido ocho!>"

    # game/chapters/2_day.rpy:3460
    old "1. <Uh, there's not many other places to look.>"
    new "1. <Eh, no hay muchos otros lugares donde mirar.>"

    # game/chapters/2_day.rpy:3463
    old "1. <If you say so, Grim...>"
    new "1. <Si tú lo dices, Parca...>"

    # game/chapters/2_day.rpy:3466
    old "9. <A solid nine!>"
    new "9. <¡Un sólido nueve!>"

    # game/chapters/2_day.rpy:3470
    old "1. <I told you! You open your mouth and I knock \nyou down a notch!>"
    new "1. <¡Te lo dije! ¡Abres la boca y te bajo un punto!>"

    # game/chapters/2_day.rpy:3475
    old "1. <If anyone's a ten, it's me!>"
    new "1. <¡Si alguien es un diez, ese soy yo!>"

    # game/chapters/2_day.rpy:3481
    old "10. <...>"
    new "10. <...>"

    # game/chapters/2_day.rpy:3488
    old "1. <I suppose you'd be a ten...>"
    new "1. <Supongo que tú serías un diez...>"

    # game/chapters/2_day.rpy:3492
    old "1. <...What?>"
    new "1. <...¿Qué?>"

    # game/chapters/2_day.rpy:3496
    old "1. <My eyes do {i}not{/i} follow your every move!>"
    new "1. <¡Mis ojos {i}no{/i} siguen cada uno de tus movimientos!>"

    # game/chapters/2_day.rpy:3501
    old "1. <Shut it, {i}Grimmy{/i}.>"
    new "1. <Cállate, {i}Parquita{/i}.>"

    # game/chapters/2_day.rpy:3505
    old "1. <I said nothing about your charm.>"
    new "1. <No dije nada sobre tu encanto.>"

    # game/chapters/2_day.rpy:3508
    old "1. <You're a ten in arrogance, maybe.>"
    new "1. <Eres un diez en arrogancia, tal vez.>"

    # game/chapters/2_day.rpy:3513
    old "1. <Wait a second...>"
    new "1. <Espera un segundo...>"

    # game/chapters/2_day.rpy:3519
    old "1. <What is that behind you?!>"
    new "1. <¡¿Qué hay detrás de ti?!>"

    # game/chapters/2_day.rpy:3530
    old "1. <That plushie! On your bed!!!>"
    new "1. <¡Ese peluche! ¡¡¡En tu cama!!!>"

    # game/chapters/2_day.rpy:3533
    old "1. <It's so cute!>"
    new "1. <¡Es tan lindo!>"

    # game/chapters/2_day.rpy:3549
    old "1. <What... how did you move that so fast...>"
    new "1. <Qué... ¿cómo moviste eso tan rápido...?>"

    # game/chapters/2_day.rpy:3552
    old "1. <Bring it back, it's adorable.>"
    new "1. <Tráelo de vuelta, es adorable.>"

    # game/chapters/2_day.rpy:3557
    old "1. <What's its name?>"
    new "1. <¿Cómo se llama?>"

    # game/chapters/2_day.rpy:3562
    old "1. <Oh, a he?>"
    new "1. <Oh, ¿es un él?>"

    # game/chapters/2_day.rpy:3567
    old "1. <Grim has a little plushieeee. How adorable.>"
    new "1. <Parca tiene un peluchitoooo. Qué adorable.>"

    # game/chapters/2_day.rpy:3569
    old "2. <This is the highlight of my day!>"
    new "2. <¡Este es el mejor momento de mi día!>"

    # game/chapters/2_day.rpy:3571
    old "3. <This is {i}so{/i} unexpected.>"
    new "3. <Esto es {i}tan{/i} inesperado.>"

    # game/chapters/2_day.rpy:3573
    old "1. <Which makes it so, so much better.>"
    new "1. <Lo que lo hace muchísimo mejor.>"

    # game/chapters/2_day.rpy:3578
    old "1. <He's so cute and pink.>"
    new "1. <Es tan lindo y rosado.>"

    # game/chapters/2_day.rpy:3581
    old "1. <Let me name him for you!>"
    new "1. <¡Déjame ponerle nombre!>"

    # game/chapters/2_day.rpy:3586
    old "1. <How about—>"
    new "1. <¿Qué tal—>"

    # game/chapters/2_day.rpy:3590
    old "1. <Oh, I've got the perfect na—>"
    new "1. <Oh, tengo el nombre perfec—>"

    # game/chapters/2_day.rpy:3599
    old "1. <Okay, that's cute.>"
    new "1. <Okey, eso es lindo.>"

    # game/chapters/2_day.rpy:3601
    old "1. <I'm somehow unsurprised by that name.>"
    new "1. <Por alguna razón, ese nombre no me sorprende.>"

    # game/chapters/2_day.rpy:3604
    old "2. <Of course it is.>"
    new "2. <Por supuesto que sí.>"

    # game/chapters/2_day.rpy:3606
    old "1. <I should have seen this coming.>"
    new "1. <Debí haberlo visto venir.>"

    # game/chapters/2_day.rpy:3610
    old "1. <{i}The Angel of Death{/i}, of course you \nwould name him Azrael.>"
    new "1. <{i}El Ángel de la Muerte{/i}, por supuesto que lo llamarías Azrael.>"

    # game/chapters/2_day.rpy:3615
    old "1. <I would have given him a great name, actually."
    new "1. <Yo le habría dado un gran nombre, en serio.>"

    # game/chapters/2_day.rpy:3618
    old "1. <Something absolutely fabulous.>"
    new "1. <Algo absolutamente fabuloso.>"

    # game/chapters/2_day.rpy:3620
    old "2. <Something positively devious.>"
    new "2. <Algo positivamente diabólico.>"

    # game/chapters/2_day.rpy:3622
    old "3. <Something SO, SO cute.>"
    new "3. <Algo TAN, TAN lindo.>"

    # game/chapters/2_day.rpy:3630
    old "1. <Isn't it a bit late to go off to work?>"
    new "1. <¿No es un poco tarde para irte a trabajar?>"

    # game/chapters/2_day.rpy:3639
    old "1. <See ya, Grim.>"
    new "1. <Nos vemos, Parca.>"

    # game/chapters/2_day.rpy:3671
    old "1. <That almost sounded romantic!>"
    new "1. <¡Eso casi sonó romántico!>"

