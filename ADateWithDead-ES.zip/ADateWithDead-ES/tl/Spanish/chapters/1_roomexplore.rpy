# TODO: Translation updated at 2026-10-15 18:36

# game/chapters/1_roomexplore.rpy:366
translate Spanish bed_hub_c63951e0:

    # "Your comfortable bed."
    "Tu cómoda cama."

# game/chapters/1_roomexplore.rpy:367
translate Spanish bed_hub_b2f03db4:

    # "It's seen you through many a night's sleep."
    "Te ha acompañado en muchas noches de sueño."

# game/chapters/1_roomexplore.rpy:368
translate Spanish bed_hub_dee7ea0f:

    # "You're not that tired yet, though."
    "Aunque aún no estás tan cansad[letra]."

# game/chapters/1_roomexplore.rpy:369
translate Spanish bed_hub_d1033f6b:

    # "You can't help but recall the day you bought this bed. It was your first piece of furniture you bought for yourself."
    "No puedes evitar recordar el día en que compraste esta cama. Fue el primer mueble que compraste para ti."

# game/chapters/1_roomexplore.rpy:370
translate Spanish bed_hub_7e2fefba:

    # "Not only was it too big to fit up the narrow stairwell, you got it wedged halfway up."
    "No solo era demasiado grande para subirla por la estrecha escalera, sino que además terminó atascada a mitad de camino."

# game/chapters/1_roomexplore.rpy:371
translate Spanish bed_hub_18b39559:

    # "You thought you were going to have to sleep there from now on."
    "Pensaste que ibas a tener que dormir ahí de ahora en adelante."

# game/chapters/1_roomexplore.rpy:372
translate Spanish bed_hub_eeaffff0:

    # "But eventually it came free... and then you stepped on a loose floorboard and nearly plummeted down a few flights of stairs."
    "Pero al final lograste liberarla... y luego pisaste una tabla suelta del suelo y casi caíste por varios tramos de escaleras."

# game/chapters/1_roomexplore.rpy:373
translate Spanish bed_hub_fc0dba82:

    # "Whoops."
    "Ups."

# game/chapters/1_roomexplore.rpy:374
translate Spanish bed_hub_a4a91e09:

    # "It's certainly an experience you'll never forget, at least?"
    "Al menos, sin duda es una experiencia que nunca olvidarás, ¿no?"

# game/chapters/1_roomexplore.rpy:383
translate Spanish door_hub_48c0cf48:

    # "The door leads out to the hallway beyond."
    "La puerta conduce al pasillo de afuera."

# game/chapters/1_roomexplore.rpy:384
translate Spanish door_hub_2f8038fc:

    # "Your apartment is on the fifth floor of a downtown apartment building."
    "Tu apartamento está en el quinto piso de un edificio en el centro de la ciudad."

# game/chapters/1_roomexplore.rpy:385
translate Spanish door_hub_3b5cdc2a:

    # "There's nowhere you want to go at the moment, but you overhear some talking on the other side in the hall beyond."
    "No hay ningún lugar al que quieras ir por el momento, pero alcanzas a oír voces en el pasillo."

# game/chapters/1_roomexplore.rpy:386
translate Spanish door_hub_66779503:

    # "You don't know your neighbors very well yet. Perhaps now is a good time to learn more about them?"
    "Todavía no conoces muy bien a tus vecinos. ¿Quizás ahora sea un buen momento para saber más de ellos?"

# game/chapters/1_roomexplore.rpy:391
translate Spanish door_hub_2e0d72de:

    # "You put your ear to the door, straining through the wood to hear the words being spoken beyond."
    "Pones la oreja en la puerta, esforzándote por escuchar las palabras a través de la madera."

# game/chapters/1_roomexplore.rpy:392
translate Spanish door_hub_0bcc5762:

    # "You hear the sound of someone knocking, then a door opening."
    "Oyes que alguien llama a la puerta y luego cómo se abre."

# game/chapters/1_roomexplore.rpy:393
translate Spanish door_hub_ac92ea3f:

    # "'Sorry to disturb you—I just moved in down the hall, and I had a package meant for you delivered to my apartment.' A deep, rich voice floats through the door."
    "'Perdón por molestarte—me acabo de mudar al fondo del pasillo, y me entregaron en mi apartamento un paquete que era para ti.' Una voz profunda y grave flota a través de la puerta."

# game/chapters/1_roomexplore.rpy:394
translate Spanish door_hub_1ba052a2:

    # "'Oh my gosh—I thought the package got lost! I really can't thank you enough.' The other voice responds, light and somewhat airy."
    "'¡Dios mío! ¡Pensé que el paquete se había perdido! De verdad, no sé cómo agradecerte lo suficiente'. Responde la otra voz, ligera y algo despreocupada."

# game/chapters/1_roomexplore.rpy:395
translate Spanish door_hub_a09ab777:

    # "'Well, it gave me a chance to introduce myself to you, so I'd call it good luck on my part. Here, all yours.'"
    "'Bueno, me dio la oportunidad de presentarme, así que diría que tuve suerte. Toma, es tuyo.'"

# game/chapters/1_roomexplore.rpy:396
translate Spanish door_hub_6b1453a2:

    # "'Thanks again... um...' The voice trails off."
    "'Gracias otra vez... em...' La voz se desvanece."

# game/chapters/1_roomexplore.rpy:397
translate Spanish door_hub_550e9d0e:

    # "'Oh! My apologies, my name is—' The voice is muffled for a moment as the elevator dings, and you miss the next few words. '—your humble servant.'"
    "'¡Ah! Disculpa, me llamo—' La voz se pierde por un momento cuando suena el ascensor, y no alcanzas a oír las siguientes palabras. '—para servirte'."

# game/chapters/1_roomexplore.rpy:398
translate Spanish door_hub_39a677a4:

    # "The second voice laughs. 'I feel like I owe you something for having to bring that heavy box all the way over here.'"
    "La segunda voz ríe. 'Siento que te debo algo por haberte hecho traer esa caja tan pesada hasta aquí'."

# game/chapters/1_roomexplore.rpy:399
translate Spanish door_hub_69c5a11a:

    # "'I would hardly call one flight of stairs 'all the way over', but I wouldn't turn down a coffee?' The deeper voice replies." id door_hub_69c5a11a
    "'Tampoco diría que subir un solo tramo de escaleras sea venir desde tan lejos, pero no le diría que no a un café'. Responde la voz más grave." id door_hub_69c5a11a

# game/chapters/1_roomexplore.rpy:400
translate Spanish door_hub_1d4c2e51:

    # "'Oh! How about... tomorrow?'"
    "'¡Oh! ¿Qué tal... mañana?'"

# game/chapters/1_roomexplore.rpy:401
translate Spanish door_hub_0a4e4798:

    # "'It's a date. I mean, not really, but... see you tomorrow.'"
    "'¡Entonces es una cita! Bueno, no exactamente, pero... nos vemos mañana'."

# game/chapters/1_roomexplore.rpy:402
translate Spanish door_hub_b5790fa3:

    # "'See you!'"
    "'¡Nos vemos!'"

# game/chapters/1_roomexplore.rpy:403
translate Spanish door_hub_b62821ce:

    # "You hear the door close and the sound of footsteps walking away from the door, and then silence."
    "Oyes que la puerta se cierra y pasos que se alejan por el pasillo, y luego silencio."

# game/chapters/1_roomexplore.rpy:404
translate Spanish door_hub_a12d64cc:

    # "...Before you hear the sound of pottery falling then shattering onto the ground."
    "...Hasta que escuchas el sonido de cerámica cayendo y rompiéndose contra el suelo."

# game/chapters/1_roomexplore.rpy:405
translate Spanish door_hub_02098a34:

    # "The door opens again."
    "La puerta se abre de nuevo."

# game/chapters/1_roomexplore.rpy:406
translate Spanish door_hub_e3cf6106:

    # "The deep voice speaks first 'I, uh... didn't see your plant there. Coffee's on me?'"
    "La voz profunda habla primero. 'Yo, eh... no vi tu planta ahí. ¿El café corre por mi cuenta?'"

# game/chapters/1_roomexplore.rpy:407
translate Spanish door_hub_310fcedd:

    # "You hear the second voice giggle, then speak. 'It's alright, I've been meaning to get a new pot for ages.'"
    "Escuchas la segunda voz reír, luego hablar. 'Está bien, tenía pensado comprar una maceta nueva desde hace tiempo.'"

# game/chapters/1_roomexplore.rpy:408
translate Spanish door_hub_7a07a6dc:

    # "'Let me at least help cleaning it up.'"
    "'Al menos déjame ayudarte a limpiarlo.'"

# game/chapters/1_roomexplore.rpy:409
translate Spanish door_hub_0123fc97:

    # "'It's really no trouble—'"
    "'De verdad, no es problema—'"

# game/chapters/1_roomexplore.rpy:410
translate Spanish door_hub_3f8cd6df:

    # "'I insist. I was the clumsy one.'"
    "'Insisto. Quien metió la pata fui yo.'"

# game/chapters/1_roomexplore.rpy:411
translate Spanish door_hub_547c15a9:

    # "'...Alright. Let me get the broom.'"
    "'…Está bien. Voy por la escoba.'"

# game/chapters/1_roomexplore.rpy:412
translate Spanish door_hub_0ba6f623:

    # "The voices become muffled, then silent. That seems to be all the information you'll get for the day."
    "Las voces se oyen cada vez más apagadas hasta que finalmente guardan silencio. Parece que eso es todo lo que conseguirás averiguar por hoy."

# game/chapters/1_roomexplore.rpy:424
translate Spanish door_hub_2e0d72de_1:

    # "You put your ear to the door, straining through the wood to hear the words being spoken beyond."
    "Pones la oreja en la puerta, esforzándote por escuchar las palabras a través de la madera."

# game/chapters/1_roomexplore.rpy:425
translate Spanish door_hub_0bcc5762_1:

    # "You hear the sound of someone knocking, then a door opening."
    "Oyes que alguien llama a la puerta y luego cómo se abre."

# game/chapters/1_roomexplore.rpy:426
translate Spanish door_hub_ac92ea3f_1:

    # "'Sorry to disturb you—I just moved in down the hall, and I had a package meant for you delivered to my apartment.' A deep, rich voice floats through the door."
    "'Perdón por molestarte—me acabo de mudar al fondo del pasillo, y me entregaron en mi apartamento un paquete que era para ti'. Una voz profunda y grave flota a través de la puerta."

# game/chapters/1_roomexplore.rpy:427
translate Spanish door_hub_1ba052a2_1:

    # "'Oh my gosh—I thought the package got lost! I really can't thank you enough.' The other voice responds, light and somewhat airy."
    "'¡Dios mío—pensé que el paquete se había perdido! De verdad no sé cómo agradecerte lo suficiente'. Responde la otra voz, ligera y un tanto despreocupada."

# game/chapters/1_roomexplore.rpy:428
translate Spanish door_hub_a09ab777_1:

    # "'Well, it gave me a chance to introduce myself to you, so I'd call it good luck on my part. Here, all yours.'"
    "'Bueno, me dio la oportunidad de presentarme, así que lo tomaré como buena suerte de mi parte. Aquí, es todo tuyo'."

# game/chapters/1_roomexplore.rpy:429
translate Spanish door_hub_6b1453a2_1:

    # "'Thanks again... um...' The voice trails off."
    "'Gracias otra vez... em...' La voz se desvanece."

# game/chapters/1_roomexplore.rpy:430
translate Spanish door_hub_550e9d0e_1:

    # "'Oh! My apologies, my name is—' The voice is muffled for a moment as the elevator dings, and you miss the next few words. '—your humble servant.'"
    "'¡Ah! Mis disculpas, mi nombre es—' La voz se amortigua un momento cuando suena el ascensor, y pierdes las siguientes palabras. '—a tu disposición.'"

# game/chapters/1_roomexplore.rpy:431
translate Spanish door_hub_39a677a4_1:

    # "The second voice laughs. 'I feel like I owe you something for having to bring that heavy box all the way over here.'"
    "La segunda voz ríe. 'Siento que te debo algo por haberte hecho traer esa caja tan pesada hasta aquí'."

# game/chapters/1_roomexplore.rpy:432
translate Spanish door_hub_69c5a11a_1:

    # "'I would hardly call one flight of stairs 'all the way over', but I wouldn't turn down a coffee?' The deeper voice replies." id door_hub_69c5a11a_1
    "'Tampoco diría que subir un solo tramo de escaleras sea venir desde tan lejos, pero no le diría que no a un café'. Responde la voz más grave." id door_hub_69c5a11a_1

# game/chapters/1_roomexplore.rpy:433
translate Spanish door_hub_1d4c2e51_1:

    # "'Oh! How about... tomorrow?'"
    "'¡Oh! ¿Qué tal... mañana?'"

# game/chapters/1_roomexplore.rpy:434
translate Spanish door_hub_0a4e4798_1:

    # "'It's a date. I mean, not really, but... see you tomorrow.'"
    "'¡Entonces es una cita! Bueno, no exactamente, pero... nos vemos mañana'."

# game/chapters/1_roomexplore.rpy:435
translate Spanish door_hub_b5790fa3_1:

    # "'See you!'"
    "'¡Nos vemos!'"

# game/chapters/1_roomexplore.rpy:436
translate Spanish door_hub_b62821ce_1:

    # "You hear the door close and the sound of footsteps walking away from the door, and then silence."
    "Oyes que la puerta se cierra y pasos que se alejan por el pasillo, y luego silencio."

# game/chapters/1_roomexplore.rpy:437
translate Spanish door_hub_a12d64cc_1:

    # "...Before you hear the sound of pottery falling then shattering onto the ground."
    "...Hasta que escuchas el sonido de cerámica cayendo y rompiéndose contra el suelo."

# game/chapters/1_roomexplore.rpy:438
translate Spanish door_hub_02098a34_1:

    # "The door opens again."
    "La puerta se abre de nuevo."

# game/chapters/1_roomexplore.rpy:439
translate Spanish door_hub_e3cf6106_1:

    # "The deep voice speaks first 'I, uh... didn't see your plant there. Coffee's on me?'"
    "La voz profunda habla primero. 'Yo, eh... no vi tu planta ahí. ¿El café corre por mi cuenta?'"

# game/chapters/1_roomexplore.rpy:440
translate Spanish door_hub_310fcedd_1:

    # "You hear the second voice giggle, then speak. 'It's alright, I've been meaning to get a new pot for ages.'"
    "Escuchas la segunda voz reír, luego hablar. 'Está bien, tenía pensado comprar una maceta nueva desde hace tiempo.'"

# game/chapters/1_roomexplore.rpy:441
translate Spanish door_hub_7a07a6dc_1:

    # "'Let me at least help cleaning it up.'"
    "'Al menos déjame ayudarte a limpiarlo.'"

# game/chapters/1_roomexplore.rpy:442
translate Spanish door_hub_0123fc97_1:

    # "'It's really no trouble—'"
    "'De verdad, no es problema—'"

# game/chapters/1_roomexplore.rpy:443
translate Spanish door_hub_3f8cd6df_1:

    # "'I insist. I was the clumsy one.'"
    "'Insisto. Quien metió la pata fui yo.'"

# game/chapters/1_roomexplore.rpy:444
translate Spanish door_hub_547c15a9_1:

    # "'...Alright. Let me get the broom.'"
    "'...Está bien. Voy por la escoba.'"

# game/chapters/1_roomexplore.rpy:445
translate Spanish door_hub_0ba6f623_1:

    # "The voices become muffled, then silent. That seems to be all the information you'll get for the day."
    "Las voces se oyen cada vez más apagadas hasta que finalmente guardan silencio. Parece que eso es todo lo que conseguirás averiguar por hoy."

# game/chapters/1_roomexplore.rpy:454
translate Spanish door_hub_2f1c9994:

    # "You listen at the door again: but all is quiet now."
    "Escuchas en la puerta de nuevo: pero ahora todo está en silencio."

# game/chapters/1_roomexplore.rpy:455
translate Spanish door_hub_7198b0b8:

    # "Perhaps you'll overhear more tomorrow?"
    "¿Quizás escuches más mañana?"

# game/chapters/1_roomexplore.rpy:473
translate Spanish snake_hub_404f3926:

    # "[pet_name] is napping on your bed."
    "[pet_name] está durmiendo la siesta en tu cama."

# game/chapters/1_roomexplore.rpy:474
translate Spanish snake_hub_5968bb4c:

    # "[pet_She] doesn't seem to want to go back into [pet_her] enclosure."
    "[pet_She!t] no parece querer volver a su recinto."

# game/chapters/1_roomexplore.rpy:475
translate Spanish snake_hub_93f6de20:

    # "You leave [pet_her2] be for now."
    "Dejas a [pet_name] en paz por ahora."

# game/chapters/1_roomexplore.rpy:482
translate Spanish snake_hub_d70c8654:

    # "You leave a little kiss against [pet_name]'s snoot."
    "Le das un besito en el hocico a [pet_name]."

# game/chapters/1_roomexplore.rpy:483
translate Spanish snake_hub_6f43f348:

    # "[pet_She] rubs [pet_her] little head against you."
    "[pet_She!t] frota su cabecita contra ti."

# game/chapters/1_roomexplore.rpy:497
translate Spanish bingus_hub_7da77281:

    # "[pet_name] is sitting on your bed regally."
    "[pet_name] está en tu cama con porte real."

# game/chapters/1_roomexplore.rpy:498
translate Spanish bingus_hub_9ade7f8b:

    # "For a moment you're unsure if you own [pet_name], or if [pet_name] owns you."
    "Por un momento, cuesta saber si [pet_name] te pertenece, o si le perteneces a [pet_name]."

# game/chapters/1_roomexplore.rpy:499
translate Spanish bingus_hub_132e369c:

    # "But of course, it's obvious to you. [pet_name] merely allows your existence."
    "Pero por supuesto, para ti es obvio. [pet_name] simplemente permite tu existencia."

# game/chapters/1_roomexplore.rpy:504
translate Spanish bingus_hub_435690d7:

    # "You pet [pet_name]."
    "Acaricias a [pet_name]."

# game/chapters/1_roomexplore.rpy:505
translate Spanish bingus_hub_b92c3a57:

    # "[pet_Her] skin is velvet to the touch."
    "Su piel es aterciopelada al tacto."

# game/chapters/1_roomexplore.rpy:506
translate Spanish bingus_hub_4de66689:

    # "[pet_She] purrs in response as you give [pet_her2] a scritch under the chin." id bingus_hub_4de66689
    "[pet_She!t] ronronea en respuesta mientras le rascas bajo la barbilla." id bingus_hub_4de66689

# game/chapters/1_roomexplore.rpy:521
translate Spanish bunny_hub_b750ff85:

    # "[pet_name] is currently zooming around your bed, playing with toys you bought recently."
    "[pet_name] está dando vueltas por tu cama, jugando con juguetes que compraste recientemente."

# game/chapters/1_roomexplore.rpy:522
translate Spanish bunny_hub_ebd22173:

    # "[pet_name] slows down for no-bunny."
    "[pet_name] no reduce la velocidad por nadie... ¡ni siquiera por un conejo!"

# game/chapters/1_roomexplore.rpy:527
translate Spanish bunny_hub_3779c4eb:

    # "You give [pet_name] a few pieces of leafy greens, and [pet_she] chews on them hungrily."
    "Le das a [pet_name] unas hojas verdes, y [pet_she!t] las mastica con ganas."

# game/chapters/1_roomexplore.rpy:528
translate Spanish bunny_hub_7a1a813a:

    # "Your stomach rumbles, and for a moment you wish you were a bunny, simple running around on a bed and eating greens."
    "Te ruge el estómago y, por un momento, desearías ser un conejo: simplemente correr por la cama y comer hojas verdes."

# game/chapters/1_roomexplore.rpy:542
translate Spanish cat_hub_d953f12f:

    # "[pet_name] is fast asleep in the sun."
    "[pet_name] está profundamente dormid[letra_pet] al sol."

# game/chapters/1_roomexplore.rpy:543
translate Spanish cat_hub_b33fec15:

    # "You gently stroke down [pet_name]'s back, not wanting to disturb [pet_her2]."
    "Acaricias suavemente la espalda de [pet_name], sin querer molestarl[letra_pet]."

# game/chapters/1_roomexplore.rpy:544
translate Spanish cat_hub_e7304e73:

    # "[pet_She]'s so fluffy and soft."
    "[pet_She!t] tiene un pelaje tan suave y esponjoso."

# game/chapters/1_roomexplore.rpy:549
translate Spanish cat_hub_8942db52:

    # "You gently poke at [pet_name]'s toebeans."
    "Presionas suavemente las almohadillas de [pet_name]."

# game/chapters/1_roomexplore.rpy:550
translate Spanish cat_hub_8917cd5c:

    # "They're squishy beneath your fingertips."
    "Son blanditas bajo tus dedos."

# game/chapters/1_roomexplore.rpy:551
translate Spanish cat_hub_c04c2936:

    # "You're thankful [pet_name] is the rare kind of cat who likes belly rubs and toebean poking."
    "Agradeces que [pet_name] sea una rara excepción entre los gatos: le gustan los masajes de panza y que le aprieten las almohadillas."

# game/chapters/1_roomexplore.rpy:565
translate Spanish dog_hub_02ee5665:

    # "[pet_name] is resting on your bed, tongue wagging."
    "[pet_name] está descansando en tu cama, con la lengua fuera."

# game/chapters/1_roomexplore.rpy:566
translate Spanish dog_hub_e3c67bbb:

    # "You give them a belly rub. [pet_She] loves belly rubs."
    "Le das un masaje en la panza. A [pet_She!t] le encantan."

# game/chapters/1_roomexplore.rpy:567
translate Spanish dog_hub_c4e03d70:

    # "What a good [pet_girl]."
    "Qué [buen_pet] [pet_girl!t]."

# game/chapters/1_roomexplore.rpy:572
translate Spanish dog_hub_c7a21c75:

    # "You give [pet_name] a little treat. [pet_She] gobbles it up easily."
    "Le das una golosina a [pet_name]. [pet_She!t] se la come enseguida."

# game/chapters/1_roomexplore.rpy:573
translate Spanish dog_hub_3c60cfee:

    # "Who's a good [pet_girl]? You're a good [pet_girl]!"
    "¿Quién es mi [buen_pet] [pet_girl!t]? ¡Tú eres mi [buen_pet] [pet_girl!t]!"

# game/chapters/1_roomexplore.rpy:588
translate Spanish hamster_hub_1b479ac6:

    # "[pet_name] is running around on your bed."
    "[pet_name] está corriendo alrededor de tu cama."

# game/chapters/1_roomexplore.rpy:589
translate Spanish hamster_hub_4dddd35e:

    # "You spent a lot of time hamster-proofing your apartment, so you don't mind [pet_name] having free reign of the place occasionally."
    "Pasaste mucho tiempo adaptando tu apartamento para hámsteres, así que no te importa que [pet_name] tenga libertad por el lugar de vez en cuando."

# game/chapters/1_roomexplore.rpy:590
translate Spanish hamster_hub_670a2307:

    # "You smile at [pet_name], then give [pet_her2] a little scritch on the head."
    "Sonríes a [pet_name], luego le das una pequeña caricia en la cabeza."

# game/chapters/1_roomexplore.rpy:595
translate Spanish hamster_hub_e0610401:

    # "You quickly cut up a slice of apple and give it to [pet_name]."
    "Cortas rápidamente una rebanada de manzana y se la das a [pet_name]."

# game/chapters/1_roomexplore.rpy:596
translate Spanish hamster_hub_e8bd748a:

    # "[pet_She] snacks on the treat hungrily."
    "[pet_She!t] devora el premio con ganas."

# game/chapters/1_roomexplore.rpy:597
translate Spanish hamster_hub_769a4bea:

    # "You smile. Apple has always been [pet_her] favorite snack."
    "Sonríes. La manzana siempre ha sido su merienda favorita."

# game/chapters/1_roomexplore.rpy:615
translate Spanish plant_hub_df5ee1ca:

    # "You give your sprout a hearty drink."
    "Le das a tu retoño un buen trago de agua."

# game/chapters/1_roomexplore.rpy:616
translate Spanish plant_hub_fe670acc:

    # "You swear you almost hear it saying thank you."
    "Jurarías que casi lo escuchas decir gracias."

# game/chapters/1_roomexplore.rpy:628
translate Spanish plant_hub_996a6523:

    # "You decide it still looks thirsty."
    "Decides que aún parece tener sed."

# game/chapters/1_roomexplore.rpy:629
translate Spanish plant_hub_140fd76b:

    # "Water starts to pool on top of the soil."
    "El agua empieza a acumularse sobre la tierra."

# game/chapters/1_roomexplore.rpy:639
translate Spanish plant_hub_c2b8e22c:

    # "You decide you've made plenty of bad decisions in your life - what's one more?"
    "Decides que ya has tomado muchas malas decisiones en tu vida, ¿qué es una más?"

# game/chapters/1_roomexplore.rpy:642
translate Spanish plant_hub_ec01dea4:

    # "Water starts overflowing from the edges of the pot as you continue to pour more in."
    "El agua empieza a desbordarse por los bordes de la maceta mientras sigues echando más."

# game/chapters/1_roomexplore.rpy:643
translate Spanish plant_hub_2133bcde:

    # "It flows all over the floor."
    "Se escurre por todo el suelo."

# game/chapters/1_roomexplore.rpy:644
translate Spanish plant_hub_51ebf01e:

    # "Fantastic, you think."
    "Fantástico, piensas."

# game/chapters/1_roomexplore.rpy:645
translate Spanish plant_hub_58344ac4:

    # "You are your own worst enemy."
    "Eres tu peor enemig[letra]."

# game/chapters/1_roomexplore.rpy:733
translate Spanish desk_hub_b2210f18:

    # "Your trusty laptop."
    "Tu fiel portátil."

# game/chapters/1_roomexplore.rpy:734
translate Spanish desk_hub_f2affa1b:

    # "It was your first purchase for yourself after you moved out."
    "Fue tu primera compra después de mudarte."

# game/chapters/1_roomexplore.rpy:735
translate Spanish desk_hub_31426c18:

    # "Remembering how you saved to be able to afford the one you wanted brings a smile to your face."
    "Recordar cuánto ahorraste para poder comprarte el que querías te hace sonreír."

# game/chapters/1_roomexplore.rpy:738
translate Spanish desk_hub_b2210f18_1:

    # "Your trusty laptop."
    "Tu fiel portátil."

# game/chapters/1_roomexplore.rpy:739
translate Spanish desk_hub_f2affa1b_1:

    # "It was your first purchase for yourself after you moved out."
    "Fue tu primera compra después de mudarte."

# game/chapters/1_roomexplore.rpy:740
translate Spanish desk_hub_31426c18_1:

    # "Remembering how you saved to be able to afford the one you wanted brings a smile to your face."
    "Recordar cuánto ahorraste para poder comprarte el que querías te hace sonreír."

# game/chapters/1_roomexplore.rpy:746
translate Spanish desk_hub_66549397:

    # "That's it, you think. You are going to commit a very bad act to this laptop of yours."
    "Eso es todo, piensas. Vas a hacerle algo terrible a tu portátil."

# game/chapters/1_roomexplore.rpy:747
translate Spanish desk_hub_98709d7f:

    # "You've halfway opened your window when you come to your senses and close the app once more."
    "Ya has abierto la ventana hasta la mitad cuando recuperas el sentido común y vuelves a cerrar la aplicación."

# game/chapters/1_roomexplore.rpy:748
translate Spanish desk_hub_75d4c771:

    # "You quickly delete it from your desktop, and empty your trashcan."
    "La eliminas rápidamente del escritorio y vacías la papelera."

# game/chapters/1_roomexplore.rpy:749
translate Spanish desk_hub_58376d71:

    # "But two moments later, it reappears exactly where it was before, and opens again."
    "Pero un instante después, reaparece exactamente donde estaba antes, y se abre de nuevo."

# game/chapters/1_roomexplore.rpy:750
translate Spanish desk_hub_59438d56:

    # "You think about the sketchy sites you've been on, but even that is hard to concentrate on past the constant dinging."
    "Piensas en los sitios dudosos que has visitado, pero ni siquiera puedes concentrarte en eso debido al incesante sonido de las notificaciones."

# game/chapters/1_roomexplore.rpy:751
translate Spanish desk_hub_18abafc1:

    # "You attempt to delete it again, but it won't delete anymore."
    "Intentas borrarla otra vez, pero ya no se puede borrar."

# game/chapters/1_roomexplore.rpy:756
translate Spanish desk_hub_733f21a5:

    # "Nothing happens."
    "No pasa nada."

# game/chapters/1_roomexplore.rpy:759
translate Spanish desk_hub_d1c9262e:

    # "Nothing continues to happen."
    "Sigue sin pasar nada."

# game/chapters/1_roomexplore.rpy:765
translate Spanish desk_hub_1ded2928:

    # "Nope, you think. Not today."
    "Nop, piensas. Hoy no."

# game/chapters/1_roomexplore.rpy:766
translate Spanish desk_hub_44523497:

    # "You keep staring at it."
    "Sigues mirándola fijamente."

# game/chapters/1_roomexplore.rpy:767
translate Spanish desk_hub_5f9b772e:

    # "...."
    "...."

# game/chapters/1_roomexplore.rpy:768
translate Spanish desk_hub_d1ddaffa:

    # "........"
    "........"

# game/chapters/1_roomexplore.rpy:769
translate Spanish desk_hub_7413fd7d:

    # "The dinging begins to drive you insane."
    "El constante sonido de las notificaciones empieza a volverte loc[letra]."

# game/chapters/1_roomexplore.rpy:770
translate Spanish desk_hub_f6bc19b7:

    # "You attempt to shut the computer down, but even that isn't working."
    "Intentas apagar el portátil, pero ni eso funciona."

# game/chapters/1_roomexplore.rpy:773
translate Spanish desk_hub_d9a2f93a:

    # "It seems to be a strange chatroom."
    "Parece ser una sala de chat extraña."

# game/chapters/1_roomexplore.rpy:778
translate Spanish desk_hub_397e2b78:

    # "You click on the app, finally taking a good look at it."
    "Haces clic en la aplicación y por fin la examinas detenidamente."

# game/chapters/1_roomexplore.rpy:779
translate Spanish desk_hub_b7a04f90:

    # "It's some kind of chatroom. It looks somewhat retro."
    "Es una especie de sala de chat. Tiene un aspecto algo retro."

# game/chapters/1_roomexplore.rpy:797
translate Spanish desk_forced_16e7e189:

    # "A ding comes from your laptop."
    "Suena una notificación en tu portátil."

# game/chapters/1_roomexplore.rpy:798
translate Spanish desk_forced_1cdf5c49:

    # "You take a look at what you expected to be an email..."
    "Echas un vistazo a lo que esperabas que fuera un correo..."

# game/chapters/1_roomexplore.rpy:799
translate Spanish desk_forced_fb9e7a99:

    # "Instead, you find yourself face to face with a strange app you've never seen before."
    "En su lugar, te encuentras cara a cara con una extraña aplicación que nunca habías visto antes."

# game/chapters/1_roomexplore.rpy:800
translate Spanish desk_forced_6d5e2a31:

    # "You look at it for a moment, before hitting the 'x' in the corner of the program."
    "La miras por un momento, antes de darle a la 'x' en la esquina del programa."

# game/chapters/1_roomexplore.rpy:818
translate Spanish desk_forced_2dd45ee4:

    # "A second ding echoes through the room."
    "Una segunda notificación resuena por la habitación."

# game/chapters/1_roomexplore.rpy:819
translate Spanish desk_forced_6173fb06:

    # "Worried, you look back to your laptop's screen."
    "Con preocupación miras de nuevo la pantalla del portátil."

# game/chapters/1_roomexplore.rpy:820
translate Spanish desk_forced_5bc5655f:

    # "The app is once again open and flashing on your hotbar."
    "La app está abierta otra vez y parpadea en tu barra de tareas."

# game/chapters/1_roomexplore.rpy:821
translate Spanish desk_forced_728e7b48:

    # "You wonder for a moment if you'd somehow picked up some malware."
    "Por un momento te preguntas si de alguna forma se te habrá colado algún malware."

# game/chapters/1_roomexplore.rpy:839
translate Spanish desk_forced_b6ee5a82:

    # "The dings are coming much more frequently now. Someone - or something - wants your attention."
    "Ahora las notificaciones suenan cada vez más seguido. Alguien —o algo— quiere llamar tu atención."

# game/chapters/1_roomexplore.rpy:840
translate Spanish desk_forced_f6bd783d:

    # "You're not worried now - you're angry."
    "Ya no estás preocupad[letra]; ahora estás enojad[letra]."

# game/chapters/1_roomexplore.rpy:841
translate Spanish desk_forced_a8490a60:

    # "The dinging is starting to annoy you."
    "El sonido de las notificaciones empieza a molestarte."

# game/chapters/1_roomexplore.rpy:842
translate Spanish desk_forced_e7b2f0f6:

    # "For a moment, you contemplate throwing your laptop out of the window, but calm before you possibly commit a crime by dropping a laptop from the fifth story of a building and knocking someone out."
    "Por un momento, consideras arrojar tu portátil por la ventana, pero logras calmarte antes de cometer un posible delito al dejar caer un portátil desde el quinto piso y dejar a alguien inconsciente."

# game/chapters/1_roomexplore.rpy:858
translate Spanish desk_forced_f0b94484:

    # "The dinging is constant. You don't know how much longer you can put up with the sound."
    "El sonido de las notificaciones es constante. No sabes cuánto tiempo más podrás soportarlo."

# game/chapters/1_roomexplore.rpy:859
translate Spanish desk_forced_a0af7c6b:

    # "Perhaps it's time to check what's going on here..."
    "Quizás sea hora de mirar qué está pasando aquí..."

translate Spanish strings:

    # game/chapters/1_roomexplore.rpy:3
    old "she"
    new "ella"

    # game/chapters/1_roomexplore.rpy:4
    old "her"
    new "ella"

    # game/chapters/1_roomexplore.rpy:5
    old "She"
    new "Ella"

    # game/chapters/1_roomexplore.rpy:6
    old "Her"
    new "Ella"

    # game/chapters/1_roomexplore.rpy:7
    old "girl"
    new "chica"

    # game/chapters/1_roomexplore.rpy:8
    old "ma'am"
    new "señora"

    # game/chapters/1_roomexplore.rpy:12
    old "he"
    new "él"

    # game/chapters/1_roomexplore.rpy:13
    old "his"
    new "él"

    # game/chapters/1_roomexplore.rpy:14
    old "He"
    new "Él"

    # game/chapters/1_roomexplore.rpy:15
    old "His"
    new "Él"

    # game/chapters/1_roomexplore.rpy:16
    old "boy"
    new "chico"

    # game/chapters/1_roomexplore.rpy:17
    old "mister"
    new "señor"

    # game/chapters/1_roomexplore.rpy:18
    old "him"
    new "él"

    # game/chapters/1_roomexplore.rpy:32
    old "female"
    new "mujer"

    # game/chapters/1_roomexplore.rpy:389
    old "1. Eavesdrop... just a little bit."
    new "1. Escuchar a escondidas... solo un poquito."

    # game/chapters/1_roomexplore.rpy:416
    old "2. Leave the door alone."
    new "2. Dejar la puerta en paz."

    # game/chapters/1_roomexplore.rpy:471
    old "Check on [pet_name]."
    new "Echar un vistazo a [pet_name]."

    # game/chapters/1_roomexplore.rpy:480
    old "Kiss [pet_name]."
    new "Besar a [pet_name]."

    # game/chapters/1_roomexplore.rpy:502
    old "Pet [pet_name]."
    new "Acariciar a [pet_name]."

    # game/chapters/1_roomexplore.rpy:525
    old "Give [pet_name] some greens."
    new "Dar hojas verdes a [pet_name]."

    # game/chapters/1_roomexplore.rpy:547
    old "Touch [pet_name]'s toebeans."
    new "Tocar las almohadillas de [pet_name]."

    # game/chapters/1_roomexplore.rpy:570
    old "Give [pet_name] a treat."
    new "Dar una golosina a [pet_name]."

    # game/chapters/1_roomexplore.rpy:593
    old "Give [pet_name] a snack."
    new "Dar un snack a [pet_name]."

    # game/chapters/1_roomexplore.rpy:669
    old "{i}The Wanderer{/i}"
    new "{i}El errante{/i}"

    # game/chapters/1_roomexplore.rpy:686
    old "The world was empty."
    new "El mundo estaba vacío."

    # game/chapters/1_roomexplore.rpy:687
    old "Life was gone."
    new "La vida había desaparecido."

    # game/chapters/1_roomexplore.rpy:688
    old "The soul whisperer wandered, now and forever."
    new "El susurrador de almas vagaba, ahora y para siempre."

    # game/chapters/1_roomexplore.rpy:689
    old "For an eternity, their footsteps echoed through empty streets and desolate ruins."
    new "Por una eternidad, sus pasos resonaban entre calles vacías y ruinas desoladas."

    # game/chapters/1_roomexplore.rpy:690
    old "Not even a soul remained to guide to their final resting place."
    new "Ya no quedaba ni un alma a la que guiar hasta su lugar de descanso final."

    # game/chapters/1_roomexplore.rpy:691
    old "And so, the soul whisperer was alone."
    new "Y así, el susurrador de almas estaba solo."

    # game/chapters/1_roomexplore.rpy:692
    old "Such was their fate. The fate of one bound to both life and death, without possessing either."
    new "Tal era su destino. El destino de alguien ligado tanto a la vida como a la muerte, sin poseer ninguna de las dos."

    # game/chapters/1_roomexplore.rpy:693
    old "They walked through a crumbling city, looking in on the remains of a civilization lost to time. Had it been a hundred years, or a thousand? Seconds merged into minutes, hours into days, months into years…"
    new "Recorría una ciudad en ruinas, contemplando los restos de una civilización perdida en el tiempo. ¿Habían pasado cien años o mil? Los segundos se fundían en minutos, las horas en días y los meses en años…"

    # game/chapters/1_roomexplore.rpy:694
    old "And for once, they wondered when their wandering would come to an end. Their soul was bound to the very world, fated to walk it until the very land itself ceased to exist."
    new "Y, por una vez, se preguntó cuándo llegaría a su fin su interminable vagar. Su alma estaba ligada a ese mismo mundo, condenada a recorrerlo hasta que la propia tierra dejara de existir."

    # game/chapters/1_roomexplore.rpy:695
    old "Something caught their eye."
    new "Algo llamó su atención."

    # game/chapters/1_roomexplore.rpy:696
    old "A soul unlike any other. As black as night, with a thousand silvery stars glittering and flowing like a river within its dark folds."
    new "Un alma como ninguna otra. Tan negra como la noche, con mil estrellas plateadas brillando y fluyendo como un río dentro de sus pliegues oscuros."

    # game/chapters/1_roomexplore.rpy:697
    old "The soul whisperer approached it, and in turn it sang them a song."
    new "El susurrador de almas se acercó a ella y, a cambio, el alma le cantó una canción."

    # game/chapters/1_roomexplore.rpy:698
    old "A voiceless song filled with wonder and awe. For a moment, the soul whisperer was lost in the rhythm of the universe, caught up in the symphony of the cosmos."
    new "Una canción sin voz, llena de maravilla y asombro. Por un instante, el susurrador de almas se perdió en el ritmo del universo, cautivado por la sinfonía del cosmos."

    # game/chapters/1_roomexplore.rpy:699
    old "But soon enough, the song came to an end, and the soul whisperer finally felt something they didn’t know was possible."
    new "Pero no tardó en terminar la canción y, por fin, el susurrador de almas sintió algo que ni siquiera sabía que era posible."

    # game/chapters/1_roomexplore.rpy:700
    old "Fear."
    new "Miedo."

    # game/chapters/1_roomexplore.rpy:701
    old "Fear of the loneliness that came with guiding the world’s final soul to their resting place."
    new "Miedo a la soledad que suponía guiar a la última alma del mundo hasta su lugar de descanso."

    # game/chapters/1_roomexplore.rpy:702
    old "It only took a moment for the soul to disappear, leaving behind a sea of glittering stars in the wanderer’s wake."
    new "El alma tardó apenas un instante en desaparecer, dejando a su paso un mar de estrellas centelleantes."

    # game/chapters/1_roomexplore.rpy:705
    old "But the soul whisperer remained, an eternal wanderer, forever seeking the lost souls of the world that were already long gone."
    new "Pero el susurrador de almas permanecía, un errante eterno, siempre buscando las almas perdidas del mundo que ya se habían ido hacía mucho tiempo."

    # game/chapters/1_roomexplore.rpy:755
    old "1. Try again."
    new "1. Inténtalo de nuevo."

    # game/chapters/1_roomexplore.rpy:758
    old "1. Try again... but angrier."
    new "1. Inténtalo de nuevo... pero con más enojo."

    # game/chapters/1_roomexplore.rpy:761
    old "1. Great, guess I've got a virus..."
    new "1. Genial, supongo que tengo un virus..."

    # game/chapters/1_roomexplore.rpy:764
    old "1. Stare the app down."
    new "1. Mirar fijamente la aplicación."

    # game/chapters/1_roomexplore.rpy:772
    old "1. Click on the app."
    new "1. Hacer clic en la aplicación."

    # game/chapters/1_roomexplore.rpy:777
    old "2. Click on the app."
    new "2. Hacer clic en la aplicación."

    # game/chapters/1_roomexplore.rpy:804
    old "1. I guess I'll just ignore it for now..."
    new "1. Creo que por ahora lo ignoraré..."

    # game/chapters/1_roomexplore.rpy:806
    old "2. I'll deal with it later..."
    new "2. Me ocuparé de eso más tarde..."

    # game/chapters/1_roomexplore.rpy:824
    old "1. Delete the app."
    new "1. Eliminar la aplicación."

    # game/chapters/1_roomexplore.rpy:826
    old "2. Ignore it."
    new "2. Ignorarla."

