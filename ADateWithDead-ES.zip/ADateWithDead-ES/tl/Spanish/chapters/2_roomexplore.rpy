# TODO: Translation updated at 2026-10-15 18:36

# game/chapters/2_roomexplore.rpy:216
translate Spanish bed_hub2_c63951e0:

    # "Your comfortable bed."
    "Tu cómoda cama."

# game/chapters/2_roomexplore.rpy:217
translate Spanish bed_hub2_b2f03db4:

    # "It's seen you through many a night's sleep."
    "Te ha acompañado en muchas noches de sueño."

# game/chapters/2_roomexplore.rpy:218
translate Spanish bed_hub2_26efad21:

    # "You're tired, but something is keeping you from being ready to sleep yet."
    "Estás cansad[letra], pero hay algo que todavía te impide irte a dormir."

# game/chapters/2_roomexplore.rpy:219
translate Spanish bed_hub2_d619a4b5:

    # "It definitely has nothing to do with the handsome man pretending to be the Grim Reaper who messaged you yesterday."
    "Definitivamente no tiene nada que ver con el hombre guapo que se hace pasar por la Parca y que te envió un mensaje ayer."

# game/chapters/2_roomexplore.rpy:220
translate Spanish bed_hub2_167bb5c0:

    # "Nothing whatsoever."
    "Absolutamente nada."

# game/chapters/2_roomexplore.rpy:221
translate Spanish bed_hub2_caf44b3d:

    # "Looking at your bed reminds you of the strange dream you had last night. You held a scythe in your hands, palms sweaty, as you took a soul from someone running down an empty street."
    "Al mirar tu cama, recuerdas el extraño sueño que tuviste anoche. Sostenías una guadaña con las manos sudorosas mientras le arrebatabas el alma a alguien que corría por una calle desierta."

# game/chapters/2_roomexplore.rpy:222
translate Spanish bed_hub2_d63a9d4a:

    # "It felt so real at the time. You wonder for a moment if that's what your new 'friend' does, before shaking your head."
    "En ese momento parecía tan real. Por un instante te preguntas si eso es lo que hace tu nuevo 'amigo', antes de negar con la cabeza."

# game/chapters/2_roomexplore.rpy:223
translate Spanish bed_hub2_d4eb1124:

    # "He's not {i}really{/i} the Grim Reaper. That would be absurd."
    "Él no es {i}realmente{/i} la Parca. Eso sería absurdo."

# game/chapters/2_roomexplore.rpy:232
translate Spanish door_hub2_48c0cf48:

    # "The door leads out to the hallway beyond."
    "La puerta da al pasillo de afuera."

# game/chapters/2_roomexplore.rpy:233
translate Spanish door_hub2_494cfb93:

    # "You're somewhat tired from your work today, so you don't feel like going anywhere at the moment."
    "Sientes un poco de cansancio por el trabajo de hoy, así que no tienes ganas de ir a ningún lado por el momento."

# game/chapters/2_roomexplore.rpy:234
translate Spanish door_hub2_91a45b5a:

    # "Just as you're about to turn away from the door, you hear a voice on the other side, speaking quietly."
    "Justo cuando estás a punto de alejarte de la puerta, oyes una voz al otro lado que habla en voz baja."

# game/chapters/2_roomexplore.rpy:235
translate Spanish door_hub2_c3dc859e:

    # "Is now a good time to eavesdrop a little more?"
    "¿Es ahora un buen momento para escuchar un poco más?"

# game/chapters/2_roomexplore.rpy:240
translate Spanish door_hub2_0da8280d:

    # "You hear a voice that's light and airy through the wooden door. They seem to be speaking over the phone with someone."
    "Se oye una voz de tono ligero y despreocupado a través de la puerta de madera. Parece que está hablando por teléfono con alguien."

# game/chapters/2_roomexplore.rpy:241
translate Spanish door_hub2_bed0acb0:

    # "'Sorry for calling back so late. I was actually on a... well, I suppose it was a date?'"
    "'Perdona por devolverte la llamada tan tarde. Estaba en una... bueno, ¿supongo que era una cita?'"

# game/chapters/2_roomexplore.rpy:242
translate Spanish door_hub2_3d1563ad:

    # "There is a short silence and the speaker's voice lowers in volume."
    "Hay un breve silencio y la voz de quien habla baja de volumen."

# game/chapters/2_roomexplore.rpy:243
translate Spanish door_hub2_11d60b28:

    # "'It was amazing. It's crazy the amount of chemistry we have, it was like meeting an old friend again. There's something so familiar about them.'"
    "'Fue increíble. Es una locura la química que tenemos; fue como reencontrarme con una vieja amistad. Hay algo en esa persona que me resulta muy familiar.'"

# game/chapters/2_roomexplore.rpy:244
translate Spanish door_hub2_60d95a25:

    # "'It's a nice feeling.'"
    "'Es una sensación agradable.'"

# game/chapters/2_roomexplore.rpy:245
translate Spanish door_hub2_c9c99660:

    # "You hear the person let out a loud sigh."
    "Oyes a la persona soltar un sonoro suspiro."

# game/chapters/2_roomexplore.rpy:246
translate Spanish door_hub2_23629445:

    # "'But then I went and spilled my coffee all over their shirt... I'm so embarrassed, I don't know if I can look them in the eyes again...'"
    "'Pero entonces terminé derramando mi café por toda su camisa... Me da tanta vergüenza que no sé si podré volver a mirarle a los ojos...'"

# game/chapters/2_roomexplore.rpy:247
translate Spanish door_hub2_7d96a260:

    # "There's a pause for a moment before the person speaks again."
    "Hay una pausa de unos instantes antes de que la persona vuelva a hablar."

# game/chapters/2_roomexplore.rpy:248
translate Spanish door_hub2_d29f41cc:

    # "'No, they were really nice about it. Just smiled at me and said it was fine...'"
    "'No, se portó muy bien. Solo me sonrió y me dijo que no pasaba nada...'"

# game/chapters/2_roomexplore.rpy:249
translate Spanish door_hub2_4d3b10c4:

    # "'My favorite part about the date? Well...'"
    "'¿Qué es lo que más me gustó de la cita? Bueno...'"

# game/chapters/2_roomexplore.rpy:250
translate Spanish door_hub2_e33d3526:

    # "'I thought I was rambling on too much, but they just watched me with a smile and encouraged me to keep talking. It felt so natural, like we've known each other forever.'"
    "'Pensé que estaba divagando demasiado, pero solo me miraba con una sonrisa y me animaba a seguir hablando. Me sentí muy a gusto, como si nos conociéramos de toda la vida.'"

# game/chapters/2_roomexplore.rpy:251
translate Spanish door_hub2_452110dc:

    # "You hear a door open as your neighbor goes to retreat into their apartment."
    "Oyes cómo se abre una puerta cuando tu vecino entra en su apartamento."

# game/chapters/2_roomexplore.rpy:252
translate Spanish door_hub2_dbb72ac8:

    # "'It was lovely... though I couldn't help but feel this strange, wistful melancholy from them every now and then.'"
    "'Fue muy bonito... aunque de vez en cuando no podía evitar percibir en esa persona una extraña melancolía teñida de nostalgia.'"

# game/chapters/2_roomexplore.rpy:253
translate Spanish door_hub2_c28bb0f4:

    # "'No, no, I'm not exactly sure why. They just had this distant look in their eyes every now and then. It's hard to explain.'"
    "'No, no, no sabría decirte exactamente por qué. Es solo que de vez en cuando tenía una mirada distante. Es difícil de explicar.'"

# game/chapters/2_roomexplore.rpy:254
translate Spanish door_hub2_1de226ed:

    # "'Anyway, I need to go cook dinner-I'll call you tomorrow, mom!'"
    "'Bueno, tengo que ir a preparar la cena. ¡Te llamaré mañana, mamá!'"

# game/chapters/2_roomexplore.rpy:255
translate Spanish door_hub2_ff9822b6:

    # "You hear a door shut, and then there's silence."
    "Oyes cómo se cierra una puerta y luego todo queda en silencio."

# game/chapters/2_roomexplore.rpy:268
translate Spanish door_hub2_0da8280d_1:

    # "You hear a voice that's light and airy through the wooden door. They seem to be speaking over the phone with someone."
    "Se oye una voz de tono ligero y despreocupado a través de la puerta de madera. Parece que está hablando por teléfono con alguien."

# game/chapters/2_roomexplore.rpy:269
translate Spanish door_hub2_bed0acb0_1:

    # "'Sorry for calling back so late. I was actually on a... well, I suppose it was a date?'"
    "'Perdona por devolverte la llamada tan tarde. Estaba en una... bueno, ¿supongo que era una cita?'"

# game/chapters/2_roomexplore.rpy:270
translate Spanish door_hub2_3d1563ad_1:

    # "There is a short silence and the speaker's voice lowers in volume."
    "Hay un breve silencio y la voz de quien habla baja de volumen."

# game/chapters/2_roomexplore.rpy:271
translate Spanish door_hub2_d663b16d:

    # "'It was amazing. It's crazy the amount of chemistry we have, it was like meeting an old friend again. There's something familiar about them.'"
    "'Fue sorprendente. Es increíble la química que tenemos, fue como reencontrarme con una vieja amistad. Hay algo que me resulta familiar.'"

# game/chapters/2_roomexplore.rpy:272
translate Spanish door_hub2_60d95a25_1:

    # "'It's a nice feeling.'"
    "'Es una sensación agradable.'"

# game/chapters/2_roomexplore.rpy:273
translate Spanish door_hub2_c9c99660_1:

    # "You hear the person let out a loud sigh."
    "Oyes a la persona soltar un sonoro suspiro."

# game/chapters/2_roomexplore.rpy:274
translate Spanish door_hub2_23629445_1:

    # "'But then I went and spilled my coffee all over their shirt... I'm so embarrassed, I don't know if I can look them in the eyes again...'"
    "'Pero entonces terminé derramando mi café por toda su camisa... Me da tanta vergüenza que no sé si podré volver a mirarle a los ojos...'"

# game/chapters/2_roomexplore.rpy:275
translate Spanish door_hub2_7d96a260_1:

    # "There's a pause for a moment before the person speaks again."
    "Hay una pausa de unos instantes antes de que la persona vuelva a hablar."

# game/chapters/2_roomexplore.rpy:276
translate Spanish door_hub2_d29f41cc_1:

    # "'No, they were really nice about it. Just smiled at me and said it was fine...'"
    "'No, se portó muy bien. Solo me sonrió y me dijo que no pasaba nada...'"

# game/chapters/2_roomexplore.rpy:277
translate Spanish door_hub2_4d3b10c4_1:

    # "'My favorite part about the date? Well...'"
    "'¿Qué es lo que más me gustó de la cita? Bueno...'"

# game/chapters/2_roomexplore.rpy:278
translate Spanish door_hub2_e33d3526_1:

    # "'I thought I was rambling on too much, but they just watched me with a smile and encouraged me to keep talking. It felt so natural, like we've known each other forever.'"
    "'Pensé que estaba divagando demasiado, pero solo me miraba con una sonrisa y me animaba a seguir hablando. Me sentí muy a gusto, como si nos conociéramos de toda la vida.'"

# game/chapters/2_roomexplore.rpy:279
translate Spanish door_hub2_452110dc_1:

    # "You hear a door open as your neighbor goes to retreat into their apartment."
    "Oyes cómo se abre una puerta cuando tu vecino entra en su apartamento."

# game/chapters/2_roomexplore.rpy:280
translate Spanish door_hub2_dbb72ac8_1:

    # "'It was lovely... though I couldn't help but feel this strange, wistful melancholy from them every now and then.'"
    "'Fue muy bonito... aunque de vez en cuando no podía evitar percibir en esa persona una extraña melancolía teñida de nostalgia.'"

# game/chapters/2_roomexplore.rpy:281
translate Spanish door_hub2_c28bb0f4_1:

    # "'No, no, I'm not exactly sure why. They just had this distant look in their eyes every now and then. It's hard to explain.'"
    "'No, no, no sabría decirte exactamente por qué. Es solo que de vez en cuando tenía una mirada distante. Es difícil de explicar.'"

# game/chapters/2_roomexplore.rpy:282
translate Spanish door_hub2_1de226ed_1:

    # "'Anyway, I need to go cook dinner-I'll call you tomorrow, mom!'"
    "'Bueno, tengo que ir a preparar la cena. ¡Te llamaré mañana, mamá!'"

# game/chapters/2_roomexplore.rpy:283
translate Spanish door_hub2_ff9822b6_1:

    # "You hear a door shut, and then there's silence."
    "Oyes cómo se cierra una puerta y luego todo queda en silencio."

# game/chapters/2_roomexplore.rpy:297
translate Spanish door_hub2_3d403dd1:

    # "The hallway beyond is silent."
    "El pasillo está en silencio."

# game/chapters/2_roomexplore.rpy:298
translate Spanish door_hub2_2bea66f4:

    # "You'll have to wait until tomorrow to hear more about the budding couple."
    "Tendrás que esperar hasta mañana para saber más sobre esta pareja que empieza a formarse."

# game/chapters/2_roomexplore.rpy:312
translate Spanish snake_hub2_b44105e0:

    # "[pet_name] is still hanging around on your bed, coiled up."
    "[pet_name] sigue en tu cama, enroscad[letra_pet]."

# game/chapters/2_roomexplore.rpy:313
translate Spanish snake_hub2_ad7fe56f:

    # "[pet_She] likes it there. You sit down next to [pet_name] for a moment, thinking of when you got [pet_her2]."
    "A [pet_she!t] le gusta estar ahí. Te sientas un momento junto a [pet_name] y recuerdas cuándo llegó a tu vida."

# game/chapters/2_roomexplore.rpy:314
translate Spanish snake_hub2_a4b8f404:

    # "That was..."
    "Eso fue..."

# game/chapters/2_roomexplore.rpy:319
translate Spanish snake_hub2_13ba0430:

    # "That's right. [pet_name] is only a recent addition to your family, but you loved them instantly."
    "Así es. [pet_name] es solo una incorporación reciente a tu familia, pero te enamoraste de [pet_she!t] al instante."

# game/chapters/2_roomexplore.rpy:322
translate Spanish snake_hub2_35219305:

    # "That's right. You only got [pet_name] a year ago. It somehow feels both like it was yesterday and forever ago."
    "Así es. Solo hace un año que tienes a [pet_name]. De alguna manera, parece que fue ayer y hace una eternidad."

# game/chapters/2_roomexplore.rpy:325
translate Spanish snake_hub2_06bbbfbc:

    # "That's right. You and [pet_name] have been together for five years already. You can't imagine life without [pet_her2]."
    "Así es. Tú y [pet_name] ya llevan cinco años juntos. No puedes imaginar tu vida sin [pet_she!t]."

# game/chapters/2_roomexplore.rpy:327
translate Spanish snake_hub2_93f6de20:

    # "You leave [pet_her2] be for now."
    "Dejas a [pet_name] en paz por ahora."

# game/chapters/2_roomexplore.rpy:334
translate Spanish snake_hub2_42f75e79:

    # "You run a finger down the length of [pet_name]'s body. [pet_She] has always liked that." id snake_hub2_42f75e79
    "Pasas un dedo por todo el cuerpo de [pet_name]. A [pet_she!t] siempre le ha gustado eso." id snake_hub2_42f75e79

# game/chapters/2_roomexplore.rpy:335
translate Spanish snake_hub2_e2449910:

    # "[pet_name]'s tongue flickers out towards you, content."
    "[pet_name] saca la lengua en tu dirección, satisfech[letra_pet]."

# game/chapters/2_roomexplore.rpy:347
translate Spanish bingus_hub2_b8ca18e0:

    # "[pet_name] is still sitting on your bed, watching you."
    "[pet_name] sigue en tu cama, observándote."

# game/chapters/2_roomexplore.rpy:348
translate Spanish bingus_hub2_ad7fe56f:

    # "[pet_She] likes it there. You sit down next to [pet_name] for a moment, thinking of when you got [pet_her2]."
    "A [pet_she!t] le gusta estar ahí. Te sientas un momento junto a [pet_name] y recuerdas cuándo llegó a tu vida."

# game/chapters/2_roomexplore.rpy:349
translate Spanish bingus_hub2_a4b8f404:

    # "That was..."
    "Eso fue..."

# game/chapters/2_roomexplore.rpy:354
translate Spanish bingus_hub2_13ba0430:

    # "That's right. [pet_name] is only a recent addition to your family, but you loved them instantly."
    "Así es. [pet_name] es solo una incorporación reciente a tu familia, pero te enamoraste de [pet_she!t] al instante."

# game/chapters/2_roomexplore.rpy:357
translate Spanish bingus_hub2_35219305:

    # "That's right. You only got [pet_name] a year ago. It somehow feels both like it was yesterday and forever ago."
    "Así es. Solo hace un año que tienes a [pet_name]. De alguna manera, parece que fue ayer y hace una eternidad."

# game/chapters/2_roomexplore.rpy:360
translate Spanish bingus_hub2_06bbbfbc:

    # "That's right. You and [pet_name] have been together for five years already. You can't imagine life without [pet_her2]."
    "Así es. Tú y [pet_name] ya llevan cinco años juntos. No puedes imaginar tu vida sin [pet_she!t]."

# game/chapters/2_roomexplore.rpy:362
translate Spanish bingus_hub2_93f6de20:

    # "You leave [pet_her2] be for now."
    "Dejas a [pet_name] en paz por ahora."

# game/chapters/2_roomexplore.rpy:367
translate Spanish bingus_hub2_fad266e9:

    # "You pick up [pet_name] in your arms."
    "Levantas a [pet_name] en tus brazos."

# game/chapters/2_roomexplore.rpy:368
translate Spanish bingus_hub2_812e4365:

    # "[pet_She] has always liked being bundled up in a blanket and cuddled."
    "A [pet_she!t] siempre le ha gustado que le arropen con una manta y le den muchos mimos."

# game/chapters/2_roomexplore.rpy:369
translate Spanish bingus_hub2_0fc228c5:

    # "[pet_name] purrs gently as you hold them close to you."
    "[pet_name] ronronea suavemente mientras l[letra_pet] abrazas contra tu pecho."

# game/chapters/2_roomexplore.rpy:381
translate Spanish bunny_hub2_aeb20d0f:

    # "[pet_name] is still sitting on your bed, big ears flopped over."
    "[pet_name] sigue sentad[letra_pet] en tu cama, con sus grandes orejas caídas."

# game/chapters/2_roomexplore.rpy:382
translate Spanish bunny_hub2_ad7fe56f:

    # "[pet_She] likes it there. You sit down next to [pet_name] for a moment, thinking of when you got [pet_her2]."
    "A [pet_she!t] le gusta estar ahí. Te sientas un momento junto a [pet_name] y recuerdas cuándo llegó a tu vida."

# game/chapters/2_roomexplore.rpy:383
translate Spanish bunny_hub2_a4b8f404:

    # "That was..."
    "Eso fue..."

# game/chapters/2_roomexplore.rpy:388
translate Spanish bunny_hub2_13ba0430:

    # "That's right. [pet_name] is only a recent addition to your family, but you loved them instantly."
    "Así es. [pet_name] es solo una incorporación reciente a tu familia, pero te enamoraste de [pet_she!t] al instante."

# game/chapters/2_roomexplore.rpy:391
translate Spanish bunny_hub2_35219305:

    # "That's right. You only got [pet_name] a year ago. It somehow feels both like it was yesterday and forever ago."
    "Así es. Solo hace un año que tienes a [pet_name]. De alguna manera, parece que fue ayer y hace una eternidad."

# game/chapters/2_roomexplore.rpy:394
translate Spanish bunny_hub2_e53b0a7a:

    # "That's right. You and [pet_name] have been together for three years already. You can't imagine life without [pet_her2]."
    "Así es. Tú y [pet_name] ya llevan tres años juntos. No puedes imaginar tu vida sin [pet_she!t]."

# game/chapters/2_roomexplore.rpy:395
translate Spanish bunny_hub2_93f6de20:

    # "You leave [pet_her2] be for now."
    "Dejas a [pet_name] en paz por ahora."

# game/chapters/2_roomexplore.rpy:400
translate Spanish bunny_hub2_49e199a0:

    # "You give [pet_name] a pat on their forehead and behind their ears."
    "Acaricias a [pet_name] en la frente y detrás de las orejas."

# game/chapters/2_roomexplore.rpy:401
translate Spanish bunny_hub2_69d86dc4:

    # "[pet_name]'s nose twitches in contentment as you smile down at [pet_her2]."
    "La nariz de [pet_name] se mueve con satisfacción mientras tú le sonríes a [pet_she!t]."

# game/chapters/2_roomexplore.rpy:412
translate Spanish cat_hub2_06607e52:

    # "[pet_name] is still sitting on your bed, curled up."
    "[pet_name] sigue en tu cama, acurrucad[letra_pet]."

# game/chapters/2_roomexplore.rpy:413
translate Spanish cat_hub2_ad7fe56f:

    # "[pet_She] likes it there. You sit down next to [pet_name] for a moment, thinking of when you got [pet_her2]."
    "A [pet_she!t] le gusta estar ahí. Te sientas un momento junto a [pet_name] y recuerdas cuándo llegó a tu vida."

# game/chapters/2_roomexplore.rpy:414
translate Spanish cat_hub2_a4b8f404:

    # "That was..."
    "Eso fue..."

# game/chapters/2_roomexplore.rpy:419
translate Spanish cat_hub2_13ba0430:

    # "That's right. [pet_name] is only a recent addition to your family, but you loved them instantly."
    "Así es. [pet_name] es solo una incorporación reciente a tu familia, pero te enamoraste de [pet_she!t] al instante."

# game/chapters/2_roomexplore.rpy:422
translate Spanish cat_hub2_35219305:

    # "That's right. You only got [pet_name] a year ago. It somehow feels both like it was yesterday and forever ago."
    "Así es. Solo hace un año que tienes a [pet_name]. De alguna manera, parece que fue ayer y hace una eternidad."

# game/chapters/2_roomexplore.rpy:425
translate Spanish cat_hub2_06bbbfbc:

    # "That's right. You and [pet_name] have been together for five years already. You can't imagine life without [pet_her2]."
    "Así es. Tú y [pet_name] ya llevan cinco años juntos. No puedes imaginar tu vida sin [pet_she!t]."

# game/chapters/2_roomexplore.rpy:426
translate Spanish cat_hub2_93f6de20:

    # "You leave [pet_her2] be for now."
    "Dejas a [pet_name] en paz por ahora."

# game/chapters/2_roomexplore.rpy:431
translate Spanish cat_hub2_495b2d64:

    # "You pull out a bag of [pet_name]'s favorite treats - that's enough to wake them up."
    "Sacas una bolsa con las golosinas favoritas de [pet_name]; eso basta para despertarl[letra_pet]."

# game/chapters/2_roomexplore.rpy:432
translate Spanish cat_hub2_46a3cb99:

    # "You feed [pet_name] a couple of them, and [pet_she] gobbles them down thankfully."
    "Le das un par a [pet_name] y [pet_she!t] se los devora agradecid[letra_pet]."

# game/chapters/2_roomexplore.rpy:444
translate Spanish dog_hub2_9359d170:

    # "[pet_name] is still sitting on your bed, tail wagging."
    "[pet_name] sigue en tu cama, moviendo la cola."

# game/chapters/2_roomexplore.rpy:445
translate Spanish dog_hub2_ad7fe56f:

    # "[pet_She] likes it there. You sit down next to [pet_name] for a moment, thinking of when you got [pet_her2]."
    "A [pet_she!t] le gusta estar ahí. Te sientas un momento junto a [pet_name] y recuerdas cuándo llegó a tu vida."

# game/chapters/2_roomexplore.rpy:446
translate Spanish dog_hub2_a4b8f404:

    # "That was..."
    "Eso fue..."

# game/chapters/2_roomexplore.rpy:451
translate Spanish dog_hub2_13ba0430:

    # "That's right. [pet_name] is only a recent addition to your family, but you loved them instantly."
    "Así es. [pet_name] es solo una incorporación reciente a tu familia, pero te enamoraste de [pet_she!t] al instante."

# game/chapters/2_roomexplore.rpy:454
translate Spanish dog_hub2_35219305:

    # "That's right. You only got [pet_name] a year ago. It somehow feels both like it was yesterday and forever ago."
    "Así es. Solo hace un año que tienes a [pet_name]. De alguna manera, parece que fue ayer y hace una eternidad."

# game/chapters/2_roomexplore.rpy:457
translate Spanish dog_hub2_06bbbfbc:

    # "That's right. You and [pet_name] have been together for five years already. You can't imagine life without [pet_her2]."
    "Así es. Tú y [pet_name] ya llevan cinco años juntos. No puedes imaginar tu vida sin [pet_she!t]."

# game/chapters/2_roomexplore.rpy:458
translate Spanish dog_hub2_93f6de20:

    # "You leave [pet_her2] be for now."
    "Dejas a [pet_name] en paz por ahora."

# game/chapters/2_roomexplore.rpy:463
translate Spanish dog_hub2_77fb8bf4:

    # "You give [pet_name] a big belly rub."
    "Le acaricias la barriga a [pet_name] con ganas."

# game/chapters/2_roomexplore.rpy:464
translate Spanish dog_hub2_259634b6:

    # "[pet_She] rolls around on the bed, happy for the attention."
    "[pet_She!t] se revuelca en la cama, feliz por la atención que recibe."

# game/chapters/2_roomexplore.rpy:476
translate Spanish hamster_hub2_9359d170:

    # "[pet_name] is still sitting on your bed, tail wagging."
    "[pet_name] sigue en tu cama, moviendo la cola."

# game/chapters/2_roomexplore.rpy:477
translate Spanish hamster_hub2_ad7fe56f:

    # "[pet_She] likes it there. You sit down next to [pet_name] for a moment, thinking of when you got [pet_her2]."
    "A [pet_she!t] le gusta estar ahí. Te sientas un momento junto a [pet_name] y recuerdas cuándo llegó a tu vida."

# game/chapters/2_roomexplore.rpy:478
translate Spanish hamster_hub2_a4b8f404:

    # "That was..."
    "Eso fue..."

# game/chapters/2_roomexplore.rpy:483
translate Spanish hamster_hub2_13ba0430:

    # "That's right. [pet_name] is only a recent addition to your family, but you loved them instantly."
    "Así es. [pet_name] es solo una incorporación reciente a tu familia, pero te enamoraste de [pet_she!t] al instante."

# game/chapters/2_roomexplore.rpy:486
translate Spanish hamster_hub2_2a4bdd08:

    # "That's right. You only got [pet_name] six months ago. It somehow feels both like it was yesterday and forever ago."
    "Así es. Solo hace seis meses que tienes a [pet_name]. De alguna manera, parece que fue ayer y hace una eternidad."

# game/chapters/2_roomexplore.rpy:489
translate Spanish hamster_hub2_2650df57:

    # "That's right. You and [pet_name] have been together for a year already. You can't imagine life without [pet_her2]."
    "Así es. Tú y [pet_name] ya llevan un año juntos. No puedes imaginar tu vida sin [pet_she!t]."

# game/chapters/2_roomexplore.rpy:490
translate Spanish hamster_hub2_93f6de20:

    # "You leave [pet_her2] be for now."
    "Dejas a [pet_name] en paz por ahora."

# game/chapters/2_roomexplore.rpy:495
translate Spanish hamster_hub2_9c8c300a:

    # "[pet_name] crawls into your hand eagerly."
    "[pet_name] se sube a tu mano con entusiasmo."

# game/chapters/2_roomexplore.rpy:496
translate Spanish hamster_hub2_8e0e7203:

    # "You smile down at [pet_her2] as you use your fingertips to gentle pet [pet_name]'s head and back."
    "Le sonríes a [pet_name] mientras le acaricias suavemente la cabeza y el lomo con las yemas de los dedos."

# game/chapters/2_roomexplore.rpy:515
translate Spanish plant_hub2_c1229c6a:

    # "You give your little sprout a big drink of water."
    "Le das a tu pequeño retoño un buen trago de agua."

# game/chapters/2_roomexplore.rpy:516
translate Spanish plant_hub2_7d49446c:

    # "It seems to perk up instantly."
    "Parece que se anima al instante."

# game/chapters/2_roomexplore.rpy:518
translate Spanish plant_hub2_518e64fd:

    # "Your little sprout has grown some leaves!"
    "¡A tu pequeño retoño le han salido hojas!"

# game/chapters/2_roomexplore.rpy:519
translate Spanish plant_hub2_8036dce1:

    # "You can't help but feel proud as you give it a big drink of water."
    "No puedes evitar sentir orgullo mientras le das un buen trago de agua."

# game/chapters/2_roomexplore.rpy:534
translate Spanish plant_hub2_b2f22d8f:

    # "You decide that your little plant needs a liiiiittle more water."
    "Decides que tu plantita necesita un poquititooooo más de agua."

# game/chapters/2_roomexplore.rpy:535
translate Spanish plant_hub2_aa824d8c:

    # "You also decide to ignore the way it pools up on top of the soil."
    "También decides ignorar cómo se acumula en la superficie de la tierra."

# game/chapters/2_roomexplore.rpy:545
translate Spanish plant_hub2_50a3a90d:

    # "You have chose violence this day."
    "Hoy has elegido el camino de la violencia."

# game/chapters/2_roomexplore.rpy:548
translate Spanish plant_hub2_b66ff125:

    # "Water is overflowing everywhere, and yet you keep pouring."
    "El agua se desborda por todas partes y, aun así, sigues echando más."

# game/chapters/2_roomexplore.rpy:549
translate Spanish plant_hub2_e196afb8:

    # "Your pet seems to be worrying about you, but you still keep pouring."
    "Tu mascota parece estar preocupad[letra_pet] por ti, pero tú sigues echando agua."

# game/chapters/2_roomexplore.rpy:550
translate Spanish plant_hub2_6f028425:

    # "It's not enough! It needs more water!"
    "¡No es suficiente! ¡Necesita más agua!"

# game/chapters/2_roomexplore.rpy:551
translate Spanish plant_hub2_70bbc284:

    # "Eventually you snap out of it. Now you have a big mess to clean up."
    "Finalmente vuelves en ti. Ahora tienes un gran desastre que limpiar."

translate Spanish strings:

    # game/chapters/2_roomexplore.rpy:238
    old "1. Eavesdrop on them."
    new "1. Escuchar su conversación a escondidas."

    # game/chapters/2_roomexplore.rpy:317
    old "1. Just a few months ago."
    new "1. Hace solo unos meses."

    # game/chapters/2_roomexplore.rpy:320
    old "2. A year ago."
    new "2. Hace un año."

    # game/chapters/2_roomexplore.rpy:323
    old "3. Five years ago already."
    new "3. Ya hace cinco años."

    # game/chapters/2_roomexplore.rpy:365
    old "Cuddle [pet_name]."
    new "Mimar a [pet_name]."

    # game/chapters/2_roomexplore.rpy:392
    old "3. Three years ago already."
    new "3. Hace ya tres años."

    # game/chapters/2_roomexplore.rpy:461
    old "Give [pet_name] a belly rub."
    new "Acariciarle la barriga a [pet_name]."

    # game/chapters/2_roomexplore.rpy:481
    old "1. A month ago."
    new "1. Hace un mes."

    # game/chapters/2_roomexplore.rpy:484
    old "2. Six months ago."
    new "2. Hace seis meses."

    # game/chapters/2_roomexplore.rpy:487
    old "3. One year ago already."
    new "3. Hace ya un año."

    # game/chapters/2_roomexplore.rpy:493
    old "Give [pet_name] a pat."
    new "Acariciar a [pet_name]."

    # game/chapters/2_roomexplore.rpy:574
    old "{i}The Raven and the Koi{/i}"
    new "{i}El Cuervo y el Koi{/i}"

    # game/chapters/2_roomexplore.rpy:590
    old "In the  waters of a secluded pond, a solitary koi fish swam gracefully through the reflections of overhanging willows."
    new "En las aguas de un estanque apartado, un solitario pez koi nadaba con elegancia entre los reflejos de los sauces cuyas ramas se inclinaban sobre el agua."

    # game/chapters/2_roomexplore.rpy:591
    old "Above the pond, perched on a moss-covered stone, a raven observed the koi with an intensity that seemed unnatural, even for a creature as clever as a raven."
    new "Sobre el estanque, posado en una piedra cubierta de musgo, un cuervo observaba al koi con una intensidad que parecía antinatural, incluso para una criatura tan astuta como él."

    # game/chapters/2_roomexplore.rpy:592
    old "'Who are you, winged messenger, and what brings you to my watery abode?' the koi inquired."
    new "'¿Quién eres tú, mensajero alado, y qué te trae a mi morada acuática?' preguntó el koi."

    # game/chapters/2_roomexplore.rpy:593
    old "'I am the harbinger of endings, the keeper of shadows,' replied the raven, its tone carrying the weight of countless whispered farewells. 'But today, I come seeking solace in the depths of your realm, for I am tired of being the herald of inevitable partings.'"
    new "'Soy el presagio del final, el guardián de las sombras', respondió el cuervo, con un tono que cargaba el peso de incontables despedidas susurradas. 'Pero hoy vengo en busca de consuelo en las profundidades de tu reino, pues estoy cansado de ser el heraldo de las despedidas inevitables.'"

    # game/chapters/2_roomexplore.rpy:594
    old "At these words, the koi swam nearer to the shadowed outcrop of stone. 'It is such a heavy burden you must bear.'"
    new "Al oír estas palabras, el koi nadó más cerca del saliente rocoso cubierto de sombras. 'Es una carga muy pesada la que debes soportar.'"

    # game/chapters/2_roomexplore.rpy:595
    old "'Tell me, wise koi, what is the meaning of my existence? Why am I cursed to fly souls through the afterlife with my ebony wings, while others may be free - like you?'"
    new "'Dime, sabio koi, ¿cuál es el sentido de mi existencia? ¿Por qué estoy condenado a llevar almas a través del más allá con mis alas de ébano, mientras otros pueden ser libres, como tú?'"

    # game/chapters/2_roomexplore.rpy:596
    old "'Every creature has its purpose, winged one,' the koi answered. 'I am beholden to this pond. You may fly.'"
    new "'Toda criatura tiene su propósito, ser alado', respondió el koi. 'Yo estoy ligado a este estanque. Tú, en cambio, puedes volar.'"

    # game/chapters/2_roomexplore.rpy:597
    old "'Do you not wish for wings of your own?' the creature questioned."
    new "'¿Acaso no deseas tener alas propias?' preguntó la criatura."

    # game/chapters/2_roomexplore.rpy:598
    old "'No, because for me, to swim is to know love. And for you, to fly is to be free. As long as you have that freedom, you can always dictate your own path to the future.'"
    new "'No, porque para mí, nadar es conocer el amor. Y para ti, volar es ser libre. Mientras conserves esa libertad, siempre podrás decidir tu propio rumbo hacia el futuro.'"

    # game/chapters/2_roomexplore.rpy:599
    old "For the longest time, the raven remained perfectly still. Quiet and contemplative. When it finally spoke, the somber and mournful tone was gone, and in its place, wonder and awe."
    new "Durante muchísimo tiempo, el cuervo permaneció completamente inmóvil, en silencio y pensativo. Cuando por fin habló, el tono sombrío y afligido había desaparecido, y en su lugar había asombro y admiración."

    # game/chapters/2_roomexplore.rpy:600
    old "'Thank you, wise koi.'"
    new "'Gracias, sabio koi.'"

    # game/chapters/2_roomexplore.rpy:601
    old "'What have I done to deserve your gratitude, feathered creature?'"
    new "'¿Qué he hecho para merecer tu gratitud, criatura emplumada?'"

    # game/chapters/2_roomexplore.rpy:602
    old "'You have reminded me of why I love to fly.'"
    new "'Me has recordado por qué amo volar.'"

