# TODO: Translation updated at 2026-10-15 18:36

# game/chapters/end_1.rpy:10
translate Spanish wedding_start_d41d8cd9:

    # nvl clear
    nvl clear

# game/chapters/end_1.rpy:21
translate Spanish wedding_start_ce6326d9:

    # center_text "You woke up early this morning feeling particularly well rested."
    center_text "Te has despertado temprano esta mañana sintiéndote especialmente descansad[letra]."

# game/chapters/end_1.rpy:22
translate Spanish wedding_start_f9385cf7:

    # center_text "No one came for your soul in the night, which means..."
    center_text "Nadie vino por tu alma durante la noche, lo que significa que..."

# game/chapters/end_1.rpy:23
translate Spanish wedding_start_b25b7a28:

    # center_text "Today is the final day of your bet!"
    center_text "¡Hoy es el último día de tu apuesta!"

# game/chapters/end_1.rpy:24
translate Spanish wedding_start_3331b1c7:

    # center_text "You almost can't contain your excitement. After all, you seem to have this in the bag."
    center_text "Casi no puedes contener la emoción. Después de todo, parece que ya tienes la victoria asegurada."

# game/chapters/end_1.rpy:25
translate Spanish wedding_start_9aea9fc5:

    # center_text "You decide not to go out anywhere today - safer to stay at home and ride out your win."
    center_text "Decides no salir a ningún lado hoy; es más seguro quedarte en casa y disfrutar de tu victoria."

# game/chapters/end_1.rpy:26
translate Spanish wedding_start_d6f1731b:

    # center_text "It's still early in the morning as you wait for the eventual message from your own personal Grim Reaper."
    center_text "Todavía es temprano mientras esperas el mensaje que tarde o temprano llegará de tu Parca personal."

# game/chapters/end_1.rpy:66
translate Spanish day7_start_weddingend_ec748259:

    # player "Morning, babygirl."
    player "Buenos días, babygirl."

# game/chapters/end_1.rpy:68
translate Spanish day7_start_weddingend_bdd80872:

    # player "G'morning, my very favorite Grim Reaper!"
    player "¡Buenos días, mi Parca favorita!"

# game/chapters/end_1.rpy:71
translate Spanish day7_start_weddingend_b3afdcb0:

    # player "It's the big day~"
    player "Es el gran día~"

# game/chapters/end_1.rpy:72
translate Spanish day7_start_weddingend_93df56c1:

    # GR "indeed it is."
    GR "en efecto lo es."

# game/chapters/end_1.rpy:73
translate Spanish day7_start_weddingend_26e2850f:

    # GR "a week has gone by rather... quickly."
    GR "una semana ha pasado bastante... rápido."

# game/chapters/end_1.rpy:77
translate Spanish day7_start_weddingend_61c52300:

    # player "Time sure flies when you're having fun, huh?"
    player "El tiempo vuela cuando te estás divirtiendo, ¿eh?"

# game/chapters/end_1.rpy:78
translate Spanish day7_start_weddingend_61d12a0f:

    # GR "so you're just assuming i've been having fun?"
    GR "¿así que asumes que me he estado divirtiendo?"

# game/chapters/end_1.rpy:82
translate Spanish day7_start_weddingend_3e4e9122:

    # player "Well, I know you can't lie, so why don't you tell me?"
    player "Bueno, sé que no puedes mentir, así que ¿por qué no me lo dices tú?"

# game/chapters/end_1.rpy:86
translate Spanish day7_start_weddingend_34e80d39:

    # player "Do you have fun talking with me?"
    player "¿Te diviertes hablando conmigo?"

# game/chapters/end_1.rpy:90
translate Spanish day7_start_weddingend_b211cb41:

    # player "Do you know what daaaay it is?"
    player "¿Sabes qué dííía es hoy?"

# game/chapters/end_1.rpy:93
translate Spanish day7_start_weddingend_2ab337a6:

    # player "I bet you doooo!"
    player "¡Apuesto a que sííí!"

# game/chapters/end_1.rpy:96
translate Spanish day7_start_weddingend_ae226a2d:

    # player "It's 'reaping day' ;D"
    player "Es el 'día de la siega' ;D"

# game/chapters/end_1.rpy:97
translate Spanish day7_start_weddingend_64f9929e:

    # GR "wow."
    GR "wow."

# game/chapters/end_1.rpy:98
translate Spanish day7_start_weddingend_c54cc782:

    # GR "i am glad to see you're taking the day of your death seriously."
    GR "me alegra ver que te tomas el día de tu muerte con seriedad."

# game/chapters/end_1.rpy:102
translate Spanish day7_start_weddingend_d4f63512:

    # player "Well, I'm a very serious person, Casper."
    player "Bueno, soy una persona muy seria, Casper."

# game/chapters/end_1.rpy:104
translate Spanish day7_start_weddingend_2295136f:

    # GR "i was being sarcastic."
    GR "estaba siendo sarcástico."

# game/chapters/end_1.rpy:108
translate Spanish day7_start_weddingend_cc25db88:

    # player "I wasn't <3"
    player "Yo no <3"

# game/chapters/end_1.rpy:111
translate Spanish day7_start_weddingend_b16d0dbf:

    # player "Anyway, I was wondering something."
    player "De todos modos, me preguntaba algo."

# game/chapters/end_1.rpy:112
translate Spanish day7_start_weddingend_11b5f990:

    # GR "whenever you wonder something, it's very dangerous."
    GR "cada vez que te preguntas algo, es muy peligroso."

# game/chapters/end_1.rpy:113
translate Spanish day7_start_weddingend_1fdc7d70:

    # GR "i never know what you're going to ask."
    GR "nunca sé qué vas a preguntar."

# game/chapters/end_1.rpy:114
translate Spanish day7_start_weddingend_75e1f663:

    # GR "but my curiosity is piqued."
    GR "pero has despertado mi curiosidad."

# game/chapters/end_1.rpy:115
translate Spanish day7_start_weddingend_22b9acdd:

    # GR "what is it?"
    GR "¿qué es?"

# game/chapters/end_1.rpy:119
translate Spanish day7_start_weddingend_e4ea439d:

    # player "Do you have fun when we talk?"
    player "¿Te diviertes cuando hablamos?"

# game/chapters/end_1.rpy:121
translate Spanish day7_start_weddingend_42db57a9:

    # GR "do you {i}think{/i} i have fun talking to you?"
    GR "¿tú {i}crees{/i} que me divierto hablando contigo?"

# game/chapters/end_1.rpy:124
translate Spanish day7_start_weddingend_858c4a27:

    # player "Casperrrrrr!"
    player "¡Casperrrrrr!"

# game/chapters/end_1.rpy:127
translate Spanish day7_start_weddingend_9b2d394a:

    # player "Answer the question, there's no need to be scared!"
    player "¡Responde la pregunta, no hay necesidad de tener miedo!"

# game/chapters/end_1.rpy:128
translate Spanish day7_start_weddingend_a5d2a736:

    # GR "i am not scared."
    GR "no tengo miedo."

# game/chapters/end_1.rpy:129
translate Spanish day7_start_weddingend_fa72e129:

    # GR "a reaper is scared of nothing."
    GR "una parca no le teme a nada."

# game/chapters/end_1.rpy:130
translate Spanish day7_start_weddingend_f88a23e6:

    # GR "especially not admitting to something so simple."
    GR "y mucho menos admitir algo tan sencillo."

# game/chapters/end_1.rpy:133
translate Spanish day7_start_weddingend_04884ec5:

    # player "Don't answer my question with another question!"
    player "¡No respondas mi pregunta con otra pregunta!"

# game/chapters/end_1.rpy:134
translate Spanish day7_start_weddingend_3a219a0a:

    # GR "why not?"
    GR "¿por qué no?"

# game/chapters/end_1.rpy:138
translate Spanish day7_start_weddingend_dde4f72d:

    # player "You're doing it again?"
    player "¿Lo estás haciendo otra vez?"

# game/chapters/end_1.rpy:140
translate Spanish day7_start_weddingend_828473a1:

    # GR "am i?"
    GR "¿lo estoy?"

# game/chapters/end_1.rpy:144
translate Spanish day7_start_weddingend_03775ec8:

    # player "..."
    player "..."

# game/chapters/end_1.rpy:146
translate Spanish day7_start_weddingend_bcc3db59:

    # player "You're lucky I like you, asshole."
    player "Tienes suerte de que me gustes, imbécil."

# game/chapters/end_1.rpy:150
translate Spanish day7_start_weddingend_beb649c6:

    # GR "...if i did not have fun talking to you, i would've stopped days ago."
    GR "...si no me divirtiera hablando contigo, habría dejado de hacerlo hace días."

# game/chapters/end_1.rpy:151
translate Spanish day7_start_weddingend_6e91401f:

    # GR "does this satisfy your needs?"
    GR "¿esto satisface tus necesidades?"

# game/chapters/end_1.rpy:155
translate Spanish day7_start_weddingend_1dff582d:

    # player "It does indeed."
    player "Sí, por supuesto."

# game/chapters/end_1.rpy:158
translate Spanish day7_start_weddingend_b3a55133:

    # player "I already knew you'd say yes, I just wanted you to say it."
    player "Ya sabía que dirías que sí, solo quería que lo dijeras."

# game/chapters/end_1.rpy:159
translate Spanish day7_start_weddingend_a59fd587:

    # GR "ah, so it was a trick."
    GR "ah, así que fue un truco."

# game/chapters/end_1.rpy:163
translate Spanish day7_start_weddingend_64ef1090:

    # player "I wouldn't say it was a {i}trick{/i} exactly."
    player "No lo llamaría exactamente un {i}truco{/i}."

# game/chapters/end_1.rpy:167
translate Spanish day7_start_weddingend_b8a76b6b:

    # player "I just like it when you say nice things to me."
    player "Solo me gusta cuando me dices cosas lindas."

# game/chapters/end_1.rpy:170
translate Spanish day7_start_weddingend_1c664587:

    # player "Though I like when you're mean, as well."
    player "Aunque también me gusta cuando eres malo conmigo."

# game/chapters/end_1.rpy:174
translate Spanish day7_start_weddingend_7447c28d:

    # player "It's very amusing."
    player "Es muy divertido."

# game/chapters/end_1.rpy:176
translate Spanish day7_start_weddingend_f3b1f875:

    # GR "......"
    GR "......"

# game/chapters/end_1.rpy:177
translate Spanish day7_start_weddingend_7db81e9b:

    # GR "why am i not surprised..."
    GR "¿por qué no me sorprende...?"

# game/chapters/end_1.rpy:181
translate Spanish day7_start_weddingend_06a486bc:

    # player "Because you know me pretty well at this point, I'd say."
    player "Porque ya me conoces bastante bien a estas alturas, diría yo."

# game/chapters/end_1.rpy:182
translate Spanish day7_start_weddingend_44b72da1:

    # GR "too well, perhaps."
    GR "demasiado bien, quizá."

# game/chapters/end_1.rpy:185
translate Spanish day7_start_weddingend_67a82cdc:

    # player "I knoooow it pleases you."
    player "Sé queeee eso te gusta."

# game/chapters/end_1.rpy:186
translate Spanish day7_start_weddingend_7550dff9:

    # GR "what does? to know you so well?"
    GR "¿el qué? ¿conocerte tan bien?"

# game/chapters/end_1.rpy:189
translate Spanish day7_start_weddingend_b195d3a6:

    # player "Uh huh!"
    player "¡Ajá!"

# game/chapters/end_1.rpy:192
translate Spanish day7_start_weddingend_0cbb0a91:

    # player "To get to be witness to my charm firsthand."
    player "Para que puedas ser testigo de mi encanto en persona."

# game/chapters/end_1.rpy:195
translate Spanish day7_start_weddingend_e06ef46a:

    # player "You loooove it."
    player "Te encaaaaanta."

# game/chapters/end_1.rpy:197
translate Spanish day7_start_weddingend_3bb983be:

    # GR "hah... how arrogant. you shouldn't assume things."
    GR "ja... qué arrogante. no deberías asumir cosas."

# game/chapters/end_1.rpy:200
translate Spanish day7_start_weddingend_5c22352f:

    # player "See, you can't even say I'm wrong."
    player "Ves, ni siquiera puedes decir que me equivoco."

# game/chapters/end_1.rpy:203
translate Spanish day7_start_weddingend_1d14680d:

    # player "TBH with the way you blush, you can't hide your feelings from me <3"
    player "Honestamente, con lo mucho que te sonrojas, no puedes ocultarme tus sentimientos <3"

# game/chapters/end_1.rpy:205
translate Spanish day7_start_weddingend_f72253a2:

    # GR "i have truly fallen so far..."
    GR "he caído tan bajo..."

# game/chapters/end_1.rpy:206
translate Spanish day7_start_weddingend_31953b19:

    # GR "a grim reaper should not be so... transparent with their feelings..."
    GR "una parca no debería ser tan... transparente con sus sentimientos..."

# game/chapters/end_1.rpy:209
translate Spanish day7_start_weddingend_0bafe666:

    # player "Poor transparent Casper~"
    player "Pobre Casper transparente~"

# game/chapters/end_1.rpy:212
translate Spanish day7_start_weddingend_1fac2798:

    # player "I could think of a few more you could satisfy."
    player "Podría pensar en unas cuantas más que podrías satisfacer."

# game/chapters/end_1.rpy:213
translate Spanish day7_start_weddingend_b957cb82:

    # GR "you...!"
    GR "¡tú...!"

# game/chapters/end_1.rpy:214
translate Spanish day7_start_weddingend_c0292167:

    # GR "you are... very... indecent..."
    GR "eres... muy... indecente..."

# game/chapters/end_1.rpy:215
translate Spanish day7_start_weddingend_e8204b0f:

    # GR "are mortals always so forward?"
    GR "¿los mortales siempre son tan directos?"

# game/chapters/end_1.rpy:218
translate Spanish day7_start_weddingend_c2d74f20:

    # player "What do you mean?"
    player "¿A qué te refieres?"

# game/chapters/end_1.rpy:219
translate Spanish day7_start_weddingend_dfb2823d:

    # GR "you said... you could think of a few more needs i could satisfy..."
    GR "dijiste... que podías pensar en unas cuantas más necesidades que podría satisfacer..."

# game/chapters/end_1.rpy:222
translate Spanish day7_start_weddingend_faa0641e:

    # player "Huh?"
    player "¿Eh?"

# game/chapters/end_1.rpy:226
translate Spanish day7_start_weddingend_16d3c514:

    # player "I was thinking you could cook me a nice meal."
    player "Pensaba que podrías cocinarme una buena comida."

# game/chapters/end_1.rpy:228
translate Spanish day7_start_weddingend_7772a27d:

    # GR "..."
    GR "..."

# game/chapters/end_1.rpy:232
translate Spanish day7_start_weddingend_e20c8008:

    # player "Is your mind in the gutter, little reaper?"
    player "¿Tienes la mente sucia, parquita?"

# game/chapters/end_1.rpy:234
translate Spanish day7_start_weddingend_2301606f:

    # GR "that is {i}not{/i} what you meant!"
    GR "¡eso {i}no{/i} es lo que quisiste decir!"

# game/chapters/end_1.rpy:238
translate Spanish day7_start_weddingend_5c5ac7ee:

    # player "It definitely is."
    player "Definitivamente sí lo era."

# game/chapters/end_1.rpy:241
translate Spanish day7_start_weddingend_8bcbd93f:

    # player "You're out here trying to change our age rating..."
    player "Estás intentando cambiar nuestra clasificación de edad..."

# game/chapters/end_1.rpy:242
translate Spanish day7_start_weddingend_7772a27d_1:

    # GR "..."
    GR "..."

# game/chapters/end_1.rpy:243
translate Spanish day7_start_weddingend_14dabc8f:

    # GR "you... imply such things, of course my mind is going to drift in such directions..."
    GR "tú... insinúas esas cosas, por supuesto que mi mente se irá en esa dirección..."

# game/chapters/end_1.rpy:247
translate Spanish day7_start_weddingend_85a998f6:

    # player "No, I'm totally pure. Like an angel."
    player "No, soy totalmente pur[letra]. Como un ángel."

# game/chapters/end_1.rpy:248
translate Spanish day7_start_weddingend_c2001448:

    # GR "your mind is far from pure."
    GR "tu mente está lejos de ser pura."

# game/chapters/end_1.rpy:249
translate Spanish day7_start_weddingend_cee94ba9:

    # GR "it's crude and troublesome."
    GR "es grosera y problemática."

# game/chapters/end_1.rpy:250
translate Spanish day7_start_weddingend_800ccb84:

    # GR "also, you will find that angels are not nearly as pure as they want you to believe."
    GR "además, descubrirás que los ángeles no son tan puros como quieren hacerte creer."

# game/chapters/end_1.rpy:251
translate Spanish day7_start_weddingend_cb8fb06f:

    # GR "they are tricksters."
    GR "son embaucadores."

# game/chapters/end_1.rpy:252
translate Spanish day7_start_weddingend_fd43315b:

    # GR "much like you..."
    GR "muy parecidos a ti..."

# game/chapters/end_1.rpy:256
translate Spanish day7_start_weddingend_dc4c5752:

    # player "And you wouldn't have it any other way."
    player "Y no lo querrías de otra forma."

# game/chapters/end_1.rpy:257
translate Spanish day7_start_weddingend_75f33ae3:

    # GR "well i suppose it does make you... {i}you{/i}."
    GR "bueno, supongo que eso te hace... {i}tú{/i}."

# game/chapters/end_1.rpy:260
translate Spanish day7_start_weddingend_a0f447e0:

    # player "I'm taking that as a '[playerfirstname], you're perfect'."
    player "Tomaré eso como un '[playerfirstname], eres la perfección'."

# game/chapters/end_1.rpy:261
translate Spanish day7_start_weddingend_7772a27d_2:

    # GR "..."
    GR "..."

# game/chapters/end_1.rpy:264
translate Spanish day7_start_weddingend_838a0b99:

    # player "<3"
    player "<3"

# game/chapters/end_1.rpy:267
translate Spanish day7_start_weddingend_935c911b:

    # player "You're such a naughty boy."
    player "Eres un chico muy travieso."

# game/chapters/end_1.rpy:268
translate Spanish day7_start_weddingend_a7e15d15:

    # GR "you...."
    GR "tú..."

# game/chapters/end_1.rpy:269
translate Spanish day7_start_weddingend_8376898e:

    # GR "you're a bad [girl] to match, then..."
    GR "entonces eres [arti_2] [girl!t] mal[letra] a juego..."

# game/chapters/end_1.rpy:272
translate Spanish day7_start_weddingend_943f3f4c:

    # player "Thank you :D"
    player "Gracias :D"

# game/chapters/end_1.rpy:275
translate Spanish day7_start_weddingend_4563086f:

    # player "It comes naturally."
    player "Me sale natural."

# game/chapters/end_1.rpy:276
translate Spanish day7_start_weddingend_583bf634:

    # GR "believe me, i know."
    GR "créeme, lo sé."

# game/chapters/end_1.rpy:279
translate Spanish day7_start_weddingend_2dd65c86:

    # player "I've worked hard to achieve this level of bad."
    player "He trabajado duro para alcanzar este nivel de maldad."

# game/chapters/end_1.rpy:280
translate Spanish day7_start_weddingend_c0590bbc:

    # GR "no, this definitely comes natural to you."
    GR "no, esto definitivamente te sale natural."

# game/chapters/end_1.rpy:281
translate Spanish day7_start_weddingend_8fdfbf6b:

    # GR "you were born a little gremlin."
    GR "naciste siendo [arti_2] pequeñ[letra] gremlin."

# game/chapters/end_1.rpy:284
translate Spanish day7_start_weddingend_cb51e712:

    # player "You know what, you're totally right."
    player "¿Sabes qué? Tienes toda la razón."

# game/chapters/end_1.rpy:286
translate Spanish day7_start_weddingend_7772a27d_3:

    # GR "..."
    GR "..."

# game/chapters/end_1.rpy:288
translate Spanish day7_start_weddingend_c8a4fa9d:

    # GR "by the way, before we go any further, i had something to talk about."
    GR "por cierto, antes de continuar, tenía algo de lo que quería hablar."

# game/chapters/end_1.rpy:292
translate Spanish day7_start_weddingend_8f9fc312:

    # player "That doesn't sound ominous at all."
    player "Eso no suena nada ominoso."

# game/chapters/end_1.rpy:294
translate Spanish day7_start_weddingend_032f4afd:

    # GR "i have... hit the books, so to speak."
    GR "he estado... estudiando, por así decirlo."

# game/chapters/end_1.rpy:298
translate Spanish day7_start_weddingend_6d645bbb:

    # player "You been studying, Grimmy?"
    player "¿Has estado estudiando, Parquita?"

# game/chapters/end_1.rpy:300
translate Spanish day7_start_weddingend_ebc9eb7a:

    # GR "yes."
    GR "sí."

# game/chapters/end_1.rpy:301
translate Spanish day7_start_weddingend_b93dc99e:

    # GR "as i said yesterday, your soul is incomplete because you keep giving parts of it away."
    GR "como dije ayer, tu alma está incompleta porque sigues entregando partes de ella."

# game/chapters/end_1.rpy:302
translate Spanish day7_start_weddingend_42f05f00:

    # GR "something that is... usually not possible for a mortal."
    GR "algo que... normalmente no es posible para un mortal."

# game/chapters/end_1.rpy:303
translate Spanish day7_start_weddingend_50e4392b:

    # GR "that answered some of my questions."
    GR "eso respondió algunas de mis preguntas."

# game/chapters/end_1.rpy:304
translate Spanish day7_start_weddingend_282b70e9:

    # GR "why your soul seemed to feel so strange, how you managed to take my soul sickness away..."
    GR "por qué tu alma parecía tan extraña, cómo lograste quitarme la enfermedad del alma..."

# game/chapters/end_1.rpy:305
translate Spanish day7_start_weddingend_f2471d4b:

    # GR "but it didn't answer enough. i have so many more questions."
    GR "pero no respondió lo suficiente. tengo muchas más preguntas."

# game/chapters/end_1.rpy:306
translate Spanish day7_start_weddingend_207ffc15:

    # GR "i found the answer."
    GR "encontré la respuesta."

# game/chapters/end_1.rpy:310
translate Spanish day7_start_weddingend_0f5f02ca:

    # player "!!!"
    player "!!!"

# game/chapters/end_1.rpy:314
translate Spanish day7_start_weddingend_ca2087c9:

    # player "Lay it on me, Casper!"
    player "¡Dímela, Casper!"

# game/chapters/end_1.rpy:316
translate Spanish day7_start_weddingend_026bf5ab:

    # GR "[playerfirstname!l], you embody life just as i embody death."
    GR "[playerfirstname!l], tú encarnas la vida así como yo encarno la muerte."

# game/chapters/end_1.rpy:320
translate Spanish day7_start_weddingend_c237b9ba:

    # player "...?"
    player "...?"

# game/chapters/end_1.rpy:322
translate Spanish day7_start_weddingend_46c9b84d:

    # GR "my research lead me to a rare trait that shows... maybe only every thousand or so years in a mortal."
    GR "mi investigación me llevó a un rasgo raro que aparece... tal vez solo cada mil años más o menos en un mortal."

# game/chapters/end_1.rpy:323
translate Spanish day7_start_weddingend_c48cea89:

    # GR "you have the touch of life on your soul."
    GR "tienes el toque de la vida en tu alma."

# game/chapters/end_1.rpy:324
translate Spanish day7_start_weddingend_f676de59:

    # GR "you {i}are{/i} life, so to speak."
    GR "tú {i}eres{/i} vida, por así decirlo."

# game/chapters/end_1.rpy:325
translate Spanish day7_start_weddingend_a4b099f0:

    # GR "that is why i have not been able to take your soul."
    GR "por eso no he podido tomar tu alma."

# game/chapters/end_1.rpy:326
translate Spanish day7_start_weddingend_9a3ba732:

    # GR "that is how you avoid death without a thought."
    GR "por eso evitas la muerte sin siquiera pensarlo."

# game/chapters/end_1.rpy:327
translate Spanish day7_start_weddingend_5ebaedf1:

    # GR "that is why you can heal as you do."
    GR "por eso puedes sanar como lo haces."

# game/chapters/end_1.rpy:328
translate Spanish day7_start_weddingend_fac7ad14:

    # GR "you are special. you've always been special."
    GR "eres especial. siempre lo has sido."

# game/chapters/end_1.rpy:332
translate Spanish day7_start_weddingend_03775ec8_1:

    # player "..."
    player "..."

# game/chapters/end_1.rpy:336
translate Spanish day7_start_weddingend_5b23d895:

    # player "So I'm immortal now?"
    player "¿Así que ahora soy inmortal?"

# game/chapters/end_1.rpy:338
translate Spanish day7_start_weddingend_30ced879:

    # GR "i am unsure."
    GR "no estoy seguro."

# game/chapters/end_1.rpy:339
translate Spanish day7_start_weddingend_a4d15129:

    # GR "perhaps."
    GR "quizá."

# game/chapters/end_1.rpy:340
translate Spanish day7_start_weddingend_3a6aafaa:

    # GR "there's only one way to find out."
    GR "solo hay una forma de averiguarlo."

# game/chapters/end_1.rpy:341
translate Spanish day7_start_weddingend_d4faa1b7:

    # GR "and that will be me trying to take your soul one final time."
    GR "y eso significa que intentaré tomar tu alma una última vez."

# game/chapters/end_1.rpy:345
translate Spanish day7_start_weddingend_462b5f65:

    # player "Grimmy, let's be serious for a second."
    player "Parquita, seamos serios un segundo."

# game/chapters/end_1.rpy:348
translate Spanish day7_start_weddingend_ec58d12f:

    # player "It's obvious to us both that you aren't taking my soul."
    player "Es obvio para ambos que no vas a tomar mi alma."

# game/chapters/end_1.rpy:351
translate Spanish day7_start_weddingend_a169228e:

    # player "Just admit to defeat and we can, I dunno..."
    player "Solo admite tu derrota y podemos, no sé..."

# game/chapters/end_1.rpy:354
translate Spanish day7_start_weddingend_54caf5b2:

    # player "Plan our wedding or something instead?"
    player "¿Planear nuestra boda o algo así, en su lugar?"

# game/chapters/end_1.rpy:355
translate Spanish day7_start_weddingend_b49104a3:

    # GR "our..."
    GR "nues..."

# game/chapters/end_1.rpy:356
translate Spanish day7_start_weddingend_c1d5c7e3:

    # GR "our what? our {i}wedding{/i}? you're STILL spouting nonsense about that???"
    GR "¿nuestra qué? ¿nuestra {i}boda{/i}? ¿¿¿TODAVÍA estás diciendo tonterías sobre eso???"

# game/chapters/end_1.rpy:359
translate Spanish day7_start_weddingend_85b5685d:

    # player "Yep."
    player "Síp."

# game/chapters/end_1.rpy:364
translate Spanish day7_start_weddingend_b67e7bea:

    # player "I told you yesterday. Shotgun wedding!"
    player "Te lo dije ayer. ¡Boda exprés!"

# game/chapters/end_1.rpy:367
translate Spanish day7_start_weddingend_174deaf3:

    # player "Unless you don't want to ever get married?"
    player "¿A menos que no quieras casarte nunca?"

# game/chapters/end_1.rpy:370
translate Spanish day7_start_weddingend_8ba44856:

    # player "That's cool too."
    player "También está bien."

# game/chapters/end_1.rpy:372
translate Spanish day7_start_weddingend_8c880249:

    # GR "i never...."
    GR "yo nunca..."

# game/chapters/end_1.rpy:373
translate Spanish day7_start_weddingend_350ea4bd:

    # GR "it is not something i have ever given much thought to."
    GR "no es algo en lo que haya pensado mucho."

# game/chapters/end_1.rpy:377
translate Spanish day7_start_weddingend_b09f5cc0:

    # player "Well give it some now!"
    player "¡Pues piénsalo ahora!"

# game/chapters/end_1.rpy:379
translate Spanish day7_start_weddingend_90989ef7:

    # GR "this does not mean i admit to defeat, you know."
    GR "esto no significa que admita mi derrota, ¿sabes?"

# game/chapters/end_1.rpy:382
translate Spanish day7_start_weddingend_3cd4f5e7:

    # player "You're gonna come and take my soul then?"
    player "¿Vas a venir a tomar mi alma entonces?"

# game/chapters/end_1.rpy:383
translate Spanish day7_start_weddingend_7772a27d_4:

    # GR "..."
    GR "..."

# game/chapters/end_1.rpy:384
translate Spanish day7_start_weddingend_e1bba5c3:

    # GR "i suppose i am not, no."
    GR "supongo que no, no lo haré."

# game/chapters/end_1.rpy:385
translate Spanish day7_start_weddingend_d93f8f8f:

    # GR "how far the great has fallen..."
    GR "qué bajo ha caído el grande..."

# game/chapters/end_1.rpy:386
translate Spanish day7_start_weddingend_cfcd4279:

    # GR "i am akin to icarus, and you are my sun..."
    GR "soy como ícaro, y tú eres mi sol..."

# game/chapters/end_1.rpy:390
translate Spanish day7_start_weddingend_2d970951:

    # player "So you admit defeat."
    player "Entonces admites la derrota."

# game/chapters/end_1.rpy:391
translate Spanish day7_start_weddingend_5d364529:

    # GR "no."
    GR "no."

# game/chapters/end_1.rpy:392
translate Spanish day7_start_weddingend_7ab38720:

    # GR "i will never admit defeat."
    GR "nunca admitiré la derrota."

# game/chapters/end_1.rpy:395
translate Spanish day7_start_weddingend_4940ac70:

    # player "You're a sore loser. I win ;)"
    player "Eres un mal perdedor. Yo gano ;)"

# game/chapters/end_1.rpy:398
translate Spanish day7_start_weddingend_df70b938:

    # player "You lose by default~"
    player "Pierdes por defecto~"

# game/chapters/end_1.rpy:399
translate Spanish day7_start_weddingend_38e760f6:

    # GR "i will not accept that outcome."
    GR "no aceptaré ese resultado."

# game/chapters/end_1.rpy:403
translate Spanish day7_start_weddingend_9e27a2b0:

    # player "That doesn't matter. You still lose."
    player "Eso no importa. Igual pierdes."

# game/chapters/end_1.rpy:407
translate Spanish day7_start_weddingend_750c53da:

    # player "You're such a sweetie, letting me keep my soul."
    player "Eres tan dulce, dejándome quedarme con mi alma."

# game/chapters/end_1.rpy:408
translate Spanish day7_start_weddingend_23c1e82c:

    # GR "what can i say, i'm just so... generous."
    GR "qué puedo decir, soy tan... generoso."

# game/chapters/end_1.rpy:409
translate Spanish day7_start_weddingend_8cbe138f:

    # GR "i'd say, as thanks, you probably owe me a favor now."
    GR "diría que, como agradecimiento, probablemente me debas un favor ahora."

# game/chapters/end_1.rpy:412
translate Spanish day7_start_weddingend_332f8faa:

    # player "Hahaha, is this the next game you wanna play?"
    player "Jajaja, ¿ese es el siguiente juego que quieres jugar?"

# game/chapters/end_1.rpy:413
translate Spanish day7_start_weddingend_15e1c76f:

    # GR "i do like a good game."
    GR "me gustan los buenos juegos."

# game/chapters/end_1.rpy:416
translate Spanish day7_start_weddingend_02af7c38:

    # player "You're my kinda guy, Grim."
    player "Eres de mi tipo, Parca."

# game/chapters/end_1.rpy:417
translate Spanish day7_start_weddingend_b9b7982c:

    # GR "i... hope so."
    GR "eso... espero."

# game/chapters/end_1.rpy:421
translate Spanish day7_start_weddingend_481de436:

    # player "I always knew I'd be victorious."
    player "Siempre supe que sería victorios[letra]."

# game/chapters/end_1.rpy:424
translate Spanish day7_start_weddingend_26397ea2:

    # player "I don't often lose, you know."
    player "No suelo perder, ¿sabes?"

# game/chapters/end_1.rpy:425
translate Spanish day7_start_weddingend_d78da614:

    # GR "yes, well, perhaps you were born with 'luck' that i was not."
    GR "sí, bueno, quizás naciste con una 'suerte' que yo no tuve."

# game/chapters/end_1.rpy:428
translate Spanish day7_start_weddingend_5d692d7b:

    # player "Now now Casper, there's no need to be a sore loser."
    player "Vamos, Casper, no hay necesidad de ser un mal perdedor."

# game/chapters/end_1.rpy:429
translate Spanish day7_start_weddingend_1951d89e:

    # GR "i am neither sore nor a loser."
    GR "no soy ni un mal perdedor ni un perdedor."

# game/chapters/end_1.rpy:432
translate Spanish day7_start_weddingend_8d8d8fee:

    # player "There's nothing wrong with second place :)"
    player "No tiene nada de malo quedar en segundo lugar :)"

# game/chapters/end_1.rpy:433
translate Spanish day7_start_weddingend_c05fd2df:

    # GR "now you're just rubbing it in."
    GR "ahora solo lo estás restregando."

# game/chapters/end_1.rpy:436
translate Spanish day7_start_weddingend_b8ebf0e2:

    # player "I'll win all our future bets and games too~"
    player "También ganaré todas nuestras futuras apuestas y juegos~"

# game/chapters/end_1.rpy:437
translate Spanish day7_start_weddingend_50b9f216:

    # GR "this is your one and only win, savor it while it lasts."
    GR "esta es tu única victoria, disfrútala mientras dure."

# game/chapters/end_1.rpy:440
translate Spanish day7_start_weddingend_3e3da431:

    # player "Yes sir!"
    player "¡Sí, señor!"

# game/chapters/end_1.rpy:442
translate Spanish day7_start_weddingend_247513f6:

    # player "I wouldn't be so sure, Grimmy~"
    player "No estaría tan segur[letra], Parquita~"

# game/chapters/end_1.rpy:446
translate Spanish day7_start_weddingend_200ea986:

    # player "I'm serious about the wedding, though."
    player "Pero hablo en serio con lo de la boda."

# game/chapters/end_1.rpy:448
translate Spanish day7_start_weddingend_201e4527:

    # GR "of... course you are."
    GR "cla... claro que sí."

# game/chapters/end_1.rpy:449
translate Spanish day7_start_weddingend_fa717c60:

    # GR "i don't think i am marriage material."
    GR "no creo que tenga madera de esposo."

# game/chapters/end_1.rpy:452
translate Spanish day7_start_weddingend_a3342a97:

    # player "That is so incorrect it's almost funny."
    player "Eso es tan incorrecto que casi da risa."

# game/chapters/end_1.rpy:455
translate Spanish day7_start_weddingend_d8f49ae5:

    # player "How can you not see that?"
    player "¿Cómo puedes no verlo?"

# game/chapters/end_1.rpy:456
translate Spanish day7_start_weddingend_47e7c160:

    # GR "i'm a reaper, in case you have forgotten."
    GR "soy una parca, por si lo habías olvidado."

# game/chapters/end_1.rpy:457
translate Spanish day7_start_weddingend_6129bf96:

    # GR "and that doesn't exactly scream 'marry me'."
    GR "y eso no grita precisamente 'cásate conmigo'."

# game/chapters/end_1.rpy:460
translate Spanish day7_start_weddingend_9edde8fa:

    # player "It does to me."
    player "Para mí sí lo hace."

# game/chapters/end_1.rpy:463
translate Spanish day7_start_weddingend_783aaf24:

    # player "When you stare at me with your stupidly pretty eyes, I can tell."
    player "Cuando me miras con esos ojos ridículamente bonitos, puedo notarlo."

# game/chapters/end_1.rpy:467
translate Spanish day7_start_weddingend_73385f4d:

    # player "Absolutely husband material."
    player "Tienes toda la madera de un buen esposo."

# game/chapters/end_1.rpy:469
translate Spanish day7_start_weddingend_4c37caf1:

    # GR "firstly, that makes no sense."
    GR "primero, eso no tiene sentido."

# game/chapters/end_1.rpy:470
translate Spanish day7_start_weddingend_ba174417:

    # GR "secondly, i stare because i've been trying to figure out how the hell you've lived this long."
    GR "segundo, te miro porque trato de entender cómo demonios has vivido tanto tiempo."

# game/chapters/end_1.rpy:471
translate Spanish day7_start_weddingend_bac7b765:

    # GR "you are a mess of a mortal."
    GR "eres un desastre de mortal."

# game/chapters/end_1.rpy:474
translate Spanish day7_start_weddingend_42161e7a:

    # player "I'm just that good at staying alive."
    player "Soy muy hábil sobreviviendo."

# game/chapters/end_1.rpy:477
translate Spanish day7_start_weddingend_1ca22e5f:

    # player "You know what else I'm good at?"
    player "¿Sabes en qué más soy hábil?"

# game/chapters/end_1.rpy:478
translate Spanish day7_start_weddingend_aa2abbd2:

    # GR "i dread to think."
    GR "me da miedo pensarlo."

# game/chapters/end_1.rpy:479
translate Spanish day7_start_weddingend_0588cc37:

    # GR "but do go ahead and grace me with whatever it is you {i}must{/i} say."
    GR "pero adelante, ilumíname con eso que {i}debes{/i} decir."

# game/chapters/end_1.rpy:482
translate Spanish day7_start_weddingend_95d3bd4f:

    # player "Planning weddings."
    player "Planear bodas."

# game/chapters/end_1.rpy:485
translate Spanish day7_start_weddingend_f6021651:

    # player "Ours specifically."
    player "La nuestra, específicamente."

# game/chapters/end_1.rpy:486
translate Spanish day7_start_weddingend_814bd5cf:

    # GR "you are... just teasing me."
    GR "tú solo... me estás tomando el pelo."

# game/chapters/end_1.rpy:490
translate Spanish day7_start_weddingend_ff885386:

    # player "You are 110 percent husband material."
    player "Tienes madera de esposo al ciento diez por ciento."

# game/chapters/end_1.rpy:493
translate Spanish day7_start_weddingend_8de50dfa:

    # player "In fact that number is much too small."
    player "De hecho, ese número es demasiado bajo."

# game/chapters/end_1.rpy:494
translate Spanish day7_start_weddingend_6bba3559:

    # GR "don't be dramatic."
    GR "no seas dramático."

# game/chapters/end_1.rpy:497
translate Spanish day7_start_weddingend_9c3d6bdd:

    # player "I'm being deadly serious right now."
    player "Hablo mortalmente en serio."

# game/chapters/end_1.rpy:500
translate Spanish day7_start_weddingend_a79b9c60:

    # player "It definitely is multiple numbers too small."
    player "Definitivamente se queda corto por varios números."

# game/chapters/end_1.rpy:501
translate Spanish day7_start_weddingend_803d04c9:

    # GR "what exactly classifies as husband material to you?"
    GR "¿qué características debe tener alguien para que lo consideres un buen esposo?"

# game/chapters/end_1.rpy:504
translate Spanish day7_start_weddingend_9d39d9f1:

    # player "Well, obviously he'd have to be a grim reaper."
    player "Bueno, obviamente tendría que ser una parca."

# game/chapters/end_1.rpy:507
translate Spanish day7_start_weddingend_6341e34a:

    # player "Otherwise it's just a no-go, you know?."
    player "De lo contrario, simplemente no funcionaría, ¿sabes?"

# game/chapters/end_1.rpy:508
translate Spanish day7_start_weddingend_7772a27d_5:

    # GR "..."
    GR "..."

# game/chapters/end_1.rpy:509
translate Spanish day7_start_weddingend_3f245338:

    # GR "right. a very reasonable expectation."
    GR "claro. una expectativa muy razonable."

# game/chapters/end_1.rpy:512
translate Spanish day7_start_weddingend_8029b449:

    # player "Pretty long white hair, deep red eyes, super awkward, really good looking."
    player "Cabello blanco largo, ojos rojos intensos, súper torpe, muy guapo."

# game/chapters/end_1.rpy:513
translate Spanish day7_start_weddingend_ca950bf9:

    # GR "i'm not awkward..."
    GR "no soy torpe..."

# game/chapters/end_1.rpy:514
translate Spanish day7_start_weddingend_175b5c4e:

    # GR "i am confident in all aspects of my life."
    GR "soy seguro de mí mismo en todos los aspectos de mi vida."

# game/chapters/end_1.rpy:517
translate Spanish day7_start_weddingend_16d1de03:

    # player "You are perfectly awkward Casper."
    player "Eres perfectamente torpe, Casper."

# game/chapters/end_1.rpy:520
translate Spanish day7_start_weddingend_60c742a0:

    # player "I like it."
    player "Me gusta."

# game/chapters/end_1.rpy:521
translate Spanish day7_start_weddingend_ad24e7dd:

    # GR "how is this happening to me..."
    GR "cómo es posible que esto me esté pasando..."

# game/chapters/end_1.rpy:524
translate Spanish day7_start_weddingend_0c88ee65:

    # player "You know what else I like?"
    player "¿Sabes qué más me gusta?"

# game/chapters/end_1.rpy:525
translate Spanish day7_start_weddingend_666fc90a:

    # GR "apart from teasing me? what else could there be?"
    GR "¿además de molestarme? ¿qué más podría haber?"

# game/chapters/end_1.rpy:528
translate Spanish day7_start_weddingend_34a1160d:

    # player "Weddings."
    player "Las bodas."

# game/chapters/end_1.rpy:530
translate Spanish day7_start_weddingend_88b9c082:

    # GR "i'm sure you're... not being serious right now."
    GR "seguro que... no estás hablando en serio ahora."

# game/chapters/end_1.rpy:533
translate Spanish day7_start_weddingend_5a0c6a5e:

    # player "You're like a dream, how would you not be?"
    player "Eres como un sueño, ¿cómo no podrías serlo?"

# game/chapters/end_1.rpy:536
translate Spanish day7_start_weddingend_72d115ae:

    # player "I bet there are loads of people who would marry you."
    player "Apuesto a que hay un montón de personas que se casarían contigo."

# game/chapters/end_1.rpy:539
translate Spanish day7_start_weddingend_6fef0b93:

    # player "If I posted some pictures of you online, people would come flocking."
    player "Si publicara algunas fotos tuyas en línea, la gente vendría en masa."

# game/chapters/end_1.rpy:540
translate Spanish day7_start_weddingend_1febb025:

    # GR "ha."
    GR "ja."

# game/chapters/end_1.rpy:541
translate Spanish day7_start_weddingend_8ac447b7:

    # GR "that much is true, at least. i am irresistible."
    GR "eso al menos es cierto. soy irresistible."

# game/chapters/end_1.rpy:544
translate Spanish day7_start_weddingend_bd6bd46f:

    # player "I can see the comments now."
    player "Ya puedo ver los comentarios."

# game/chapters/end_1.rpy:547
translate Spanish day7_start_weddingend_f2a4221e:

    # player "'I'd marry him.', 'He's so babygirl.', 'Can I make him whimper~'."
    player "'Me casaría con él.', 'Es tan babygirl.', '¿Puedo hacer que gimotee~?'"

# game/chapters/end_1.rpy:548
translate Spanish day7_start_weddingend_02becdc2:

    # GR "why would anyone say that last one?"
    GR "¿por qué alguien diría ese último?"

# game/chapters/end_1.rpy:551
translate Spanish day7_start_weddingend_d0c16ade:

    # player "Good question."
    player "Buena pregunta."

# game/chapters/end_1.rpy:554
translate Spanish day7_start_weddingend_dcc67f07:

    # player "But seriously though, the whole wedding thing..."
    player "Pero en serio, con respecto a lo de la boda..."

# game/chapters/end_1.rpy:557
translate Spanish day7_start_weddingend_88b9c082_1:

    # GR "i'm sure you're... not being serious right now."
    GR "seguro que... no estás hablando en serio ahora."

# game/chapters/end_1.rpy:563
translate Spanish day7_start_weddingend_056fa040:

    # player "I'd marry you in a heartbeat."
    player "Me casaría contigo sin pensarlo."

# game/chapters/end_1.rpy:564
translate Spanish day7_start_weddingend_7772a27d_6:

    # GR "..."
    GR "..."

# game/chapters/end_1.rpy:594
translate Spanish call1_dayweddingend_e9be2e7c:

    # GRC "Ah, shit, I didn't mean to hit the call button...!"
    GRC "¡Ah, mierda, no quise presionar el botón de llamada...!"

# game/chapters/end_1.rpy:595
translate Spanish call1_dayweddingend_405951fa:

    # GRC "You weren't supposed to answer!"
    GRC "¡No se suponía que contestaras!"

# game/chapters/end_1.rpy:600
translate Spanish call1_dayweddingend_7593d9a2:

    # GRC "Hang up! This instant, mortal, or I will have your soul immediately...!"
    GRC "¡Cuelga! ¡En este instante, mortal, o tomaré tu alma de inmediato...!"

# game/chapters/end_1.rpy:612
translate Spanish call1_dayweddingend_0a2c4bf7:

    # GRC "!!!"
    GRC "!!!"

# game/chapters/end_1.rpy:616
translate Spanish call1_dayweddingend_251f58c6:

    # GRC "Wh-what?!"
    GRC "¡¿Q-qué?!"

# game/chapters/end_1.rpy:626
translate Spanish call1_dayweddingend_252e644f:

    # GRC "I don't... we...!"
    GRC "¡Yo no... nosotros...!"

# game/chapters/end_1.rpy:631
translate Spanish call1_dayweddingend_3ac24fdd:

    # GRC "Nine hells, Sunshine..." id call1_dayweddingend_3ac24fdd
    GRC "Nueve infiernos, Solecito..." id call1_dayweddingend_3ac24fdd

# game/chapters/end_1.rpy:637
translate Spanish call1_dayweddingend_fb1ebf40:

    # GRC "You're suddenly going on and on about marriage...!"
    GRC "¡De repente empiezas a hablar sin parar sobre matrimonio...!"

# game/chapters/end_1.rpy:639
translate Spanish call1_dayweddingend_a89cbcd3:

    # GRC "Surely I'm the last person you'd want to do that with!"
    GRC "¡Seguramente soy la última persona con la que querrías hacer eso!"

# game/chapters/end_1.rpy:648
translate Spanish call1_dayweddingend_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/end_1.rpy:649
translate Spanish call1_dayweddingend_ab8f3a55:

    # GRC "If only I could have... hating you would make my life much easier..."
    GRC "Si tan solo hubiera podido... Odiarte haría mi vida mucho más fácil..."

# game/chapters/end_1.rpy:651
translate Spanish call1_dayweddingend_76ba04b1:

    # GRC "...Sunshine, I've come to desire you above everything else."
    GRC "...Solecito, he llegado a desearte por encima de todo."

# game/chapters/end_1.rpy:652
translate Spanish call1_dayweddingend_c4081306:

    # GRC "Maybe that's just a... one-sided wish, though."
    GRC "Aunque quizá eso sea solo un... deseo unilateral."

# game/chapters/end_1.rpy:675
translate Spanish call1_dayweddingend_55bdc250:

    # GRC "......"
    GRC "......"

# game/chapters/end_1.rpy:679
translate Spanish call1_dayweddingend_5bba3ea2:

    # GRC "Are... are you pulling another prank on me?"
    GRC "¿Me... me estás gastando otra broma?"

# game/chapters/end_1.rpy:680
translate Spanish call1_dayweddingend_93c67178:

    # GRC "Is this a joke?"
    GRC "¿Es una broma?"

# game/chapters/end_1.rpy:687
translate Spanish call1_dayweddingend_0c13df0d:

    # GRC "A grim reaper cannot refuse to take a soul, you know."
    GRC "Una parca no puede negarse a tomar un alma, ¿sabes?"

# game/chapters/end_1.rpy:688
translate Spanish call1_dayweddingend_ec273235:

    # GRC "Neither can they run away with someone to get married."
    GRC "Tampoco puede huir con alguien para casarse."

# game/chapters/end_1.rpy:694
translate Spanish call1_dayweddingend_5c95df3b:

    # GRC "Are you offering to hide me?"
    GRC "¿Estás ofreciéndote para esconderme?"

# game/chapters/end_1.rpy:701
translate Spanish call1_dayweddingend_873012cb:

    # GRC "Then... theoretically speaking..."
    GRC "Entonces... teóricamente hablando..."

# game/chapters/end_1.rpy:703
translate Spanish call1_dayweddingend_280feb06:

    # GRC "Maybe in some place with... flowers?"
    GRC "¿Tal vez en algún lugar con... flores?"

# game/chapters/end_1.rpy:707
translate Spanish call1_dayweddingend_3317b6ac:

    # GRC "And maybe in a season where the sun shines bright..."
    GRC "Y quizá en una estación donde el sol brille con fuerza..."

# game/chapters/end_1.rpy:709
translate Spanish call1_dayweddingend_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/end_1.rpy:710
translate Spanish call1_dayweddingend_85834589:

    # GRC "If you'd like..."
    GRC "Si quisieras..."

# game/chapters/end_1.rpy:712
translate Spanish call1_dayweddingend_8710f0c1:

    # GRC "Theoretically..."
    GRC "Teóricamente..."

# game/chapters/end_1.rpy:714
translate Spanish call1_dayweddingend_7aadc7a1:

    # GRC "Maybe?"
    GRC "¿Tal vez?"

# game/chapters/end_1.rpy:721
translate Spanish call1_dayweddingend_008afe10_2:

    # GRC "..."
    GRC "..."

# game/chapters/end_1.rpy:728
translate Spanish call1_dayweddingend_4ac0f8fe:

    # GRC "50 percent... that is incorrect."
    GRC "Cincuenta por ciento... eso es incorrecto."

# game/chapters/end_1.rpy:733
translate Spanish call1_dayweddingend_dff5f59e:

    # GRC "Sunshine, when I'm around you, I am a zero on the pureness scale..." id call1_dayweddingend_dff5f59e
    GRC "Solecito, cuando estoy contigo, soy un cero en la escala de pureza..." id call1_dayweddingend_dff5f59e

# game/chapters/end_1.rpy:741
translate Spanish call1_dayweddingend_133c1d0c:

    # GRC "That is not a word I would associate with myself."
    GRC "Esa no es una palabra que asociaría conmigo."

# game/chapters/end_1.rpy:744
translate Spanish call1_dayweddingend_cd5c1d78:

    # GRC "I could not disagree more.."
    GRC "No podría estar más en desacuerdo..."

# game/chapters/end_1.rpy:751
translate Spanish call1_dayweddingend_b8d5f407:

    # GRC "...!"
    GRC "...!"

# game/chapters/end_1.rpy:762
translate Spanish call1_dayweddingend_7fd46421:

    # GRC "You're sitting down."
    GRC "Estás sentad[letra]."

# game/chapters/end_1.rpy:767
translate Spanish call1_dayweddingend_550b3130:

    # GRC "That sounds stupid."
    GRC "Eso suena estúpido."

# game/chapters/end_1.rpy:779
translate Spanish call1_dayweddingend_defb3329:

    # GRC "I would wear something that complements my good looks."
    GRC "Usaría algo que complemente mi buen aspecto."

# game/chapters/end_1.rpy:787
translate Spanish call1_dayweddingend_89e8213d:

    # GRC "I know."
    GRC "Lo sé."

# game/chapters/end_1.rpy:793
translate Spanish call1_dayweddingend_3df106d6:

    # GRC "I will... wear something else. Something special."
    GRC "Yo... usaré otra cosa. Algo especial."

# game/chapters/end_1.rpy:801
translate Spanish call1_dayweddingend_1dfb0165:

    # GRC "Only if you do the same."
    GRC "Solo si tú haces lo mismo."

# game/chapters/end_1.rpy:802
translate Spanish call1_dayweddingend_3944e4b2:

    # GRC "It will only be fair."
    GRC "Será justo."

# game/chapters/end_1.rpy:813
translate Spanish call1_dayweddingend_b8d5f407_1:

    # GRC "...!"
    GRC "...!"

# game/chapters/end_1.rpy:817
translate Spanish call1_dayweddingend_04ad4823:

    # GRC "You... twist my words..."
    GRC "Tú... retuerces mis palabras..."

# game/chapters/end_1.rpy:827
translate Spanish call1_dayweddingend_008afe10_3:

    # GRC "..."
    GRC "..."

# game/chapters/end_1.rpy:838
translate Spanish call1_dayweddingend_0096bb44:

    # GRC "I told you... it's not something I've ever really thought much about."
    GRC "Te lo dije... no es algo en lo que haya pensado mucho."

# game/chapters/end_1.rpy:846
translate Spanish call1_dayweddingend_008afe10_4:

    # GRC "..."
    GRC "..."

# game/chapters/end_1.rpy:847
translate Spanish call1_dayweddingend_afe2f617:

    # GRC "Gods you're good..."
    GRC "Por los dioses, qué bien lo haces..."

# game/chapters/end_1.rpy:858
translate Spanish call1_dayweddingend_3484df58:

    # GRC "I... well."
    GRC "Yo... bueno."

# game/chapters/end_1.rpy:859
translate Spanish call1_dayweddingend_008afe10_5:

    # GRC "..."
    GRC "..."

# game/chapters/end_1.rpy:861
translate Spanish call1_dayweddingend_ff789da1:

    # GRC "I suppose it would be nice."
    GRC "Supongo que sería lindo."

# game/chapters/end_1.rpy:862
translate Spanish call1_dayweddingend_fee2e323:

    # GRC "...If you wanted to."
    GRC "...Si tú quisieras."

# game/chapters/end_1.rpy:875
translate Spanish call1_dayweddingend_7fd28643:

    # GRC "I can't believe I want you..."
    GRC "No puedo creer que te quiera..."

# game/chapters/end_1.rpy:876
translate Spanish call1_dayweddingend_77bdb959:

    # GRC "Of all the mortals, it had to be you..."
    GRC "De todos los mortales, tenías que ser tú..."

# game/chapters/end_1.rpy:878
translate Spanish call1_dayweddingend_16f66647:

    # GRC "And for some reason, I would have it no other way..."
    GRC "Y por alguna razón, no lo querría de otra manera..."

# game/chapters/end_1.rpy:882
translate Spanish call1_dayweddingend_b868d01f:

    # GRC "That you also want me... makes my chest feel a heaviness I've never felt before."
    GRC "Que tú también me quieras... hace que mi pecho sienta una pesadez que nunca antes había sentido."

# game/chapters/end_1.rpy:889
translate Spanish call1_dayweddingend_0682eb00:

    # GRC "...I've never been very patient, I suppose."
    GRC "...Nunca he sido muy paciente, supongo."

# game/chapters/end_1.rpy:900
translate Spanish call1_dayweddingend_2bde79b7:

    # GRC "That... you wear something gorgeous."
    GRC "Que... lleves algo hermoso."

# game/chapters/end_1.rpy:901
translate Spanish call1_dayweddingend_13b49e8e:

    # GRC "And that I get picture of you in it."
    GRC "Y que tenga una foto tuya con eso puesto."

# game/chapters/end_1.rpy:912
translate Spanish call1_dayweddingend_2df19302:

    # GRC "Pictures of you... with the flowers."
    GRC "Fotos tuyas... entre las flores."

# game/chapters/end_1.rpy:920
translate Spanish call1_dayweddingend_8229f56c:

    # GRC "You want to get {i}naked{/i} for photos at your OWN wedding?"
    GRC "¿Quieres {i}desnudarte{/i} para las fotos de tu PROPIA boda?"

# game/chapters/end_1.rpy:924
translate Spanish call1_dayweddingend_6a31fbe0:

    # GRC "You are... unbelievable."
    GRC "Eres... increíble."

# game/chapters/end_1.rpy:925
translate Spanish call1_dayweddingend_4bba97c9:

    # GRC "Then let me take the photos. So that.. I... I'm the only one that can... see you like that."
    GRC "Entonces déjame tomar las fotos. Así... yo... seré el único que pueda... verte así."

# game/chapters/end_1.rpy:941
translate Spanish call1_dayweddingend_3d68be09:

    # GRC "You're really into this."
    GRC "Realmente te gusta esto."

# game/chapters/end_1.rpy:949
translate Spanish call1_dayweddingend_f311eac5:

    # GRC "Yes, well... you'll need some patience, Sunshine." id call1_dayweddingend_f311eac5
    GRC "Sí, bueno... vas a necesitar algo de paciencia, Solecito." id call1_dayweddingend_f311eac5

# game/chapters/end_1.rpy:950
translate Spanish call1_dayweddingend_bc091f97:

    # GRC "Weddings do not spring up out of nowhere... hypothetical or not."
    GRC "Las bodas no surgen de la nada... hipotéticas o no."

# game/chapters/end_1.rpy:955
translate Spanish call1_dayweddingend_7a511b2b:

    # GRC "...You're enjoying this way too much."
    GRC "...Te estás divirtiendo demasiado con esto."

# game/chapters/end_1.rpy:967
translate Spanish call1_dayweddingend_b24d2596:

    # GRC "Killer... sure, that's definitely what it was."
    GRC "Letal... claro, eso definitivamente fue lo que pasó."

# game/chapters/end_1.rpy:972
translate Spanish call1_dayweddingend_f9e61c98:

    # GRC "You are the worst person in existence."
    GRC "Eres la peor persona que existe."

# game/chapters/end_1.rpy:973
translate Spanish call1_dayweddingend_1d1bbdfa:

    # GRC "And for some reason I love it. Ugh."
    GRC "Y por alguna razón me encanta. Ugh."

# game/chapters/end_1.rpy:977
translate Spanish call1_dayweddingend_68482d8c:

    # GRC "Is it not {i}my{/i} good looks {i}you{/i} fell for?"
    GRC "¿No fue {i}mi{/i} buen aspecto lo que {i}te{/i} enamoró?"

# game/chapters/end_1.rpy:981
translate Spanish call1_dayweddingend_008afe10_6:

    # GRC "..."
    GRC "..."

# game/chapters/end_1.rpy:983
translate Spanish call1_dayweddingend_cc8bd2a6:

    # GRC "I'm good with both."
    GRC "Me gustan ambas cosas."

# game/chapters/end_1.rpy:988
translate Spanish call1_dayweddingend_5ef49cc4:

    # GRC "Silly..."
    GRC "Tonta..."

# game/chapters/end_1.rpy:989
translate Spanish call1_dayweddingend_0cdec69e:

    # GRC "You are the one with a silly personality."
    GRC "Tú eres quien tiene una personalidad tonta."

# game/chapters/end_1.rpy:990
translate Spanish call1_dayweddingend_d5f06535:

    # GRC "You're far more odd than I am."
    GRC "Eres mucho más bicho raro que yo."

# game/chapters/end_1.rpy:994
translate Spanish call1_dayweddingend_c30b8a34:

    # GRC "My life just got a hell of a lot more chaotic."
    GRC "Mi vida acaba de volverse muchísimo más caótica."

# game/chapters/end_1.rpy:1004
translate Spanish call1_dayweddingend_8da23161:

    # GRC "...."
    GRC "...."

# game/chapters/end_1.rpy:1008
translate Spanish call1_dayweddingend_1388ed66:

    # GRC "I want to come see you, Sunshine." id call1_dayweddingend_1388ed66
    GRC "Quiero ir a verte, Solecito." id call1_dayweddingend_1388ed66

# game/chapters/end_1.rpy:1015
translate Spanish call1_dayweddingend_008afe10_7:

    # GRC "..."
    GRC "..."

# game/chapters/end_1.rpy:1016
translate Spanish call1_dayweddingend_134684d9:

    # GRC "Wait for me, okay?"
    GRC "Espérame, ¿okey?"

# game/chapters/end_1.rpy:1055
translate Spanish chat2_dayweddingend_1dc1b57f:

    # GRC "Sunshine." id chat2_dayweddingend_1dc1b57f
    GRC "Solecito." id chat2_dayweddingend_1dc1b57f

# game/chapters/end_1.rpy:1058
translate Spanish chat2_dayweddingend_52fcdb03:

    # GRC "I'm hoping this will be the first and last time, actually."
    GRC "Espero que esta sea la primera y última vez, en realidad."

# game/chapters/end_1.rpy:1061
translate Spanish chat2_dayweddingend_f0a23812:

    # GRC "Is it okay?"
    GRC "¿Está bien?"

# game/chapters/end_1.rpy:1065
translate Spanish chat2_dayweddingend_66cb8233:

    # GRC "Ha."
    GRC "Ja."

# game/chapters/end_1.rpy:1066
translate Spanish chat2_dayweddingend_f7779861:

    # GRC "I would've gone with devilishly handsome."
    GRC "Yo habría dicho 'endiabladamente guapo'."

# game/chapters/end_1.rpy:1067
translate Spanish chat2_dayweddingend_62a1c8e5:

    # GRC "But... to die for seems adequate considering how we met."
    GRC "Pero... 'para morirse' parece adecuado, considerando cómo nos conocimos."

# game/chapters/end_1.rpy:1071
translate Spanish chat2_dayweddingend_8fd49486:

    # GRC "Then you know I wasn't lying."
    GRC "Entonces sabes que no mentía."

# game/chapters/end_1.rpy:1087
translate Spanish chat2_dayweddingend_008afe10:

    # GRC "..."
    GRC "..."

# game/chapters/end_1.rpy:1088
translate Spanish chat2_dayweddingend_52755892:

    # GRC "You too, Sunshine."
    GRC "Tú también, Solecito."

# game/chapters/end_1.rpy:1089
translate Spanish chat2_dayweddingend_305abe08:

    # GRC "You're... irresistible. More than words can ever come close to explaining."
    GRC "Eres... irresistible. No hay palabras que alcancen a describirlo."

# game/chapters/end_1.rpy:1090
translate Spanish chat2_dayweddingend_00b6212b:

    # GRC "I have to admit, I'm feeling a little..."
    GRC "Debo admitirlo, me siento un poco..."

# game/chapters/end_1.rpy:1091
translate Spanish chat2_dayweddingend_e36825f5:

    # GRC "Nervous."
    GRC "Nervioso."

# game/chapters/end_1.rpy:1098
translate Spanish chat2_dayweddingend_06cb1448:

    # GRC "I am trying to ignore the feeling."
    GRC "Estoy intentando ignorar la sensación."

# game/chapters/end_1.rpy:1099
translate Spanish chat2_dayweddingend_df2f609d:

    # GRC "But it's... quite strange."
    GRC "Pero es... bastante extraña."

# game/chapters/end_1.rpy:1103
translate Spanish chat2_dayweddingend_9c1698de:

    # GRC "I've always been good at what I do."
    GRC "Siempre he sido bueno en lo que hago."

# game/chapters/end_1.rpy:1104
translate Spanish chat2_dayweddingend_d2822586:

    # GRC "Call me arrogant, but it's true..."
    GRC "Llámame arrogante, pero es verdad..."

# game/chapters/end_1.rpy:1105
translate Spanish chat2_dayweddingend_c201b11c:

    # GRC "This is the most important thing I've ever done, and I want to get it right."
    GRC "Esto es lo más importante que he hecho en mi vida, y quiero hacerlo bien."

# game/chapters/end_1.rpy:1108
translate Spanish chat2_dayweddingend_008afe10_1:

    # GRC "..."
    GRC "..."

# game/chapters/end_1.rpy:1109
translate Spanish chat2_dayweddingend_32668226:

    # GRC "Thanks?"
    GRC "¿Gracias?"

# game/chapters/end_1.rpy:1119
translate Spanish chat2_dayweddingend_3e3dc261:

    # GRC "They remind me of you."
    GRC "Me recuerdan a ti."

# game/chapters/end_1.rpy:1120
translate Spanish chat2_dayweddingend_7d9dc1a1:

    # GRC "I couldn't pick anything else."
    GRC "No podía elegir otra cosa."

# game/chapters/end_1.rpy:1122
translate Spanish chat2_dayweddingend_8da23161:

    # GRC "...."
    GRC "...."

# game/chapters/end_1.rpy:1123
translate Spanish chat2_dayweddingend_1dc1b57f_1:

    # GRC "Sunshine." id chat2_dayweddingend_1dc1b57f_1
    GRC "Solecito." id chat2_dayweddingend_1dc1b57f_1

# game/chapters/end_1.rpy:1124
translate Spanish chat2_dayweddingend_5be3b454:

    # GRC "My Sunshine."
    GRC "Mi Solecito."

# game/chapters/end_1.rpy:1125
translate Spanish chat2_dayweddingend_57b80d2c:

    # GRC "Shall we get married?"
    GRC "¿Nos casamos?"

# game/chapters/end_1.rpy:1135
translate Spanish chat2_dayweddingend_1ec6ed45:

    # GRC "This is going to be chaotic."
    GRC "Esto va a ser un caos."

# game/chapters/end_1.rpy:1136
translate Spanish chat2_dayweddingend_21eca543:

    # GRC "In all the best ways."
    GRC "De todas las mejores formas posibles."

# game/chapters/end_1.rpy:1139
translate Spanish chat2_dayweddingend_51547240:

    # GRC "We've been planning this for ages...."
    GRC "Hemos estado planeando esto desde hace siglos..."

# game/chapters/end_1.rpy:1149
translate Spanish chat2_dayweddingend_c28ee3a2:

    # GRC "Somehow even that makes me happy..."
    GRC "De alguna manera, incluso eso me hace feliz..."

# game/chapters/end_1.rpy:1151
translate Spanish chat2_dayweddingend_ac51bc43:

    # GRC "Ha. Speak for yourself, Sunshine."
    GRC "Ja. Habla por ti, Solecito."

# game/chapters/end_1.rpy:1152
translate Spanish chat2_dayweddingend_80ebea43:

    # GRC "I'll be the one trying to keep you in line."
    GRC "Yo seré quien intente mantenerte a raya."

# game/chapters/end_1.rpy:1156
translate Spanish chat2_dayweddingend_928e3116:

    # GRC "I said it like that for a reason."
    GRC "Lo dije así por una razón."

# game/chapters/end_1.rpy:1157
translate Spanish chat2_dayweddingend_4b7846a8:

    # GRC "But I don't mind."
    GRC "Pero no me importa."

# game/chapters/end_1.rpy:1158
translate Spanish chat2_dayweddingend_d45717c5:

    # GRC "Life would be a lot less interesting if you weren't such a troublesome mortal."
    GRC "La vida sería mucho menos interesante si no fueras [arti_2] mortal tan problemátic[letra]."

# game/chapters/end_1.rpy:1160
translate Spanish chat2_dayweddingend_1737f4cf:

    # GRC "...I love you, my perfect ray of sunshine." id chat2_dayweddingend_1737f4cf
    GRC "...Te amo, mi rayito de sol perfecto." id chat2_dayweddingend_1737f4cf

# game/chapters/end_1.rpy:1161
translate Spanish chat2_dayweddingend_f379b6dc:

    # GRC "Always have and always will."
    GRC "Siempre te he amado y siempre lo haré."

# game/chapters/end_1.rpy:1171
translate Spanish chat2_dayweddingend_07ab7154:

    # GRC "...What?"
    GRC "...¿Qué?"

# game/chapters/end_1.rpy:1172
translate Spanish chat2_dayweddingend_3e691d1b:

    # GRC "We're getting {i}MARRIED{/i} and you're spouting that nonsense again?"
    GRC "¿Nos vamos a {i}CASAR{/i} y estás diciendo esas tonterías otra vez?"

# game/chapters/end_1.rpy:1178
translate Spanish chat2_dayweddingend_63a2fd47:

    # GRC "What in the Hells am I meant to do with you..."
    GRC "¿Qué demonios se supone que debo hacer contigo...?"

# game/chapters/end_1.rpy:1179
translate Spanish chat2_dayweddingend_e0ba1b6a:

    # GRC "Fine. I'll humor you, even though {i}soul babies{/i} do not exist."
    GRC "Está bien. Te seguiré el juego, aunque los {i}bebés alma{/i} no existen."

# game/chapters/end_1.rpy:1180
translate Spanish chat2_dayweddingend_2fa18d39:

    # GRC "Of all the people in the world, you are the one I would want to..."
    GRC "De todas las personas del mundo, eres con quien yo querría..."

# game/chapters/end_1.rpy:1181
translate Spanish chat2_dayweddingend_5a76dd5d:

    # GRC "I can't believe I'm saying this."
    GRC "No puedo creer que esté diciendo esto."

# game/chapters/end_1.rpy:1182
translate Spanish chat2_dayweddingend_28de0049:

    # GRC "...You're the one I'd want to have... soul babies with."
    GRC "...Eres con quien querría tener... bebés alma."

# game/chapters/end_1.rpy:1183
translate Spanish chat2_dayweddingend_5b036dcf:

    # GRC "There. Are you happy?"
    GRC "Listo. ¿Feliz?"

# game/chapters/end_1.rpy:1189
translate Spanish chat2_dayweddingend_91330efa:

    # GRC "Ugh..."
    GRC "Ugh..."

# game/chapters/end_1.rpy:1200
translate Spanish chat2_dayweddingend_c69a9993:

    # GRC "...Me too, [playerfirstname]."
    GRC "...Yo también, [playerfirstname]."

translate Spanish strings:

    # game/chapters/end_1.rpy:65
    old "1. <Morning, babygirl.>"
    new "1. <Buenos días, babygirl.>"

    # game/chapters/end_1.rpy:67
    old "2. <G'morning, my very favorite Grim Reaper!>"
    new "2. <¡Buenos días, mi Parca favorita!>"

    # game/chapters/end_1.rpy:70
    old "1. <It's the big day~>"
    new "1. <Es el gran día~>"

    # game/chapters/end_1.rpy:76
    old "1. <Time sure flies when you're having fun, huh?>"
    new "1. <El tiempo vuela cuando te estás divirtiendo, ¿eh?>"

    # game/chapters/end_1.rpy:81
    old "1. <Well, I know you can't lie, so why don't you tell me?>"
    new "1. <Bueno, sé que no puedes mentir, así que ¿por qué no me lo dices tú?>"

    # game/chapters/end_1.rpy:85
    old "1. <Do you have fun talking with me?>"
    new "1. <¿Te diviertes hablando conmigo?>"

    # game/chapters/end_1.rpy:89
    old "2. <Do you know what daaaay it is?>"
    new "2. <¿Sabes qué dííía es hoy?>"

    # game/chapters/end_1.rpy:92
    old "1. <I bet you doooo!>"
    new "1. <¡Apuesto a que sííí!>"

    # game/chapters/end_1.rpy:95
    old "1. <It's 'reaping day' ;D>"
    new "1. <Es el 'día de la siega' ;D>"

    # game/chapters/end_1.rpy:101
    old "1. <Well, I'm a very serious person, Casper.>"
    new "1. <Bueno, soy una persona muy seria, Casper.>"

    # game/chapters/end_1.rpy:107
    old "1. <I wasn't <3>"
    new "1. <Yo no <3>"

    # game/chapters/end_1.rpy:118
    old "1. <Do you have fun when we talk?>"
    new "1. <¿Te diviertes cuando hablamos?>"

    # game/chapters/end_1.rpy:123
    old "1. <Casperrrrrr!>"
    new "1. <¡Casperrrrrr!>"

    # game/chapters/end_1.rpy:126
    old "1. <Answer the question, there's no need to be scared!>"
    new "1. <¡Responde la pregunta, no hay necesidad de tener miedo!>"

    # game/chapters/end_1.rpy:132
    old "2. <Don't answer my question with another question!>"
    new "2. <¡No respondas mi pregunta con otra pregunta!>"

    # game/chapters/end_1.rpy:137
    old "1. <You're doing it again?>"
    new "1. <¿Lo estás haciendo otra vez?>"

    # game/chapters/end_1.rpy:145
    old "2. <You're lucky I like you, asshole.>"
    new "2. <Tienes suerte de que me gustes, imbécil.>"

    # game/chapters/end_1.rpy:154
    old "1. <It does indeed.>"
    new "1. <Sí, por supuesto.>"

    # game/chapters/end_1.rpy:157
    old "1. <I already knew you'd say yes, I just wanted you to say it.>"
    new "1. <Ya sabía que dirías que sí, solo quería que lo dijeras.>"

    # game/chapters/end_1.rpy:162
    old "1. <I wouldn't say it was a {i}trick{/i} exactly.>"
    new "1. <No lo llamaría exactamente un {i}truco{/i}.>"

    # game/chapters/end_1.rpy:166
    old "1. <I just like it when you say nice things to me.>"
    new "1. <Solo me gusta cuando me dices cosas lindas.>"

    # game/chapters/end_1.rpy:169
    old "1. <Though I like when you're mean, as well.>"
    new "1. <Aunque también me gusta cuando eres malo conmigo.>"

    # game/chapters/end_1.rpy:173
    old "1. <It's very amusing.>"
    new "1. <Es muy divertido.>"

    # game/chapters/end_1.rpy:180
    old "1. <Because you know me pretty well at this point, I'd say.>"
    new "1. <Porque ya me conoces bastante bien a estas alturas, diría yo.>"

    # game/chapters/end_1.rpy:184
    old "1. <I knoooow it pleases you.>"
    new "1. <Sé queeee eso te gusta.>"

    # game/chapters/end_1.rpy:188
    old "1. <Uh huh!>"
    new "1. <¡Ajá!>"

    # game/chapters/end_1.rpy:191
    old "1. <To get to be witness to my charm firsthand.>"
    new "1. <Para que puedas ser testigo de mi encanto en persona.>"

    # game/chapters/end_1.rpy:194
    old "1. <You loooove it.>"
    new "1. <Te encaaaaanta.>"

    # game/chapters/end_1.rpy:199
    old "1. <See, you can't even say I'm wrong.>"
    new "1. <Ves, ni siquiera puedes decir que me equivoco.>"

    # game/chapters/end_1.rpy:202
    old "1. <TBH with the way you blush, you can't hide your feelings from me <3>"
    new "1. <Honestamente, con lo mucho que te sonrojas, no puedes ocultarme tus sentimientos <3>"

    # game/chapters/end_1.rpy:208
    old "1. <Poor transparent Casper~>"
    new "1. <Pobre Casper transparente~>"

    # game/chapters/end_1.rpy:211
    old "2. <I could think of a few more you could satisfy.>"
    new "2. <Podría pensar en unas cuantas más que podrías satisfacer.>"

    # game/chapters/end_1.rpy:225
    old "1. <I was thinking you could cook me a nice meal.>"
    new "1. <Pensaba que podrías cocinarme una buena comida.>"

    # game/chapters/end_1.rpy:231
    old "1. <Is your mind in the gutter, little reaper?>"
    new "1. <¿Tienes la mente sucia, parquita?>"

    # game/chapters/end_1.rpy:237
    old "1. <It definitely is.>"
    new "1. <Definitivamente sí lo era.>"

    # game/chapters/end_1.rpy:240
    old "1. <You're out here trying to change our age rating...>"
    new "1. <Estás intentando cambiar nuestra clasificación de edad...>"

    # game/chapters/end_1.rpy:246
    old "1. <No, I'm totally pure. Like an angel.>"
    new "1. <No, soy totalmente pur[letra]. Como un ángel.>"

    # game/chapters/end_1.rpy:255
    old "1. <And you wouldn't have it any other way.>"
    new "1. <Y no lo querrías de otra forma.>"

    # game/chapters/end_1.rpy:259
    old "1. <I'm taking that as a '[playerfirstname], you're perfect'.>"
    new "1. <Tomaré eso como un '[playerfirstname], eres la perfección'.>"

    # game/chapters/end_1.rpy:266
    old "2. <You're such a naughty boy.>"
    new "2. <Eres un chico muy travieso.>"

    # game/chapters/end_1.rpy:274
    old "1. <It comes naturally.>"
    new "1. <Me sale natural.>"

    # game/chapters/end_1.rpy:278
    old "2. <I've worked hard to achieve this level of bad.>"
    new "2. <He trabajado duro para alcanzar este nivel de maldad.>"

    # game/chapters/end_1.rpy:283
    old "1. <You know what, you're totally right.>"
    new "1. <¿Sabes qué? Tienes toda la razón.>"

    # game/chapters/end_1.rpy:291
    old "1. <That doesn't sound ominous at all.>"
    new "1. <Eso no suena nada ominoso.>"

    # game/chapters/end_1.rpy:297
    old "1. <You been studying, Grimmy?>"
    new "1. <¿Has estado estudiando, Parquita?>"

    # game/chapters/end_1.rpy:344
    old "1. <Grimmy, let's be serious for a second.>"
    new "1. <Parquita, seamos serios un segundo.>"

    # game/chapters/end_1.rpy:347
    old "1. <It's obvious to us both that you aren't taking my soul.>"
    new "1. <Es obvio para ambos que no vas a tomar mi alma.>"

    # game/chapters/end_1.rpy:350
    old "1. <Just admit to defeat and we can, I dunno...>"
    new "1. <Solo admite tu derrota y podemos, no sé...>"

    # game/chapters/end_1.rpy:353
    old "1. <Plan our wedding or something instead?>"
    new "1. <¿Planear nuestra boda o algo así, en su lugar?>"

    # game/chapters/end_1.rpy:358
    old "1. <Yep.>"
    new "1. <Síp.>"

    # game/chapters/end_1.rpy:363
    old "1. <I told you yesterday. Shotgun wedding!>"
    new "1. <Te lo dije ayer. ¡Boda exprés!>"

    # game/chapters/end_1.rpy:366
    old "1. <Unless you don't want to ever get married?>"
    new "1. <¿A menos que no quieras casarte nunca?>"

    # game/chapters/end_1.rpy:369
    old "1. <That's cool too.>"
    new "1. <También está bien.>"

    # game/chapters/end_1.rpy:376
    old "1. <Well give it some now!>"
    new "1. <¡Pues piénsalo ahora!>"

    # game/chapters/end_1.rpy:381
    old "1. <You're gonna come and take my soul then?>"
    new "1. <¿Vas a venir a tomar mi alma entonces?>"

    # game/chapters/end_1.rpy:389
    old "1. <So you admit defeat.>"
    new "1. <Entonces admites la derrota.>"

    # game/chapters/end_1.rpy:394
    old "1. <You're a sore loser. I win ;)>"
    new "1. <Eres un mal perdedor. Yo gano ;)>"

    # game/chapters/end_1.rpy:397
    old "1. <You lose by default~>"
    new "1. <Pierdes por defecto~>"

    # game/chapters/end_1.rpy:402
    old "1. <That doesn't matter. You still lose.>"
    new "1. <Eso no importa. Igual pierdes.>"

    # game/chapters/end_1.rpy:406
    old "2. <You're such a sweetie, letting me keep my soul.>"
    new "2. <Eres tan dulce, dejándome quedarme con mi alma.>"

    # game/chapters/end_1.rpy:411
    old "1. <Hahaha, is this the next game you wanna play?>"
    new "1. <Jajaja, ¿ese es el siguiente juego que quieres jugar?>"

    # game/chapters/end_1.rpy:415
    old "1. <You're my kinda guy, Grim.>"
    new "1. <Eres de mi tipo, Parca.>"

    # game/chapters/end_1.rpy:420
    old "3. <I always knew I'd be victorious.>"
    new "3. <Siempre supe que sería victorios[letra].>"

    # game/chapters/end_1.rpy:423
    old "1. <I don't often lose, you know.>"
    new "1. <No suelo perder, ¿sabes?>"

    # game/chapters/end_1.rpy:427
    old "1. <Now now Casper, there's no need to be a sore loser.>"
    new "1. <Vamos, Casper, no hay necesidad de ser un mal perdedor.>"

    # game/chapters/end_1.rpy:431
    old "1. <There's nothing wrong with second place :)>"
    new "1. <No tiene nada de malo quedar en segundo lugar :)>"

    # game/chapters/end_1.rpy:435
    old "1. <I'll win all our future bets and games too~>"
    new "1. <También ganaré todas nuestras futuras apuestas y juegos~>"

    # game/chapters/end_1.rpy:439
    old "1. <Yes sir!>"
    new "1. <¡Sí, señor!>"

    # game/chapters/end_1.rpy:441
    old "2. <I wouldn't be so sure, Grimmy~>"
    new "2. <No estaría tan segur[letra], Parquita~>"

    # game/chapters/end_1.rpy:445
    old "1. <I'm serious about the wedding, though.>"
    new "1. <Pero hablo en serio con lo de la boda.>"

    # game/chapters/end_1.rpy:451
    old "1. <That is so incorrect it's almost funny.>"
    new "1. <Eso es tan incorrecto que casi da risa.>"

    # game/chapters/end_1.rpy:454
    old "1. <How can you not see that?>"
    new "1. <¿Cómo puedes no verlo?>"

    # game/chapters/end_1.rpy:459
    old "1. <It does to me.>"
    new "1. <Para mí sí lo hace.>"

    # game/chapters/end_1.rpy:462
    old "1. <When you stare at me with your stupidly pretty eyes, I can tell.>"
    new "1. <Cuando me miras con esos ojos ridículamente bonitos, puedo notarlo.>"

    # game/chapters/end_1.rpy:466
    old "1. <Absolutely husband material.>"
    new "1. <Tienes toda la madera de un buen esposo.>"

    # game/chapters/end_1.rpy:473
    old "1. <I'm just that good at staying alive.>"
    new "1. <Soy muy hábil sobreviviendo.>"

    # game/chapters/end_1.rpy:476
    old "1. <You know what else I'm good at?>"
    new "1. <¿Sabes en qué más soy hábil?>"

    # game/chapters/end_1.rpy:481
    old "1. <Planning weddings.>"
    new "1. <Planear bodas.>"

    # game/chapters/end_1.rpy:484
    old "1. <Ours specifically.>"
    new "1. <La nuestra, específicamente.>"

    # game/chapters/end_1.rpy:489
    old "2. <You are 110 percent husband material.>"
    new "2. <Tienes madera de esposo al ciento diez por ciento.>"

    # game/chapters/end_1.rpy:492
    old "1. <In fact that number is much too small.>"
    new "1. <De hecho, ese número es demasiado bajo.>"

    # game/chapters/end_1.rpy:496
    old "1. <I'm being deadly serious right now.>"
    new "1. <Hablo mortalmente en serio.>"

    # game/chapters/end_1.rpy:499
    old "1. <It definitely is multiple numbers too small.>"
    new "1. <Definitivamente se queda corto por varios números.>"

    # game/chapters/end_1.rpy:503
    old "1. <Well, obviously he'd have to be a grim reaper.>"
    new "1. <Bueno, obviamente tendría que ser una parca.>"

    # game/chapters/end_1.rpy:506
    old "1. <Otherwise it's just a no-go, you know?>"
    new "1. <De lo contrario, simplemente no funcionaría, ¿sabes?>"

    # game/chapters/end_1.rpy:511
    old "1. <Pretty long white hair, deep red eyes, super awkward, really good looking.>"
    new "1. <Cabello blanco largo, ojos rojos intensos, súper torpe, muy guapo.>"

    # game/chapters/end_1.rpy:516
    old "1. <You are perfectly awkward Casper.>"
    new "1. <Eres perfectamente torpe, Casper.>"

    # game/chapters/end_1.rpy:523
    old "1. <You know what else I like?>"
    new "1. <¿Sabes qué más me gusta?>"

    # game/chapters/end_1.rpy:527
    old "1. <Weddings.>"
    new "1. <Las bodas.>"

    # game/chapters/end_1.rpy:532
    old "3. <You're like a dream, how would you not be?>"
    new "3. <Eres como un sueño, ¿cómo no podrías serlo?>"

    # game/chapters/end_1.rpy:535
    old "1. <I bet there are loads of people who would marry you.>"
    new "1. <Apuesto a que hay un montón de personas que se casarían contigo.>"

    # game/chapters/end_1.rpy:538
    old "1. <If I posted some pictures of you online, people would come flocking.>"
    new "1. <Si publicara algunas fotos tuyas en línea, la gente vendría en masa.>"

    # game/chapters/end_1.rpy:543
    old "1. <I can see the comments now.>"
    new "1. <Ya puedo ver los comentarios.>"

    # game/chapters/end_1.rpy:546
    old "1. <'I'd marry him.', 'He's so babygirl.', 'Can I make him whimper~'.>"
    new "1. <'Me casaría con él.', 'Es tan babygirl.', '¿Puedo hacer que gimotee~?'>"

    # game/chapters/end_1.rpy:553
    old "1. <But seriously though, the whole wedding thing...>"
    new "1. <Pero en serio, con respecto a lo de la boda...>"

    # game/chapters/end_1.rpy:562
    old "1. <I'd marry you in a heartbeat.>"
    new "1. <Me casaría contigo sin pensarlo.>"

    # game/chapters/end_1.rpy:602
    old "1. <And miss seeing you so flushed at the \nidea of marriage?>"
    new "1. <¿Y perderme verte tan sonrojado con la idea del matrimonio?>"

    # game/chapters/end_1.rpy:614
    old "1. <Were you thinking an indoor or outdoor reception?>"
    new "1. <¿Pensabas en una recepción interior o al aire libre?>"

    # game/chapters/end_1.rpy:618
    old "1. <You heard me.>"
    new "1. <Me oíste bien.>"

    # game/chapters/end_1.rpy:620
    old "2. <It's a simple question.>"
    new "2. <Es una pregunta simple.>"

    # game/chapters/end_1.rpy:624
    old "1. <Inside or outside?>"
    new "1. <¿Dentro o fuera?>"

    # game/chapters/end_1.rpy:628
    old "1. <Outside it is, then.>"
    new "1. <Entonces será afuera.>"

    # game/chapters/end_1.rpy:635
    old "2. <Theres no need to be embarrassed.>"
    new "2. <No hay razón para avergonzarse.>"

    # game/chapters/end_1.rpy:641
    old "1. <You're the only person I want to do it with.>"
    new "1. <Eres la única persona con la que quiero hacerlo.>"

    # game/chapters/end_1.rpy:645
    old "1. <Did you change your mind about me since yesterday?>"
    new "1. <¿Cambiaste de opinión sobre mí desde ayer?>"

    # game/chapters/end_1.rpy:655
    old "1. <Oh, Casper.>"
    new "1. <Oh, Casper.>"

    # game/chapters/end_1.rpy:657
    old "2. <Oh, my little reaper.>"
    new "2. <Oh, mi parquita.>"

    # game/chapters/end_1.rpy:659
    old "3. <Oh, Grim.>"
    new "3. <Oh, Parca.>"

    # game/chapters/end_1.rpy:662
    old "1. <I've liked you for a long time now.>"
    new "1. <Me gustas desde hace mucho tiempo.>"

    # game/chapters/end_1.rpy:664
    old "2. <I think I'm in love with you.>"
    new "2. <Creo que me he enamorado de ti.>"

    # game/chapters/end_1.rpy:668
    old "1. <I thought that would be obvious, with \nall this talk of weddings.>"
    new "1. <Pensé que sería obvio, con toda esta charla sobre bodas.>"

    # game/chapters/end_1.rpy:683
    old "1. <No, I'm serious.>"
    new "1. <No, hablo en serio.>"

    # game/chapters/end_1.rpy:691
    old "1. <You've been breaking a lot of rules lately \nanyway, right?>"
    new "1. <Has estado rompiendo muchas reglas últimamente de todos modos, ¿no?>"

    # game/chapters/end_1.rpy:697
    old "1. <What if I was?>"
    new "1. <¿Y si fuera así?>"

    # game/chapters/end_1.rpy:705
    old "1. <Sounds perfect. I love flowers.>"
    new "1. <Suena perfecto. Me encantan las flores.>"

    # game/chapters/end_1.rpy:716
    old "1. <You call me Sunshine and want to get married \nin the sunshine!>"
    new "1. <¡Me llamas Solecito y quieres casarte a la luz del sol!>"

    # game/chapters/end_1.rpy:719
    old "1. <You are so pure-hearted.>"
    new "1. <Tienes un corazón tan puro.>"

    # game/chapters/end_1.rpy:723
    old "1. <Okay, maybe not completely pure.>"
    new "1. <Okey, quizá no completamente puro.>"

    # game/chapters/end_1.rpy:726
    old "1. <50 percent pure, at least.>"
    new "1. <Al menos un 50 por ciento puro.>"

    # game/chapters/end_1.rpy:730
    old "1. <Oh? 75 percent?>"
    new "1. <¿Oh? ¿Un 75 por ciento?>"

    # game/chapters/end_1.rpy:735
    old "1. <How forward, Casper.>"
    new "1. <Qué atrevido, Casper.>"

    # game/chapters/end_1.rpy:737
    old "2. <That works for me.>"
    new "2. <Eso me funciona.>"

    # game/chapters/end_1.rpy:740
    old "2. <You're such a sweetheart.>"
    new "2. <Eres tan dulce.>"

    # game/chapters/end_1.rpy:743
    old "1. <It suits you, though.>"
    new "1. <Pero te queda bien.>"

    # game/chapters/end_1.rpy:746
    old "2. <Does it embarass you, Sweetheart?>"
    new "2. <¿Te avergüenza, Cariño?>"

    # game/chapters/end_1.rpy:753
    old "1. <That is my favorite face of yours.>"
    new "1. <Esa es mi cara favorita tuya.>"

    # game/chapters/end_1.rpy:756
    old "1. <Makes me wanna pinch your cute little cheeks.>"
    new "1. <Me dan ganas de pellizcarte esas mejillas tan lindas.>"

    # game/chapters/end_1.rpy:758
    old "2. <There is nothing better than making a grown \nman flushed.>"
    new "2. <No hay nada mejor que hacer sonrojar a un hombre adulto.>"

    # game/chapters/end_1.rpy:761
    old "3. <Just keep sweeping me off my feet, why don't you?>"
    new "3. <Sigue así, a ver si me haces perder el equilibrio.>"

    # game/chapters/end_1.rpy:764
    old "1. <Just keep sweeping me off my chair, why don't you?>"
    new "1. <Sigue así, a ver si me tiras de la silla.>"

    # game/chapters/end_1.rpy:770
    old "1. <I usually do.>"
    new "1. <Normalmente lo hago.>"

    # game/chapters/end_1.rpy:773
    old "1. <So, what would you wear to our hypothetical wedding?>"
    new "1. <Entonces, ¿qué usarías en nuestra boda hipotética?>"

    # game/chapters/end_1.rpy:776
    old "1. <Something fancy?>"
    new "1. <¿Algo elegante?>"

    # game/chapters/end_1.rpy:781
    old "1. <I honestly think that could be ANYTHING you wear.>"
    new "1. <Sinceramente creo que podría ser CUALQUIER cosa que uses.>"

    # game/chapters/end_1.rpy:789
    old "1. <I bet you'd turn up in your usual outfit.>"
    new "1. <Apuesto a que aparecerías con tu atuendo habitual.>"

    # game/chapters/end_1.rpy:795
    old "1. <You will?>"
    new "1. <¿Lo harás?>"

    # game/chapters/end_1.rpy:798
    old "1. <Going to dress up for me, Casper?>"
    new "1. <¿Vas a arreglarte para mí, Casper?>"

    # game/chapters/end_1.rpy:804
    old "1. <I like how you've switched from '{i}I woulds{/i}'.>"
    new "1. <Me gusta cómo pasaste de los '{i}yo haría{/i}'.>"

    # game/chapters/end_1.rpy:807
    old "1. <To '{i}I wills{/i}', by the way.>"
    new "1. <A los '{i}yo haré{/i}', por cierto.>"

    # game/chapters/end_1.rpy:815
    old "1. <And you can't even deny it.>"
    new "1. <Y ni siquiera puedes negarlo.>"

    # game/chapters/end_1.rpy:819
    old "1. <There is no twisting needed.>"
    new "1. <No hace falta retorcer nada.>"

    # game/chapters/end_1.rpy:822
    old "1. <You've said it all yourself.>"
    new "1. <Tú mismo lo has dicho todo.>"

    # game/chapters/end_1.rpy:825
    old "1. <So let me just be plain with you.>"
    new "1. <Así que voy a hablar claro.>"

    # game/chapters/end_1.rpy:829
    old "1. <Do you want to get married?>"
    new "1. <¿Quieres casarte?>"

    # game/chapters/end_1.rpy:832
    old "1. <Just run away and leave everything else behind?>"
    new "1. <¿Simplemente huir y dejar todo atrás?>"

    # game/chapters/end_1.rpy:835
    old "1. <[pet_name]'s coming though, of course.>"
    new "1. <Aunque [pet_name] viene con nosotros, por supuesto.>"

    # game/chapters/end_1.rpy:840
    old "1. <That's not what I'm asking you.>"
    new "1. <No es eso lo que te estoy preguntando.>"

    # game/chapters/end_1.rpy:843
    old "1. <Naughty Casper, don't try weasel your way \nout of my questions.>"
    new "1. <Casper travieso, no intentes escabullirte de mis preguntas.>"

    # game/chapters/end_1.rpy:849
    old "1. <Oh, I know.>"
    new "1. <Oh, lo sé.>"

    # game/chapters/end_1.rpy:852
    old "1. <Give me a 'yes' or a 'no'.>"
    new "1. <Dame un 'sí' o un 'no'.>"

    # game/chapters/end_1.rpy:855
    old "1. <Do you or do you not want to get married?>"
    new "1. <¿Quieres o no quieres casarte?>"

    # game/chapters/end_1.rpy:864
    old "1. <Aaaaaah...>"
    new "1. <Aaaaaah...>"

    # game/chapters/end_1.rpy:866
    old "2. <How are you so... just so cute!?>"
    new "2. <¿Cómo puedes ser tan... tan adorable?>"

    # game/chapters/end_1.rpy:869
    old "1. <You really wanna do it, don't you?>"
    new "1. <De verdad quieres hacerlo, ¿cierto?>"

    # game/chapters/end_1.rpy:872
    old "1. <You want to marry me so bad, it makes you flustered.>"
    new "1. <Quieres casarte conmigo tanto que hasta te sonrojas.>"

    # game/chapters/end_1.rpy:884
    old "1. <Then... I guess we have no choice but to just do it.>"
    new "1. <Entonces... supongo que no nos queda más opción que hacerlo.>"

    # game/chapters/end_1.rpy:887
    old "1. <No need to delay the inevitable, after all.>"
    new "1. <Después de todo, no hay razón para retrasar lo inevitable.>"

    # game/chapters/end_1.rpy:891
    old "1. <Then I'd say we're in agreement.>"
    new "1. <Entonces diría que estamos de acuerdo.>"

    # game/chapters/end_1.rpy:894
    old "1. <A wedding in the sunlight with pretty flowers.>"
    new "1. <Una boda bajo el sol, con flores hermosas.>"

    # game/chapters/end_1.rpy:897
    old "1. <Do you have any other requirements?>"
    new "1. <¿Tienes algún otro requisito?>"

    # game/chapters/end_1.rpy:903
    old "1. <You can have as many pictures as you want.>"
    new "1. <Puedes tener todas las fotos que quieras.>"

    # game/chapters/end_1.rpy:906
    old "1. <I'll wear a really nice dress!>"
    new "1. <¡Usaré un vestido realmente bonito!>"

    # game/chapters/end_1.rpy:908
    old "2. <I'll wear a really nice suit!>"
    new "2. <¡Usaré un traje realmente elegante!>"

    # game/chapters/end_1.rpy:910
    old "3. <I'll wear a really nice outfit!>"
    new "3. <¡Usaré un atuendo realmente bonito!>"

    # game/chapters/end_1.rpy:916
    old "1. <Remember when we talked about that Spring \nphotoshoot the other day?>"
    new "1. <¿Recuerdas cuando hablamos de esa sesión de fotos primaveral el otro día?>"

    # game/chapters/end_1.rpy:918
    old "1. <We could do that at the wedding?>"
    new "1. <¿Podríamos hacerlo en la boda?>"

    # game/chapters/end_1.rpy:922
    old "1. <It would certainly make it even MORE memorable.>"
    new "1. <Sin duda la haría aún MÁS memorable.>"

    # game/chapters/end_1.rpy:927
    old "1. <Sounds perfect.>"
    new "1. <Suena perfecto.>"

    # game/chapters/end_1.rpy:934
    old "1. <We'll get some together as well, obviously.>"
    new "1. <Y obviamente, también tomaremos algunas juntos.>"

    # game/chapters/end_1.rpy:937
    old "1. <I think we'd look good together in photos.>"
    new "1. <Creo que nos veríamos bien juntos en las fotos.>"

    # game/chapters/end_1.rpy:943
    old "1. <As if you aren't!>"
    new "1. <¡Como si a ti no te gustara!>"

    # game/chapters/end_1.rpy:946
    old "1. <I'm looking forward to it, Casper.>"
    new "1. <Lo espero con ansias, Casper.>"

    # game/chapters/end_1.rpy:953
    old "1. <That just gives me time to plan it!>"
    new "1. <¡Eso solo me da tiempo para planearlo!>"

    # game/chapters/end_1.rpy:957
    old "1. <Well, a pretty man just told me I don't \nneed to die today.>"
    new "1. <Bueno, un hombre guapo acaba de decirme que no tengo que morir hoy.>"

    # game/chapters/end_1.rpy:959
    old "2. <Well you see, the man 'fated' to take my \nsoul has fallen for me.>"
    new "2. <Verás, el hombre 'destinado' a tomar mi alma se ha enamorado de mí.>"

    # game/chapters/end_1.rpy:962
    old "1. <And shy as he is, wants to get married \nto me instead.>"
    new "1. <Y, tímido como es, quiere casarse conmigo en lugar de eso.>"

    # game/chapters/end_1.rpy:965
    old "1. <He couldn't resist my 'killer' personality.>"
    new "1. <No pudo resistirse a mi personalidad 'letal'.>"

    # game/chapters/end_1.rpy:969
    old "1. <I love when you can't lie.>"
    new "1. <Me encanta cuando no puedes mentir.>"

    # game/chapters/end_1.rpy:975
    old "2. <He loved my good looks so much he just \ncouldn't resist.>"
    new "2. <Le gustó tanto mi buen aspecto que simplemente no pudo resistirse.>"

    # game/chapters/end_1.rpy:979
    old "1. <Can it not be both?>"
    new "1. <¿No pueden ser ambas cosas?>"

    # game/chapters/end_1.rpy:985
    old "1. <I also like your silly personality too.>"
    new "1. <También me gusta tu personalidad tonta.>"

    # game/chapters/end_1.rpy:992
    old "1. <The exact kinda odd {i}you{/i} wanna marry~>"
    new "1. <El tipo de rareza exacta con la que {i}tú{/i} quieres casarte~>"

    # game/chapters/end_1.rpy:996
    old "1. <You bet it did.>"
    new "1. <Puedes apostar que sí.>"

    # game/chapters/end_1.rpy:1010
    old "1. <Perfect.>"
    new "1. <Perfecto.>"

    # game/chapters/end_1.rpy:1013
    old "1. <We can chat about all this in person.>"
    new "1. <Podemos hablar de todo esto en persona.>"

    # game/chapters/end_1.rpy:1022
    old "1. <See you soon, future husband of mine.>"
    new "1. <Nos vemos pronto, mi futuro esposo.>"

    # game/chapters/end_1.rpy:1057
    old "1. <Hey handsome. Come here often?>"
    new "1. <Hola, guapo. ¿Vienes mucho por aquí?>"

    # game/chapters/end_1.rpy:1060
    old "2. <Casper. You look...>"
    new "2. <Casper. Te ves...>"

    # game/chapters/end_1.rpy:1063
    old "1. <You look to die for.>"
    new "1. <Estás de muerte.>"

    # game/chapters/end_1.rpy:1069
    old "1. <I'm pretty sure you told me you were devilishly handsome back then yourself.>"
    new "1. <Estoy bastante segur[letra] de que tú mismo me dijiste en aquel entonces que eras endiabladamente guapo.>"

    # game/chapters/end_1.rpy:1073
    old "1. <You are a troublsome thing.>"
    new "1. <Eres todo un problema.>"

    # game/chapters/end_1.rpy:1078
    old "1. <You do look really good though.>"
    new "1. <Aunque sí te ves muy bien.>"

    # game/chapters/end_1.rpy:1081
    old "1. <Like {i}really{/i} good.>"
    new "1. <Pero {i}muy{/i} bien.>"

    # game/chapters/end_1.rpy:1084
    old "1. <You even styled your hair differently.>"
    new "1. <Hasta te peinaste diferente.>"

    # game/chapters/end_1.rpy:1096
    old "2. <It's just me.>"
    new "2. <Solo soy yo.>"

    # game/chapters/end_1.rpy:1107
    old "1. <You could be standing there in a trash bag and you'd still be doing it right.>"
    new "1. <Podrías estar ahí con una bolsa de basura y aun así lo estarías haciendo bien.>"

    # game/chapters/end_1.rpy:1111
    old "1. <You're welcome, my love.>"
    new "1. <De nada, mi amor.>"

    # game/chapters/end_1.rpy:1113
    old "2. <You're welcome, Grim.>"
    new "2. <De nada, Parca.>"

    # game/chapters/end_1.rpy:1117
    old "1. <You... picked sunflowers.>"
    new "1. <Tú... elegiste girasoles.>"

    # game/chapters/end_1.rpy:1127
    old "1. <{i}Take his hand right away.{/i}>"
    new "1. <{i}Tomar su mano de inmediato.{/i}>"

    # game/chapters/end_1.rpy:1129
    old "2. <{i}Smirk and take his hand.{/i}>"
    new "2. <{i}Sonreír con picardía y tomar su mano.{/i}>"

    # game/chapters/end_1.rpy:1131
    old "3. <{i}Wait a good few seconds, wiggle \nyour eyebrows, then take his hand.{/i}>"
    new "3. <{i}Esperar unos segundos, mover las cejas y luego tomar su mano.{/i}>"

    # game/chapters/end_1.rpy:1138
    old "2. <I thought you were never gonna ask.>"
    new "2. <Pensé que nunca me lo pedirías.>"

    # game/chapters/end_1.rpy:1144
    old "1. <There is nothing better in life than bullying you.>"
    new "1. <No hay nada mejor en la vida que molestarte.>"

    # game/chapters/end_1.rpy:1147
    old "1. <Especially at our wedding.>"
    new "1. <Sobre todo en nuestra boda.>"

    # game/chapters/end_1.rpy:1150
    old "3. <We're going to be such a troublsome \ncouple.>"
    new "3. <Vamos a ser una pareja tan problemática.>"

    # game/chapters/end_1.rpy:1154
    old "1. <{i}Trying{/i}.>"
    new "1. <{i}Intentándolo{/i}.>"

    # game/chapters/end_1.rpy:1164
    old "1. <...I love you too, Casper.>"
    new "1. <...Yo también te amo, Casper.>"

    # game/chapters/end_1.rpy:1169
    old "1. <Does this mean the soul babies are a go?>"
    new "1. <¿Esto significa que los bebés alma tienen luz verde?>"

    # game/chapters/end_1.rpy:1186
    old "1. <I absolutely am.>"
    new "1. <Totalmente.>"

    # game/chapters/end_1.rpy:1192
    old "1. <Looking forward to spending the rest of my life with you.>"
    new "1. <Estoy deseando pasar el resto de mi vida contigo.>"

