# TODO: Translation updated at 2026-10-15 18:36

# game/chapters/badend_roomexplore.rpy:215
translate Spanish bed_hubbadend_72d9e0e5:

    # "You're feeling a little... sluggish today."
    "Hoy te sientes un poco... aletargad[letra]."

# game/chapters/badend_roomexplore.rpy:216
translate Spanish bed_hubbadend_65dcf9e3:

    # "Even sitting on the edge of your bed, you can't be bothered even thinking of standing to do anything else."
    "Aun sentad[letra] al borde de la cama, te da tanta pereza que ni siquiera quieres pensar en levantarte para hacer otra cosa."

# game/chapters/badend_roomexplore.rpy:217
translate Spanish bed_hubbadend_89161ccd:

    # "Strange."
    "Extraño."

# game/chapters/badend_roomexplore.rpy:223
translate Spanish door_hubbadend_3d403dd1:

    # "The hallway beyond is silent."
    "El pasillo de afuera está en silencio."

# game/chapters/badend_roomexplore.rpy:224
translate Spanish door_hubbadend_a043409e:

    # "You wonder what's happened with your neighbors, but you're too tired to really care..."
    "Te preguntas qué habrá pasado con tus vecinos, pero sientes demasiado cansancio como para preocuparte realmente..."

# game/chapters/badend_roomexplore.rpy:237
translate Spanish snake_hubbadend_688f43ae:

    # "[pet_name] has seemed a little down all day."
    "[pet_name] ha estado un poco triste todo el día."

# game/chapters/badend_roomexplore.rpy:238
translate Spanish snake_hubbadend_a1404f7e:

    # "You've been worrying that [pet_she] is getting sick again, so you've been wishing as hard as you can."
    "Te preocupa que [pet_she!t] esté enfermándose otra vez, así que has estado deseando con todas tus fuerzas que no sea así."

# game/chapters/badend_roomexplore.rpy:239
translate Spanish snake_hubbadend_f25bd1bc:

    # "But, despite what Casper said about your so-called 'abilities', nothing has changed."
    "Pero, a pesar de lo que dijo Casper sobre tus supuestas 'habilidades', nada ha cambiado."

# game/chapters/badend_roomexplore.rpy:245
translate Spanish snake_hubbadend_19531c55:

    # "You concentrate, then concentrate some more..."
    "Te concentras, y luego te concentras un poco más..."

# game/chapters/badend_roomexplore.rpy:246
translate Spanish snake_hubbadend_0b0d98ea:

    # "But you don't notice any changes."
    "Pero no notas ningún cambio."

# game/chapters/badend_roomexplore.rpy:247
translate Spanish snake_hubbadend_5adf06fd:

    # "Maybe you just need to keep trying?"
    "¿Quizás solo necesites seguir intentándolo?"

# game/chapters/badend_roomexplore.rpy:251
translate Spanish snake_hubbadend_fe24f979:

    # "You decide to leave [pet_name] alone for now."
    "Decides dejar a [pet_name] en paz por ahora."

# game/chapters/badend_roomexplore.rpy:265
translate Spanish bingus_hubbadend_688f43ae:

    # "[pet_name] has seemed a little down all day."
    "[pet_name] ha estado un poco triste todo el día."

# game/chapters/badend_roomexplore.rpy:266
translate Spanish bingus_hubbadend_a1404f7e:

    # "You've been worrying that [pet_she] is getting sick again, so you've been wishing as hard as you can."
    "Te preocupa que [pet_she!t] esté enfermándose otra vez, así que has estado deseando con todas tus fuerzas que no sea así."

# game/chapters/badend_roomexplore.rpy:267
translate Spanish bingus_hubbadend_f25bd1bc:

    # "But, despite what Casper said about your so-called 'abilities', nothing has changed."
    "Pero, a pesar de lo que dijo Casper sobre tus supuestas 'habilidades', nada ha cambiado."

# game/chapters/badend_roomexplore.rpy:273
translate Spanish bingus_hubbadend_19531c55:

    # "You concentrate, then concentrate some more..."
    "Te concentras, y luego te concentras un poco más..."

# game/chapters/badend_roomexplore.rpy:274
translate Spanish bingus_hubbadend_0b0d98ea:

    # "But you don't notice any changes."
    "Pero no notas ningún cambio."

# game/chapters/badend_roomexplore.rpy:275
translate Spanish bingus_hubbadend_5adf06fd:

    # "Maybe you just need to keep trying?"
    "¿Quizás solo necesites seguir intentándolo?"

# game/chapters/badend_roomexplore.rpy:279
translate Spanish bingus_hubbadend_fe24f979:

    # "You decide to leave [pet_name] alone for now."
    "Decides dejar a [pet_name] en paz por ahora."

# game/chapters/badend_roomexplore.rpy:293
translate Spanish bunny_hubbadend_688f43ae:

    # "[pet_name] has seemed a little down all day."
    "[pet_name] ha estado un poco triste todo el día."

# game/chapters/badend_roomexplore.rpy:294
translate Spanish bunny_hubbadend_a1404f7e:

    # "You've been worrying that [pet_she] is getting sick again, so you've been wishing as hard as you can."
    "Te preocupa que [pet_she!t] esté enfermándose otra vez, así que has estado deseando con todas tus fuerzas que no sea así."

# game/chapters/badend_roomexplore.rpy:295
translate Spanish bunny_hubbadend_f25bd1bc:

    # "But, despite what Casper said about your so-called 'abilities', nothing has changed."
    "Pero, a pesar de lo que dijo Casper sobre tus supuestas 'habilidades', nada ha cambiado."

# game/chapters/badend_roomexplore.rpy:301
translate Spanish bunny_hubbadend_19531c55:

    # "You concentrate, then concentrate some more..."
    "Te concentras, y luego te concentras un poco más..."

# game/chapters/badend_roomexplore.rpy:302
translate Spanish bunny_hubbadend_0b0d98ea:

    # "But you don't notice any changes."
    "Pero no notas ningún cambio."

# game/chapters/badend_roomexplore.rpy:303
translate Spanish bunny_hubbadend_5adf06fd:

    # "Maybe you just need to keep trying?"
    "¿Quizás solo necesites seguir intentándolo?"

# game/chapters/badend_roomexplore.rpy:307
translate Spanish bunny_hubbadend_fe24f979:

    # "You decide to leave [pet_name] alone for now."
    "Decides dejar a [pet_name] en paz por ahora."

# game/chapters/badend_roomexplore.rpy:321
translate Spanish cat_hubbadend_688f43ae:

    # "[pet_name] has seemed a little down all day."
    "[pet_name] ha estado un poco triste todo el día."

# game/chapters/badend_roomexplore.rpy:322
translate Spanish cat_hubbadend_a1404f7e:

    # "You've been worrying that [pet_she] is getting sick again, so you've been wishing as hard as you can."
    "Te preocupa que [pet_she!t] esté enfermándose otra vez, así que has estado deseando con todas tus fuerzas que no sea así."

# game/chapters/badend_roomexplore.rpy:323
translate Spanish cat_hubbadend_f25bd1bc:

    # "But, despite what Casper said about your so-called 'abilities', nothing has changed."
    "Pero, a pesar de lo que dijo Casper sobre tus supuestas 'habilidades', nada ha cambiado."

# game/chapters/badend_roomexplore.rpy:329
translate Spanish cat_hubbadend_19531c55:

    # "You concentrate, then concentrate some more..."
    "Te concentras, y luego te concentras un poco más..."

# game/chapters/badend_roomexplore.rpy:330
translate Spanish cat_hubbadend_0b0d98ea:

    # "But you don't notice any changes."
    "Pero no notas ningún cambio."

# game/chapters/badend_roomexplore.rpy:331
translate Spanish cat_hubbadend_5adf06fd:

    # "Maybe you just need to keep trying?"
    "¿Quizás solo necesites seguir intentándolo?"

# game/chapters/badend_roomexplore.rpy:335
translate Spanish cat_hubbadend_fe24f979:

    # "You decide to leave [pet_name] alone for now."
    "Decides dejar a [pet_name] en paz por ahora."

# game/chapters/badend_roomexplore.rpy:349
translate Spanish dog_hubbadend_688f43ae:

    # "[pet_name] has seemed a little down all day."
    "[pet_name] ha estado un poco triste todo el día."

# game/chapters/badend_roomexplore.rpy:350
translate Spanish dog_hubbadend_a1404f7e:

    # "You've been worrying that [pet_she] is getting sick again, so you've been wishing as hard as you can."
    "Te preocupa que [pet_she!t] esté enfermándose otra vez, así que has estado deseando con todas tus fuerzas que no sea así."

# game/chapters/badend_roomexplore.rpy:351
translate Spanish dog_hubbadend_f25bd1bc:

    # "But, despite what Casper said about your so-called 'abilities', nothing has changed."
    "Pero, a pesar de lo que dijo Casper sobre tus supuestas 'habilidades', nada ha cambiado."

# game/chapters/badend_roomexplore.rpy:357
translate Spanish dog_hubbadend_19531c55:

    # "You concentrate, then concentrate some more..."
    "Te concentras, y luego te concentras un poco más..."

# game/chapters/badend_roomexplore.rpy:358
translate Spanish dog_hubbadend_0b0d98ea:

    # "But you don't notice any changes."
    "Pero no notas ningún cambio."

# game/chapters/badend_roomexplore.rpy:359
translate Spanish dog_hubbadend_5adf06fd:

    # "Maybe you just need to keep trying?"
    "¿Quizás solo necesites seguir intentándolo?"

# game/chapters/badend_roomexplore.rpy:363
translate Spanish dog_hubbadend_fe24f979:

    # "You decide to leave [pet_name] alone for now."
    "Decides dejar a [pet_name] en paz por ahora."

# game/chapters/badend_roomexplore.rpy:377
translate Spanish hamster_hubbadend_688f43ae:

    # "[pet_name] has seemed a little down all day."
    "[pet_name] ha estado un poco triste todo el día."

# game/chapters/badend_roomexplore.rpy:378
translate Spanish hamster_hubbadend_a1404f7e:

    # "You've been worrying that [pet_she] is getting sick again, so you've been wishing as hard as you can."
    "Te preocupa que [pet_she!t] esté enfermándose otra vez, así que has estado deseando con todas tus fuerzas que no sea así."

# game/chapters/badend_roomexplore.rpy:379
translate Spanish hamster_hubbadend_f25bd1bc:

    # "But, despite what Casper said about your so-called 'abilities', nothing has changed."
    "Pero, a pesar de lo que dijo Casper sobre tus supuestas 'habilidades', nada ha cambiado."

# game/chapters/badend_roomexplore.rpy:385
translate Spanish hamster_hubbadend_19531c55:

    # "You concentrate, then concentrate some more..."
    "Te concentras, y luego te concentras un poco más..."

# game/chapters/badend_roomexplore.rpy:386
translate Spanish hamster_hubbadend_0b0d98ea:

    # "But you don't notice any changes."
    "Pero no notas ningún cambio."

# game/chapters/badend_roomexplore.rpy:387
translate Spanish hamster_hubbadend_5adf06fd:

    # "Maybe you just need to keep trying?"
    "¿Quizás solo necesites seguir intentándolo?"

# game/chapters/badend_roomexplore.rpy:391
translate Spanish hamster_hubbadend_fe24f979:

    # "You decide to leave [pet_name] alone for now."
    "Decides dejar a [pet_name] en paz por ahora."

# game/chapters/badend_roomexplore.rpy:399
translate Spanish plant_hubbadend_0e3d137f:

    # "You go to water your plant, but..."
    "Vas a regar tu planta, pero..."

# game/chapters/badend_roomexplore.rpy:404
translate Spanish plant_hubbadend_26e21a33:

    # "It's... shrunk?"
    "¿Se ha... hecho más pequeña?"

# game/chapters/badend_roomexplore.rpy:405
translate Spanish plant_hubbadend_a3cd780e:

    # "It's withered up into barely a sprout, and is completely dry to boot."
    "Se ha marchitado tanto que apenas queda un brote, y encima está completamente seca."

# game/chapters/badend_roomexplore.rpy:406
translate Spanish plant_hubbadend_2b58e62e:

    # "How strange and disappointing."
    "Qué extraño y decepcionante."

translate Spanish strings:

    # game/chapters/badend_roomexplore.rpy:243
    old "1. Try to heal [pet_name] again."
    new "1. Intentar sanar a [pet_name] otra vez."

    # game/chapters/badend_roomexplore.rpy:249
    old "2. Leave [pet_name] to rest."
    new "2. Dejar que [pet_name] descanse."

    # game/chapters/badend_roomexplore.rpy:440
    old "{i}You flip to the end of your favorite childhood book. Resting against the page is a quote that's stuck with you.{/i}"
    new "{i}Pasas a la última página de tu libro favorito de la infancia. Allí encuentras una cita que se te quedó grabada.{/i}"

