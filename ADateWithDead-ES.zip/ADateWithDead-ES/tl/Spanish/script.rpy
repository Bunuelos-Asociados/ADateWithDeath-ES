# game/script.rpy:569
translate Spanish start_84a025ce:
     
    $playername = "Alma#8129"
    $player_bio_default_text = "Haz clic aquí para introducir la biografía de tu personaje. ¡Puedes actualizarla cuando quieras!"

    # center_text "You've been here before, haven't you?"
    center_text "Ya has estado aquí antes, ¿no es así?"

# game/script.rpy:570
translate Spanish start_a68fbade:

    # center_text "You've been that perfectly ordinary person, with a perfectly ordinary job and a perfectly ordinary apartment."
    center_text "Has sido esa persona perfectamente común, con un trabajo perfectamente común y un apartamento perfectamente común."

# game/script.rpy:571
translate Spanish start_b44a86b7:

    # center_text "You met someone who called himself the Grim Reaper, and you fell in love..."
    center_text "Conociste a alguien que se hacía llamar la Parca, y te enamoraste…"

# game/script.rpy:572
translate Spanish start_602e1841:

    # center_text "But is that the end of the story?"
    center_text "Pero ¿ese es el final de la historia?"

# game/script.rpy:573
translate Spanish start_74b0946e:

    # center_text "To you, it feels like there's something... more left."
    center_text "Para ti, se siente como si quedara... algo más."

# game/script.rpy:574
translate Spanish start_63279fc0:

    # center_text "Begin at the start of the original game, or jump to the end of day 5 and begin Beyond the Bet?"
    center_text "¿Quieres comenzar desde el inicio del juego original o saltar al final del día 5 y empezar Beyond the Bet?"

# game/script.rpy:579
translate Spanish start_8024c3a9:

    # center_text "You shake your head... you must just be misremembering a dream."
    center_text "Sacudes la cabeza... debes estar recordando mal un sueño."

# game/script.rpy:599
translate Spanish start_6577b4f9:

    # center_text "You've always been a perfectly ordinary person."
    center_text "Siempre has sido una persona perfectamente común."

# game/script.rpy:602
translate Spanish start_e89f2caf:

    # center_text "An ordinary person with an ordinary job and an ordinary apartment."
    center_text "Una persona común con un trabajo común y un apartamento común."

# game/script.rpy:603
translate Spanish start_07a8d23d:

    # center_text "That is, putting aside some of the strange occurrences that happen around you."
    center_text "Es decir, dejando de lado algunas de las extrañas ocurrencias que suceden a tu alrededor."

# game/script.rpy:604
translate Spanish start_05bc066c:

    # center_text "Who hasn't been involved in a train crash, a house fire, a hurricane and a parachute-related skydiving issue all in the span of a few months, after all?"
    center_text "¿Quién no se ha visto envuelto en un accidente de tren, un incendio en casa, un huracán y un percance con el paracaídas durante un salto, todo en unos pocos meses, después de todo?"

# game/script.rpy:605
translate Spanish start_0b9bd1f2:

    # center_text "You've always been this way. You've found yourself in many unlucky situations, but come out unscathed every time."
    center_text "Siempre has sido así. Te has encontrado en muchas situaciones desafortunadas, pero siempre has salido sin un rasguño."

# game/script.rpy:606
translate Spanish start_792d7811:

    # center_text "Friends and family have always called you lucky—but at this point, you don't even bat an eyelash at these occurrences."
    center_text "Tus amigos y familiares siempre te han considerado una persona afortunada, pero a estas alturas ya ni siquiera te inmutas ante estas cosas."

# game/script.rpy:607
translate Spanish start_fae24f8c:

    # center_text "A piano falls from a six story building above you? You simply step to the side."
    center_text "¿Un piano cae desde un edificio de seis pisos justo encima de ti? Simplemente das un paso al costado."

# game/script.rpy:608
translate Spanish start_d52c867f:

    # center_text "You trip on your shoelace and fall down a flight of stairs? Not even a scratch."
    center_text "¿Tropiezas con tus cordones y caes por unas escaleras? Ni un rasguño."

# game/script.rpy:609
translate Spanish start_bd1f1c14:

    # center_text "It's on one of these unusually ordinary days when you arrive home, and look into your mirror."
    center_text "Es en uno de esos días inusualmente ordinarios cuando llegas a casa y miras en tu espejo."

# game/script.rpy:610
translate Spanish start_b5b79c6c:

    # center_text "What do you see?"
    center_text "¿Qué ves?"

translate Spanish strings:

    # game/script.rpy:67
    old "Soul#8129"
    new "Alma#8129"

    # game/script.rpy:146
    old "Grim Reaper"
    new "La Parca"

    # game/script.rpy:147
    old "Testing, testing"
    new "Probando, probando"

    # game/script.rpy:179
    old "Nobody"
    new "Nadie"

    # game/script.rpy:578
    old "1. Start from the beginning"
    new "1. Empezar desde el principio"

    # game/script.rpy:581
    old "2. Jump to Beyond the Bet"
    new "2. Saltar a Beyond the Bet"

    # game/script.rpy:583
    old "Grim"
    new "Parca"

    # game/script.rpy:680
    old "Male"
    new "{size=30}Masculino{/size}"

    # game/script.rpy:689
    old "Female"
    new "{size=30}Femenino{/size}"
