# TODO: Translation updated at 2026-10-15 18:36

translate Spanish strings:

    # game/books.rpy:4
    old "{i}What's your favourite colour?{/i}"
    new "{i}¿Cuál es tu color favorito?{/i}"

    # game/books.rpy:21
    old "What's your favourite colour?"
    new "¿Cuál es tu color favorito?"

    # game/books.rpy:22
    old "Mine is white, the beginning \nThe light you see as you open your eyes \nAs a new day dawns once more with endless possibilities \nAnd the universe greets you with it's arms open wide and loving "
    new "El mío es el blanco, el inicio \nLa luz que ves al abrir los ojos \nCuando un nuevo día amanece de nuevo con infinitas posibilidades \nY el universo te recibe con los brazos abiertos y amorosos "

    # game/books.rpy:23
    old "What is your favourite colour?"
    new "¿Cuál es tu color favorito?"

    # game/books.rpy:24
    old "Mine is grey, the journey \nThe spectrum between two and stretched across horizons \nStorm clouds covering the sky in a familiar warning \nHair slowly collecting it until there's no other colour left"
    new "El mío es el gris, el viaje \nEl espectro entre dos y extendido a través de los horizontes \nNubes de tormenta cubriendo el cielo en una advertencia familiar \nEl cabello recogiéndolo poco a poco hasta que no queda otro color"

    # game/books.rpy:25
    old "Mine is black, the end \nThe final moments of night at the end of a day \nThe new moon, a symbol of opposites in a circle \nAs you close your eyes and all you see is darkness stretching beyond time"
    new "El mío es el negro, el final \nLos últimos momentos de la noche al terminar el día \nLa luna nueva, un símbolo de opuestos en un círculo \nCuando cierras los ojos y todo lo que ves es oscuridad extendiéndose más allá del tiempo"

    # game/books.rpy:27
    old "Mine is a spectrum, everything that once was and in-between and will be \nA story of time and of life, living and death \nThe beginning, the journey, the end in constant cycle?"
    new "El mío es un espectro, todo lo que alguna vez fue, lo que está en medio y lo que será \nUna historia del tiempo y de la vida, de vivir y de la muerte \n¿El inicio, el viaje, el final en un ciclo constante?"

    # game/books.rpy:29
    old "- Shilou M. McDonagh-Gorham"
    new "- Shilou M. McDonagh-Gorham"

    # game/books.rpy:39
    old "{i}In Darkest Daydream{/i}"
    new "{i}En el más oscuro ensueño{/i}"

    # game/books.rpy:56
    old "Nostalgia is such a fickle thing. It entraps the heart and mind, lulling both into a sense of bittersweet, wistful longing. Then, just as soon as it comes, it is gone; a wisp in the wind, to return whenever fate may deem fit. Sometimes, it can take on the added effect of remembrance. Whether clear or vague, it leaves the mind curious, grasping at something it can or cannot recollect. Deja vu, as the phenomenon is termed first by Emile Boirac. A feeling so simple yet so mysterious. Yet, too, it is as memorable as ‘once upon a time.’ "
    new "La nostalgia es una cosa tan voluble. Atrapa el corazón y la mente, arrullándolos en una sensación de anhelo agridulce y melancólico. Y luego, tan pronto como llega, se va; una brizna en el viento, que vuelve cuando el destino lo considere. A veces adopta la forma de un recuerdo. Claro o vago, deja la mente curiosa, aferrándose a algo que puede —o no— rememorar. Déjà vu, como denominó primero Emile Boirac al fenómeno. Un sentimiento tan simple y, sin embargo, tan misterioso. Y, a la vez, tan memorable como un ‘érase una vez’."

    # game/books.rpy:57
    old "Once upon a time, a time before technological advance and modernity, there was a rather interesting person. Their quirks, their whimsy, their charm, made them unique among their peers, their fellow man. A one-of-a-kind soul. Never again would it be replicated...at least, that is how things usually are. Fate is not so linear, so firm, as one might think. It is malleable, non-complacent - the smallest occurrence or entrance can change it. "
    new "Érase una vez, en una época anterior al avance tecnológico y a la modernidad, existía una persona bastante interesante. Sus rarezas, su capricho, su encanto hacían de esta persona alguien único entre sus iguales, entre los demás. Un alma irrepetible. Nunca más sería duplicada... al menos, así suele ocurrir. El destino no es tan lineal ni tan rígido como se podría creer. Es maleable, nada complaciente: la más pequeña ocurrencia o llegada puede alterarlo."

    # game/books.rpy:58
    old "A grand party was to be held at an estate near this individual; as were all about their settlement, they were invited to attend. Though their choice of costume and fashion kept them within social decency, it was not without the individual’s own special touch. The color combination, the silhouette, the very air about them was no short of spellbinding. Yet, no equally special attention was paid to them. Well, at least not entirely. There was one who, too, stood out among the rest. This person, cloaked in black, came upon this little light and asked for their company, their dance. "
    new "Se celebraría una gran fiesta en una hacienda cercana a esta persona; como a todos en su asentamiento, les invitaron a asistir. Aunque su elección de vestuario y moda respetaba la decencia social, no carecía del toque especial del individuo. La combinación de colores, la silueta, el aire que desprendía resultaban hipnóticos. Aun así, nadie les prestó una atención igual de especial. Bueno, al menos no del todo. Hubo alguien que también destacó entre los demás. Esta persona, envuelta en negro, se acercó a esa pequeña luz y solicitó su compañía, su baile."

    # game/books.rpy:59
    old "Dance they did - around and around, dip and bow. The couple stepped and swayed until they could no more. And even then, chatter and laughter filled the space between them. A banter here, a quip there; a lovely giggle from the special one, a handsome smile from he who was darkly clad. Such a kinship could not come to an end with the coming dawn. The two found each other, again and again and again, without fail. "
    new "Bailaron —una y otra vez—, giro tras giro, reverencia tras reverencia. La pareja avanzó y se meció hasta no poder más. Y aun así, el parloteo y la risa inundaban el espacio entre ellos. Un intercambio aquí, una ocurrencia allá; una risita encantadora de la persona especial, una sonrisa atractiva del que vestía de oscuro. Tal afinidad no podía extinguirse con la llegada del alba. Los dos se encontraron una y otra vez, sin falta."

    # game/books.rpy:60
    old "A special bond between two individuals such as that could not go to waste. As most stories go, the companions soon formed a relationship that passed the barrier of friendship. This dark figure and sparkling light, both elated that the other reciprocated their affection. Ah, but there was a catch: a secret the man did hold. Never had he uttered it to another soul - not until then. He feared rejection, revulsion, terror from his darling love. Like the sun that brought about life for all on earth, the kiss bestowed by his lover warmed him, burned any doubt that remained in his heart."
    new "Un lazo especial entre dos individuos así no podía desperdiciarse. Como en muchas historias, los compañeros pronto formaron una relación que trascendió la barrera de la amistad. Esta figura oscura y esa luz radiante, ambos extasiados porque el otro correspondía su afecto. Ah, pero había una trampa: un secreto que él guardaba. Nunca se lo había confesado a otra alma —no hasta entonces. Temía el rechazo, la repulsión, el pavor de su amado. Como el sol que da vida en la tierra, el beso de su amante lo calentó y consumió cualquier duda que persistiera en su corazón."

    # game/books.rpy:61
    old "  All good things must come to and end, eventually. A soul, no matter how special, will one day flicker and die. Their fleshy husk will wither and decay, slowly, until one day it breathes its last. This interesting person, who bound the man in love for eternity, one day came to meet their own maker. No amount of begging, bargaining, screams and tears, could prevent it. Like all mortals, his love’s soul awaited their own afterlife. "
    new "  Todas las cosas buenas deben llegar a su fin, eventualmente. Un alma, por especial que sea, un día vacilará y morirá. Su carcasa carnosa se marchitará y pudrirá, despacio, hasta que un día exhale su último aliento. Esta persona interesante, que ató al hombre en amor eterno, un día fue a encontrarse con su Creador. Ninguna súplica, ninguna negociación, grito o lágrima pudo evitarlo. Como todos los mortales, el alma de su amor aguardaba su propio más allá."

    # game/books.rpy:62
    old "But what if... What if, dear reader, there was one trick up his sleeve? A plot - a loophole, if you will. No one can stop the coming of Death, no one can. Though, perhaps, one can delay Death’s collection of a soul. If they were to hide it away, per se. If given such an opportunity to prolong your time with someone so special, would you? "
    new "Pero ¿y si...? ¿Y si, querido lector, él tuviera un as bajo la manga? Un plan —un resquicio, si quieres—. Nadie puede detener la llegada de la Muerte, nadie. Aunque, quizá, uno pueda demorar la recolección de un alma por parte de la Muerte. Si pudiera esconderla, por así decirlo. Si se te brindara la oportunidad de prolongar tu tiempo con alguien tan especial, ¿lo harías?"

    # game/books.rpy:63
    old " Would you persist, even with the catch: your loved one would not remember their past life, and thus you. Your time spent together, the affection and care and passion you shared? Gone. Perhaps, if you are lucky, there are fleeting moments of recollection - that ‘deja vu’ aforementioned. A sense they’ve done something before. Read a book or poem, but they just can’t remember when; gazed upon glorious scenery or beheld spectacular, towering architecture and felt it familiar to the eye. Do you think you could make them remember?"
    new " ¿Persistirías, incluso con la condición de que tu ser querido no recordaría su vida pasada y, por tanto, tampoco a ti? ¿Todo el tiempo compartido, el afecto, el cuidado y la pasión que vivieron? Desvanecidos. Tal vez, si tienes suerte, haya instantes fugaces de recuerdo —ese ‘déjà vu’ mencionado antes—. La sensación de haber hecho algo con anterioridad. Leer un libro o un poema sin poder precisar cuándo; contemplar un paisaje glorioso o una arquitectura imponente y sentirlo familiar a la vista. ¿Crees que podrías hacer que lo recuerden?"

    # game/books.rpy:64
    old "That maybe, just maybe, with their soul intact, that spark long ago could be rekindled? Do you think there is a chance?"
    new "¿Que quizás, solo quizás, con su alma intacta, esa chispa de antaño pueda reavivarse? ¿Crees que existe una posibilidad?"

    # game/books.rpy:65
    old "I do."
    new "Yo sí creo."

    # game/books.rpy:66
    old "Whether centuries or millennia more, I will seek for you to love me once more. A lifetime and eons’ score, I will wait. Patiently, unwavering, for you, my love. Is it you reading this now, I wonder? This little tale of ours? This wish I write? In the confines of your subconscious mind, do you dream of me tonight? "
    new "Ya sean siglos o milenios, te buscaré para que me vuelvas a amar. Una vida y eras enteras, esperaré. Paciente, inquebrantable, por ti, mi amor. ¿Serás tú quien lee esto ahora, me pregunto? ¿Nuestro pequeño cuento? ¿Este deseo que escribo? En los confines de tu subconsciente, ¿me sueñas esta noche?"

    # game/books.rpy:67
    old "I forgive you for the heartbreak that has come from this long journey. Whether you find love with another or decline one entirely. All the while I am here, considerate of your new life’s amnesia. I watch and I wait, protect and anticipate every path you take. No power, good and evil and in-between, can keep me from you. For I know, one day, it will be our time again."
    new "Te perdono por el desgarro que ha traído este largo viaje. Tanto si hallas amor con otro como si lo rechazas por completo. Mientras tanto, aquí estoy, respetuoso de la amnesia de tu nueva vida. Observo y espero, protejo y anticipo cada camino que tomes. Ningún poder, ya sea bueno, malo o intermedio, puede alejarme de ti. Porque sé que, un día, será nuestro momento otra vez."

    # game/books.rpy:68
    old "The hope of us to reunite, not just in friendship but in love, too, keeps my spirits alight. Just as you always have, my love. And so I dance with you, in life and death and the space between. Seek me out, if this is you that reads. Whisper for me, beckon me forward - though you do not know my name, I shall come. Pray thee let me embrace you, hold you close, kiss your lips, hear your sweet voice close to my ear. My desire for you is patient and everlasting - as is your fickle, yet persistent deja vu. "
    new "La esperanza de reencontrarnos, no solo en la amistad sino también en el amor, mantiene mi espíritu encendido. Tal como siempre lo has hecho, mi amor. Y así bailo contigo, en la vida y la muerte y el espacio intermedio. Búscame, si eres tú quien lee esto. Susúrrame, llámame —aunque no conozcas mi nombre, acudiré. Te ruego que me dejes abrazarte, tenerte cerca, besar tus labios, escuchar tu dulce voz junto a mi oído. Mi deseo por ti es paciente y eterno —al igual que tu voluble, pero persistente, déjà vu."

    # game/books.rpy:69
    old "I wait for you, for now and eternity. In the shadows of your mind - in your darkest daydream."
    new "Te espero, ahora y por la eternidad. En las sombras de tu mente —en tu más oscuro ensueño."

    # game/books.rpy:70
    old "- Madilyn H. Wilbanks"
    new "- Madilyn H. Wilbanks"

    # game/books.rpy:79
    old "{i}Poet or Madman{/i}"
    new "{i}¿Poeta o Loco?{/i}"

    # game/books.rpy:96
    old "In the line between insanity and virtue"
    new "En la línea entre la locura y la virtud"

    # game/books.rpy:97
    old "I ponder the stance of my essence"
    new "Reflexiono sobre la postura de mi esencia"

    # game/books.rpy:98
    old "A step forward, \nand my very thoughts singe \nRhythmically"
    new "Un paso adelante, \ny mis propios pensamientos arden \nRítmicamente"

    # game/books.rpy:99
    old "A step backwards, \nAnd my actions swell and fester without \npredictability"
    new "Un paso atrás, \ny mis acciones se hinchan y supuran sin \npredictibilidad"

    # game/books.rpy:100
    old "It bouts of rage, lingering moments of bliss \nI project ever-shifting words that twist and turn"
    new "En arrebatos de ira, instantes persistentes de dicha \nProyecto palabras cambiantes que se retuercen y giran"

    # game/books.rpy:101
    old "My mind, verge of collapsing, fabricate stories \nIn which I set forth from the prison-deemed mentality"
    new "Mi mente, al borde del colapso, fabrica historias \nEn las que me libero de la mentalidad que llaman prisión"

    # game/books.rpy:102
    old "I stand before you, holy panel of judges \nTo lay your conviction thick \nAnd evaluate my inner-workings"
    new "Me presento ante ustedes, sagrado tribunal de jueces \nPara que dicten su firme condena \nY evalúen mis entrañas"

    # game/books.rpy:103
    old "Declare my sentence \nTill it echoes through the room"
    new "Proclamen mi sentencia \nHasta que resuene en toda la sala"

    # game/books.rpy:104
    old "Am I commended \nA poet \nOr \nMadman?"
    new "¿Soy aclamado \nPoeta \nO \nLoco?"

    # game/books.rpy:105
    old "- Amias C"
    new "- Amias C"

    # game/books.rpy:114
    old "{i}Butterfly{/i}"
    new "{i}Mariposa{/i}"

    # game/books.rpy:131
    old "The young girls watch the butterfly flap its iridescent wings as its tiny, black body hits the sides of the glass, seeking escape. One girl wears blue ribbons in her pigtails, the other a single ponytail with a red ribbon tied neatly in a bow. "
    new "Las niñas observan a la mariposa batir sus alas iridiscentes mientras su diminuto cuerpo negro golpea los lados del vidrio, buscando escapar. Una lleva cintas azules en sus coletas, la otra una sola coleta con un lazo rojo atado con pulcritud."

    # game/books.rpy:132
    old "When they first arrived at this old house filled with dust, dead plants, and vases of standing water, they feared there wouldn’t be anything exciting until they stumbled upon this room where nothing was house save for this singular butterfly. It was sunset when they came to this place with their parents. The colors of the butterfly’s wings –light and dark blue with splashes of purple and green– caught their curious eyes and they were instantly drawn in."
    new "Cuando llegaron por primera vez a esta vieja casa llena de polvo, plantas muertas y jarrones con agua estancada, temieron que no habría nada emocionante hasta que se toparon con esta habitación donde no había nada salvo esta única mariposa. Era el atardecer cuando llegaron allí con sus padres. Los colores de las alas de la mariposa —azules claros y oscuros con destellos de púrpura y verde— captaron sus ojos curiosos y quedaron al instante fascinadas."

    # game/books.rpy:133
    old "They left the door open when they came in here and now they can hear beyond the struggling butterfly the sounds of a machine dying and their mother sobbing. The house breathes in deeply, startling the butterfly and girls alike."
    new "Dejaron la puerta abierta al entrar y ahora, más allá de la mariposa que forcejea, pueden oír los sonidos de una máquina muriendo y los sollozos de su madre. La casa respira hondo, sobresaltando tanto a la mariposa como a las niñas."

    # game/books.rpy:134
    old "The jar holding it in place tips over when the house lets out its breath, toppling it to the ground in a resounding crash. Sparkling slivers of glass sprinkle their exposed toes, cutting their tender skin, but their eyes watch the butterfly as it flies high to the ceiling before it finds the open window."
    new "El frasco que la retenía se vuelca cuando la casa exhala, cayendo al suelo con un estruendo resonante. Brillantes fragmentos de vidrio salpican sus pies descalzos, cortando su piel tierna, pero sus ojos siguen a la mariposa que vuela alto hacia el techo antes de hallar la ventana abierta."

    # game/books.rpy:135
    old "Running on tiny feet, they follow its path until their chests hit the windowsill, blocking them from taking flight along with it."
    new "Corriendo con pies diminutos, siguen su trayectoria hasta que sus pechos chocan contra el alféizar, impidiéndoles volar junto a ella."

    # game/books.rpy:136
    old "Behind them, they finally hear their father, his words laced with sorrow and pain:"
    new "Detrás de ellas, al fin oyen a su padre, con palabras cargadas de pena y dolor:"

    # game/books.rpy:137
    old "'Come say goodbye to your grandfather.'"
    new "'Vengan a despedirse de su abuelo.'"

    # game/books.rpy:138
    old "He says nothing more but his presence waits for them."
    new "No dice nada más, pero su presencia las aguarda."

    # game/books.rpy:139
    old "The girls look at one another to find the other with tears in her eyes, ribbons and bow askew from the house’s earlier sighs. The butterfly has flown too far away for them to ever catch."
    new "Las niñas se miran entre sí y encuentran en la otra lágrimas en los ojos, con las cintas y el lazo desordenados por los suspiros previos de la casa. La mariposa ha volado demasiado lejos para que puedan atraparla."

    # game/books.rpy:140
    old "Now, the only sounds they can hear are the pitter patter of tears. "
    new "Ahora, los únicos sonidos que escuchan son el repiqueteo de las lágrimas."

    # game/books.rpy:141
    old "- TDO"
    new "- TDO"

    # game/books.rpy:153
    old "{i}Positives and Negatives{/i}"
    new "{i}Positivos y Negativos{/i}"

    # game/books.rpy:170
    old "The rain will fall, and The sun will rise. \nThe thunder will crash, and The flowers will bloom."
    new "La lluvia caerá, y el sol se alzará. \nEl trueno retumbará, y las flores florecerán."

    # game/books.rpy:171
    old "A positive, and a negative. \nWith strength, will come an eventual exhaustion. \nA boulder at first, but a pebble soon after."
    new "Un positivo, y un negativo. \nCon la fuerza, llegará un eventual agotamiento. \nUn peñasco al principio, pero pronto solo un guijarro."

    # game/books.rpy:172
    old "With courage, fear will arise. \nBut the darkened clouds will lighten with colors in its wake."
    new "Con valentía, surgirá el miedo. \nPero las nubes oscurecidas se aclararán con colores en su estela."

    # game/books.rpy:173
    old "Then why, oh why, \nDid the universe place \nTwo negatives, \nTo match with the red string."
    new "Entonces, por qué, oh por qué, \nPuso el universo \nDos negativos, \nPara enlazarlos con el hilo rojo."

    # game/books.rpy:174
    old "The crimson cord, \nas simple as it may be."
    new "El cordón carmesí, \npor simple que parezca."

    # game/books.rpy:175
    old "Binding, Pulling, Stretching. \nCatching on every corner, \nTugging on every imbalance."
    new "Atando, Tirando, Estirando. \nEnredándose en cada esquina, \nTirando de cada desequilibrio."

    # game/books.rpy:176
    old "Tensions rise, \nAnd fall back down. \nWhether wishful or not, \nThey come and go like waves."
    new "Las tensiones suben, \nY vuelven a caer. \nSean deseadas o no, \nVienen y van como olas."

    # game/books.rpy:177
    old "And yet, \nDespite all of my faults, \nAnd all of yours as well."
    new "Y aun así, \nA pesar de todas mis faltas, \nY también de las tuyas."

    # game/books.rpy:178
    old "The cord remains \nalmost unbothered. \nAs if nothing happened. \nWhy is that?"
    new "El cordón permanece \ncasi intacto. \nComo si nada hubiera pasado. \n¿Por qué es así?"

    # game/books.rpy:179
    old "Why is it despite everything that happens \nIn this waking world, \nThat the cord has not split."
    new "¿Por qué, a pesar de todo lo que ocurre \nEn este mundo despierto, \nEl cordón no se ha roto?"

    # game/books.rpy:180
    old "Because, Love, \nWhile we may not be positives \nIn our own eyes, \nThe things we do together are."
    new "Porque, Amor, \nAunque quizá no seamos positivos \nA nuestros propios ojos, \nLo que hacemos juntos sí lo es."

    # game/books.rpy:181
    old "We’re there for each other. \nDespite any negativity, \nThat comes our way."
    new "Estamos el uno para el otro. \nA pesar de cualquier negatividad \nQue se cruce en nuestro camino."

    # game/books.rpy:182
    old "The positives we create with each other \nWill be the Equivalent \nTo the Negatives we will face."
    new "Los positivos que creamos juntos \nSerán el Equivalente \nA los Negativos que enfrentaremos."

    # game/books.rpy:183
    old "- a.m.l.r."
    new "- a.m.l.r."

    # game/books.rpy:194
    old "{i}Cruel truth in bright color{/i}"
    new "{i}Cruel verdad en colores brillantes{/i}"

    # game/books.rpy:211
    old "There really was a special joy in being free to make your own choices; no matter the size, scope, or how wild they seemed, in retrospect. With a simple gesture – the mountains moved, the colors of the sky rippled like water, cities appeared or vanished at a whim. Immense joy and a tactical sense of power so thick he could taste it. "
    new "Había realmente un gozo especial en ser libre de tomar tus propias decisiones; sin importar el tamaño, el alcance o lo descabelladas que parecieran en retrospectiva. Con un simple gesto, las montañas se movían, los colores del cielo ondulaban como agua, las ciudades aparecían o desaparecían a su antojo. Un gozo inmenso y una sensación táctica de poder tan densa que podía saborearla."

    # game/books.rpy:212
    old "Cameron knew it wasn’t real, but that didn’t stop that thrill from rushing through him, adrenaline buzzing at his fingertips and prickling the hair at the nape of his neck. He wouldn't stop. No, couldn’t stop. This was a world all his own, and nobody could take that from him."
    new "Cameron sabía que no era real, pero eso no impedía que la emoción lo recorriera, la adrenalina cosquilleando en sus dedos y erizando el vello de su nuca. No se detendría. No, no podía detenerse. Ese era un mundo solo suyo, y nadie podría arrebatárselo."

    # game/books.rpy:213
    old "“No time,” he’d say, while trees popped up and formed a forest."
    new "'No hay tiempo', decía, mientras surgían árboles que formaban un bosque."

    # game/books.rpy:214
    old "“They’d just get in the way,” and a city full of empty smiling faces appeared near the green ocean."
    new "'Solo estorbarían', y una ciudad llena de rostros sonrientes y vacíos aparecía cerca del océano verde."

    # game/books.rpy:215
    old "“If I need a conversation I’ll just talk to myself,” he’d scoff, “only intelligent conversationalist around anyway.”"
    new "'Si necesito una conversación, hablaré conmigo mismo', se burlaba, 'soy el único conversador inteligente por aquí, de todos modos'."

    # game/books.rpy:216
    old "Of course, as he said these things, nobody was around to hear them. Only his perfect, peaceful world."
    new "Por supuesto, mientras decía esas cosas, no había nadie alrededor para escucharlas. Solo su mundo perfecto y pacífico."

    # game/books.rpy:217
    old "There were people, naturally. Though those empty-eyed puppets only existed to fill the spaces he created – to make them lifelike, believable. They bore faces he knew, each one either a copy or an amalgam of features he’d passed on the street; pretty girls who never gave him the time of day, eyes he’d met on the subway once, the strong jaws of the boys that used to beat him in school."
    new "Había gente, naturalmente. Aunque esos títeres de ojos vacíos solo existían para llenar los espacios que él creaba, para hacerlos verosímiles, creíbles. Tenían rostros que conocía, cada uno una copia o una amalgama de rasgos que había visto en la calle: chicas bonitas que nunca le prestaban atención, ojos que había cruzado una vez en el metro, las mandíbulas fuertes de los chicos que solían golpearlo en la escuela."

    # game/books.rpy:218
    old "They were all beautiful, perfect for the role he gave them, and in there – in his safe world where nothing unexpected happened – he was happy-"
    new "Todos eran hermosos, perfectos para el papel que él les asignaba, y allí —en su mundo seguro donde nada inesperado ocurría— era feliz…"

    # game/books.rpy:219
    old "“That mountain is new, isn’t it?”"
    new "'Esa montaña es nueva, ¿verdad?'"

    # game/books.rpy:220
    old "-except, when HE showed up."
    new "—excepto cuando ÉL aparecía."

    # game/books.rpy:221
    old "“Of course it’s new, I change them around almost every day.” Cameron didn’t turn around as he spoke, a part of him perhaps hoping that if he didn’t look at his uninvited guest, said guest would disappear; pop out of existence just like the way he constantly popped into it."
    new "'Claro que es nueva, las cambio casi todos los días.' Cameron no se dio la vuelta al hablar, quizá con la esperanza de que si no miraba a su invitado no deseado, este desaparecería; se esfumaría de la existencia, así como solía irrumpir en ella constantemente."

    # game/books.rpy:222
    old "It never worked."
    new "Nunca funcionó."

    # game/books.rpy:223
    old "“I see. Well, I think I liked it better where it was last time, around that fjord in the north.”"
    new "'Ya veo. Bueno, creo que me gustaba más donde estaba la última vez, cerca de aquel fiordo en el norte.'"

    # game/books.rpy:224
    old "“Well, I suppose it’s good that this place is mine, isn’t it? Not yours. And really, you don’t have to look at it. I would actually prefer if you didn’t.”"
    new "'Bueno, supongo que es bueno que este lugar sea mío, ¿no? No tuyo. Y en realidad, no tienes por qué mirarlo. De hecho, preferiría que no lo hicieras.'"

    # game/books.rpy:225
    old "“Aw Cam, don’t be like that-“"
    new "'Ay, Cam, no seas así…'"

    # game/books.rpy:226
    old "“Cameron.”"
    new "'Cameron.'"

    # game/books.rpy:227
    old "“-fine fine, Cameron. I’m here as a friend-“"
    new "'—Está bien, está bien, Cameron. Estoy aquí como amigo…'"

    # game/books.rpy:228
    old "“I don’t have friends.”"
    new "'No tengo amigos.'"

    # game/books.rpy:229
    old "“...That’s not true. You know your room is rarely empty, right? They haven’t given up hope just yet, praying you’ll find your way out again. They wish they could come see you, come get you but… anyway it doesn’t matter. Complain all you like, but I’m your friend… I’ll always be your friend.”"
    new "“...Eso no es verdad. Sabes que tu habitación casi nunca está vacía, ¿verdad? Todavía no han perdido la esperanza, rezan para que vuelvas a encontrar la salida. Desearían poder ir a verte, ir a buscarte, pero… en fin, no importa. Quéjate todo lo que quieras, pero soy tu amigo… siempre seré tu amigo.”"

    # game/books.rpy:230
    old "Cameron drew a deep breath, taking a moment to notice how his ribs expanded as his lungs filled up, allowing the sensation to ground him before he turned to face his guest."
    new "Cameron inspiró profundamente, tomándose un momento para notar cómo sus costillas se expandían al llenarse sus pulmones, permitiéndole anclarse en la sensación antes de girarse para enfrentar a su invitado."

    # game/books.rpy:231
    old "He hadn’t changed. Never did. Always the same eyes fixed on him, filled with a kindness and compassion Cameron knew he didn’t deserve – a kindness so deep it hurt him to perceive. No matter how he tried to push him away, the man never listened, even as he screamed. Insulted. Sulked."
    new "No había cambiado. Nunca lo hacía. Siempre los mismos ojos fijos en él, llenos de una bondad y una compasión que Cameron sabía que no merecía; una bondad tan profunda que le dolía percibirla. No importaba cuánto intentara alejarlo, el hombre nunca escuchaba, incluso cuando le gritaba. Lo insultaba. Se enfurruñaba."

    # game/books.rpy:232
    old "The man always came back."
    new "El hombre siempre regresaba."

    # game/books.rpy:233
    old "And Cameron supposed the worst thing was that he knew why. He knew the man was right – that he’d have to eventually listen, to admit that it was time and that he was ready to go with him. He knew he couldn’t stay in his made-up world forever, as much as he wanted to."
    new "Y Cameron suponía que lo peor era que sabía por qué. Sabía que el hombre tenía razón, que tarde o temprano tendría que escuchar, admitir que había llegado la hora y que estaba listo para irse con él. Sabía que no podía quedarse para siempre en su mundo inventado, por mucho que lo deseara."

    # game/books.rpy:234
    old "“I hate you.”"
    new "'Te odio.'"

    # game/books.rpy:235
    old "“I know.”"
    new "'Lo sé.'"

    # game/books.rpy:236
    old "In a sterile hospital room – both far away and not very far at all, machines beeped in the rhythm of a heartbeat, while lights blinked steadily on the diodes attached to a young man’s temples as he replaced life with facsimile, breath with data, connection with binary…"
    new "En una habitación de hospital estéril —a la vez muy lejana y no tan distante—, las máquinas pitaban al ritmo de un latido, mientras las luces parpadeaban en los diodos conectados a las sienes de un joven, que reemplazaba la vida con una réplica, la respiración con datos, la conexión con binarios…"

    # game/books.rpy:237
    old "Cruel truth in bright color."
    new "Cruel verdad en colores brillantes."

    # game/books.rpy:239
    old "- Erla Ruth Möller"
    new "- Erla Ruth Möller"

    # game/books.rpy:249
    old "{i}The Alchemist{/i}"
    new "{i}El Alquimista{/i}"

    # game/books.rpy:266
    old "The alchemist burst through his laboratory door, ponytail swishing against his shoulders, and long coat billowing behind him. As the door fell closed with a thud, he pulled off the coat, throwing it up to hang on the back of the door. He crossed the room, rolling up his sleeves as he did, the dark swirled patterns on his arms glowing a soft blue colour. The tall man crouched in front of the heart, pulling a hanging cauldron forward, and lighting a fire underneath it."
    new "El alquimista irrumpió por la puerta de su laboratorio, la coleta azotando sus hombros y el largo abrigo ondeando tras de él. Cuando la puerta se cerró con un golpe seco, se quitó el abrigo y lo arrojó sobre la percha detrás de la puerta. Cruzó la habitación arremangándose, mientras los oscuros patrones en espiral de sus brazos brillaban con un suave tono azul. El hombre alto se agachó frente al hogar, arrastró un caldero colgante hacia adelante y encendió un fuego debajo."

    # game/books.rpy:267
    old "It had been days, maybe even weeks since he'd been in here, uninspired, unmotivated. Yet one conversation with him and he was devising new theories on what he'd been doing wrong before."
    new "Habían pasado días, quizá incluso semanas desde la última vez que había estado allí, sin inspiración ni motivación. Sin embargo, una sola conversación con él bastó para que empezara a idear nuevas teorías sobre lo que había estado haciendo mal antes."

    # game/books.rpy:268
    old "He fetched a jug of water, pouring it into the bone-dry cauldron. It was... A starting point. The man then proceeded to move back and forth, pulling various jars from shelves and gathering them on the nearby table. Picking up his knife and twirling it between his fingers, he looked over his collective of ingredients, debating if this was everything he needed."
    new "Tomó una jarra de agua y la vertió en el caldero reseco. Era... un punto de partida. Luego comenzó a ir y venir, sacando varios frascos de los estantes y reuniéndolos sobre la mesa cercana. Tomando su cuchillo y haciéndolo girar entre los dedos, observó su colección de ingredientes, preguntándose si era todo lo que necesitaba."

    # game/books.rpy:269
    old "The man tapped the top of a few jars with the tip of his knife before starting to chop up the loose ingredients, throwing them into the top of the cauldron. He nudged his glasses back up his nose with his knuckle between ingredients. He stopped to stir the water, pulling a large ladle down from the mantlepiece and dipping it in the now murky liquid."
    new "El hombre golpeó la tapa de algunos frascos con la punta de su cuchillo antes de comenzar a picar los ingredientes sueltos y arrojarlos al caldero. Entre un ingrediente y otro, se acomodaba las gafas con el nudillo. Se detuvo a remover el agua, bajando un gran cucharón de la repisa y sumergiéndolo en el líquido ya turbio."

    # game/books.rpy:270
    old "Suddenly, all motion in the room stopped, one of the alchemist's hands hovering over the gently bubbling liquid, the long fingers of his other hand still wrapped around the ladle's handle. Mismatched eyes had fallen closed and his breathing was deep and even."
    new "De repente, todo movimiento en la sala se detuvo: una de las manos del alquimista quedó suspendida sobre el líquido que burbujeaba suavemente, mientras los largos dedos de la otra seguían aferrados al mango del cucharón. Sus desiguales ojos se habían cerrado y su respiración era profunda y uniforme."

    # game/books.rpy:271
    old "As suddenly as he stopped, he started again, letting the ladle fall against the side of the cauldron with a light thunk and moving back to his table. He chopped up a few more things before starting with the jars. He uncorked a few, pulling pieces out. With others, he opened them and poured their entire contents into the mix. The mixture's colour was still murky but was something more like a deep green than a muddy grey now."
    new "Tan repentinamente como se detuvo, volvió a empezar, dejando que el cucharón golpeara contra el borde del caldero con un leve ruido sordo antes de regresar a su mesa. Picó algunas cosas más antes de empezar con los frascos. Destapó varios y sacó piezas de su interior; con otros, vertió todo el contenido en la mezcla. El color seguía siendo turbio, aunque ahora se parecía más a un verde profundo que a un gris lodoso."

    # game/books.rpy:272
    old "With a few more ingredients and a little more stirring, the liquid was iridescent, bubbling away on the heat. Slender fingers waved over the top of the cauldron, the dark swirls on his arms now glowing a bright blue, almost white."
    new "Con unos pocos ingredientes más y un poco más de agitación, el líquido se volvió iridiscente, burbujeando sobre el calor. Sus delgados dedos pasaron sobre la superficie del caldero, mientras las oscuras espirales de sus brazos brillaban ahora en un azul brillante, casi blanco."

    # game/books.rpy:273
    old "The alchemist slowly dipped one set of fingertips into the water, hissing at the scalding heat. Black iridescent scales began creeping up his fingers, fully covering his hand by the time they were rolling up his forearm to his elbow and beyond. He could feel his blood starting to run cold, his heart rate slowing to a crawl."
    new "El alquimista sumergió lentamente las yemas de los dedos en el agua, siseando ante el calor abrasador. Escamas negras e iridiscentes comenzaron a trepar por sus dedos, cubriendo por completo su mano cuando ya se extendían por su antebrazo hasta el codo y más allá. Podía sentir su sangre enfriarse y su corazón reduciendo el ritmo hasta casi detenerse."

    # game/books.rpy:274
    old "He'd done it. It was working."
    new "Lo había logrado. Estaba funcionando."

    # game/books.rpy:275
    old "He could finally look like the monster everyone presumed him to be."
    new "Por fin podía lucir como el monstruo que todos presumían que era."

    # game/books.rpy:276
    old "- Morgan K. Stark"
    new "- Morgan K. Stark"

    # game/books.rpy:286
    old "{i}Night Sky{/i}"
    new "{i}Cielo nocturno{/i}"

    # game/books.rpy:303
    old "The night sky has always fascinated me, the vastness of it, how small it should make me feel is terrifying and beautiful at the same time. The stars which shine so brightly that I see as I stare up into the darkness may well have burnt out thousands of years ago, yet I can still see them sparkling above me. I still marvel at how we made constellations from the patterns we see in them, and how sailors used them to find their way home from sea."
    new "El cielo nocturno siempre me ha fascinado, su inmensidad, la pequeñez que debería hacerme sentir es aterradora y hermosa al mismo tiempo. Las estrellas que brillan con tanta intensidad cuando miro hacia la oscuridad quizá se apagaron hace miles de años, y aun así puedo verlas centellear sobre mí. Sigo maravillándome de cómo creamos constelaciones a partir de los patrones que vemos en ellas, y de cómo los marineros las usaban para encontrar el camino de regreso desde el mar."

    # game/books.rpy:304
    old "As a child I used to fight going to bed early or sneak out of bed to watch meteor showers or satellites moving across the sky, I no longer have to do that now, instead choosing to stay awake to watch events in the night sky because I simply want to. I can take a blanket and make a hot drink and sit outside and just enjoy the quiet stillness, I could stay out there for hours enjoying the cool air and the cloudless expanse above my head."
    new "Cuando era niña solía resistirme a irme temprano a la cama o escaparme para mirar lluvias de meteoros o satélites cruzando el cielo. Ahora ya no necesito hacerlo, sino que elijo quedarme despierta para ver los eventos en el cielo nocturno simplemente porque quiero. Puedo llevar una manta, preparar una bebida caliente y sentarme afuera a disfrutar del silencio tranquilo; podría quedarme allí horas disfrutando del aire fresco y de la extensión despejada sobre mi cabeza."

    # game/books.rpy:305
    old "I have always preferred the moon over the sun, the softer glow that doesn’t burn my skin or make me squint my eyes closed due to the brightness. The night is quieter, more peaceful, more comforting where I am not busy rushing around with work or chores and I can just take time for myself to simply exist."
    new "Siempre he preferido la luna al sol, ese resplandor más suave que no quema mi piel ni me hace entrecerrar los ojos por el brillo. La noche es más tranquila, más pacífica, más reconfortante; en ella no estoy ocupada corriendo de un lado a otro con trabajos o quehaceres, y puedo tomarme un tiempo para mí, simplemente para existir."

    # game/books.rpy:306
    old "- Moonlight Musings"
    new "- Reflexiones a la Luz de la Luna"

    # game/books.rpy:317
    old "{i}Love of Mine{/i}"
    new "{i}Amor mío{/i}"

    # game/books.rpy:334
    old "It all began with a list. Your name was insignificant - another in a line of many, but with time you proved to be my greatest challenge, my deepest desire, and ultimately my downfall."
    new "Todo empezó con una lista. Tu nombre era insignificante —otro más en una fila de muchos—, pero con el tiempo resultaste ser mi mayor desafío, mi deseo más profundo y, en última instancia, mi perdición."

    # game/books.rpy:335
    old "At first it was nothing more than a mere curiosity, yet something about you stood out—something unique, a warmth that even I could feel. As I began to watch you my interest in you deepened, and as it did I came to know you, the real you. Every choice you made was a testament to your devotion to others. Your selflessness shone brightly, inspiring others around you. Your successes filled me with happiness. You embodied everything I was not."
    new "Al principio no fue más que una mera curiosidad, pero algo en ti destacaba —algo único, una calidez que hasta yo podía sentir. Al empezar a observarte, mi interés por ti se profundizó y, a medida que lo hacía, llegué a conocerte: el verdadero tú. Cada decisión que tomabas era un testimonio de tu entrega hacia los demás. Tu desinterés brillaba con fuerza, inspirando a quienes te rodeaban. Tus éxitos me llenaban de alegría. Encarnabas todo aquello que yo no era."

    # game/books.rpy:336
    old "This feeling was unlike anything I had ever known before. How did I come to feel this way, what power could a mere mortal possess to sway my heart?"
    new "Este sentimiento no se parecía a nada que hubiera conocido antes. ¿Cómo llegué a sentirme así? ¿Qué poder podría poseer un simple mortal para conmover mi corazón?"

    # game/books.rpy:337
    old "With every passing day my senses grew overwhelmed by my adoration. I could think of nothing else, but you. You were my first thought upon awakening, and my final thought as I drifted off to sleep. I realized that I could not allow any harm to come to you."
    new "Con cada día que pasaba, mis sentidos se vieron desbordados por mi adoración. No podía pensar en otra cosa que no fueras tú. Eras mi primer pensamiento al despertar y el último al caer dormido. Comprendí que no podía permitir que nada te hiciera daño."

    # game/books.rpy:338
    old "And so I intervened, I broke the rules to protect you. A slight push here, a gentle breeze there —subtle influences to steer you out of harm’s way. You never knew it was me, but you seemed grateful for the intervention. A small smile would grace your lips, perhaps you thought you were lucky? Every smile you unknowingly directed my way filled me with a warmth I had never known. I yearned to reveal myself to you, to bridge the gap between us, but courage always eluded me."
    new "Y así intervine: quebranté las reglas para protegerte. Un pequeño empujón aquí, una brisa suave allá —influencias sutiles para apartarte del peligro. Nunca supiste que era yo, pero parecías agradecido por la intervención. Una leve sonrisa se posaba en tus labios; quizás pensabas que habías tenido suerte. Cada sonrisa que me dirigías sin saberlo me llenaba de una calidez desconocida. Anhelaba revelarme ante ti, tender un puente entre nosotros, pero el valor siempre me eludía."

    # game/books.rpy:339
    old "Oftentimes, I would find you lost in thought as you gazed out at the world before you. I wondered what occupied your mind. Then one day, I succumbed to my desires. I appeared to you as a creature I knew you could not overlook —a white raven. You noticed me, and from then on, you eagerly awaited my return."
    new "A menudo te encontraba perdido en pensamientos mientras contemplabas el mundo ante ti. Me preguntaba qué ocupaba tu mente. Y un día sucumbí a mis deseos. Me mostré ante ti como una criatura que sabía no podrías pasar por alto —un cuervo blanco. Me notaste y, desde entonces, aguardaste con ansias mi regreso."

    # game/books.rpy:340
    old "As time passed, I began to draw closer to you, envisioning a world in which we stood together, your fingers entwined with mine. I longed for the day you might turn your head and see me. If only I were free from these otherworldly obligations, what could have existed between us?"
    new "Con el paso del tiempo me fui acercando a ti, imaginando un mundo en el que estábamos juntos, tus dedos entrelazados con los míos. Anhelaba el día en que giraras la cabeza y me vieras. Si tan solo fuera libre de estas obligaciones de otro mundo, ¿qué podría haber existido entre nosotros?"

    # game/books.rpy:341
    old "Our daily meetings became a comforting ritual for me, and yet even like this, I struggled to be near you. I cautioned myself to keep my distance, fearing that I would let slip what I really was."
    new "Nuestros encuentros diarios se convirtieron en un ritual reconfortante para mí, y aun así, incluso de ese modo, me costaba estar cerca de ti. Me advertía guardar distancia, temiendo que se me escapara lo que realmente era."

    # game/books.rpy:342
    old "Eventually, I withdrew."
    new "Eventualmente, me retiré."

    # game/books.rpy:343
    old "I no longer intervened, and allowed life’s natural course to resume once more."
    new "Ya no intervine y permití que el curso natural de la vida se reanudara."

    # game/books.rpy:344
    old "When our daily ritual ceased, your confusion over my absence pained me. I agonized over the decision I had made. Over the years, you had changed me so profoundly that I no longer recognized who I was before. Truthfully, I welcomed this change, it showed me that I could not be without you. "
    new "Cuando nuestro ritual diario cesó, tu confusión por mi ausencia me dolió. Agonicé por la decisión que había tomado. Con los años, me habías transformado tan profundamente que ya no reconocía quién fui antes. Sinceramente, di la bienvenida a ese cambio: me demostró que no podía estar sin ti."

    # game/books.rpy:345
    old "Panic washed over me as I realized my mistake. Returning to your favored form, I hurried to your side once more, whispering a silent oath vowing to protect you for as long as time allowed. "
    new "El pánico me invadió al comprender mi error. Volviendo a tu forma preferida, me apresuré a tu lado una vez más, susurrando un juramento silencioso de protegerte mientras el tiempo lo permitiera."

    # game/books.rpy:346
    old "But fate unfolded just as I knew, and the inevitable moment had arrived."
    new "Pero el destino se desplegó tal como yo sabía, y el momento inevitable llegó."

    # game/books.rpy:347
    old "I was too late, it was my fault. My hesitation. My weakness."
    new "Llegué demasiado tarde; fue mi culpa. Mi vacilación. Mi debilidad."

    # game/books.rpy:348
    old "A pool of crimson surrounded you."
    new "Un charco carmesí te rodeaba."

    # game/books.rpy:349
    old "Seeing you like this tore at my very soul. It was like nothing I had ever felt before."
    new "Verte así desgarró mi alma. No se parecía a nada que hubiera sentido antes."

    # game/books.rpy:350
    old "As your gaze met mine, the raven fell away. I finally stood before you."
    new "Cuando tu mirada se encontró con la mía, el cuervo se desvaneció. Finalmente me planté ante ti."

    # game/books.rpy:351
    old "'There you are,' you whispered weakly, a faint smile on your lips."
    new "—Ahí estás —susurraste débilmente, con una leve sonrisa en los labios."

    # game/books.rpy:352
    old "Despite my sorrow, I managed a smile in return. 'My dear, I could never stay away.' The words caught in my throat, weighed down by years of silence between us. Looking at me now you did not see a white raven, you did not see your death, you saw only a man."
    new "A pesar de mi dolor, logré corresponder con una sonrisa. —Querido mío, nunca pude alejarme —las palabras se clavaron en mi garganta, cargadas por años de silencio entre nosotros. Al mirarme ahora no viste un cuervo blanco, no viste a tu muerte; solo viste a un hombre."

    # game/books.rpy:353
    old "I took your hand, as your final moment drew near. We were two souls destined for failure right from the start."
    new "Tomé tu mano cuando tu último momento se acercaba. Éramos dos almas destinadas al fracaso desde el principio."

    # game/books.rpy:354
    old "I pulled you close, our first and last kiss. Your lips were cold against mine."
    new "Te acerqué a mí: nuestro primer y último beso. Tus labios estaban fríos contra los míos."

    # game/books.rpy:355
    old "Love of mine, today you have died, and with you, so shall I."
    new "Amor mío, hoy has muerto, y contigo, yo también."

    # game/books.rpy:356
    old "- The White Raven"
    new "- El Cuervo Blanco"

    # game/books.rpy:369
    old "{i}Whiskers and Shadow{/i}"
    new "{i}Bigotes y Sombra{/i}"

    # game/books.rpy:386
    old "Nat’s eyes opened as wide as possible, peering through the darkness of her room. Whatever was in there, she couldn’t see it, but she could feel it. It was back again, to torment her, to scare her, to ruin the precious hours of the night when we should feel the most at peace in restful sleep. She wanted to get up, to turn a light on and tell it to leave. But once again she found herself stuck in place, unable to move or speak or do anything, completely and totally petrified as if she just peered into the eyes of Medusa herself, making her bed feel more like a prison than a place of slumber."
    new "Los ojos de Nat se abrieron todo lo que pudieron, escudriñando la oscuridad de su habitación. Fuera lo que fuera lo que estaba allí, no podía verlo, pero sí sentirlo. Había vuelto una vez más, para atormentarla, asustarla y arruinar las preciosas horas de la noche cuando deberíamos sentirnos más en paz en un sueño reparador. Quería levantarse, encender una luz y decirle que se marchara. Pero una vez más se encontró inmóvil, incapaz de moverse, hablar o hacer nada, completamente petrificada como si hubiera mirado a los ojos de la propia Medusa, haciendo que su cama se sintiera más como una prisión que como un lugar de descanso."

    # game/books.rpy:387
    old "Tears welled in her eyes as she felt each sharp pain on her body coming with no warning as she could not see the entity responsible for such agony. Again, and again and again, it went on for what felt like hours. She wasn’t sure how much more she could take, it felt like at any moment death himself would come for her if for nothing else but to relieve her of this torture. It had been weeks of these nightly visits from her invisible tormenting, she didn't know why it chose her, but she knew she couldn't hold on for much longer."
    new "Las lágrimas inundaron sus ojos al sentir cada punzada de dolor en su cuerpo llegando sin aviso, ya que no podía ver a la entidad responsable de tal agonía. Una y otra vez, parecía continuar durante horas. No estaba segura de cuánto más podría soportar; sentía que en cualquier momento la propia muerte vendría por ella, aunque solo fuera para liberarla de esta tortura. Llevaba semanas sufriendo estas visitas nocturnas de su tormento invisible; no sabía por qué la había escogido a ella, pero sabía que no aguantaría mucho más."

    # game/books.rpy:388
    old "Bracing herself mentally for the next lashing, she closed her eyes tight, her muscles tensing to prepare for the pain that she knew was coming. But this time, it didn’t. She waited, her eyes closed tight, sure that her attacker hadn't satisfied himself just yet. But When she opened them, she was surprised to see a swirling darkness in the corner of her room, so dark it looked like a mirror peering into the void itself. It was unlike anything she had ever seen before. Was this her assailant manifesting into its physical form? “Please, no…” she shuddered at the thought of it."
    new "Preparándose mentalmente para el próximo azote, cerró los ojos con fuerza, tensando sus músculos para el dolor que sabía que vendría. Pero esta vez, no llegó. Esperó, con los ojos bien cerrados, convencida de que su atacante aún no estaba satisfecho. Pero cuando los abrió, se sorprendió al ver una oscuridad giratoria en la esquina de su habitación, tan densa que parecía un espejo asomándose al vacío mismo. Era algo que nunca había visto antes. ¿Era ese su agresor manifestándose en forma física? “Por favor, no…” se estremeció ante la idea."

    # game/books.rpy:389
    old "Her imagination had barely a moment to run away from her when it was dragged back by a loud snap as the black hole disappeared before her eyes and in its place, on the floor was… a cat? No, this wasn’t just any cat. This was a black cat… A black cat that belonged to one of her best friends, Maz."
    new "Su imaginación apenas tuvo un instante para desbocarse cuando un fuerte chasquido la hizo volver en sí: el agujero negro desapareció ante sus ojos y, en su lugar, en el suelo había… ¿un gato? No, no era un gato cualquiera. Era un gato negro… Un gato negro que pertenecía a una de sus mejores amigas, Maz."

    # game/books.rpy:390
    old "“Smudge? What the hell are you doing here?” The words left her mouth before she even thought them, surprising herself to hear her own voice ring out through the darkness. The cat looked at her and tilted his head, casually flicking his tail back and forth. They held eye contact for a small moment, before Smudge looked back towards the center of the room. "
    new "“¿Smudge? ¿Qué demonios haces aquí?” Las palabras salieron de su boca antes incluso de pensarlas, sorprendiéndose al escuchar su propia voz resonar en la oscuridad. El gato la miró e inclinó la cabeza, moviendo su cola de un lado a otro con calma. Mantuvieron el contacto visual por un breve instante, antes de que Smudge volviera la mirada hacia el centro de la habitación."

    # game/books.rpy:391
    old "His eyes flashed a bright red as he leapt into the air, a trail of absolute darkness following him and enveloping the entire room. Nat couldn’t see what was happening but she could hear the sounds of a fight; flesh tearing, blows landing, bodies being pushed into furniture. She sunk herself into her bed as deeply as she could so as to not get caught in the crossfire of the battle raging throughout her room, not moving a muscle until a loud growl burst into a roar of anguish and then was followed by a suffocating silence. The fight was over. "
    new "Sus ojos destellaron de un rojo brillante cuando saltó al aire, dejando tras de sí un rastro de oscuridad absoluta que envolvió toda la habitación. Nat no podía ver lo que ocurría, pero escuchaba los sonidos de una pelea: carne desgarrándose, golpes aterrizando, cuerpos empujados contra los muebles. Se hundió en la cama todo lo que pudo para no quedar atrapada en el fuego cruzado de la batalla que arrasaba su cuarto, sin mover un músculo hasta que un fuerte gruñido estalló en un rugido de angustia seguido de un silencio asfixiante. La pelea había terminado."

    # game/books.rpy:392
    old "Nat’s eyes darted around the darkness enveloping the room trying to see anything, any kind of hint of who was the victor. Slowly the familiarity of her room started to appear before her, moonlight pouring in through the window, illuminating the bright green eyes of the black cat sitting at the bottom of her bed."
    new "Los ojos de Nat recorrieron la oscuridad que envolvía la habitación tratando de distinguir algo, alguna pista de quién había sido el vencedor. Poco a poco, la familiaridad de su cuarto comenzó a aparecer de nuevo, con la luz de la luna entrando por la ventana e iluminando los brillantes ojos verdes del gato negro sentado al pie de su cama."

    # game/books.rpy:393
    old "“Oh, thank the gods,” she whispered, letting out a deep sigh of relief. Smudge stood up and stretched before making his way towards the top of the bed where he gently headbutted Nat’s arm. She ran her hand through his silky, black fur, feeling the soothing vibration of his deep purr as he paced back and forth alongside her. She smiled to herself, allowing the stillness in the room to wash over her, her muscles finally relaxing and releasing all the tension they had held just moments before."
    new "“Oh, gracias a los dioses,” susurró, soltando un profundo suspiro de alivio. Smudge se levantó y se estiró antes de dirigirse a la cabecera de la cama, donde dio un suave cabezazo en el brazo de Nat. Ella pasó la mano por su sedoso pelaje negro, sintiendo la vibración reconfortante de su ronroneo profundo mientras él iba y venía a su lado. Sonrió para sí misma, dejando que la quietud del cuarto la envolviera, con sus músculos finalmente relajándose y liberando toda la tensión acumulada instantes antes."

    # game/books.rpy:394
    old "“Thank you, my little prince of darkness. And tell your mom I said hi, too. I know she would have come herself if she could.” "
    new "“Gracias, mi pequeño príncipe de la oscuridad. Y dile a tu mamá que le mando saludos también. Sé que ella habría venido en persona si hubiera podido.”"

    # game/books.rpy:395
    old "Finally, she could get some rest. "
    new "Finalmente, podía descansar."

    # game/books.rpy:396
    old "- Maziibean"
    new "- Maziibean"

    # game/books.rpy:407
    old "{i}Undelivered Love Letter{/i}"
    new "{i}Carta de amor no entregada{/i}"

    # game/books.rpy:424
    old "The moment you stood in front of me, \nWearing red, like Roses, \nHaving made me aware, \nYou were missing, \nThat piece of jewelry,"
    new "El momento en que te paraste frente a mí, \nVestida de rojo, como Rosas, \nHaciéndome notar, \nQue te faltaba, \nEsa pieza de joyería,"

    # game/books.rpy:425
    old "I don't know... \nWhat washed over me."
    new "No sé... \nQué se apoderó de mí."

    # game/books.rpy:426
    old "I try to recall that moment over and over again. \nBut the only thing I can remember, is how I felt. \nI didn't even have a chance to think before I had already undone the loop of my earring. \nYou stopped me and said it was the pendant you were missing, with a soft laugh. \nAll I said was 'oh' before laughing back & proceeding to remove the pendant instead."
    new "Intento recordar ese momento una y otra vez. \nPero lo único que recuerdo es cómo me sentí. \nNi siquiera tuve tiempo de pensar antes de haber desabrochado ya el aro de mi pendiente. \nMe detuviste y dijiste que lo que te faltaba era el colgante, con una suave risa. \nTodo lo que dije fue 'oh' antes de reír contigo y proceder a quitar el colgante en su lugar."

    # game/books.rpy:427
    old "You stood there, in complete shock... \nI just couldn't help but... smile... \nHaving you put your hand out, \nI placed it in the center of your palm. \nI remember pushing down slightly before having you coil your fingers around it. \nYou didn't know what to say"
    new "Te quedaste allí, completamente en shock... \nYo simplemente no pude evitar... sonreír... \nAl extender tu mano, \nLo coloqué en el centro de tu palma. \nRecuerdo haber presionado suavemente antes de que cerraras tus dedos alrededor de él. \nNo sabías qué decir"

    # game/books.rpy:428
    old "And I didn't know... \nI... didn't know... \nThat... \nI wasn't just giving you my pendant, \nThat day... \nNo... \nThat was going to be the day, \nI gave you my heart to hold."
    new "Y yo no sabía... \nYo... no sabía... \nQue... \nNo solo te estaba entregando mi colgante, \nEse día... \nNo... \nEse iba a ser el día, \nEn que te entregaría mi corazón para que lo sostuvieras."

    # game/books.rpy:429
    old "Looking back now... \nIt's so clear, \nThat's where it all started."
    new "Mirando atrás ahora... \nEs tan claro, \nAhí fue donde todo comenzó."

    # game/books.rpy:430
    old "- Blooming Soul in Spring"
    new "- Alma floreciente en primavera"

    # game/books.rpy:440
    old "{i}Reminder{/i}"
    new "{i}Recordatorio{/i}"

    # game/books.rpy:457
    old "Hey there! I hope life’s been treating you kindly. If not, then I’m sorry to hear that. It happens to a lot of us, more than you know, so don’t sweat it."
    new "¡Hola! Espero que la vida te haya tratado con amabilidad. Si no, lamento escuchar eso. Nos pasa a muchos, más de lo que imaginas, así que no te preocupes."

    # game/books.rpy:458
    old "If you haven’t been told this lately, then I just want to say I’m proud of you for coming this far. The journey may not have been easy to get to this point, but I can only hope that it gets easier for you as the days go by. Feel free to step back, recharge as long as you need, and take a moment to yourself if you can. I, as well as many others, got your back."
    new "Si no te lo han dicho últimamente, quiero decirte que estoy orgulloso de ti por haber llegado hasta aquí. El camino puede no haber sido fácil, pero solo espero que con el tiempo se vuelva más llevadero. Siéntete libre de dar un paso atrás, recargar energías todo lo que necesites y tomarte un momento para ti si puedes. Yo, al igual que muchos otros, estoy contigo."

    # game/books.rpy:459
    old "Everything will be okay. It may not seem like it right now, but just remember that whatever situation you’re going through is only temporary. The future is always changing."
    new "Todo estará bien. Puede que ahora no lo parezca, pero recuerda que cualquier situación por la que estés pasando es solo temporal. El futuro siempre está cambiando."

    # game/books.rpy:460
    old "Now, if it’s alright with you, could you take some deep breaths with me? I’m going through some stresses myself, and I think it would help a lot if we did this together. Better than going through this alone, right?"
    new "Ahora, si está bien contigo, ¿podrías respirar profundo conmigo? Yo también estoy pasando por algo de estrés y creo que nos ayudaría mucho hacerlo juntos. Mejor que pasarlo en soledad, ¿verdad?"

    # game/books.rpy:461
    old "Ready?"
    new "¿Listo?"

    # game/books.rpy:462
    old "Breathe…"
    new "Respira…"

    # game/books.rpy:463
    old "1…"
    new "1…"

    # game/books.rpy:464
    old "2…"
    new "2…"

    # game/books.rpy:465
    old "3…"
    new "3…"

    # game/books.rpy:466
    old "Again."
    new "De nuevo."

    # game/books.rpy:470
    old "Apologies for dragging you into this with me if you didn’t need it. I appreciate you. Make sure to get some water and grab a bite to eat if you haven’t eaten today. Even a tiny snack will help some! No, energy drinks and coffee don’t count."
    new "Perdón por arrastrarte a esto conmigo si no lo necesitabas. Te aprecio. Asegúrate de tomar agua y de comer algo si aún no lo has hecho hoy. ¡Incluso un pequeño bocadillo ayuda! Y no, las bebidas energéticas y el café no cuentan."

    # game/books.rpy:471
    old "Thank you for your time and continue on enjoying your time with Death."
    new "Gracias por tu tiempo y sigue disfrutando de tu tiempo con Death."

    # game/books.rpy:472
    old "- redmapleboi"
    new "- redmapleboi"

    # game/books.rpy:483
    old "{i}Dreaming of Life{/i}"
    new "{i}Soñando con la vida{/i}"

    # game/books.rpy:500
    old "Today was another day I only caught myself long after sunset. Again, passed through distraction, searching for an escape I could never quite find. This was one more day I didn’t leave the house, spent in hiding. But I decided I could at least imagine I stepped outside today. The irritating need to do something — anything — having snapped my last thread connecting me to the reality of my bed beneath me."
    new "Hoy fue otro día en el que apenas me descubrí a mí mismo mucho después del atardecer. Otra vez, perdido en distracciones, buscando una salida que nunca logré encontrar. Fue un día más en el que no salí de casa, escondido. Pero decidí que al menos podía imaginar que salía hoy. La molesta necesidad de hacer algo —lo que fuera— rompió el último hilo que me ataba a la realidad de mi cama bajo mí."

    # game/books.rpy:501
    old "Sometimes, it’s okay to close my eyes to get my much-deserved rest, to stop pushing ever further ahead. Knowing that it’s time to dream while I wait for the Earth to twirl further about and for everything to catch up with my racing thoughts of possibilities."
    new "A veces está bien cerrar los ojos para obtener mi merecido descanso, dejar de empujar siempre hacia adelante. Saber que es tiempo de soñar mientras espero a que la Tierra siga girando y todo alcance a ponerse al día con mis pensamientos acelerados de posibilidades."

    # game/books.rpy:502
    old "I would walk down the hill to meet the footpath bordering the towering Eucalyptus trees, passing by the last solitary streetlamp, then follow the path lit only by moonlight. Unlike in Earth’s nosier places, the stars would be able to surface for air here, and the trees would sing clearly to each other. And I would be able to think, to question, but maybe with less of a suffocating haze over my mind."
    new "Bajaría la colina hasta el sendero bordeado por los imponentes eucaliptos, pasando la última farola solitaria, siguiendo el camino iluminado solo por la luz de la luna. A diferencia de los lugares más ruidosos de la Tierra, aquí las estrellas podrían salir a tomar aire, y los árboles cantarían con claridad entre sí. Y yo podría pensar, cuestionar, pero quizás con menos de esa neblina sofocante sobre mi mente."

    # game/books.rpy:503
    old "What does it mean to be alive? Is it having breath in my lungs, a spasming heart dragging blood through my veins, or pulses of electricity and chemicals screaming through my brain?"
    new "¿Qué significa estar vivo? ¿Es tener aire en los pulmones, un corazón espasmódico arrastrando sangre por mis venas, o pulsos de electricidad y químicos gritando en mi cerebro?"

    # game/books.rpy:504
    old "Some would argue that that isn’t enough to classify living, that I need to have a spark — a desire — for music, adventure, or my connections with other living beings. What happens if I had a spark and then lost it? Had it stolen away from me?"
    new "Algunos dirían que eso no es suficiente para clasificar la vida, que necesito tener una chispa —un deseo— por la música, la aventura o mis conexiones con otros seres vivos. ¿Qué pasa si tuve esa chispa y luego la perdí? ¿Si me la arrebataron?"

    # game/books.rpy:505
    old "How do I find a spark? Even if it’s just one thing, one small hope. The universe expands far beyond the reaches of my touch with many things to latch on to and deepen my ties with. How do I choose which flames to feed when it all feels so far away, and my bonds are already threadbare?"
    new "¿Cómo encuentro una chispa? Aunque sea solo una cosa, una pequeña esperanza. El universo se expande mucho más allá de lo que alcanzo a tocar, con tantas cosas a las que aferrarme y con las que profundizar mis lazos. ¿Cómo elijo qué llamas alimentar cuando todo parece tan lejano y mis vínculos ya están desgastados?"

    # game/books.rpy:506
    old "As I would brush past the trees bringing me the breath in my lungs, their gentle leaves like fingers reaching to cup my face and wipe away my very real tears, it would be hard to deny that there are innumerable connections. But how do I reach back—and should I?"
    new "Al rozar los árboles que me dan el aire en mis pulmones, con sus hojas suaves como dedos que alcanzan mi rostro y secan mis lágrimas verdaderas, sería difícil negar que existen innumerables conexiones. Pero ¿cómo devuelvo el gesto—y debería hacerlo?"

    # game/books.rpy:507
    old "What is and isn’t safe isn’t always noticeable at first glance. Still, if I wait too long to peer into the dark, something that could’ve been beautiful could snap under the weight of my suspicions, its ends fluttering away in the breeze, never to be snatched back again."
    new "Lo que es o no es seguro no siempre se nota a primera vista. Aun así, si espero demasiado para mirar en la oscuridad, algo que podría haber sido hermoso podría romperse bajo el peso de mis sospechas, y sus extremos se perderían flotando en la brisa, sin posibilidad de recuperarlos."

    # game/books.rpy:508
    old "Pausing to choose whether to continue onwards or diverge off onto raw soil leading to a stream, the gentle trickle ushering in peace would also warn of danger, of suffocation. But peering into its dark waters, it would only ever reflect the desire drowned within myself—the talent buried below my surface."
    new "Al detenerme para elegir entre seguir adelante o desviarme hacia la tierra cruda que conduce a un arroyo, su suave murmullo de paz también advertiría de peligro, de asfixia. Pero al mirar en sus aguas oscuras, solo reflejaría el deseo ahogado en mí mismo—el talento enterrado bajo mi superficie."

    # game/books.rpy:509
    old "But what if I am scared to drown? To be so totally consumed by one’s passion takes dedication. And careful planning. Water will cling to my skin and soak in, altering my texture long after I have dried off. What happens if after the creek has dried up until a more favourable season, I find something that lights a greater fire in my heart than before, but now delicate threads slip through my wrinkled fingers? "
    new "¿Pero qué pasa si tengo miedo de ahogarme? Ser consumido totalmente por la pasión requiere dedicación. Y una planificación cuidadosa. El agua se aferrará a mi piel y se absorberá, alterando mi textura mucho después de que me haya secado. ¿Qué pasa si, después de que el arroyo se seque hasta una temporada más favorable, encuentro algo que encienda un fuego aún mayor en mi corazón, pero ahora los hilos delicados se escurren entre mis dedos arrugados?"

    # game/books.rpy:510
    old "What happens when my brain and body differ from those around me, and I have no one to guide my search to the start of a thread made just right for me? How do I decide the right kind or colour of the material, learn how to wind each fibre together or even just overcome the boundaries placed before me to create?"
    new "¿Qué pasa cuando mi mente y mi cuerpo difieren de los que me rodean, y no tengo a nadie que guíe mi búsqueda hasta el inicio de un hilo hecho justo para mí? ¿Cómo decido el tipo o el color adecuado del material, aprendo a hilar cada fibra o incluso a superar las barreras que tengo delante para crear?"

    # game/books.rpy:511
    old "Say I decided I knew what to look for with certainty or stumbled upon it in an act of good fortune. I had found the stream on the off-beaten track, pushing through the trees’ warning arms that would keep my breath in my lungs but snuff out the light. I would notice my heart beating with purpose, my breaths coming faster in anticipation, and my brain flooding with bliss, informing me that what I had found was just right. How do I reach for it? Or them? How do I deepen my bonds to the world around me, especially to what I long for? How do I become comfortable, not overwhelmed?"
    new "Supongamos que decidí saber con certeza lo que buscaba o me topé con ello por fortuna. Habría encontrado el arroyo en un sendero poco transitado, empujando los brazos de advertencia de los árboles que mantenían el aire en mis pulmones pero apagaban la luz. Notaría mi corazón latiendo con propósito, mis respiraciones aceleradas por la anticipación y mi mente inundada de dicha, informándome de que lo que encontré era lo correcto. ¿Cómo lo alcanzo? ¿O los alcanzo? ¿Cómo profundizo mis lazos con el mundo que me rodea, especialmente con lo que anhelo? ¿Cómo me vuelvo cómodo, no abrumado?"

    # game/books.rpy:512
    old "Looking around at all the vitality spiralling out from the stream, all its interconnected beating hearts and rustling leaves, I would find that I have even more questions. The hardest part comes when I’ve reached my home, my purpose. It’s not in the finding. How do I keep ahold of the fragile threads twirled around my fingers? Life has a way of wearing any threads bare, how do I reinforce them to withstand the weight of time? "
    new "Al mirar alrededor toda la vitalidad que brota en espiral del arroyo, todos sus corazones latiendo e interconectados y sus hojas susurrantes, descubriría que tengo aún más preguntas. La parte más difícil llega cuando he alcanzado mi hogar, mi propósito. No está en el hallazgo. ¿Cómo mantengo los frágiles hilos enredados en mis dedos? La vida tiene la forma de desgastar cualquier hilo, ¿cómo los refuerzo para soportar el peso del tiempo?"

    # game/books.rpy:513
    old "Hopefully, with my pyre blazing bright in my chest, I can find out. Forging more pieces of string from pure will alone and winding them all together to build a rope can be possible. Then, I can use that rope to drag myself ever further through my passions, feeding it to the flames until nothing is left to burn."
    new "Con suerte, con mi pira ardiendo intensamente en mi pecho, puedo descubrirlo. Forjar más hilos solo con pura voluntad y entrelazarlos todos para formar una cuerda puede ser posible. Entonces, podría usar esa cuerda para arrastrarme cada vez más lejos a través de mis pasiones, alimentándola a las llamas hasta que no quede nada por quemar."

    # game/books.rpy:514
    old "And as the Earth unspools on its doomed dance of passion, the sun will eventually demand the life left in the bones of the planets it forged, dragging them in by invisible ropes too massive to ignore. The universe will then ignite something new. Something bright and unignorable. By that time, the matter that makes me, me, and the substance that made my spark dazzle, both as they were, will have disappeared. Reformed into something or someone new, maybe. But I’ve realised that nothing will change that every moment I breathe, every beat of my heart, from that moment I found my spark or my spark found me, it will be what made me alive. Or at least, I now dream it will."
    new "Y mientras la Tierra se desenrolla en su condenada danza de pasión, el sol acabará por reclamar la vida que queda en los huesos de los planetas que forjó, arrastrándolos con cuerdas invisibles demasiado masivas para ignorarlas. El universo entonces encenderá algo nuevo. Algo brillante e ineludible. Para entonces, la materia que me forma a mí y la sustancia que hizo brillar mi chispa, tal como eran, habrán desaparecido. Reformadas quizá en algo o alguien nuevo. Pero me he dado cuenta de que nada cambiará el hecho de que cada momento que respiro, cada latido de mi corazón, desde ese instante en que encontré mi chispa o mi chispa me encontró a mí, será lo que me hizo estar vivo. O al menos, ahora sueño que lo será."

    # game/books.rpy:515
    old "- A. C. Capra"
    new "- A. C. Capra"

    # game/books.rpy:526
    old "{i}Mourning{/i}"
    new "{i}Luto{/i}"

    # game/books.rpy:543
    old "Sometimes when I wake, I forget the conversations we had in my dreams weren’t real. It makes me remember that someday, I’ll have to distort my memories to see you. I dwell on it, but still can’t manage to make the most of the time we have. I wonder if I’ll end up the memory first. "
    new "A veces, cuando despierto, olvido que las conversaciones que tuvimos en mis sueños no fueron reales. Me hace recordar que algún día tendré que distorsionar mis recuerdos para poder verte. Lo rumio, pero aún no logro aprovechar al máximo el tiempo que tenemos. Me pregunto si acabaré siendo yo el recuerdo primero."

    # game/books.rpy:544
    old "***"
    new "***"

    # game/books.rpy:545
    old "We take turns yelling into a shallow lake, and it ripples out in ways that rewrite years. The ground is still unstable, islands having drifted back together, anchored close enough to walk across. We drift from side-by-side to a mile away in dense fog. So sometimes we toss stones and listen for the call-response of stones hitting water, and other times the silence is all."
    new "Nos turnamos para gritar en un lago poco profundo, y las ondas se expanden reescribiendo años. El terreno sigue inestable, islas que han vuelto a juntarse, ancladas lo bastante cerca para cruzarlas a pie. Pasamos de estar lado a lado a estar a una milla de distancia en una niebla densa. Así que a veces lanzamos piedras y escuchamos el diálogo de los golpes sobre el agua, y otras veces solo reina el silencio."

    # game/books.rpy:547
    old "Then we’re on a ledge, separated by a pane of glass, and it distorts everything. Halfway down a cliff-face, on an unreliable outcropping. Too small. The river below too strained. There’s nothing to be done but to write on the glass and play deranged charades until we can compensate for the distortion. We have most of it figured out, but the separation is still clear, and sometimes it’s too much. When it is, we just sit there. Sometimes I think the glass is one-way. "
    new "Entonces estamos en un saliente, separados por un cristal, y todo se distorsiona. A mitad de la pared de un acantilado, en un saliente poco fiable. Demasiado pequeño. El río abajo demasiado agitado. No hay más que escribir en el cristal y jugar a mímicas desquiciadas hasta lograr compensar la distorsión. Tenemos la mayor parte resuelta, pero la separación sigue siendo evidente, y a veces es demasiado. Cuando eso sucede, nos quedamos sentados. A veces creo que el cristal es unidireccional."

    # game/books.rpy:549
    old "I’m building a bridge somewhere that doesn’t need one. The pieces are all worn and some are a bit rotten, but not all of them. My dad is building the bridge from the other side, and his pieces aren’t much better, mismatched stone and brick. Many are chipped and cracked, the mortar too dry or wet. But the bridge holds, and we work toward the middle. He looks over at me now again with his usual half-smile and I smile back. It’s nice. It’s messy and unstable and an architect’s worst nightmare, but it doesn’t matter. Even if it bends and creaks, it’ll survive a storm."
    new "Estoy construyendo un puente en algún lugar que no lo necesita. Las piezas están gastadas y algunas un poco podridas, pero no todas. Mi papá construye el puente desde el otro lado, y sus piezas no son mucho mejores: piedra y ladrillo desparejados. Muchas están astilladas y agrietadas, el mortero demasiado seco o demasiado húmedo. Pero el puente se sostiene, y trabajamos hacia el centro. Me mira ahora otra vez con su acostumbrada media sonrisa y yo le devuelvo la sonrisa. Es agradable. Es desordenado e inestable y la pesadilla de cualquier arquitecto, pero no importa. Aunque se doble y crujan las tablas, resistirá la tormenta."

    # game/books.rpy:551
    old "I’m sitting atop some grand redwood, looking down, and there he is, below, staring back. He hates heights. “You’re not usually here,” I say."
    new "Estoy sentada en la cima de una imponente secuoya, mirando hacia abajo, y ahí está él, abajo, devolviendo la mirada. Odia las alturas. 'Normalmente no estás aquí', digo."

    # game/books.rpy:552
    old "“I’d like to be.” "
    new "'Me gustaría estarlo.'"

    # game/books.rpy:553
    old "I smile and climb down. I didn’t want to try flying this time anyway. He hums out-of-tune and I laugh, just a little."
    new "Sonrío y bajo. De todos modos, esta vez no quería intentar volar. Él tararea desafinado y yo río, solo un poco."

    # game/books.rpy:554
    old "Then I fall, because I’m prone to it, and I look down to see sunny pavement leading to ferry docks. Dad sighs. “I told you not to run.” And the day before and the day before and the day before. My brother is out ahead and I’m so very young. I cry because my knees are scraped and it hurts and I’m young. I’m up and walking beside my dad, and he holds my hand. Tomorrow I’ll be running again, and falling again. And the day after and the day after."
    new "Luego caigo, porque soy propensa a ello, y miro abajo para ver un pavimento soleado que conduce a los muelles del ferry. Papá suspira. 'Te dije que no corrieras.' Y el día anterior y el anterior y el anterior. Mi hermano va adelante y yo soy tan joven. Lloro porque mis rodillas están raspadas y duele y soy joven. Me levanto y camino junto a mi papá, y él sostiene mi mano. Mañana volveré a correr, y a caer otra vez. Y al día siguiente y al siguiente."

    # game/books.rpy:556
    old "I’m old enough to not need to run. We’re in an art gallery and he’s regaling an art history class. He reads every plaque next to the empty display spaces. All the information and history that bores me to death. There’s nothing to see, just walls that don’t even hold the dust echoes of stolen artwork. Glass display cases that only scream the light they reflect. "
    new "Soy lo bastante mayor como para no necesitar correr. Estamos en una galería de arte y él entretiene a una clase de historia del arte. Lee cada placa junto a los espacios vacíos de exposición. Toda la información e historia que me aburre hasta la muerte. No hay nada que ver, solo paredes que ni siquiera conservan los ecos polvorientos de obras robadas. Vitrinas de vidrio que solo gritan con la luz que reflejan."

    # game/books.rpy:557
    old "I’m bored to death and back. But don’t say a word of it. Listening. Just like he does for me, though surely it’s just as boring."
    new "Me aburro a morir y más. Pero no digo ni una palabra. Escucho. Igual que él lo hace por mí, aunque seguro que a él también le resulta igual de aburrido."

    # game/books.rpy:558
    old "There’s one sculpture. It’s a coin, with my face on one side, his on the other. It’s rare, and he knows everything about it, telling me how valuable it is. I nod along, all the while wondering who would’ve made such a thing. Is it more art than coin? Which side would it more likely land on?"
    new "Hay una escultura. Es una moneda, con mi rostro en una cara y el suyo en la otra. Es rara, y él lo sabe todo sobre ella, contándome lo valiosa que es. Yo asiento, mientras me pregunto quién habría hecho algo así. ¿Es más arte que moneda? ¿En qué cara es más probable que caiga?"

    # game/books.rpy:560
    old "We’re sitting in a car, and I’m in the driver’s seat. We’re at a red light, but it’s going to stay red forever. “You should be mad at me,” I say."
    new "Estamos sentados en un coche, y yo estoy en el asiento del conductor. Estamos en un semáforo en rojo, pero va a quedarse en rojo para siempre. 'Deberías estar enfadado conmigo', digo."

    # game/books.rpy:561
    old "“I’m not. A little annoyed, maybe, but not mad.”"
    new "'No lo estoy. Un poco molesto, quizá, pero no enfadado.'"

    # game/books.rpy:562
    old "I smile, but somehow him saying that makes me feel guilty. It’d be better if he were mad, I think. “Why not?”"
    new "Sonrío, pero de algún modo que él lo diga me hace sentir culpable. Sería mejor si estuviera enfadado, pienso. '¿Por qué no?'"

    # game/books.rpy:563
    old "“Because it’s not a big deal. It’s not worth being angry over,” he says. He turns and looks at me with his signature half-smile. The light turns green."
    new "'Porque no es gran cosa. No vale la pena enfadarse por ello', dice. Se gira y me mira con su media sonrisa característica. El semáforo se pone en verde."

    # game/books.rpy:565
    old "We’re in one of the houses we’ve lived in before. It’s a basement crossed with a living room, with only an unfamiliar grandfather clock, hanging from the middle of the ceiling. We’re sitting in front of it, me on the floor, my dad in a chair. I see his reflection in the pendulum, and he taps his foot out-of-sync with its rhythm. I’m only watching. Listening. Sometimes his tapping lines up with the clock, but it mostly doesn’t. I start tapping my fingers along to both, indecisive. I switch between. One, the other, both. It’s uneven and chaotic. I keep at it."
    new "Estamos en una de las casas en las que hemos vivido antes. Es un sótano cruzado con una sala, con solo un desconocido reloj de péndulo colgando del centro del techo. Estamos sentados frente a él, yo en el suelo, mi papá en una silla. Veo su reflejo en el péndulo, y él golpea el pie fuera de ritmo con su compás. Solo observo. Escucho. A veces su golpeteo coincide con el reloj, pero la mayor parte del tiempo no. Empiezo a golpear con los dedos al compás de ambos, indecisa. Cambio entre uno, otro, ambos. Es desigual y caótico. Sigo insistiendo."

    # game/books.rpy:567
    old "It’s when we’re driving down the freeway, there on the shoulder. Rolled on its side and unmoving. Something tells me it’s me. And I wonder what it’s like, the last moments. Did it know that it was dying? Does it perceive pain the same, with fear and confusion? I feel like I know your memories, watching the river of lights, too fast to follow, flowing over the midnight pavement between slowing blinks."
    new "Es cuando vamos por la autopista, allí en el arcén. Volcado de lado e inmóvil. Algo me dice que soy yo. Y me pregunto cómo son los últimos instantes. ¿Sabía que estaba muriendo? ¿Percibe el dolor igual, con miedo y confusión? Siento como si conociera tus recuerdos, viendo el río de luces, demasiado rápido para seguirlo, fluyendo sobre el pavimento de medianoche entre parpadeos que se ralentizan."

    # game/books.rpy:568
    old "Stumbling toward the long dark, sluggish and growing cold. Bloodless. Falling to lie in wait for dawn. The sensation of fading, slow, into the never waking. Will they remember me once my blood and bones have gone? Did you know you were dying? That your legs would never again hold your weight? Do you, like the crows and elephants, comprehend death and mourn? Who will mourn for us? I think I am already mourning myself."
    new "Tambaleándome hacia la larga oscuridad, lenta y enfriándose. Sin sangre. Cayendo para esperar el amanecer. La sensación de desvanecerse, despacio, hacia el nunca despertar. ¿Me recordarán una vez que mi sangre y mis huesos se hayan ido? ¿Sabías que estabas muriendo? ¿Que tus piernas nunca volverían a sostener tu peso? ¿Comprendes, como los cuervos y los elefantes, la muerte y el duelo? ¿Quién llorará por nosotros? Creo que ya me estoy llorando a mí misma."

    # game/books.rpy:569
    old "- Silica Gel"
    new "- Silica Gel"

    # game/books.rpy:581
    old "{i}A Guidebook to Living with Your Very Own Immortal{/i}"
    new "{i}Una guía para vivir con tu propio inmortal{/i}"

    # game/books.rpy:598
    old "Round One: Fight!"
    new "Primera ronda: ¡Pelea!"

    # game/books.rpy:599
    old "Wait, hold on - don’t fight. Instead just pick your haunt. Do you two want a room with a cemetery view…or is your studio apartment enough? "
    new "Espera, alto ahí, no peleen. Mejor escojan su guarida. ¿Quieren una habitación con vista al cementerio... o su apartamento tipo estudio es suficiente?"

    # game/books.rpy:600
    old "Alright, you two want to move in together - congratulations! But whose astral plane are you living in? "
    new "Muy bien, ustedes dos quieren mudarse juntos, ¡felicitaciones! Pero ¿en qué plano astral van a vivir?"

    # game/books.rpy:601
    old "Wait…you both just agreed unanimously that they were moving in with you? In the human world?"
    new "Esperen... ¿acaban de estar de acuerdo unánimemente en que se mudan contigo? ¿En el mundo humano?"

    # game/books.rpy:602
    old "Oh, okay. Maybe skip this section, then. "
    new "Ah, okey. Entonces quizá sáltate esta sección."

    # game/books.rpy:603
    old "We don’t really know why you decided to start here, but it seems like your biggest problem has already been solved. We just hope you both have enough room in your existing closet for the sheer volume of hoodies that they own that are all the exact same style. "
    new "No sabemos muy bien por qué decidieron empezar aquí, pero parece que su mayor problema ya está resuelto. Solo esperamos que tengan suficiente espacio en el armario para la enorme cantidad de sudaderas que poseen, todas exactamente del mismo estilo."

    # game/books.rpy:604
    old "They are super fashionable hoodies, though. Maybe you should think about stealing one or two. Or buying one of your own."
    new "Aunque son sudaderas muy a la moda. Tal vez deberías pensar en robarte una o dos. O comprarte una propia."

    # game/books.rpy:605
    old "They look really comfy…"
    new "Se ven muy cómodas…"

    # game/books.rpy:606
    old "Wait, why are you still reading this section? Skip ahead, you have other things to worry about here. Move along."
    new "Espera, ¿por qué sigues leyendo esta sección? Sáltala, tienes otras cosas de qué preocuparte aquí. Sigue adelante."

    # game/books.rpy:607
    old "Do go look up those hoodies, though."
    new "Aunque sí deberías buscar esas sudaderas."

    # game/books.rpy:608
    old "We’re moving on, just for you. Think about this, instead: you both don’t really own a lot of furniture, huh? "
    new "Avancemos, solo por ti. Piensa en esto mejor: en realidad ninguno de los dos tiene muchos muebles, ¿eh?"

    # game/books.rpy:609
    old "Whose bed are you keeping? Whose dresser? Whose art is going on the walls? "
    new "¿De quién conservarán la cama? ¿De quién la cómoda? ¿Qué arte va a ir en las paredes?"

    # game/books.rpy:610
    old "Let’s be honest, you saw their posters. They saw what you had on your own walls. One of you is kinda goth and one of you is kinda…not. How can you meet in the middle? "
    new "Seamos honestos, viste sus pósters. Ellos vieron lo que tenías en tus paredes. Uno de ustedes es medio gótico y el otro es como que... no. ¿Cómo pueden llegar a un punto medio?"

    # game/books.rpy:611
    old "Time to talk about it."
    new "Es momento de hablar de ello."

    # game/books.rpy:612
    old "You really need to figure out a few things. Namely, how many books can be stored on one bookshelf, how many plants are worth keeping alive, and…if you both actually like the fairy lights. "
    new "En serio necesitan aclarar algunas cosas. Como cuántos libros caben en una sola estantería, cuántas plantas vale la pena mantener vivas y... si realmente a ambos les gustan las luces de hadas."

    # game/books.rpy:613
    old "Do it. "
    new "Háganlo."

    # game/books.rpy:614
    old "Now."
    new "Ahora."

    # game/books.rpy:615
    old "Let’s talk about the stuffed animals."
    new "Hablemos de los peluches."

    # game/books.rpy:616
    old "Okay, cool, you know that they have that one plush that is non-negotiable, but have you told them about all the pet toys you have shoved underneath your bed that technically…aren’t just for your pet? We both know that big plushie you’re calling a “pet bed” is your favorite pillow.  "
    new "Okey, genial, sabes que tienen ese peluche que es innegociable, pero ¿ya les contaste de todos los juguetes de mascota que tienes metidos debajo de tu cama y que técnicamente... no son solo para tu mascota? Ambos sabemos que ese peluche gigante al que llamas “cama de mascota” es tu almohada favorita."

    # game/books.rpy:617
    old "Weirdly, we have a feeling that this is more important than the fact that neither of the two of you own a couch. "
    new "Extrañamente, tenemos la sensación de que esto es más importante que el hecho de que ninguno de los dos tenga un sofá."

    # game/books.rpy:618
    old "Think about investing in some sort of storage containers that work for both of you. Between your pet and Your Immortal’s love for anything soft and evil, you’ll run out of space quickly if you don’t find a solution right from the start."
    new "Piensen en invertir en algún tipo de contenedores de almacenamiento que sirvan para ambos. Entre tu mascota y el amor de tu Inmortal por todo lo que sea suave y siniestro, se quedarán sin espacio rápidamente si no encuentran una solución desde el principio."

    # game/books.rpy:619
    old "Solve the shower debate. Normally."
    new "Resuelvan el debate de la ducha. Normalmente."

    # game/books.rpy:620
    old "We all know you joked in those chat messages about sharing a shower, but how serious were you, actually? "
    new "Todos sabemos que bromeaste en esos mensajes de chat sobre compartir la ducha, pero ¿qué tan en serio lo decías?"

    # game/books.rpy:621
    old "You’re a morning person and they’re a night person? Great! "
    new "¿Eres de la mañana y ellos de la noche? ¡Genial!"

    # game/books.rpy:622
    old "Vice versa? Just as excellent! "
    new "¿Al revés? ¡Igual de excelente!"

    # game/books.rpy:623
    old "But what if the two of you overlap? "
    new "¿Pero qué pasa si se superponen?"

    # game/books.rpy:624
    old "Time to make a timetable. Whether that has to be literal or not is up to you. "
    new "Es hora de hacer un horario. Que sea literal o no depende de ustedes."

    # game/books.rpy:625
    old "Either way, figure out a schedule and allow a few instances for…overlapping. Just in case you were serious in your messages. Just in case. We aren’t judging you if you were. "
    new "De cualquier manera, organicen un horario y dejen espacio para algunas... coincidencias. Por si acaso hablabas en serio en tus mensajes. Por si acaso. No los juzgamos si así fue."

    # game/books.rpy:626
    old "We’re all for conserving water, after all.  "
    new "Después de todo, estamos totalmente a favor de conservar el agua."

    # game/books.rpy:627
    old "Round 2: Wait, It’s Not a Fade to Black? Who wrote this?"
    new "Ronda 2: Espera, ¿esto no se funde a negro? ¿Quién escribió esto?"

    # game/books.rpy:628
    old "Do both of you need to eat?"
    new "¿Ambos necesitan comer?"

    # game/books.rpy:629
    old "It’s not an unfair question. They’re an immortal who you originally thought subsided off of the buzz of souls alone. But now this is reality…and you’ve been living your life as a…mostly human being."
    new "No es una pregunta injusta. Ellos son un inmortal que pensabas que se alimentaba solo de la energía de las almas. Pero ahora esta es la realidad... y has estado viviendo tu vida como un... ser mayormente humano."

    # game/books.rpy:630
    old "You’re used to cooking, but what about your Lover? Now might be an important time to talk about your diet vs. theirs and figure out if there is any overlap that needs to be addressed in the weekly shopping visit."
    new "Cocinar ya es costumbre para ti, pero ¿y tu Amante? Ahora podría ser un buen momento para hablar de tu dieta frente a la suya y ver si hay algún punto en común que deba resolverse en la compra semanal."

    # game/books.rpy:631
    old "If you’re very lucky, you might end up surprised. "
    new "Si tienes mucha suerte, podrías llevarte una sorpresa."

    # game/books.rpy:632
    old "Even if they don’t have to eat, consider making a challenge out of having your Lover cook for you. It might offer endless opportunities for the two of you to work together in an environment free of stress that you will grow to love."
    new "Incluso si no necesitan comer, considera proponer como reto que tu Amante cocine para ti. Podría brindarles infinitas oportunidades de trabajar juntos en un ambiente libre de estrés que aprenderán a amar."

    # game/books.rpy:633
    old "Who’s going to be washing all those hoodies and…plushies? What about the pet beds? "
    new "¿Quién va a lavar todas esas sudaderas y... peluches? ¿Y las camas de mascotas?"

    # game/books.rpy:634
    old "So you found out that they magically clean their clothes. Do those powers still exist in your own realm? If they do - great! If not, there are bigger questions. Namely: how do they feel about making the bed by hand? "
    new "Así que descubriste que limpian mágicamente su ropa. ¿Esos poderes siguen existiendo en tu propio mundo? Si es así, ¡genial! Si no, hay preguntas más grandes. Principalmente: ¿qué opinan de tender la cama a mano?"

    # game/books.rpy:635
    old "And, who exactly is folding all those aforementioned hoodies? "
    new "Y, ¿quién exactamente está doblando todas esas sudaderas mencionadas?"

    # game/books.rpy:636
    old "You’re used to your home, but your Love is not. Figure out where the two of you can compromise and which one of you doesn’t mind picking up the chores the other one hates."
    new "Tu hogar ya te resulta familiar, pero a tu Amor no. Descubran en qué pueden ceder y cuál de los dos no tiene problema en asumir las tareas que el otro odia."

    # game/books.rpy:637
    old "We have a feeling both of you have your strengths outside of supporting one another in your life decisions, so don’t be afraid to create dedicated tasks."
    new "Tenemos la sensación de que ambos tienen fortalezas fuera de apoyarse mutuamente en sus decisiones de vida, así que no teman asignar tareas específicas."

    # game/books.rpy:638
    old "They appreciate soft sheets against their skin? Perfect! They’re in charge of laundry."
    new "¿Aprecian las sábanas suaves contra su piel? ¡Perfecto! Ellos se encargan de la lavandería."

    # game/books.rpy:639
    old "You like the way they admire the sunshine against your skin through the early-morning windows? Excellent! "
    new "¿Te gusta la forma en que admiran el sol sobre tu piel a través de las ventanas en la mañana? ¡Excelente!"

    # game/books.rpy:640
    old "You’re in charge of dusting. Sorry, we don’t make the rules."
    new "Tú te encargas de desempolvar. Lo sentimos, no hacemos las reglas."

    # game/books.rpy:641
    old "Not So Friendly Ghosts: who upholds the illusion that you’re both human?  "
    new "Fantasmas no tan amistosos: ¿quién mantiene la ilusión de que ambos son humanos?"

    # game/books.rpy:642
    old "Listen, the neighbors you’ve been eavesdropping on are a reality. "
    new "Escucha, los vecinos a los que has estado espiando son reales."

    # game/books.rpy:643
    old "The two of you need to decide from the beginning whether or not you’re going to admit to them that the two of you aren’t the only non-conventional pairing in the building."
    new "Ustedes dos tienen que decidir desde el principio si van a admitirles que no son la única pareja no convencional en el edificio."

    # game/books.rpy:644
    old "Maybe don’t start the conversation with the fact that you’ve been listening to them since Day One and somehow know all about how their first date was instigated. "
    new "Quizá no empieces la conversación con el hecho de que los has estado escuchando desde el día uno y de alguna manera sabes todo sobre cómo se inició su primera cita."

    # game/books.rpy:645
    old "It also could be important to withhold your own paramour’s job status until you’re sure you can trust them."
    new "También podría ser importante reservarse el estatus laboral de tu amante hasta tener la certeza de que puedes confiar en ellos."

    # game/books.rpy:646
    old "But hey, you know they both like coffee, so maybe starting there is the best decision? "
    new "Pero bueno, sabes que a ambos les gusta el café, así que quizá empezar por ahí sea la mejor decisión."

    # game/books.rpy:647
    old "Consider meeting somewhere public though, just in case your Immortal Love lets something slip when they forget that mortals don’t really have a grasp on what the two of you have going on. "
    new "Consideren reunirse en algún lugar público, por si acaso tu Amor Inmortal deja escapar algo cuando olvida que los mortales realmente no entienden lo que ustedes dos tienen."

    # game/books.rpy:648
    old "They are so lucky you love them. "
    new "Tienen tanta suerte de que los ames."

    # game/books.rpy:649
    old "But never forget that you’re lucky as well, because they love you, too."
    new "Pero nunca olvides que tú también tienes suerte, porque ellos también te aman."

    # game/books.rpy:650
    old "Like a sunflower loves sunshine."
    new "Como un girasol ama la luz del sol."

    # game/books.rpy:651
    old "- Lauren Buczek"
    new "- Lauren Buczek"

    # game/books.rpy:660
    old "{i}Monsters{/i}"
    new "{i}Monstruos{/i}"

    # game/books.rpy:679
    old "You turned us into monsters,"
    new "Nos convertiste en monstruos,"

    # game/books.rpy:680
    old "Shoving us out of the light of day,"
    new "Arrojándonos fuera de la luz del día,"

    # game/books.rpy:681
    old "Existing only in shadows,"
    new "Existiendo solo en las sombras,"

    # game/books.rpy:682
    old "Hidden away in closets to keep safe -"
    new "Escondidos en los armarios para mantenernos a salvo -"

    # game/books.rpy:683
    old "Safe from the violence, safe from the screaming, safe from you."
    new "A salvo de la violencia, a salvo de los gritos, a salvo de ti."

    # game/books.rpy:684
    old "Unmentionables hidden under beds next to our forgotten hopes and unlikely dreams."
    new "Innombrables escondidos bajo las camas junto a nuestras esperanzas olvidadas y sueños improbables."

    # game/books.rpy:685
    old "You told your children stories,"
    new "Les contabas historias a tus hijos,"

    # game/books.rpy:686
    old "Made them fear."
    new "Los hiciste temer."

    # game/books.rpy:687
    old "You named us after the bundle of sticks you burned us on,"
    new "Nos nombraste por el haz de leña en el que nos quemaste,"

    # game/books.rpy:688
    old "Believing us witches."
    new "Creyéndonos brujos."

    # game/books.rpy:689
    old "We are not boogeymen,"
    new "No somos el coco,"

    # game/books.rpy:690
    old "And we never were."
    new "Y nunca lo fuimos."

    # game/books.rpy:691
    old "The monsters here were always you."
    new "Los monstruos aquí siempre fuiste tú."

    # game/books.rpy:692
    old "- Devin Crozier"
    new "- Devin Crozier"

    # game/books.rpy:702
    old "{i}Impulses{/i}"
    new "{i}Impulsos{/i}"

    # game/books.rpy:719
    old "Am I bad? Is that why I'm still here? I stayed didn't I? I've stayed now... how long has it been? At first it was hard. I needed to hunt and eat to survive. At some point that stopped mattering. My body got slow. My limbs got weak. I laid down to rest and never truly moved again. Still I waited. I was told to stay, so I stayed. My meat was consumed by the larger beasts, the smaller took what remained. I witnessed the pale parts buried in snow, defrosted, buried in snow, defrosted, countless times as even they were taken by the vegetation. Here I waited... I was told to stay. For what felt like an eternity I couldn't move anyway. I was just... here. Waiting. Staying. Fulfilling my obligation."
    new "¿Soy malo? ¿Es por eso que todavía estoy aquí? Me quedé, ¿no? Me he quedado ahora... ¿cuánto tiempo ha pasado? Al principio fue duro. Tenía que cazar y comer para sobrevivir. En algún momento eso dejó de importar. Mi cuerpo se volvió lento. Mis extremidades se debilitaron. Me tumbé a descansar y nunca volví a moverme de verdad. Aun así esperé. Me dijeron que me quedara, así que me quedé. Mi carne fue consumida por las bestias más grandes, las más pequeñas tomaron lo que quedó. Vi las partes pálidas enterradas en la nieve, descongeladas, enterradas en la nieve, descongeladas, incontables veces mientras incluso ellas eran tomadas por la vegetación. Aquí esperé... Me dijeron que me quedara. Durante lo que pareció una eternidad no pude moverme de todos modos. Simplemente estaba... aquí. Esperando. Quedándome. Cumpliendo con mi obligación."

    # game/books.rpy:720
    old "He told me to stay. He had never kept me waiting long. When he returned there was always meat and merriment. Meat and merriment. Those were the times I coveted. How long had it been since I tasted either? How long had it been since I moved? Not needing to eat was a plus, but it made this process maddening. Maddening was an interesting way to put it. When I lived and breathed, everything was simple. As time dragged on, I ironically became more conscious of... everything."
    new "Él me dijo que me quedara. Nunca me hizo esperar mucho. Cuando volvía siempre había carne y jolgorio. Carne y jolgorio. Esos eran los tiempos que codiciaba. ¿Cuánto tiempo había pasado desde que probé cualquiera de los dos? ¿Cuánto tiempo había pasado desde que me moví? No necesitar comer era una ventaja, pero hacía que este proceso fuera enloquecedor. Enloquecedor era una manera interesante de decirlo. Cuando vivía y respiraba, todo era simple. A medida que el tiempo se estiraba, irónicamente me volví más consciente de... todo."

    # game/books.rpy:721
    old "Sun rise. Sun set. Moon full. No moon. Fresh flowers. Falling leaves."
    new "Salida del sol. Puesta del sol. Luna llena. Sin luna. Flores frescas. Hojas que caen."

    # game/books.rpy:722
    old "I have to learn to move again. He expects me to hunt and sniff and chase. I need to move. I cant look around... yet I see all around me. I can't sniff, yet I feel the life nearby. Animals, trees, bugs, something smaller. They all move. Why can't I? Was I not good? Was it because I left to eat and drink? I haven't left in what feels like an eternity. He never returned. I stayed. But I need to move. The smallest ones: They move - Wiggle. They float. Is that how I move?"
    new "Tengo que aprender a moverme de nuevo. Él espera que cace, huela y persiga. Necesito moverme. No puedo mirar alrededor... y, sin embargo, veo a mi alrededor. No puedo olfatear, y sin embargo siento la vida cercana. Animales, árboles, insectos, algo más pequeño. Todos se mueven. ¿Por qué no puedo? ¿No fui bueno? ¿Fue porque me fui a comer y beber? No me he ido en lo que parece una eternidad. Él nunca regresó. Me quedé. Pero necesito moverme. Los más pequeños: se mueven — menearse. Flotan. ¿Así es como me muevo?"

    # game/books.rpy:723
    old "Sunrise. Sunset. Full moon. New moon. Fresh snow. Baked earth."
    new "Amanecer. Atardecer. Luna llena. Luna nueva. Nieve fresca. Tierra horneada."

    # game/books.rpy:724
    old "Wiggle. Movement! It feels like glancing. I can sense more in one direction. Less in the other. I can no longer see my pale parts, but I feel them beneath me. Like an anchor they withhold my glance. How can I stay any longer? He must need me. The meat and merriment are gone. His scent has long since faded. My scent no longer exists. Scent! Earth. Grass. Life. Death. The sting of snow. The weight of dew. The burn of sun. The wilt of death. I smell it all! The smallest things wiggle. The bigger things spread. As above, so below. They are rooted to the ground too, yet they push through and make it their own. I feel myself spread as the years pass."
    new "Menear. ¡Movimiento! Se siente como un vistazo. Puedo sentir más en una dirección. Menos en la otra. Ya no puedo ver mis partes pálidas, pero las siento bajo mí. Como un ancla retienen mi mirada. ¿Cómo puedo quedarme más tiempo? Debe necesitarme. La carne y el jolgorio se han ido. Su aroma hace tiempo que se desvaneció. Mi aroma ya no existe. ¡Olor! Tierra. Hierba. Vida. Muerte. El aguijón de la nieve. El peso del rocío. La quemadura del sol. La marchitez de la muerte. ¡Lo huelo todo! Las cosas más pequeñas se mueven. Las cosas mayores se expanden. Como arriba, así abajo. También están arraigadas al suelo, sin embargo se abren paso y lo hacen suyo. Siento que me expando a medida que pasan los años."

    # game/books.rpy:725
    old "Years. That's what these are. The sun fades. The moon fades. The seasons fade. Decades. I've spread to become immense. I was only trying to move, yet now I feel the world move beneath my feet. Feet! For a moment I'm sure I felt the earth, but then it was gone. The smallest things notice me. The spreading things flock to me. The wise things fear me and warn eachother to stay away. Wise things! Not him, though. I hadn't realized there were more wise things here. I can't feel him or smell him. I need to move. Sun fades. Moon fades. How many times have we circled the hearth? I study them now; the wise things avoid me but they can't evade me. They hunt and eat too, but not near me. They crowd together in little rings and bark at eachother with meaning. They use those barks to warn eachother away from here. Still I catch them where I can see occasionally. That's how they do it!"
    new "Años. Eso es lo que son. El sol se desvanece. La luna se desvanece. Las estaciones se desvanecen. Décadas. Me he extendido hasta volverme inmenso. Solo intentaba moverme, pero ahora siento el mundo moverse bajo mis pies. ¡Pies! Por un momento estoy seguro de que sentí la tierra, pero luego desapareció. Las cosas más pequeñas me notan. Las cosas que se extienden acuden a mí. Las cosas sabias me temen y se advierten entre ellas que se mantengan alejadas. ¡Cosas sabias! Pero no él. No me había dado cuenta de que había más cosas sabias aquí. No puedo sentirlo ni olerlo. Necesito moverme. El sol se desvanece. La luna se desvanece. ¿Cuántas veces hemos rodeado el hogar? Ahora las estudio; las cosas sabias me evitan pero no pueden evadirme. También cazan y comen, pero no cerca de mí. Se apiñan en pequeños anillos y se ladran entre sí con significado. Usan esos ladridos para advertirse mutuamente que se alejen de aquí. Aun así las atrapo cuando puedo verlas ocasionalmente. ¡Así es como lo hacen!"

    # game/books.rpy:726
    old "Impulse to signal. Signal to chemical. Chemical to channel. A river becomes an ocean. Who knew that it took so much to STEP! Feet. No fur. Not four. Only 2. I studied the wise things too hard. Will he recognize me? Am I good? Meat and merriment!? The merriment... songs and tales. The meat... I smell it!"
    new "Impulso a señal. Señal a químico. Químico a canal. Un río se vuelve océano. ¡Quién iba a saber que hacía falta tanto para PISAR! Pies. Sin pelaje. No cuatro. Solo 2. Estudié demasiado a las cosas sabias. ¿Me reconocerá? ¿Soy bueno? ¡¿Carne y jolgorio?! El jolgorio... canciones y relatos. La carne... ¡la huelo!"

    # game/books.rpy:727
    old "Impulse. Signal. Chemical. Channel. River. Ocean. Left foot forward."
    new "Impulso. Señal. Químico. Canal. Río. Océano. Pie izquierdo adelante."

    # game/books.rpy:728
    old "Impulse. Signal. Chemical. Channel. River. Ocean. Right foot forward."
    new "Impulso. Señal. Químico. Canal. Río. Océano. Pie derecho adelante."

    # game/books.rpy:729
    old "Ocean. Left. Ocean. Right."
    new "Océano. Izquierda. Océano. Derecha."

    # game/books.rpy:730
    old "Left, right, left, right."
    new "Izquierda, derecha, izquierda, derecha."

    # game/books.rpy:731
    old "Feet step. Hands sway. Eyes see. Ears hear. Nostrils smell. Tongue tastes. Skin feels."
    new "Los pies pisan. Las manos se balancean. Los ojos ven. Los oídos oyen. Las narinas huelen. La lengua prueba. La piel siente."

    # game/books.rpy:732
    old "My bare feet sink into the earth with every step. Those spreading below are pushed down but spring back up as I move on. The smell of meat is pouring out of the nearby ring of trees. Tiny particles of meat and wood which enter my nose and send the impulse to make my mouth water. The sounds of merriment are assailing me. So many wise things... some sing, some dance, some are making the complex sounds I've heard with meaning. All of them are the loudest things I've heard in decades. I reach out with my hand and push against the tree barrier."
    new "Mis pies descalzos se hunden en la tierra con cada paso. Los que se extienden abajo son empujados hacia abajo pero vuelven a brotar mientras sigo avanzando. El olor a carne fluye desde el anillo de árboles cercano. Minúsculas partículas de carne y madera entran en mi nariz y envían el impulso que hace que se me haga agua la boca. Los sonidos del jolgorio me asaltan. Tantas cosas sabias... algunas cantan, otras bailan, algunas emiten los sonidos complejos que he oído con significado. Todas son las cosas más ruidosas que he oído en décadas. Extiendo la mano y empujo contra la barrera de árboles."

    # game/books.rpy:733
    old "The merriment ends as I stumble into their enclosure. I didn't mean to make their huge sticks crash down, but they seem more worried than angry. THEY! My eyes see people! My ears hear screams. My nostrils smell meat! My tongue tastes air. I let out the first sound I've made in centuries. A gasp? A whine? Its not the bold bark I remember. Surely he'll hear it and come running. I found the meat, now you find me! My skin feels cold. Not enough hair. The mankind whine back at me and surround me. Sit! That whine I know. I do my best. Left thigh, right thigh, down! More sounds from the humans. My thighs feel tree. Dead tree. They've been sitting on large cuts of dead trees. The corpses of the trees stayed here but they're not living anymore... these are only their pale parts. Am I... dead? Is he... dead? If so, there's no need to stay or move?"
    new "El jolgorio termina cuando tropiezo dentro de su recinto. No quise hacer que sus enormes palos se vinieran abajo, pero parecen más preocupados que enfadados. ¡ELLOS! ¡Mis ojos ven gente! Mis oídos oyen gritos. ¡Mis narinas huelen carne! Mi lengua prueba el aire. Dejo escapar el primer sonido que he hecho en siglos. ¿Un jadeo? ¿Un gemido? No es el ladrido audaz que recuerdo. Seguramente él lo oirá y vendrá corriendo. ¡Encontré la carne, ahora encuéntrame! Mi piel se siente fría. No suficiente pelo. La humanidad me responde con quejidos y me rodea. ¡Siéntate! Ese quejido lo conozco. Hago lo mejor que puedo. Muslo izquierdo, muslo derecho, ¡abajo! Más sonidos de los humanos. Mis muslos se sienten como árbol. Árbol muerto. Han estado sentados sobre grandes cortes de árboles muertos. Los cadáveres de los árboles permanecieron aquí pero ya no están vivos... estas son solo sus partes pálidas. ¿Estoy... muerto? ¿Él está... muerto? Si es así, ¿no hay necesidad de quedarse o de moverse?"

    # game/books.rpy:734
    old "Eyes close. Body weak. Fade away. I can finally rest. Ocean drains. River runs dry. Chemicals dissipate. Signal fades. All that's left is the source of the impulse. ... Source!? Fuck!"
    new "Los ojos se cierran. El cuerpo débil. Desvanecerse. Por fin puedo descansar. El océano se vacía. El río se seca. Los químicos se disipan. La señal se desvanece. Todo lo que queda es la fuente del impulso. ... ¡¿Fuente?! ¡Maldición!"

    # game/books.rpy:735
    old "- Cúsleácrann - The Hound That Stayed"
    new "- Cúsleácrann - El Sabueso Que Se Quedó"

    # game/books.rpy:746
    old "{i}Blossoms{/i}"
    new "{i}Flores{/i}"

    # game/books.rpy:763
    old "Expressed in bouquets \nAnd tied neatly with a bow \nAre words a flower can speak \nWith no mouth or voice"
    new "Expresadas en ramos \nY atadas con un lazo prolijo \nSon palabras que una flor puede decir \nSin boca ni voz"

    # game/books.rpy:764
    old "Secret messages \nBetween two people \nMeaning hidden in plain sight \nBut hardly plain in sight"
    new "Mensajes secretos \nEntre dos personas \nSignificado oculto a simple vista \nPero difícilmente simple a la vista"

    # game/books.rpy:765
    old "The warmth of a heart reflected \nDeep red and overwhelming \nEasy to speak of \nDifficult to understand"
    new "El calor de un corazón reflejado \nRojo intenso y abrumador \nFácil de mencionar \nDifícil de comprender"

    # game/books.rpy:766
    old "The ache of wanting \nJust out of reach \nAffection flush with absence \nA far away love"
    new "El dolor del deseo \nApenas fuera de alcance \nAfecto teñido de ausencia \nUn amor lejano"

    # game/books.rpy:767
    old "The blazing heat of the sun \nBright and unconstrained light \nAs fierce as a lion \nYet stalwart as any hound"
    new "El ardiente calor del sol \nLuz brillante y sin restricciones \nTan fiera como un león \nY tan leal como cualquier sabueso"

    # game/books.rpy:768
    old "Invisible yet unmistakable \nA message of sentiments \nWhispered in blossoms \nAnd promised in soul"
    new "Invisible pero inconfundible \nUn mensaje de sentimientos \nSusurrado en flores \nY prometido en el alma"

    # game/books.rpy:769
    old "- Mika Akatsuka"
    new "- Mika Akatsuka"

