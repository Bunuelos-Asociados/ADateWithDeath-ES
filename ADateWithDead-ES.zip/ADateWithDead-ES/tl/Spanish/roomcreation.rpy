# TODO: Translation updated at 2026-10-15 18:36

translate Spanish strings:

    # game/roomcreation.rpy:74
    old "Wall Color"
    new "Color - Pared"

    # game/roomcreation.rpy:113
    old "Desk Decor"
    new "Escritorio"

    # game/roomcreation.rpy:140
    old "Bed Color"
    new "Color - Cama"

    # game/roomcreation.rpy:171
    old "Room Decor"
    new "Habitación"

    # game/roomcreation.rpy:181
    old "Polaroid Set"
    new "Set Polaroid"

    # game/roomcreation.rpy:240
    old "Fairylights Set"
    new "Set Luces"

    # game/roomcreation.rpy:280
    old "Plant Lover Set"
    new "Set Plantas"

    # game/roomcreation.rpy:338
    old "Posters Set"
    new "Set Pósters"

    # game/roomcreation.rpy:410
    old "Neat Set"
    new "Set Ordenado"

