# TODO: Translation updated at 2026-10-15 18:36

translate Spanish strings:

    # game/computer.rpy:13
    old "Wallpapers"
    new "Fondos"

    # game/computer.rpy:17
    old "Music"
    new "Música"

    # game/computer.rpy:21
    old "Paint"
    new "Pintura"

    # game/computer.rpy:25
    old "Chatroom"
    new "Chat"

    # game/computer.rpy:35
    old "Gallery"
    new "Galería"

    # game/computer.rpy:39
    old "Internet"
    new "Internet"

    # game/computer.rpy:45
    old "Games"
    new "Juegos"

    # game/computer.rpy:68
    old "Leave"
    new "Salir"

    # game/computer.rpy:96
    old "Cloudy"
    new "Nublado"

    # game/computer.rpy:118
    old "Sunny"
    new "Soleado"

    # game/computer.rpy:390
    old "Your past was filled with comfort and contentment."
    new "Tu pasado estuvo lleno de comodidad y satisfacción."

    # game/computer.rpy:392
    old "Your past was filled with curiousity."
    new "Tu pasado estuvo lleno de curiosidad."

    # game/computer.rpy:394
    old "Your past was filled with catnaps."
    new "Tu pasado estuvo lleno de siestas gatunas."

    # game/computer.rpy:396
    old "Your past was filled with playfulness."
    new "Tu pasado estuvo lleno de espíritu juguetón."

    # game/computer.rpy:398
    old "Your past was filled with frustration, which you overcame."
    new "Tu pasado estuvo lleno de frustraciones, que lograste superar."

    # game/computer.rpy:400
    old "In the past, you were always a clever kitten."
    new "En el pasado, siempre fuiste un gatito ingenioso."

    # game/computer.rpy:402
    old "In the past, you were overcome with projects."
    new "En el pasado, los proyectos te desbordaban."

    # game/computer.rpy:404
    old "In the past, you bounced back from plenty of problems."
    new "En el pasado, te recuperaste de muchos problemas."

    # game/computer.rpy:406
    old "In the past, you were always wildly perceptive."
    new "En el pasado, tu percepción siempre fue asombrosa."

    # game/computer.rpy:408
    old "In the past, you loved competition."
    new "En el pasado, amabas la competencia."

    # game/computer.rpy:411
    old "Right now, you're like a content cat, lounging in the sunbeam of life."
    new "Ahora mismo eres como un gato satisfecho, descansando en el rayo de sol de la vida."

    # game/computer.rpy:413
    old "Your curiosity is at its peak, akin to a kitten chasing mysterious shadows."
    new "Tu curiosidad está en su punto más alto, como un gatito persiguiendo sombras misteriosas."

    # game/computer.rpy:415
    old "Currently, you're in need of a catnap – a break from the hustle and bustle of life."
    new "Actualmente necesitas una siesta gatuna: un descanso del ajetreo de la vida."

    # game/computer.rpy:417
    old "Your playfulness knows no bounds, much like a kitten chasing its tail."
    new "Tu espíritu juguetón no conoce límites, como un gatito persiguiendo su cola."

    # game/computer.rpy:419
    old "Life's annoyances are like an itch, and you're ready to scratch them away."
    new "Las molestias de la vida son como una picazón, y te dispones a rascarlas."

    # game/computer.rpy:421
    old "Your wit and resourcefulness shine bright, resembling a cat plotting its next mischief."
    new "Tu ingenio y astucia brillan, como un gato tramando su próxima travesura."

    # game/computer.rpy:423
    old "You're entangled in life's exciting projects, like a kitten wrapped in a ball of yarn."
    new "Estás enredado en proyectos emocionantes de la vida, como un gatito envuelto en un ovillo de lana."

    # game/computer.rpy:425
    old "You're currently being resilient against powers that work against you."
    new "Actualmente demuestras resiliencia frente a fuerzas que actúan contra ti."

    # game/computer.rpy:427
    old "Your intuition is sharp, mirroring a cat's keen gaze in the dark."
    new "Tu intuición es aguda, como la mirada penetrante de un gato en la oscuridad."

    # game/computer.rpy:429
    old "You're tackling life's challenges with the playfulness of a cat chasing a mouse."
    new "Enfrentas los retos de la vida con la picardía de un gato persiguiendo un ratón."

    # game/computer.rpy:432
    old "In the future, you'll find the ultimate state of contentment, much like a cat in a cozy sunbeam."
    new "En el futuro alcanzarás el máximo estado de satisfacción, como un gato en un rayo de sol acogedor."

    # game/computer.rpy:434
    old "Your curiosity will lead you on an adventure in the days to come."
    new "Tu curiosidad te llevará a una aventura en los días venideros."

    # game/computer.rpy:436
    old "A peaceful catnap in your future indicates rest and rejuvenation."
    new "Una tranquila siesta gatuna en tu futuro indica descanso y renovación."

    # game/computer.rpy:438
    old "Your playfulness will be your guiding star."
    new "Tu espíritu juguetón será tu estrella guía."

    # game/computer.rpy:440
    old "In the future, you'll scratch away life's annoyances."
    new "En el futuro, rascarás las molestias de la vida."

    # game/computer.rpy:442
    old "Your future holds moments of wit and resourcefulness, much like a cat plotting its next adventure."
    new "Tu futuro traerá momentos de ingenio y astucia, como un gato planeando su próxima aventura."

    # game/computer.rpy:444
    old "In the days to come, you'll be entranced by life's colorful threads."
    new "En los días por venir, los hilos coloridos de la vida te fascinarán."

    # game/computer.rpy:446
    old "Resilience will be your hallmark in the future."
    new "La resiliencia será tu sello en el futuro."

    # game/computer.rpy:448
    old "In the future, you will need to depend on your intuition to have a favorable outcome to your bet."
    new "En el futuro, deberás confiar en tu intuición para lograr un desenlace favorable en tu apuesta."

    # game/computer.rpy:450
    old "Your future promises fun challenges, like a cat chasing a mouse."
    new "Tu futuro promete retos divertidos, como un gato persiguiendo un ratón."

    # game/computer.rpy:645
    old "Past"
    new "Pasado"

    # game/computer.rpy:646
    old "Present"
    new "Presente"

    # game/computer.rpy:647
    old "Future"
    new "Futuro"

    # game/computer.rpy:720
    old "minesweeper"
    new "Buscaminas"

    # game/computer.rpy:741
    old "{color=e91019}RESET{/color}"
    new "{color=e91019}REINICIAR{/color}"

    # game/computer.rpy:766
    old "Yes."
    new "Sí."

    # game/computer.rpy:770
    old "Ask again tomorrow."
    new "Pregunta de nuevo mañana."

    # game/computer.rpy:773
    old "No."
    new "No."

    # game/computer.rpy:776
    old "Did you really need a test for this?"
    new "¿De verdad necesitabas una prueba para esto?"

    # game/computer.rpy:779
    old "Nope, your computer is on strike today. Just kidding, it's on, obviously."
    new "Nop, tu computadora está en huelga hoy. Es broma, obviamente está encendida."

    # game/computer.rpy:782
    old "Try turning it on and off again."
    new "Intenta apagarla y encenderla de nuevo."

    # game/computer.rpy:785
    old "Is a hot dog a sandwich? Irrelevant, but your computer is definitely on."
    new "¿Un hot dog es un sándwich? Irrelevante, pero tu computadora está encendida."

    # game/computer.rpy:788
    old "On? Yes. Off? No."
    new "¿Encendida? Sí. ¿Apagada? No."

    # game/computer.rpy:791
    old "If you're reading this, I hope you have a wonderful day. Also, yes."
    new "Si estás leyendo esto, espero que tengas un día maravilloso. Y sí, está encendida."

    # game/computer.rpy:793
    old "I had a vision, and it's telling me 'yes'."
    new "Tuve una visión y me dice que 'sí'."

    # game/computer.rpy:816
    old "Grim: Feeling a little catty today #KittyCat"
    new "Parca: Hoy ando con vibras gatunas #Gatito"

    # game/computer.rpy:820
    old "Grim: Whoops I seemed to drop something on the floor, \nthanks for picking it up for me!"
    new "Parca: Ups, parece que dejé caer algo al suelo,\n¡gracias por recogerlo por mí!"

    # game/computer.rpy:824
    old "Grim: Oh noooo don't lift my shirt...!"
    new "Parca: Oh nooo, ¡no levantes mi camisa...!"

    # game/computer.rpy:836
    old "Loading, please wait"
    new "Cargando, por favor espera"

    # game/computer.rpy:838
    old "Taking longer than expected"
    new "Está tardando más de lo esperado"

    # game/computer.rpy:840
    old "You're still here, huh?"
    new "¿Aún sigues aquí, eh?"

    # game/computer.rpy:842
    old "Nothing better to do?"
    new "¿No tienes nada mejor que hacer?"

    # game/computer.rpy:844
    old "I hope you don't think there's a reward for waiting"
    new "Espero que no creas que hay una recompensa por esperar"

    # game/computer.rpy:846
    old "There's definitely not"
    new "Definitivamente no la hay"

    # game/computer.rpy:849
    old "You already have the achievement!"
    new "¡Ya tienes el logro!"

    # game/computer.rpy:851
    old "...Fine, click here to take an achievement."
    new "...Está bien, haz clic aquí para obtener un logro."

    # game/computer.rpy:910
    old "Stirred: [spoon_turn_counter]"
    new "Revuelto: [spoon_turn_counter]"

    # game/computer.rpy:969
    old "This will begin the chatroom. Proceed?"
    new "Esto iniciará la sala de chat. ¿Deseas continuar?"

    # game/computer.rpy:1031
    old "Music Player"
    new "Reproductor de música"

    # game/computer.rpy:1045
    old "Collected Images"
    new "Imágenes recopiladas"

    # game/computer.rpy:1066
    old "pong.exe"
    new "pong.exe"

    # game/computer.rpy:1067
    old "runner.exe"
    new "runner.exe"

    # game/computer.rpy:1201
    old "untitled.jpg - Draw"
    new "untitled.jpg - Dibujar"

    # game/computer.rpy:1268
    old "Size"
    new "Tamaño"

    # game/computer.rpy:1279
    old "Do you want to wipe the canvas?"
    new "¿Quieres borrar el lienzo?"

