# TODO: Translation updated at 2026-10-15 18:36

# game/beyond the bet/soulbabyend.rpy:3
translate Spanish dlc_soulbabyend_start_515c800f:

    # center_text "You dream of..."
    center_text "Sueñas con..."

# game/beyond the bet/soulbabyend.rpy:6
translate Spanish dlc_soulbabyend_start_d97281d9:

    # center_text "Connection."
    center_text "Conexión."

# game/beyond the bet/soulbabyend.rpy:7
translate Spanish dlc_soulbabyend_start_a6d45e97:

    # center_text "It's a funny thing to dream about, really."
    center_text "Es algo curioso con lo que soñar, la verdad."

# game/beyond the bet/soulbabyend.rpy:8
translate Spanish dlc_soulbabyend_start_c1f73e2e:

    # center_text "Connections don't usually have forms, and yet you can see it."
    center_text "Las conexiones no suelen tener forma, y aun así puedes verla."

# game/beyond the bet/soulbabyend.rpy:9
translate Spanish dlc_soulbabyend_start_60cd607c:

    # center_text "It's bright and fuzzy around the edges. You reach your hand out, and find it warm and comfortable."
    center_text "Es brillante y difusa en los bordes. Extiendes la mano y la encuentras cálida y reconfortante."

# game/beyond the bet/soulbabyend.rpy:10
translate Spanish dlc_soulbabyend_start_a2248359:

    # center_text "You feel the warmth all throughout your body, like a hug."
    center_text "Sientes el calor por todo el cuerpo, como un abrazo."

# game/beyond the bet/soulbabyend.rpy:11
translate Spanish dlc_soulbabyend_start_1bc966ad:

    # center_text "It feels like Casper. It feels like home."
    center_text "Se siente como Casper. Se siente como estar en casa."

# game/beyond the bet/soulbabyend.rpy:12
translate Spanish dlc_soulbabyend_start_7c074fe5:

    # center_text "It suddenly speeds away from you. You look to the horizon, searching for that connection."
    center_text "De repente se aleja velozmente de ti. Miras hacia el horizonte, buscando esa conexión."

# game/beyond the bet/soulbabyend.rpy:13
translate Spanish dlc_soulbabyend_start_e02698ec:

    # center_text "And there you see Casper."
    center_text "Y ahí ves a Casper."

# game/beyond the bet/soulbabyend.rpy:14
translate Spanish dlc_soulbabyend_start_e02427dd:

    # center_text "Your eyes meet."
    center_text "Sus miradas se encuentran."

# game/beyond the bet/soulbabyend.rpy:15
translate Spanish dlc_soulbabyend_start_dfcdf404:

    # center_text "And once again you feel that warmth."
    center_text "Y una vez más sientes ese calor."

# game/beyond the bet/soulbabyend.rpy:39
translate Spanish dlc_soulbabyend_start_b6bb744a:

    # "You blink open your eyes, still tired from the night before."
    "Abres los ojos parpadeando, todavía cansad[letra] por la noche anterior."

# game/beyond the bet/soulbabyend.rpy:42
translate Spanish dlc_soulbabyend_start_18447391:

    # "For a moment you feel disorientated - this isn't your room, where are you...?"
    "Por un momento te sientes desorientad[letra]: esta no es tu habitación, ¿dónde estás...?"

# game/beyond the bet/soulbabyend.rpy:43
translate Spanish dlc_soulbabyend_start_25d5a7db:

    # "Ah, you think. Right."
    "Ah, piensas. Claro."

# game/beyond the bet/soulbabyend.rpy:44
translate Spanish dlc_soulbabyend_start_db2a3b0d:

    # "It's Casper's room."
    "Es la habitación de Casper."

# game/beyond the bet/soulbabyend.rpy:45
translate Spanish dlc_soulbabyend_start_3a8b9de1:

    # "It's still strange to actually be here. Sure, you saw it on your video calls, but now you're really here."
    "Todavía se siente extraño estar aquí de verdad. Claro, la viste en tus videollamadas, pero ahora estás realmente aquí."

# game/beyond the bet/soulbabyend.rpy:46
translate Spanish dlc_soulbabyend_start_8519c933:

    # "In Casper's room, which is full of Casper's silly little things."
    "En la habitación de Casper, que está llena de las cosillas tontas de Casper."

# game/beyond the bet/soulbabyend.rpy:47
translate Spanish dlc_soulbabyend_start_6df21e4b:

    # "All of his posters, his jars of what look to be skincare, his scythe leaning up against the wall..."
    "Todos sus pósters, sus frascos de lo que parece ser cuidado de la piel, su guadaña apoyada contra la pared..."

# game/beyond the bet/soulbabyend.rpy:48
translate Spanish dlc_soulbabyend_start_18aff788:

    # "These are the things that Casper chose out. Special things to him. It's a nice feeling to be amongst those special things."
    "Estas son las cosas que Casper eligió. Cosas especiales para él. Es agradable estar entre todas esas cosas especiales."

# game/beyond the bet/soulbabyend.rpy:49
translate Spanish dlc_soulbabyend_start_055bac27:

    # "And there he is, you see. Sitting at his desk."
    "Y ahí está él, ves. Sentado en su escritorio."

# game/beyond the bet/soulbabyend.rpy:50
translate Spanish dlc_soulbabyend_start_782bc057:

    # "A warm feeling settles over your chest. Yeah, this is definitely a nice feeling."
    "Una sensación cálida se instala en tu pecho. Sí, definitivamente es una sensación agradable."

# game/beyond the bet/soulbabyend.rpy:51
translate Spanish dlc_soulbabyend_start_0e4e0529:

    # "He hasn't yet noticed that you're awake, but that's okay. It's nice just to watch him for a moment."
    "Aún no ha notado que estás despiert[letra], pero está bien. Es agradable simplemente mirarlo un momento."

# game/beyond the bet/soulbabyend.rpy:52
translate Spanish dlc_soulbabyend_start_99b9b653:

    # "It also feels a little... lonely. "
    "También se siente un poco... solitario. "

# game/beyond the bet/soulbabyend.rpy:53
translate Spanish dlc_soulbabyend_start_4b69df41:

    # "He's been alone in this room... forever?"
    "Ha estado solo en esta habitación... ¿desde siempre?"

# game/beyond the bet/soulbabyend.rpy:54
translate Spanish dlc_soulbabyend_start_8aed4b30:

    # "With no one to lean on. No one to look after him when he was sick with that soulsickness of his."
    "Sin nadie en quien apoyarse. Sin nadie que lo cuidara cuando estaba enfermo con esa Enfermedad del Alma suya."

# game/beyond the bet/soulbabyend.rpy:55
translate Spanish dlc_soulbabyend_start_1bf53335:

    # "If you can be that person for him, well... that would make you very happy."
    "Si puedes ser esa persona para él, bueno... eso te haría muy feliz."

# game/beyond the bet/soulbabyend.rpy:56
translate Spanish dlc_soulbabyend_start_9e509460:

    # "You wonder for a moment when Casper got back."
    "Te preguntas por un momento cuándo volvió Casper."

# game/beyond the bet/soulbabyend.rpy:57
translate Spanish dlc_soulbabyend_start_a2d6418d:

    # "Did he see you sleeping, look down at you with content, then let you sleep just a little bit longer?"
    "¿Te vio dormir, te miró con satisfacción y luego te dejó dormir un poquito más?"

# game/beyond the bet/soulbabyend.rpy:58
translate Spanish dlc_soulbabyend_start_6c6296a8:

    # "Did he tiptoe around the room, careful not to wake you up?"
    "¿Caminó de puntillas por la habitación, con cuidado de no despertarte?"

# game/beyond the bet/soulbabyend.rpy:59
translate Spanish dlc_soulbabyend_start_c117f646:

    # "You sigh, happy. He really is cute."
    "Suspiras, content[letra]. Es realmente lindo."

# game/beyond the bet/soulbabyend.rpy:60
translate Spanish dlc_soulbabyend_start_ca89015c:

    # "His head turns in your direction, and his gaze is soft. Lately, it's always soft when he looks at you. When did that happen?"
    "Gira la cabeza hacia ti y su mirada es suave. Últimamente siempre es suave cuando te mira. ¿Cuándo pasó eso?"

# game/beyond the bet/soulbabyend.rpy:78
translate Spanish dlc_soulbabyend_start_9308f43c:

    # GRC "It's been but a few hours."
    GRC "Han pasado apenas unas horas."

# game/beyond the bet/soulbabyend.rpy:85
translate Spanish dlc_soulbabyend_start_a63299e2:

    # GRC "Time matters little to a reaper, but I do have a clock."
    GRC "El tiempo importa poco para una parca, pero sí tengo un reloj."

# game/beyond the bet/soulbabyend.rpy:86
translate Spanish dlc_soulbabyend_start_e2c70259:

    # GRC "You've been asleep for a few hours."
    GRC "Has dormido unas cuantas horas."

# game/beyond the bet/soulbabyend.rpy:91
translate Spanish dlc_soulbabyend_start_a4a00bee:

    # GRC "Not long ago."
    GRC "Hace poco."

# game/beyond the bet/soulbabyend.rpy:93
translate Spanish dlc_soulbabyend_start_636ec676:

    # GRC "I... disliked the idea of you being here alone."
    GRC "Yo... no me agradaba la idea de que estuvieras aquí sol[letra]."

# game/beyond the bet/soulbabyend.rpy:94
translate Spanish dlc_soulbabyend_start_6518c502:

    # GRC "It is beyond frustrating. If I take you with me, you are in danger. If I leave you here, you are also in danger."
    GRC "Es sumamente frustrante. Si te llevo conmigo, estás en peligro. Si te dejo aquí, también estás en peligro."

# game/beyond the bet/soulbabyend.rpy:96
translate Spanish dlc_soulbabyend_start_2f50d567:

    # GRC "And I... will admit, I do like seeing you in my bed."
    GRC "Y yo... admitiré que sí me gusta verte en mi cama."

# game/beyond the bet/soulbabyend.rpy:97
translate Spanish dlc_soulbabyend_start_b800e09c:

    # GRC "It's almost annoying how much I like it."
    GRC "Es casi molesto cuánto me gusta."

# game/beyond the bet/soulbabyend.rpy:101
translate Spanish dlc_soulbabyend_start_bcbbdaac:

    # GRC "Yes, well, that much should be obvious. I am the best, so I need the best."
    GRC "Sí, bueno, eso debería ser obvio. Soy el mejor, así que necesito lo mejor."

# game/beyond the bet/soulbabyend.rpy:102
translate Spanish dlc_soulbabyend_start_ffd63cf6:

    # GRC "And that is putting Azrael aside. I would not allow him to sleep on a bed riddled with wayward springs."
    GRC "Y eso dejando a Azrael de lado. No permitiría que durmiera en una cama plagada de resortes sueltos."

# game/beyond the bet/soulbabyend.rpy:103
translate Spanish dlc_soulbabyend_start_fdacfec4:

    # GRC "If it is to your taste, then I am... glad."
    GRC "Si es de tu agrado, entonces me... alegra."

# game/beyond the bet/soulbabyend.rpy:117
translate Spanish dlc_soulbabyend_start_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/soulbabyend.rpy:119
translate Spanish dlc_soulbabyend_start_628f1972:

    # GRC "Azrael would not be stolen away from me so easily. He goes where I go."
    GRC "Azrael no me sería arrebatado tan fácilmente. Él va donde yo voy."

# game/beyond the bet/soulbabyend.rpy:127
translate Spanish dlc_soulbabyend_start_c94a0948:

    # GRC "Superstition says bad things do, as well."
    GRC "La superstición dice que las cosas malas también."

# game/beyond the bet/soulbabyend.rpy:140
translate Spanish dlc_soulbabyend_start_c9ea1e27:

    # GRC "Hah! So Azrael is not content with being the best reaper, he also wants to steal you away from me?"
    GRC "¡Ja! ¿Así que Azrael no se conforma con ser la mejor parca, sino que también quiere robarte de mi lado?"

# game/beyond the bet/soulbabyend.rpy:142
translate Spanish dlc_soulbabyend_start_e3dbca34:

    # GRC "I respect that, though I will not allow it."
    GRC "Respeto eso, aunque no lo permitiré."

# game/beyond the bet/soulbabyend.rpy:161
translate Spanish dlc_soulbabyend_start_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/soulbabyend.rpy:162
translate Spanish dlc_soulbabyend_start_d1bcc7fc:

    # GRC "And that one person would be..."
    GRC "Y esa única persona sería..."

# game/beyond the bet/soulbabyend.rpy:168
translate Spanish dlc_soulbabyend_start_6e762138:

    # GRC "What...!"
    GRC "¡Qué...!"

# game/beyond the bet/soulbabyend.rpy:179
translate Spanish dlc_soulbabyend_start_ba2e7048:

    # GRC "You... what?"
    GRC "Tú... ¿qué?"

# game/beyond the bet/soulbabyend.rpy:185
translate Spanish dlc_soulbabyend_start_c6227050:

    # GRC "Would you... not prefer to just... bring some sleeping clothes?"
    GRC "¿No... preferirías simplemente... traer ropa para dormir?"

# game/beyond the bet/soulbabyend.rpy:194
translate Spanish dlc_soulbabyend_start_29e9c144:

    # GRC "I... you are... free to do so if you wish..."
    GRC "Yo... tú... eres libre de hacerlo si así lo deseas..."

# game/beyond the bet/soulbabyend.rpy:198
translate Spanish dlc_soulbabyend_start_008afe10_2:

    # GRC "..."
    GRC "..."

# game/beyond the bet/soulbabyend.rpy:200
translate Spanish dlc_soulbabyend_start_096c2e7c:

    # GRC "It would be best if the next time we... slept near each other... it was at your apartment, however."
    GRC "Sin embargo, sería mejor que la próxima vez que... durmamos cerca el uno del otro... sea en tu apartamento."

# game/beyond the bet/soulbabyend.rpy:205
translate Spanish dlc_soulbabyend_start_83aac3c9:

    # GRC "It's not that..."
    GRC "No es que..."

# game/beyond the bet/soulbabyend.rpy:207
translate Spanish dlc_soulbabyend_start_54388975:

    # GRC "This place is dangerous. I want you alive."
    GRC "Este lugar es peligroso. Te quiero con vida."

# game/beyond the bet/soulbabyend.rpy:212
translate Spanish dlc_soulbabyend_start_bc8921ca:

    # "{i}You see a small smile tug at the corner of his mouth.{/i}"
    "{i}Ves una pequeña sonrisa asomarse en la comisura de sus labios.{/i}"

# game/beyond the bet/soulbabyend.rpy:213
translate Spanish dlc_soulbabyend_start_bd21011e:

    # "{i}He does look slightly tired, actually. Tired, but also determined.{/i}"
    "{i}De hecho, se ve un poco cansado. Cansado, pero también decidido.{/i}"

# game/beyond the bet/soulbabyend.rpy:221
translate Spanish dlc_soulbabyend_start_3217a0b3:

    # GRC "Nothing I did not already know. It is beyond frustrating."
    GRC "Nada que no supiera ya. Es sumamente frustrante."

# game/beyond the bet/soulbabyend.rpy:223
translate Spanish dlc_soulbabyend_start_c37eb99f:

    # GRC "There are so many questions I need answered, and I am certain others would have the same questions, but there is no one to ask."
    GRC "Hay tantas preguntas que necesito que me respondan, y estoy seguro de que otros tendrían las mismas, pero no hay a quién preguntarle."

# game/beyond the bet/soulbabyend.rpy:225
translate Spanish dlc_soulbabyend_start_75e9328e:

    # GRC "...Everyone else who cared is long gone."
    GRC "...Todos los demás a quienes les importaba se fueron hace mucho."

# game/beyond the bet/soulbabyend.rpy:230
translate Spanish dlc_soulbabyend_start_c75c67fe:

    # GRC "I knew... some people who questioned our way of doing things in the past."
    GRC "Conocí... a algunas personas que cuestionaron nuestra manera de hacer las cosas en el pasado."

# game/beyond the bet/soulbabyend.rpy:232
translate Spanish dlc_soulbabyend_start_6f826236:

    # GRC "They were all terminated. My organization does not suffer 'questions'."
    GRC "Todos fueron eliminados. Mi organización no tolera las 'preguntas'."

# game/beyond the bet/soulbabyend.rpy:236
translate Spanish dlc_soulbabyend_start_8aeaf751:

    # GRC "I am the one who is more sorry."
    GRC "Soy yo quien lo lamenta más."

# game/beyond the bet/soulbabyend.rpy:238
translate Spanish dlc_soulbabyend_start_ce1af5ba:

    # GRC "I watched a lot of people go to their death, and I did nothing about it."
    GRC "Vi a muchísima gente ir a su muerte y no hice nada al respecto."

# game/beyond the bet/soulbabyend.rpy:240
translate Spanish dlc_soulbabyend_start_1bcf8bcf:

    # GRC "Perhaps there is not so much fairness in death, after all..."
    GRC "Quizás no haya tanta justicia en la muerte, después de todo..."

# game/beyond the bet/soulbabyend.rpy:250
translate Spanish dlc_soulbabyend_start_008afe10_3:

    # GRC "..."
    GRC "..."

# game/beyond the bet/soulbabyend.rpy:251
translate Spanish dlc_soulbabyend_start_f8358be4:

    # GRC "Maybe."
    GRC "Quizás."

# game/beyond the bet/soulbabyend.rpy:253
translate Spanish dlc_soulbabyend_start_c5fdbafc:

    # GRC "Anyway. I can find no one I can speak to in confidence."
    GRC "En fin. No encuentro a nadie con quien hablar en confianza."

# game/beyond the bet/soulbabyend.rpy:254
translate Spanish dlc_soulbabyend_start_e45895b2:

    # GRC "And if I were to say the wrong thing to the wrong person..."
    GRC "Y si dijera algo indebido a la persona equivocada..."

# game/beyond the bet/soulbabyend.rpy:276
translate Spanish dlc_soulbabyend_start_ff9bf034:

    # GRC "How lovely. I so do love things."
    GRC "Qué encantador. Adoro las cosas."

# game/beyond the bet/soulbabyend.rpy:278
translate Spanish dlc_soulbabyend_start_6dd5c08b:

    # GRC "Are you going to elaborate?"
    GRC "¿Vas a explicarte mejor?"

# game/beyond the bet/soulbabyend.rpy:289
translate Spanish dlc_soulbabyend_start_008afe10_4:

    # GRC "..."
    GRC "..."

# game/beyond the bet/soulbabyend.rpy:290
translate Spanish dlc_soulbabyend_start_afc6c8b5:

    # GRC "What is..."
    GRC "¿Qué es...?"

# game/beyond the bet/soulbabyend.rpy:291
translate Spanish dlc_soulbabyend_start_755ac7ec:

    # GRC "Where did you get this?"
    GRC "¿De dónde sacaste esto?"

# game/beyond the bet/soulbabyend.rpy:299
translate Spanish dlc_soulbabyend_start_effa3324:

    # GRC "Well, you cannot go off on your own. There is no chance I could let you make that choice."
    GRC "Pues no puedes irte por tu cuenta. No hay forma de que te deje tomar esa decisión."

# game/beyond the bet/soulbabyend.rpy:306
translate Spanish dlc_soulbabyend_start_5361e2fc:

    # GRC "Are you crazy?"
    GRC "¿Estás loc[letra]?"

# game/beyond the bet/soulbabyend.rpy:322
translate Spanish dlc_soulbabyend_start_a831b486:

    # GRC "I mean..."
    GRC "Quiero decir..."

# game/beyond the bet/soulbabyend.rpy:335
translate Spanish dlc_soulbabyend_start_5524ff38:

    # GRC "What if they just kill you?"
    GRC "¿Y si simplemente te matan?"

# game/beyond the bet/soulbabyend.rpy:339
translate Spanish dlc_soulbabyend_start_5e0718f2:

    # GRC "But not impossible to kill."
    GRC "Pero no imposible de matar."

# game/beyond the bet/soulbabyend.rpy:347
translate Spanish dlc_soulbabyend_start_c7a311ec:

    # GRC "...It's too much of a risk."
    GRC "...Es demasiado riesgo."

# game/beyond the bet/soulbabyend.rpy:352
translate Spanish dlc_soulbabyend_start_2b37ec09:

    # GRC "Ha...."
    GRC "Ah...."

# game/beyond the bet/soulbabyend.rpy:353
translate Spanish dlc_soulbabyend_start_7f225fdd:

    # GRC "You are my only weakness, Sunshine."
    GRC "Eres mi única debilidad, Solecito."

# game/beyond the bet/soulbabyend.rpy:358
translate Spanish dlc_soulbabyend_start_16f3c56d:

    # GRC "I do not!"
    GRC "¡No lo hago!"

# game/beyond the bet/soulbabyend.rpy:363
translate Spanish dlc_soulbabyend_start_9496cc98:

    # GRC "Gods... this is such a stupid idea..."
    GRC "Dioses... esta es una idea muy estúpida..."

# game/beyond the bet/soulbabyend.rpy:371
translate Spanish dlc_soulbabyend_start_5843b601:

    # GRC "More than you would be able to count."
    GRC "Más de las que podrías contar."

# game/beyond the bet/soulbabyend.rpy:381
translate Spanish dlc_soulbabyend_start_27a8e94f:

    # GRC "Hmmm..."
    GRC "Mmmm..."

# game/beyond the bet/soulbabyend.rpy:382
translate Spanish dlc_soulbabyend_start_5cefc106:

    # GRC "I think there could be something..."
    GRC "Creo que podría haber algo..."

# game/beyond the bet/soulbabyend.rpy:384
translate Spanish dlc_soulbabyend_start_cc448cf6:

    # "{i}You watch Casper cross the room, then pull out a thick, leatherbound book from his shelf.{/i}"
    "{i}Ves a Casper cruzar la habitación y sacar de su estante un libro grueso, encuadernado en cuero.{/i}"

# game/beyond the bet/soulbabyend.rpy:385
translate Spanish dlc_soulbabyend_start_ad053471:

    # "{i}That thing is at least 2000 pages long.{/i}"
    "{i}Esa cosa tiene al menos 2000 páginas.{/i}"

# game/beyond the bet/soulbabyend.rpy:386
translate Spanish dlc_soulbabyend_start_ac8dd316:

    # "{i}It's no longer a book. That thing is a murder weapon.{/i}"
    "{i}Ya no es un libro. Esa cosa es un arma homicida.{/i}"

# game/beyond the bet/soulbabyend.rpy:398
translate Spanish dlc_soulbabyend_start_088e3fd5:

    # GRC "Here..."
    GRC "Toma..."

# game/beyond the bet/soulbabyend.rpy:400
translate Spanish dlc_soulbabyend_start_45c200d9:

    # GRC "We have a lot of old, antiqued laws that technically are followed, but they're forgotten."
    GRC "Tenemos muchas leyes antiguas, anticuadas, que técnicamente se siguen cumpliendo, pero están olvidadas."

# game/beyond the bet/soulbabyend.rpy:401
translate Spanish dlc_soulbabyend_start_7d2e2a36:

    # GRC "If the one hunting you strictly follows the rules, then this may help."
    GRC "Si quien te persigue sigue las reglas al pie de la letra, esto podría ayudar."

# game/beyond the bet/soulbabyend.rpy:405
translate Spanish dlc_soulbabyend_start_1f62f16f:

    # GRC "It's ancient, and rarely invoked as humans do not know it exists."
    GRC "Es antigua y rara vez se invoca, pues los humanos no saben que existe."

# game/beyond the bet/soulbabyend.rpy:406
translate Spanish dlc_soulbabyend_start_ba1aefe2:

    # GRC "When a reaper arrives to take a soul, a human may call upon this law to be aided by the reaper in a specific, final task."
    GRC "Cuando una parca llega para llevarse un alma, un humano puede invocar esta ley para ser ayudado por la parca en una tarea final específica."

# game/beyond the bet/soulbabyend.rpy:407
translate Spanish dlc_soulbabyend_start_557b5e18:

    # GRC "They must help you for exactly one hour before being allowed to take your soul."
    GRC "Deben ayudarte durante exactamente una hora antes de que se les permita llevarse tu alma."

# game/beyond the bet/soulbabyend.rpy:411
translate Spanish dlc_soulbabyend_start_788506ea:

    # GRC "Yes, well, there's a reason it is mostly lost to time."
    GRC "Sí, bueno, hay una razón por la que ha quedado casi perdida en el tiempo."

# game/beyond the bet/soulbabyend.rpy:412
translate Spanish dlc_soulbabyend_start_4de2ee16:

    # GRC "I myself only learned of it recently, while... trying to find some solution to our problem."
    GRC "Yo mismo me enteré hace poco, mientras... intentaba encontrar alguna solución a nuestro problema."

# game/beyond the bet/soulbabyend.rpy:417
translate Spanish dlc_soulbabyend_start_ee9e29e1:

    # GRC "Within reason."
    GRC "Dentro de lo razonable."

# game/beyond the bet/soulbabyend.rpy:419
translate Spanish dlc_soulbabyend_start_48286cfc:

    # GRC "It must be something you can reasonably accomplish, and they have to help however they can."
    GRC "Debe ser algo que puedas lograr de forma razonable, y ellos tienen que ayudar como puedan."

# game/beyond the bet/soulbabyend.rpy:420
translate Spanish dlc_soulbabyend_start_12dae2c1:

    # GRC "But once the hour is up, there is no extending it."
    GRC "Pero una vez que pasa la hora, no se puede extender."

# game/beyond the bet/soulbabyend.rpy:422
translate Spanish dlc_soulbabyend_start_11642700:

    # GRC "You will be forfeiting your soul by using this law." id dlc_soulbabyend_start_11642700
    GRC "Perderás tu alma al usar esta ley." id dlc_soulbabyend_start_11642700

# game/beyond the bet/soulbabyend.rpy:427
translate Spanish dlc_soulbabyend_start_8e94c9f8:

    # GRC "I really should just come with you."
    GRC "De verdad debería ir contigo."

# game/beyond the bet/soulbabyend.rpy:434
translate Spanish dlc_soulbabyend_start_008afe10_5:

    # GRC "..."
    GRC "..."

# game/beyond the bet/soulbabyend.rpy:435
translate Spanish dlc_soulbabyend_start_1756d874:

    # GRC "...Fine."
    GRC "...Está bien."

# game/beyond the bet/soulbabyend.rpy:436
translate Spanish dlc_soulbabyend_start_091a9eba:

    # GRC "Fine, alright, you win... but you must message me if anything goes wrong, and I will be there in an instant."
    GRC "Está bien, de acuerdo, ganas... pero debes escribirme si algo sale mal, y estaré ahí en un instante."

# game/beyond the bet/soulbabyend.rpy:442
translate Spanish dlc_soulbabyend_start_1e84d4ef:

    # "{i}You stand and pick up Casper's jacket that sits by the door, and then turn back to him.{/i}"
    "{i}Te levantas, tomas la chaqueta de Casper que está junto a la puerta y luego te giras hacia él.{/i}"

# game/beyond the bet/soulbabyend.rpy:443
translate Spanish dlc_soulbabyend_start_5cf34f90:

    # "{i}His expression is concerned, and his eyebrows are knitted together.{/i}"
    "{i}Su expresión es de preocupación y tiene el ceño fruncido.{/i}"

# game/beyond the bet/soulbabyend.rpy:459
translate Spanish dlc_soulbabyend_start_c71b2201:

    # GRC "You're the bane of my existence, you know."
    GRC "Eres la perdición de mi existencia, ¿sabes?"

# game/beyond the bet/soulbabyend.rpy:460
translate Spanish dlc_soulbabyend_start_a2f64cfc:

    # GRC "And yet I desire you above all else."
    GRC "Y aun así te deseo por encima de todo."

# game/beyond the bet/soulbabyend.rpy:462
translate Spanish dlc_soulbabyend_start_36f49fd1:

    # GRC "How frustrating."
    GRC "Qué frustrante."

# game/beyond the bet/soulbabyend.rpy:468
translate Spanish dlc_soulbabyend_start_491073ad:

    # GRC "Stay safe, Sunshine. "
    GRC "Cuídate, Solecito. "

# game/beyond the bet/soulbabyend.rpy:469
translate Spanish dlc_soulbabyend_start_be7ff534:

    # GRC "I shall await your message, and then I will be there."
    GRC "Esperaré tu mensaje y entonces estaré ahí."

# game/beyond the bet/soulbabyend.rpy:470
translate Spanish dlc_soulbabyend_start_692fd682:

    # GRC "Don't do anything stupid."
    GRC "No hagas nada estúpido."

# game/beyond the bet/soulbabyend.rpy:478
translate Spanish dlc_soulbabyend_start_be6976f7:

    # "{i}You leave a gentle kiss against Casper's lips, then open the door.{/i}"
    "{i}Dejas un suave beso en los labios de Casper y luego abres la puerta.{/i}"

# game/beyond the bet/soulbabyend.rpy:498
translate Spanish dlc_soulbabyend_start_9de4e837:

    # "You step outside, and keep your head down."
    "Sales y mantienes la cabeza gacha."

# game/beyond the bet/soulbabyend.rpy:500
translate Spanish dlc_soulbabyend_start_cd15b399:

    # "Even though you expected it, it's strange for your body to tell you it's morning, but see only darkness outside."
    "Aunque lo esperabas, es extraño que tu cuerpo te diga que es de mañana y solo veas oscuridad afuera."

# game/beyond the bet/soulbabyend.rpy:501
translate Spanish dlc_soulbabyend_start_63baa8dc:

    # "A small reminder that you're not home."
    "Un pequeño recordatorio de que no estás en casa."

# game/beyond the bet/soulbabyend.rpy:502
translate Spanish dlc_soulbabyend_start_1b59ea9a:

    # "Your hand clasps around the keycard, and you keep walking."
    "Tu mano se aferra a la tarjeta de acceso y sigues caminando."

# game/beyond the bet/soulbabyend.rpy:503
translate Spanish dlc_soulbabyend_start_199d6056:

    # "People pass you by, and you can't help but feel like they're watching you."
    "La gente pasa a tu lado y no puedes evitar sentir que te observan."

# game/beyond the bet/soulbabyend.rpy:504
translate Spanish dlc_soulbabyend_start_6b1cf410:

    # "Are you being too suspicious?"
    "¿Estás levantando demasiadas sospechas?"

# game/beyond the bet/soulbabyend.rpy:505
translate Spanish dlc_soulbabyend_start_aebc9b70:

    # "Is this just a terrible idea?"
    "¿Es simplemente una pésima idea?"

# game/beyond the bet/soulbabyend.rpy:506
translate Spanish dlc_soulbabyend_start_6d5bfafc:

    # "Well, yes, it's a terrible idea, but that's to be expected. It was your idea."
    "Bueno, sí, es una pésima idea, pero es lo esperable. Fue idea tuya."

# game/beyond the bet/soulbabyend.rpy:507
translate Spanish dlc_soulbabyend_start_f549acee:

    # "Terrible ideas are usually the best ones, anyway."
    "Las ideas terribles suelen ser las mejores, de todos modos."

# game/beyond the bet/soulbabyend.rpy:508
translate Spanish dlc_soulbabyend_start_f88b9a07:

    # "You continue onwards, following the surprisingly well made signage."
    "Sigues adelante, guiándote por la señalización, sorprendentemente bien hecha."

# game/beyond the bet/soulbabyend.rpy:509
translate Spanish dlc_soulbabyend_start_8d6299ac:

    # "Whoever designs those in the Underworld needs a raise."
    "Quien diseñe esos carteles en el Inframundo merece un aumento."

# game/beyond the bet/soulbabyend.rpy:510
translate Spanish dlc_soulbabyend_start_c2dc43f3:

    # "Soon enough, you arrive at the building from the description on the keycard."
    "Enseguida llegas al edificio de la descripción de la tarjeta de acceso."

# game/beyond the bet/soulbabyend.rpy:511
translate Spanish dlc_soulbabyend_start_ca268598:

    # "The 'Library of the Lost'."
    "La 'Biblioteca de los Perdidos'."

# game/beyond the bet/soulbabyend.rpy:512
translate Spanish dlc_soulbabyend_start_ac7949be:

    # "There's no one else around."
    "No hay nadie más alrededor."

# game/beyond the bet/soulbabyend.rpy:513
translate Spanish dlc_soulbabyend_start_753f0647:

    # "You walk up to the door and scan your keycard. With a click, the door opens for you, and you go inside."
    "Te acercas a la puerta y escaneas tu tarjeta de acceso. Con un clic, la puerta se abre para ti y entras."

# game/beyond the bet/soulbabyend.rpy:526
translate Spanish dlc_soulbabyend_start_c9f750dd:

    # "The huge library spreads out before you."
    "La enorme biblioteca se extiende ante ti."

# game/beyond the bet/soulbabyend.rpy:543
translate Spanish dlc_soulbabyend_start_5557a5cf:

    # O_ip "You're smarter than I gave you credit for, 'Sunshine'."
    O_ip "Eres más list[letra] de lo que creí, 'Solecito'."

# game/beyond the bet/soulbabyend.rpy:546
translate Spanish dlc_soulbabyend_start_af04890f:

    # O_ip "So quick to blasphemy."
    O_ip "Qué rápido recurres a la blasfemia."

# game/beyond the bet/soulbabyend.rpy:548
translate Spanish dlc_soulbabyend_start_16f9ec87:

    # O_ip "It's fine, I didn't need my eardrums intact."
    O_ip "No importa, no necesitaba mis tímpanos intactos."

# game/beyond the bet/soulbabyend.rpy:551
translate Spanish dlc_soulbabyend_start_7b57fe62:

    # O_ip "Very eloquent."
    O_ip "Muy elocuente."

# game/beyond the bet/soulbabyend.rpy:552
translate Spanish dlc_soulbabyend_start_8326da51:

    # O_ip "A command of your language that Shakespeare would envy."
    O_ip "Un dominio de tu idioma que Shakespeare envidiaría."

# game/beyond the bet/soulbabyend.rpy:565
translate Spanish dlc_soulbabyend_start_3a0ded6b:

    # O_ip "And you are the mortal that 8394 has abandoned his station to protect."
    O_ip "Y tú eres [arti] mortal para cuya protección 8394 ha abandonado su puesto."

# game/beyond the bet/soulbabyend.rpy:566
translate Spanish dlc_soulbabyend_start_cfc65f5f:

    # O_ip "A disappointing end for an otherwise remarkable Grim Reaper."
    O_ip "Un final decepcionante para una Parca, por lo demás, excepcional."

# game/beyond the bet/soulbabyend.rpy:567
translate Spanish dlc_soulbabyend_start_e9a698fa:

    # O_ip "I cannot help but wonder what he finds so interesting about you."
    O_ip "No puedo evitar preguntarme qué le resulta tan interesante de ti."

# game/beyond the bet/soulbabyend.rpy:568
translate Spanish dlc_soulbabyend_start_a28cc333:

    # O_ip "From my point of view, you're just another human."
    O_ip "Desde mi punto de vista, eres solo [arti_2] human[letra] más."

# game/beyond the bet/soulbabyend.rpy:573
translate Spanish dlc_soulbabyend_start_628c260b:

    # O_ip "I..."
    O_ip "Yo..."

# game/beyond the bet/soulbabyend.rpy:574
translate Spanish dlc_soulbabyend_start_7623c422:

    # O_ip "Likely, yes. I do not think dancing belongs to you."
    O_ip "Probablemente, sí. No creo que bailar sea lo tuyo."

# game/beyond the bet/soulbabyend.rpy:577
translate Spanish dlc_soulbabyend_start_51e78ca9:

    # O_ip "Okay. I do feel like I have no choice but to be impressed by that."
    O_ip "Okey. No me queda más remedio que sentirme impresionado por eso."

# game/beyond the bet/soulbabyend.rpy:578
translate Spanish dlc_soulbabyend_start_99459652:

    # O_ip "Bravo."
    O_ip "Bravo."

# game/beyond the bet/soulbabyend.rpy:581
translate Spanish dlc_soulbabyend_start_b8ef8a7a:

    # O_ip "Are you?"
    O_ip "¿Lo eres?"

# game/beyond the bet/soulbabyend.rpy:587
translate Spanish dlc_soulbabyend_start_64fd2d94:

    # O_ip "Right. Somehow, I am not surprised."
    O_ip "Claro. Curiosamente, no me sorprende."

# game/beyond the bet/soulbabyend.rpy:589
translate Spanish dlc_soulbabyend_start_40e54a09:

    # O_ip "In any manner, I would absolutely hate to stand here chatting with you all day, so let's get down to business, shall we?"
    O_ip "De cualquier modo, detestaría quedarme aquí charlando contigo todo el día, así que vayamos al grano, ¿te parece?"

# game/beyond the bet/soulbabyend.rpy:590
translate Spanish dlc_soulbabyend_start_53029769:

    # O_ip "You are supposed to be dead."
    O_ip "Se supone que deberías estar muert[letra]."

# game/beyond the bet/soulbabyend.rpy:592
translate Spanish dlc_soulbabyend_start_a4d4a604:

    # O_ip "I understand that it can be difficult for a mortal to move on."
    O_ip "Entiendo que puede ser difícil para los mortales partir."

# game/beyond the bet/soulbabyend.rpy:594
translate Spanish dlc_soulbabyend_start_90195479:

    # O_ip "But it is the natural order of things."
    O_ip "Pero es el orden natural de las cosas."

# game/beyond the bet/soulbabyend.rpy:602
translate Spanish dlc_soulbabyend_start_d9cce995:

    # O_ip "So, you think you are above the rules?"
    O_ip "¿Así que crees estar por encima de las reglas?"

# game/beyond the bet/soulbabyend.rpy:603
translate Spanish dlc_soulbabyend_start_7e7f3ce6:

    # O_ip "Why should you live, where many others have died?"
    O_ip "¿Por qué deberías vivir tú, donde tantos otros han muerto?"

# game/beyond the bet/soulbabyend.rpy:607
translate Spanish dlc_soulbabyend_start_e74900d4:

    # O_ip "Ah, so you would disturb the cycle of life and death."
    O_ip "Ah, así que alterarías el ciclo de la vida y la muerte."

# game/beyond the bet/soulbabyend.rpy:608
translate Spanish dlc_soulbabyend_start_353d99be:

    # O_ip "If no one died, do you think your realm would survive?"
    O_ip "Si nadie muriera, ¿crees que tu reino sobreviviría?"

# game/beyond the bet/soulbabyend.rpy:609
translate Spanish dlc_soulbabyend_start_a217d9df:

    # O_ip "Perhaps I seem unfair to you, but—"
    O_ip "Quizás te parezca injusto, pero—"

# game/beyond the bet/soulbabyend.rpy:617
translate Spanish dlc_soulbabyend_start_e56c7961:

    # O_ip "..."
    O_ip "..."

# game/beyond the bet/soulbabyend.rpy:618
translate Spanish dlc_soulbabyend_start_b0139b4f:

    # O_ip "You will give up your soul."
    O_ip "Entregarás tu alma."

# game/beyond the bet/soulbabyend.rpy:619
translate Spanish dlc_soulbabyend_start_1ca83b30:

    # O_ip "I will teach you that there are consequences for your actions."
    O_ip "Te enseñaré que tus actos tienen consecuencias."

# game/beyond the bet/soulbabyend.rpy:620
translate Spanish dlc_soulbabyend_start_7a90994f:

    # O_ip "I am the consequences."
    O_ip "Yo soy las consecuencias."

# game/beyond the bet/soulbabyend.rpy:624
translate Spanish dlc_soulbabyend_start_f8f086c1:

    # O_ip "That is not my name."
    O_ip "Ese no es mi nombre."

# game/beyond the bet/soulbabyend.rpy:628
translate Spanish dlc_soulbabyend_start_fdd58e0a:

    # O_ip "It is not."
    O_ip "No lo es."

# game/beyond the bet/soulbabyend.rpy:633
translate Spanish dlc_soulbabyend_start_d55a5031:

    # O_ip "I do not have a name!"
    O_ip "¡No tengo nombre!"

# game/beyond the bet/soulbabyend.rpy:640
translate Spanish dlc_soulbabyend_start_f304eae0:

    # O_ip "Reapers do not have names—"
    O_ip "Las parcas no tienen nombre—"

# game/beyond the bet/soulbabyend.rpy:652
translate Spanish dlc_soulbabyend_start_0666ff01:

    # O_ip "...Why 8394 would give up everything for someone so aggravating, I will never understand."
    O_ip "...Nunca entenderé por qué 8394 renunciaría a todo por alguien tan exasperante."

# game/beyond the bet/soulbabyend.rpy:653
translate Spanish dlc_soulbabyend_start_d75de9ad:

    # O_ip "I tire of this."
    O_ip "Me canso de esto."

# game/beyond the bet/soulbabyend.rpy:654
translate Spanish dlc_soulbabyend_start_7d308cf0:

    # O_ip "It is about time we finished up here."
    O_ip "Ya es hora de que terminemos aquí."

# game/beyond the bet/soulbabyend.rpy:655
translate Spanish dlc_soulbabyend_start_dc947300:

    # "{i}He walks towards you, scythe in hand.{/i}"
    "{i}Camina hacia ti, con la guadaña en la mano.{/i}"

# game/beyond the bet/soulbabyend.rpy:656
translate Spanish dlc_soulbabyend_start_6b9949e1:

    # "{i}It's a big scythe, actually.{/i}"
    "{i}Es una guadaña bastante grande, de hecho.{/i}"

# game/beyond the bet/soulbabyend.rpy:664
translate Spanish dlc_soulbabyend_start_f29da9b5:

    # "{i}He continues towards you.{/i}"
    "{i}Sigue avanzando hacia ti.{/i}"

# game/beyond the bet/soulbabyend.rpy:675
translate Spanish dlc_soulbabyend_start_42cbb686:

    # O_ip "Excuse me?"
    O_ip "¿Perdón?"

# game/beyond the bet/soulbabyend.rpy:679
translate Spanish dlc_soulbabyend_start_f05f0a69:

    # O_ip "You must be stupid to even suggest I would—"
    O_ip "Debes ser estúpid[letra] para siquiera sugerir que yo—"

# game/beyond the bet/soulbabyend.rpy:684
translate Spanish dlc_soulbabyend_start_e56c7961_1:

    # O_ip "..."
    O_ip "..."

# game/beyond the bet/soulbabyend.rpy:686
translate Spanish dlc_soulbabyend_start_7d7b91c2:

    # O_ip "That law is greatly outdated."
    O_ip "Esa ley está muy obsoleta."

# game/beyond the bet/soulbabyend.rpy:694
translate Spanish dlc_soulbabyend_start_853a4ff2:

    # O_ip "...Damn it all."
    O_ip "...Maldita sea."

# game/beyond the bet/soulbabyend.rpy:696
translate Spanish dlc_soulbabyend_start_c60e9758:

    # O_ip "Fine. I will play your game."
    O_ip "Bien. Jugaré tu juego."

# game/beyond the bet/soulbabyend.rpy:697
translate Spanish dlc_soulbabyend_start_3ceb797b:

    # O_ip "From this moment, I will be in your service for one hour only. "
    O_ip "A partir de este momento, estaré a tu servicio durante una hora solamente. "

# game/beyond the bet/soulbabyend.rpy:698
translate Spanish dlc_soulbabyend_start_d1437d7d:

    # O_ip "At the end of this hour, your soul will rightfully belong to me."
    O_ip "Al terminar esta hora, tu alma me pertenecerá por derecho."

# game/beyond the bet/soulbabyend.rpy:702
translate Spanish dlc_soulbabyend_start_50e51a1d:

    # O_ip "No."
    O_ip "No."

# game/beyond the bet/soulbabyend.rpy:706
translate Spanish dlc_soulbabyend_start_50e51a1d_1:

    # O_ip "No."
    O_ip "No."

# game/beyond the bet/soulbabyend.rpy:716
translate Spanish dlc_soulbabyend_start_9ee5ae45:

    # O_ip "And you would like me to determine what would help you?"
    O_ip "¿Y quieres que sea yo quien determine qué te ayudaría?"

# game/beyond the bet/soulbabyend.rpy:717
translate Spanish dlc_soulbabyend_start_e0568fee:

    # O_ip "Because I believe that—"
    O_ip "Porque creo que—"

# game/beyond the bet/soulbabyend.rpy:727
translate Spanish dlc_soulbabyend_start_e56c7961_2:

    # O_ip "..."
    O_ip "..."

# game/beyond the bet/soulbabyend.rpy:728
translate Spanish dlc_soulbabyend_start_28c0f156:

    # O_ip "So be it."
    O_ip "Que así sea."

# game/beyond the bet/soulbabyend.rpy:735
translate Spanish dlc_soulbabyend_start_c20c44a3:

    # "{i}He turns towards the numerous bookshelves.{/i}"
    "{i}Se vuelve hacia los numerosos estantes.{/i}"

# game/beyond the bet/soulbabyend.rpy:736
translate Spanish dlc_soulbabyend_start_7c291116:

    # "{i}Now that you're having a proper look at the room, there really are WAY too many books in here.{/i}"
    "{i}Ahora que miras bien la sala, de verdad hay DEMASIADOS libros aquí.{/i}"

# game/beyond the bet/soulbabyend.rpy:737
translate Spanish dlc_soulbabyend_start_0ff2526b:

    # "{i}How could an hour be enough?{/i}"
    "{i}¿Cómo podría bastar una hora?{/i}"

# game/beyond the bet/soulbabyend.rpy:752
translate Spanish dlc_soulbabyend_start_32163db4:

    # O_ip "Talking to yourself?"
    O_ip "¿Hablando contigo mism[letra]?"

# game/beyond the bet/soulbabyend.rpy:756
translate Spanish dlc_soulbabyend_start_f8f086c1_1:

    # O_ip "That is not my name."
    O_ip "Ese no es mi nombre."

# game/beyond the bet/soulbabyend.rpy:763
translate Spanish dlc_soulbabyend_start_1399c400:

    # O_ip "...If you must refer to me, I am 5012."
    O_ip "...Si debes referirte a mí, soy 5012."

# game/beyond the bet/soulbabyend.rpy:768
translate Spanish dlc_soulbabyend_start_50e51a1d_2:

    # O_ip "No."
    O_ip "No."

# game/beyond the bet/soulbabyend.rpy:775
translate Spanish dlc_soulbabyend_start_02a88ec2:

    # "{i}He turns back to begin searching the room.{/i}"
    "{i}Se da la vuelta para comenzar a registrar la sala.{/i}"

# game/beyond the bet/soulbabyend.rpy:776
translate Spanish dlc_soulbabyend_start_bce8c137:

    # "{i}In the meantime, you open up your bag, where your laptop is still slipped in.{/i}"
    "{i}Mientras tanto, abres tu bolso, donde tu laptop sigue guardada.{/i}"

# game/beyond the bet/soulbabyend.rpy:777
translate Spanish dlc_soulbabyend_start_d19cbddb:

    # "{i}You boot it up.{/i}"
    "{i}La enciendes.{/i}"

# game/beyond the bet/soulbabyend.rpy:812
translate Spanish soulbabychatend1_18028a76:

    # player "My beloved Casper, where art thou?"
    player "Mi amado Casper, ¿dónde te hallas?"

# game/beyond the bet/soulbabyend.rpy:813
translate Spanish soulbabychatend1_b8567c4b:

    # GR "exactly where you left me, stewing in my own inability to do anything to keep you safe."
    GR "exactamente donde me dejaste, consumiéndome en mi propia incapacidad de hacer algo para mantenerte a salvo."

# game/beyond the bet/soulbabyend.rpy:816
translate Spanish soulbabychatend1_acc1928c:

    # player "That was a little more serious than I was going for, uhhhh..."
    player "Eso fue un poco más serio de lo que buscaba, ehhhh..."

# game/beyond the bet/soulbabyend.rpy:818
translate Spanish soulbabychatend1_f7b67523:

    # player "I'm alive!"
    player "¡Estoy viv[letra]!"

# game/beyond the bet/soulbabyend.rpy:819
translate Spanish soulbabychatend1_ed43e74f:

    # GR "i would have killed you if you were not."
    GR "te habría matado si no lo estuvieras."

# game/beyond the bet/soulbabyend.rpy:822
translate Spanish soulbabychatend1_ed075257:

    # player "I'll pretend that makes sense. Uh huh."
    player "Fingiré que eso tiene sentido. Aja."

# game/beyond the bet/soulbabyend.rpy:824
translate Spanish soulbabychatend1_29927959:

    # player "Ooooh. It's the ghooost of [playerfirstname], here to haaaaaunt youuuu~"
    player "Uuuuuh. Es el fantaaasma de [playerfirstname], que viene a atormeeentarteee~"

# game/beyond the bet/soulbabyend.rpy:825
translate Spanish soulbabychatend1_60e09ef2:

    # GR "that is not true, i have never met a ghost who haunts someone over a messenger client."
    GR "eso no es cierto, nunca he conocido a un fantasma que atormente a alguien por un cliente de mensajería."

# game/beyond the bet/soulbabyend.rpy:828
translate Spanish soulbabychatend1_9e40a1b2:

    # player "There's a first time for everything, Casper."
    player "Todo tiene una primera vez, Casper."

# game/beyond the bet/soulbabyend.rpy:829
translate Spanish soulbabychatend1_0db7b40b:

    # GR "where are you???"
    GR "¿¿¿dónde estás???"

# game/beyond the bet/soulbabyend.rpy:830
translate Spanish soulbabychatend1_8b39a094:

    # GR "did you make it there safely?"
    GR "¿llegaste bien?"

# game/beyond the bet/soulbabyend.rpy:831
translate Spanish soulbabychatend1_7625865a:

    # GR "are you hurt?"
    GR "¿estás herid[letra]?"

# game/beyond the bet/soulbabyend.rpy:834
translate Spanish soulbabychatend1_58ad14da:

    # player "Woah, woah, woah."
    player "Ey, ey, ey."

# game/beyond the bet/soulbabyend.rpy:837
translate Spanish soulbabychatend1_de457b30:

    # player "I'm fine."
    player "Estoy bien."

# game/beyond the bet/soulbabyend.rpy:840
translate Spanish soulbabychatend1_714f280a:

    # player "I got here safely, and now I'm making my new servant search the shelves."
    player "Llegué bien y ahora estoy haciendo que mi nuevo sirviente busque en los estantes."

# game/beyond the bet/soulbabyend.rpy:841
translate Spanish soulbabychatend1_ef683588:

    # GR "it worked, then?"
    GR "¿funcionó, entonces?"

# game/beyond the bet/soulbabyend.rpy:842
translate Spanish soulbabychatend1_907f224c:

    # GR "thank the gods."
    GR "gracias a los dioses."

# game/beyond the bet/soulbabyend.rpy:845
translate Spanish soulbabychatend1_3a2709c5:

    # player "Why thank the gods when I'm right here?"
    player "¿Por qué agradecerles a los dioses si estoy justo aquí?"

# game/beyond the bet/soulbabyend.rpy:847
translate Spanish soulbabychatend1_b4e6951a:

    # player "It was really pretty easy."
    player "Fue bastante fácil, la verdad."

# game/beyond the bet/soulbabyend.rpy:850
translate Spanish soulbabychatend1_592f0cca:

    # player "This guy is kinda a prick, though."
    player "Aunque este tipo es medio idiota."

# game/beyond the bet/soulbabyend.rpy:851
translate Spanish soulbabychatend1_0698cd72:

    # GR "Did you get his number?"
    GR "¿Conseguiste su número?"

# game/beyond the bet/soulbabyend.rpy:854
translate Spanish soulbabychatend1_12927fa5:

    # player "Oh, yeah. 5012."
    player "Ah, sí. 5012."

# game/beyond the bet/soulbabyend.rpy:857
translate Spanish soulbabychatend1_ef2a7380:

    # player "I asked if I could give him a nickname, but he said no :("
    player "Le pregunté si podía ponerle un apodo, pero dijo que no :("

# game/beyond the bet/soulbabyend.rpy:858
translate Spanish soulbabychatend1_cc21bd84:

    # GR "!!!"
    GR "!!!"

# game/beyond the bet/soulbabyend.rpy:859
translate Spanish soulbabychatend1_d26b2cfc:

    # GR "5012?!"
    GR "¡¿5012?!"

# game/beyond the bet/soulbabyend.rpy:862
translate Spanish soulbabychatend1_7f26b94a:

    # player "You know him?"
    player "¿Lo conoces?"

# game/beyond the bet/soulbabyend.rpy:864
translate Spanish soulbabychatend1_47d39f88:

    # player "I wasn't expecting recognition."
    player "No esperaba que lo reconocieras."

# game/beyond the bet/soulbabyend.rpy:865
translate Spanish soulbabychatend1_b83443de:

    # GR "he..."
    GR "él..."

# game/beyond the bet/soulbabyend.rpy:866
translate Spanish soulbabychatend1_428920aa:

    # GR "he trained me, for some time."
    GR "me entrenó, durante un tiempo."

# game/beyond the bet/soulbabyend.rpy:867
translate Spanish soulbabychatend1_f1d29267:

    # GR "well, perhaps 'disciplined' is the right word."
    GR "bueno, quizás 'disciplinó' sea la palabra correcta."

# game/beyond the bet/soulbabyend.rpy:870
translate Spanish soulbabychatend1_baf30d96:

    # player "You, disciplined?"
    player "¿Tú, castigado?"

# game/beyond the bet/soulbabyend.rpy:873
translate Spanish soulbabychatend1_2167af99:

    # player "Were you a bad boy?"
    player "¿Fuiste un chico malo?"

# game/beyond the bet/soulbabyend.rpy:875
translate Spanish soulbabychatend1_1eff1e28:

    # player "The high and mighty Casper?"
    player "¿El altivo y poderoso Casper?"

# game/beyond the bet/soulbabyend.rpy:876
translate Spanish soulbabychatend1_7772a27d:

    # GR "..."
    GR "..."

# game/beyond the bet/soulbabyend.rpy:877
translate Spanish soulbabychatend1_b65db488:

    # GR "i am the best grim reaper now, but i was not always this way."
    GR "ahora soy la mejor parca, pero no siempre fui así."

# game/beyond the bet/soulbabyend.rpy:880
translate Spanish soulbabychatend1_44ecf6bd:

    # player "And here I thought you were born perfect."
    player "Y yo que pensaba que habías nacido perfecto."

# game/beyond the bet/soulbabyend.rpy:881
translate Spanish soulbabychatend1_52c52bb2:

    # GR "an easy mistake to make, when it comes to me."
    GR "un error fácil de cometer, tratándose de mí."

# game/beyond the bet/soulbabyend.rpy:882
translate Spanish soulbabychatend1_fe207185:

    # GR "i am an ideal specimen."
    GR "soy un espécimen ideal."

# game/beyond the bet/soulbabyend.rpy:883
translate Spanish soulbabychatend1_58a53a72:

    # GR "near faultless."
    GR "casi impecable."

# game/beyond the bet/soulbabyend.rpy:886
translate Spanish soulbabychatend1_4742f912:

    # player "Huh."
    player "Vaya."

# game/beyond the bet/soulbabyend.rpy:889
translate Spanish soulbabychatend1_5c2bbbb4:

    # player "Maybe you and this guy are pretty similar actually..."
    player "Quizás tú y este tipo se parecen bastante, en realidad..."

# game/beyond the bet/soulbabyend.rpy:890
translate Spanish soulbabychatend1_e9f2ef90:

    # GR "what do you mean by that."
    GR "qué quieres decir con eso."

# game/beyond the bet/soulbabyend.rpy:891
translate Spanish soulbabychatend1_edfc134b:

    # GR "he is a cold, pompous, cocky, conceited prick."
    GR "es un cretino frío, pomposo, arrogante y engreído."

# game/beyond the bet/soulbabyend.rpy:894
translate Spanish soulbabychatend1_93ef5b29:

    # player "Pot meet kettle."
    player "El burro hablando de orejas."

# game/beyond the bet/soulbabyend.rpy:897
translate Spanish soulbabychatend1_d4c23dc4:

    # player "ANYWAY!"
    player "¡DE TODOS MODOS!"

# game/beyond the bet/soulbabyend.rpy:900
translate Spanish soulbabychatend1_79e60187:

    # player "I'm going to help search."
    player "Voy a ayudar a buscar."

# game/beyond the bet/soulbabyend.rpy:901
translate Spanish soulbabychatend1_bdd44e71:

    # GR "i will come and assist you."
    GR "iré a ayudarte."

# game/beyond the bet/soulbabyend.rpy:902
translate Spanish soulbabychatend1_497d3bb0:

    # GR "i also want to keep an eye on 5012."
    GR "también quiero vigilar a 5012."

# game/beyond the bet/soulbabyend.rpy:903
translate Spanish soulbabychatend1_1165b115:

    # GR "i do not trust him."
    GR "no confío en él."

# game/beyond the bet/soulbabyend.rpy:906
translate Spanish soulbabychatend1_03a00408:

    # player "You jealous I'm spending time with someone else?"
    player "¿Estás celoso de que pase tiempo con otra persona?"

# game/beyond the bet/soulbabyend.rpy:907
translate Spanish soulbabychatend1_fe5ce676:

    # GR "no!"
    GR "¡no!"

# game/beyond the bet/soulbabyend.rpy:908
translate Spanish soulbabychatend1_e9b17589:

    # GR "the fact that the only reaper who should be by your side is me... is beside the point."
    GR "el hecho de que la única parca que debería estar a tu lado soy yo... no viene al caso."

# game/beyond the bet/soulbabyend.rpy:909
translate Spanish soulbabychatend1_aced07d8:

    # GR "of course."
    GR "por supuesto."

# game/beyond the bet/soulbabyend.rpy:910
translate Spanish soulbabychatend1_3b88aa11:

    # GR "that has nothing to do with anything."
    GR "eso no tiene nada que ver con nada."

# game/beyond the bet/soulbabyend.rpy:913
translate Spanish soulbabychatend1_e7e9c558:

    # player "Casper, my love."
    player "Casper, mi amor."

# game/beyond the bet/soulbabyend.rpy:916
translate Spanish soulbabychatend1_716504ae:

    # player "My most dearest."
    player "Mi queridísimo."

# game/beyond the bet/soulbabyend.rpy:919
translate Spanish soulbabychatend1_ac2a4b3b:

    # player "My beloved."
    player "Mi amado."

# game/beyond the bet/soulbabyend.rpy:922
translate Spanish soulbabychatend1_14fc0c59:

    # player "You are sooo jealous."
    player "Estás celosísimo."

# game/beyond the bet/soulbabyend.rpy:925
translate Spanish soulbabychatend1_3d6e656d:

    # player "How cute."
    player "Qué tierno."

# game/beyond the bet/soulbabyend.rpy:927
translate Spanish soulbabychatend1_9d628965:

    # player "Tut tut, Mister."
    player "Tsk, tsk, señor."

# game/beyond the bet/soulbabyend.rpy:929
translate Spanish soulbabychatend1_f2b03886:

    # player "You're the only reaper for me."
    player "Eres la única parca para mí."

# game/beyond the bet/soulbabyend.rpy:932
translate Spanish soulbabychatend1_81760142:

    # player "But don't come yet."
    player "Pero no vengas todavía."

# game/beyond the bet/soulbabyend.rpy:935
translate Spanish soulbabychatend1_9a588110:

    # player "I need you to be a surprise."
    player "Necesito que seas una sorpresa."

# game/beyond the bet/soulbabyend.rpy:936
translate Spanish soulbabychatend1_dfb0bd6b:

    # GR "what, do you expect me to jump out of a cake or something?"
    GR "¿qué, esperas que salte de un pastel o algo así?"

# game/beyond the bet/soulbabyend.rpy:939
translate Spanish soulbabychatend1_61fac05a:

    # player "Yes, nude."
    player "Sí, desnudo."

# game/beyond the bet/soulbabyend.rpy:941
translate Spanish soulbabychatend1_b640f11f:

    # player "Wait, is that an option?"
    player "Espera, ¿es una opción?"

# game/beyond the bet/soulbabyend.rpy:942
translate Spanish soulbabychatend1_7bf4614a:

    # GR "ok no i was not being serious about that."
    GR "ok no, no hablaba en serio."

# game/beyond the bet/soulbabyend.rpy:945
translate Spanish soulbabychatend1_7c56749b:

    # player "Damn."
    player "Maldición."

# game/beyond the bet/soulbabyend.rpy:947
translate Spanish soulbabychatend1_aa4221a1:

    # player "A shame."
    player "Qué pena."

# game/beyond the bet/soulbabyend.rpy:950
translate Spanish soulbabychatend1_47e6d640:

    # player "Let's workshop the cake idea later."
    player "Luego trabajamos la idea del pastel."

# game/beyond the bet/soulbabyend.rpy:951
translate Spanish soulbabychatend1_0bf643c4:

    # GR "we will not be doing that."
    GR "no haremos eso."

# game/beyond the bet/soulbabyend.rpy:954
translate Spanish soulbabychatend1_17aa1c51:

    # player "We're putting a pin in it."
    player "La dejamos pendiente."

# game/beyond the bet/soulbabyend.rpy:955
translate Spanish soulbabychatend1_63aae541:

    # GR "no we are not."
    GR "no, no lo haremos."

# game/beyond the bet/soulbabyend.rpy:958
translate Spanish soulbabychatend1_c037342e:

    # player "Maybe for my birthday?"
    player "¿Quizás para mi cumpleaños?"

# game/beyond the bet/soulbabyend.rpy:960
translate Spanish soulbabychatend1_eed53444:

    # player "At our wedding!"
    player "¡En nuestra boda!"

# game/beyond the bet/soulbabyend.rpy:963
translate Spanish soulbabychatend1_c688c722:

    # player "But!!!"
    player "¡¡¡Pero!!!"

# game/beyond the bet/soulbabyend.rpy:966
translate Spanish soulbabychatend1_fba9f974:

    # player "What I actually meant was, he is probably expecting you to turn up now."
    player "Lo que en realidad quería decir es que probablemente él espera que aparezcas ahora."

# game/beyond the bet/soulbabyend.rpy:969
translate Spanish soulbabychatend1_c7bbd2c8:

    # player "If you wait until the hour is up, he's gonna think he's won."
    player "Si esperas a que se acabe la hora, va a pensar que ganó."

# game/beyond the bet/soulbabyend.rpy:972
translate Spanish soulbabychatend1_2cb57c61:

    # player "I want to wipe the smug look off his face."
    player "Quiero borrarle esa cara de suficiencia."

# game/beyond the bet/soulbabyend.rpy:973
translate Spanish soulbabychatend1_55592c4d:

    # GR "all of that..."
    GR "todo eso..."

# game/beyond the bet/soulbabyend.rpy:974
translate Spanish soulbabychatend1_5491059e:

    # GR "risking your life..."
    GR "arriesgando tu vida..."

# game/beyond the bet/soulbabyend.rpy:975
translate Spanish soulbabychatend1_14ee5bc4:

    # GR "because you want to bully him?"
    GR "¿porque quieres molestarlo?"

# game/beyond the bet/soulbabyend.rpy:978
translate Spanish soulbabychatend1_e571c08a:

    # player "What can I say, it's just in my personality."
    player "Qué puedo decir, es parte de mi personalidad."

# game/beyond the bet/soulbabyend.rpy:981
translate Spanish soulbabychatend1_93ffd1fd:

    # player "You reapers are just so bullyable!"
    player "¡Ustedes, las parcas, son tan fáciles de molestar!"

# game/beyond the bet/soulbabyend.rpy:983
translate Spanish soulbabychatend1_4a927ac2:

    # player "I want to keep you safe."
    player "Quiero mantenerte a salvo."

# game/beyond the bet/soulbabyend.rpy:986
translate Spanish soulbabychatend1_84608410:

    # player "If I get to be a little mean to him along the way, I think it was meant to be."
    player "Si de paso puedo ser un poquito mal[letra] con él, creo que estaba destinado a ser."

# game/beyond the bet/soulbabyend.rpy:987
translate Spanish soulbabychatend1_55690088:

    # GR "...fine."
    GR "...está bien."

# game/beyond the bet/soulbabyend.rpy:988
translate Spanish soulbabychatend1_0756185c:

    # GR "gods, this is infuriating."
    GR "dioses, esto es exasperante."

# game/beyond the bet/soulbabyend.rpy:989
translate Spanish soulbabychatend1_ac7af04a:

    # GR "all i can do is pace around and worry."
    GR "lo único que puedo hacer es dar vueltas y preocuparme."

# game/beyond the bet/soulbabyend.rpy:992
translate Spanish soulbabychatend1_92f1593e:

    # player "Now, that's a cute picture in my head."
    player "Esa sí que es una imagen tierna en mi cabeza."

# game/beyond the bet/soulbabyend.rpy:994
translate Spanish soulbabychatend1_ce892bcf:

    # player "Awww, Casper."
    player "Awww, Casper."

# game/beyond the bet/soulbabyend.rpy:995
translate Spanish soulbabychatend1_2c4e1025:

    # GR "...if you find anything, or the hour has just come to a close, call for me."
    GR "...si encuentras algo, o si la hora está por terminar, llámame."

# game/beyond the bet/soulbabyend.rpy:996
translate Spanish soulbabychatend1_eecf8dd4:

    # GR "i will be there."
    GR "estaré ahí."

# game/beyond the bet/soulbabyend.rpy:999
translate Spanish soulbabychatend1_bc497f76:

    # player "I'll message you."
    player "Te escribiré."

# game/beyond the bet/soulbabyend.rpy:1000
translate Spanish soulbabychatend1_73cc2d67:

    # GR "no, i..."
    GR "no, yo..."

# game/beyond the bet/soulbabyend.rpy:1001
translate Spanish soulbabychatend1_1d51f6d5:

    # GR "believe that is not needed."
    GR "creo que no será necesario."

# game/beyond the bet/soulbabyend.rpy:1004
translate Spanish soulbabychatend1_05cf1b99:

    # player "???"
    player "???"

# game/beyond the bet/soulbabyend.rpy:1005
translate Spanish soulbabychatend1_4b3385bf:

    # GR "our connection."
    GR "nuestra conexión."

# game/beyond the bet/soulbabyend.rpy:1006
translate Spanish soulbabychatend1_24ebc1a6:

    # GR "even now, part of my soul still resides within you."
    GR "incluso ahora, una parte de mi alma aún reside en ti."

# game/beyond the bet/soulbabyend.rpy:1007
translate Spanish soulbabychatend1_6a346cae:

    # GR "the smallest part, but..."
    GR "la parte más pequeña, pero..."

# game/beyond the bet/soulbabyend.rpy:1008
translate Spanish soulbabychatend1_c0d1b697:

    # GR "if you call for me, i will be there."
    GR "si me llamas, estaré ahí."

# game/beyond the bet/soulbabyend.rpy:1011
translate Spanish soulbabychatend1_50ffb010:

    # player "I'll be counting on you, then."
    player "Entonces contaré contigo."

# game/beyond the bet/soulbabyend.rpy:1013
translate Spanish soulbabychatend1_f1e59b40:

    # player "I'll call real loud!"
    player "¡Llamaré bien fuerte!"

# game/beyond the bet/soulbabyend.rpy:1016
translate Spanish soulbabychatend1_4576169c:

    # player "See you soon, okay?"
    player "Nos vemos pronto, ¿okey?"

# game/beyond the bet/soulbabyend.rpy:1017
translate Spanish soulbabychatend1_b02e55ba:

    # GR "stay safe, [playerfirstname!l]."
    GR "cuídate, [playerfirstname!l]."

# game/beyond the bet/soulbabyend.rpy:1018
translate Spanish soulbabychatend1_a60bd551:

    # GR "my stray ray of sunshine."
    GR "mi rayito de sol perdido."

# game/beyond the bet/soulbabyend.rpy:1051
translate Spanish soulbabychatend1_a90952a0:

    # O_ip "Many things, human."
    O_ip "Muchas cosas, human[letra]."

# game/beyond the bet/soulbabyend.rpy:1052
translate Spanish soulbabychatend1_9f4173c1:

    # O_ip "Books, mostly."
    O_ip "Libros, en su mayoría."

# game/beyond the bet/soulbabyend.rpy:1062
translate Spanish soulbabychatend1_1d5e686b:

    # O_ip "Anything to save you from your inevitable demise?"
    O_ip "¿Algo que te salve de tu inevitable final?"

# game/beyond the bet/soulbabyend.rpy:1064
translate Spanish soulbabychatend1_50e51a1d:

    # O_ip "No."
    O_ip "No."

# game/beyond the bet/soulbabyend.rpy:1068
translate Spanish soulbabychatend1_57407e54:

    # O_ip "You have exactly 45 minutes and 17 seconds left of my service."
    O_ip "Te quedan exactamente 45 minutos y 17 segundos de mi servicio."

# game/beyond the bet/soulbabyend.rpy:1069
translate Spanish soulbabychatend1_b1db61cf:

    # O_ip "Perhaps you should consider using me for something more meaningful."
    O_ip "Quizás deberías considerar usarme para algo más significativo."

# game/beyond the bet/soulbabyend.rpy:1071
translate Spanish soulbabychatend1_cd29a392:

    # O_ip "To say goodbye to your family, or your friends, or whoever has the displeasure of knowing you."
    O_ip "Para despedirte de tu familia, de tus amigos o de quien tenga el disgusto de conocerte."

# game/beyond the bet/soulbabyend.rpy:1088
translate Spanish soulbabychatend1_81e5dad0:

    # O_ip "I will continue searching."
    O_ip "Seguiré buscando."

# game/beyond the bet/soulbabyend.rpy:1102
translate Spanish soulbabychatend1_ddc0f189:

    # "45 minutes becomes 30 minutes."
    "45 minutos se convierten en 30."

# game/beyond the bet/soulbabyend.rpy:1103
translate Spanish soulbabychatend1_559b7e0c:

    # "Then 20."
    "Luego 20."

# game/beyond the bet/soulbabyend.rpy:1104
translate Spanish soulbabychatend1_97f7efa1:

    # "Then 10."
    "Luego 10."

# game/beyond the bet/soulbabyend.rpy:1105
translate Spanish soulbabychatend1_cbd082e3:

    # "When 5 minutes are left, you look up from the book in your hands."
    "Cuando quedan 5 minutos, levantas la vista del libro que tienes en las manos."

# game/beyond the bet/soulbabyend.rpy:1133
translate Spanish soulbabychatend1_56bc0666:

    # O_ip "This is not just a library."
    O_ip "Esto no es solo una biblioteca."

# game/beyond the bet/soulbabyend.rpy:1135
translate Spanish soulbabychatend1_775a5009:

    # O_ip "It is a collection of our past."
    O_ip "Es una colección de nuestro pasado."

# game/beyond the bet/soulbabyend.rpy:1136
translate Spanish soulbabychatend1_d88425d3:

    # O_ip "Of course the books are heavy with history, politics, and whatnot."
    O_ip "Por supuesto que los libros están cargados de historia, política y demás."

# game/beyond the bet/soulbabyend.rpy:1138
translate Spanish soulbabychatend1_0bd34541:

    # O_ip "Did you really think a book would miraculously appear that would solve all of your problems?"
    O_ip "¿De verdad creíste que aparecería milagrosamente un libro que resolviera todos tus problemas?"

# game/beyond the bet/soulbabyend.rpy:1139
translate Spanish soulbabychatend1_2c14439f:

    # O_ip "Life is not often that convenient."
    O_ip "La vida rara vez es tan conveniente."

# game/beyond the bet/soulbabyend.rpy:1141
translate Spanish soulbabychatend1_e06836ec:

    # O_ip "It is best to give up now and accept what is to come."
    O_ip "Lo mejor es rendirte ahora y aceptar lo que viene."

# game/beyond the bet/soulbabyend.rpy:1142
translate Spanish soulbabychatend1_408ec251:

    # O_ip "It will make passing on easier for your frail human body."
    O_ip "Hará que el tránsito sea más fácil para tu frágil cuerpo humano."

# game/beyond the bet/soulbabyend.rpy:1151
translate Spanish soulbabychatend1_25e849cb:

    # O_ip "If it pleases you."
    O_ip "Si eso te complace."

# game/beyond the bet/soulbabyend.rpy:1162
translate Spanish soulbabychatend1_5c138bec:

    # "{i}You keep looking, flinging books from the shelves and scanning them as fast as possible.{/i}"
    "{i}Sigues buscando, arrojando libros de los estantes y revisándolos lo más rápido posible.{/i}"

# game/beyond the bet/soulbabyend.rpy:1163
translate Spanish soulbabychatend1_ac96258f:

    # "{i}Three minutes left.{/i}"
    "{i}Quedan tres minutos.{/i}"

# game/beyond the bet/soulbabyend.rpy:1164
translate Spanish soulbabychatend1_dadd0048:

    # "{i}So many words - you're not sure if you're even really reading them anymore.{/i}"
    "{i}Tantas palabras: ya ni siquiera sabes si de verdad las estás leyendo.{/i}"

# game/beyond the bet/soulbabyend.rpy:1165
translate Spanish soulbabychatend1_baa57f8a:

    # "{i}You're just searching.{/i}"
    "{i}Solo estás buscando.{/i}"

# game/beyond the bet/soulbabyend.rpy:1166
translate Spanish soulbabychatend1_f26d3b4f:

    # "{i}Searching for something.{/i}"
    "{i}Buscando algo.{/i}"

# game/beyond the bet/soulbabyend.rpy:1167
translate Spanish soulbabychatend1_80c3bbb6:

    # "{i}Anything.{/i}"
    "{i}Cualquier cosa.{/i}"

# game/beyond the bet/soulbabyend.rpy:1168
translate Spanish soulbabychatend1_ad26d1b1:

    # "{i}Two minutes.{/i}"
    "{i}Dos minutos.{/i}"

# game/beyond the bet/soulbabyend.rpy:1169
translate Spanish soulbabychatend1_6fe62be4:

    # "{i}And then, the smallest glimmer.{/i}"
    "{i}Y entonces, el más mínimo destello.{/i}"

# game/beyond the bet/soulbabyend.rpy:1170
translate Spanish soulbabychatend1_cacb6ff7:

    # "{i}A scruffy old book. There's not even a title.{/i}"
    "{i}Un libro viejo y descuidado. Ni siquiera tiene título.{/i}"

# game/beyond the bet/soulbabyend.rpy:1171
translate Spanish soulbabychatend1_3ff059cf:

    # "{i}You don't know what drew you to it, but you pull it from the shelf.{/i}"
    "{i}No sabes qué te atrajo hacia él, pero lo sacas del estante.{/i}"

# game/beyond the bet/soulbabyend.rpy:1172
translate Spanish soulbabychatend1_b97b8f1b:

    # "{i}Your fingers run over the cover, and you pull open the book.{/i}"
    "{i}Tus dedos recorren la portada y abres el libro.{/i}"

# game/beyond the bet/soulbabyend.rpy:1173
translate Spanish soulbabychatend1_05f3d672:

    # "{i}Handwritten, and old. Very old.{/i}"
    "{i}Escrito a mano, y antiguo. Muy antiguo.{/i}"

# game/beyond the bet/soulbabyend.rpy:1174
translate Spanish soulbabychatend1_816d762a:

    # "{i}You flick through the pages, and you can feel yourself shaking.{/i}"
    "{i}Hojeas las páginas y sientes que estás temblando.{/i}"

# game/beyond the bet/soulbabyend.rpy:1175
translate Spanish soulbabychatend1_11fdfe16:

    # "{i}There's no time.{/i}"
    "{i}No hay tiempo.{/i}"

# game/beyond the bet/soulbabyend.rpy:1176
translate Spanish soulbabychatend1_459d7dfd:

    # "{i}You scan the pages as fast as you can, your eyes flicking over the words.{/i}"
    "{i}Repasas las páginas lo más rápido que puedes, con los ojos saltando sobre las palabras.{/i}"

# game/beyond the bet/soulbabyend.rpy:1177
translate Spanish soulbabychatend1_adf6539a:

    # "{i}One minute.{/i}"
    "{i}Un minuto.{/i}"

# game/beyond the bet/soulbabyend.rpy:1178
translate Spanish soulbabychatend1_84acceb3:

    # "'There exists a middle between life and death - between a mortal and a Grim Reaper.'"
    "'Existe un punto medio entre la vida y la muerte, entre un mortal y una Parca.'"

# game/beyond the bet/soulbabyend.rpy:1179
translate Spanish soulbabychatend1_3f5b7758:

    # "'This middle has been studied little, though I hope to change that.'"
    "'Este punto medio ha sido poco estudiado, aunque espero cambiar eso.'"

# game/beyond the bet/soulbabyend.rpy:1180
translate Spanish soulbabychatend1_da35ca41:

    # "'It is difficult to consider. Studying it properly would require two people. A Grim Reaper, and a mortal with an incredibly strong soul. We have yet to find a set of people like this.'"
    "'Es difícil de plantear. Estudiarlo adecuadamente requeriría dos personas: una Parca y un mortal con un alma increíblemente fuerte. Aún no hemos encontrado a un par de personas así.'"

# game/beyond the bet/soulbabyend.rpy:1181
translate Spanish soulbabychatend1_0c06ff3b:

    # "'So, this entry will focus on the theoretical side of this. How the bond could work, how the souls could merge, and how a being like this could exist.'"
    "'Por eso, esta entrada se centrará en el aspecto teórico: cómo podría funcionar el vínculo, cómo podrían fusionarse las almas y cómo podría existir un ser así.'"

# game/beyond the bet/soulbabyend.rpy:1182
translate Spanish soulbabychatend1_049442b3:

    # "'The idea is that two souls with a connection beyond the ordinary could combine the exceptional parts of their souls. The 'being' that is created from the fusion would hold the weight of both their souls, and provide some kind of protection for them.'"
    "'La idea es que dos almas con una conexión fuera de lo común podrían combinar las partes excepcionales de sus almas. El 'ser' creado a partir de la fusión cargaría con el peso de ambas almas y les brindaría algún tipo de protección.'"

# game/beyond the bet/soulbabyend.rpy:1183
translate Spanish soulbabychatend1_92a48e06:

    # "'Reapers would no longer experience the Soulsickness. In fact, they would not really be Grim Reapers any longer.'"
    "'Las parcas ya no padecerían la Enfermedad del Alma. De hecho, ya no serían realmente Parcas.'"

# game/beyond the bet/soulbabyend.rpy:1184
translate Spanish soulbabychatend1_30995493:

    # "'And the human would no longer age. They would not be a part of the cycle of rebirth any longer.'"
    "'Y el humano dejaría de envejecer. Ya no formaría parte del ciclo de renacimiento.'"

# game/beyond the bet/soulbabyend.rpy:1185
translate Spanish soulbabychatend1_d3cd8cf1:

    # "'But this is all theory. In practice, it would take a very special connection for a bond like this to exist, and I believe the consequences would be immense.'"
    "'Pero todo esto es teoría. En la práctica, haría falta una conexión muy especial para que existiera un vínculo así, y creo que las consecuencias serían inmensas.'"

# game/beyond the bet/soulbabyend.rpy:1186
translate Spanish soulbabychatend1_6187f577:

    # "'To be so connected that one could no longer live without the other. I'm not sure if that is a blessing, or a curse.'"
    "'Estar tan conectados que uno ya no pudiera vivir sin el otro. No sé si eso es una bendición o una maldición.'"

# game/beyond the bet/soulbabyend.rpy:1187
translate Spanish soulbabychatend1_fa9a366b:

    # "'It would be a bond unlike any other.'"
    "'Sería un vínculo distinto a cualquier otro.'"

# game/beyond the bet/soulbabyend.rpy:1188
translate Spanish soulbabychatend1_a4aaade3:

    # "'Though, again, it is all theory.'"
    "'Aunque, repito, todo es teoría.'"

# game/beyond the bet/soulbabyend.rpy:1189
translate Spanish soulbabychatend1_59f4f746:

    # "{i}You look up from the book just as 5012's eyes find yours.{/i}"
    "{i}Levantas la vista del libro justo cuando los ojos de 5012 encuentran los tuyos.{/i}"

# game/beyond the bet/soulbabyend.rpy:1197
translate Spanish soulbabychatend1_808fa5b8:

    # O_ip "I hope you enjoyed your final hour, 'Sunshine'."
    O_ip "Espero que hayas disfrutado tu última hora, 'Solecito'."

# game/beyond the bet/soulbabyend.rpy:1198
translate Spanish soulbabychatend1_5e346c1d:

    # O_ip "A shame that your wishes did not come to fruition."
    O_ip "Lástima que tus deseos no se hayan cumplido."

# game/beyond the bet/soulbabyend.rpy:1199
translate Spanish soulbabychatend1_467ad0f7:

    # O_ip "Now, I will take what is owed to me."
    O_ip "Ahora tomaré lo que se me debe."

# game/beyond the bet/soulbabyend.rpy:1204
translate Spanish soulbabychatend1_a5d4ac21:

    # "You feel a pull on something inside of you... your very soul?"
    "Sientes un tirón en algo dentro de ti... ¿tu propia alma?"

# game/beyond the bet/soulbabyend.rpy:1205
translate Spanish soulbabychatend1_7a78d721:

    # "That pull... pulls something to you. Someone."
    "Ese tirón... atrae algo hacia ti. A alguien."

# game/beyond the bet/soulbabyend.rpy:1222
translate Spanish soulbabychatend1_1f0e271b:

    # "You blink your eyes against the feeling, and when they reopen, you see Casper."
    "Parpadeas para resistir la sensación y, cuando vuelves a abrir los ojos, ves a Casper."

# game/beyond the bet/soulbabyend.rpy:1228
translate Spanish soulbabychatend1_8b4a0557:

    # GRC "You called."
    GRC "Me llamaste."

# game/beyond the bet/soulbabyend.rpy:1230
translate Spanish soulbabychatend1_ddc38b1d:

    # O_ip "Welcome, 'Casper'. It's been some time."
    O_ip "Bienvenido, 'Casper'. Ha pasado tiempo."

# game/beyond the bet/soulbabyend.rpy:1231
translate Spanish soulbabychatend1_94006839:

    # O_ip "A shame our reunion couldn't be under better circumstances."
    O_ip "Lástima que nuestro reencuentro no sea en mejores circunstancias."

# game/beyond the bet/soulbabyend.rpy:1233
translate Spanish soulbabychatend1_56f201e4:

    # O_ip "I suppose I shall always be cleaning up your mess."
    O_ip "Supongo que siempre estaré limpiando tus desastres."

# game/beyond the bet/soulbabyend.rpy:1234
translate Spanish soulbabychatend1_211a27bc:

    # O_ip "Say your final goodbyes."
    O_ip "Di tus últimos adioses."

# game/beyond the bet/soulbabyend.rpy:1235
translate Spanish soulbabychatend1_4b4d14d8:

    # GRC "Just try it. I won't let you touch my mortal."
    GRC "Inténtalo. No dejaré que toques a mi mortal."

# game/beyond the bet/soulbabyend.rpy:1236
translate Spanish soulbabychatend1_18680135:

    # O_ip "The fact you think you can stand against me is hysterical."
    O_ip "Que creas poder enfrentarme es hilarante."

# game/beyond the bet/soulbabyend.rpy:1241
translate Spanish soulbabychatend1_8e0dfc42:

    # GRC "...Unfortunately."
    GRC "...Por desgracia."

# game/beyond the bet/soulbabyend.rpy:1246
translate Spanish soulbabychatend1_125f2bd9:

    # GRC "On the...?"
    GRC "¿En el...?"

# game/beyond the bet/soulbabyend.rpy:1251
translate Spanish soulbabychatend1_161e62e8:

    # "{i}Whatever else he says is lost as you close your eyes and concentrate.{/i}"
    "{i}Lo que sea que diga después se pierde mientras cierras los ojos y te concentras.{/i}"

# game/beyond the bet/soulbabyend.rpy:1254
translate Spanish soulbabychatend1_5f66cd16:

    # "{i}You picture that bridge as you try to calm your mind.{/i}"
    "{i}Imaginas ese puente mientras intentas calmar tu mente.{/i}"

# game/beyond the bet/soulbabyend.rpy:1255
translate Spanish soulbabychatend1_b0ff65d1:

    # "{i}One step, and then another.{/i}"
    "{i}Un paso y luego otro.{/i}"

# game/beyond the bet/soulbabyend.rpy:1256
translate Spanish soulbabychatend1_19c6e094:

    # "{i}You hold onto the handrails, and you walk.{/i}"
    "{i}Te agarras de los pasamanos y caminas.{/i}"

# game/beyond the bet/soulbabyend.rpy:1257
translate Spanish soulbabychatend1_c720dd4f:

    # "{i}It's funny being back here.{/i}"
    "{i}Es curioso estar de vuelta aquí.{/i}"

# game/beyond the bet/soulbabyend.rpy:1258
translate Spanish soulbabychatend1_3f1a801d:

    # "{i}It somehow feels like years since you and Casper did this for the first time.{/i}"
    "{i}De algún modo se siente como si hubieran pasado años desde que tú y Casper hicieron esto por primera vez.{/i}"

# game/beyond the bet/soulbabyend.rpy:1259
translate Spanish soulbabychatend1_8c55d13c:

    # "{i}But it was only a few days ago now.{/i}"
    "{i}Pero fue hace apenas unos días.{/i}"

# game/beyond the bet/soulbabyend.rpy:1260
translate Spanish soulbabychatend1_0b6f8e26:

    # "{i}You look up with eyes shut tight.{/i}"
    "{i}Levantas la mirada con los ojos bien cerrados.{/i}"

# game/beyond the bet/soulbabyend.rpy:1261
translate Spanish soulbabychatend1_01538507:

    # "{i}But you see him.{/i}"
    "{i}Pero lo ves.{/i}"

# game/beyond the bet/soulbabyend.rpy:1262
translate Spanish soulbabychatend1_2c220b21:

    # "{i}Casper.{/i}"
    "{i}Casper.{/i}"

# game/beyond the bet/soulbabyend.rpy:1265
translate Spanish soulbabychatend1_d3716dc2:

    # GRC "What are we doing?"
    GRC "¿Qué estamos haciendo?"

# game/beyond the bet/soulbabyend.rpy:1268
translate Spanish soulbabychatend1_41803608:

    # GRC "Sunshine, for the last time, soulbabies are NOT real!"
    GRC "¡Solecito, por última vez, los bebés alma NO son reales!"

# game/beyond the bet/soulbabyend.rpy:1280
translate Spanish soulbabychatend1_b4d34529:

    # GRC "...What do you mean?"
    GRC "...¿A qué te refieres?"

# game/beyond the bet/soulbabyend.rpy:1285
translate Spanish soulbabychatend1_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/soulbabyend.rpy:1286
translate Spanish soulbabychatend1_74a49f81:

    # GRC "Is this really what you want?"
    GRC "¿De verdad esto es lo que quieres?"

# game/beyond the bet/soulbabyend.rpy:1296
translate Spanish soulbabychatend1_7b361108:

    # GRC "Sunshine, I want nothing else except for you."
    GRC "Solecito, no quiero nada más que a ti."

# game/beyond the bet/soulbabyend.rpy:1319
translate Spanish soulbabychatend1_4659d31e:

    # O_ip "What in the..."
    O_ip "¿Qué demonios...?"

# game/beyond the bet/soulbabyend.rpy:1320
translate Spanish soulbabychatend1_6e377e9d:

    # "{i}You open your eyes.{/i}"
    "{i}Abres los ojos.{/i}"

# game/beyond the bet/soulbabyend.rpy:1321
translate Spanish soulbabychatend1_08cb0618:

    # "{i}Floating between you and Casper is...{/i}"
    "{i}Flotando entre tú y Casper hay...{/i}"

# game/beyond the bet/soulbabyend.rpy:1329
translate Spanish soulbabychatend1_18db7ce7:

    # "{i}It's slightly see through. Barely there, really.{/i}"
    "{i}Es ligeramente transparente. Apenas está ahí, en realidad.{/i}"

# game/beyond the bet/soulbabyend.rpy:1330
translate Spanish soulbabychatend1_48e5ec64:

    # "{i}But it is there.{/i}"
    "{i}Pero está ahí.{/i}"

# game/beyond the bet/soulbabyend.rpy:1331
translate Spanish soulbabychatend1_ec3f70be:

    # "{i}A part of you, and a part of Casper.{/i}"
    "{i}Una parte de ti y una parte de Casper.{/i}"

# game/beyond the bet/soulbabyend.rpy:1333
translate Spanish soulbabychatend1_b015f13b:

    # O_ip "You two are..."
    O_ip "Ustedes dos son..."

# game/beyond the bet/soulbabyend.rpy:1335
translate Spanish soulbabychatend1_124deb1c:

    # O_ip "No longer the same."
    O_ip "Ya no son lo mismo."

# game/beyond the bet/soulbabyend.rpy:1336
translate Spanish soulbabychatend1_04265950:

    # O_ip "What is this?"
    O_ip "¿Qué es esto?"

# game/beyond the bet/soulbabyend.rpy:1340
translate Spanish soulbabychatend1_30c74a20:

    # GRC "Oh, for the love of..."
    GRC "Ay, por el amor de..."

# game/beyond the bet/soulbabyend.rpy:1342
translate Spanish soulbabychatend1_e7956f01:

    # GRC "It's not a soulbaby!"
    GRC "¡No es un bebé alma!"

# game/beyond the bet/soulbabyend.rpy:1350
translate Spanish soulbabychatend1_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/soulbabyend.rpy:1359
translate Spanish soulbabychatend1_617404b9:

    # "{i}You watch 5012 pull out a piece of paper from his pocket.{/i}"
    "{i}Ves a 5012 sacar un papel de su bolsillo.{/i}"

# game/beyond the bet/soulbabyend.rpy:1360
translate Spanish soulbabychatend1_407d277f:

    # "{i}He goes between staring at it and then you incredulously.{/i}"
    "{i}Alterna entre mirarlo y luego mirarte a ti con incredulidad.{/i}"

# game/beyond the bet/soulbabyend.rpy:1361
translate Spanish soulbabychatend1_f5308875:

    # O_ip "If this were up to me, both of you would be tried for this."
    O_ip "Si dependiera de mí, ambos serían juzgados por esto."

# game/beyond the bet/soulbabyend.rpy:1362
translate Spanish soulbabychatend1_162c76a9:

    # O_ip "But it is not up to me."
    O_ip "Pero no depende de mí."

# game/beyond the bet/soulbabyend.rpy:1363
translate Spanish soulbabychatend1_77acbc5e:

    # O_ip "I am not a judge."
    O_ip "No soy un juez."

# game/beyond the bet/soulbabyend.rpy:1364
translate Spanish soulbabychatend1_05125d01:

    # O_ip "I am simply a follower of the rules."
    O_ip "Soy simplemente un seguidor de las reglas."

# game/beyond the bet/soulbabyend.rpy:1365
translate Spanish soulbabychatend1_5c3d7051:

    # O_ip "Human. 'Casper'."
    O_ip "Human[letra]. 'Casper'."

# game/beyond the bet/soulbabyend.rpy:1366
translate Spanish soulbabychatend1_aed95bfe:

    # O_ip "The two of you are neither human, nor Grim Reaper, and thus I have no hold over you."
    O_ip "Ustedes dos no son ni humanos ni Parcas, y por lo tanto no tengo autoridad sobre ustedes."

# game/beyond the bet/soulbabyend.rpy:1367
translate Spanish soulbabychatend1_8aa376b2:

    # O_ip "You will be sent back to the mortal realm."
    O_ip "Serán enviados de vuelta al reino mortal."

# game/beyond the bet/soulbabyend.rpy:1368
translate Spanish soulbabychatend1_9383888c:

    # O_ip "But let it be known... if the two of you ever go back to the way you were, I will be there."
    O_ip "Pero que quede claro... si alguna vez vuelven a ser como eran, ahí estaré."

# game/beyond the bet/soulbabyend.rpy:1376
translate Spanish soulbabychatend1_3d16660d:

    # O_ip "Even listening to you makes me lose brain cells."
    O_ip "Incluso escucharte me hace perder neuronas."

# game/beyond the bet/soulbabyend.rpy:1378
translate Spanish soulbabychatend1_4a99352a:

    # "{i}You watch him raise his hand, and before you know it you're falling.{/i}"
    "{i}Lo ves levantar la mano y, antes de darte cuenta, estás cayendo.{/i}"

# game/beyond the bet/soulbabyend.rpy:1382
translate Spanish soulbabychatend1_a76d7500:

    # "{i}Falling, falling, falling.{/i}"
    "{i}Cayendo, cayendo, cayendo.{/i}"

# game/beyond the bet/soulbabyend.rpy:1383
translate Spanish soulbabychatend1_d65f81a4:

    # "{i}Until you aren't.{/i}"
    "{i}Hasta que dejas de caer.{/i}"

# game/beyond the bet/soulbabyend.rpy:1395
translate Spanish soulbabayplayerroom_7b1530d5:

    # "Sunlight cascades in from the window."
    "La luz del sol entra a raudales por la ventana."

# game/beyond the bet/soulbabyend.rpy:1398
translate Spanish soulbabayplayerroom_a795d44d:

    # "You blink, unused to the sunlight."
    "Parpadeas, desacostumbrad[letra] a la luz del sol."

# game/beyond the bet/soulbabyend.rpy:1399
translate Spanish soulbabayplayerroom_fc5bd961:

    # "Looking around, you see..."
    "Al mirar a tu alrededor, ves..."

# game/beyond the bet/soulbabyend.rpy:1400
translate Spanish soulbabayplayerroom_b26676e0:

    # "Your room."
    "Tu habitación."

# game/beyond the bet/soulbabyend.rpy:1401
translate Spanish soulbabayplayerroom_1639a40d:

    # "You see [pet_name], returned somehow."
    "Ves a [pet_name], de vuelta de alguna manera."

# game/beyond the bet/soulbabyend.rpy:1402
translate Spanish soulbabayplayerroom_3a03df1e:

    # "Azrael sits next to [pet_name] on the bed."
    "Azrael está sentado junto a [pet_name] en la cama."

# game/beyond the bet/soulbabyend.rpy:1403
translate Spanish soulbabayplayerroom_cb91f99d:

    # "Your bag is here. Your laptop."
    "Tu bolso está aquí. Tu laptop."

# game/beyond the bet/soulbabyend.rpy:1404
translate Spanish soulbabayplayerroom_a338fa90:

    # "...And there's Casper, too."
    "...Y Casper también está ahí."

# game/beyond the bet/soulbabyend.rpy:1409
translate Spanish soulbabayplayerroom_a45a048c:

    # GRC "It worked...?"
    GRC "¿Funcionó...?"

# game/beyond the bet/soulbabyend.rpy:1424
translate Spanish soulbabayplayerroom_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/beyond the bet/soulbabyend.rpy:1426
translate Spanish soulbabayplayerroom_d221eb59:

    # GRC "I never thought this could be possible."
    GRC "Nunca pensé que esto podría ser posible."

# game/beyond the bet/soulbabyend.rpy:1428
translate Spanish soulbabayplayerroom_6712e35b:

    # GRC "...Thank you, Sunshine."
    GRC "...Gracias, Solecito."

# game/beyond the bet/soulbabyend.rpy:1429
translate Spanish soulbabayplayerroom_bfe3a40f:

    # GRC "What now?"
    GRC "¿Y ahora qué?"

# game/beyond the bet/soulbabyend.rpy:1440
translate Spanish soulbabayplayerroom_9871267c:

    # GRC "We have little choice, really."
    GRC "No tenemos mucha opción, en realidad."

# game/beyond the bet/soulbabyend.rpy:1442
translate Spanish soulbabayplayerroom_c918d133:

    # GRC "I intend to stay with you forever, so..."
    GRC "Pienso quedarme contigo para siempre, así que..."

# game/beyond the bet/soulbabyend.rpy:1449
translate Spanish soulbabayplayerroom_833d8396:

    # GRC "And I you."
    GRC "Y yo a ti."

# game/beyond the bet/soulbabyend.rpy:1456
translate Spanish soulbabayplayerroom_91330efa:

    # GRC "Ugh..."
    GRC "Ugh..."

# game/beyond the bet/soulbabyend.rpy:1457
translate Spanish soulbabayplayerroom_e2cfa5a4:

    # GRC "Where did it go, anyway?"
    GRC "¿A dónde se fue, por cierto?"

# game/beyond the bet/soulbabyend.rpy:1474
translate Spanish soulbabayplayerroom_4d4a8863:

    # GRC "You want my soul now?!"
    GRC "¡¿Ahora quieres mi alma?!"

# game/beyond the bet/soulbabyend.rpy:1481
translate Spanish soulbabayplayerroom_8a1fd0c6:

    # GRC "...Should I be worried?"
    GRC "...¿Debería preocuparme?"

# game/beyond the bet/soulbabyend.rpy:1486
translate Spanish soulbabayplayerroom_1756d874:

    # GRC "...Fine."
    GRC "...Está bien."

# game/beyond the bet/soulbabyend.rpy:1487
translate Spanish soulbabayplayerroom_7a19575d:

    # GRC "You, my troublesome little piece of Sunshine, can have whatever piece of me you wish."
    GRC "Tú, mi problemático pedacito de Solecito, puedes tener la parte de mí que desees."

# game/beyond the bet/soulbabyend.rpy:1527
translate Spanish interwoven_end_after_f87c540b:

    # "{i}The sound of water splashing, lapping against the tub as someone steps in.{/i}"
    "{i}El sonido del agua salpicando, golpeando suavemente contra la tina mientras alguien entra.{/i}"

# game/beyond the bet/soulbabyend.rpy:1532
translate Spanish interwoven_end_after_b4e51a82:

    # "{i}You've noticed that a lot lately. Little sounds you didn't hear when you lived alone.{/i}"
    "{i}Lo has notado mucho últimamente. Pequeños sonidos que no oías cuando vivías sol[letra].{/i}"

# game/beyond the bet/soulbabyend.rpy:1533
translate Spanish interwoven_end_after_c4c0ceed:

    # "{i}{i}The sound of sheets shifting as you lay still.{/i}"
    "{i}{i}El sonido de las sábanas moviéndose mientras permaneces inmóvil.{/i}"

# game/beyond the bet/soulbabyend.rpy:1534
translate Spanish interwoven_end_after_923de9ad:

    # "{i}Pans clattering in the kitchen as you sit at your desk.{/i}"
    "{i}Sartenes resonando en la cocina mientras te sientas en tu escritorio.{/i}"

# game/beyond the bet/soulbabyend.rpy:1535
translate Spanish interwoven_end_after_85c0dccc:

    # "{i}All these little sounds have become special to you.{/i}"
    "{i}Todos estos pequeños sonidos se han vuelto especiales para ti.{/i}"

# game/beyond the bet/soulbabyend.rpy:1536
translate Spanish interwoven_end_after_c5f703d4:

    # "{i}The sound of someone else, sharing your space.{/i}"
    "{i}El sonido de otra persona compartiendo tu espacio.{/i}"

# game/beyond the bet/soulbabyend.rpy:1537
translate Spanish interwoven_end_after_aceb72a6:

    # "{i}It's enough to make you smile.{/i}"
    "{i}Es suficiente para hacerte sonreír.{/i}"

# game/beyond the bet/soulbabyend.rpy:1541
translate Spanish interwoven_end_after_98069ac3:

    # GRC "Is this... is this really what you want?!"
    GRC "¡¿Esto... esto es de verdad lo que quieres?!"

# game/beyond the bet/soulbabyend.rpy:1547
translate Spanish interwoven_end_after_c818ae5c:

    # GRC "This is more a reward for myself than you!"
    GRC "¡Esto es más una recompensa para mí que para ti!"

# game/beyond the bet/soulbabyend.rpy:1576
translate Spanish interwoven_end_after_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/soulbabyend.rpy:1599
translate Spanish interwoven_end_after_1a999333:

    # GRC "Y... yes, it feels nice!"
    GRC "¡S... sí, se siente bien!"

# game/beyond the bet/soulbabyend.rpy:1605
translate Spanish interwoven_end_after_7395fe32:

    # GRC "I am... in a bathtub, and you are... right there..."
    GRC "Estoy... en una bañera y tú estás... justo ahí..."

# game/beyond the bet/soulbabyend.rpy:1618
translate Spanish interwoven_end_after_369f58fd:

    # GRC "Are we still talking about my hair...?"
    GRC "¿Seguimos hablando de mi cabello...?"

# game/beyond the bet/soulbabyend.rpy:1622
translate Spanish interwoven_end_after_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/soulbabyend.rpy:1626
translate Spanish interwoven_end_after_669f0d74:

    # GRC "N... no..."
    GRC "N... no..."

# game/beyond the bet/soulbabyend.rpy:1627
translate Spanish interwoven_end_after_9b3393d4:

    # GRC "Please continue..."
    GRC "Por favor, continúa..."

# game/beyond the bet/soulbabyend.rpy:1633
translate Spanish interwoven_end_after_b0c4d38e:

    # GRC "But..."
    GRC "Pero..."

# game/beyond the bet/soulbabyend.rpy:1634
translate Spanish interwoven_end_after_90986bd0:

    # GRC "Next time, we should..."
    GRC "La próxima vez, deberíamos..."

# game/beyond the bet/soulbabyend.rpy:1638
translate Spanish interwoven_end_after_bfdba04b:

    # GRC "Forget about it."
    GRC "Olvídalo."

# game/beyond the bet/soulbabyend.rpy:1642
translate Spanish interwoven_end_after_91330efa:

    # GRC "Ugh..."
    GRC "Ugh..."

# game/beyond the bet/soulbabyend.rpy:1662
translate Spanish interwoven_end_after_609dbd6a:

    # GRC "Next time we should share the bath!"
    GRC "¡La próxima vez deberíamos bañarnos juntos!"

# game/beyond the bet/soulbabyend.rpy:1669
translate Spanish interwoven_end_after_726ae069:

    # GRC "If you don't want to, then forget it..."
    GRC "Si no quieres, entonces olvídalo..."

# game/beyond the bet/soulbabyend.rpy:1676
translate Spanish interwoven_end_after_fefd110f:

    # GRC "Huh?!"
    GRC "¡¿Eh?!"

# game/beyond the bet/soulbabyend.rpy:1680
translate Spanish interwoven_end_after_5f22f54c:

    # GRC "I am not!"
    GRC "¡No lo estoy!"

# game/beyond the bet/soulbabyend.rpy:1684
translate Spanish interwoven_end_after_625b860f:

    # GRC "I never go red!"
    GRC "¡Yo nunca me pongo rojo!"

# game/beyond the bet/soulbabyend.rpy:1706
translate Spanish interwoven_end_after_08f5c414:

    # "{i}You smile down at Casper.{/i}"
    "{i}Le sonríes a Casper desde arriba.{/i}"

# game/beyond the bet/soulbabyend.rpy:1707
translate Spanish interwoven_end_after_4e04358b:

    # "{i}Life is good.{/i}"
    "{i}La vida es buena.{/i}"

# game/beyond the bet/soulbabyend.rpy:1708
translate Spanish interwoven_end_after_12b38479:

    # "{i}Better than good, actually.{/i}"
    "{i}Mejor que buena, en realidad.{/i}"

# game/beyond the bet/soulbabyend.rpy:1709
translate Spanish interwoven_end_after_87247c5d:

    # "{i}It's pretty much perfect.{/i}"
    "{i}Es prácticamente perfecta.{/i}"

# game/beyond the bet/soulbabyend.rpy:1710
translate Spanish interwoven_end_after_b438f3d4:

    # "{i}You and Casper.{/i}"
    "{i}Tú y Casper.{/i}"

# game/beyond the bet/soulbabyend.rpy:1730
translate Spanish interwoven_end_after_01e07095:

    # "{i}Yeah. You like the sound of that, you think.{/i}"
    "{i}Sí. Te gusta cómo suena eso, piensas.{/i}"

translate Spanish strings:

    # game/beyond the bet/soulbabyend.rpy:73
    old "1. <Working hard, Casper?>"
    new "1. <¿Trabajando duro, Casper?>"

    # game/beyond the bet/soulbabyend.rpy:75
    old "1. <How long have I been asleep?>"
    new "1. <¿Cuánto tiempo llevo dormid[letra]?>"

    # game/beyond the bet/soulbabyend.rpy:80
    old "2. <G'morning, Casper.>"
    new "2. <Buenos días, Casper.>"

    # game/beyond the bet/soulbabyend.rpy:82
    old "1. <Wait, {i}is{/i} it morning? How can you even tell down here?>"
    new "1. <Espera, ¿{i}es{/i} de mañana? ¿Cómo puedes saberlo aquí abajo?>"

    # game/beyond the bet/soulbabyend.rpy:88
    old "1. <When did you get back?>"
    new "1. <¿Cuándo volviste?>"

    # game/beyond the bet/soulbabyend.rpy:99
    old "1. <It's so comfortable.>"
    new "1. <Es muy cómoda.>"

    # game/beyond the bet/soulbabyend.rpy:105
    old "1. <It's literally more comfortable than my bed.>"
    new "1. <Es literalmente más cómoda que mi cama.>"

    # game/beyond the bet/soulbabyend.rpy:108
    old "1. <No one told me the Underworld was the place to go for a quality mattress.>"
    new "1. <Nadie me dijo que el Inframundo era el lugar al que ir por un colchón de calidad.>"

    # game/beyond the bet/soulbabyend.rpy:111
    old "1. <Can I have it? Wait, I wouldn't want to rob Azrael of his bed...>"
    new "1. <¿Puedo quedármela? Espera, no quisiera quitarle su cama a Azrael...>"

    # game/beyond the bet/soulbabyend.rpy:114
    old "1. <I'll have to take him with me too.>"
    new "1. <Tendré que llevármelo a él también.>"

    # game/beyond the bet/soulbabyend.rpy:121
    old "1. <Perfect!>"
    new "1. <¡Perfecto!>"

    # game/beyond the bet/soulbabyend.rpy:124
    old "1. <Then I'm bringing you, too. All good things come in threes.>"
    new "1. <Entonces te llevo a ti también. Todas las cosas buenas vienen de tres en tres.>"

    # game/beyond the bet/soulbabyend.rpy:129
    old "1. <You, me, and Azrael.>"
    new "1. <Tú, yo y Azrael.>"

    # game/beyond the bet/soulbabyend.rpy:132
    old "1. <Oh, and my new comfy mattress.>"
    new "1. <Ah, y mi nuevo colchón cómodo.>"

    # game/beyond the bet/soulbabyend.rpy:135
    old "1. <Til death do us part.>"
    new "1. <Hasta que la muerte nos separe.>"

    # game/beyond the bet/soulbabyend.rpy:138
    old "2. <I got to snuggle up with Azrael. Best. Sleep. Ever.>"
    new "2. <Pude acurrucarme con Azrael. Mejor. Sueño. De. Mi. Vida.>"

    # game/beyond the bet/soulbabyend.rpy:144
    old "1. <Hahaha. You're silly.>"
    new "1. <Jajaja. Qué tonto eres.>"

    # game/beyond the bet/soulbabyend.rpy:147
    old "1. <He's just being a good boy.>"
    new "1. <Solo está siendo un buen chico.>"

    # game/beyond the bet/soulbabyend.rpy:150
    old "1. <{i}Give Azrael a little head pat{/i}.>"
    new "1. <{i}Darle a Azrael unas palmaditas en la cabeza{/i}.>"

    # game/beyond the bet/soulbabyend.rpy:152
    old "2. <{i}Give Azrael a squeeze{/i}.>"
    new "2. <{i}Darle a Azrael un apretón{/i}.>"

    # game/beyond the bet/soulbabyend.rpy:155
    old "1. <My heart belongs to one person only, Azrael.>"
    new "1. <Mi corazón le pertenece a una sola persona, Azrael.>"

    # game/beyond the bet/soulbabyend.rpy:158
    old "1. <Sorry.>"
    new "1. <Perdón.>"

    # game/beyond the bet/soulbabyend.rpy:164
    old "1. <You, stupid.>"
    new "1. <Tú, tonto.>"

    # game/beyond the bet/soulbabyend.rpy:166
    old "2. <Jeremy.>"
    new "2. <Jeremy.>"

    # game/beyond the bet/soulbabyend.rpy:170
    old "1. <It's obviously you, loser.>"
    new "1. <Obviamente eres tú, perdedor.>"

    # game/beyond the bet/soulbabyend.rpy:174
    old "3. <You know, I didn't bring any pajamas...>"
    new "3. <Sabes, no traje pijama...>"

    # game/beyond the bet/soulbabyend.rpy:176
    old "1. <Next time, I'm just gonna sleep in one of your shirts, alright?>"
    new "1. <La próxima vez voy a dormir con una de tus camisetas, ¿sí?>"

    # game/beyond the bet/soulbabyend.rpy:181
    old "1. <You'd like that, huh?>"
    new "1. <Te gustaría eso, ¿eh?>"

    # game/beyond the bet/soulbabyend.rpy:183
    old "2. <Is there a problem?>"
    new "2. <¿Hay algún problema?>"

    # game/beyond the bet/soulbabyend.rpy:187
    old "1. <Nah, I'd much rather just wear your shirt.>"
    new "1. <Nah, prefiero ponerme tu camiseta.>"

    # game/beyond the bet/soulbabyend.rpy:190
    old "1. <I wonder what would happen if I reached up while wearing your shirt...>"
    new "1. <Me pregunto qué pasaría si estirara los brazos hacia arriba con tu camiseta puesta...>"

    # game/beyond the bet/soulbabyend.rpy:192
    old "2. <Don't you think it'd be comfy?>"
    new "2. <¿No crees que sería cómodo?>"

    # game/beyond the bet/soulbabyend.rpy:196
    old "1. <Just say you want me to.>"
    new "1. <Solo di que quieres que lo haga.>"

    # game/beyond the bet/soulbabyend.rpy:202
    old "1. <Awww, don't want me to stay over?>"
    new "1. <Awww, ¿no quieres que me quede a dormir?>"

    # game/beyond the bet/soulbabyend.rpy:209
    old "1. <Oh how the tables have turned.>"
    new "1. <Cómo han cambiado las cosas.>"

    # game/beyond the bet/soulbabyend.rpy:215
    old "1. <How did it go, anyway?>"
    new "1. <¿Cómo te fue, por cierto?>"

    # game/beyond the bet/soulbabyend.rpy:218
    old "1. <Any leads?>"
    new "1. <¿Alguna pista?>"

    # game/beyond the bet/soulbabyend.rpy:234
    old "1. <I'm sorry, Casper...>"
    new "1. <Lo siento, Casper...>"

    # game/beyond the bet/soulbabyend.rpy:242
    old "1. <They didn't deserve to die.>"
    new "1. <No merecían morir.>"

    # game/beyond the bet/soulbabyend.rpy:244
    old "1. <But it's not your fault.>"
    new "1. <Pero no es tu culpa.>"

    # game/beyond the bet/soulbabyend.rpy:246
    old "2. <I'm sad for them, but I'm glad you're here.>"
    new "2. <Estoy triste por ellos, pero me alegra que estés aquí.>"

    # game/beyond the bet/soulbabyend.rpy:248
    old "1. <And maybe if you'd helped them, you wouldn't be anymore.>"
    new "1. <Y quizás si los hubieras ayudado, ya no estarías aquí.>"

    # game/beyond the bet/soulbabyend.rpy:256
    old "1. <It's just the two of us against the world, then.>"
    new "1. <Entonces somos solo los dos contra el mundo.>"

    # game/beyond the bet/soulbabyend.rpy:259
    old "1. <Well, the two of us against a buttload of reapers.>"
    new "1. <Bueno, los dos contra un montón de parcas.>"

    # game/beyond the bet/soulbabyend.rpy:262
    old "1. <You know, I might have an idea or two up my sleeves.>"
    new "1. <Sabes, quizás tenga un par de ideas bajo la manga.>"

    # game/beyond the bet/soulbabyend.rpy:265
    old "1. <And I own plenty of sleeves!>"
    new "1. <¡Y tengo muchísimas mangas!>"

    # game/beyond the bet/soulbabyend.rpy:270
    old "2. <So, here's the thing...>"
    new "2. <Entonces, resulta que...>"

    # game/beyond the bet/soulbabyend.rpy:273
    old "1. <I have this... thing.>"
    new "1. <Tengo esta... cosa.>"

    # game/beyond the bet/soulbabyend.rpy:280
    old "1. <It would be funnier if I didn't.>"
    new "1. <Sería más gracioso si no la tuviera.>"

    # game/beyond the bet/soulbabyend.rpy:282
    old "2. <Yeah.>"
    new "2. <Sí.>"

    # game/beyond the bet/soulbabyend.rpy:286
    old "1. <{i}Show Casper the letter and keycard.{/i}>"
    new "1. <{i}Mostrarle a Casper la carta y la tarjeta de acceso.{/i}>"

    # game/beyond the bet/soulbabyend.rpy:293
    old "1. <It was on my desk...>"
    new "1. <Estaba en mi escritorio...>"

    # game/beyond the bet/soulbabyend.rpy:296
    old "1. <After that other reaper spoke to me yesterday.>"
    new "1. <Después de que esa otra parca me hablara ayer.>"

    # game/beyond the bet/soulbabyend.rpy:304
    old "1. <What if I did go alone?>"
    new "1. <¿Y si de verdad fuera sol[letra]?>"

    # game/beyond the bet/soulbabyend.rpy:308
    old "1. <Maybe, but that's beside the point.>"
    new "1. <Quizás, pero eso no viene al caso.>"

    # game/beyond the bet/soulbabyend.rpy:310
    old "2. <Crazy for you, snookums.>"
    new "2. <Loc[letra] por ti, cariñito.>"

    # game/beyond the bet/soulbabyend.rpy:313
    old "1. <Whoever this is, they're obviously trying to trick me.>"
    new "1. <Quienquiera que sea, obviamente está tratando de engañarme.>"

    # game/beyond the bet/soulbabyend.rpy:316
    old "1. <It's such an obvious trap.>"
    new "1. <Es una trampa muy obvia.>"

    # game/beyond the bet/soulbabyend.rpy:319
    old "1. <Maybe they think I'm stupid or something?>"
    new "1. <¿Quizás creen que soy estúpid[letra] o algo así?>"

    # game/beyond the bet/soulbabyend.rpy:326
    old "2. <Okay, fair.>"
    new "2. <Okey, justo.>"

    # game/beyond the bet/soulbabyend.rpy:329
    old "1. <But can't we use this to our advantage?>"
    new "1. <Pero ¿no podemos usar esto a nuestro favor?>"

    # game/beyond the bet/soulbabyend.rpy:332
    old "1. <What if they DO know something that could help?>"
    new "1. <¿Y si SÍ saben algo que podría ayudar?>"

    # game/beyond the bet/soulbabyend.rpy:337
    old "1. <You should know that I'm famously hard to kill.>"
    new "1. <Deberías saber que tengo fama de ser difícil de matar.>"

    # game/beyond the bet/soulbabyend.rpy:344
    old "1. <I haven't died even once!>"
    new "1. <¡No he muerto ni una sola vez!>"

    # game/beyond the bet/soulbabyend.rpy:349
    old "1. <Trust in me, Casper.>"
    new "1. <Confía en mí, Casper.>"

    # game/beyond the bet/soulbabyend.rpy:355
    old "1. <That and you also type incorrectly a lot.>"
    new "1. <Eso, y también escribes mal muy seguido.>"

    # game/beyond the bet/soulbabyend.rpy:360
    old "1. <You really do.>"
    new "1. <Sí que lo haces.>"

    # game/beyond the bet/soulbabyend.rpy:365
    old "1. <Stupid ideas are my forte. You know that.>"
    new "1. <Las ideas estúpidas son mi especialidad. Lo sabes.>"

    # game/beyond the bet/soulbabyend.rpy:368
    old "1. <You reapers have a lot of rules and laws and stuff, right?>"
    new "1. <Ustedes, las parcas, tienen un montón de reglas y leyes y esas cosas, ¿no?>"

    # game/beyond the bet/soulbabyend.rpy:373
    old "1. <Ouch.>"
    new "1. <Auch.>"

    # game/beyond the bet/soulbabyend.rpy:375
    old "2. <I dunno, I CAN count to 100...>"
    new "2. <No sé, YO puedo contar hasta 100...>"

    # game/beyond the bet/soulbabyend.rpy:378
    old "1. <But is there anything I could use there to give me some more time?>"
    new "1. <¿Pero hay algo ahí que pueda usar para ganar más tiempo?>"

    # game/beyond the bet/soulbabyend.rpy:403
    old "1. <'The Law of Final Service'...?>"
    new "1. <¿'La Ley del Servicio Final'...?>"

    # game/beyond the bet/soulbabyend.rpy:409
    old "1. <Hey, this is actually kinda nice.>"
    new "1. <Oye, esto en realidad está bastante bien.>"

    # game/beyond the bet/soulbabyend.rpy:414
    old "1. <So they just have to do whatever I say?>"
    new "1. <¿Entonces solo tienen que hacer lo que yo diga?>"

    # game/beyond the bet/soulbabyend.rpy:424
    old "1. <What if, in that hour, I can work out how to fix things?>"
    new "1. <¿Y si, en esa hora, descubro cómo arreglar las cosas?>"

    # game/beyond the bet/soulbabyend.rpy:429
    old "1. <Let me try, Casper.>"
    new "1. <Déjame intentarlo, Casper.>"

    # game/beyond the bet/soulbabyend.rpy:432
    old "1. <Let me show you how serious I am about you. About us, together.>"
    new "1. <Déjame mostrarte lo en serio que voy contigo. Con nosotros, juntos.>"

    # game/beyond the bet/soulbabyend.rpy:438
    old "1. <I promise.>"
    new "1. <Lo prometo.>"

    # game/beyond the bet/soulbabyend.rpy:440
    old "2. <Of course.>"
    new "2. <Claro.>"

    # game/beyond the bet/soulbabyend.rpy:445
    old "1. <I'm gonna borrow this, alright?>"
    new "1. <Voy a tomar esto prestado, ¿sí?>"

    # game/beyond the bet/soulbabyend.rpy:447
    old "2. <Yoink.>"
    new "2. <¡Zas!>"

    # game/beyond the bet/soulbabyend.rpy:450
    old "1. <If anyone asks, I'm just a reaper, wearing a normal reaper jacket, \ndoing a normal walk through the normal Underworld.>"
    new "1. <Si alguien pregunta, solo soy una parca con una chaqueta de parca normal, dando un paseo normal por el Inframundo normal.>"

    # game/beyond the bet/soulbabyend.rpy:453
    old "1. <Nothing suspicious here!>"
    new "1. <¡Nada sospechoso por aquí!>"

    # game/beyond the bet/soulbabyend.rpy:455
    old "2. <Act cool, [playerfirstname], act cool.>"
    new "2. <Actúa con naturalidad, [playerfirstname], actúa con naturalidad.>"

    # game/beyond the bet/soulbabyend.rpy:464
    old "1. <How far the great fall.>"
    new "1. <Qué bajo caen los grandes.>"

    # game/beyond the bet/soulbabyend.rpy:466
    old "2. <I like frustrating you.>"
    new "2. <Me gusta frustrarte.>"

    # game/beyond the bet/soulbabyend.rpy:472
    old "1. <Stupid is my middle name.>"
    new "1. <Estúpid[letra] es mi segundo nombre.>"

    # game/beyond the bet/soulbabyend.rpy:474
    old "2. <I'm not very good at that.>"
    new "2. <No se me da muy bien eso.>"

    # game/beyond the bet/soulbabyend.rpy:476
    old "3. <Aye aye, Captain!>"
    new "3. <¡Sí, sí, capitán!>"

    # game/beyond the bet/soulbabyend.rpy:480
    old "1. <I love you.>"
    new "1. <Te amo.>"

    # game/beyond the bet/soulbabyend.rpy:482
    old "2. <See you soon, Casper.>"
    new "2. <Nos vemos pronto, Casper.>"

    # game/beyond the bet/soulbabyend.rpy:547
    old "2. <AAAAAAAAAAAAAAAAHHHHHHHHHHHH!>"
    new "2. <AAAAAAAAAAAAAAAAHHHHHHHHHHHH!>"

    # game/beyond the bet/soulbabyend.rpy:549
    old "3. <Who the, what the, how the fuck, what is, who are you?!>"
    new "3. <¡¿Quién diablos, qué diablos, cómo carajos, qué es, quién eres?!>"

    # game/beyond the bet/soulbabyend.rpy:554
    old "1. <You're him!>"
    new "1. <¡Eres tú!>"

    # game/beyond the bet/soulbabyend.rpy:557
    old "1. <Asshole Mc-Asshole face.>"
    new "1. <Imbécil Mc-Cara de imbécil.>"

    # game/beyond the bet/soulbabyend.rpy:559
    old "2. <The creepy hacker!>"
    new "2. <¡El hacker espeluznante!>"

    # game/beyond the bet/soulbabyend.rpy:561
    old "3. <That guy!>"
    new "3. <¡Ese tipo!>"

    # game/beyond the bet/soulbabyend.rpy:570
    old "1. <Can any other human do this?>"
    new "1. <¿Algún otro humano puede hacer esto?>"

    # game/beyond the bet/soulbabyend.rpy:572
    old "1. <{i}Do a small but hearty dance.{/i}>"
    new "1. <{i}Hacer un baile pequeño pero animado.{/i}>"

    # game/beyond the bet/soulbabyend.rpy:575
    old "2. <{i}Recite the alphabet backwards.{/i}>"
    new "2. <{i}Recitar el abecedario al revés.{/i}>"

    # game/beyond the bet/soulbabyend.rpy:579
    old "2. <I'm a particularly good looking human. Maybe it's that?>"
    new "2. <Soy [arti_2] human[letra] particularmente atractiv[letra]. ¿Quizás es eso?>"

    # game/beyond the bet/soulbabyend.rpy:582
    old "3. <I'm a mortal who makes annoying people my full time job.>"
    new "3. <Soy [arti_2] mortal que hace de fastidiar a la gente un trabajo de tiempo completo.>"

    # game/beyond the bet/soulbabyend.rpy:584
    old "1. <And, baby, I've never missed a day.>"
    new "1. <Y, cariño, nunca he faltado ni un día.>"

    # game/beyond the bet/soulbabyend.rpy:596
    old "1. <Screw your natural order.>"
    new "1. <Al diablo con tu orden natural.>"

    # game/beyond the bet/soulbabyend.rpy:599
    old "1. <If I was supposed to be dead, I'd be dead.>"
    new "1. <Si debiera estar muert[letra], ya lo estaría.>"

    # game/beyond the bet/soulbabyend.rpy:605
    old "1. <Maybe they shouldn't have died either.>"
    new "1. <Quizás tampoco deberían haber muerto.>"

    # game/beyond the bet/soulbabyend.rpy:611
    old "1. <'The only fairness is in death'.>"
    new "1. <'La única justicia está en la muerte'.>"

    # game/beyond the bet/soulbabyend.rpy:614
    old "1. <Yada yada yada. It's not my first rodeo, buckeroo.>"
    new "1. <Bla, bla, bla. No es mi primer rodeo, vaquero.>"

    # game/beyond the bet/soulbabyend.rpy:622
    old "1. <Hi Consequences, I'm [playerfirstname]. How do you do?>"
    new "1. <Hola, Consecuencias, soy [playerfirstname]. ¿Cómo te va?>"

    # game/beyond the bet/soulbabyend.rpy:626
    old "1. <I think it is.>"
    new "1. <Creo que sí lo es.>"

    # game/beyond the bet/soulbabyend.rpy:630
    old "1. <I think you're wrong.>"
    new "1. <Creo que te equivocas.>"

    # game/beyond the bet/soulbabyend.rpy:638
    old "1. <Are you taking suggestions?>"
    new "1. <¿Aceptas sugerencias?>"

    # game/beyond the bet/soulbabyend.rpy:645
    old "1. <Consequences?>"
    new "1. <¿Consecuencias?>"

    # game/beyond the bet/soulbabyend.rpy:647
    old "2. <Jeremy?>"
    new "2. <¿Jeremy?>"

    # game/beyond the bet/soulbabyend.rpy:649
    old "3. <[playerfirstname] the Second.>"
    new "3. <[playerfirstname] II.>"

    # game/beyond the bet/soulbabyend.rpy:658
    old "1. <You compensating for something?>"
    new "1. <¿Estás compensando algo?>"

    # game/beyond the bet/soulbabyend.rpy:660
    old "2. <Oooh, that thing looks a little dangerous.>"
    new "2. <Uuuh, esa cosa se ve un poco peligrosa.>"

    # game/beyond the bet/soulbabyend.rpy:662
    old "3. <Bad boy! Put it down!>"
    new "3. <¡Chico malo! ¡Suéltala!>"

    # game/beyond the bet/soulbabyend.rpy:669
    old "1. <I have a much better idea than me dying.>"
    new "1. <Tengo una idea mucho mejor que morirme.>"

    # game/beyond the bet/soulbabyend.rpy:672
    old "1. <How about you help me search this library for a way to get my name off your stupid list?>"
    new "1. <¿Qué tal si me ayudas a buscar en esta biblioteca una forma de sacar mi nombre de tu estúpida lista?>"

    # game/beyond the bet/soulbabyend.rpy:677
    old "1. <Even better, something that gets both me and Casper off your radar.>"
    new "1. <Mejor aún, algo que nos saque a Casper y a mí de tu radar.>"

    # game/beyond the bet/soulbabyend.rpy:681
    old "1. <Have you heard of the 'Law of Final Service'?>"
    new "1. <¿Has oído hablar de la 'Ley del Servicio Final'?>"

    # game/beyond the bet/soulbabyend.rpy:688
    old "1. <You seem like someone who likes following the rules, even if they are old.>"
    new "1. <Pareces alguien a quien le gusta seguir las reglas, aunque sean viejas.>"

    # game/beyond the bet/soulbabyend.rpy:691
    old "1. <Am I wrong?>"
    new "1. <¿Me equivoco?>"

    # game/beyond the bet/soulbabyend.rpy:700
    old "1. <Are you going to call me 'Master'?>"
    new "1. <¿Vas a llamarme 'Am[letra]'?>"

    # game/beyond the bet/soulbabyend.rpy:704
    old "1. <What if I say please?>"
    new "1. <¿Y si digo por favor?>"

    # game/beyond the bet/soulbabyend.rpy:708
    old "1. <Dang it.>"
    new "1. <Rayos.>"

    # game/beyond the bet/soulbabyend.rpy:710
    old "2. <Boooo.>"
    new "2. <Buuuu.>"

    # game/beyond the bet/soulbabyend.rpy:713
    old "1. <Fine. Then what I actually want you to do is search this place for anything that could possibly help Casper and I.>"
    new "1. <Bien. Entonces lo que en realidad quiero que hagas es buscar en este lugar cualquier cosa que pueda ayudarnos a Casper y a mí.>"

    # game/beyond the bet/soulbabyend.rpy:719
    old "1. <I should be more clear.>"
    new "1. <Debería ser más clar[letra].>"

    # game/beyond the bet/soulbabyend.rpy:722
    old "1. <It has to be something that will help us not be hunted any more.>"
    new "1. <Tiene que ser algo que ayude a que dejen de perseguirnos.>"

    # game/beyond the bet/soulbabyend.rpy:725
    old "1. <I want to be able to go home, and I want Casper to go with me.>"
    new "1. <Quiero poder volver a casa, y quiero que Casper venga conmigo.>"

    # game/beyond the bet/soulbabyend.rpy:739
    old "1. <It has to be...>"
    new "1. <Tiene que ser...>"

    # game/beyond the bet/soulbabyend.rpy:754
    old "1. <Get back to work, Reaper boy.>"
    new "1. <Vuelve al trabajo, chico Parca.>"

    # game/beyond the bet/soulbabyend.rpy:758
    old "1. <You haven't told me what to call you.>"
    new "1. <No me has dicho cómo llamarte.>"

    # game/beyond the bet/soulbabyend.rpy:765
    old "1. <Can I call you five for short?>"
    new "1. <¿Puedo llamarte Cinco para abreviar?>"

    # game/beyond the bet/soulbabyend.rpy:781
    old "you make me worry..."
    new "me preocupas..."

    # game/beyond the bet/soulbabyend.rpy:811
    old "1. <My beloved Casper, where art thou?>"
    new "1. <Mi amado Casper, ¿dónde te hallas?>"

    # game/beyond the bet/soulbabyend.rpy:815
    old "1. <That was a little more serious than I was going for, uhhhh...>"
    new "1. <Eso fue un poco más serio de lo que buscaba, ehhhh...>"

    # game/beyond the bet/soulbabyend.rpy:817
    old "2. <I'm alive!>"
    new "2. <¡Estoy viv[letra]!>"

    # game/beyond the bet/soulbabyend.rpy:821
    old "1. <I'll pretend that makes sense. Uh huh.>"
    new "1. <Fingiré que eso tiene sentido. Aja.>"

    # game/beyond the bet/soulbabyend.rpy:823
    old "3. <Ooooh. It's the ghooost of [playerfirstname], \nhere to haaaaaunt youuuu~>"
    new "3. <Uuuuuh. Es el fantaaasma de [playerfirstname], que viene a atormeeentarteee~>"

    # game/beyond the bet/soulbabyend.rpy:827
    old "1. <There's a first time for everything, Casper.>"
    new "1. <Todo tiene una primera vez, Casper.>"

    # game/beyond the bet/soulbabyend.rpy:839
    old "1. <I got here safely, and now I'm making my new servant search the shelves.>"
    new "1. <Llegué bien y ahora estoy haciendo que mi nuevo sirviente busque en los estantes.>"

    # game/beyond the bet/soulbabyend.rpy:844
    old "1. <Why thank the gods when I'm right here?>"
    new "1. <¿Por qué agradecerles a los dioses si estoy justo aquí?>"

    # game/beyond the bet/soulbabyend.rpy:846
    old "2. <It was really pretty easy.>"
    new "2. <Fue bastante fácil, la verdad.>"

    # game/beyond the bet/soulbabyend.rpy:849
    old "1. <This guy is kinda a prick, though.>"
    new "1. <Aunque este tipo es medio idiota.>"

    # game/beyond the bet/soulbabyend.rpy:853
    old "1. <Oh, yeah. 5012.>"
    new "1. <Ah, sí. 5012.>"

    # game/beyond the bet/soulbabyend.rpy:856
    old "1. <I asked if I could give him a nickname, but he said no :(>"
    new "1. <Le pregunté si podía ponerle un apodo, pero dijo que no :(>"

    # game/beyond the bet/soulbabyend.rpy:861
    old "1. <You know him?>"
    new "1. <¿Lo conoces?>"

    # game/beyond the bet/soulbabyend.rpy:863
    old "2. <I wasn't expecting recognition.>"
    new "2. <No esperaba que lo reconocieras.>"

    # game/beyond the bet/soulbabyend.rpy:869
    old "1. <You, disciplined?>"
    new "1. <¿Tú, castigado?>"

    # game/beyond the bet/soulbabyend.rpy:872
    old "1. <Were you a bad boy?>"
    new "1. <¿Fuiste un chico malo?>"

    # game/beyond the bet/soulbabyend.rpy:874
    old "2. <The high and mighty Casper?>"
    new "2. <¿El altivo y poderoso Casper?>"

    # game/beyond the bet/soulbabyend.rpy:879
    old "1. <And here I thought you were born perfect.>"
    new "1. <Y yo que pensaba que habías nacido perfecto.>"

    # game/beyond the bet/soulbabyend.rpy:885
    old "1. <Huh.>"
    new "1. <Vaya.>"

    # game/beyond the bet/soulbabyend.rpy:888
    old "1. <Maybe you and this guy are pretty similar actually...>"
    new "1. <Quizás tú y este tipo se parecen bastante, en realidad...>"

    # game/beyond the bet/soulbabyend.rpy:896
    old "1. <ANYWAY!>"
    new "1. <¡DE TODOS MODOS!>"

    # game/beyond the bet/soulbabyend.rpy:899
    old "1. <I'm going to help search.>"
    new "1. <Voy a ayudar a buscar.>"

    # game/beyond the bet/soulbabyend.rpy:905
    old "1. <You jealous I'm spending time with someone else?>"
    new "1. <¿Estás celoso de que pase tiempo con otra persona?>"

    # game/beyond the bet/soulbabyend.rpy:912
    old "1. <Casper, my love.>"
    new "1. <Casper, mi amor.>"

    # game/beyond the bet/soulbabyend.rpy:915
    old "1. <My most dearest.>"
    new "1. <Mi queridísimo.>"

    # game/beyond the bet/soulbabyend.rpy:918
    old "1. <My beloved.>"
    new "1. <Mi amado.>"

    # game/beyond the bet/soulbabyend.rpy:921
    old "1. <You are sooo jealous.>"
    new "1. <Estás celosísimo.>"

    # game/beyond the bet/soulbabyend.rpy:924
    old "1. <How cute.>"
    new "1. <Qué tierno.>"

    # game/beyond the bet/soulbabyend.rpy:926
    old "2. <Tut tut, Mister.>"
    new "2. <Tsk, tsk, señor.>"

    # game/beyond the bet/soulbabyend.rpy:928
    old "3. <You're the only reaper for me.>"
    new "3. <Eres la única parca para mí.>"

    # game/beyond the bet/soulbabyend.rpy:931
    old "1. <But don't come yet.>"
    new "1. <Pero no vengas todavía.>"

    # game/beyond the bet/soulbabyend.rpy:934
    old "1. <I need you to be a surprise.>"
    new "1. <Necesito que seas una sorpresa.>"

    # game/beyond the bet/soulbabyend.rpy:938
    old "1. <Yes, nude.>"
    new "1. <Sí, desnudo.>"

    # game/beyond the bet/soulbabyend.rpy:940
    old "2. <Wait, is that an option?>"
    new "2. <Espera, ¿es una opción?>"

    # game/beyond the bet/soulbabyend.rpy:946
    old "2. <A shame.>"
    new "2. <Qué pena.>"

    # game/beyond the bet/soulbabyend.rpy:949
    old "1. <Let's workshop the cake idea later.>"
    new "1. <Luego trabajamos la idea del pastel.>"

    # game/beyond the bet/soulbabyend.rpy:953
    old "1. <We're putting a pin in it.>"
    new "1. <La dejamos pendiente.>"

    # game/beyond the bet/soulbabyend.rpy:957
    old "1. <Maybe for my birthday?>"
    new "1. <¿Quizás para mi cumpleaños?>"

    # game/beyond the bet/soulbabyend.rpy:959
    old "2. <At our wedding!>"
    new "2. <¡En nuestra boda!>"

    # game/beyond the bet/soulbabyend.rpy:962
    old "1. <But!!!>"
    new "1. <¡¡¡Pero!!!>"

    # game/beyond the bet/soulbabyend.rpy:965
    old "1. <What I actually meant was, he is probably expecting you to turn up now.>"
    new "1. <Lo que en realidad quería decir es que probablemente él espera que aparezcas ahora.>"

    # game/beyond the bet/soulbabyend.rpy:968
    old "1. <If you wait until the hour is up, he's gonna think he's won.>"
    new "1. <Si esperas a que se acabe la hora, va a pensar que ganó.>"

    # game/beyond the bet/soulbabyend.rpy:971
    old "1. <I want to wipe the smug look off his face.>"
    new "1. <Quiero borrarle esa cara de suficiencia.>"

    # game/beyond the bet/soulbabyend.rpy:977
    old "1. <What can I say, it's just in my personality.>"
    new "1. <Qué puedo decir, es parte de mi personalidad.>"

    # game/beyond the bet/soulbabyend.rpy:980
    old "1. <You reapers are just so bullyable!>"
    new "1. <¡Ustedes, las parcas, son tan fáciles de molestar!>"

    # game/beyond the bet/soulbabyend.rpy:982
    old "2. <I want to keep you safe.>"
    new "2. <Quiero mantenerte a salvo.>"

    # game/beyond the bet/soulbabyend.rpy:985
    old "1. <If I get to be a little mean to him along the way, I think it was meant to be.>"
    new "1. <Si de paso puedo ser un poquito mal[letra] con él, creo que estaba destinado a ser.>"

    # game/beyond the bet/soulbabyend.rpy:991
    old "1. <Now, that's a cute picture in my head.>"
    new "1. <Esa sí que es una imagen tierna en mi cabeza.>"

    # game/beyond the bet/soulbabyend.rpy:993
    old "2. <Awww, Casper.>"
    new "2. <Awww, Casper.>"

    # game/beyond the bet/soulbabyend.rpy:998
    old "1. <I'll message you.>"
    new "1. <Te escribiré.>"

    # game/beyond the bet/soulbabyend.rpy:1010
    old "1. <I'll be counting on you, then.>"
    new "1. <Entonces contaré contigo.>"

    # game/beyond the bet/soulbabyend.rpy:1012
    old "2. <I'll call real loud!>"
    new "2. <¡Llamaré bien fuerte!>"

    # game/beyond the bet/soulbabyend.rpy:1015
    old "1. <See you soon, okay?>"
    new "1. <Nos vemos pronto, ¿okey?>"

    # game/beyond the bet/soulbabyend.rpy:1040
    old "1. <You found anything, Reaper boy?>"
    new "1. <¿Encontraste algo, chico Parca?>"

    # game/beyond the bet/soulbabyend.rpy:1054
    old "1. <Ha. Ha. Ha.>"
    new "1. <Ja. Ja. Ja.>"

    # game/beyond the bet/soulbabyend.rpy:1057
    old "1. <You're such a comedian.>"
    new "1. <Eres todo un comediante.>"

    # game/beyond the bet/soulbabyend.rpy:1060
    old "1. <Anything USEFUL, doofus.>"
    new "1. <Algo ÚTIL, bobo.>"

    # game/beyond the bet/soulbabyend.rpy:1066
    old "1. <Keep looking.>"
    new "1. <Sigue buscando.>"

    # game/beyond the bet/soulbabyend.rpy:1073
    old "1. <Or...>"
    new "1. <O...>"

    # game/beyond the bet/soulbabyend.rpy:1076
    old "1. <How about we spend the next 45 minutes doing an interpretive dance together?>"
    new "1. <¿Qué tal si pasamos los próximos 45 minutos haciendo un baile interpretativo juntos?>"

    # game/beyond the bet/soulbabyend.rpy:1078
    old "2. <We could just spend it chatting! That would be fun.>"
    new "2. <¡Podríamos pasarlo charlando! Sería divertido.>"

    # game/beyond the bet/soulbabyend.rpy:1080
    old "3. <Oh! We could play a board game.>"
    new "3. <¡Oh! Podríamos jugar un juego de mesa.>"

    # game/beyond the bet/soulbabyend.rpy:1082
    old "1. <That one with all the circles.>"
    new "1. <Ese que tiene todos los círculos.>"

    # game/beyond the bet/soulbabyend.rpy:1085
    old "1. <Left hand green... oh no! I've slipped and fallen on top of you!>"
    new "1. <Mano izquierda en verde... ¡oh, no! ¡Me resbalé y caí encima de ti!>"

    # game/beyond the bet/soulbabyend.rpy:1096
    old "1. <{i}Start searching.{/i}>"
    new "1. <{i}Empezar a buscar.{/i}>"

    # game/beyond the bet/soulbabyend.rpy:1116
    old "1. <All of these books suck!>"
    new "1. <¡Todos estos libros son un asco!>"

    # game/beyond the bet/soulbabyend.rpy:1119
    old "1. <Why is there so much... so much...>"
    new "1. <¿Por qué hay tanto... tanto...?>"

    # game/beyond the bet/soulbabyend.rpy:1144
    old "1. <Keep looking...>"
    new "1. <Sigue buscando...>"

    # game/beyond the bet/soulbabyend.rpy:1147
    old "1. <There has to be something.>"
    new "1. <Tiene que haber algo.>"

    # game/beyond the bet/soulbabyend.rpy:1149
    old "2. <Until the last moment.>"
    new "2. <Hasta el último momento.>"

    # game/beyond the bet/soulbabyend.rpy:1201
    old "1. <Casper...!>"
    new "1. <¡Casper...!>"

    # game/beyond the bet/soulbabyend.rpy:1225
    old "1. <You came...>"
    new "1. <Viniste...>"

    # game/beyond the bet/soulbabyend.rpy:1239
    old "1. <Casper, do you trust me?>"
    new "1. <Casper, ¿confías en mí?>"

    # game/beyond the bet/soulbabyend.rpy:1243
    old "1. <Meet me on the bridge!>"
    new "1. <¡Nos vemos en el puente!>"

    # game/beyond the bet/soulbabyend.rpy:1267
    old "1. <You. Me. Soulbaby.>"
    new "1. <Tú. Yo. Bebé alma.>"

    # game/beyond the bet/soulbabyend.rpy:1270
    old "1. <I think they might be, actually.>"
    new "1. <Creo que podrían serlo, en realidad.>"

    # game/beyond the bet/soulbabyend.rpy:1272
    old "2. <I found something that might help.>"
    new "2. <Encontré algo que podría ayudar.>"

    # game/beyond the bet/soulbabyend.rpy:1274
    old "1. <A way to make me something other than human, and you something other than a Grim Reaper.>"
    new "1. <Una forma de convertirme en algo distinto de un ser humano y a ti en algo distinto de una Parca.>"

    # game/beyond the bet/soulbabyend.rpy:1277
    old "1. <They might stop hunting us, if they're such sticklers for rules.>"
    new "1. <Podrían dejar de perseguirnos, si son tan estrictos con las reglas.>"

    # game/beyond the bet/soulbabyend.rpy:1282
    old "1. <We'll combine a part of each of our souls.>"
    new "1. <Combinaremos una parte de cada una de nuestras almas.>"

    # game/beyond the bet/soulbabyend.rpy:1288
    old "1. <What I really want is to be with you.>"
    new "1. <Lo que realmente quiero es estar contigo.>"

    # game/beyond the bet/soulbabyend.rpy:1290
    old "2. <Yes, it is.>"
    new "2. <Sí, lo es.>"

    # game/beyond the bet/soulbabyend.rpy:1293
    old "1. <If it's what you want, too.>"
    new "1. <Si es lo que tú también quieres.>"

    # game/beyond the bet/soulbabyend.rpy:1298
    old "1. <{i}Reach out with your soul.{/i}>"
    new "1. <{i}Extender tu alma.{/i}>"

    # game/beyond the bet/soulbabyend.rpy:1323
    old "1. <A sunflower.>"
    new "1. <Un girasol.>"

    # game/beyond the bet/soulbabyend.rpy:1325
    old "2. <A skull.>"
    new "2. <Una calavera.>"

    # game/beyond the bet/soulbabyend.rpy:1327
    old "3. <An axolotl.>"
    new "3. <Un ajolote.>"

    # game/beyond the bet/soulbabyend.rpy:1338
    old "1. <A soulbaby!>"
    new "1. <¡Un bebé alma!>"

    # game/beyond the bet/soulbabyend.rpy:1344
    old "1. <It's effectively a soulbaby.>"
    new "1. <En efecto, es un bebé alma.>"

    # game/beyond the bet/soulbabyend.rpy:1347
    old "1. <I wonder if he'll have my eyes or yours...>"
    new "1. <Me pregunto si tendrá mis ojos o los tuyos...>"

    # game/beyond the bet/soulbabyend.rpy:1351
    old "2. <A part of us.>"
    new "2. <Una parte de nosotros.>"

    # game/beyond the bet/soulbabyend.rpy:1353
    old "1. <And you're right. We're not the same anymore.>"
    new "1. <Y tienes razón. Ya no somos los mismos.>"

    # game/beyond the bet/soulbabyend.rpy:1370
    old "1. <We'll invite you to the wedding.>"
    new "1. <Te invitaremos a la boda.>"

    # game/beyond the bet/soulbabyend.rpy:1372
    old "2. <Wow, you like me that much?>"
    new "2. <Wow, ¿tanto te gusto?>"

    # game/beyond the bet/soulbabyend.rpy:1374
    old "3. <Sorry, I'm taken.>"
    new "3. <Lo siento, ya tengo pareja.>"

    # game/beyond the bet/soulbabyend.rpy:1406
    old "1. <It... worked.>"
    new "1. <Esto... funcionó.>"

    # game/beyond the bet/soulbabyend.rpy:1411
    old "1. <It worked!>"
    new "1. <¡Funcionó!>"

    # game/beyond the bet/soulbabyend.rpy:1414
    old "1. <We're back, Casper! We're back!>"
    new "1. <¡Volvimos, Casper! ¡Volvimos!>"

    # game/beyond the bet/soulbabyend.rpy:1416
    old "2. <Welcome home.>"
    new "2. <Bienvenido a casa.>"

    # game/beyond the bet/soulbabyend.rpy:1419
    old "1. <The sun! My stupid plant! Everything's... everything's still here.>"
    new "1. <¡El sol! ¡Mi estúpida planta! Todo... todo sigue aquí.>"

    # game/beyond the bet/soulbabyend.rpy:1422
    old "1. <But now it's even better, because you're here too.>"
    new "1. <Pero ahora es aún mejor, porque tú también estás aquí.>"

    # game/beyond the bet/soulbabyend.rpy:1431
    old "1. <Well, I feel like we're gonna have to work out the whole 'no proof you were ever born' thing.>"
    new "1. <Bueno, creo que tendremos que resolver eso de que 'no hay pruebas de que hayas nacido'.>"

    # game/beyond the bet/soulbabyend.rpy:1434
    old "1. <Without any legal documents, it might be hard...>"
    new "1. <Sin ningún documento legal, podría ser difícil...>"

    # game/beyond the bet/soulbabyend.rpy:1437
    old "1. <But we'll work something out, right?>"
    new "1. <Pero encontraremos algo, ¿verdad?>"

    # game/beyond the bet/soulbabyend.rpy:1444
    old "1. <Aww, Casper...>"
    new "1. <Aww, Casper...>"

    # game/beyond the bet/soulbabyend.rpy:1447
    old "1. <I really do love you.>"
    new "1. <De verdad te amo.>"

    # game/beyond the bet/soulbabyend.rpy:1451
    old "1. <Thanks for having soulbabies with me.>"
    new "1. <Gracias por tener bebés alma conmigo.>"

    # game/beyond the bet/soulbabyend.rpy:1453
    old "2. <I really can't believe that worked...>"
    new "2. <No puedo creer que de verdad funcionara...>"

    # game/beyond the bet/soulbabyend.rpy:1459
    old "1. <I don't know.>"
    new "1. <No lo sé.>"

    # game/beyond the bet/soulbabyend.rpy:1462
    old "1. <I only saw it for a split second, then it disappeared.>"
    new "1. <Solo lo vi una fracción de segundo y luego desapareció.>"

    # game/beyond the bet/soulbabyend.rpy:1465
    old "1. <I guess it's quietly keeping us safe.>"
    new "1. <Supongo que nos mantiene a salvo en silencio.>"

    # game/beyond the bet/soulbabyend.rpy:1468
    old "1. <Hey, would you say I won our bet?>"
    new "1. <Oye, ¿dirías que gané nuestra apuesta?>"

    # game/beyond the bet/soulbabyend.rpy:1471
    old "1. <You didn't take my soul.>"
    new "1. <No te llevaste mi alma.>"

    # game/beyond the bet/soulbabyend.rpy:1479
    old "1. <Can I pick something else?>"
    new "1. <¿Puedo elegir otra cosa?>"

    # game/beyond the bet/soulbabyend.rpy:1483
    old "1. <Oh, absolutely.>"
    new "1. <Ah, por supuesto.>"

    # game/beyond the bet/soulbabyend.rpy:1543
    old "1. <It is!>"
    new "1. <¡Sí lo es!>"

    # game/beyond the bet/soulbabyend.rpy:1545
    old "2. <Sit still, will you?!>"
    new "2. <¡¿Quieres quedarte quieto?!>"

    # game/beyond the bet/soulbabyend.rpy:1549
    old "1. <Then stop wiggling!>"
    new "1. <¡Entonces deja de moverte!>"

    # game/beyond the bet/soulbabyend.rpy:1552
    old "1. <There.>"
    new "1. <Listo.>"

    # game/beyond the bet/soulbabyend.rpy:1555
    old "1. <Does it feel nice?>"
    new "1. <¿Se siente bien?>"

    # game/beyond the bet/soulbabyend.rpy:1578
    old "1. <Casper...?>"
    new "1. <¿Casper...?>"

    # game/beyond the bet/soulbabyend.rpy:1601
    old "1. <Are you thinking something dirty?>"
    new "1. <¿Estás pensando en algo sucio?>"

    # game/beyond the bet/soulbabyend.rpy:1603
    old "2. <What are you so distracted with, hmmm?>"
    new "2. <¿En qué estás tan distraído, mmm?>"

    # game/beyond the bet/soulbabyend.rpy:1607
    old "1. <Well, I can't wash your hair from the next room over!>"
    new "1. <¡Bueno, no puedo lavarte el cabello desde la habitación de al lado!>"

    # game/beyond the bet/soulbabyend.rpy:1610
    old "1. <Seriously, from the first second I saw your hair, I knew I had to touch it properly one day.>"
    new "1. <En serio, desde el primer segundo que vi tu cabello, supe que algún día tendría que tocarlo como se debe.>"

    # game/beyond the bet/soulbabyend.rpy:1613
    old "1. <It's so soft!>"
    new "1. <¡Es tan suave!>"

    # game/beyond the bet/soulbabyend.rpy:1616
    old "1. <So long!>"
    new "1. <¡Tan largo!>"

    # game/beyond the bet/soulbabyend.rpy:1620
    old "1. <What else would I be talking about?>"
    new "1. <¿De qué más estaría hablando?>"

    # game/beyond the bet/soulbabyend.rpy:1624
    old "1. <If you don't like it, I can stop.>"
    new "1. <Si no te gusta, puedo parar.>"

    # game/beyond the bet/soulbabyend.rpy:1631
    old "2. <Yessir.>"
    new "2. <Sí, señor.>"

    # game/beyond the bet/soulbabyend.rpy:1640
    old "1. <Do you want me to pull your hair?>"
    new "1. <¿Quieres que te tire del cabello?>"

    # game/beyond the bet/soulbabyend.rpy:1664
    old "1. <Oho.>"
    new "1. <Oho.>"

    # game/beyond the bet/soulbabyend.rpy:1667
    old "1. <Someone is getting very confident over here.>"
    new "1. <Alguien se está poniendo muy confiado por aquí.>"

    # game/beyond the bet/soulbabyend.rpy:1671
    old "1. <Did I say that?>"
    new "1. <¿Eso dije?>"

    # game/beyond the bet/soulbabyend.rpy:1674
    old "1. <In fact, why don't I just hop in now?>"
    new "1. <De hecho, ¿por qué no me meto ahora mismo?>"

    # game/beyond the bet/soulbabyend.rpy:1678
    old "1. <You're going red.>"
    new "1. <Te estás poniendo rojo.>"

    # game/beyond the bet/soulbabyend.rpy:1686
    old "1. <I love how bad you are at lying, now that you can do it.>"
    new "1. <Me encanta lo malo que eres para mentir, ahora que puedes hacerlo.>"

