# TODO: Translation updated at 2026-10-15 18:36

# game/beyond the bet/7dlc_roomexplore.rpy:215
translate Spanish bed_hub7dlc_76d6bcf2:

    # "Day seven already."
    "Ya es el séptimo día."

# game/beyond the bet/7dlc_roomexplore.rpy:216
translate Spanish bed_hub7dlc_acd0984c:

    # "The bet's come and gone faster than you ever would have expected."
    "La apuesta empezó y terminó mucho más rápido de lo que jamás habrías imaginado."

# game/beyond the bet/7dlc_roomexplore.rpy:217
translate Spanish bed_hub7dlc_f478508f:

    # "What started as a joke has now become...."
    "Lo que empezó como una broma se ha convertido en algo..."

# game/beyond the bet/7dlc_roomexplore.rpy:218
translate Spanish bed_hub7dlc_c077ee6d:

    # "Something far more."
    "Algo mucho más."

# game/beyond the bet/7dlc_roomexplore.rpy:219
translate Spanish bed_hub7dlc_b31778b1:

    # "[pet_name] isn't on your bed for the moment, so you lay like a starfish, stare at your ceiling, and think about your stupid Grim Reaper."
    "[pet_name] no está en tu cama por ahora, así que te estiras como una estrella de mar, miras al techo y piensas en tu estúpida Parca."

# game/beyond the bet/7dlc_roomexplore.rpy:220
translate Spanish bed_hub7dlc_6ec9af91:

    # "...You're so down bad you can barely believe it. What a bother."
    "...Estás tan colad[letra] por él que ni tú mism[letra] puedes creértelo. Qué fastidio."

# game/beyond the bet/7dlc_roomexplore.rpy:228
translate Spanish door_hub7dlc_61d26833:

    # "You put your ear to the door, ready to eavesdrop on your neighbors once again..."
    "Pegas la oreja a la puerta, list[letra] para espiar a tus vecinos una vez más..."

# game/beyond the bet/7dlc_roomexplore.rpy:229
translate Spanish door_hub7dlc_eb006a43:

    # "But instead of whispers, or phone calls, or proclamations of love..."
    "Pero en lugar de susurros, llamadas telefónicas o declaraciones de amor..."

# game/beyond the bet/7dlc_roomexplore.rpy:230
translate Spanish door_hub7dlc_0c8370e0:

    # "You hear the sound of moving!"
    "¡Oyes el ruido de una mudanza en marcha!"

# game/beyond the bet/7dlc_roomexplore.rpy:231
translate Spanish door_hub7dlc_aa051b6c:

    # "You poke your head out, curious, to see people from a moving company carrying boxes from the apartment next door."
    "Asomas la cabeza, con curiosidad, y ves a gente de una empresa de mudanzas sacando cajas del apartamento de al lado."

# game/beyond the bet/7dlc_roomexplore.rpy:232
translate Spanish door_hub7dlc_6ea728ab:

    # "It seems your neighbor is very suddenly moving."
    "Parece que quien vive al lado se muda de forma muy repentina."

# game/beyond the bet/7dlc_roomexplore.rpy:233
translate Spanish door_hub7dlc_d443eceb:

    # "Feeling a little disappointed but also incredibly curious, you go back into your apartment and think for a while on your next door neighbor."
    "Algo decepcionad[letra], pero también increíblemente curios[letra], vuelves a tu apartamento y piensas un rato en quien vivía al lado."

# game/beyond the bet/7dlc_roomexplore.rpy:234
translate Spanish door_hub7dlc_e0f5ed86:

    # "You never met them - never even got their name... life is pretty fleeting, huh?"
    "Nunca llegaste a conocerle, ni siquiera supiste su nombre... La vida pasa bastante rápido, ¿eh?"

# game/beyond the bet/7dlc_roomexplore.rpy:239
translate Spanish door_hub7dlc_3844b164:

    # "You hear the hustle and bustle of feet squeaking against the floor and heavy boxes being lugged downstairs..."
    "Oyes el ajetreo de pasos que chirrían contra el suelo y de cajas pesadas arrastradas escaleras abajo..."

# game/beyond the bet/7dlc_roomexplore.rpy:240
translate Spanish door_hub7dlc_2061b2c0:

    # "But you don't hear your neighbors."
    "Pero no oyes a tus vecinos."

# game/beyond the bet/7dlc_roomexplore.rpy:262
translate Spanish plant_hub7dlc_c1229c6a:

    # "You give your little sprout a big drink of water."
    "Le das a tu pequeño retoño un buen trago de agua."

# game/beyond the bet/7dlc_roomexplore.rpy:263
translate Spanish plant_hub7dlc_c5de961c:

    # "Though you don't speak sprout, it seems to say thank you."
    "Aunque no hablas el idioma de los retoños, parece darte las gracias."

# game/beyond the bet/7dlc_roomexplore.rpy:265
translate Spanish plant_hub7dlc_518e64fd:

    # "Your little sprout has grown some leaves!"
    "¡A tu pequeño retoño le han salido hojas!"

# game/beyond the bet/7dlc_roomexplore.rpy:266
translate Spanish plant_hub7dlc_8036dce1:

    # "You can't help but feel proud as you give it a big drink of water."
    "No puedes evitar sentir orgullo mientras le das un buen trago de agua."

# game/beyond the bet/7dlc_roomexplore.rpy:268
translate Spanish plant_hub7dlc_adaac543:

    # "Even more leaves have appeared now!"
    "¡Ahora han aparecido aún más hojas!"

# game/beyond the bet/7dlc_roomexplore.rpy:269
translate Spanish plant_hub7dlc_a4970463:

    # "You water it generously and feel excited that, this time, you didn't kill your plant instantly."
    "La riegas abundantemente y te emociona comprobar que esta vez no has matado tu planta nada más empezar."

# game/beyond the bet/7dlc_roomexplore.rpy:271
translate Spanish plant_hub7dlc_2087a70f:

    # "Your little plant is growing healthily!"
    "¡Tu pequeña planta está creciendo sana y fuerte!"

# game/beyond the bet/7dlc_roomexplore.rpy:272
translate Spanish plant_hub7dlc_80d209cf:

    # "You give it a big drink of water, excited about its growth."
    "Le das un buen trago de agua, con entusiasmo por su crecimiento."

# game/beyond the bet/7dlc_roomexplore.rpy:274
translate Spanish plant_hub7dlc_41affa3b:

    # "Your little plant has sprouted some buds!"
    "¡A tu pequeña planta le han salido algunos botones florales!"

# game/beyond the bet/7dlc_roomexplore.rpy:275
translate Spanish plant_hub7dlc_75fbf720:

    # "You almost tear up when you notice them. They're so cute - you can't wait to see what the flowers will look like."
    "Casi se te saltan las lágrimas al verlos. ¡Son tan adorables! No puedes esperar a ver cómo serán las flores."

# game/beyond the bet/7dlc_roomexplore.rpy:277
translate Spanish plant_hub7dlc_33ab5804:

    # "The buds on your little plant seem to be doing well!"
    "¡Los botones florales de tu pequeña planta parecen estar desarrollándose bien!"

# game/beyond the bet/7dlc_roomexplore.rpy:278
translate Spanish plant_hub7dlc_8b2d7914:

    # "You can't believe how healthy it is... though after what Casper told you, you're starting to understand why..."
    "No puedes creer lo saludable que está... aunque después de lo que te contó Casper, empiezas a entender por qué..."

# game/beyond the bet/7dlc_roomexplore.rpy:280
translate Spanish plant_hub7dlc_3a8cf5f3:

    # "Your little sprout has grown up happily and healthily all because of you, and today..."
    "Tu pequeño retoño ha crecido feliz y saludable gracias a ti, y hoy..."

# game/beyond the bet/7dlc_roomexplore.rpy:286
translate Spanish plant_hub7dlc_3542ab9b:

    # "It rewards you with four beautiful flowers!"
    "¡Te recompensa con cuatro hermosas flores!"

# game/beyond the bet/7dlc_roomexplore.rpy:287
translate Spanish plant_hub7dlc_c9e73e13:

    # "You water your plant and feel a sense of accomplishment."
    "Riegas tu planta y sientes una sensación de logro."

# game/beyond the bet/7dlc_roomexplore.rpy:289
translate Spanish plant_hub7dlc_1f8f8ef0:

    # "You stare at the beautiful blooming flower on your beautiful plant."
    "Contemplas la hermosa flor que ha florecido en tu hermosa planta."

# game/beyond the bet/7dlc_roomexplore.rpy:290
translate Spanish plant_hub7dlc_74334dfd:

    # "It really is amazing you managed to not kill this one."
    "De verdad es asombroso que hayas logrado no matar a esta."

# game/beyond the bet/7dlc_roomexplore.rpy:291
translate Spanish plant_hub7dlc_20285160:

    # "You give yourself a pat on the back - you really are the best."
    "Te das una palmadita en la espalda: de verdad eres [arti] mejor."

# game/beyond the bet/7dlc_roomexplore.rpy:305
translate Spanish plant_hub7dlc_bc195acd:

    # "It still looks a little dry, so you give your plant some extra water."
    "Todavía se ve un poco seca, así que le das a tu planta un poco más de agua."

# game/beyond the bet/7dlc_roomexplore.rpy:306
translate Spanish plant_hub7dlc_3ff72aaf:

    # "You're sure it'll enjoy it."
    "Seguro que le encantará."

# game/beyond the bet/7dlc_roomexplore.rpy:320
translate Spanish plant_hub7dlc_8d6db9a0:

    # "You would happily watch the world burn."
    "Verías el mundo arder con gusto."

# game/beyond the bet/7dlc_roomexplore.rpy:321
translate Spanish plant_hub7dlc_efc8bb2a:

    # "Or, in this case, drown under your endless watering."
    "O, en este caso, ahogarse bajo tu riego interminable."

# game/beyond the bet/7dlc_roomexplore.rpy:322
translate Spanish plant_hub7dlc_be48a4f8:

    # "And you would smile all the while."
    "Y sonreirías todo el tiempo."

translate Spanish strings:

    # game/beyond the bet/7dlc_roomexplore.rpy:29
    old "Your Bed"
    new "Tu Cama"

    # game/beyond the bet/7dlc_roomexplore.rpy:37
    old "Door"
    new "Puerta"

    # game/beyond the bet/7dlc_roomexplore.rpy:46
    old "Your Plant"
    new "Tu Planta"

    # game/beyond the bet/7dlc_roomexplore.rpy:54
    old "Renovate & Appearance"
    new "Renovación & Apariencia"

    # game/beyond the bet/7dlc_roomexplore.rpy:62
    old "Your Laptop"
    new "Tu Portátil"

    # game/beyond the bet/7dlc_roomexplore.rpy:70
    old "Bookshelf"
    new "Estantería"

    # game/beyond the bet/7dlc_roomexplore.rpy:78
    old "Change Music"
    new "Cambiar Música"

    # game/beyond the bet/7dlc_roomexplore.rpy:171
    old "Name your pet:"
    new "Mascota:"

    # game/beyond the bet/7dlc_roomexplore.rpy:172
    old "Gender:"
    new "Género:"

    # game/beyond the bet/7dlc_roomexplore.rpy:201
    old "COMPLETE"
    new "TERMINAR"

    # game/beyond the bet/7dlc_roomexplore.rpy:247
    old "Water your plant."
    new "Regar tu planta."

    # game/beyond the bet/7dlc_roomexplore.rpy:297
    old "Don't water it."
    new "No regarla."

    # game/beyond the bet/7dlc_roomexplore.rpy:300
    old "Water it some more."
    new "Regarla un poco más."

    # game/beyond the bet/7dlc_roomexplore.rpy:310
    old "Don't water it more."
    new "No regarla más."

    # game/beyond the bet/7dlc_roomexplore.rpy:313
    old "Water it some more... again."
    new "Regarla un poco más... otra vez."

    # game/beyond the bet/7dlc_roomexplore.rpy:326
    old "Don't water it more. Seriously."
    new "No regarla más. En serio."

    # game/beyond the bet/7dlc_roomexplore.rpy:329
    old "No more watering."
    new "No más agua."

    # game/beyond the bet/7dlc_roomexplore.rpy:334
    old "Pick a new book to read."
    new "Elegir un nuevo libro para leer."

    # game/beyond the bet/7dlc_roomexplore.rpy:343
    old "Read a book again."
    new "Volver a leer un libro."

    # game/beyond the bet/7dlc_roomexplore.rpy:345
    old "Nevermind."
    new "Mejor no."

    # game/beyond the bet/7dlc_roomexplore.rpy:350
    old "Update Appearance."
    new "Actualizar Apariencia."

    # game/beyond the bet/7dlc_roomexplore.rpy:354
    old "Renovate Room."
    new "Renovar habitación."

    # game/beyond the bet/7dlc_roomexplore.rpy:358
    old "Update Bio."
    new "Actualizar biografía."

    # game/beyond the bet/7dlc_roomexplore.rpy:367
    old "Check your computer."
    new "Revisar tu computadora."

