# TODO: Translation updated at 2026-10-15 18:36

# game/beyond the bet/day9dlc.rpy:18
translate Spanish dlc_9room_b7d888af:

    # center_text "Has sleep ever come so easily to you?"
    center_text "¿Alguna vez te había resultado tan fácil dormir?"

# game/beyond the bet/day9dlc.rpy:21
translate Spanish dlc_9room_8880022a:

    # center_text "No, you think. It hasn't."
    center_text "No, piensas. Nunca te había resultado tan fácil."

# game/beyond the bet/day9dlc.rpy:22
translate Spanish dlc_9room_51397c55:

    # center_text "How did you survive so long without this warmth? Without the weight of a person beside you?"
    center_text "¿Cómo sobreviviste tanto tiempo sin esta calidez? ¿Sin el peso de una persona a tu lado?"

# game/beyond the bet/day9dlc.rpy:23
translate Spanish dlc_9room_c0429b70:

    # center_text "Your dreams that night were peaceful."
    center_text "Tus sueños de esa noche fueron apacibles."

# game/beyond the bet/day9dlc.rpy:24
translate Spanish dlc_9room_12a675fb:

    # center_text "Like sunlight poking out after a rainy day."
    center_text "Como la luz del sol asomando tras un día lluvioso."

# game/beyond the bet/day9dlc.rpy:34
translate Spanish dlc_9room_c14913f2:

    # "{i}You open your eyes, blinking as sunlight streams in from your window.{/i}"
    "{i}Abres los ojos, parpadeando mientras la luz del sol entra por tu ventana.{/i}"

# game/beyond the bet/day9dlc.rpy:35
translate Spanish dlc_9room_97cd0518:

    # "{i}And there, laying next to you, is Casper, his hair strewn about the pillow, his body tangled in the blankets, and his chest rising and falling with his soft breaths.{/i}"
    "{i}Y ahí, acostado a tu lado, está Casper, con el cabello esparcido por la almohada, el cuerpo enredado en las mantas y el pecho subiendo y bajando con su suave respiración.{/i}"

# game/beyond the bet/day9dlc.rpy:36
translate Spanish dlc_9room_7e7c1c21:

    # "{i}A smile spreads across your face, and a warm fuzzy feeling settles in your chest.{/i}"
    "{i}Una sonrisa se extiende por tu rostro, y una cálida sensación se instala en tu pecho.{/i}"

# game/beyond the bet/day9dlc.rpy:37
translate Spanish dlc_9room_0dd1713a:

    # "{i}Casper is really there, right next to you.{/i}"
    "{i}Casper de verdad está ahí, justo a tu lado.{/i}"

# game/beyond the bet/day9dlc.rpy:38
translate Spanish dlc_9room_134768bd:

    # "{i}It feels like a dream, almost.{/i}"
    "{i}Casi parece un sueño.{/i}"

# game/beyond the bet/day9dlc.rpy:39
translate Spanish dlc_9room_350a134e:

    # "{i}A crazy one, at that. Honestly, if this were all a dream, it would make much more sense.{/i}"
    "{i}Y vaya que sería un sueño descabellado. Sinceramente, si todo esto fuera un sueño, tendría mucho más sentido.{/i}"

# game/beyond the bet/day9dlc.rpy:40
translate Spanish dlc_9room_d04b0ad8:

    # "{i}An immortal Grim Reaper and the soul he just couldn't take... it sounds like the plot to a bad novel.{/i}"
    "{i}Una Parca inmortal y el alma que simplemente no pudo llevarse... Suena a la trama de una mala novela.{/i}"

# game/beyond the bet/day9dlc.rpy:41
translate Spanish dlc_9room_54925d8c:

    # "{i}But, here you are.{/i}"
    "{i}Pero, aquí estás.{/i}"

# game/beyond the bet/day9dlc.rpy:42
translate Spanish dlc_9room_ff28e5ce:

    # "{i}And here Casper is, in the flesh.{/i}"
    "{i}Y aquí está Casper, en carne y hueso.{/i}"

# game/beyond the bet/day9dlc.rpy:43
translate Spanish dlc_9room_8b81c99f:

    # "{i}Gently, you reach out and stroke his hair.{/i}"
    "{i}Con suavidad, extiendes la mano y le acaricias el cabello.{/i}"

# game/beyond the bet/day9dlc.rpy:44
translate Spanish dlc_9room_df3eabf5:

    # "{i}He shifts, eyes fluttering open.{/i}"
    "{i}Se mueve y abre los ojos lentamente.{/i}"

# game/beyond the bet/day9dlc.rpy:62
translate Spanish dlc_9room_2ba5529e:

    # GRC "Sunshine."
    GRC "Solecito."

# game/beyond the bet/day9dlc.rpy:66
translate Spanish dlc_9room_b669d0ca:

    # GRC "Still not my name."
    GRC "Sigue sin ser mi nombre."

# game/beyond the bet/day9dlc.rpy:71
translate Spanish dlc_9room_d087df07:

    # GRC "A nickname, yes. A cute one? Debateable."
    GRC "Un apodo, sí. ¿Uno lindo? Discutible."

# game/beyond the bet/day9dlc.rpy:75
translate Spanish dlc_9room_8c2662a7:

    # GRC "Ah..."
    GRC "Ah..."

# game/beyond the bet/day9dlc.rpy:77
translate Spanish dlc_9room_a9da004b:

    # GRC "To hear my name from your lips is still strange. Even now."
    GRC "Oír mi nombre de tus labios sigue siendo extraño. Incluso ahora."

# game/beyond the bet/day9dlc.rpy:84
translate Spanish dlc_9room_07ab7154:

    # GRC "...What?"
    GRC "...¿Qué?"

# game/beyond the bet/day9dlc.rpy:93
translate Spanish dlc_9room_870e3a26:

    # GRC "...It's..."
    GRC "...Es..."

# game/beyond the bet/day9dlc.rpy:94
translate Spanish dlc_9room_98b8e53a:

    # GRC "Cute... I suppose..."
    GRC "Lindo... supongo..."

# game/beyond the bet/day9dlc.rpy:100
translate Spanish dlc_9room_34ca6ebe:

    # GRC "I'm still here."
    GRC "Todavía estoy aquí."

# game/beyond the bet/day9dlc.rpy:105
translate Spanish dlc_9room_bc714919:

    # GRC "Work always needs me."
    GRC "El trabajo siempre me necesita."

# game/beyond the bet/day9dlc.rpy:107
translate Spanish dlc_9room_001d6fc5:

    # GRC "But there is... something more important than that to me at the moment."
    GRC "Pero hay... algo más importante que eso para mí en este momento."

# game/beyond the bet/day9dlc.rpy:110
translate Spanish dlc_9room_32f44438:

    # GRC "Yes."
    GRC "Sí."

# game/beyond the bet/day9dlc.rpy:112
translate Spanish dlc_9room_cdbfd013:

    # GRC "Though, when you say it like that, it sounds like I'm being negligent."
    GRC "Aunque, dicho así, suena como si estuviera siendo negligente."

# game/beyond the bet/day9dlc.rpy:119
translate Spanish dlc_9room_6a297273:

    # GRC "Who said I meant you?"
    GRC "¿Quién dijo que me refería a ti?"

# game/beyond the bet/day9dlc.rpy:124
translate Spanish dlc_9room_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:126
translate Spanish dlc_9room_e33200b4:

    # GRC "You are..."
    GRC "Eres..."

# game/beyond the bet/day9dlc.rpy:128
translate Spanish dlc_9room_b869dbba:

    # GRC "You have become precious to me."
    GRC "Te has vuelto preciad[letra] para mí."

# game/beyond the bet/day9dlc.rpy:133
translate Spanish dlc_9room_09825890:

    # GRC "Regret..."
    GRC "Arrepentirme..."

# game/beyond the bet/day9dlc.rpy:134
translate Spanish dlc_9room_db8024dd:

    # GRC "It is not a feeling I am accustomed to."
    GRC "No es un sentimiento al que esté acostumbrado."

# game/beyond the bet/day9dlc.rpy:136
translate Spanish dlc_9room_a673537e:

    # GRC "There has been no room for regret in my long life."
    GRC "No ha habido lugar para el arrepentimiento en mi larga vida."

# game/beyond the bet/day9dlc.rpy:137
translate Spanish dlc_9room_ddc4c155:

    # GRC "There's only been... following commands. Day in and day out, more of the same."
    GRC "Solo ha habido... seguir órdenes. Día tras día, más de lo mismo."

# game/beyond the bet/day9dlc.rpy:139
translate Spanish dlc_9room_8d03dd8e:

    # GRC "I feel I only learned regret once I met you."
    GRC "Siento que solo aprendí lo que es el arrepentimiento al conocerte."

# game/beyond the bet/day9dlc.rpy:147
translate Spanish dlc_9room_0fe0f833:

    # GRC "Had I not told you the truth of how I felt, then I would have felt regret."
    GRC "Si no te hubiera dicho la verdad sobre lo que siento, habría sentido arrepentimiento."

# game/beyond the bet/day9dlc.rpy:149
translate Spanish dlc_9room_b12c32df:

    # GRC "And if I do not do all in my power to keep you safe throughout the difficult days to come, then I will feel something far worse than regret."
    GRC "Y si no hago todo lo que está en mi poder para mantenerte a salvo durante los difíciles días que vendrán, entonces sentiré algo mucho peor que arrepentimiento."

# game/beyond the bet/day9dlc.rpy:156
translate Spanish dlc_9room_13a36a76:

    # GRC "Well..."
    GRC "Bueno..."

# game/beyond the bet/day9dlc.rpy:157
translate Spanish dlc_9room_904daf8d:

    # GRC "I must return to work. Being gone for too long will raise suspicions."
    GRC "Debo volver al trabajo. Ausentarme demasiado tiempo levantará sospechas."

# game/beyond the bet/day9dlc.rpy:164
translate Spanish dlc_9room_401de55d:

    # GRC "I... wish I could stay."
    GRC "Yo... desearía poder quedarme."

# game/beyond the bet/day9dlc.rpy:165
translate Spanish dlc_9room_f9100c82:

    # GRC "But I feel that running away from my responsibilities will just end in heartbreak."
    GRC "Pero siento que huir de mis responsabilidades solo acabará en desamor."

# game/beyond the bet/day9dlc.rpy:166
translate Spanish dlc_9room_5bb073fe:

    # GRC "I would not see you hurt."
    GRC "No permitiría que te hicieran daño."

# game/beyond the bet/day9dlc.rpy:168
translate Spanish dlc_9room_7b3d156f:

    # GRC "Even if you are a complete idiot."
    GRC "Aunque seas [arti_2] idiota de remate."

# game/beyond the bet/day9dlc.rpy:175
translate Spanish dlc_9room_254aa246:

    # GRC "Only an idiot would get involved with someone like me."
    GRC "Solo [arti_2] idiota se involucraría con alguien como yo."

# game/beyond the bet/day9dlc.rpy:176
translate Spanish dlc_9room_7535e7a2:

    # GRC "Therefore, you must be an idiot."
    GRC "Por lo tanto, debes de ser [arti_2] idiota."

# game/beyond the bet/day9dlc.rpy:181
translate Spanish dlc_9room_fe523cd9:

    # GRC "You may be right."
    GRC "Puede que tengas razón."

# game/beyond the bet/day9dlc.rpy:183
translate Spanish dlc_9room_2c175e6d:

    # GRC "But at least I am a very handsome, charming, and overall perfect idiot."
    GRC "Pero al menos soy un idiota muy atractivo, encantador y, en general, perfecto."

# game/beyond the bet/day9dlc.rpy:190
translate Spanish dlc_9room_70363630:

    # GRC "Obviously."
    GRC "Obviamente."

# game/beyond the bet/day9dlc.rpy:198
translate Spanish dlc_9room_1908eb09:

    # GRC "I am... acutely aware."
    GRC "Soy... plenamente consciente."

# game/beyond the bet/day9dlc.rpy:199
translate Spanish dlc_9room_d620609b:

    # GRC "I need some time."
    GRC "Necesito algo de tiempo."

# game/beyond the bet/day9dlc.rpy:201
translate Spanish dlc_9room_cb3465db:

    # GRC "Perhaps something like this has happened before."
    GRC "Quizás algo así ya haya ocurrido antes."

# game/beyond the bet/day9dlc.rpy:202
translate Spanish dlc_9room_ecd60a9d:

    # GRC "Maybe there's a way to clear your name."
    GRC "Quizás haya una forma de limpiar tu nombre."

# game/beyond the bet/day9dlc.rpy:207
translate Spanish dlc_9room_0743eb59:

    # GRC "It does sound unlikely."
    GRC "Suena improbable, sí."

# game/beyond the bet/day9dlc.rpy:209
translate Spanish dlc_9room_fbd37b0e:

    # GRC "But you are a special case. They will have to understand that."
    GRC "Pero eres un caso especial. Tendrán que entenderlo."

# game/beyond the bet/day9dlc.rpy:211
translate Spanish dlc_9room_f364534d:

    # GRC "Give me time, Sunshine. I will try to work something out."
    GRC "Dame tiempo, Solecito. Intentaré arreglar algo."

# game/beyond the bet/day9dlc.rpy:221
translate Spanish dlc_9room_8eff24a5:

    # GRC "There is nothing to worry about."
    GRC "No hay nada de qué preocuparse."

# game/beyond the bet/day9dlc.rpy:226
translate Spanish dlc_9room_9e7cb13a:

    # GRC "Okay."
    GRC "Okey."

# game/beyond the bet/day9dlc.rpy:227
translate Spanish dlc_9room_de1eb439:

    # GRC "There is something to worry about, then."
    GRC "Entonces sí hay algo de qué preocuparse."

# game/beyond the bet/day9dlc.rpy:229
translate Spanish dlc_9room_555e8018:

    # GRC "But I do not expect them to act that quickly."
    GRC "Pero no espero que actúen tan rápido."

# game/beyond the bet/day9dlc.rpy:231
translate Spanish dlc_9room_fd5de30e:

    # GRC "I have been a model Grim Reaper for the majority of my lifetime."
    GRC "He sido una Parca ejemplar durante la mayor parte de mi vida."

# game/beyond the bet/day9dlc.rpy:233
translate Spanish dlc_9room_92fc65b8:

    # GRC "I would hope that means something."
    GRC "Esperaría que eso significara algo."

# game/beyond the bet/day9dlc.rpy:237
translate Spanish dlc_9room_13a36a76_1:

    # GRC "Well..."
    GRC "Bueno..."

# game/beyond the bet/day9dlc.rpy:238
translate Spanish dlc_9room_42afc4dc:

    # "{i}He looks at you with eyes that say he doesn't want to go.{/i}"
    "{i}Te mira con ojos que dicen que no quiere irse.{/i}"

# game/beyond the bet/day9dlc.rpy:239
translate Spanish dlc_9room_c6132f21:

    # "{i}It breaks your heart, just a little bit.{/i}"
    "{i}Te rompe el corazón, solo un poquito.{/i}"

# game/beyond the bet/day9dlc.rpy:241
translate Spanish dlc_9room_9edd76ef:

    # GRC "How about breakfast first?"
    GRC "¿Y si primero desayunamos?"

# game/beyond the bet/day9dlc.rpy:245
translate Spanish dlc_9room_83f55258:

    # GRC "What? Why do you sound so displeased?"
    GRC "¿Qué? ¿Por qué suenas tan descontent[letra]?"

# game/beyond the bet/day9dlc.rpy:246
translate Spanish dlc_9room_a3ac6cb3:

    # GRC "Are you not hungry?"
    GRC "¿No tienes hambre?"

# game/beyond the bet/day9dlc.rpy:249
translate Spanish dlc_9room_86c0a99d:

    # GRC "Is there some kind of problem?"
    GRC "¿Hay algún problema?"

# game/beyond the bet/day9dlc.rpy:250
translate Spanish dlc_9room_e9241924:

    # GRC "I thought you would be hungry."
    GRC "Pensé que tendrías hambre."

# game/beyond the bet/day9dlc.rpy:260
translate Spanish dlc_9room_b23d9229:

    # GRC "It is not necessary, but..."
    GRC "No es necesario, pero..."

# game/beyond the bet/day9dlc.rpy:261
translate Spanish dlc_9room_8a2710bd:

    # GRC "I will allow it."
    GRC "Lo permitiré."

# game/beyond the bet/day9dlc.rpy:265
translate Spanish dlc_9room_03061a71:

    # GRC "You're amusing, mortal."
    GRC "Eres divertid[letra], mortal."

# game/beyond the bet/day9dlc.rpy:270
translate Spanish dlc_9room_bb28f04b:

    # GRC "I think you are lying, but I will pretend you are not."
    GRC "Creo que mientes, pero fingiré que no."

# game/beyond the bet/day9dlc.rpy:274
translate Spanish dlc_9room_83bb4f4b:

    # GRC "Let's be honest here."
    GRC "Seamos sinceros."

# game/beyond the bet/day9dlc.rpy:275
translate Spanish dlc_9room_63d8c33d:

    # GRC "Even if it burnt down, you would be completely unharmed."
    GRC "Aunque se quemara, saldrías completamente iles[letra]."

# game/beyond the bet/day9dlc.rpy:280
translate Spanish dlc_9room_89e8213d:

    # GRC "I know."
    GRC "Lo sé."

# game/beyond the bet/day9dlc.rpy:285
translate Spanish dlc_9room_a9acfce3:

    # GRC "Any suggestions?"
    GRC "¿Alguna sugerencia?"

# game/beyond the bet/day9dlc.rpy:293
translate Spanish dlc_9room_e8327e55:

    # GRC "I have not heard of this 'vegemite'. What is it?"
    GRC "No he oído hablar de ese 'vegemite'. ¿Qué es?"

# game/beyond the bet/day9dlc.rpy:307
translate Spanish dlc_9room_b9da3cd6:

    # GRC "No, I..."
    GRC "No, yo..."

# game/beyond the bet/day9dlc.rpy:308
translate Spanish dlc_9room_a3218f8f:

    # GRC "Ahem. I hadn't expected to..."
    GRC "Ejem. No había pensado que..."

# game/beyond the bet/day9dlc.rpy:312
translate Spanish dlc_9room_1579316f:

    # GRC "Right."
    GRC "Cierto."

# game/beyond the bet/day9dlc.rpy:317
translate Spanish dlc_9room_c96c243d:

    # GRC "I seriously doubt that."
    GRC "Lo dudo seriamente."

# game/beyond the bet/day9dlc.rpy:325
translate Spanish dlc_9room_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:327
translate Spanish dlc_9room_4f65d017:

    # GRC "Should I be scared?"
    GRC "¿Debería tener miedo?"

# game/beyond the bet/day9dlc.rpy:333
translate Spanish dlc_9room_1756d874:

    # GRC "...Fine."
    GRC "...Está bien."

# game/beyond the bet/day9dlc.rpy:334
translate Spanish dlc_9room_ee7d8788:

    # GRC "Dress me as you will."
    GRC "Vísteme como quieras."

# game/beyond the bet/day9dlc.rpy:336
translate Spanish dlc_9room_9f81c7a7:

    # GRC "I will return whatever you give me the next time I see you."
    GRC "Devolveré lo que me des la próxima vez que te vea."

# game/beyond the bet/day9dlc.rpy:348
translate Spanish dlc_9room_bb5c6fe8:

    # "{i}You run off to search through your wardrobe.{/i}"
    "{i}Sales corriendo a buscar en tu armario.{/i}"

# game/beyond the bet/day9dlc.rpy:349
translate Spanish dlc_9room_ccd44195:

    # "{i}There must be SOMETHING that'll fit Casper in here, right...?{/i}"
    "{i}Tiene que haber ALGO que le quede a Casper aquí, ¿no...?{/i}"

# game/beyond the bet/day9dlc.rpy:350
translate Spanish dlc_9room_8d0f54b4:

    # "{i}You pick...{/i}"
    "{i}Eliges...{/i}"

# game/beyond the bet/day9dlc.rpy:357
translate Spanish dlc_9room_d1c7c912:

    # GRC "This is..."
    GRC "Esto es..."

# game/beyond the bet/day9dlc.rpy:358
translate Spanish dlc_9room_8a81068e:

    # GRC "Why do you own this?"
    GRC "¿Por qué tienes esto?"

# game/beyond the bet/day9dlc.rpy:365
translate Spanish dlc_9room_2615ec39:

    # GRC "Are you calling me some kind of clown?"
    GRC "¿Me estás llamando payaso o algo así?"

# game/beyond the bet/day9dlc.rpy:369
translate Spanish dlc_9room_e8ebd254:

    # GRC "I am not saying honk."
    GRC "No voy a decir 'honk'."

# game/beyond the bet/day9dlc.rpy:379
translate Spanish dlc_9room_008afe10_2:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:380
translate Spanish dlc_9room_222bac18:

    # GRC "This is ridiculous..."
    GRC "Esto es ridículo..."

# game/beyond the bet/day9dlc.rpy:391
translate Spanish dlc_9room_8386d430:

    # GRC "Are the sunglasses necessary?"
    GRC "¿Son necesarias las gafas de sol?"

# game/beyond the bet/day9dlc.rpy:402
translate Spanish dlc_9room_008afe10_3:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:403
translate Spanish dlc_9room_3e50bc24:

    # GRC "I... was not expecting something like this to be pulled from your wardrobe."
    GRC "Yo... no esperaba que sacaras algo así de tu armario."

# game/beyond the bet/day9dlc.rpy:408
translate Spanish dlc_9room_599a1c27:

    # GRC "It almost looks like a style from the Underworld..."
    GRC "Casi parece un estilo del Inframundo..."

# game/beyond the bet/day9dlc.rpy:416
translate Spanish dlc_9room_574e8562:

    # GRC "The... harness seems a little unnecessary..."
    GRC "El... arnés parece un poco innecesario..."

# game/beyond the bet/day9dlc.rpy:421
translate Spanish dlc_9room_56bfcf6f:

    # GRC "What is the use?"
    GRC "¿Y para qué sirve?"

# game/beyond the bet/day9dlc.rpy:428
translate Spanish dlc_9room_8ddb221e:

    # GRC "Yes, well, I obviously look good in anything."
    GRC "Sí, bueno, obviamente me veo bien con cualquier cosa."

# game/beyond the bet/day9dlc.rpy:435
translate Spanish dlc_9room_008afe10_4:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:436
translate Spanish dlc_9room_59d297ee:

    # GRC "Right. Breakfast."
    GRC "Cierto. El desayuno."

# game/beyond the bet/day9dlc.rpy:441
translate Spanish dlc_9room_594ec1ab:

    # GRC "Nine hells... that such a clothing item could exist...!"
    GRC "¡Por los nueve infiernos...! ¡No puedo creer que exista una prenda así...!"

# game/beyond the bet/day9dlc.rpy:443
translate Spanish dlc_9room_39d503b0:

    # GRC "I will treasure this, Sunshine."
    GRC "Atesoraré esto, Solecito."

# game/beyond the bet/day9dlc.rpy:447
translate Spanish dlc_9room_ebedd8fb:

    # GRC "I am no common thief. I will return it... in time."
    GRC "No soy un ladrón común. Lo devolveré... a su debido tiempo."

# game/beyond the bet/day9dlc.rpy:452
translate Spanish dlc_9room_54be47e5:

    # GRC "An amount of time that I will not currently disclose."
    GRC "Una cantidad de tiempo que por ahora no revelaré."

# game/beyond the bet/day9dlc.rpy:457
translate Spanish dlc_9room_e55a898e:

    # GRC "Have you given it a name?"
    GRC "¿Le has puesto nombre?"

# game/beyond the bet/day9dlc.rpy:460
translate Spanish dlc_9room_32f44438_1:

    # GRC "Yes."
    GRC "Sí."

# game/beyond the bet/day9dlc.rpy:462
translate Spanish dlc_9room_a194429d:

    # GRC "A sibling to Azrael needs a fine name."
    GRC "Un hermano de Azrael necesita un buen nombre."

# game/beyond the bet/day9dlc.rpy:466
translate Spanish dlc_9room_f034338d:

    # GRC "Hmm..."
    GRC "Mmm..."

# game/beyond the bet/day9dlc.rpy:467
translate Spanish dlc_9room_d0bc9659:

    # GRC "Oliver the Great."
    GRC "Oliver el Grande."

# game/beyond the bet/day9dlc.rpy:472
translate Spanish dlc_9room_76f0cc33:

    # GRC "Being an axolotl, of course."
    GRC "Que sea un ajolote, por supuesto."

# game/beyond the bet/day9dlc.rpy:474
translate Spanish dlc_9room_cb2b5150:

    # GRC "Now. Sunshine, Oliver, let us commence breakfast."
    GRC "Bien. Solecito, Oliver, comencemos a desayunar."

# game/beyond the bet/day9dlc.rpy:478
translate Spanish dlc_9room_ddf986f0:

    # GRC "Cupcake..."
    GRC "Cupcake..."

# game/beyond the bet/day9dlc.rpy:480
translate Spanish dlc_9room_e5f4d213:

    # GRC "A good name. It strikes fear into the heart."
    GRC "Un buen nombre. Infunde temor en el corazón."

# game/beyond the bet/day9dlc.rpy:505
translate Spanish dlc_9room_c5808e8c:

    # GRC "It... fits well, surprisingly."
    GRC "Sorprendentemente... me queda bien."

# game/beyond the bet/day9dlc.rpy:507
translate Spanish dlc_9room_4c4bec6c:

    # GRC "But why can I not use the jacket sleeves normally?"
    GRC "Pero ¿por qué no puedo meter los brazos en las mangas de la chaqueta como de costumbre?"

# game/beyond the bet/day9dlc.rpy:511
translate Spanish dlc_9room_3adcb240:

    # GRC "And what exactly is that supposed to mean?"
    GRC "¿Y eso qué se supone que significa exactamente?"

# game/beyond the bet/day9dlc.rpy:519
translate Spanish dlc_9room_7b6578de:

    # GRC "S..."
    GRC "S..."

# game/beyond the bet/day9dlc.rpy:521
translate Spanish dlc_9room_8c2a035a:

    # GRC "Seduce you?!"
    GRC "¡¿Seducirte?!"

# game/beyond the bet/day9dlc.rpy:527
translate Spanish dlc_9room_2178013a:

    # GRC "It... was?"
    GRC "¿De verdad...?"

# game/beyond the bet/day9dlc.rpy:529
translate Spanish dlc_9room_d39d20d9:

    # GRC "I... well, of course!"
    GRC "Yo... ¡bueno, por supuesto!"

# game/beyond the bet/day9dlc.rpy:530
translate Spanish dlc_9room_38b86287:

    # GRC "Seducing someone is straightforward for one such as I."
    GRC "Seducir a alguien es sencillo para alguien como yo."

# game/beyond the bet/day9dlc.rpy:539
translate Spanish dlc_9room_e0229e66:

    # GRC "Ah."
    GRC "Ah."

# game/beyond the bet/day9dlc.rpy:541
translate Spanish dlc_9room_bd601347:

    # GRC "I... knew that, of course."
    GRC "Yo... lo sabía, por supuesto."

# game/beyond the bet/day9dlc.rpy:543
translate Spanish dlc_9room_34ad36fe:

    # GRC "Ha. Ha. Another funny mortal joke."
    GRC "Ja. Ja. Otra graciosa broma mortal."

# game/beyond the bet/day9dlc.rpy:544
translate Spanish dlc_9room_008afe10_5:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:556
translate Spanish dlc_9room_c33ed384:

    # GRC "I doubt I'd fit in. Vampires are very vain."
    GRC "Dudo que encajara. Los vampiros son muy vanidosos."

# game/beyond the bet/day9dlc.rpy:563
translate Spanish dlc_9room_45cc7ed5:

    # GRC "Did it sound like a joke?"
    GRC "¿Sonó a broma?"

# game/beyond the bet/day9dlc.rpy:571
translate Spanish dlc_9room_28e3c646:

    # GRC "Why?"
    GRC "¿Por qué?"

# game/beyond the bet/day9dlc.rpy:575
translate Spanish dlc_9room_26d2360c:

    # GRC "What makes me vain?"
    GRC "¿Qué me hace vanidoso?"

# game/beyond the bet/day9dlc.rpy:580
translate Spanish dlc_9room_1cab09e7:

    # GRC "Well, obviously."
    GRC "Bueno, obviamente."

# game/beyond the bet/day9dlc.rpy:581
translate Spanish dlc_9room_e733ba87:

    # GRC "I'm the most handsome man in history."
    GRC "Soy el hombre más guapo de la historia."

# game/beyond the bet/day9dlc.rpy:585
translate Spanish dlc_9room_bd0808a5:

    # GRC "If you had my voice, I'm sure you would never stop talking to yourself."
    GRC "Si tuvieras mi voz, seguro que nunca dejarías de hablarte."

# game/beyond the bet/day9dlc.rpy:590
translate Spanish dlc_9room_c77da232:

    # GRC "Fine. Maybe I'm a touch vain. But who could blame me, really?"
    GRC "Bien. Quizás soy un poquito vanidoso. Pero ¿quién podría culparme, de verdad?"

# game/beyond the bet/day9dlc.rpy:605
translate Spanish dlc_9room_ad7cb925:

    # GRC "...Okay now I just feel like a pet."
    GRC "...Okey, ahora siento que soy una mascota."

# game/beyond the bet/day9dlc.rpy:610
translate Spanish dlc_9room_6f91156e:

    # GRC "Uh... me?"
    GRC "Eh... ¿yo?"

# game/beyond the bet/day9dlc.rpy:628
translate Spanish dlc_9room_70ec1bea:

    # GRC "I am not a sheep, Sunshine!"
    GRC "¡No soy una oveja, Solecito!"

# game/beyond the bet/day9dlc.rpy:639
translate Spanish dlc_9room_167c8b4e:

    # GRC "F... fine. I... will allow you to do that."
    GRC "B... bueno. Yo... te permitiré hacer eso."

# game/beyond the bet/day9dlc.rpy:644
translate Spanish dlc_9room_d985f4bf:

    # GRC "What!"
    GRC "¡Qué!"

# game/beyond the bet/day9dlc.rpy:646
translate Spanish dlc_9room_a2d4347a:

    # GRC "{b}YOU{/b} are the one who wanted to pat me, not the other way around!"
    GRC "¡{b}TÚ{/b} eres quien quería acariciarme, no al revés!"

# game/beyond the bet/day9dlc.rpy:654
translate Spanish dlc_9room_796db5ba:

    # GRC "I never said that."
    GRC "Yo nunca dije eso."

# game/beyond the bet/day9dlc.rpy:658
translate Spanish dlc_9room_008afe10_6:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:660
translate Spanish dlc_9room_ec986cf3:

    # GRC "B..."
    GRC "B..."

# game/beyond the bet/day9dlc.rpy:664
translate Spanish dlc_9room_84b2c1a7:

    # GRC "B.... baaa..."
    GRC "B.... beee..."

# game/beyond the bet/day9dlc.rpy:672
translate Spanish dlc_9room_b6e047b5:

    # GRC "M... me... baa..."
    GRC "Y... yo... bee..."

# game/beyond the bet/day9dlc.rpy:682
translate Spanish dlc_9room_c39b1c75:

    # "{i}You take Casper by the hand and pull him into the kitchen.{/i}"
    "{i}Tomas a Casper de la mano y lo llevas a la cocina.{/i}"

# game/beyond the bet/day9dlc.rpy:683
translate Spanish dlc_9room_865c26bf:

    # "{i}What should be an incredibly simple cooking experience becomes a journey.{/i}"
    "{i}Lo que debería ser una experiencia culinaria increíblemente simple se convierte en un viaje.{/i}"

# game/beyond the bet/day9dlc.rpy:684
translate Spanish dlc_9room_04aa2210:

    # "{i}One filled with peril, and excitement, and a healthy dose of chaos.{/i}"
    "{i}Uno lleno de peligro, emoción y una buena dosis de caos.{/i}"

# game/beyond the bet/day9dlc.rpy:685
translate Spanish dlc_9room_366721cf:

    # "{i}But, by the end of it, you have two slices of vegemite on toast.{/i}"
    "{i}Pero, al final, tienes dos rebanadas de pan tostado con vegemite.{/i}"

# game/beyond the bet/day9dlc.rpy:686
translate Spanish dlc_9room_d7fd2aaa:

    # "{i}Casper doesn't look awfully impressed by the meal.{/i}"
    "{i}Casper no parece muy impresionado por la comida.{/i}"

# game/beyond the bet/day9dlc.rpy:701
translate Spanish dlc_9room_89c6f3c8:

    # GRC "Is it supposed to look like that?"
    GRC "¿Se supone que debe verse así?"

# game/beyond the bet/day9dlc.rpy:706
translate Spanish dlc_9room_38f63093:

    # GRC "It looks far less than delicious, Sunshine."
    GRC "Se ve bastante poco delicioso, Solecito."

# game/beyond the bet/day9dlc.rpy:707
translate Spanish dlc_9room_ce4d6fe3:

    # GRC "But... we made it together, so it must be at least edible."
    GRC "Pero... lo hicimos juntos, así que al menos debe de ser comestible."

# game/beyond the bet/day9dlc.rpy:712
translate Spanish dlc_9room_6f520b37:

    # GRC "No, because I had a hand in it." id dlc_9room_6f520b37
    GRC "No, porque yo participé en ello." id dlc_9room_6f520b37

# game/beyond the bet/day9dlc.rpy:713
translate Spanish dlc_9room_04f2a08b:

    # GRC "Everything I do is perfect."
    GRC "Todo lo que hago es perfecto."

# game/beyond the bet/day9dlc.rpy:717
translate Spanish dlc_9room_01a86666:

    # GRC "Then why are we making it for breakfast?"
    GRC "Entonces, ¿por qué lo preparamos para desayunar?"

# game/beyond the bet/day9dlc.rpy:721
translate Spanish dlc_9room_008afe10_7:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:723
translate Spanish dlc_9room_1549eb5a:

    # GRC "Then let us commence the meal."
    GRC "Entonces comencemos la comida."

# game/beyond the bet/day9dlc.rpy:725
translate Spanish dlc_9room_86391acd:

    # "{i}Casper picks up his slice, you pick up yours.{/i}"
    "{i}Casper toma su rebanada, tú tomas la tuya.{/i}"

# game/beyond the bet/day9dlc.rpy:726
translate Spanish dlc_9room_d9056693:

    # "{i}You stare each other in the eye.{/i}"
    "{i}Se miran fijamente a los ojos.{/i}"

# game/beyond the bet/day9dlc.rpy:727
translate Spanish dlc_9room_abb26afe:

    # "{i}Who will draw first?{/i}"
    "{i}¿Quién morderá primero?{/i}"

# game/beyond the bet/day9dlc.rpy:728
translate Spanish dlc_9room_11e8b4f1:

    # "{i}Casper, apparently.{/i}"
    "{i}Casper, al parecer.{/i}"

# game/beyond the bet/day9dlc.rpy:729
translate Spanish dlc_9room_ec55b5ce:

    # "{i}He brings the toast to his lips and takes a large bite.{/i}"
    "{i}Se lleva la tostada a los labios y da un gran mordisco.{/i}"

# game/beyond the bet/day9dlc.rpy:730
translate Spanish dlc_9room_e0091194:

    # "{i}You do the same.{/i}"
    "{i}Tú haces lo mismo.{/i}"

# game/beyond the bet/day9dlc.rpy:733
translate Spanish dlc_9room_74973f25:

    # "{i}It's...{/i}"
    "{i}Es...{/i}"

# game/beyond the bet/day9dlc.rpy:736
translate Spanish dlc_9room_f8741240:

    # "{i}It's strong, it's salty, it's... almost meaty?{/i}"
    "{i}Tiene un sabor intenso, es salado y... ¿casi sabe a carne?{/i}"

# game/beyond the bet/day9dlc.rpy:737
translate Spanish dlc_9room_12e27831:

    # "{i}What a terrible breakfast food!{/i}"
    "{i}¡Qué cosa tan horrible para desayunar!{/i}"

# game/beyond the bet/day9dlc.rpy:740
translate Spanish dlc_9room_e3b1834f:

    # "{i}It's not terrible. It's a little strong, but unique.{/i}"
    "{i}No está mal. Tiene un sabor un poco intenso, pero es único.{/i}"

# game/beyond the bet/day9dlc.rpy:743
translate Spanish dlc_9room_bb6684b8:

    # "{i}Wow."
    "{i}Guau.{/i}"

# game/beyond the bet/day9dlc.rpy:744
translate Spanish dlc_9room_02016fa5:

    # "{i}Vegemite has now become your favorite food ever.{/i}"
    "{i}El Vegemite se ha convertido en tu comida favorita de todos los tiempos.{/i}"

# game/beyond the bet/day9dlc.rpy:745
translate Spanish dlc_9room_05c5b7c8:

    # "{i}The strong, salty flavor is like heaven in your mouth.{/i}"
    "{i}Su sabor intenso y salado es como el paraíso en tu boca.{/i}"

# game/beyond the bet/day9dlc.rpy:748
translate Spanish dlc_9room_b37b65a1:

    # "{i}You look towards Casper.{/i}"
    "{i}Miras a Casper.{/i}"

# game/beyond the bet/day9dlc.rpy:749
translate Spanish dlc_9room_a468ae7c:

    # "{i}Oh, boy.{/i}"
    "{i}Ay, hombre.{/i}"

# game/beyond the bet/day9dlc.rpy:750
translate Spanish dlc_9room_98fbde3d:

    # "{i}Yeah, he's not a fan.{/i}"
    "{i}Sí, está claro que no le gusta.{/i}"

# game/beyond the bet/day9dlc.rpy:752
translate Spanish dlc_9room_00d37c11:

    # "{i}He stares back down at the toast as if it had just said something offensive about his mother.{/i}"
    "“i}Vuelve a clavar la mirada en la tostada, como si acabara de insultar a su madre.{/i}"

# game/beyond the bet/day9dlc.rpy:760
translate Spanish dlc_9room_805c64c4:

    # GRC "It's..."
    GRC "Es..."

# game/beyond the bet/day9dlc.rpy:761
translate Spanish dlc_9room_c320dbc2:

    # "{i}You can see the conflict in his eyes.{/i}"
    "{i}Puedes ver el conflicto en sus ojos.{/i}"

# game/beyond the bet/day9dlc.rpy:762
translate Spanish dlc_9room_c804c826:

    # "{i}He wants to lie so badly.{/i}"
    "{i}Tiene tantas ganas de mentir.{/i}"

# game/beyond the bet/day9dlc.rpy:763
translate Spanish dlc_9room_5148e34d:

    # GRC "It is... the taste is..."
    GRC "Es... su sabor es..."

# game/beyond the bet/day9dlc.rpy:767
translate Spanish dlc_9room_b06f0f63:

    # GRC "This is the worst thing I've ever eaten."
    GRC "Es lo peor que he comido jamás."

# game/beyond the bet/day9dlc.rpy:778
translate Spanish dlc_9room_91968cf0:

    # GRC "Why... why is it like that? Who enjoys it?!"
    GRC "¿Por qué... por qué es así? ¡¿A quién le gusta?!"

# game/beyond the bet/day9dlc.rpy:784
translate Spanish dlc_9room_b4523e24:

    # GRC "The whole continent of Australia should consider getting their taste buds looked at."
    GRC "Todo el continente de Australia debería plantearse que le revisen las papilas gustativas."

# game/beyond the bet/day9dlc.rpy:788
translate Spanish dlc_9room_468c3fc9:

    # GRC "RIGHT?"
    GRC "¿VERDAD?"

# game/beyond the bet/day9dlc.rpy:790
translate Spanish dlc_9room_f279cfa0:

    # GRC "You don't know how happy I am that you agree, Sunshine."
    GRC "No sabes lo feliz que me hace que estés de acuerdo, Solecito."

# game/beyond the bet/day9dlc.rpy:791
translate Spanish dlc_9room_fb8ef62e:

    # GRC "We can share in this misery together."
    GRC "Podemos compartir esta miseria juntos."

# game/beyond the bet/day9dlc.rpy:796
translate Spanish dlc_9room_14cbb985:

    # GRC "Anyway..."
    GRC "En fin..."

# game/beyond the bet/day9dlc.rpy:797
translate Spanish dlc_9room_59930b20:

    # GRC "It is about time I made my way home, before I draw further ire from my employers."
    GRC "Ya es hora de que regrese a casa, antes de atraer más la ira de mis empleadores."

# game/beyond the bet/day9dlc.rpy:798
translate Spanish dlc_9room_4b07dd64:

    # GRC "But we will talk soon, okay? I will figure something out."
    GRC "Pero hablaremos pronto, ¿okey? Se me ocurrirá algo."

# game/beyond the bet/day9dlc.rpy:800
translate Spanish dlc_9room_866f8fdd:

    # GRC "Just... perhaps it would be a good idea to stay inside your home today."
    GRC "Solo... quizás sería buena idea que hoy te quedaras en casa."

# game/beyond the bet/day9dlc.rpy:805
translate Spanish dlc_9room_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/beyond the bet/day9dlc.rpy:806
translate Spanish dlc_9room_7071840e:

    # GRC "Have a bad feeling, I suppose."
    GRC "Tengo un mal presentimiento, supongo."

# game/beyond the bet/day9dlc.rpy:821
translate Spanish dlc_9room_50c2bf74:

    # GRC "I will... return these clothing items to you soon enough."
    GRC "Te devolveré estas prendas lo antes posible."

# game/beyond the bet/day9dlc.rpy:832
translate Spanish dlc_9room_9f3a7633:

    # GRC "I am not a clown. I am a Grim Reaper."
    GRC "No soy un payaso. Soy una Parca."

# game/beyond the bet/day9dlc.rpy:842
translate Spanish dlc_9room_3ab6d11e:

    # GRC "I would feel guilty for keeping your clothes."
    GRC "Me sentiría culpable si me quedara con tu ropa."

# game/beyond the bet/day9dlc.rpy:850
translate Spanish dlc_9room_36af616a:

    # GRC "Well, if you insist."
    GRC "Bueno, si insistes."

# game/beyond the bet/day9dlc.rpy:851
translate Spanish dlc_9room_d5f8eb1b:

    # GRC "I will take this axolotl costume off your hands."
    GRC "Me llevaré este disfraz de ajolote."

# game/beyond the bet/day9dlc.rpy:852
translate Spanish dlc_9room_1dc334f5:

    # GRC "Only because you asked me to, of course."
    GRC "Solo porque me lo pediste, por supuesto."

# game/beyond the bet/day9dlc.rpy:860
translate Spanish dlc_9room_89e8213d_1:

    # GRC "I know."
    GRC "Lo sé."

# game/beyond the bet/day9dlc.rpy:861
translate Spanish dlc_9room_576e718e:

    # GRC "It should be a sin, being this good looking in everything."
    GRC "Debería ser pecado verse así de bien con todo."

# game/beyond the bet/day9dlc.rpy:869
translate Spanish dlc_9room_4eb9a670:

    # GRC "Yes, well, maybe..."
    GRC "Sí, bueno, quizás..."

# game/beyond the bet/day9dlc.rpy:870
translate Spanish dlc_9room_c8121e0e:

    # GRC "Maybe you will see me in formal clothes again one day."
    GRC "Quizás me veas con ropa formal de nuevo algún día."

# game/beyond the bet/day9dlc.rpy:875
translate Spanish dlc_9room_ac16a735:

    # GRC "N... no! I mean, not yet... ugh..."
    GRC "¡N... no! O sea, todavía no... ugh..."

# game/beyond the bet/day9dlc.rpy:886
translate Spanish dlc_9room_ca175789:

    # GRC "...Yes, you'll get it back quickly. I promise."
    GRC "...Sí, la recuperarás pronto. Lo prometo."

# game/beyond the bet/day9dlc.rpy:897
translate Spanish dlc_9room_008afe10_8:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:904
translate Spanish dlc_9room_e3271d70:

    # GRC "I, uh..."
    GRC "Yo, eh..."

# game/beyond the bet/day9dlc.rpy:905
translate Spanish dlc_9room_65122790_1:

    # GRC "I..."
    GRC "Yo..."

# game/beyond the bet/day9dlc.rpy:907
translate Spanish dlc_9room_f5e62b28:

    # GRC "Nine hells, I think I'm going to die if this godforsaken fluttering in my stomach does not cease!"
    GRC "¡Nueve infiernos, creo que voy a morir si este maldito aleteo en mi estómago no cesa!"

# game/beyond the bet/day9dlc.rpy:908
translate Spanish dlc_9room_008afe10_9:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:909
translate Spanish dlc_9room_a6df74f0:

    # GRC "I... love you, Sunshine. Be well."
    GRC "Yo... te amo, Solecito. Cuídate."

# game/beyond the bet/day9dlc.rpy:919
translate Spanish dlc_9room_c056a9f7:

    # GRC "That is the goal."
    GRC "Ese es el objetivo."

# game/beyond the bet/day9dlc.rpy:920
translate Spanish dlc_9room_dbcae3d4:

    # "{i}He gives you a gentle kiss, before he turns towards your window.{/i}"
    "{i}Te da un suave beso antes de girarse hacia tu ventana.{/i}"

# game/beyond the bet/day9dlc.rpy:925
translate Spanish dlc_9room_bc77dcd3:

    # "{i}It's too late.{/i}"
    "{i}Es demasiado tarde.{/i}"

# game/beyond the bet/day9dlc.rpy:926
translate Spanish dlc_9room_a9fd7552:

    # "{i}He's gone out the window again.{/i}"
    "{i}Se ha ido por la ventana otra vez.{/i}"

# game/beyond the bet/day9dlc.rpy:927
translate Spanish dlc_9room_1fdd3495:

    # "{i}What a weirdo.{/i}"
    "{i}Qué bicho raro.{/i}"

# game/beyond the bet/day9dlc.rpy:928
translate Spanish dlc_9room_3ce2333f:

    # "{i}With a happy sigh, you turn back to your room.{/i}"
    "{i}Con un suspiro de felicidad, vuelves a mirar hacia tu habitación.{/i}"

# game/beyond the bet/day9dlc.rpy:929
translate Spanish dlc_9room_4f77a412:

    # "{i}Time to entertain yourself for a little while, you suppose.{/i}"
    "{i}Supongo que ahora toca entretenerme un rato.{/i}"

# game/beyond the bet/day9dlc.rpy:936
translate Spanish dlc_9room_60d3fd44:

    # center_text "You spend the day with [pet_name], clean up your apartment, and play around on your computer."
    center_text "Pasas el día con [pet_name], limpias tu apartamento y pasas un rato en la computadora."

# game/beyond the bet/day9dlc.rpy:937
translate Spanish dlc_9room_bebb0c78:

    # center_text "It's a little boring now that Casper isn't here, but you manage."
    center_text "Ahora que Casper no está, todo es un poco aburrido, pero te las arreglas."

# game/beyond the bet/day9dlc.rpy:938
translate Spanish dlc_9room_15e7c81f:

    # center_text "You've spent years without knowing Casper! Why should you be bored now?"
    center_text "¡Pasaste años sin conocer a Casper! ¿Por qué tendrías que aburrirte ahora?"

# game/beyond the bet/day9dlc.rpy:939
translate Spanish dlc_9room_e3c3584d:

    # center_text "But, you come to realize that you are indeed feeling a little lonely with him gone."
    center_text "Pero terminas dándote cuenta de que sí te sientes un poco sol[letra] ahora que él no está."

# game/beyond the bet/day9dlc.rpy:940
translate Spanish dlc_9room_54609664:

    # center_text "As the moon rises high in the sky, you finish washing your dishes, then turn back to your room..."
    center_text "Mientras la luna se alza en lo alto del cielo, terminas de lavar los platos y luego vuelves a tu habitación..."

# game/beyond the bet/day9dlc.rpy:948
translate Spanish day9dlc_roomstart_d41d8cd9:

    # nvl clear
    nvl clear

# game/beyond the bet/day9dlc.rpy:991
translate Spanish day9dlc_chatstart_731ee0d9:

    # GR "sunshine, are you safe? well? are you at home? did you eat?"
    GR "solecito, ¿estás a salvo? ¿estás bien? ¿estás en casa? ¿ya comiste?"

# game/beyond the bet/day9dlc.rpy:994
translate Spanish day9dlc_chatstart_58ad14da:

    # player "Woah, woah, woah."
    player "Ey, ey, ey."

# game/beyond the bet/day9dlc.rpy:996
translate Spanish day9dlc_chatstart_8e54c607:

    # player "TOO MANY QUESTIONS!"
    player "¡DEMASIADAS PREGUNTAS!"

# game/beyond the bet/day9dlc.rpy:999
translate Spanish day9dlc_chatstart_92eb84b9:

    # player "Slow down!"
    player "¡Más despacio!"

# game/beyond the bet/day9dlc.rpy:1000
translate Spanish day9dlc_chatstart_4ee98cd4:

    # GR "okay."
    GR "okey."

# game/beyond the bet/day9dlc.rpy:1001
translate Spanish day9dlc_chatstart_f8a24d9a:

    # GR "s"
    GR "s"

# game/beyond the bet/day9dlc.rpy:1002
translate Spanish day9dlc_chatstart_ea05e82e:

    # GR "u"
    GR "o"

# game/beyond the bet/day9dlc.rpy:1003
translate Spanish day9dlc_chatstart_79b4c597:

    # GR "n"
    GR "l"

# game/beyond the bet/day9dlc.rpy:1004
translate Spanish day9dlc_chatstart_f8a24d9a_1:

    # GR "s"
    GR "e"

# game/beyond the bet/day9dlc.rpy:1005
translate Spanish day9dlc_chatstart_a1982015:

    # GR "h"
    GR "c"

# game/beyond the bet/day9dlc.rpy:1006
translate Spanish day9dlc_chatstart_c7bbf3f0:

    # GR "i"
    GR "i"

# game/beyond the bet/day9dlc.rpy:1007
translate Spanish day9dlc_chatstart_79b4c597_1:

    # GR "n"
    GR "t"

# game/beyond the bet/day9dlc.rpy:1008
translate Spanish day9dlc_chatstart_c36dfc42:

    # GR "e"
    GR "o"

# game/beyond the bet/day9dlc.rpy:1011
translate Spanish day9dlc_chatstart_41b2766a:

    # player "Alright you asshole, not that slow."
    player "Está bien, idiota, tampoco te tardes tanto."

# game/beyond the bet/day9dlc.rpy:1013
translate Spanish day9dlc_chatstart_1ac6ba13:

    # player "Ha. Ha. Ha."
    player "Ja. Ja. Ja."

# game/beyond the bet/day9dlc.rpy:1014
translate Spanish day9dlc_chatstart_2b0cbe16:

    # GR "i will take it to mean you are well."
    GR "lo tomaré como que estás bien."

# game/beyond the bet/day9dlc.rpy:1017
translate Spanish day9dlc_chatstart_ff7ba720:

    # player "I'm fine, yeah."
    player "Sí, estoy bien."

# game/beyond the bet/day9dlc.rpy:1020
translate Spanish day9dlc_chatstart_def8d72d:

    # player "Just been hanging out with [pet_name]."
    player "Solo pasando el rato con [pet_name]."

# game/beyond the bet/day9dlc.rpy:1023
translate Spanish day9dlc_chatstart_e59bec0b:

    # player "No one's come to steal away my soul or anything."
    player "Nadie ha venido a llevarse mi alma ni nada."

# game/beyond the bet/day9dlc.rpy:1024
translate Spanish day9dlc_chatstart_81b9d595:

    # GR "that is good. good..."
    GR "eso es bueno. bueno..."

# game/beyond the bet/day9dlc.rpy:1027
translate Spanish day9dlc_chatstart_a68810e2:

    # player "Aaargh, no... I think... I think I'm... dying..."
    player "Aaargh, no... creo que... creo que me estoy... muriendo..."

# game/beyond the bet/day9dlc.rpy:1028
translate Spanish day9dlc_chatstart_3622363b:

    # GR "?????????"
    GR "?????????"

# game/beyond the bet/day9dlc.rpy:1029
translate Spanish day9dlc_chatstart_0b297f38:

    # GR "stay right there!!!"
    GR "¡¡¡quédate ahí!!!"

# game/beyond the bet/day9dlc.rpy:1032
translate Spanish day9dlc_chatstart_ee5fa167:

    # player "Wait!! I'm kidding!!!"
    player "¡¡Espera!! ¡¡Es broma!!"

# game/beyond the bet/day9dlc.rpy:1035
translate Spanish day9dlc_chatstart_52f5677d:

    # player "I'm fine, I promise!"
    player "¡Estoy bien, lo prometo!"

# game/beyond the bet/day9dlc.rpy:1036
translate Spanish day9dlc_chatstart_7772a27d:

    # GR "..."
    GR "..."

# game/beyond the bet/day9dlc.rpy:1037
translate Spanish day9dlc_chatstart_e9b95e5a:

    # GR "you should not frighten me so."
    GR "no deberías asustarme así."

# game/beyond the bet/day9dlc.rpy:1040
translate Spanish day9dlc_chatstart_77e9f5df:

    # player "I didn't mean to."
    player "No era mi intención."

# game/beyond the bet/day9dlc.rpy:1043
translate Spanish day9dlc_chatstart_01ee5672:

    # player "My bad."
    player "Mi error."

# game/beyond the bet/day9dlc.rpy:1045
translate Spanish day9dlc_chatstart_96ef45cc:

    # player "I'm a little sorry but it's also a bit funny, you know?"
    player "Me siento un poco mal, pero también tiene algo de gracia, ¿sabes?"

# game/beyond the bet/day9dlc.rpy:1046
translate Spanish day9dlc_chatstart_17fa0a85:

    # GR "to scare me?"
    GR "¿asustarme?"

# game/beyond the bet/day9dlc.rpy:1049
translate Spanish day9dlc_chatstart_2284033c:

    # player "To scare the big bad Grim Reaper, yeah!"
    player "¡Asustar a la gran y malvada Parca, sí!"

# game/beyond the bet/day9dlc.rpy:1050
translate Spanish day9dlc_chatstart_ec79d7e8:

    # GR "sigh......."
    GR "suspiro......."

# game/beyond the bet/day9dlc.rpy:1051
translate Spanish day9dlc_chatstart_5ea3249b:

    # GR "you are a troublesome mortal. very troublesome."
    GR "eres [arti_2] mortal problemátic[letra]. muy problemátic[letra]."

# game/beyond the bet/day9dlc.rpy:1054
translate Spanish day9dlc_chatstart_21826d5b:

    # player "How's everything going?"
    player "¿Cómo va todo?"

# game/beyond the bet/day9dlc.rpy:1055
translate Spanish day9dlc_chatstart_0f66a0e8:

    # GR "that depends on what you are referring to."
    GR "eso depende de a qué te refieras."

# game/beyond the bet/day9dlc.rpy:1056
translate Spanish day9dlc_chatstart_8a8ec0f6:

    # GR "in regards to azrael, he is well."
    GR "en cuanto a azrael, está bien."

# game/beyond the bet/day9dlc.rpy:1057
translate Spanish day9dlc_chatstart_6da1e239:

    # GR "in regards to me, i believe soon i may go crazy from our current predicament."
    GR "en cuanto a mí, creo que pronto podría volverme loco por nuestra situación actual."

# game/beyond the bet/day9dlc.rpy:1060
translate Spanish day9dlc_chatstart_0c46ae89:

    # player "I'm glad Azrael's good!"
    player "¡Me alegra que Azrael esté bien!"

# game/beyond the bet/day9dlc.rpy:1061
translate Spanish day9dlc_chatstart_ef726d95:

    # GR "as am i."
    GR "a mí también."

# game/beyond the bet/day9dlc.rpy:1062
translate Spanish day9dlc_chatstart_2d6cb7cc:

    # GR "too much stress is not good for him."
    GR "el exceso de estrés no le hace bien."

# game/beyond the bet/day9dlc.rpy:1064
translate Spanish day9dlc_chatstart_c2f908ee:

    # player "You sound a little stressed."
    player "Suenas un poco estresado."

# game/beyond the bet/day9dlc.rpy:1065
translate Spanish day9dlc_chatstart_1f1a49e9:

    # GR "a little?"
    GR "¿un poco?"

# game/beyond the bet/day9dlc.rpy:1066
translate Spanish day9dlc_chatstart_ddb5f781:

    # GR "that is an understatement."
    GR "eso es quedarse corto."

# game/beyond the bet/day9dlc.rpy:1067
translate Spanish day9dlc_chatstart_ee842b59:

    # GR "the understatement of the decade."
    GR "el eufemismo de la década."

# game/beyond the bet/day9dlc.rpy:1068
translate Spanish day9dlc_chatstart_7bf4e85d:

    # GR "or perhaps even the century."
    GR "o quizás incluso del siglo."

# game/beyond the bet/day9dlc.rpy:1071
translate Spanish day9dlc_chatstart_d1388376:

    # player "What part is making *you* so stressed, then?"
    player "¿Qué es lo que te estresa a 'ti', entonces?"

# game/beyond the bet/day9dlc.rpy:1074
translate Spanish day9dlc_chatstart_91d05df7:

    # player "Stressed about how good-looking I am?"
    player "¿Estresado por lo guap[letra] que soy?"

# game/beyond the bet/day9dlc.rpy:1075
translate Spanish day9dlc_chatstart_a4c1625b:

    # GR "i... what?"
    GR "yo... ¿qué?"

# game/beyond the bet/day9dlc.rpy:1076
translate Spanish day9dlc_chatstart_46021d84:

    # GR "i suppose that plays into this, somewhat."
    GR "supongo que eso influye, en cierta medida."

# game/beyond the bet/day9dlc.rpy:1077
translate Spanish day9dlc_chatstart_f5be1a38:

    # GR "if you were not so annoyingly charming..."
    GR "si no fueras tan insufriblemente lind[letra]."

# game/beyond the bet/day9dlc.rpy:1078
translate Spanish day9dlc_chatstart_30c7e1df:

    # GR "and good-looking..."
    GR "y tan guap[letra]..."

# game/beyond the bet/day9dlc.rpy:1079
translate Spanish day9dlc_chatstart_a394a689:

    # GR "then perhaps i would not have fallen into this trap."
    GR "entonces quizás no habría caído en esta trampa."

# game/beyond the bet/day9dlc.rpy:1082
translate Spanish day9dlc_chatstart_71b6229f:

    # player "Oooh you think I'm cuuuute, huh?"
    player "Oooh, te parezco adoraaable, ¿eh?"

# game/beyond the bet/day9dlc.rpy:1083
translate Spanish day9dlc_chatstart_f94badc6:

    # GR "shut up."
    GR "cállate."

# game/beyond the bet/day9dlc.rpy:1086
translate Spanish day9dlc_chatstart_5bc56c80:

    # player "I think you're cute."
    player "Yo creo que eres lindo."

# game/beyond the bet/day9dlc.rpy:1087
translate Spanish day9dlc_chatstart_2c20a8d3:

    # GR "that much is obvious to anyone that has eyes."
    GR "eso es obvio para cualquiera que tenga ojos."

# game/beyond the bet/day9dlc.rpy:1090
translate Spanish day9dlc_chatstart_735a390e:

    # player "Your confidence really has never wavered."
    player "Tu confianza de verdad nunca ha flaqueado."

# game/beyond the bet/day9dlc.rpy:1091
translate Spanish day9dlc_chatstart_bd743cc0:

    # GR "as i told you a long time ago, confidence is sexy."
    GR "como te dije hace mucho tiempo, la confianza es sexy."

# game/beyond the bet/day9dlc.rpy:1092
translate Spanish day9dlc_chatstart_eec1ba7a:

    # GR "i am confident in... most things."
    GR "tengo confianza en... la mayoría de las cosas."

# game/beyond the bet/day9dlc.rpy:1093
translate Spanish day9dlc_chatstart_1eea651f:

    # GR "my looks, well, i am obviously confident when it comes to that."
    GR "mi apariencia, bueno, obviamente tengo confianza en eso."

# game/beyond the bet/day9dlc.rpy:1094
translate Spanish day9dlc_chatstart_36abde25:

    # GR "but when it comes to you..."
    GR "pero cuando se trata de ti..."

# game/beyond the bet/day9dlc.rpy:1095
translate Spanish day9dlc_chatstart_79840e45:

    # GR "ah, how you make me waver."
    GR "ah, cómo haces que flaquee."

# game/beyond the bet/day9dlc.rpy:1098
translate Spanish day9dlc_chatstart_838a0b99:

    # player "<3"
    player "<3"

# game/beyond the bet/day9dlc.rpy:1101
translate Spanish day9dlc_chatstart_043ebff4:

    # player "Hold up."
    player "Espera un momento."

# game/beyond the bet/day9dlc.rpy:1104
translate Spanish day9dlc_chatstart_c81bb7bd:

    # player "'a long time ago', he says."
    player "'hace mucho tiempo', dice."

# game/beyond the bet/day9dlc.rpy:1107
translate Spanish day9dlc_chatstart_9a0a7379:

    # player "That was like, a week ago!"
    player "¡Fue como hace una semana!"

# game/beyond the bet/day9dlc.rpy:1108
translate Spanish day9dlc_chatstart_bca18746:

    # GR "surely that is nearly a lifetime to a mortal like you, no?"
    GR "seguramente eso es casi una vida entera para un mortal como tú, ¿no?"

# game/beyond the bet/day9dlc.rpy:1111
translate Spanish day9dlc_chatstart_6296060c:

    # player "Alright, old man."
    player "Está bien, viejo."

# game/beyond the bet/day9dlc.rpy:1112
translate Spanish day9dlc_chatstart_8b1a8a6c:

    # GR "old man?!"
    GR "¡¿viejo?!"

# game/beyond the bet/day9dlc.rpy:1115
translate Spanish day9dlc_chatstart_6cc037be:

    # player "You're old, aren't you?"
    player "Eres viejo, ¿no?"

# game/beyond the bet/day9dlc.rpy:1116
translate Spanish day9dlc_chatstart_6dac5a80:

    # GR "...older than you."
    GR "...mayor que tú."

# game/beyond the bet/day9dlc.rpy:1119
translate Spanish day9dlc_chatstart_c3d5b65d:

    # player "I think I've found a new nickname."
    player "Creo que he encontrado un nuevo apodo."

# game/beyond the bet/day9dlc.rpy:1122
translate Spanish day9dlc_chatstart_58715da2:

    # player "Old Man Reaper."
    player "Viejo Parca."

# game/beyond the bet/day9dlc.rpy:1123
translate Spanish day9dlc_chatstart_1799b0de:

    # GR "........."
    GR "........."

# game/beyond the bet/day9dlc.rpy:1126
translate Spanish day9dlc_chatstart_71fab042:

    # player "You won't have to worry about greying with that hair, at least."
    player "Al menos no tendrás que preocuparte por las canas con ese cabello."

# game/beyond the bet/day9dlc.rpy:1127
translate Spanish day9dlc_chatstart_f33babb4:

    # GR "i do not grey!" id day9dlc_chatstart_f33babb4
    GR "¡no tengo canas!" id day9dlc_chatstart_f33babb4

# game/beyond the bet/day9dlc.rpy:1130
translate Spanish day9dlc_chatstart_7340c52e:

    # player "Wrinkly, grey haired Casper..."
    player "Casper arrugado y canoso..."

# game/beyond the bet/day9dlc.rpy:1133
translate Spanish day9dlc_chatstart_6f63e908:

    # player "It's almost a cute thought."
    player "Casi es un pensamiento lindo."

# game/beyond the bet/day9dlc.rpy:1134
translate Spanish day9dlc_chatstart_5c7c7f55:

    # GR "..........."
    GR "..........."

# game/beyond the bet/day9dlc.rpy:1135
translate Spanish day9dlc_chatstart_09cbb622:

    # GR "you are a nuisance."
    GR "eres una molestia."

# game/beyond the bet/day9dlc.rpy:1138
translate Spanish day9dlc_chatstart_bb14f5df:

    # player "Old man 🫵"
    player "Viejo 🫵"

# game/beyond the bet/day9dlc.rpy:1139
translate Spanish day9dlc_chatstart_b4ccc447:

    # GR "annoying mortal 🫵"
    GR "mortal molest[letra] 🫵"

# game/beyond the bet/day9dlc.rpy:1142
translate Spanish day9dlc_chatstart_58ca946b:

    # player "Woah, is that the first time you've ever used a normal emoji?"
    player "Uy, ¿es la primera vez que usas un emoji normal?"

# game/beyond the bet/day9dlc.rpy:1145
translate Spanish day9dlc_chatstart_e267a9d1:

    # player "Congratulations are in order!"
    player "¡Hay que felicitarte!"

# game/beyond the bet/day9dlc.rpy:1146
translate Spanish day9dlc_chatstart_133ecf3f:

    # GR "🖕🖕🖕"
    GR "🖕🖕🖕"

# game/beyond the bet/day9dlc.rpy:1147
translate Spanish day9dlc_chatstart_4bacd7f2:

    # GR "that one was beside the pointing finger. i believe it is quite fitting for this conversation."
    GR "ese estaba al lado del dedo que señala. creo que encaja bastante bien con esta conversación."

# game/beyond the bet/day9dlc.rpy:1150
translate Spanish day9dlc_chatstart_ddab294c:

    # player "Haha. You love me."
    player "Jaja. Me amas."

# game/beyond the bet/day9dlc.rpy:1151
translate Spanish day9dlc_chatstart_09ff6b05:

    # GR "ugh............"
    GR "ugh............"

# game/beyond the bet/day9dlc.rpy:1155
translate Spanish day9dlc_chatstart_1b57798c:

    # player "I enjoy making you uncertain."
    player "Me gusta hacerte dudar."

# game/beyond the bet/day9dlc.rpy:1158
translate Spanish day9dlc_chatstart_b8dd3a1c:

    # player "Something about a confident, handsome man becoming a mess just does it for me."
    player "Hay algo en ver a un hombre guapo y seguro de sí mismo perder la compostura que me encanta."

# game/beyond the bet/day9dlc.rpy:1159
translate Spanish day9dlc_chatstart_fc83d88c:

    # GR "i am not a mess."
    GR "no soy un desastre."

# game/beyond the bet/day9dlc.rpy:1160
translate Spanish day9dlc_chatstart_7302031e:

    # GR "i simply become... a little disarrayed."
    GR "simplemente me... descompongo un poco."

# game/beyond the bet/day9dlc.rpy:1163
translate Spanish day9dlc_chatstart_61041f69:

    # player "I can't imagine you in actual disarray."
    player "No me imagino que puedas perder realmente la compostura."

# game/beyond the bet/day9dlc.rpy:1166
translate Spanish day9dlc_chatstart_bd102777:

    # player "You seem like the kind of guy who likes everything neat and in order."
    player "Pareces de los que les gusta tener todo ordenado y en su sitio."

# game/beyond the bet/day9dlc.rpy:1167
translate Spanish day9dlc_chatstart_ba553548:

    # GR "i do."
    GR "así es."

# game/beyond the bet/day9dlc.rpy:1170
translate Spanish day9dlc_chatstart_8a3c9409:

    # player "So, if we lived together..."
    player "Entonces, si viviéramos juntos..."

# game/beyond the bet/day9dlc.rpy:1173
translate Spanish day9dlc_chatstart_8e8fecf9:

    # player "You'd be like my house wife?"
    player "¿Serías como mi ama de casa?"

# game/beyond the bet/day9dlc.rpy:1174
translate Spanish day9dlc_chatstart_ebf05d6f:

    # GR "h... house wife...?!"
    GR "a... ¡¿ama de casa...?!"

# game/beyond the bet/day9dlc.rpy:1175
translate Spanish day9dlc_chatstart_65cdfdb2:

    # GR "wouldn't i be a house husband?!"
    GR "¡¿no sería yo un amo de casa?!"

# game/beyond the bet/day9dlc.rpy:1178
translate Spanish day9dlc_chatstart_bf0d3836:

    # player "House wife is a state of being, Casper."
    player "Ama de casa es un estado del ser, Casper."

# game/beyond the bet/day9dlc.rpy:1179
translate Spanish day9dlc_chatstart_7772a27d_1:

    # GR "..."
    GR "..."

# game/beyond the bet/day9dlc.rpy:1180
translate Spanish day9dlc_chatstart_e1acc420:

    # GR "then..."
    GR "entonces..."

# game/beyond the bet/day9dlc.rpy:1181
translate Spanish day9dlc_chatstart_ad9a4f1a:

    # GR "i will be your house wife, sunshine."
    GR "seré tu ama de casa, solecito."

# game/beyond the bet/day9dlc.rpy:1184
translate Spanish day9dlc_chatstart_0b8b6bc0:

    # player "That's true love <3"
    player "Eso es amor verdadero <3"

# game/beyond the bet/day9dlc.rpy:1187
translate Spanish day9dlc_chatstart_6126a258:

    # player "I can leave all the cleaning to you."
    player "Puedo dejarte toda la limpieza a ti."

# game/beyond the bet/day9dlc.rpy:1188
translate Spanish day9dlc_chatstart_57ca9b7b:

    # GR "well, seeing your apartment, i believe that is the right call."
    GR "bueno, viendo tu apartamento, creo que es la decisión correcta."

# game/beyond the bet/day9dlc.rpy:1191
translate Spanish day9dlc_chatstart_f044b30a:

    # player "Hey!"
    player "¡Hey!"

# game/beyond the bet/day9dlc.rpy:1194
translate Spanish day9dlc_chatstart_1b90f441:

    # player "My apartment is super clean."
    player "Mi apartamento está súper limpio."

# game/beyond the bet/day9dlc.rpy:1195
translate Spanish day9dlc_chatstart_eb263b48:

    # GR "i saw all the things you stuffed under your bed."
    GR "vi todas las cosas que metiste debajo de tu cama."

# game/beyond the bet/day9dlc.rpy:1198
translate Spanish day9dlc_chatstart_9f1b6413:

    # player "Ah."
    player "Ah."

# game/beyond the bet/day9dlc.rpy:1201
translate Spanish day9dlc_chatstart_17855849:

    # player "Busted."
    player "Me descubrieron."

# game/beyond the bet/day9dlc.rpy:1202
translate Spanish day9dlc_chatstart_7c1d2e69:

    # GR "if... a time ever came where you and i..."
    GR "si... algún día llegara el momento en que tú y yo..."

# game/beyond the bet/day9dlc.rpy:1203
translate Spanish day9dlc_chatstart_b8a86f17:

    # GR "ahem..."
    GR "ejem..."

# game/beyond the bet/day9dlc.rpy:1204
translate Spanish day9dlc_chatstart_0e84935e:

    # GR "you can leave the cleaning to me."
    GR "puedes dejar la limpieza en mis manos."

# game/beyond the bet/day9dlc.rpy:1207
translate Spanish day9dlc_chatstart_2335f374:

    # player "That works for me!"
    player "¡Por mí, perfecto!"

# game/beyond the bet/day9dlc.rpy:1209
translate Spanish day9dlc_chatstart_53821982:

    # player "Thank god."
    player "Gracias a Dios."

# game/beyond the bet/day9dlc.rpy:1211
translate Spanish day9dlc_chatstart_39c65d70:

    # player "But really, I can help."
    player "Pero en serio, puedo ayudar."

# game/beyond the bet/day9dlc.rpy:1214
translate Spanish day9dlc_chatstart_b58385b3:

    # player "A little."
    player "Un poco."

# game/beyond the bet/day9dlc.rpy:1217
translate Spanish day9dlc_chatstart_3f60a1ae:

    # player "The whole forbidden relationship thing?"
    player "¿Lo de la relación prohibida y todo eso?"

# game/beyond the bet/day9dlc.rpy:1218
translate Spanish day9dlc_chatstart_fdada7b6:

    # GR "the way you downplay that is astounding."
    GR "la forma en que le restas importancia es asombrosa."

# game/beyond the bet/day9dlc.rpy:1219
translate Spanish day9dlc_chatstart_43001f7f:

    # GR "i wish had your nonchalance."
    GR "ojalá tuviera tu despreocupación."

# game/beyond the bet/day9dlc.rpy:1222
translate Spanish day9dlc_chatstart_54a246a0:

    # player "Thanks, I'm actually terrified."
    player "Gracias, en realidad me muero de miedo."

# game/beyond the bet/day9dlc.rpy:1223
translate Spanish day9dlc_chatstart_6d3b5ce3:

    # GR "aha!"
    GR "¡aja!"

# game/beyond the bet/day9dlc.rpy:1224
translate Spanish day9dlc_chatstart_ef7fe539:

    # GR "well, color me surprised."
    GR "vaya, qué sorpresa."

# game/beyond the bet/day9dlc.rpy:1225
translate Spanish day9dlc_chatstart_44478ffb:

    # GR "i would not have guessed."
    GR "no lo habría imaginado."

# game/beyond the bet/day9dlc.rpy:1228
translate Spanish day9dlc_chatstart_6ea969da:

    # player "Thank you, thank you."
    player "Gracias, gracias."

# game/beyond the bet/day9dlc.rpy:1231
translate Spanish day9dlc_chatstart_fb47e944:

    # player "When can I collect my emmy?"
    player "¿Cuándo puedo recoger mi Emmy?"

# game/beyond the bet/day9dlc.rpy:1232
translate Spanish day9dlc_chatstart_cfda8b52:

    # GR "when you win one."
    GR "cuando ganes uno."

# game/beyond the bet/day9dlc.rpy:1233
translate Spanish day9dlc_chatstart_5507d5e2:

    # GR "do not quit your day job, sunshine."
    GR "no dejes tu trabajo diario, solecito."

# game/beyond the bet/day9dlc.rpy:1236
translate Spanish day9dlc_chatstart_5b80b9bb:

    # player "You think I couldn't make it as an actor?"
    player "¿Crees que no podría triunfar en la actuación?"

# game/beyond the bet/day9dlc.rpy:1237
translate Spanish day9dlc_chatstart_59597739:

    # GR "perhaps you could consider being a stunt double."
    GR "quizás podrías considerar ser doble de acción."

# game/beyond the bet/day9dlc.rpy:1240
translate Spanish day9dlc_chatstart_fe244085:

    # player "Oooooh!"
    player "¡Oooooh!"

# game/beyond the bet/day9dlc.rpy:1241
translate Spanish day9dlc_chatstart_ab13546a:

    # GR "you could be thrown into any dangerous stunt and still come out unscathed."
    GR "podrían lanzarte a cualquier escena peligrosa y saldrías iles[letra]."

# game/beyond the bet/day9dlc.rpy:1242
translate Spanish day9dlc_chatstart_7722a3bc:

    # GR "a role made for you, in my opinion."
    GR "un papel hecho para ti, en mi opinión."

# game/beyond the bet/day9dlc.rpy:1245
translate Spanish day9dlc_chatstart_78f3dc99:

    # player "Maybe if all of this works out and I get to keep my soul, I'll try it out."
    player "Quizás si todo esto sale bien y me quedo con mi alma, lo probaré."

# game/beyond the bet/day9dlc.rpy:1248
translate Spanish day9dlc_chatstart_13651b16:

    # player "You know, on the side."
    player "Ya sabes, como extra."

# game/beyond the bet/day9dlc.rpy:1251
translate Spanish day9dlc_chatstart_d4cabce7:

    # player "If that's something you even do on the side? Anyway..."
    player "¿Si es algo que se hace como extra siquiera? En fin..."

# game/beyond the bet/day9dlc.rpy:1254
translate Spanish day9dlc_chatstart_050d0738:

    # player "Life's easier when you stop giving so much of a shit, ya know?"
    player "La vida es más fácil cuando dejas de darle tanta importancia a todo, ¿sabes?"

# game/beyond the bet/day9dlc.rpy:1255
translate Spanish day9dlc_chatstart_3b93aaec:

    # GR "that is... surprisingly good advice."
    GR "eso es... un consejo sorprendentemente bueno."

# game/beyond the bet/day9dlc.rpy:1258
translate Spanish day9dlc_chatstart_701c4c34:

    # player "I'm full of good advice."
    player "Tengo un montón de buenos consejos."

# game/beyond the bet/day9dlc.rpy:1259
translate Spanish day9dlc_chatstart_4dee5ebe:

    # GR "then give me another piece of it."
    GR "entonces dame otro más."

# game/beyond the bet/day9dlc.rpy:1262
translate Spanish day9dlc_chatstart_8b4257db:

    # player "Time to pull out [playerfirstname]'s sage advice. Ahem."
    player "Es hora de recurrir a los sabios consejos de [playerfirstname]. Ejem."

# game/beyond the bet/day9dlc.rpy:1265
translate Spanish day9dlc_chatstart_e85cbcdc:

    # player "He who chases two rabbits catches neither."
    player "Quien persigue dos conejos no atrapa ninguno."

# game/beyond the bet/day9dlc.rpy:1266
translate Spanish day9dlc_chatstart_b2bc8adc:

    # GR "huh. that is indeed wise."
    GR "vaya. es sabio, en efecto."

# game/beyond the bet/day9dlc.rpy:1269
translate Spanish day9dlc_chatstart_19b10b1b:

    # player "Thanks, I read it on the side of a cereal box."
    player "Gracias, lo leí en el costado de una caja de cereal."

# game/beyond the bet/day9dlc.rpy:1270
translate Spanish day9dlc_chatstart_723ace68:

    # GR "when did cereal become so deep?"
    GR "¿cuándo se volvió tan profundo el cereal?"

# game/beyond the bet/day9dlc.rpy:1273
translate Spanish day9dlc_chatstart_e366aad6:

    # player "Oh, it's always been deep, Casper."
    player "Oh, siempre ha sido profundo, Casper."

# game/beyond the bet/day9dlc.rpy:1276
translate Spanish day9dlc_chatstart_f0f296b5:

    # player "Cereal is no joke."
    player "El cereal no es ninguna broma."

# game/beyond the bet/day9dlc.rpy:1277
translate Spanish day9dlc_chatstart_740478b1:

    # GR "i feel you are, as i heard a mortal say once, 'taking the piss'."
    GR "siento que me estás, como escuché decir una vez a un mortal, 'tomando el pelo'."

# game/beyond the bet/day9dlc.rpy:1280
translate Spanish day9dlc_chatstart_e564304a:

    # player "Jeez."
    player "Cielos."

# game/beyond the bet/day9dlc.rpy:1283
translate Spanish day9dlc_chatstart_19413a29:

    # player "What Australians have you been talking to?"
    player "¿Con qué australianos has estado hablando?"

# game/beyond the bet/day9dlc.rpy:1284
translate Spanish day9dlc_chatstart_0913acc8:

    # GR "i take souls from all over the world."
    GR "tomo almas de todo el mundo."

# game/beyond the bet/day9dlc.rpy:1285
translate Spanish day9dlc_chatstart_6b246ac1:

    # GR "i hear many strange sayings."
    GR "oigo muchos dichos extraños."

# game/beyond the bet/day9dlc.rpy:1288
translate Spanish day9dlc_chatstart_957dde9e:

    # player "I hope you'll tell me all about them one day."
    player "Espero que algún día me los cuentes todos."

# game/beyond the bet/day9dlc.rpy:1289
translate Spanish day9dlc_chatstart_b11878f5:

    # GR "when everything calms down, i hope to tell you lots of things."
    GR "cuando todo se calme, espero contarte muchas cosas."

# game/beyond the bet/day9dlc.rpy:1292
translate Spanish day9dlc_chatstart_7a7393dc:

    # player "He who smelt it, dealt it."
    player "Quien lo huele, debajo lo tiene."

# game/beyond the bet/day9dlc.rpy:1293
translate Spanish day9dlc_chatstart_d2974b70:

    # GR "shame on me for expecting something serious."
    GR "qué ingenuo fui al esperar algo serio."

# game/beyond the bet/day9dlc.rpy:1296
translate Spanish day9dlc_chatstart_037746c5:

    # player "Yeah that's on you, buddy."
    player "Sí, eso es culpa tuya, amigo."

# game/beyond the bet/day9dlc.rpy:1299
translate Spanish day9dlc_chatstart_f8010c75:

    # player "You know me better than that."
    player "Me conoces mejor que eso."

# game/beyond the bet/day9dlc.rpy:1300
translate Spanish day9dlc_chatstart_83d76bda:

    # GR "where that is fortunate or not, i do not know."
    GR "no sé si eso es una suerte o no."

# game/beyond the bet/day9dlc.rpy:1303
translate Spanish day9dlc_chatstart_4961a417:

    # player "Definitely fortunate."
    player "Definitivamente es una suerte."

# game/beyond the bet/day9dlc.rpy:1306
translate Spanish day9dlc_chatstart_4bed5448:

    # player "Somehow after only, what, a little over a week?"
    player "¿Y pensar que solo llevamos, qué, poco más de una semana?"

# game/beyond the bet/day9dlc.rpy:1309
translate Spanish day9dlc_chatstart_7c1065a1:

    # player "You know me so much better than anyone else."
    player "Me conoces mucho mejor que nadie."

# game/beyond the bet/day9dlc.rpy:1310
translate Spanish day9dlc_chatstart_3643f970:

    # GR "i have known you longer than that."
    GR "yo te conozco desde mucho antes."

# game/beyond the bet/day9dlc.rpy:1311
translate Spanish day9dlc_chatstart_b0307b77:

    # GR "it is only you that has known me for that long."
    GR "tú eres quien solo me conoce desde hace ese tiempo."

# game/beyond the bet/day9dlc.rpy:1314
translate Spanish day9dlc_chatstart_f8495abb:

    # player "Right."
    player "Cierto."

# game/beyond the bet/day9dlc.rpy:1317
translate Spanish day9dlc_chatstart_07d98e08:

    # player "I forgot you have a voyeuristic streak."
    player "Olvidé que tienes tu lado voyeur."

# game/beyond the bet/day9dlc.rpy:1318
translate Spanish day9dlc_chatstart_3622363b_1:

    # GR "?????????"
    GR "?????????"

# game/beyond the bet/day9dlc.rpy:1319
translate Spanish day9dlc_chatstart_311f00fa:

    # GR "it was my job to watch you! your soul was owed to me!"
    GR "¡mi trabajo era observarte! ¡tu alma me pertenecía!"

# game/beyond the bet/day9dlc.rpy:1322
translate Spanish day9dlc_chatstart_dc1a3449:

    # player "Come onnn, Grimmy."
    player "Vamos, Parquita."

# game/beyond the bet/day9dlc.rpy:1325
translate Spanish day9dlc_chatstart_80d26414:

    # player "We both know you were watching closer than you needed to."
    player "Ambos sabemos que mirabas más de cerca de lo necesario."

# game/beyond the bet/day9dlc.rpy:1328
translate Spanish day9dlc_chatstart_f1ca70f3:

    # player "Did you like what you saw?"
    player "¿Te gustó lo que viste?"

# game/beyond the bet/day9dlc.rpy:1329
translate Spanish day9dlc_chatstart_c30211c0:

    # GR "i..."
    GR "yo..."

# game/beyond the bet/day9dlc.rpy:1330
translate Spanish day9dlc_chatstart_26660509:

    # GR "you were a target."
    GR "eras un objetivo."

# game/beyond the bet/day9dlc.rpy:1333
translate Spanish day9dlc_chatstart_8b5b893f:

    # player "Buuuut?"
    player "¿Peeero?"

# game/beyond the bet/day9dlc.rpy:1334
translate Spanish day9dlc_chatstart_7772a27d_2:

    # GR "..."
    GR "..."

# game/beyond the bet/day9dlc.rpy:1335
translate Spanish day9dlc_chatstart_31c5a651:

    # GR "yes, fine."
    GR "sí, bien."

# game/beyond the bet/day9dlc.rpy:1336
translate Spanish day9dlc_chatstart_ff473f59:

    # GR "perhaps i needn't have spent so many evenings gazing at you from afar..."
    GR "quizás no habría necesitado pasar tantas noches contemplándote desde lejos..."

# game/beyond the bet/day9dlc.rpy:1337
translate Spanish day9dlc_chatstart_13c46b0f:

    # GR "wondering what you were thinking about..."
    GR "preguntándome en qué estarías pensando..."

# game/beyond the bet/day9dlc.rpy:1338
translate Spanish day9dlc_chatstart_97a5920e:

    # GR "perhaps that was not part of my job."
    GR "quizás eso no formaba parte de mi trabajo."

# game/beyond the bet/day9dlc.rpy:1339
translate Spanish day9dlc_chatstart_a4d15129:

    # GR "perhaps."
    GR "quizá."

# game/beyond the bet/day9dlc.rpy:1342
translate Spanish day9dlc_chatstart_c13aafc6:

    # player "You're so cute."
    player "Eres tan lindo."

# game/beyond the bet/day9dlc.rpy:1346
translate Spanish day9dlc_chatstart_a6c0f259:

    # player "Hey, Casper!"
    player "¡Oye, Casper!"

# game/beyond the bet/day9dlc.rpy:1347
translate Spanish day9dlc_chatstart_e58cd47c:

    # GR "yes, [playerfirstname!l]?"
    GR "¿sí, [playerfirstname!l]?"

# game/beyond the bet/day9dlc.rpy:1350
translate Spanish day9dlc_chatstart_932ddc65:

    # player "Did you make any progress today on the whole, ya know, have to take my soul thing?"
    player "¿Avanzaste algo hoy con lo de, ya sabes, tener que llevarte mi alma?"

# game/beyond the bet/day9dlc.rpy:1351
translate Spanish day9dlc_chatstart_759553e9:

    # GR "...very little."
    GR "...muy poco."

# game/beyond the bet/day9dlc.rpy:1352
translate Spanish day9dlc_chatstart_524b4f2e:

    # GR "i was sent on another mission as soon as i returned, and have only just come back to the underworld."
    GR "me enviaron a otra misión en cuanto regresé, y apenas acabo de volver al inframundo."

# game/beyond the bet/day9dlc.rpy:1353
translate Spanish day9dlc_chatstart_840607ec:

    # GR "i'm hoping i can convince them that your soul is not supposed to be taken yet, but..."
    GR "espero poder convencerlos de que tu alma aún no debe ser tomada, pero..."

# game/beyond the bet/day9dlc.rpy:1356
translate Spanish day9dlc_chatstart_70d6b430:

    # player "But?"
    player "¿Pero?"

# game/beyond the bet/day9dlc.rpy:1357
translate Spanish day9dlc_chatstart_3c910256:

    # GR "i can not think of a single case in history where a reaper has managed to 'save' a mortal."
    GR "no se me ocurre un solo caso en la historia en que una parca haya logrado 'salvar' a un mortal."

# game/beyond the bet/day9dlc.rpy:1360
translate Spanish day9dlc_chatstart_fcc80e17:

    # player "Not fantastic odds, then."
    player "Entonces no son probabilidades fantásticas."

# game/beyond the bet/day9dlc.rpy:1361
translate Spanish day9dlc_chatstart_1913bd3e:

    # GR "no, not at all fantastic."
    GR "no, para nada fantásticas."

# game/beyond the bet/day9dlc.rpy:1362
translate Spanish day9dlc_chatstart_8d541756:

    # GR "there are other avenues for me to investigate."
    GR "hay otras vías que puedo investigar."

# game/beyond the bet/day9dlc.rpy:1363
translate Spanish day9dlc_chatstart_bd9f4019:

    # GR "a way for me to give up being a reaper... equally unlikely, though worth pursuing, perhaps."
    GR "una forma de dejar de ser parca... igual de improbable, aunque quizás valga la pena intentarlo."

# game/beyond the bet/day9dlc.rpy:1364
translate Spanish day9dlc_chatstart_f50cd7a9:

    # GR "maybe a way to secretly remove you from our systems..."
    GR "quizás una forma de eliminarte en secreto de nuestros sistemas..."

# game/beyond the bet/day9dlc.rpy:1367
translate Spanish day9dlc_chatstart_289264dc:

    # player "Woah, I'd be going underground?"
    player "Uy, ¿pasaría a la clandestinidad?"

# game/beyond the bet/day9dlc.rpy:1368
translate Spanish day9dlc_chatstart_07f8397a:

    # GR "in the eyes of the grim reapers, yes."
    GR "a ojos de las parcas, sí."

# game/beyond the bet/day9dlc.rpy:1369
translate Spanish day9dlc_chatstart_a63f9660:

    # GR "and if none of that works... then i hope to find a way to protect you after i am terminated."
    GR "y si nada de eso funciona... espero encontrar una forma de protegerte después de que me eliminen."

# game/beyond the bet/day9dlc.rpy:1372
translate Spanish day9dlc_chatstart_e74030b3:

    # player "Casper."
    player "Casper."

# game/beyond the bet/day9dlc.rpy:1374
translate Spanish day9dlc_chatstart_718c2337:

    # player "Grim."
    player "Parca."

# game/beyond the bet/day9dlc.rpy:1377
translate Spanish day9dlc_chatstart_846872c7:

    # player "No one's getting terminated."
    player "Nadie va a ser eliminado."

# game/beyond the bet/day9dlc.rpy:1378
translate Spanish day9dlc_chatstart_c4198a20:

    # GR "i cannot see an ending that does not have one or both of us dead."
    GR "no logro ver un final que no tenga a uno de los dos muertos, o a ambos."

# game/beyond the bet/day9dlc.rpy:1379
translate Spanish day9dlc_chatstart_3a1d8a55:

    # GR "but your optimism is infectious, like a disease." id day9dlc_chatstart_3a1d8a55
    GR "pero tu optimismo es contagioso, como una enfermedad." id day9dlc_chatstart_3a1d8a55

# game/beyond the bet/day9dlc.rpy:1380
translate Spanish day9dlc_chatstart_1a7d8fd3:

    # GR "and as such, i will investigate whatever avenues i can."
    GR "y por lo tanto, investigaré todas las vías que pueda."

# game/beyond the bet/day9dlc.rpy:1383
translate Spanish day9dlc_chatstart_e48e809c:

    # player "Good boy."
    player "Buen chico."

# game/beyond the bet/day9dlc.rpy:1384
translate Spanish day9dlc_chatstart_d3ee0316:

    # GR "again with the... good boy..."
    GR "otra vez con lo de... buen chico..."

# game/beyond the bet/day9dlc.rpy:1385
translate Spanish day9dlc_chatstart_0f1964f1:

    # GR "if anything, i am a bad boy."
    GR "en todo caso, soy un chico malo."

# game/beyond the bet/day9dlc.rpy:1388
translate Spanish day9dlc_chatstart_c8ea5c73:

    # player "Do you want me to call you bad boy, babygirl?"
    player "¿Quieres que te llame chico malo, babygirl?"

# game/beyond the bet/day9dlc.rpy:1389
translate Spanish day9dlc_chatstart_73cb9ec2:

    # GR "somehow that's worse."
    GR "de algún modo eso es peor."

# game/beyond the bet/day9dlc.rpy:1392
translate Spanish day9dlc_chatstart_50b253b9:

    # player "I will too."
    player "Yo también."

# game/beyond the bet/day9dlc.rpy:1393
translate Spanish day9dlc_chatstart_a47778eb:

    # GR "it is too dangerous."
    GR "es demasiado peligroso."

# game/beyond the bet/day9dlc.rpy:1394
translate Spanish day9dlc_chatstart_0649c639:

    # GR "please, just stay home and be safe for a little while."
    GR "por favor, solo quédate en casa y mantente a salvo por un tiempo."

# game/beyond the bet/day9dlc.rpy:1395
translate Spanish day9dlc_chatstart_2f4a574b:

    # GR "i will come up with a plan. i must."
    GR "se me ocurrirá un plan. tiene que ser así."

# game/beyond the bet/day9dlc.rpy:1396
translate Spanish day9dlc_chatstart_194ff93c:

    # GR "anyway."
    GR "de todos modos."

# game/beyond the bet/day9dlc.rpy:1397
translate Spanish day9dlc_chatstart_9831a280:

    # GR "i have made no progress yet, but i have ideas."
    GR "aún no he avanzado, pero tengo ideas."

# game/beyond the bet/day9dlc.rpy:1398
translate Spanish day9dlc_chatstart_11ab6096:

    # GR "i believe you should be safe for some time."
    GR "creo que deberías estar a salvo durante un tiempo."

# game/beyond the bet/day9dlc.rpy:1399
translate Spanish day9dlc_chatstart_02138ffa:

    # GR "my superiors know your soul is difficult, and as such they should give me a little more leeway."
    GR "mis superiores saben que tu alma es difícil y, por lo tanto, deberían darme un poco más de margen."

# game/beyond the bet/day9dlc.rpy:1402
translate Spanish day9dlc_chatstart_ada437c4:

    # player "What about the whole... uh..."
    player "¿Y qué pasa con lo de... eh..."

# game/beyond the bet/day9dlc.rpy:1405
translate Spanish day9dlc_chatstart_5bfd8b8f:

    # player "Weird memory thing you had?"
    player "¿Lo del recuerdo raro que tuviste?"

# game/beyond the bet/day9dlc.rpy:1406
translate Spanish day9dlc_chatstart_c30211c0_1:

    # GR "i..."
    GR "yo..."

# game/beyond the bet/day9dlc.rpy:1407
translate Spanish day9dlc_chatstart_139eea36:

    # GR "honestly do not know who to talk to or ask about such a thing."
    GR "sinceramente no sé con quién hablar ni a quién preguntar sobre algo así."

# game/beyond the bet/day9dlc.rpy:1408
translate Spanish day9dlc_chatstart_0fcb5f7b:

    # GR "if i speak to the wrong person, the consequences could be dire."
    GR "si hablo con la persona equivocada, las consecuencias podrían ser terribles."

# game/beyond the bet/day9dlc.rpy:1409
translate Spanish day9dlc_chatstart_290841e9:

    # GR "i do have an idea."
    GR "sí tengo una idea."

# game/beyond the bet/day9dlc.rpy:1412
translate Spanish day9dlc_chatstart_11542440:

    # player "You're just full of ideas today."
    player "Hoy estás lleno de ideas."

# game/beyond the bet/day9dlc.rpy:1414
translate Spanish day9dlc_chatstart_0bcb3ac3:

    # player "Go on, tell me about it."
    player "Adelante, cuéntame."

# game/beyond the bet/day9dlc.rpy:1415
translate Spanish day9dlc_chatstart_2cfbaea0:

    # GR "well..."
    GR "bueno..."

# game/beyond the bet/day9dlc.rpy:1416
translate Spanish day9dlc_chatstart_07541744:

    # GR "in the underworld there is a grand... what would you call it?"
    GR "en el inframundo hay una gran... ¿cómo la llamarías?"

# game/beyond the bet/day9dlc.rpy:1417
translate Spanish day9dlc_chatstart_c5f4e9d6:

    # GR "a library, i suppose."
    GR "una biblioteca, supongo."

# game/beyond the bet/day9dlc.rpy:1418
translate Spanish day9dlc_chatstart_6bb4c2da:

    # GR "the library of the lost."
    GR "la biblioteca de los perdidos."

# game/beyond the bet/day9dlc.rpy:1421
translate Spanish day9dlc_chatstart_cd123954:

    # player "How fitting."
    player "Qué apropiado."

# game/beyond the bet/day9dlc.rpy:1423
translate Spanish day9dlc_chatstart_9ccec399:

    # player "An apt name."
    player "Un nombre acertado."

# game/beyond the bet/day9dlc.rpy:1424
translate Spanish day9dlc_chatstart_08402326:

    # GR "all of our history is in there. thousands of years of grim reapers... and more."
    GR "toda nuestra historia está allí. miles de años de parcas... y más."

# game/beyond the bet/day9dlc.rpy:1425
translate Spanish day9dlc_chatstart_f1bf4617:

    # GR "but i would never be able to get clearance to the place."
    GR "pero nunca podría conseguir autorización para entrar."

# game/beyond the bet/day9dlc.rpy:1428
translate Spanish day9dlc_chatstart_9f0484db:

    # player "Who would?"
    player "¿Quién podría?"

# game/beyond the bet/day9dlc.rpy:1429
translate Spanish day9dlc_chatstart_de1903e8:

    # GR "i do not know."
    GR "no lo sé."

# game/beyond the bet/day9dlc.rpy:1430
translate Spanish day9dlc_chatstart_1175b2db:

    # GR "not my boss, nor my bosses' boss."
    GR "ni mi jefe, ni el jefe de mi jefe."

# game/beyond the bet/day9dlc.rpy:1431
translate Spanish day9dlc_chatstart_d4c15cf8:

    # GR "the secrets that are held there are immense."
    GR "los secretos que se guardan allí son inmensos."

# game/beyond the bet/day9dlc.rpy:1432
translate Spanish day9dlc_chatstart_7e651c03:

    # GR "...i would imagine. i have never been there, nor met anyone that has, either."
    GR "...imagino. nunca he estado allí, ni he conocido a nadie que haya estado."

# game/beyond the bet/day9dlc.rpy:1433
translate Spanish day9dlc_chatstart_1f21df34:

    # GR "but if any place holds the answer to what we can do, and the truth of my creation, it would be there."
    GR "pero si algún lugar guarda la respuesta a lo que podemos hacer, y la verdad de mi creación, sería ese."

# game/beyond the bet/day9dlc.rpy:1436
translate Spanish day9dlc_chatstart_7e9bfae2:

    # player "Is it heist time?"
    player "¿Es hora del atraco?"

# game/beyond the bet/day9dlc.rpy:1437
translate Spanish day9dlc_chatstart_8d31bf7d:

    # GR "huh???"
    GR "¿¿¿eh???"

# game/beyond the bet/day9dlc.rpy:1440
translate Spanish day9dlc_chatstart_57812fc9:

    # player "It could be like a spy movie."
    player "Podría ser como una película de espías."

# game/beyond the bet/day9dlc.rpy:1443
translate Spanish day9dlc_chatstart_a7d52f17:

    # player "We'll get onto the roof, then you'll lower me down with a rope!"
    player "¡Subiremos al techo y tú me bajarás con una cuerda!"

# game/beyond the bet/day9dlc.rpy:1446
translate Spanish day9dlc_chatstart_d6bddbf2:

    # player "And then I'll do some cool ass flips over all the lasers."
    player "Y luego haré unas volteretas buenísimas sobre todos los láseres."

# game/beyond the bet/day9dlc.rpy:1447
translate Spanish day9dlc_chatstart_c5e91258:

    # GR "you watch too many movies."
    GR "ves demasiadas películas."

# game/beyond the bet/day9dlc.rpy:1448
translate Spanish day9dlc_chatstart_a0201334:

    # GR "forget the lasers, i would be more worried about the gargoyles."
    GR "olvida los láseres, me preocuparían más las gárgolas."

# game/beyond the bet/day9dlc.rpy:1451
translate Spanish day9dlc_chatstart_f2bef0fd:

    # player "GARGOYLES???"
    player "¿¿¿GÁRGOLAS???"

# game/beyond the bet/day9dlc.rpy:1452
translate Spanish day9dlc_chatstart_99c627ea:

    # GR "yes. they make excellent security guards."
    GR "sí. son excelentes guardias de seguridad."

# game/beyond the bet/day9dlc.rpy:1455
translate Spanish day9dlc_chatstart_86f14166:

    # player "Foiled once again..."
    player "Frustrados una vez más..."

# game/beyond the bet/day9dlc.rpy:1457
translate Spanish day9dlc_chatstart_28bebb3f:

    # player "Dang it..."
    player "Rayos..."

# game/beyond the bet/day9dlc.rpy:1461
translate Spanish day9dlc_chatstart_c226fe23:

    # player "I wonder if we could find someone to let us in?"
    player "Me pregunto si podríamos encontrar a alguien que nos deje entrar."

# game/beyond the bet/day9dlc.rpy:1462
translate Spanish day9dlc_chatstart_cf85785e:

    # GR "like who?"
    GR "¿como quién?"

# game/beyond the bet/day9dlc.rpy:1465
translate Spanish day9dlc_chatstart_f83237d4:

    # player "You're so good at your job, Grimmy."
    player "Eres tan bueno en tu trabajo, Parquita."

# game/beyond the bet/day9dlc.rpy:1468
translate Spanish day9dlc_chatstart_af3fb51e:

    # player "Surely someone would have noticed?"
    player "¿Seguro que alguien se habría dado cuenta?"

# game/beyond the bet/day9dlc.rpy:1471
translate Spanish day9dlc_chatstart_6a5e09b2:

    # player "Maybe we can convince them to let us just take a peek."
    player "Quizás podamos convencerlos de que nos dejen echar un vistazo."

# game/beyond the bet/day9dlc.rpy:1472
translate Spanish day9dlc_chatstart_41ba8f3d:

    # GR "sunshine, i really don't like many people."
    GR "solecito, la verdad es que no me cae bien mucha gente."

# game/beyond the bet/day9dlc.rpy:1473
translate Spanish day9dlc_chatstart_3304ffa9:

    # GR "i am not the type to suck up to my superiors."
    GR "no soy del tipo que adula a sus superiores."

# game/beyond the bet/day9dlc.rpy:1476
translate Spanish day9dlc_chatstart_9f1b6413_1:

    # player "Ah."
    player "Ah."

# game/beyond the bet/day9dlc.rpy:1479
translate Spanish day9dlc_chatstart_ee04492d:

    # player "You're not very liked in the workplace."
    player "No le caes muy bien a la gente en el trabajo."

# game/beyond the bet/day9dlc.rpy:1480
translate Spanish day9dlc_chatstart_91cff787:

    # GR "....right."
    GR "....cierto."

# game/beyond the bet/day9dlc.rpy:1482
translate Spanish day9dlc_chatstart_1785b1df:

    # GR "i tire of typing."
    GR "me canso de escribir."

# game/beyond the bet/day9dlc.rpy:1515
translate Spanish call1_daydlc9_0d38c0cd:

    # GRC "There you are."
    GRC "Ahí estás."

# game/beyond the bet/day9dlc.rpy:1516
translate Spanish call1_daydlc9_780a7fa6:

    # GRC "That's much better."
    GRC "Mucho mejor así."

# game/beyond the bet/day9dlc.rpy:1529
translate Spanish call1_daydlc9_5df5bf7c:

    # GRC "More than I care to admit."
    GRC "Más de lo que me gusta admitir."

# game/beyond the bet/day9dlc.rpy:1531
translate Spanish call1_daydlc9_3893d74d:

    # GRC "Seeing you safe gives me... an odd relief."
    GRC "Verte a salvo me produce... un extraño alivio."

# game/beyond the bet/day9dlc.rpy:1542
translate Spanish call1_daydlc9_79d6ebb2:

    # GRC "A strange... warmness of the chest..."
    GRC "Una extraña... calidez en el pecho..."

# game/beyond the bet/day9dlc.rpy:1544
translate Spanish call1_daydlc9_2f0911b5:

    # GRC "Dear gods, is this a heart I've acquired?"
    GRC "Santos dioses, ¿acaso he adquirido un corazón?"

# game/beyond the bet/day9dlc.rpy:1552
translate Spanish call1_daydlc9_997a6b3e:

    # GRC "Hah!"
    GRC "¡Ja!"

# game/beyond the bet/day9dlc.rpy:1553
translate Spanish call1_daydlc9_6ffd6cfb:

    # GRC "Sunshine, you are an idiot."
    GRC "Solecito, eres [arti_2] idiota."

# game/beyond the bet/day9dlc.rpy:1564
translate Spanish call1_daydlc9_c6d39738:

    # GRC "Fortunately, no one has noticed... I think."
    GRC "Por suerte, nadie lo ha notado... creo."

# game/beyond the bet/day9dlc.rpy:1566
translate Spanish call1_daydlc9_32155b2e:

    # GRC "I hope, I pray."
    GRC "Espero, rezo."

# game/beyond the bet/day9dlc.rpy:1574
translate Spanish call1_daydlc9_2cb764b1:

    # GRC "That's a little out of nowhere."
    GRC "Eso salió de la nada."

# game/beyond the bet/day9dlc.rpy:1578
translate Spanish call1_daydlc9_2eaec8bd:

    # GRC "Yes, well..."
    GRC "Sí, bueno..."

# game/beyond the bet/day9dlc.rpy:1589
translate Spanish call1_daydlc9_6db6e312:

    # GRC "I wasn't afraid of it in the past."
    GRC "Antes no le tenía miedo."

# game/beyond the bet/day9dlc.rpy:1591
translate Spanish call1_daydlc9_5b5bae6c:

    # GRC "I saw countless terrible things happen, and yet I never feared... what they did was of little concern to me."
    GRC "Vi innumerables cosas terribles suceder y, aun así, nunca temí... lo que hicieran me importaba poco."

# game/beyond the bet/day9dlc.rpy:1593
translate Spanish call1_daydlc9_342ccd38:

    # GRC "I suppose I now have a reason to fear them."
    GRC "Supongo que ahora tengo una razón para temerles."

# game/beyond the bet/day9dlc.rpy:1598
translate Spanish call1_daydlc9_13a36a76:

    # GRC "Well..."
    GRC "Bueno..."

# game/beyond the bet/day9dlc.rpy:1600
translate Spanish call1_daydlc9_25ddc080:

    # GRC "I suppose I am scared of myself, in a way."
    GRC "Supongo que me temo a mí mismo, en cierto modo."

# game/beyond the bet/day9dlc.rpy:1602
translate Spanish call1_daydlc9_d153bb19:

    # GRC "Lately I feel as though I do not truly know who I am."
    GRC "Últimamente siento que no sé realmente quién soy."

# game/beyond the bet/day9dlc.rpy:1603
translate Spanish call1_daydlc9_84337016:

    # GRC "Nor where I came from."
    GRC "Ni de dónde vengo."

# game/beyond the bet/day9dlc.rpy:1605
translate Spanish call1_daydlc9_48e97f68:

    # GRC "Things I did not even think of before I met you."
    GRC "Cosas en las que ni siquiera pensaba antes de conocerte."

# game/beyond the bet/day9dlc.rpy:1614
translate Spanish call1_daydlc9_61068345:

    # GRC "Really, it's all your fault and you should feel terrible about it."
    GRC "En serio, es todo culpa tuya y deberías sentirte fatal por ello."

# game/beyond the bet/day9dlc.rpy:1625
translate Spanish call1_daydlc9_9d3101ac:

    # GRC "Ice cold, Sunshine."
    GRC "Qué frialdad, Solecito."

# game/beyond the bet/day9dlc.rpy:1633
translate Spanish call1_daydlc9_79a02e54:

    # GRC "It's a bit of a mouthful."
    GRC "Es un poco largo."

# game/beyond the bet/day9dlc.rpy:1635
translate Spanish call1_daydlc9_bef6ad24:

    # GRC "I think I'll stick with just Sunshine."
    GRC "Creo que me quedo solo con Solecito."

# game/beyond the bet/day9dlc.rpy:1658
translate Spanish call1_daydlc9_54a4fdeb:

    # GRC "...You are a better person than I deserve."
    GRC "...Eres mejor persona de lo que merezco."

# game/beyond the bet/day9dlc.rpy:1660
translate Spanish call1_daydlc9_1e167022:

    # GRC "And that's saying something, because I deserve plenty."
    GRC "Y eso es decir mucho, porque merezco bastante."

# game/beyond the bet/day9dlc.rpy:1671
translate Spanish call1_daydlc9_ed086fa4:

    # GRC "Ah... achoo!"
    GRC "Ah... ¡achís!"

# game/beyond the bet/day9dlc.rpy:1676
translate Spanish call1_daydlc9_31b5b939:

    # GRC "Good question. Maybe I'm allergic to bullshit?"
    GRC "Buena pregunta. ¿Quizás tengo alergia a las tonterías?"

# game/beyond the bet/day9dlc.rpy:1683
translate Spanish call1_daydlc9_db81abb8:

    # GRC "You don't say."
    GRC "No me digas."

# game/beyond the bet/day9dlc.rpy:1686
translate Spanish call1_daydlc9_97cc27de:

    # GRC "What about you, then?"
    GRC "¿Y tú, entonces?"

# game/beyond the bet/day9dlc.rpy:1745
translate Spanish call1_daydlc9_9e2bb48e:

    # GRC "...I'm not going anywhere. Not if I can help it."
    GRC "...No me voy a ninguna parte. No si puedo evitarlo."

# game/beyond the bet/day9dlc.rpy:1746
translate Spanish call1_daydlc9_224d7273:

    # GRC "Now that I have known your light, I cannot even think of going back to the dark."
    GRC "Ahora que he conocido tu luz, ni siquiera puedo pensar en volver a la oscuridad."

# game/beyond the bet/day9dlc.rpy:1766
translate Spanish call1_daydlc9_a335595c:

    # GRC "And you will."
    GRC "Y lo harás."

# game/beyond the bet/day9dlc.rpy:1786
translate Spanish call1_daydlc9_a72dcf20:

    # GRC "If nothing else, you have..."
    GRC "Si nada más, tú has..."

# game/beyond the bet/day9dlc.rpy:1788
translate Spanish call1_daydlc9_742021b3:

    # GRC "Left me better than you found me."
    GRC "Me has dejado mejor de como me encontraste."

# game/beyond the bet/day9dlc.rpy:1803
translate Spanish call1_daydlc9_3ef019a1:

    # GRC "...You're adding another fear to my pile, Sunshine."
    GRC "...Estás añadiendo otro miedo a mi lista, Solecito."

# game/beyond the bet/day9dlc.rpy:1805
translate Spanish call1_daydlc9_fdd42f2c:

    # GRC "I kid. In all honestly, I think you take plenty of risks."
    GRC "Es broma. Con total sinceridad, creo que te arriesgas bastante."

# game/beyond the bet/day9dlc.rpy:1807
translate Spanish call1_daydlc9_5df3abf9:

    # GRC "Just look at the mess we've stuck ourselves in."
    GRC "Mira el lío en el que nos hemos metido."

# game/beyond the bet/day9dlc.rpy:1813
translate Spanish call1_daydlc9_5f838062:

    # GRC "Haa..."
    GRC "Haa..."

# game/beyond the bet/day9dlc.rpy:1818
translate Spanish call1_daydlc9_7762ea19:

    # GRC "I'm annoyed."
    GRC "Estoy molesto."

# game/beyond the bet/day9dlc.rpy:1823
translate Spanish call1_daydlc9_7b2af8f4:

    # GRC "It's time."
    GRC "Es la hora."

# game/beyond the bet/day9dlc.rpy:1827
translate Spanish call1_daydlc9_69f9facd:

    # GRC "No, it's not time for anything."
    GRC "No, no es hora de nada."

# game/beyond the bet/day9dlc.rpy:1837
translate Spanish call1_daydlc9_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:1842
translate Spanish call1_daydlc9_2fa1246e:

    # GRC "No, you fool. No matter how many times you bring it up, it's STILL not possible."
    GRC "No, tont[letra]. No importa cuántas veces lo menciones, sigue SIN ser posible."

# game/beyond the bet/day9dlc.rpy:1843
translate Spanish call1_daydlc9_f2e4f466:

    # GRC "There is no way to have a soul baby!"
    GRC "¡No hay forma de tener un bebé alma!"

# game/beyond the bet/day9dlc.rpy:1844
translate Spanish call1_daydlc9_354bc127:

    # GRC "They don't exist!"
    GRC "¡No existen!"

# game/beyond the bet/day9dlc.rpy:1852
translate Spanish call1_daydlc9_550b3130:

    # GRC "That sounds stupid."
    GRC "Eso suena estúpido."

# game/beyond the bet/day9dlc.rpy:1860
translate Spanish call1_daydlc9_77643055:

    # GRC "Time is what is annoying me."
    GRC "El tiempo es lo que me molesta."

# game/beyond the bet/day9dlc.rpy:1864
translate Spanish call1_daydlc9_d3436057:

    # GRC "It goes by so quickly. What feels like the blink of an eye to someone like me is a lifetime to someone like you."
    GRC "Pasa tan rápido. Lo que para alguien como yo es un parpadeo, para alguien como tú es una vida entera."

# game/beyond the bet/day9dlc.rpy:1866
translate Spanish call1_daydlc9_e34134ac:

    # GRC "It is frustrating."
    GRC "Es frustrante."

# game/beyond the bet/day9dlc.rpy:1868
translate Spanish call1_daydlc9_e421866a:

    # GRC "There is so much I still do not know about you."
    GRC "Hay tantas cosas que aún no sé de ti."

# game/beyond the bet/day9dlc.rpy:1869
translate Spanish call1_daydlc9_a6edfe6b:

    # GRC "Things I wish to know."
    GRC "Cosas que deseo saber."

# game/beyond the bet/day9dlc.rpy:1877
translate Spanish call1_daydlc9_73ea8f82:

    # GRC "Where would I even begin when I desire everything from you?"
    GRC "¿Por dónde empezar cuando deseo todo de ti?"

# game/beyond the bet/day9dlc.rpy:1884
translate Spanish call1_daydlc9_f0598492:

    # GRC "How about..."
    GRC "¿Qué tal...?"

# game/beyond the bet/day9dlc.rpy:1886
translate Spanish call1_daydlc9_73395837:

    # GRC "Your favorite food?"
    GRC "¿Tu comida favorita?"

# game/beyond the bet/day9dlc.rpy:1888
translate Spanish call1_daydlc9_b310aa31:

    # GRC "No. Your favorite guilty pleasure food."
    GRC "No. Tu comida favorita de esas que comes con culpa."

# game/beyond the bet/day9dlc.rpy:1910
translate Spanish call1_daydlc9_76f32119:

    # GRC "What sort of chocolate?"
    GRC "¿Qué tipo de chocolate?"

# game/beyond the bet/day9dlc.rpy:1915
translate Spanish call1_daydlc9_98e8b743:

    # GRC "All chocolate?"
    GRC "¿Todos los chocolates?"

# game/beyond the bet/day9dlc.rpy:1919
translate Spanish call1_daydlc9_11a9e6c7:

    # GRC "Every single one?"
    GRC "¿Absolutamente todos?"

# game/beyond the bet/day9dlc.rpy:1923
translate Spanish call1_daydlc9_82f63da9:

    # GRC "That's a lot of chocolate."
    GRC "Eso es mucho chocolate."

# game/beyond the bet/day9dlc.rpy:1938
translate Spanish call1_daydlc9_37aba6d2:

    # GRC "That was a terrible joke."
    GRC "Ese fue un chiste terrible."

# game/beyond the bet/day9dlc.rpy:1943
translate Spanish call1_daydlc9_f43b159a:

    # GRC "I suppose your choice isn't too bad, however. Cheese is fine enough."
    GRC "Supongo que tu elección no está tan mal, sin embargo. El queso está bastante bien."

# game/beyond the bet/day9dlc.rpy:1954
translate Spanish call1_daydlc9_9d7a5c88:

    # GRC "There's a difference between kinds of cheese?"
    GRC "¿Hay diferencias entre los tipos de queso?"

# game/beyond the bet/day9dlc.rpy:1962
translate Spanish call1_daydlc9_2ff8f588:

    # GRC "That sounds absolutely terrible and I can't think of anything better."
    GRC "Eso suena absolutamente terrible y no se me ocurre nada mejor."

# game/beyond the bet/day9dlc.rpy:1969
translate Spanish call1_daydlc9_b4b73e7f:

    # GRC "You're such a moron."
    GRC "Eres [arti_2] idiota."

# game/beyond the bet/day9dlc.rpy:1977
translate Spanish call1_daydlc9_56382092:

    # GRC "Apart from your stomach."
    GRC "Aparte de tu estómago."

# game/beyond the bet/day9dlc.rpy:1982
translate Spanish call1_daydlc9_3123dedb:

    # GRC "Ah, a noble sacrifice."
    GRC "Ah, un sacrificio noble."

# game/beyond the bet/day9dlc.rpy:1984
translate Spanish call1_daydlc9_a4628d5f:

    # GRC "The world thanks you."
    GRC "El mundo te lo agradece."

# game/beyond the bet/day9dlc.rpy:1991
translate Spanish call1_daydlc9_f59608b4:

    # GRC "Pickles...?"
    GRC "¿Pepinillos...?"

# game/beyond the bet/day9dlc.rpy:1996
translate Spanish call1_daydlc9_3b367026:

    # GRC "I... of all the foods in the world, why pickles?"
    GRC "Yo... de todas las comidas del mundo, ¿por qué pepinillos?"

# game/beyond the bet/day9dlc.rpy:2006
translate Spanish call1_daydlc9_e1e6b4c1:

    # GRC "What..."
    GRC "Qué..."

# game/beyond the bet/day9dlc.rpy:2014
translate Spanish call1_daydlc9_2f382b6c:

    # GRC "WHY would I want that?!"
    GRC "¡¿POR QUÉ habría de querer eso?!"

# game/beyond the bet/day9dlc.rpy:2015
translate Spanish call1_daydlc9_36cc4103:

    # GRC "Why would you WANT to do that?!"
    GRC "¡¿Por qué HABRÍAS de querer hacer eso?!"

# game/beyond the bet/day9dlc.rpy:2023
translate Spanish call1_daydlc9_29558f51:

    # GRC "No, not really."
    GRC "No, no realmente."

# game/beyond the bet/day9dlc.rpy:2025
translate Spanish call1_daydlc9_acedb439:

    # GRC "Why you humans altered cucumbers in such a way, I shall never understand."
    GRC "Por qué ustedes los humanos modificaron los pepinos de esa manera, jamás lo entenderé."

# game/beyond the bet/day9dlc.rpy:2046
translate Spanish call1_daydlc9_4770ec78:

    # GRC "Strawberries... they are quite nice, yes."
    GRC "Las fresas... son bastante buenas, sí."

# game/beyond the bet/day9dlc.rpy:2048
translate Spanish call1_daydlc9_137285ba:

    # GRC "I once visited a strawberry farm, actually."
    GRC "De hecho, una vez visité una granja de fresas."

# game/beyond the bet/day9dlc.rpy:2052
translate Spanish call1_daydlc9_bc62d576:

    # GRC "Yes, the owner sadly passed away."
    GRC "Sí, por desgracia el dueño falleció."

# game/beyond the bet/day9dlc.rpy:2054
translate Spanish call1_daydlc9_17f9af9a:

    # GRC "But his strawberries were very tasty at least."
    GRC "Pero al menos sus fresas eran muy sabrosas."

# game/beyond the bet/day9dlc.rpy:2062
translate Spanish call1_daydlc9_488f8e66:

    # GRC "It comes with the job."
    GRC "Es parte del trabajo."

# game/beyond the bet/day9dlc.rpy:2074
translate Spanish call1_daydlc9_f034338d:

    # GRC "Hmm..."
    GRC "Mmm..."

# game/beyond the bet/day9dlc.rpy:2076
translate Spanish call1_daydlc9_efa14cf0:

    # GRC "I like bread."
    GRC "Me gusta el pan."

# game/beyond the bet/day9dlc.rpy:2082
translate Spanish call1_daydlc9_7cd20502:

    # GRC "Just plain bread."
    GRC "Solo pan sencillo."

# game/beyond the bet/day9dlc.rpy:2083
translate Spanish call1_daydlc9_58c6eaf2:

    # GRC "However, it does taste better when folded in half."
    GRC "Sin embargo, sabe mejor doblado por la mitad."

# game/beyond the bet/day9dlc.rpy:2094
translate Spanish call1_daydlc9_48ca75bf:

    # GRC "Indeed."
    GRC "En efecto."

# game/beyond the bet/day9dlc.rpy:2096
translate Spanish call1_daydlc9_65c42b2e:

    # GRC "It is still inferior to noodles, but it has its perks."
    GRC "Sigue siendo inferior a los fideos, pero tiene sus ventajas."

# game/beyond the bet/day9dlc.rpy:2100
translate Spanish call1_daydlc9_07283614:

    # GRC "Correct."
    GRC "Correcto."

# game/beyond the bet/day9dlc.rpy:2105
translate Spanish call1_daydlc9_31602eeb:

    # GRC "How many times do I have to say yes?"
    GRC "¿Cuántas veces tengo que decir que sí?"

# game/beyond the bet/day9dlc.rpy:2118
translate Spanish call1_daydlc9_2caf724b:

    # GRC "When, and not if?"
    GRC "¿Dices 'cuando' y no 'si'?"

# game/beyond the bet/day9dlc.rpy:2129
translate Spanish call1_daydlc9_2c727339:

    # GRC "Ah, the age old question."
    GRC "Ah, la pregunta de siempre."

# game/beyond the bet/day9dlc.rpy:2133
translate Spanish call1_daydlc9_d9c0c83d:

    # GRC "It is a question as old as time."
    GRC "Es una pregunta tan antigua como el tiempo."

# game/beyond the bet/day9dlc.rpy:2138
translate Spanish call1_daydlc9_7109134f:

    # GRC "If I were not so busy and important, perhaps I would write an essay on this topic."
    GRC "Si no estuviera tan ocupado y fuera tan importante, quizás escribiría un ensayo sobre este tema."

# game/beyond the bet/day9dlc.rpy:2140
translate Spanish call1_daydlc9_616790dd:

    # GRC "There are many good flavors, but only some may claim to be {b}great{/b}."
    GRC "Hay muchos buenos sabores, pero solo algunos pueden presumir de ser {b}geniales{/b}."

# game/beyond the bet/day9dlc.rpy:2146
translate Spanish call1_daydlc9_02890dd0:

    # GRC "Sitting in third place, sweet chilli."
    GRC "En tercer lugar, chile dulce."

# game/beyond the bet/day9dlc.rpy:2153
translate Spanish call1_daydlc9_b5b943f4:

    # GRC "In second, seafood. The milky broth, chewy calamari, and plum vinegar flavor... ah, my mouth is alight just thinking of it."
    GRC "En segundo, mariscos. El caldo lechoso, el calamar masticable y el sabor a vinagre de ciruela... ah, se me enciende la boca solo de pensarlo."

# game/beyond the bet/day9dlc.rpy:2158
translate Spanish call1_daydlc9_952568ff:

    # GRC "It is a figure of speech."
    GRC "Es una figura retórica."

# game/beyond the bet/day9dlc.rpy:2162
translate Spanish call1_daydlc9_4f7b18b0:

    # GRC "And in first place..."
    GRC "Y en primer lugar..."

# game/beyond the bet/day9dlc.rpy:2163
translate Spanish call1_daydlc9_a5c5835d:

    # GRC "Drum roll, please."
    GRC "Redoble de tambores, por favor."

# game/beyond the bet/day9dlc.rpy:2168
translate Spanish call1_daydlc9_81a01d10:

    # GRC "Original."
    GRC "Original."

# game/beyond the bet/day9dlc.rpy:2186
translate Spanish call1_daydlc9_de910531:

    # GRC "There is a reason it is the best selling."
    GRC "Hay una razón por la que es el más vendido."

# game/beyond the bet/day9dlc.rpy:2188
translate Spanish call1_daydlc9_0acd1476:

    # GRC "Nothing can beat the original."
    GRC "Nada puede superar al original."

# game/beyond the bet/day9dlc.rpy:2193
translate Spanish call1_daydlc9_9bb1b6a2:

    # GRC "...Well."
    GRC "...Bueno."

# game/beyond the bet/day9dlc.rpy:2195
translate Spanish call1_daydlc9_8c7482fe:

    # GRC "That would depend on what flavor you like."
    GRC "Eso dependería del sabor que te guste."

# game/beyond the bet/day9dlc.rpy:2196
translate Spanish call1_daydlc9_834f53ec:

    # GRC "For you, I would eat an inferior flavor."
    GRC "Por ti, comería un sabor inferior."

# game/beyond the bet/day9dlc.rpy:2206
translate Spanish call1_daydlc9_b1fe3d9a:

    # GRC "Noodles are inherently romantic."
    GRC "Los fideos son inherentemente románticos."

# game/beyond the bet/day9dlc.rpy:2210
translate Spanish call1_daydlc9_720d74e1:

    # GRC "You see-"
    GRC "Verás-"

# game/beyond the bet/day9dlc.rpy:2224
translate Spanish call1_daydlc9_89ca9d44:

    # GRC "That is a terrible joke and you should feel awful about it."
    GRC "Ese es un chiste terrible y deberías sentirte fatal por eso."

# game/beyond the bet/day9dlc.rpy:2226
translate Spanish call1_daydlc9_33656e42:

    # GRC "I won't even mention that, once again, we are NOT having soulbabies."
    GRC "Ni siquiera mencionaré que, una vez más, NO vamos a tener bebés alma."

# game/beyond the bet/day9dlc.rpy:2231
translate Spanish call1_daydlc9_063f0b42:

    # GRC "They do not!"
    GRC "¡No existen!"

# game/beyond the bet/day9dlc.rpy:2232
translate Spanish call1_daydlc9_c7991b44:

    # GRC "I swear, you-"
    GRC "Lo juro, tú-"

# game/beyond the bet/day9dlc.rpy:2241
translate Spanish call1_daydlc9_78cf4306:

    # GRC "Hm. It is a fine flavor, though it would fall into the 'good' category, not the 'great'."
    GRC "Mm. Es un buen sabor, aunque entraría en la categoría de 'bueno', no de 'genial'."

# game/beyond the bet/day9dlc.rpy:2242
translate Spanish call1_daydlc9_b69ef529:

    # GRC "I suppose my tastebuds are just much more refined than a mortals."
    GRC "Supongo que mis papilas gustativas son mucho más refinadas que las de un mortal."

# game/beyond the bet/day9dlc.rpy:2250
translate Spanish call1_daydlc9_16066a70:

    # GRC "Sarcasm! How lovely."
    GRC "¡Sarcasmo! Qué encantador."

# game/beyond the bet/day9dlc.rpy:2258
translate Spanish call1_daydlc9_284aac10:

    # GRC "And I may or may not have an answer for you."
    GRC "Y puede que tenga o no una respuesta para ti."

# game/beyond the bet/day9dlc.rpy:2268
translate Spanish call1_daydlc9_77161952:

    # GRC "They are not so easily obtained."
    GRC "No son tan fáciles de conseguir."

# game/beyond the bet/day9dlc.rpy:2272
translate Spanish call1_daydlc9_9b48acb8:

    # GRC "Perhaps I will let you hold it, if you ask nicely."
    GRC "Quizás te deje sostenerla, si lo pides amablemente."

# game/beyond the bet/day9dlc.rpy:2276
translate Spanish call1_daydlc9_506100f9:

    # GRC "Those are mere toys - props for mortals who dare to imitate my greatness."
    GRC "Esas son meros juguetes: accesorios para mortales que osan imitar mi grandeza."

# game/beyond the bet/day9dlc.rpy:2277
translate Spanish call1_daydlc9_a6d27e6b:

    # GRC "My scythe is the real deal."
    GRC "Mi guadaña es la auténtica."

# game/beyond the bet/day9dlc.rpy:2279
translate Spanish call1_daydlc9_fdb32c9a:

    # GRC "You will not find another like mine in existence."
    GRC "No encontrarás otra como la mía en la existencia."

# game/beyond the bet/day9dlc.rpy:2285
translate Spanish call1_daydlc9_84997c42:

    # GRC "When a reaper is created, their scythe is made from a part of their soul."
    GRC "Cuando se crea a una parca, su guadaña se hace con una parte de su alma."

# game/beyond the bet/day9dlc.rpy:2287
translate Spanish call1_daydlc9_a757aaaf:

    # GRC "I do not know the specifics. I believe it to be a closely guarded secret."
    GRC "No sé los detalles. Creo que es un secreto muy bien guardado."

# game/beyond the bet/day9dlc.rpy:2288
translate Spanish call1_daydlc9_a12cdf74:

    # GRC "So while my scythe is not strictly a part of my body, it is created from a small piece of me."
    GRC "Así que, aunque mi guadaña no es estrictamente una parte de mi cuerpo, está creada a partir de un pedacito de mí."

# game/beyond the bet/day9dlc.rpy:2296
translate Spanish call1_daydlc9_f02e71de:

    # GRC "Unfortunately, they do not come in mortal."
    GRC "Por desgracia, no vienen en versión mortal."

# game/beyond the bet/day9dlc.rpy:2307
translate Spanish call1_daydlc9_89f76fd7:

    # GRC "I hardly think you—"
    GRC "Apenas creo que tú—"

# game/beyond the bet/day9dlc.rpy:2311
translate Spanish call1_daydlc9_1595ac1a:

    # GRC "Hopefully I do what?"
    GRC "¿Ojalá yo qué?"

# game/beyond the bet/day9dlc.rpy:2317
translate Spanish call1_daydlc9_9467829c:

    # GRC "....."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:2319
translate Spanish call1_daydlc9_0b6c2529:

    # GRC ".............."
    GRC ".............."

# game/beyond the bet/day9dlc.rpy:2321
translate Spanish call1_daydlc9_1a9f5e07:

    # GRC "What are you... listen to the filth you spew with such ease!"
    GRC "¡Qué... escucha las inmundicias que sueltas con tanta facilidad!"

# game/beyond the bet/day9dlc.rpy:2322
translate Spanish call1_daydlc9_a9b4909a:

    # GRC "I swear, you—"
    GRC "Lo juro, tú—"

# game/beyond the bet/day9dlc.rpy:2339
translate Spanish chat3_day9dlc_d41d8cd9:

    # nvl clear
    nvl clear

# game/beyond the bet/day9dlc.rpy:2354
translate Spanish chat3_day9dlc_0877f0e7:

    # player "What the..."
    player "Qué demo..."

# game/beyond the bet/day9dlc.rpy:2359
translate Spanish chat3_day9dlc_db474e30:

    # player "Casper, the call disconnected!"
    player "¡Casper, la llamada se desconectó!"

# game/beyond the bet/day9dlc.rpy:2362
translate Spanish chat3_day9dlc_f5da3fed:

    # player "Why is it RED?"
    player "¿POR QUÉ está en ROJO?"

# game/beyond the bet/day9dlc.rpy:2364
translate Spanish chat3_day9dlc_9e026024:

    # player "Something is wrong with your app, Grimmy..."
    player "Algo le pasa a tu aplicación, Parquita..."

# game/beyond the bet/day9dlc.rpy:2367
translate Spanish chat3_day9dlc_6db9cf6a:

    # player "Wait, did you hang up on me?"
    player "Espera, ¿me colgaste?"

# game/beyond the bet/day9dlc.rpy:2370
translate Spanish chat3_day9dlc_9cf596de:

    # player "Hellloooo?"
    player "¿¿Holaaaa??"

# game/beyond the bet/day9dlc.rpy:2373
translate Spanish chat3_day9dlc_ecf16999:

    # player "Casper?"
    player "¿Casper?"

# game/beyond the bet/day9dlc.rpy:2374
translate Spanish chat3_day9dlc_3868ba1d:

    # O "Hello, 'Sunshine'."
    O "Hola, 'Solecito'."

# game/beyond the bet/day9dlc.rpy:2377
translate Spanish chat3_day9dlc_05cf1b99:

    # player "???"
    player "???"

# game/beyond the bet/day9dlc.rpy:2380
translate Spanish chat3_day9dlc_ecf16999_1:

    # player "Casper?"
    player "¿Casper?"

# game/beyond the bet/day9dlc.rpy:2381
translate Spanish chat3_day9dlc_1f7abed7:

    # O "Unfortunately, 'Casper' couldn't make it. What a shame."
    O "Por desgracia, 'Casper' no pudo venir. Qué lástima."

# game/beyond the bet/day9dlc.rpy:2382
translate Spanish chat3_day9dlc_04c4bf72:

    # O "Instead it's just you and me."
    O "En su lugar, solo estamos tú y yo."

# game/beyond the bet/day9dlc.rpy:2385
translate Spanish chat3_day9dlc_4a66f4b1:

    # player "Who are you?"
    player "¿Quién eres?"

# game/beyond the bet/day9dlc.rpy:2386
translate Spanish chat3_day9dlc_5d68ebdc:

    # O "Who I am is not important."
    O "Quién soy no es importante."

# game/beyond the bet/day9dlc.rpy:2387
translate Spanish chat3_day9dlc_210cad09:

    # O "I'm far more interested in you."
    O "Me interesas mucho más tú."

# game/beyond the bet/day9dlc.rpy:2388
translate Spanish chat3_day9dlc_27d439cd:

    # O "[playerfirstname] [playerlastname], the keeper of an incredibly rare soul."
    O "[playerfirstname] [playerlastname], dueñ[letra] de un alma increíblemente rara."

# game/beyond the bet/day9dlc.rpy:2389
translate Spanish chat3_day9dlc_37551ec9:

    # O "Sadly, that soul no longer belongs to you."
    O "Lamentablemente, esa alma ya no te pertenece."

# game/beyond the bet/day9dlc.rpy:2390
translate Spanish chat3_day9dlc_66b6e2bb:

    # O "My organization doesn't appreciate those who withold their property."
    O "Mi organización no aprecia a quienes retienen su propiedad."

# game/beyond the bet/day9dlc.rpy:2393
translate Spanish chat3_day9dlc_ae33e023:

    # player "You're a... Grim Reaper?"
    player "¿Eres... una Parca?"

# game/beyond the bet/day9dlc.rpy:2394
translate Spanish chat3_day9dlc_4abfd867:

    # O "I am Death."
    O "Soy la Muerte."

# game/beyond the bet/day9dlc.rpy:2395
translate Spanish chat3_day9dlc_6ddaf134:

    # O "The one you call Casper has been infected with mortal desires, and now must face the consequences."
    O "Aquel al que llamas Casper se ha contagiado de deseos mortales, y ahora debe afrontar las consecuencias."

# game/beyond the bet/day9dlc.rpy:2396
translate Spanish chat3_day9dlc_b5ba1975:

    # O "As will you."
    O "Al igual que tú."

# game/beyond the bet/day9dlc.rpy:2399
translate Spanish chat3_day9dlc_ed31f512:

    # player "You think you can just threaten me?"
    player "¿Crees que puedes simplemente amenazarme?"

# game/beyond the bet/day9dlc.rpy:2400
translate Spanish chat3_day9dlc_47933aa2:

    # O "I know I can, and these are not threats, but promises."
    O "Sé que puedo, y esto no son amenazas, sino promesas."

# game/beyond the bet/day9dlc.rpy:2402
translate Spanish chat3_day9dlc_c3a26357:

    # player "Why are you doing this?"
    player "¿Por qué haces esto?"

# game/beyond the bet/day9dlc.rpy:2403
translate Spanish chat3_day9dlc_66163ba5:

    # O "Because I take my role in this world seriously."
    O "Porque me tomo en serio mi papel en este mundo."

# game/beyond the bet/day9dlc.rpy:2404
translate Spanish chat3_day9dlc_82dcd60d:

    # O "Perhaps you think me unkind?"
    O "¿Quizás piensas que soy poco amable?"

# game/beyond the bet/day9dlc.rpy:2405
translate Spanish chat3_day9dlc_17e13254:

    # O "Then you would be correct."
    O "Entonces tendrías razón."

# game/beyond the bet/day9dlc.rpy:2406
translate Spanish chat3_day9dlc_c6abe14b:

    # O "We are not kind, but we are just."
    O "No somos amables, pero somos justos."

# game/beyond the bet/day9dlc.rpy:2407
translate Spanish chat3_day9dlc_e4a4bdba:

    # O "I will give you one final chance to reconsider."
    O "Te daré una última oportunidad para que lo reconsideres."

# game/beyond the bet/day9dlc.rpy:2408
translate Spanish chat3_day9dlc_b5c63ff1:

    # O "Come with me, and I promise you will face a quick end."
    O "Ven conmigo y te prometo que tu final será rápido."

# game/beyond the bet/day9dlc.rpy:2412
translate Spanish chat3_day9dlc_82596b83:

    # player "I'll never bow down to your system."
    player "Jamás me someteré a tu sistema."

# game/beyond the bet/day9dlc.rpy:2413
translate Spanish chat3_day9dlc_0a3390a1:

    # O "Without 'my system', the world would collapse."
    O "Sin 'mi sistema', el mundo se derrumbaría."

# game/beyond the bet/day9dlc.rpy:2414
translate Spanish chat3_day9dlc_92261e7c:

    # O "Whether you like it or not."
    O "Te guste o no."

# game/beyond the bet/day9dlc.rpy:2418
translate Spanish chat3_day9dlc_77ea6b70:

    # player "I won't let you take our future!"
    player "¡No dejaré que te lleves nuestro futuro!"

# game/beyond the bet/day9dlc.rpy:2419
translate Spanish chat3_day9dlc_27f301ee:

    # O "You have no future."
    O "No tienes futuro."

# game/beyond the bet/day9dlc.rpy:2420
translate Spanish chat3_day9dlc_7f2b1d96:

    # O "You delude yourself into thinking otherwise."
    O "Te engañas a ti mism[letra] creyendo lo contrario."

# game/beyond the bet/day9dlc.rpy:2424
translate Spanish chat3_day9dlc_f5b49b43:

    # player "...If I do, will you let Casper go?"
    player "...Si lo hago, ¿dejarás ir a Casper?"

# game/beyond the bet/day9dlc.rpy:2425
translate Spanish chat3_day9dlc_5e9b2461:

    # O "Perhaps."
    O "Quizás."

# game/beyond the bet/day9dlc.rpy:2426
translate Spanish chat3_day9dlc_acbb217d:

    # O "That will depend on you."
    O "Eso dependerá de ti."

# game/beyond the bet/day9dlc.rpy:2430
translate Spanish chat3_day9dlc_163cf589:

    # player "I won't do anything for a 'perhaps'."
    player "No haré nada por un 'quizás'."

# game/beyond the bet/day9dlc.rpy:2432
translate Spanish chat3_day9dlc_c0b1b5f6:

    # O "You will see in time just how ill-thought-out your decision is, 'Sunshine'."
    O "Con el tiempo verás lo desacertada que fue tu decisión, 'Solecito'."

# game/beyond the bet/day9dlc.rpy:2433
translate Spanish chat3_day9dlc_f5dfd056:

    # O "Lock your door and your windows if you'd like, but I'll be there soon enough."
    O "Cierra con llave la puerta y las ventanas si quieres, pero no tardaré en llegar."

# game/beyond the bet/day9dlc.rpy:2434
translate Spanish chat3_day9dlc_212e8027:

    # O "Goodbye."
    O "Adiós."

# game/beyond the bet/day9dlc.rpy:2437
translate Spanish chat3_day9dlc_137f242c:

    # player "WAIT!"
    player "¡ESPERA!"

# game/beyond the bet/day9dlc.rpy:2440
translate Spanish chat3_day9dlc_bb23ee73:

    # player "Please, just leave Casper alone!"
    player "¡Por favor, deja a Casper en paz!"

# game/beyond the bet/day9dlc.rpy:2442
translate Spanish chat3_day9dlc_830608c7:

    # player "Just leave us alone!"
    player "¡Déjanos en paz!"

# game/beyond the bet/day9dlc.rpy:2464
translate Spanish day9afterother_c6b16748:

    # "{i}You shut down your computer, then back away from your desk before noticing an envelope sitting right next to your now closed laptop.{/i}"
    "{i}Apagas la computadora y te alejas del escritorio, pero entonces notas un sobre justo al lado de tu computadora, ahora apagada.{/i}"

# game/beyond the bet/day9dlc.rpy:2465
translate Spanish day9afterother_f99b6a25:

    # "{i}When did that get there?{/i}"
    "{i}¿En qué momento apareció ahí?{/i}"

# game/beyond the bet/day9dlc.rpy:2466
translate Spanish day9afterother_4465a49a:

    # "{i}It's black with a red seal on it, which you carefully open.{/i}"
    "{i}Es negro y tiene un sello rojo que abres con cuidado.{/i}"

# game/beyond the bet/day9dlc.rpy:2467
translate Spanish day9afterother_c159da0d:

    # "{i}You find two things inside - a letter, and a keycard.{/i}"
    "{i}Dentro encuentras dos cosas: una carta y una tarjeta de acceso.{/i}"

# game/beyond the bet/day9dlc.rpy:2468
translate Spanish day9afterother_15ca0258:

    # "{i}'Dearest [playerfirstname],'{/i}"
    "{i}'Querid[letra] [playerfirstname],'{/i}"

# game/beyond the bet/day9dlc.rpy:2469
translate Spanish day9afterother_2ad2cec2:

    # "{i}'Would you like to know the truth?'{/i}"
    "{i}'¿Te gustaría conocer la verdad?'{/i}"

# game/beyond the bet/day9dlc.rpy:2470
translate Spanish day9afterother_cc552807:

    # "{i}'Then come. Alone.'{/i}"
    "{i}'Entonces ven. A solas.'{/i}"

# game/beyond the bet/day9dlc.rpy:2471
translate Spanish day9afterother_d198021f:

    # "{i}There's no name at the bottom of the letter.{/i}"
    "{i}La carta no tiene ningún nombre al final.{/i}"

# game/beyond the bet/day9dlc.rpy:2472
translate Spanish day9afterother_adc9e315:

    # "{i}Your eyes go to your door, and you lock it anyway, despite what the stranger told you.{/i}"
    "{i}Miras hacia la puerta y, aun así, le echas el cerrojo, pese a lo que te dijo aquel desconocido.{/i}"

# game/beyond the bet/day9dlc.rpy:2474
translate Spanish day9afterother_7f29dd89:

    # "{i}You've moved to your window when you hear a knock at the door.{/i}"
    "{i}Te acercas a la ventana cuando oyes que llaman a la puerta.{/i}"

# game/beyond the bet/day9dlc.rpy:2482
translate Spanish day9afterother_a20034cd:

    # "{i}The knocking continues.{/i}"
    "{i}Los golpes en la puerta continúan.{/i}"

# game/beyond the bet/day9dlc.rpy:2484
translate Spanish day9afterother_1d95e34d:

    # "{i}And again, a little louder.{/i}"
    "{i}Vuelven a llamar, esta vez un poco más fuerte.{/i}"

# game/beyond the bet/day9dlc.rpy:2485
translate Spanish day9afterother_f3f3effe:

    # GRC "Oi, Sunshine!"
    GRC "¡Oye, Solecito!"

# game/beyond the bet/day9dlc.rpy:2492
translate Spanish day9afterother_0bb3ca31:

    # GRC "Who else has such a handsome, unforgettable voice?"
    GRC "¿Quién más tiene una voz tan atractiva e inolvidable?"

# game/beyond the bet/day9dlc.rpy:2499
translate Spanish day9afterother_f7507b35:

    # GRC "What?"
    GRC "¿Qué?"

# game/beyond the bet/day9dlc.rpy:2503
translate Spanish day9afterother_eb985eca:

    # GRC "Azrael, of course. Lord Azrael the Great, if you want to get technical."
    GRC "Azrael, por supuesto. Lord Azrael el Grande, si quieres ser técnic[letra]."

# game/beyond the bet/day9dlc.rpy:2510
translate Spanish day9afterother_aa67501b:

    # "{i}You open the door, and there looking slighty windswept is the one and only Casper.{/i}" id day9afterother_aa67501b
    "{i}Abres la puerta, y allí, ligeramente despeinado por el viento, está el único e inigualable Casper.{/i}" id day9afterother_aa67501b

# game/beyond the bet/day9dlc.rpy:2513
translate Spanish day9afterother_0528b371:

    # GRC "Sorry, I..."
    GRC "Perdón, yo..."

# game/beyond the bet/day9dlc.rpy:2514
translate Spanish day9afterother_9bf497f4:

    # GRC "My app was playing up, so I just wanted to make sure you were okay-"
    GRC "Mi aplicación fallaba, así que solo quería asegurarme de que estabas bien-"

# game/beyond the bet/day9dlc.rpy:2518
translate Spanish day9afterother_1861830e:

    # "{i}You grab him by the arm and pull him inside, then lock the door behind the both of you.{/i}"
    "{i}Lo agarras del brazo y lo metes dentro, luego cierras la puerta con llave tras los dos.{/i}"

# game/beyond the bet/day9dlc.rpy:2523
translate Spanish day9afterother_d85a09bf:

    # GRC "Someone else?"
    GRC "¿Alguien más?"

# game/beyond the bet/day9dlc.rpy:2527
translate Spanish day9afterother_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:2529
translate Spanish day9afterother_dccd5be3:

    # GRC "...It is not safe to be here."
    GRC "...No es seguro estar aquí."

# game/beyond the bet/day9dlc.rpy:2530
translate Spanish day9afterother_6bb44114:

    # GRC "I was right to come."
    GRC "Hice bien en venir."

# game/beyond the bet/day9dlc.rpy:2537
translate Spanish day9afterother_e97eb176:

    # GRC "We have to leave."
    GRC "Tenemos que irnos."

# game/beyond the bet/day9dlc.rpy:2539
translate Spanish day9afterother_73f0ecce:

    # GRC "I must take you somewhere safe."
    GRC "Debo llevarte a un lugar seguro."

# game/beyond the bet/day9dlc.rpy:2545
translate Spanish day9afterother_64a4d4f6:

    # GRC "...Reapers can track anyone easily throughout your realm, but..."
    GRC "...Las parcas pueden rastrear a cualquiera con facilidad por tu reino, pero..."

# game/beyond the bet/day9dlc.rpy:2550
translate Spanish day9afterother_97d0cac1:

    # GRC "I have a terrible idea."
    GRC "Tengo una pésima idea."

# game/beyond the bet/day9dlc.rpy:2557
translate Spanish day9afterother_a8cc8e4c:

    # GRC "...I can take you to my place."
    GRC "...Puedo llevarte a mi casa."

# game/beyond the bet/day9dlc.rpy:2564
translate Spanish day9afterother_7c8077e1:

    # GRC "Wha... no! I don't mean it like... ugh..."
    GRC "¡Qu... no! No lo digo como... ugh..."

# game/beyond the bet/day9dlc.rpy:2566
translate Spanish day9afterother_ee5ea3f3:

    # GRC "You will not be tracked so easily there, and I imagine it is the last place they would expect you."
    GRC "Allí no te rastrearán tan fácilmente, y me imagino que es el último lugar donde esperarían encontrarte."

# game/beyond the bet/day9dlc.rpy:2570
translate Spanish day9afterother_bfd380c3:

    # GRC "I can take you first, then come back for your beast."
    GRC "Puedo llevarte primero a ti y luego volver por tu bestia."

# game/beyond the bet/day9dlc.rpy:2582
translate Spanish day9afterother_461abe55:

    # "{i}You grab a duffle bag and stuff it with some essentials - including the letter and keycard you were somehow given.{/i}"
    "{i}Agarras un bolso de viaje y lo llenas con algunas cosas esenciales, incluida la carta y la tarjeta de acceso que, de alguna manera, llegaron a tus manos.{/i}"

# game/beyond the bet/day9dlc.rpy:2583
translate Spanish day9afterother_842ac83d:

    # "{i}Every now and then you hear a strange sound and jump, but nothing is there.{/i}"
    "{i}De vez en cuando oyes un ruido extraño y das un respingo, pero no hay nada.{/i}"

# game/beyond the bet/day9dlc.rpy:2596
translate Spanish day9afterother_5cd7fc8a:

    # GRC "Were the circumstances different, I would rather never take you to such a place, but..."
    GRC "Si las circunstancias fueran distintas, preferiría no llevarte nunca a un lugar así, pero..."

# game/beyond the bet/day9dlc.rpy:2598
translate Spanish day9afterother_935e79cc:

    # GRC "Well, we should go quickly."
    GRC "Bueno, deberíamos irnos rápido."

# game/beyond the bet/day9dlc.rpy:2603
translate Spanish day9afterother_22926687:

    # GRC "We fly, obviously."
    GRC "Volamos, obviamente."

# game/beyond the bet/day9dlc.rpy:2608
translate Spanish day9afterother_0cdbabba:

    # "{i}You watch as Casper pulls open the window, then steps out as if there were something to step out onto.{/i}"
    "{i}Ves cómo Casper abre la ventana y luego sale como si hubiera un suelo donde apoyar los pies.{/i}"

# game/beyond the bet/day9dlc.rpy:2609
translate Spanish day9afterother_953be0c1:

    # "{i}He reaches his hand back in your window.{/i}"
    "{i}Vuelve a extender la mano hacia el interior de tu ventana.{/i}"

# game/beyond the bet/day9dlc.rpy:2614
translate Spanish day9afterother_b2742a6f:

    # GRC "Shut up."
    GRC "Cállate."

# game/beyond the bet/day9dlc.rpy:2628
translate Spanish day9afterother_3e67dfe0:

    # "{i}You take his hand, and step out onto the tops of his shoes.{/i}" id day9afterother_3e67dfe0
    "{i}Tomas su mano y apoyas los pies sobre sus zapatos.{/i}" id day9afterother_3e67dfe0

# game/beyond the bet/day9dlc.rpy:2637
translate Spanish day9afterother_631e3a01:

    # GRC "Maybe you're just freakishly tall."
    GRC "Quizás lo que pasa es que tú eres descomunalmente alt[letra]."

# game/beyond the bet/day9dlc.rpy:2644
translate Spanish day9afterother_05f6fae3:

    # GRC "I... have never been knighted, so you must be talking about someone else."
    GRC "Yo... nunca he sido nombrado caballero, así que debes de estar hablando de otra persona."

# game/beyond the bet/day9dlc.rpy:2649
translate Spanish day9afterother_935fb5b1:

    # GRC "Things change."
    GRC "Las cosas cambian."

# game/beyond the bet/day9dlc.rpy:2651
translate Spanish day9afterother_572141f8:

    # "{i}You nearly cry out when Casper moves, shifting you into his arms as the two of you start drifting through the night sky, like a pair of shooting stars.{/i}"
    "{i}Estás a punto de gritar cuando Casper se mueve y te acomoda entre sus brazos. Entonces, ambos comienzan a flotar por el cielo nocturno, como un par de estrellas fugaces.{/i}"

# game/beyond the bet/day9dlc.rpy:2652
translate Spanish day9afterother_f617a176:

    # "{i}It's a strangely freeing feeling, flying. You'd think you'd feel fear, or trepidation, but instead you just feel... in awe.{/i}"
    "{i}Volar es una sensación extrañamente liberadora. Pensarías que sentirías miedo o inquietud, pero, en cambio, solo sientes... asombro.{/i}"

# game/beyond the bet/day9dlc.rpy:2653
translate Spanish day9afterother_0365bc50:

    # "{i}The world goes on below you - lights, and buildings, and streets, and cars. It all seems so small.{/i}"
    "{i}El mundo se extiende bajo tus pies: luces, edificios, calles y autos. Todo parece tan pequeño.{/i}"

# game/beyond the bet/day9dlc.rpy:2660
translate Spanish day9afterother_37ffaf0d:

    # GRC "Us? No, not at all."
    GRC "¿A nosotros? No, para nada."

# game/beyond the bet/day9dlc.rpy:2665
translate Spanish day9afterother_92d6929f:

    # GRC "They would see you hanging onto a bird."
    GRC "Verían cómo te aferras a un pájaro."

# game/beyond the bet/day9dlc.rpy:2673
translate Spanish day9afterother_65fa306c:

    # GRC "True, but it will be hilarious."
    GRC "Cierto, pero será hilarante."

# game/beyond the bet/day9dlc.rpy:2677
translate Spanish day9afterother_5b1b33cb:

    # "{i}Whatever response you're about to call out to Casper is lost to the void as darkness consumes the two of you.{/i}"
    "{i}Cualquier respuesta que estés a punto de gritarle a Casper se pierde en el vacío cuando la oscuridad los envuelve a ambos.{/i}"

# game/beyond the bet/day9dlc.rpy:2678
translate Spanish day9afterother_e8287bba:

    # "{i}Your stomach drops as if you were falling.{/i}" id day9afterother_e8287bba
    "{i}Sientes un vuelco en el estómago, como si estuvieras cayendo.{/i}" id day9afterother_e8287bba

# game/beyond the bet/day9dlc.rpy:2680
translate Spanish day9afterother_4a824199:

    # "{i}Then, it's gone, and you're standing in a place you've only ever seen on your laptop screen.{/i}"
    "{i}Entonces, todo desaparece y te encuentras en un lugar que hasta ahora solo habías visto en la pantalla de tu computadora.{/i}"

# game/beyond the bet/day9dlc.rpy:2696
translate Spanish day9afterother_72492d44:

    # "{i}Casper gently settles your feet to the floor, but you can't help but notice his arms stay around you almost protectively.{/i}"
    "{i}Casper te baja suavemente hasta que tus pies tocan el suelo, pero no puedes evitar notar que mantiene los brazos alrededor de ti, casi como si quisiera protegerte.{/i}"

# game/beyond the bet/day9dlc.rpy:2698
translate Spanish day9afterother_d0532ef0:

    # GRC "I would say welcome, but I hardly think it would be appropriate considering the circumstances..."
    GRC "Te daría la bienvenida, pero no creo que sea lo más apropiado dadas las circunstancias..."

# game/beyond the bet/day9dlc.rpy:2700
translate Spanish day9afterother_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:2702
translate Spanish day9afterother_f8ec4e22:

    # GRC "I have to admit seeing you standing here..."
    GRC "Debo admitir que verte aquí..."

# game/beyond the bet/day9dlc.rpy:2703
translate Spanish day9afterother_8351daca:

    # GRC "In my space."
    GRC "En mi espacio."

# game/beyond the bet/day9dlc.rpy:2704
translate Spanish day9afterother_aebb00f0:

    # GRC "I... find myself enjoying the sight."
    GRC "Yo... no puedo evitar disfrutar de tenerte aquí."

# game/beyond the bet/day9dlc.rpy:2706
translate Spanish day9afterother_47d40c13:

    # GRC "While simultaneously wishing you were anywhere else."
    GRC "Aunque, al mismo tiempo, desearía que estuvieras en cualquier otro lugar."

# game/beyond the bet/day9dlc.rpy:2707
translate Spanish day9afterother_f6075a0b:

    # "{i}You watch Casper fiddle with his hair, worry on his face.{/i}"
    "{i}Ves a Casper juguetear con su cabello, con expresión preocupada.{/i}"

# game/beyond the bet/day9dlc.rpy:2710
translate Spanish day9afterother_34bd562a:

    # "{i}Only when your eyes meet does he smile again, strained as it is.{/i}"
    "{i}Solo cuando sus ojos se encuentran con los tuyos vuelve a sonreír, aunque su sonrisa parece forzada.{/i}"

# game/beyond the bet/day9dlc.rpy:2714
translate Spanish day9afterother_22618ebd:

    # GRC "Terrified, honestly."
    GRC "Aterrado, sinceramente."

# game/beyond the bet/day9dlc.rpy:2717
translate Spanish day9afterother_57e3e2b6:

    # GRC "Yes, and no."
    GRC "Sí, y no."

# game/beyond the bet/day9dlc.rpy:2719
translate Spanish day9afterother_a895ae41:

    # GRC "I love being with you, and yet I hate it, too."
    GRC "Me encanta estar contigo, y sin embargo también lo odio."

# game/beyond the bet/day9dlc.rpy:2720
translate Spanish day9afterother_b85111db:

    # GRC "What I would give to just have you be safe..."
    GRC "Lo que daría por que simplemente estuvieras a salvo..."

# game/beyond the bet/day9dlc.rpy:2724
translate Spanish day9afterother_ff4253ea:

    # GRC "I hope so."
    GRC "Eso espero."

# game/beyond the bet/day9dlc.rpy:2726
translate Spanish day9afterother_293ee8b2:

    # GRC "But there will always come a time where things cannot be figured out, Sunshine."
    GRC "Pero siempre llegará un momento en que las cosas no se puedan resolver, Solecito."

# game/beyond the bet/day9dlc.rpy:2728
translate Spanish day9afterother_1aceab9f:

    # GRC "Everything comes to an end eventually."
    GRC "Todo llega a su fin tarde o temprano."

# game/beyond the bet/day9dlc.rpy:2730
translate Spanish day9afterother_008afe10_2:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:2732
translate Spanish day9afterother_47f84ea1:

    # GRC "I... feel like I'm falling."
    GRC "Yo... siento que estoy cayendo."

# game/beyond the bet/day9dlc.rpy:2733
translate Spanish day9afterother_52fd63b6:

    # GRC "Even now, with my feet on solid ground."
    GRC "Incluso ahora, con los pies en tierra firme."

# game/beyond the bet/day9dlc.rpy:2741
translate Spanish day9afterother_740ac309:

    # GRC "Making jokes at inappropriate moments?"
    GRC "¿Hacer bromas en momentos inapropiados?"

# game/beyond the bet/day9dlc.rpy:2758
translate Spanish day9afterother_a482e185:

    # GRC "Ha..."
    GRC "Ah..."

# game/beyond the bet/day9dlc.rpy:2759
translate Spanish day9afterother_5e4d3376:

    # GRC "Perhaps that stubborn streak of yours I despised for so long is a good thing, after all."
    GRC "Quizás esa terquedad tuya que despreciaba desde hacía tanto tiempo sea algo bueno, después de todo."

# game/beyond the bet/day9dlc.rpy:2766
translate Spanish day9afterother_6d484d1b:

    # GRC "It has... grown on me."
    GRC "Con el tiempo... ha terminado gustándome."

# game/beyond the bet/day9dlc.rpy:2771
translate Spanish day9afterother_51a288e8:

    # GRC "Like nothing else."
    GRC "Como nadie más."

# game/beyond the bet/day9dlc.rpy:2782
translate Spanish day9afterother_b47c080b:

    # GRC "I doubt it would keep us safe for long..."
    GRC "Dudo que eso nos mantenga a salvo por mucho tiempo..."

# game/beyond the bet/day9dlc.rpy:2784
translate Spanish day9afterother_22c05be4:

    # GRC "Though, the idea does sound appealing."
    GRC "Aunque, la idea suena atractiva."

# game/beyond the bet/day9dlc.rpy:2788
translate Spanish day9afterother_bb01a410:

    # GRC "Staying inside forever with you."
    GRC "Quedarme dentro para siempre contigo."

# game/beyond the bet/day9dlc.rpy:2792
translate Spanish day9afterother_1ca15c2a:

    # GRC "Now you're tempting me."
    GRC "Ahora me estás tentando."

# game/beyond the bet/day9dlc.rpy:2794
translate Spanish day9afterother_4db57177:

    # GRC "Alas, no. We need a more permanent solution."
    GRC "Por desgracia, no. Necesitamos una solución más permanente."

# game/beyond the bet/day9dlc.rpy:2802
translate Spanish day9afterother_0b12ed27:

    # GRC "What, run away?"
    GRC "¿Qué, huir?"

# game/beyond the bet/day9dlc.rpy:2810
translate Spanish day9afterother_6a9e9ec1:

    # GRC "It may come to that..."
    GRC "Puede que se llegue a eso..."

# game/beyond the bet/day9dlc.rpy:2811
translate Spanish day9afterother_9871d934:

    # GRC "But it would be setting us up for a lifetime of being chased."
    GRC "Pero nos condenaría a una vida entera de ser perseguidos."

# game/beyond the bet/day9dlc.rpy:2812
translate Spanish day9afterother_771bb7a5:

    # GRC "I hope to find something more permanent..."
    GRC "Espero encontrar algo más permanente..."

# game/beyond the bet/day9dlc.rpy:2817
translate Spanish day9afterother_8c2662a7:

    # GRC "Ah..."
    GRC "Ah..."

# game/beyond the bet/day9dlc.rpy:2830
translate Spanish day9afterother_0f740ee6:

    # GRC "I would... like that."
    GRC "Me... gustaría eso."

# game/beyond the bet/day9dlc.rpy:2831
translate Spanish day9afterother_7486251d:

    # GRC "Let me sort this out. I will find a solution."
    GRC "Déjame resolver esto. Encontraré una solución."

# game/beyond the bet/day9dlc.rpy:2834
translate Spanish day9afterother_40b2b884:

    # GRC "But putting aside anything else, you should rest. Your body is likely tired after travelling across realms."
    GRC "Pero dejando todo lo demás de lado, deberías descansar. Tu cuerpo probablemente esté cansado tras viajar entre reinos."

# game/beyond the bet/day9dlc.rpy:2839
translate Spanish day9afterother_8b3f4226:

    # GRC "I will be back."
    GRC "Volveré."

# game/beyond the bet/day9dlc.rpy:2849
translate Spanish day9afterother_c31e6b30:

    # GRC "...Well, how could I say no to that?" id day9afterother_c31e6b30
    GRC "...Bueno, ¿cómo podría decir que no a eso?" id day9afterother_c31e6b30

# game/beyond the bet/day9dlc.rpy:2860
translate Spanish day9sfwnot_eeb8b5cf:

    # center_text "You pull Casper by the hand towards his bed, your eyes sleepy."
    center_text "Tomas a Casper de la mano y lo llevas hacia su cama, con los ojos cargados de sueño."

# game/beyond the bet/day9dlc.rpy:2861
translate Spanish day9sfwnot_5e1f7d7b:

    # center_text "It really did take a lot out of you. You wonder for a moment how Casper can do it so much."
    center_text "La verdad es que todo eso te dejó agotad[letra]. Por un momento, te preguntas cómo puede Casper hacerlo tantas veces."

# game/beyond the bet/day9dlc.rpy:2862
translate Spanish day9sfwnot_ecd0e92c:

    # center_text "You lay back, then pull him towards you."
    center_text "Te recuestas y luego lo atraes hacia ti."

# game/beyond the bet/day9dlc.rpy:2863
translate Spanish day9sfwnot_fdc5eaf6:

    # center_text "His hands wrap around your waist, and you nestle into the crook of his neck."
    center_text "Él te rodea la cintura con los brazos y tú te acurrucas en el hueco de su cuello."

# game/beyond the bet/day9dlc.rpy:2864
translate Spanish day9sfwnot_083c8ccf:

    # center_text "It's warm and comfortable."
    center_text "Es cálido y reconfortante."

# game/beyond the bet/day9dlc.rpy:2865
translate Spanish day9sfwnot_e0a73181:

    # center_text "Being held by him just feels right."
    center_text "Estar entre sus brazos se siente simplemente bien."

# game/beyond the bet/day9dlc.rpy:2866
translate Spanish day9sfwnot_d4afe288:

    # center_text "Feeling his chest rise and fall, his heart beating."
    center_text "Sientes cómo su pecho sube y baja y cómo late su corazón."

# game/beyond the bet/day9dlc.rpy:2867
translate Spanish day9sfwnot_3b65848d:

    # center_text "The warmth of his skin, and the softness of his hair."
    center_text "La calidez de su piel y la suavidad de su cabello."

# game/beyond the bet/day9dlc.rpy:2868
translate Spanish day9sfwnot_10e1860e:

    # center_text "His fingers, stroking gently against your cheek."
    center_text "Sus dedos acarician suavemente tu mejilla."

# game/beyond the bet/day9dlc.rpy:2869
translate Spanish day9sfwnot_80d54f94:

    # center_text "Time goes by as you simply hold each other, afraid to let go."
    center_text "El tiempo pasa mientras permanecen abrazados, con miedo de soltarse."

# game/beyond the bet/day9dlc.rpy:2870
translate Spanish day9sfwnot_102fb9ec:

    # center_text "It's some time later when you decide to speak up."
    center_text "Un rato después, decides romper el silencio."

# game/beyond the bet/day9dlc.rpy:2887
translate Spanish day9sfwnot_997a6b3e:

    # GRC "Hah!"
    GRC "¡Ja!"

# game/beyond the bet/day9dlc.rpy:2888
translate Spanish day9sfwnot_2e9531ac:

    # GRC "I am unsure how much say I would have in the matter, but I will try my best not to perish."
    GRC "No estoy seguro de cuánta voz tendría yo en el asunto, pero haré todo lo posible por no perecer."

# game/beyond the bet/day9dlc.rpy:2891
translate Spanish day9sfwnot_d81534fb:

    # GRC "For once, death has no appeal to me."
    GRC "Por una vez, la muerte no me atrae."

# game/beyond the bet/day9dlc.rpy:2892
translate Spanish day9sfwnot_f2cddfb0:

    # GRC "Look what you've gone and done."
    GRC "Mira lo que has hecho."

# game/beyond the bet/day9dlc.rpy:2894
translate Spanish day9sfwnot_8a2853d4:

    # GRC "You've corrupted a model Grim Reaper."
    GRC "Has corrompido a una Parca ejemplar."

# game/beyond the bet/day9dlc.rpy:2900
translate Spanish day9sfwnot_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day9dlc.rpy:2901
translate Spanish day9sfwnot_a3fa68d1:

    # GRC "...I will be back soon, Sunshine. Don't go anywhere, and don't open the door."
    GRC "...Volveré pronto, Solecito. No te vayas a ninguna parte y no abras la puerta."

# game/beyond the bet/day9dlc.rpy:2907
translate Spanish day9sfwnot_ce0497b1:

    # "{i}He leans in and kisses you, gentle, tender.{/i}"
    "{i}Se inclina hacia ti y te da un beso suave y lleno de ternura.{/i}"

# game/beyond the bet/day9dlc.rpy:2909
translate Spanish day9sfwnot_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/beyond the bet/day9dlc.rpy:2910
translate Spanish day9sfwnot_fcd30c53:

    # GRC "I will see you later, my love."
    GRC "Te veré luego, amor mío."

# game/beyond the bet/day9dlc.rpy:2914
translate Spanish day9sfwnot_aa4f95ee:

    # center_text "He stands, then stops to look down at you, his eyes filled with a sort of affection you never thought could be aimed at you."
    center_text "Se pone de pie, pero se detiene para mirarte desde arriba. Sus ojos reflejan un cariño que nunca imaginaste que alguien pudiera sentir por ti."

# game/beyond the bet/day9dlc.rpy:2915
translate Spanish day9sfwnot_b5ca00ae:

    # center_text "And then he turns and walks out the door."
    center_text "Después, se da la vuelta y sale de la habitación."

# game/beyond the bet/day9dlc.rpy:2916
translate Spanish day9sfwnot_9c0f4773:

    # center_text "As it closes, a cold feeling settles in the room."
    center_text "Cuando la puerta se cierra, una sensación de frío invade la habitación."

# game/beyond the bet/day9dlc.rpy:2917
translate Spanish day9sfwnot_c825bb38:

    # center_text "You look towards your bag, where the letter from the mysterious reaper is hidden."
    center_text "Miras hacia tu bolso, donde está escondida la carta de la misteriosa Parca."

# game/beyond the bet/day9dlc.rpy:2918
translate Spanish day9sfwnot_374ab89c:

    # center_text "But your body feels heavy, and your eyelids droop."
    center_text "Pero sientes el cuerpo pesado y los párpados cada vez más caídos."

# game/beyond the bet/day9dlc.rpy:2919
translate Spanish day9sfwnot_f77e2aa1:

    # center_text "Time to sleep, you think. Just a nap, and then you'll wake up and everything will be fine."
    center_text "Es hora de dormir, piensas. Solo una siesta y luego despertarás; todo estará bien."

# game/beyond the bet/day9dlc.rpy:2920
translate Spanish day9sfwnot_796a6d87:

    # center_text "With a yawn, you close your eyes, and let yourself drift off to sleep."
    center_text "Bostezas, cierras los ojos y te dejas vencer por el sueño."

translate Spanish strings:

    # game/beyond the bet/day9dlc.rpy:64
    old "1. <Grimmy.>"
    new "1. <Parquita.>"

    # game/beyond the bet/day9dlc.rpy:68
    old "1. <No, but it IS a cute nickname.>"
    new "1. <No, pero ES un apodo lindo.>"

    # game/beyond the bet/day9dlc.rpy:73
    old "2. <Casper.>"
    new "2. <Casper.>"

    # game/beyond the bet/day9dlc.rpy:79
    old "1. <Well, get used to it.>"
    new "1. <Pues acostúmbrate.>"

    # game/beyond the bet/day9dlc.rpy:82
    old "3. <Moonlight.>"
    new "3. <Lunita.>"

    # game/beyond the bet/day9dlc.rpy:87
    old "1. <It's cute, right?>"
    new "1. <Es lindo, ¿verdad?>"

    # game/beyond the bet/day9dlc.rpy:90
    old "1. <If I'm supposed to be like sunshine, you're definitely more like moonlight.>"
    new "1. <Si se supone que yo soy como el sol, tú eres definitivamente más como la luz de la luna.>"

    # game/beyond the bet/day9dlc.rpy:97
    old "1. <You're still here.>"
    new "1. <Sigues aquí.>"

    # game/beyond the bet/day9dlc.rpy:102
    old "1. <Work doesn't need you?>"
    new "1. <¿El trabajo no te necesita?>"

    # game/beyond the bet/day9dlc.rpy:109
    old "1. <More important than the cycle of death and rebirth?>"
    new "1. <¿Más importante que el ciclo de la muerte y el renacimiento?>"

    # game/beyond the bet/day9dlc.rpy:114
    old "1. <Just a little.>"
    new "1. <Solo un poquito.>"

    # game/beyond the bet/day9dlc.rpy:117
    old "2. <Aw, Casper...>"
    new "2. <Aw, Casper...>"

    # game/beyond the bet/day9dlc.rpy:121
    old "1. <Did you mean me?>"
    new "1. <¿Te referías a mí?>"

    # game/beyond the bet/day9dlc.rpy:130
    old "1. <I half thought you'd wake up and regret it.>"
    new "1. <Por un momento pensé que despertarías y te arrepentirías.>"

    # game/beyond the bet/day9dlc.rpy:141
    old "1. <Ah... so you...?>"
    new "1. <Ah... ¿entonces tú...?>"

    # game/beyond the bet/day9dlc.rpy:143
    old "2. <I... you...>"
    new "2. <Yo... tú...>"

    # game/beyond the bet/day9dlc.rpy:145
    old "3. <What exactly do you regret?>"
    new "3. <¿De qué te arrepientes exactamente?>"

    # game/beyond the bet/day9dlc.rpy:151
    old "1. <What are we gonna do?>"
    new "1. <¿Qué vamos a hacer?>"

    # game/beyond the bet/day9dlc.rpy:153
    old "2. <What's next for us, then?>"
    new "2. <¿Y qué nos espera ahora?>"

    # game/beyond the bet/day9dlc.rpy:159
    old "1. <That makes sense.>"
    new "1. <Tiene sentido.>"

    # game/beyond the bet/day9dlc.rpy:161
    old "2. <I wish you'd stay...>"
    new "2. <Ojalá pudieras quedarte...>"

    # game/beyond the bet/day9dlc.rpy:173
    old "1. <Where'd that come from?!>"
    new "1. <¡¿De dónde salió eso?!>"

    # game/beyond the bet/day9dlc.rpy:178
    old "1. <Takes one to know one.>"
    new "1. <El que lo dice, lo es.>"

    # game/beyond the bet/day9dlc.rpy:185
    old "1. <It hurts to know you can't lie sometimes.>"
    new "1. <Duele saber que a veces no puedes mentir.>"

    # game/beyond the bet/day9dlc.rpy:188
    old "1. <You really think all that's true, huh?>"
    new "1. <¿De verdad crees que todo eso es cierto, eh?>"

    # game/beyond the bet/day9dlc.rpy:192
    old "1. <So, you go back, and then...>"
    new "1. <Entonces, vuelves y luego...>"

    # game/beyond the bet/day9dlc.rpy:195
    old "1. <Tomorrow is day ten of our bet.>"
    new "1. <Mañana es el día diez de nuestra apuesta.>"

    # game/beyond the bet/day9dlc.rpy:204
    old "1. <To clear my name of DEATH?>"
    new "1. <¿Para limpiar mi nombre de la MUERTE?>"

    # game/beyond the bet/day9dlc.rpy:213
    old "1. <Alright, but...>"
    new "1. <Está bien, pero...>"

    # game/beyond the bet/day9dlc.rpy:216
    old "1. <Please stay safe, Casper.>"
    new "1. <Por favor, cuídate, Casper.>"

    # game/beyond the bet/day9dlc.rpy:218
    old "2. <I'm more worried about you.>"
    new "2. <Me preocupas más tú.>"

    # game/beyond the bet/day9dlc.rpy:223
    old "1. <You said they could KILL you for not getting my soul!>"
    new "1. <¡Dijiste que podrían MATARTE por no conseguir mi alma!>"

    # game/beyond the bet/day9dlc.rpy:235
    old "1. <Are you going right away?>"
    new "1. <¿Te vas de inmediato?>"

    # game/beyond the bet/day9dlc.rpy:243
    old "1. <Oh god.>"
    new "1. <Oh, dios.>"

    # game/beyond the bet/day9dlc.rpy:247
    old "2. <Please, no.>"
    new "2. <Por favor, no.>"

    # game/beyond the bet/day9dlc.rpy:251
    old "3. <I'd like that.>"
    new "3. <Me gustaría eso.>"

    # game/beyond the bet/day9dlc.rpy:254
    old "1. <Why don't we cook together?>"
    new "1. <¿Por qué no cocinamos juntos?>"

    # game/beyond the bet/day9dlc.rpy:257
    old "1. <I'm not sick now, so I can help.>"
    new "1. <Ya me recuperé, así que puedo ayudar.>"

    # game/beyond the bet/day9dlc.rpy:263
    old "1. <Permission to use my own kitchen: granted.>"
    new "1. <Permiso para usar mi propia cocina: concedido.>"

    # game/beyond the bet/day9dlc.rpy:267
    old "1. <Amusing is my middle name.>"
    new "1. <Divertid[letra] es mi segundo nombre.>"

    # game/beyond the bet/day9dlc.rpy:272
    old "2. <Now I know it won't burn down.>"
    new "2. <Ahora sé que no se quemará.>"

    # game/beyond the bet/day9dlc.rpy:277
    old "1. <Well, it wouldn't be my first housefire like that.>"
    new "1. <Bueno, no sería la primera vez que provoco un incendio en casa.>"

    # game/beyond the bet/day9dlc.rpy:282
    old "1. <And what will we make, Chef Casper?>"
    new "1. <¿Y qué vamos a preparar, Chef Casper?>"

    # game/beyond the bet/day9dlc.rpy:287
    old "1. <I've got something perfect.>"
    new "1. <Tengo algo perfecto.>"

    # game/beyond the bet/day9dlc.rpy:290
    old "1. <Vegemite. On. Toast.>"
    new "1. <Vegemite. En. Tostada.>"

    # game/beyond the bet/day9dlc.rpy:298
    old "1. <You're gonna hate this.>"
    new "1. <Vas a odiar esto.>"

    # game/beyond the bet/day9dlc.rpy:301
    old "1. <Wait, before we eat...>"
    new "1. <Espera, antes de comer...>"

    # game/beyond the bet/day9dlc.rpy:304
    old "1. <You didn't bring a change of clothes, did you?>"
    new "1. <No trajiste una muda de ropa, ¿verdad?>"

    # game/beyond the bet/day9dlc.rpy:310
    old "1. <Stay the night?>"
    new "1. <¿A quedarte a dormir?>"

    # game/beyond the bet/day9dlc.rpy:314
    old "1. <I might have something that fits you.>"
    new "1. <Quizás tenga algo que te quede.>"

    # game/beyond the bet/day9dlc.rpy:319
    old "1. <No, I really might! >"
    new "1. <¡No, de verdad que sí! >"

    # game/beyond the bet/day9dlc.rpy:322
    old "1. <Can I pick something?>"
    new "1. <¿Puedo elegir algo?>"

    # game/beyond the bet/day9dlc.rpy:329
    old "1. <Oh, you should always be a little scared when it comes to me, Casper.>"
    new "1. <Oh, deberías tener siempre un poco de miedo cuando se trata de mí, Casper.>"

    # game/beyond the bet/day9dlc.rpy:331
    old "2. <Noooo, of course not.>"
    new "2. <Noooo, claro que no.>"

    # game/beyond the bet/day9dlc.rpy:338
    old "1. <Yay!>"
    new "1. <¡Yay!>"

    # game/beyond the bet/day9dlc.rpy:354
    old "1. <That clowncore-ish outfit you picked up somewhere.>"
    new "1. <Ese atuendo estilo clowncore que conseguiste en algún lado.>"

    # game/beyond the bet/day9dlc.rpy:360
    old "1. <I used to dress like this.>"
    new "1. <Solía vestirme así.>"

    # game/beyond the bet/day9dlc.rpy:362
    old "2. <It was a costume for Halloween, I think.>"
    new "2. <Creo que era un disfraz de Halloween.>"

    # game/beyond the bet/day9dlc.rpy:367
    old "1. <I don't know. Clowns say honk?>"
    new "1. <No sé. ¿Los payasos dicen 'honk'?>"

    # game/beyond the bet/day9dlc.rpy:371
    old "1. <You just did.>"
    new "1. <Acabas de hacerlo.>"

    # game/beyond the bet/day9dlc.rpy:374
    old "1. <Clown Casper.>"
    new "1. <Payaso Casper.>"

    # game/beyond the bet/day9dlc.rpy:382
    old "1. <I actually think it suits you.>"
    new "1. <De hecho creo que te queda bien.>"

    # game/beyond the bet/day9dlc.rpy:384
    old "1. <You look cute.>"
    new "1. <Te ves lindo.>"

    # game/beyond the bet/day9dlc.rpy:386
    old "2. <Yeah, it looks a bit silly.>"
    new "2. <Sí, se ve un poco tonto.>"

    # game/beyond the bet/day9dlc.rpy:388
    old "1. <But I like it, too!>"
    new "1. <¡Pero a mí también me gusta!>"

    # game/beyond the bet/day9dlc.rpy:393
    old "1. <Oh yes. Very necessary.>"
    new "1. <Oh, sí. Muy necesarias.>"

    # game/beyond the bet/day9dlc.rpy:396
    old "1. <Annnnnyway. Breakfast!>"
    new "1. <Enfiiiin. ¡El desayuno!>"

    # game/beyond the bet/day9dlc.rpy:399
    old "2. <That military-like outfit with the harnesses.>"
    new "2. <Ese atuendo de estilo militar con arneses.>"

    # game/beyond the bet/day9dlc.rpy:405
    old "1. <You like?>"
    new "1. <¿Te gusta?>"

    # game/beyond the bet/day9dlc.rpy:410
    old "1. <I thought it'd be your style, yeah.>"
    new "1. <Pensé que sería tu estilo, sí.>"

    # game/beyond the bet/day9dlc.rpy:413
    old "1. <Honestly, it looks even better on you than I thought it would.>"
    new "1. <Sinceramente, te queda incluso mejor de lo que pensé.>"

    # game/beyond the bet/day9dlc.rpy:418
    old "1. <Oh, no. It's very necessary.>"
    new "1. <Oh, no. Es muy necesario.>"

    # game/beyond the bet/day9dlc.rpy:423
    old "1. <The use is: sexy.>"
    new "1. <Sirve para verte: sexy.>"

    # game/beyond the bet/day9dlc.rpy:425
    old "2. <I get to look at you in a harness. No other use needed.>"
    new "2. <Puedo admirarte usando un arnés. No necesito ninguna otra utilidad.>"

    # game/beyond the bet/day9dlc.rpy:432
    old "2. <Anything AND nothing.>"
    new "2. <Cualquier cosa Y nada.>"

    # game/beyond the bet/day9dlc.rpy:438
    old "3. <The axolotl onesie.>"
    new "3. <El pijama de ajolote.>"

    # game/beyond the bet/day9dlc.rpy:445
    old "1. <Now I feel like I won't get it back...>"
    new "1. <Ahora siento que no me lo devolverás...>"

    # game/beyond the bet/day9dlc.rpy:449
    old "1. <'In time' being...>"
    new "1. <'A su debido tiempo' siendo...>"

    # game/beyond the bet/day9dlc.rpy:454
    old "1. <Hahahahaha.>"
    new "1. <Jajajajaja.>"

    # game/beyond the bet/day9dlc.rpy:459
    old "1. <A name? For a onesie?>"
    new "1. <¿Un nombre? ¿Para un pijama?>"

    # game/beyond the bet/day9dlc.rpy:464
    old "1. <Go on. Pick something then.>"
    new "1. <Vamos. Entonces elige algo.>"

    # game/beyond the bet/day9dlc.rpy:469
    old "1. <What makes him great?>"
    new "1. <¿Qué lo hace grande?>"

    # game/beyond the bet/day9dlc.rpy:476
    old "2. <Yeah. I was thinking... Cupcake.>"
    new "2. <Sí. Estaba pensando... Cupcake.>"

    # game/beyond the bet/day9dlc.rpy:482
    old "1. <Whenever I remember you can't lie it amazes me.>"
    new "1. <Cada vez que recuerdo que no puedes mentir, me asombra.>"

    # game/beyond the bet/day9dlc.rpy:485
    old "1. <Let's get breakfast, Cupcake and Casper!>"
    new "1. <¡Vamos a desayunar, Cupcake y Casper!>"

    # game/beyond the bet/day9dlc.rpy:488
    old "4. <A turtleneck, high waisted pants, and an oversized jacket.>"
    new "4. <Un suéter de cuello alto, pantalones de tiro alto y una chaqueta holgada.>"

    # game/beyond the bet/day9dlc.rpy:492
    old "1. <Ta-da!>"
    new "1. <¡Tachán!>"

    # game/beyond the bet/day9dlc.rpy:495
    old "1. <Go on, do a little twirl.>"
    new "1. <Vamos, da una pequeña vuelta.>"

    # game/beyond the bet/day9dlc.rpy:498
    old "1. <Wow, that really suits you.>"
    new "1. <Wow, eso de verdad te queda bien.>"

    # game/beyond the bet/day9dlc.rpy:500
    old "2. <Hot damn, boy.>"
    new "2. <Santo cielo, muchacho.>"

    # game/beyond the bet/day9dlc.rpy:502
    old "3. <Zoo-wee Momma~>"
    new "3. <Uuuuf, qué bombón~>"

    # game/beyond the bet/day9dlc.rpy:509
    old "1. <That's funny coming from you.>"
    new "1. <Qué gracioso viniendo de ti.>"

    # game/beyond the bet/day9dlc.rpy:513
    old "1. <You never wear your jacket right!>"
    new "1. <¡Nunca te pones bien la chaqueta!>"

    # game/beyond the bet/day9dlc.rpy:516
    old "1. <You're always trying to seduce me with your sultry off the shoulder look!>"
    new "1. <¡Siempre intentas seducirme con ese look tan sensual que deja tus hombros al descubierto!>"

    # game/beyond the bet/day9dlc.rpy:523
    old "1. <Is that not what you're doing?>"
    new "1. <¿No es eso lo que estás haciendo?>"

    # game/beyond the bet/day9dlc.rpy:526
    old "1. <And it was working, too...>"
    new "1. <Y estaba funcionando, además...>"

    # game/beyond the bet/day9dlc.rpy:532
    old "1. <Oh, I'm swooning...>"
    new "1. <Oh, me estoy derritiendo...>"

    # game/beyond the bet/day9dlc.rpy:535
    old "1. <Maybe that's because I'm hungry, actually.>"
    new "1. <Quizás es porque tengo hambre, en realidad.>"

    # game/beyond the bet/day9dlc.rpy:538
    old "2. <I'm kidding, Casper.>"
    new "2. <Es broma, Casper.>"

    # game/beyond the bet/day9dlc.rpy:546
    old "1. <You know what's not a joke? Breakfast. Let's go!>"
    new "1. <¿Sabes qué no es una broma? El desayuno. ¡Vamos!>"

    # game/beyond the bet/day9dlc.rpy:549
    old "5. <A trendy black and red waist coat.>"
    new "5. <Un chaleco negro y rojo a la moda.>"

    # game/beyond the bet/day9dlc.rpy:553
    old "1. <Okay, if the Grim Reaper thing doesn't work out, I seriously think you should consider being a vampire.>"
    new "1. <Okey, si lo de ser Parca no funciona, creo en serio que deberías considerar ser vampiro.>"

    # game/beyond the bet/day9dlc.rpy:561
    old "1. <Is that a... joke?>"
    new "1. <¿Eso es una... broma?>"

    # game/beyond the bet/day9dlc.rpy:565
    old "1. <No, you said it totally seriously.>"
    new "1. <No, lo dijiste con total seriedad.>"

    # game/beyond the bet/day9dlc.rpy:568
    old "1. <But that has to be a joke.>"
    new "1. <Pero tiene que ser una broma.>"

    # game/beyond the bet/day9dlc.rpy:573
    old "1. <You're the most vain person I know!>"
    new "1. <¡Eres la persona más vanidosa que conozco!>"

    # game/beyond the bet/day9dlc.rpy:577
    old "1. <You're ALWAYS going on about your looks!>"
    new "1. <¡SIEMPRE estás hablando de tu aspecto!>"

    # game/beyond the bet/day9dlc.rpy:583
    old "1. <And you're addicted to the sound of your own voice!>"
    new "1. <¡Y eres adicto al sonido de tu propia voz!>"

    # game/beyond the bet/day9dlc.rpy:587
    old "1. <Case in point.>"
    new "1. <Ejemplo perfecto.>"

    # game/beyond the bet/day9dlc.rpy:592
    old "1. <Me.>"
    new "1. <Yo.>"

    # game/beyond the bet/day9dlc.rpy:594
    old "1. <Someone needs to bring you down a peg.>"
    new "1. <Alguien tiene que bajarte los humos.>"

    # game/beyond the bet/day9dlc.rpy:597
    old "1. <But that can come after breakfast.>"
    new "1. <Pero eso puede venir después del desayuno.>"

    # game/beyond the bet/day9dlc.rpy:600
    old "2. <To be honest, I like it.>"
    new "2. <Sinceramente, me gusta.>"

    # game/beyond the bet/day9dlc.rpy:602
    old "1. <Who's my handsome lil guy? You are!>"
    new "1. <¿Quién es mi guapo chiquitín? ¡Tú!>"

    # game/beyond the bet/day9dlc.rpy:607
    old "1. <Who wants scratchies?>"
    new "1. <¿Quién quiere rascaditas?>"

    # game/beyond the bet/day9dlc.rpy:612
    old "1. <After breakfast. Come on, boy, to the kitchen!>"
    new "1. <Después del desayuno. ¡Vamos, chico, a la cocina!>"

    # game/beyond the bet/day9dlc.rpy:615
    old "6. <The Comfy Sheep Outfit!>"
    new "6. <¡El cómodo atuendo de ovejita!>"

    # game/beyond the bet/day9dlc.rpy:619
    old "1. <Awwww, Casper...!>"
    new "1. <¡Awwww, Casper...!>"

    # game/beyond the bet/day9dlc.rpy:622
    old "1. <You look so cute.>"
    new "1. <Te ves tan lindo.>"

    # game/beyond the bet/day9dlc.rpy:625
    old "1. <Can you say 'baaa' for me?>"
    new "1. <¿Puedes decir 'beee' por mí?>"

    # game/beyond the bet/day9dlc.rpy:630
    old "1. <You certainly look like one right now.>"
    new "1. <Desde luego te ves como una en este momento.>"

    # game/beyond the bet/day9dlc.rpy:633
    old "1. <A fantasy sheep that wears a cloak, that is.>"
    new "1. <Una oveja fantástica que lleva una capa, eso sí.>"

    # game/beyond the bet/day9dlc.rpy:636
    old "1. <I want to pat your fluffy white hair.>"
    new "1. <Quiero acariciar tu cabello blanco y esponjoso.>"

    # game/beyond the bet/day9dlc.rpy:641
    old "1. <Only if you say 'baaa'.>"
    new "1. <Solo si dices 'beee'.>"

    # game/beyond the bet/day9dlc.rpy:648
    old "1. <Yeah but now you want me to do it.>"
    new "1. <Sí, pero ahora eres tú quien quiere que lo haga.>"

    # game/beyond the bet/day9dlc.rpy:651
    old "1. <Reeeeaaaal bad.>"
    new "1. <Muuuuuy maaaal.>"

    # game/beyond the bet/day9dlc.rpy:656
    old "1. <Then tell me I'm wrong.>"
    new "1. <Entonces dime que me equivoco.>"

    # game/beyond the bet/day9dlc.rpy:662
    old "1. <B...?>"
    new "1. <¿B...?>"

    # game/beyond the bet/day9dlc.rpy:666
    old "1. <{i}Ruffle Casper's hair.{/i}>"
    new "1. <{i}Revolverle el cabello a Casper.{/i}>"

    # game/beyond the bet/day9dlc.rpy:669
    old "1. <Who's a good little sheep?>"
    new "1. <¿Quién es una buena ovejita?>"

    # game/beyond the bet/day9dlc.rpy:674
    old "1. <I suppose if you're a sheep, I'm your shepherd!>"
    new "1. <¡Supongo que si tú eres la oveja, yo soy tu pastor!>"

    # game/beyond the bet/day9dlc.rpy:677
    old "1. <Allow me to guide you to the kitchen, my lost little lamb.>"
    new "1. <Permíteme guiarte a la cocina, mi corderito perdido.>"

    # game/beyond the bet/day9dlc.rpy:703
    old "1. <What, delicious?>"
    new "1. <¿Qué, deliciosa?>"

    # game/beyond the bet/day9dlc.rpy:709
    old "1. <Awww. 'Cause we did it together?>"
    new "1. <Awww. ¿Porque lo hicimos juntos?>"

    # game/beyond the bet/day9dlc.rpy:715
    old "2. <To tell you the truth, I've never had it before...>"
    new "2. <A decir verdad, nunca lo había probado antes...>"

    # game/beyond the bet/day9dlc.rpy:719
    old "1. <I thought it'd be fun to try it together for the first time.>"
    new "1. <Pensé que sería divertido probarlo juntos por primera vez.>"

    # game/beyond the bet/day9dlc.rpy:735
    old "1. <Terrible.>"
    new "1. <Horrible.>"

    # game/beyond the bet/day9dlc.rpy:739
    old "2. <Fine, you suppose.>"
    new "2. <Está bien, supongo.>"

    # game/beyond the bet/day9dlc.rpy:742
    old "3. <The best thing you've ever eaten.>"
    new "3. <Lo mejor que has probado en tu vida.>"

    # game/beyond the bet/day9dlc.rpy:755
    old "1. <...You like it, then?>"
    new "1. <...¿Entonces sí te gusta?>"

    # game/beyond the bet/day9dlc.rpy:765
    old "1. <You can say it.>"
    new "1. <Puedes decirlo.>"

    # game/beyond the bet/day9dlc.rpy:769
    old "1. <Hahahahaha!>"
    new "1. <¡Jajajajaja!>"

    # game/beyond the bet/day9dlc.rpy:772
    old "1. <Somehow I knew you'd hate it.>"
    new "1. <De algún modo sabía que lo odiarías.>"

    # game/beyond the bet/day9dlc.rpy:775
    old "1. <You're so cute.>"
    new "1. <Eres tan lindo.>"

    # game/beyond the bet/day9dlc.rpy:780
    old "1. <The whole continent of Australia.>"
    new "1. <A todo el continente de Australia.>"

    # game/beyond the bet/day9dlc.rpy:782
    old "1. <The non-betrayers, that is.>"
    new "1. <Los no traidores, eso sí.>"

    # game/beyond the bet/day9dlc.rpy:786
    old "2. <I have no clue, it's terrible.>"
    new "2. <No tengo ni idea, es terrible.>"

    # game/beyond the bet/day9dlc.rpy:793
    old "1. <Amen.>"
    new "1. <Amén.>"

    # game/beyond the bet/day9dlc.rpy:802
    old "1. <Why?>"
    new "1. <¿Por qué?>"

    # game/beyond the bet/day9dlc.rpy:808
    old "1. <I didn't peg you for the superstitious type.>"
    new "1. <No te imaginaba como alguien supersticioso.>"

    # game/beyond the bet/day9dlc.rpy:810
    old "1. <But alright. I'll stick around here.>"
    new "1. <Pero está bien. Me quedaré por aquí.>"

    # game/beyond the bet/day9dlc.rpy:813
    old "1. <I wanted to hang with [pet_name] anyway.>"
    new "1. <De todos modos quería pasar el rato con [pet_name].>"

    # game/beyond the bet/day9dlc.rpy:816
    old "2. <I was planning on it anyway.>"
    new "2. <De todos modos pensaba hacerlo.>"

    # game/beyond the bet/day9dlc.rpy:818
    old "1. <A day of relaxing is in order, me thinks.>"
    new "1. <Creo que hoy toca relajarse.>"

    # game/beyond the bet/day9dlc.rpy:823
    old "1. <But it all looks so good on you!>"
    new "1. <¡Pero todo te queda tan bien!>"

    # game/beyond the bet/day9dlc.rpy:829
    old "1. <My cute little clown boy.>"
    new "1. <Mi lindo chico payaso.>"

    # game/beyond the bet/day9dlc.rpy:834
    old "1. <A Grim Reaper who says honk.>"
    new "1. <Una Parca que dice 'honk'.>"

    # game/beyond the bet/day9dlc.rpy:840
    old "1. <Honestly, it looks so good on you, I think you should keep it.>"
    new "1. <Sinceramente, te queda tan bien que creo que deberías quedártelo.>"

    # game/beyond the bet/day9dlc.rpy:844
    old "1. <At least keep the harness, then. That's gotta stay.>"
    new "1. <Al menos quédate con el arnés, entonces. Eso tiene que quedarse.>"

    # game/beyond the bet/day9dlc.rpy:854
    old "1. <Not because you want it. Not at all.>"
    new "1. <No porque lo quieras. Para nada.>"

    # game/beyond the bet/day9dlc.rpy:863
    old "1. <Next time I'm giving you a little maid dress and making you clean my house.>"
    new "1. <La próxima vez te daré un vestidito de sirvienta y te haré limpiar mi casa.>"

    # game/beyond the bet/day9dlc.rpy:872
    old "1. <Are you asking me to marry you or something?>"
    new "1. <¿Me estás pidiendo que me case contigo o algo así?>"

    # game/beyond the bet/day9dlc.rpy:880
    old "1. <My favorite little sheepy.>"
    new "1. <Mi ovejita favorita.>"

    # game/beyond the bet/day9dlc.rpy:883
    old "1. <I baaa you, hehe.>"
    new "1. <Te quierooo, beejeje.>"

    # game/beyond the bet/day9dlc.rpy:888
    old "1. <But it looks so cute!!!>"
    new "1. <¡¡¡Pero se ve tan lindo!!!>"

    # game/beyond the bet/day9dlc.rpy:891
    old "1. <My lost little lamb~>"
    new "1. <Mi corderito perdido~>"

    # game/beyond the bet/day9dlc.rpy:901
    old "2. <You look like you want to say something.>"
    new "2. <Parece que quieres decir algo.>"

    # game/beyond the bet/day9dlc.rpy:911
    old "1. <I love you too, Casper.>"
    new "1. <Yo también te amo, Casper.>"

    # game/beyond the bet/day9dlc.rpy:913
    old "2. <I feel the same.>"
    new "2. <Siento lo mismo.>"

    # game/beyond the bet/day9dlc.rpy:916
    old "1. <Don't die, alright?>"
    new "1. <No te mueras, ¿de acuerdo?>"

    # game/beyond the bet/day9dlc.rpy:922
    old "1. <Once again, I have a door->"
    new "1. <Una vez más, tengo una puerta->"

    # game/beyond the bet/day9dlc.rpy:966
    old "skin so soft..."
    new "piel tan suave..."

    # game/beyond the bet/day9dlc.rpy:993
    old "1. <Woah, woah, woah.>"
    new "1. <Ey, ey, ey.>"

    # game/beyond the bet/day9dlc.rpy:995
    old "2. <TOO MANY QUESTIONS!>"
    new "2. <¡DEMASIADAS PREGUNTAS!>"

    # game/beyond the bet/day9dlc.rpy:998
    old "1. <Slow down!>"
    new "1. <¡Más despacio!>"

    # game/beyond the bet/day9dlc.rpy:1010
    old "1. <Alright you asshole, not that slow.>"
    new "1. <Está bien, idiota, tampoco te tardes tanto.>"

    # game/beyond the bet/day9dlc.rpy:1012
    old "2. <Ha. Ha. Ha.>"
    new "2. <Ja. Ja. Ja.>"

    # game/beyond the bet/day9dlc.rpy:1016
    old "1. <I'm fine, yeah.>"
    new "1. <Sí, estoy bien.>"

    # game/beyond the bet/day9dlc.rpy:1019
    old "1. <Just been hanging out with [pet_name].>"
    new "1. <Solo pasando el rato con [pet_name].>"

    # game/beyond the bet/day9dlc.rpy:1022
    old "1. <No one's come to steal away my soul or anything.>"
    new "1. <Nadie ha venido a llevarse mi alma ni nada.>"

    # game/beyond the bet/day9dlc.rpy:1026
    old "2. <Aaargh, no... I think... I think I'm... dying...>"
    new "2. <Aaargh, no... creo que... creo que me estoy... muriendo...>"

    # game/beyond the bet/day9dlc.rpy:1031
    old "1. <Wait!! I'm kidding!!!>"
    new "1. <¡¡Espera!! ¡¡Es broma!!>"

    # game/beyond the bet/day9dlc.rpy:1034
    old "2. <I'm fine, I promise!>"
    new "2. <¡Estoy bien, lo prometo!>"

    # game/beyond the bet/day9dlc.rpy:1039
    old "1. <I didn't mean to.>"
    new "1. <No era mi intención.>"

    # game/beyond the bet/day9dlc.rpy:1044
    old "2. <I'm a little sorry but it's also a bit funny, you know?>"
    new "2. <Me siento un poco mal, pero también tiene algo de gracia, ¿sabes?>"

    # game/beyond the bet/day9dlc.rpy:1048
    old "1. <To scare the big bad Grim Reaper, yeah!>"
    new "1. <¡Asustar a la gran y malvada Parca, sí!>"

    # game/beyond the bet/day9dlc.rpy:1053
    old "1. <How's everything going?>"
    new "1. <¿Cómo va todo?>"

    # game/beyond the bet/day9dlc.rpy:1059
    old "1. <I'm glad Azrael's good!>"
    new "1. <¡Me alegra que Azrael esté bien!>"

    # game/beyond the bet/day9dlc.rpy:1063
    old "2. <You sound a little stressed.>"
    new "2. <Suenas un poco estresado.>"

    # game/beyond the bet/day9dlc.rpy:1070
    old "1. <What part is making *you* so stressed, then?>"
    new "1. <¿Qué es lo que te estresa a 'ti', entonces?>"

    # game/beyond the bet/day9dlc.rpy:1073
    old "1. <Stressed about how good-looking I am?>"
    new "1. <¿Estresado por lo guap[letra] que soy?>"

    # game/beyond the bet/day9dlc.rpy:1081
    old "1. <Oooh you think I'm cuuuute, huh?>"
    new "1. <Oooh, te parezco adoraaable, ¿eh?>"

    # game/beyond the bet/day9dlc.rpy:1085
    old "1. <I think you're cute.>"
    new "1. <Yo creo que eres lindo.>"

    # game/beyond the bet/day9dlc.rpy:1089
    old "1. <Your confidence really has never wavered.>"
    new "1. <Tu confianza de verdad nunca ha flaqueado.>"

    # game/beyond the bet/day9dlc.rpy:1100
    old "1. <Hold up.>"
    new "1. <Espera un momento.>"

    # game/beyond the bet/day9dlc.rpy:1103
    old "1. <'a long time ago', he says.>"
    new "1. <'hace mucho tiempo', dice.>"

    # game/beyond the bet/day9dlc.rpy:1106
    old "1. <That was like, a week ago!>"
    new "1. <¡Fue como hace una semana!>"

    # game/beyond the bet/day9dlc.rpy:1110
    old "1. <Alright, old man.>"
    new "1. <Está bien, viejo.>"

    # game/beyond the bet/day9dlc.rpy:1114
    old "1. <You're old, aren't you?>"
    new "1. <Eres viejo, ¿no?>"

    # game/beyond the bet/day9dlc.rpy:1118
    old "1. <I think I've found a new nickname.>"
    new "1. <Creo que he encontrado un nuevo apodo.>"

    # game/beyond the bet/day9dlc.rpy:1121
    old "1. <Old Man Reaper.>"
    new "1. <Viejo Parca.>"

    # game/beyond the bet/day9dlc.rpy:1125
    old "1. <You won't have to worry about greying with that hair, at least.>"
    new "1. <Al menos no tendrás que preocuparte por las canas con ese cabello.>"

    # game/beyond the bet/day9dlc.rpy:1129
    old "1. <Wrinkly, grey haired Casper...>"
    new "1. <Casper arrugado y canoso...>"

    # game/beyond the bet/day9dlc.rpy:1132
    old "1. <It's almost a cute thought.>"
    new "1. <Casi es un pensamiento lindo.>"

    # game/beyond the bet/day9dlc.rpy:1137
    old "1. <Old man 🫵>"
    new "1. <Viejo 🫵>"

    # game/beyond the bet/day9dlc.rpy:1141
    old "1. <Woah, is that the first time you've ever used a normal emoji?>"
    new "1. <Uy, ¿es la primera vez que usas un emoji normal?>"

    # game/beyond the bet/day9dlc.rpy:1144
    old "1. <Congratulations are in order!>"
    new "1. <¡Hay que felicitarte!>"

    # game/beyond the bet/day9dlc.rpy:1149
    old "1. <Haha. You love me.>"
    new "1. <Jaja. Me amas.>"

    # game/beyond the bet/day9dlc.rpy:1154
    old "2. <I enjoy making you uncertain.>"
    new "2. <Me gusta hacerte dudar.>"

    # game/beyond the bet/day9dlc.rpy:1157
    old "1. <Something about a confident, handsome man becoming a mess just does it for me.>"
    new "1. <Hay algo en ver a un hombre guapo y seguro de sí mismo perder la compostura que me encanta.>"

    # game/beyond the bet/day9dlc.rpy:1162
    old "1. <I can't imagine you in actual disarray.>"
    new "1. <No me imagino que puedas perder realmente la compostura.>"

    # game/beyond the bet/day9dlc.rpy:1165
    old "1. <You seem like the kind of guy who likes everything neat and in order.>"
    new "1. <Pareces de los que les gusta tener todo ordenado y en su sitio.>"

    # game/beyond the bet/day9dlc.rpy:1169
    old "1. <So, if we lived together...>"
    new "1. <Entonces, si viviéramos juntos...>"

    # game/beyond the bet/day9dlc.rpy:1172
    old "1. <You'd be like my house wife?>"
    new "1. <¿Serías como mi ama de casa?>"

    # game/beyond the bet/day9dlc.rpy:1177
    old "1. <House wife is a state of being, Casper.>"
    new "1. <Ama de casa es un estado del ser, Casper.>"

    # game/beyond the bet/day9dlc.rpy:1183
    old "1. <That's true love <3>"
    new "1. <Eso es amor verdadero <3>"

    # game/beyond the bet/day9dlc.rpy:1186
    old "2. <I can leave all the cleaning to you.>"
    new "2. <Puedo dejarte toda la limpieza a ti.>"

    # game/beyond the bet/day9dlc.rpy:1193
    old "1. <My apartment is super clean.>"
    new "1. <Mi apartamento está súper limpio.>"

    # game/beyond the bet/day9dlc.rpy:1200
    old "1. <Busted.>"
    new "1. <Me descubrieron.>"

    # game/beyond the bet/day9dlc.rpy:1206
    old "1. <That works for me!>"
    new "1. <¡Por mí, perfecto!>"

    # game/beyond the bet/day9dlc.rpy:1208
    old "2. <Thank god.>"
    new "2. <Gracias a Dios.>"

    # game/beyond the bet/day9dlc.rpy:1210
    old "3. <But really, I can help.>"
    new "3. <Pero en serio, puedo ayudar.>"

    # game/beyond the bet/day9dlc.rpy:1216
    old "2. <The whole forbidden relationship thing?>"
    new "2. <¿Lo de la relación prohibida y todo eso?>"

    # game/beyond the bet/day9dlc.rpy:1221
    old "1. <Thanks, I'm actually terrified.>"
    new "1. <Gracias, en realidad me muero de miedo.>"

    # game/beyond the bet/day9dlc.rpy:1227
    old "1. <Thank you, thank you.>"
    new "1. <Gracias, gracias.>"

    # game/beyond the bet/day9dlc.rpy:1230
    old "1. <When can I collect my emmy?>"
    new "1. <¿Cuándo puedo recoger mi Emmy?>"

    # game/beyond the bet/day9dlc.rpy:1235
    old "1. <You think I couldn't make it as an actor?>"
    new "1. <¿Crees que no podría triunfar en la actuación?>"

    # game/beyond the bet/day9dlc.rpy:1239
    old "1. <Oooooh!>"
    new "1. <¡Oooooh!>"

    # game/beyond the bet/day9dlc.rpy:1244
    old "1. <Maybe if all of this works out and I get to keep my soul, I'll try it out.>"
    new "1. <Quizás si todo esto sale bien y me quedo con mi alma, lo probaré.>"

    # game/beyond the bet/day9dlc.rpy:1247
    old "1. <You know, on the side.>"
    new "1. <Ya sabes, como extra.>"

    # game/beyond the bet/day9dlc.rpy:1250
    old "1. <If that's something you even do on the side? Anyway...>"
    new "1. <¿Si es algo que se hace como extra siquiera? En fin...>"

    # game/beyond the bet/day9dlc.rpy:1253
    old "2. <Life's easier when you stop giving so much of a shit, ya know?>"
    new "2. <La vida es más fácil cuando dejas de darle tanta importancia a todo, ¿sabes?>"

    # game/beyond the bet/day9dlc.rpy:1257
    old "1. <I'm full of good advice.>"
    new "1. <Tengo un montón de buenos consejos.>"

    # game/beyond the bet/day9dlc.rpy:1261
    old "1. <Time to pull out [playerfirstname]'s sage advice. Ahem.>"
    new "1. <Es hora de recurrir a los sabios consejos de [playerfirstname]. Ejem.>"

    # game/beyond the bet/day9dlc.rpy:1264
    old "1. <He who chases two rabbits catches neither.>"
    new "1. <Quien persigue dos conejos no atrapa ninguno.>"

    # game/beyond the bet/day9dlc.rpy:1268
    old "1. <Thanks, I read it on the side of a cereal box.>"
    new "1. <Gracias, lo leí en el costado de una caja de cereal.>"

    # game/beyond the bet/day9dlc.rpy:1272
    old "1. <Oh, it's always been deep, Casper.>"
    new "1. <Oh, siempre ha sido profundo, Casper.>"

    # game/beyond the bet/day9dlc.rpy:1275
    old "1. <Cereal is no joke.>"
    new "1. <El cereal no es ninguna broma.>"

    # game/beyond the bet/day9dlc.rpy:1279
    old "1. <Jeez.>"
    new "1. <Cielos.>"

    # game/beyond the bet/day9dlc.rpy:1282
    old "1. <What Australians have you been talking to?>"
    new "1. <¿Con qué australianos has estado hablando?>"

    # game/beyond the bet/day9dlc.rpy:1287
    old "1. <I hope you'll tell me all about them one day.>"
    new "1. <Espero que algún día me los cuentes todos.>"

    # game/beyond the bet/day9dlc.rpy:1291
    old "2. <He who smelt it, dealt it.>"
    new "2. <Quien lo huele, debajo lo tiene.>"

    # game/beyond the bet/day9dlc.rpy:1295
    old "1. <Yeah that's on you, buddy.>"
    new "1. <Sí, eso es culpa tuya, amigo.>"

    # game/beyond the bet/day9dlc.rpy:1298
    old "1. <You know me better than that.>"
    new "1. <Me conoces mejor que eso.>"

    # game/beyond the bet/day9dlc.rpy:1302
    old "1. <Definitely fortunate.>"
    new "1. <Definitivamente es una suerte.>"

    # game/beyond the bet/day9dlc.rpy:1305
    old "1. <Somehow after only, what, a little over a week?>"
    new "1. <¿Y pensar que solo llevamos, qué, poco más de una semana?>"

    # game/beyond the bet/day9dlc.rpy:1308
    old "1. <You know me so much better than anyone else.>"
    new "1. <Me conoces mucho mejor que nadie.>"

    # game/beyond the bet/day9dlc.rpy:1313
    old "1. <Right.> {#day9right}"
    new "1. <Cierto.> {#day9right}"

    # game/beyond the bet/day9dlc.rpy:1316
    old "1. <I forgot you have a voyeuristic streak.>"
    new "1. <Olvidé que tienes tu lado voyeur.>"

    # game/beyond the bet/day9dlc.rpy:1321
    old "1. <Come onnn, Grimmy.>"
    new "1. <Vamos, Parquita.>"

    # game/beyond the bet/day9dlc.rpy:1324
    old "1. <We both know you were watching closer than you needed to.>"
    new "1. <Ambos sabemos que mirabas más de cerca de lo necesario.>"

    # game/beyond the bet/day9dlc.rpy:1327
    old "1. <Did you like what you saw?>"
    new "1. <¿Te gustó lo que viste?>"

    # game/beyond the bet/day9dlc.rpy:1332
    old "1. <Buuuut?>"
    new "1. <¿Peeero?>"

    # game/beyond the bet/day9dlc.rpy:1345
    old "1. <Hey, Casper!>"
    new "1. <¡Oye, Casper!>"

    # game/beyond the bet/day9dlc.rpy:1349
    old "1. <Did you make any progress today on the whole, ya know, have to take my soul thing?>"
    new "1. <¿Avanzaste algo hoy con lo de, ya sabes, tener que llevarte mi alma?>"

    # game/beyond the bet/day9dlc.rpy:1355
    old "1. <But?>"
    new "1. <¿Pero?>"

    # game/beyond the bet/day9dlc.rpy:1359
    old "1. <Not fantastic odds, then.>"
    new "1. <Entonces no son probabilidades fantásticas.>"

    # game/beyond the bet/day9dlc.rpy:1366
    old "1. <Woah, I'd be going underground?>"
    new "1. <Uy, ¿pasaría a la clandestinidad?>"

    # game/beyond the bet/day9dlc.rpy:1373
    old "2. <Grim.>"
    new "2. <Parca.>"

    # game/beyond the bet/day9dlc.rpy:1376
    old "1. <No one's getting terminated.>"
    new "1. <Nadie va a ser eliminado.>"

    # game/beyond the bet/day9dlc.rpy:1387
    old "1. <Do you want me to call you bad boy, babygirl?>"
    new "1. <¿Quieres que te llame chico malo, babygirl?>"

    # game/beyond the bet/day9dlc.rpy:1391
    old "2. <I will too.>"
    new "2. <Yo también.>"

    # game/beyond the bet/day9dlc.rpy:1401
    old "1. <What about the whole... uh...>"
    new "1. <¿Y qué pasa con lo de... eh...>"

    # game/beyond the bet/day9dlc.rpy:1404
    old "1. <Weird memory thing you had?>"
    new "1. <¿Lo del recuerdo raro que tuviste?>"

    # game/beyond the bet/day9dlc.rpy:1411
    old "1. <You're just full of ideas today.>"
    new "1. <Hoy estás lleno de ideas.>"

    # game/beyond the bet/day9dlc.rpy:1413
    old "2. <Go on, tell me about it.>"
    new "2. <Adelante, cuéntame.>"

    # game/beyond the bet/day9dlc.rpy:1420
    old "1. <How fitting.>"
    new "1. <Qué apropiado.>"

    # game/beyond the bet/day9dlc.rpy:1422
    old "2. <An apt name.>"
    new "2. <Un nombre acertado.>"

    # game/beyond the bet/day9dlc.rpy:1427
    old "1. <Who would?>"
    new "1. <¿Quién podría?>"

    # game/beyond the bet/day9dlc.rpy:1435
    old "1. <Is it heist time?>"
    new "1. <¿Es hora del atraco?>"

    # game/beyond the bet/day9dlc.rpy:1439
    old "1. <It could be like a spy movie.>"
    new "1. <Podría ser como una película de espías.>"

    # game/beyond the bet/day9dlc.rpy:1442
    old "1. <We'll get onto the roof, then you'll lower me down with a rope!>"
    new "1. <¡Subiremos al techo y tú me bajarás con una cuerda!>"

    # game/beyond the bet/day9dlc.rpy:1445
    old "1. <And then I'll do some cool ass flips over all the lasers.>"
    new "1. <Y luego haré unas volteretas buenísimas sobre todos los láseres.>"

    # game/beyond the bet/day9dlc.rpy:1450
    old "1. <GARGOYLES???>"
    new "1. <¿¿¿GÁRGOLAS???>"

    # game/beyond the bet/day9dlc.rpy:1454
    old "1. <Foiled once again...>"
    new "1. <Frustrados una vez más...>"

    # game/beyond the bet/day9dlc.rpy:1456
    old "2. <Dang it...>"
    new "2. <Rayos...>"

    # game/beyond the bet/day9dlc.rpy:1460
    old "2. <I wonder if we could find someone to let us in?>"
    new "2. <Me pregunto si podríamos encontrar a alguien que nos deje entrar.>"

    # game/beyond the bet/day9dlc.rpy:1464
    old "1. <You're so good at your job, Grimmy.>"
    new "1. <Eres tan bueno en tu trabajo, Parquita.>"

    # game/beyond the bet/day9dlc.rpy:1467
    old "1. <Surely someone would have noticed?>"
    new "1. <¿Seguro que alguien se habría dado cuenta?>"

    # game/beyond the bet/day9dlc.rpy:1470
    old "1. <Maybe we can convince them to let us just take a peek.>"
    new "1. <Quizás podamos convencerlos de que nos dejen echar un vistazo.>"

    # game/beyond the bet/day9dlc.rpy:1478
    old "1. <You're not very liked in the workplace.>"
    new "1. <No le caes muy bien a la gente en el trabajo.>"

    # game/beyond the bet/day9dlc.rpy:1518
    old "1. <Did you miss me?>"
    new "1. <¿Me extrañaste?>"

    # game/beyond the bet/day9dlc.rpy:1541
    old "1. <Tell me more of this 'odd feeling'.>"
    new "1. <Cuéntame más sobre esa 'extraña sensación'.>"

    # game/beyond the bet/day9dlc.rpy:1546
    old "1. <Surely not!>"
    new "1. <¡Seguro que no!>"

    # game/beyond the bet/day9dlc.rpy:1549
    old "1. <Surely the Grim Reaper is above such a mortal thing!>"
    new "1. <¡Seguro que la Parca está por encima de algo tan mortal!>"

    # game/beyond the bet/day9dlc.rpy:1555
    old "1. <We're two peas in a pod, buddy.>"
    new "1. <Somos como dos gotas de agua, amigo.>"

    # game/beyond the bet/day9dlc.rpy:1557
    old "2. <It must be like looking in a mirror.>"
    new "2. <Debe de ser como mirarse al espejo.>"

    # game/beyond the bet/day9dlc.rpy:1560
    old "2. <I feel the same about you.>"
    new "2. <Siento lo mismo.>"

    # game/beyond the bet/day9dlc.rpy:1562
    old "1. <I was a little worried you'd be in trouble for staying at my apartment last night.>"
    new "1. <Me preocupaba un poco que te metieras en problemas por quedarte en mi apartamento anoche.>"

    # game/beyond the bet/day9dlc.rpy:1568
    old "1. <I was wondering something.>"
    new "1. <Me preguntaba algo.>"

    # game/beyond the bet/day9dlc.rpy:1571
    old "1. <What's your biggest fear?>"
    new "1. <¿Cuál es tu mayor miedo?>"

    # game/beyond the bet/day9dlc.rpy:1576
    old "1. <I was just thinking, you seem a little scared \nof your organization.>"
    new "1. <Estaba pensando que pareces tenerle un poco de miedo a tu organización.>"

    # game/beyond the bet/day9dlc.rpy:1595
    old "1. <Is there anything else you're scared of?>"
    new "1. <¿Hay algo más que te dé miedo?>"

    # game/beyond the bet/day9dlc.rpy:1616
    old "1. <Oh, I feel just awful.>"
    new "1. <Oh, me siento fatal.>"

    # game/beyond the bet/day9dlc.rpy:1618
    old "1. <Truly terrible.>"
    new "1. <Realmente terrible.>"

    # game/beyond the bet/day9dlc.rpy:1621
    old "1. <It's all my fault that my wonderful Casper \nnow has to have human feelings.>"
    new "1. <Es todo culpa mía que mi maravilloso Casper ahora tenga que tener sentimientos humanos.>"

    # game/beyond the bet/day9dlc.rpy:1624
    old "1. <Just kidding. Suffer like the rest of us.>"
    new "1. <Es broma. Sufre como el resto de nosotros.>"

    # game/beyond the bet/day9dlc.rpy:1627
    old "1. <That could be my new nickname.>"
    new "1. <Ese podría ser mi nuevo apodo.>"

    # game/beyond the bet/day9dlc.rpy:1630
    old "1. <Ice Cold Sunshine.>"
    new "1. <Solecito Gélido.>"

    # game/beyond the bet/day9dlc.rpy:1637
    old "1. <Your loss.>"
    new "1. <Tú te lo pierdes.>"

    # game/beyond the bet/day9dlc.rpy:1640
    old "2. <Actually, I do really feel a tiny bit bad.>"
    new "2. <En realidad, sí me siento un poquito mal.>"

    # game/beyond the bet/day9dlc.rpy:1642
    old "1. <But at the end of the day, it's probably for the best.>"
    new "1. <Pero al final del día, probablemente sea lo mejor.>"

    # game/beyond the bet/day9dlc.rpy:1644
    old "1. <Thinking about the past is hard, but...>"
    new "1. <Pensar en el pasado es difícil, pero...>"

    # game/beyond the bet/day9dlc.rpy:1647
    old "1. <It's good to understand where you come from.>"
    new "1. <Es bueno entender de dónde vienes.>"

    # game/beyond the bet/day9dlc.rpy:1650
    old "1. <Then you can decide what you want to do with yourself.>"
    new "1. <Así puedes decidir qué quieres hacer contigo.>"

    # game/beyond the bet/day9dlc.rpy:1653
    old "2. <The past can be painful.>"
    new "2. <El pasado puede ser doloroso.>"

    # game/beyond the bet/day9dlc.rpy:1655
    old "1. <But I'll be here for you through learning \nabout it. I promise.>"
    new "1. <Pero estaré a tu lado mientras lo descubres. Te lo prometo.>"

    # game/beyond the bet/day9dlc.rpy:1663
    old "2. <Sorry, I'm allergic to guilt.>"
    new "2. <Perdón, la culpa me da alergia.>"

    # game/beyond the bet/day9dlc.rpy:1665
    old "1. <Ah... ah...>"
    new "1. <Ah... ah...>"

    # game/beyond the bet/day9dlc.rpy:1668
    old "1. <Achoo!>"
    new "1. <¡Achís!>"

    # game/beyond the bet/day9dlc.rpy:1673
    old "1. <Wait, why are you sneezing?>"
    new "1. <Espera, ¿por qué estornudas?>"

    # game/beyond the bet/day9dlc.rpy:1678
    old "1. <Damn.>"
    new "1. <Maldición.>"

    # game/beyond the bet/day9dlc.rpy:1681
    old "1. <That's an unfortunate allergy to have around me.>"
    new "1. <Qué mala suerte tener esa alergia estando cerca de mí.>"

    # game/beyond the bet/day9dlc.rpy:1691
    old "1. <Well, you went and said something serious. \nI was gonna say...>"
    new "1. <Bueno, ahora que te has puesto serio... Yo iba a decir...>"

    # game/beyond the bet/day9dlc.rpy:1694
    old "1. <Clowns.>"
    new "1. <Payasos.>"

    # game/beyond the bet/day9dlc.rpy:1696
    old "1. <There's something terrifying about them, but honestly...>"
    new "1. <Hay algo aterrador en ellos, pero, sinceramente...>"

    # game/beyond the bet/day9dlc.rpy:1699
    old "1. <I don't see many clowns in my life.>"
    new "1. <No me encuentro con muchos payasos en mi vida.>"

    # game/beyond the bet/day9dlc.rpy:1703
    old "1. <That's why I had that clown-y outfit I loaned you.>"
    new "1. <Por eso tenía ese atuendo de payaso que te presté.>"

    # game/beyond the bet/day9dlc.rpy:1706
    old "1. <Exposure therapy, or something.>"
    new "1. <Terapia de exposición, o algo así.>"

    # game/beyond the bet/day9dlc.rpy:1709
    old "2. <Centipedes.>"
    new "2. <Ciempiés.>"

    # game/beyond the bet/day9dlc.rpy:1711
    old "1. <Nothing should have that many legs.>"
    new "1. <Nada debería tener tantas patas.>"

    # game/beyond the bet/day9dlc.rpy:1714
    old "3. <Quicksand.>"
    new "3. <Arenas movedizas.>"

    # game/beyond the bet/day9dlc.rpy:1716
    old "1. <When I was a kid, I greatly overestimated how \nmuch quicksand I would encounter.>"
    new "1. <Cuando era niñ[letra], sobrestimé enormemente cuántas arenas movedizas me encontraría.>"

    # game/beyond the bet/day9dlc.rpy:1719
    old "4. <Seaweed.>"
    new "4. <Algas.>"

    # game/beyond the bet/day9dlc.rpy:1721
    old "1. <Not only is it slimy and gross...>"
    new "1. <No solo es viscosa y asquerosa...>"

    # game/beyond the bet/day9dlc.rpy:1724
    old "1. <When I was a kid, I thought it was going to grab \nme and pull me underwater.>"
    new "1. <Cuando era niñ[letra], pensaba que me iba a agarrar y arrastrar bajo el agua.>"

    # game/beyond the bet/day9dlc.rpy:1727
    old "1. <Not a fan.>"
    new "1. <No me gustan.>"

    # game/beyond the bet/day9dlc.rpy:1730
    old "1. <But, something more serious...>"
    new "1. <Pero, algo más serio...>"

    # game/beyond the bet/day9dlc.rpy:1733
    old "1. <I'm scared of losing the people most important to me.>"
    new "1. <Me da miedo perder a las personas más importantes para mí.>"

    # game/beyond the bet/day9dlc.rpy:1736
    old "1. <I feel like I've lost a lot of important \npeople throughout my life...>"
    new "1. <Siento que he perdido a muchas personas importantes a lo largo de mi vida...>"

    # game/beyond the bet/day9dlc.rpy:1739
    old "1. <I don't want to lose you too.>"
    new "1. <No quiero perderte a ti también.>"

    # game/beyond the bet/day9dlc.rpy:1748
    old "2. <I'm scared of missing the little things in life.>"
    new "2. <Me da miedo perderme las pequeñas cosas de la vida.>"

    # game/beyond the bet/day9dlc.rpy:1751
    old "1. <Seeing my breath on a cold winter morning...>"
    new "1. <Ver mi aliento en una fría mañana de invierno...>"

    # game/beyond the bet/day9dlc.rpy:1754
    old "1. <Smelling the flowers that you bring me...>"
    new "1. <Oler las flores que me traes...>"

    # game/beyond the bet/day9dlc.rpy:1757
    old "1. <Staying up late playing my favorite games...>"
    new "1. <Desvelarme jugando mis juegos favoritos...>"

    # game/beyond the bet/day9dlc.rpy:1760
    old "1. <I want to enjoy the little things for as long as I can.>"
    new "1. <Quiero disfrutar de las pequeñas cosas mientras pueda.>"

    # game/beyond the bet/day9dlc.rpy:1768
    old "3. <I'm scared of leaving nothing behind to be \nremembered by.>"
    new "3. <Me da miedo no dejar nada atrás por lo que me recuerden.>"

    # game/beyond the bet/day9dlc.rpy:1771
    old "1. <Which is inevitable, I suppose.>"
    new "1. <Lo cual es inevitable, supongo.>"

    # game/beyond the bet/day9dlc.rpy:1774
    old "1. <One day everything will be gone, but...>"
    new "1. <Un día todo desaparecerá, pero...>"

    # game/beyond the bet/day9dlc.rpy:1777
    old "1. <I want to create something.>"
    new "1. <Quiero crear algo.>"

    # game/beyond the bet/day9dlc.rpy:1780
    old "1. <Some kind of... change.>"
    new "1. <Algún tipo de... cambio.>"

    # game/beyond the bet/day9dlc.rpy:1783
    old "1. <Something to leave this world a better \nplace than I found it.>"
    new "1. <Algo que deje este mundo en mejor lugar del que lo encontré.>"

    # game/beyond the bet/day9dlc.rpy:1791
    old "4. <I'm scared of not taking enough risks.>"
    new "4. <Me da miedo no arriesgarme lo suficiente.>"

    # game/beyond the bet/day9dlc.rpy:1794
    old "1. <I think I'm too risk averse.>"
    new "1. <Creo que soy demasiado reaci[letra] al riesgo.>"

    # game/beyond the bet/day9dlc.rpy:1797
    old "1. <But sometimes, a risk is what you need to take \nto make things better.>"
    new "1. <Pero a veces, un riesgo es lo que necesitas asumir para mejorar las cosas.>"

    # game/beyond the bet/day9dlc.rpy:1810
    old "1. <...Thanks, Casper.>"
    new "1. <...Gracias, Casper.>"

    # game/beyond the bet/day9dlc.rpy:1815
    old "1. <What are you sighing about now?>"
    new "1. <¿Por qué suspiras ahora?>"

    # game/beyond the bet/day9dlc.rpy:1820
    old "1. <About...?>"
    new "1. <¿Por...?>"

    # game/beyond the bet/day9dlc.rpy:1825
    old "1. <Time for...?>"
    new "1. <¿Hora de...?>"

    # game/beyond the bet/day9dlc.rpy:1829
    old "1. <I think it's time for plenty.>"
    new "1. <Creo que es hora de muchas cosas.>"

    # game/beyond the bet/day9dlc.rpy:1832
    old "1. <Breathing, for one.>"
    new "1. <Respirar, por ejemplo.>"

    # game/beyond the bet/day9dlc.rpy:1835
    old "1. <It's always time for breathing.>"
    new "1. <Siempre es hora de respirar.>"

    # game/beyond the bet/day9dlc.rpy:1839
    old "2. <S.... soul baby time...?>"
    new "2. <H... ¿hora del bebé alma...?>"

    # game/beyond the bet/day9dlc.rpy:1846
    old "1. <Those are the words of someone who's giving up.>"
    new "1. <Esas son palabras de alguien que se rinde.>"

    # game/beyond the bet/day9dlc.rpy:1849
    old "1. <A... give-r up-erer.>"
    new "1. <Un... rendi-dor.>"

    # game/beyond the bet/day9dlc.rpy:1854
    old "1. <Yeah. It is.>"
    new "1. <Sí. Lo es.>"

    # game/beyond the bet/day9dlc.rpy:1857
    old "1. <Then, time for what?>"
    new "1. <Entonces, ¿hora de qué?>"

    # game/beyond the bet/day9dlc.rpy:1871
    old "1. <Well, we have some time now.>"
    new "1. <Bueno, ahora tenemos algo de tiempo.>"

    # game/beyond the bet/day9dlc.rpy:1874
    old "1. <What did you want to know?>"
    new "1. <¿Qué querías saber?>"

    # game/beyond the bet/day9dlc.rpy:1879
    old "1. <Well, gotta start somewhere.>"
    new "1. <Bueno, hay que empezar por algo.>"

    # game/beyond the bet/day9dlc.rpy:1881
    old "2. <E... everything...?>"
    new "2. <T... ¿todo...?>"

    # game/beyond the bet/day9dlc.rpy:1890
    old "1. <Ooooh. That's a good question.>"
    new "1. <Ooooh. Esa es una buena pregunta.>"

    # game/beyond the bet/day9dlc.rpy:1893
    old "1. <I can think of so many things.>"
    new "1. <Se me ocurren tantas cosas.>"

    # game/beyond the bet/day9dlc.rpy:1895
    old "1. <If I had to settle on one, maybe...>"
    new "1. <Si tuviera que quedarme con una, quizás...>"

    # game/beyond the bet/day9dlc.rpy:1897
    old "2. <A tough one, too.>"
    new "2. <Y además, es difícil.>"

    # game/beyond the bet/day9dlc.rpy:1899
    old "1. <I think it has to be...>"
    new "1. <Creo que tiene que ser...>"

    # game/beyond the bet/day9dlc.rpy:1902
    old "1. <Chocolate!>"
    new "1. <¡Chocolate!>"

    # game/beyond the bet/day9dlc.rpy:1904
    old "1. <It seems a little obvious, I know.>"
    new "1. <Parece un poco obvio, lo sé.>"

    # game/beyond the bet/day9dlc.rpy:1907
    old "1. <But that would be because it's the correct answer.>"
    new "1. <Pero eso sería porque es la respuesta correcta.>"

    # game/beyond the bet/day9dlc.rpy:1912
    old "1. <Can I just have all?>"
    new "1. <¿Puedo quedarme con todos?>"

    # game/beyond the bet/day9dlc.rpy:1925
    old "1. <Gosh I hope so.>"
    new "1. <Cielos, espero que sí.>"

    # game/beyond the bet/day9dlc.rpy:1928
    old "2. <Anything with cheese.>"
    new "2. <Cualquier cosa con queso.>"

    # game/beyond the bet/day9dlc.rpy:1930
    old "1. <I'm so glad I'm not lactose intolerant.>"
    new "1. <Me alegra tanto no ser intolerante a la lactosa.>"

    # game/beyond the bet/day9dlc.rpy:1932
    old "1. <That would be... shitty.>"
    new "1. <Eso sería... una mierda.>"

    # game/beyond the bet/day9dlc.rpy:1935
    old "1. <Ba dum tss.>"
    new "1. <Ba dum tss.>"

    # game/beyond the bet/day9dlc.rpy:1945
    old "1. <You know, there's a part of you that seems \nlike a red wine and expensive cheese guy.>"
    new "1. <Sabes, hay una parte de ti que parece de los que toman vino tinto y queso caro.>"

    # game/beyond the bet/day9dlc.rpy:1948
    old "1. <But then on the other hand... your diet is cheap, \ncup noodles.>"
    new "1. <Pero por otro lado... tu dieta son fideos instantáneos baratos.>"

    # game/beyond the bet/day9dlc.rpy:1951
    old "1. <You're really a plastic cheese kinda guy, aren't you?>"
    new "1. <De verdad eres de los de queso de plástico, ¿no?>"

    # game/beyond the bet/day9dlc.rpy:1959
    old "1. <I'd be happy to give you my ranking of the \ntop 20 cheeses some time.>"
    new "1. <Con gusto te daré algún día mi ranking de los 20 mejores quesos.>"

    # game/beyond the bet/day9dlc.rpy:1964
    old "1. <It's a date, then.>"
    new "1. <Es una cita, entonces.>"

    # game/beyond the bet/day9dlc.rpy:1967
    old "2. <I'm... lactose intolerant... but it's worth it.>"
    new "2. <Soy... intolerante a la lactosa... pero vale la pena.>"

    # game/beyond the bet/day9dlc.rpy:1971
    old "1. <For cheese, yes.>"
    new "1. <Por el queso, sí.>"

    # game/beyond the bet/day9dlc.rpy:1974
    old "1. <Cheese makes almost anything better.>"
    new "1. <El queso mejora casi cualquier cosa.>"

    # game/beyond the bet/day9dlc.rpy:1979
    old "1. <It's a risk worth taking.>"
    new "1. <Es un riesgo que vale la pena correr.>"

    # game/beyond the bet/day9dlc.rpy:1986
    old "1. <Once again... I'm practically a super hero.>"
    new "1. <Una vez más... soy prácticamente un superhéroe.>"

    # game/beyond the bet/day9dlc.rpy:1989
    old "3. <Pickles.>"
    new "3. <Pepinillos.>"

    # game/beyond the bet/day9dlc.rpy:1993
    old "1. <Is there something wrong with pickles?>"
    new "1. <¿Hay algo malo con los pepinillos?>"

    # game/beyond the bet/day9dlc.rpy:1998
    old "1. <Okay, okay, Mr Pickle Hater.>"
    new "1. <Okey, okey, Señor Odia-Pepinillos.>"

    # game/beyond the bet/day9dlc.rpy:2001
    old "1. <You just can't handle the crunch.>"
    new "1. <Es que no soportas el crujido.>"

    # game/beyond the bet/day9dlc.rpy:2003
    old "2. <Your palate just isn't as developed as mine.>"
    new "2. <Tu paladar simplemente no está tan desarrollado como el mío.>"

    # game/beyond the bet/day9dlc.rpy:2008
    old "1. <Hey. I could grab some now. It'd be like...>"
    new "1. <Oye. Podría traer algunos ahora. Sería como...>"

    # game/beyond the bet/day9dlc.rpy:2011
    old "1. <Pickle ASMR.>"
    new "1. <ASMR de pepinillos.>"

    # game/beyond the bet/day9dlc.rpy:2017
    old "1. <I don't, really. But it would be funny.>"
    new "1. <No me gustan, en realidad. Pero sería gracioso.>"

    # game/beyond the bet/day9dlc.rpy:2020
    old "1. <You really don't like them?>"
    new "1. <¿De verdad no te gustan?>"

    # game/beyond the bet/day9dlc.rpy:2027
    old "1. <A pickle is an upgraded cucumber.>"
    new "1. <Un pepinillo es un pepino mejorado.>"

    # game/beyond the bet/day9dlc.rpy:2030
    old "1. <Isn't evolution beautiful?>"
    new "1. <¿No es hermosa la evolución?>"

    # game/beyond the bet/day9dlc.rpy:2033
    old "4. <Strawberries!>"
    new "4. <¡Fresas!>"

    # game/beyond the bet/day9dlc.rpy:2035
    old "1. <With sugar and cream...>"
    new "1. <Con azúcar y crema...>"

    # game/beyond the bet/day9dlc.rpy:2037
    old "2. <Dipped in chocolate, of course.>"
    new "2. <Bañados en chocolate, por supuesto.>"

    # game/beyond the bet/day9dlc.rpy:2039
    old "1. <Mmm... strawberries and melted chocolate...>"
    new "1. <Mmm... fresas y chocolate derretido...>"

    # game/beyond the bet/day9dlc.rpy:2041
    old "2. <Then in the fridge until they set.>"
    new "2. <Luego, a la nevera hasta que el chocolate se endurezca.>"

    # game/beyond the bet/day9dlc.rpy:2043
    old "3. <They don't even need anything on them.>"
    new "3. <Ni siquiera necesitan nada encima.>"

    # game/beyond the bet/day9dlc.rpy:2050
    old "1. <You did?>"
    new "1. <¿Lo hiciste?>"

    # game/beyond the bet/day9dlc.rpy:2059
    old "1. <Casper, that's kinda morbid.>"
    new "1. <Casper, eso es un poco macabro.>"

    # game/beyond the bet/day9dlc.rpy:2065
    old "1. <Anyway, what about you, Casper?>"
    new "1. <En fin, ¿y tú, Casper?>"

    # game/beyond the bet/day9dlc.rpy:2068
    old "1. <You can't say noodles!>"
    new "1. <¡No puedes decir fideos!>"

    # game/beyond the bet/day9dlc.rpy:2071
    old "1. <Anything else.>"
    new "1. <Cualquier otra cosa.>"

    # game/beyond the bet/day9dlc.rpy:2078
    old "1. <Just... bread?>"
    new "1. <¿Solo... pan?>"

    # game/beyond the bet/day9dlc.rpy:2080
    old "2. <Like, a sandwich?>"
    new "2. <¿Como, un sándwich?>"

    # game/beyond the bet/day9dlc.rpy:2092
    old "1. <Folded... bread...?>"
    new "1. <¿Pan... doblado...?>"

    # game/beyond the bet/day9dlc.rpy:2098
    old "1. <A sandwich with nothing in it?>"
    new "1. <¿Un sándwich sin nada dentro?>"

    # game/beyond the bet/day9dlc.rpy:2102
    old "1. <A nothing sandwich.>"
    new "1. <Un sándwich de nada.>"

    # game/beyond the bet/day9dlc.rpy:2107
    old "1. <Surely it tastes the same folded or not.>"
    new "1. <Seguro que sabe igual doblado o no.>"

    # game/beyond the bet/day9dlc.rpy:2110
    old "1. <Grimmy, that's very strange.>"
    new "1. <Parquita, eso es muy raro.>"

    # game/beyond the bet/day9dlc.rpy:2112
    old "2. <Well, I guess it could be weirder.>"
    new "2. <Bueno, supongo que podría ser más raro.>"

    # game/beyond the bet/day9dlc.rpy:2115
    old "1. <When we move in together, I am going to introduce you to so much food.>"
    new "1. <Cuando nos mudemos juntos, te voy a presentar tanta comida.>"

    # game/beyond the bet/day9dlc.rpy:2120
    old "1. <I feel like I have a moral obligation to get \nyou to eat better.>"
    new "1. <Siento que tengo la obligación moral de hacer que comas mejor.>"

    # game/beyond the bet/day9dlc.rpy:2123
    old "1. <But, going back to noodles...>"
    new "1. <Pero, volviendo a los fideos...>"

    # game/beyond the bet/day9dlc.rpy:2126
    old "1. <What flavors do you like, anyway?>"
    new "1. <¿Qué sabores te gustan, por cierto?>"

    # game/beyond the bet/day9dlc.rpy:2131
    old "1. <What makes that an age old question???>"
    new "1. <¿¿¿Qué hace que sea una pregunta de siempre???>"

    # game/beyond the bet/day9dlc.rpy:2135
    old "1. <I feel like it's only as old as noodles existing.>"
    new "1. <Siento que solo es tan antigua como la existencia de los fideos.>"

    # game/beyond the bet/day9dlc.rpy:2142
    old "1. <And...?>"
    new "1. <¿Y...?>"

    # game/beyond the bet/day9dlc.rpy:2144
    old "2. <I bet you like plain chicken noodles.>"
    new "2. <Apuesto a que te gustan los fideos de pollo sencillos.>"

    # game/beyond the bet/day9dlc.rpy:2148
    old "1. <Ooooh, Grimmy is getting a little spicy.>"
    new "1. <Ooooh, Parquita se está poniendo un poco picante.>"

    # game/beyond the bet/day9dlc.rpy:2150
    old "2. <Not a bad choice.>"
    new "2. <No está mal la elección.>"

    # game/beyond the bet/day9dlc.rpy:2155
    old "1. <How can a mouth be alight?>"
    new "1. <¿Cómo puede una boca estar encendida?>"

    # game/beyond the bet/day9dlc.rpy:2160
    old "1. <Not one I've ever heard before.>"
    new "1. <No es una que haya oído antes.>"

    # game/beyond the bet/day9dlc.rpy:2165
    old "1. <{i}Give Casper a drum roll.{/i}>"
    new "1. <{i}Hacerle un redoble de tambores a Casper.{/i}>"

    # game/beyond the bet/day9dlc.rpy:2170
    old "1. <Original...?>"
    new "1. <¿Original...?>"

    # game/beyond the bet/day9dlc.rpy:2172
    old "2. <Really...?>"
    new "2. <¿De verdad...?>"

    # game/beyond the bet/day9dlc.rpy:2174
    old "3. <Oh my god.>"
    new "3. <Oh, dios mío.>"

    # game/beyond the bet/day9dlc.rpy:2177
    old "1. <Of course it's original.>"
    new "1. <Por supuesto que es el original.>"

    # game/beyond the bet/day9dlc.rpy:2180
    old "1. <You're so basic sometimes.>"
    new "1. <A veces eres tan básico.>"

    # game/beyond the bet/day9dlc.rpy:2182
    old "2. <To be honest, that's my favorite too.>"
    new "2. <Sinceramente, ese también es mi favorito.>"

    # game/beyond the bet/day9dlc.rpy:2184
    old "3. <Original is pretty good, though.>"
    new "3. <El original está bastante bueno, sin embargo.>"

    # game/beyond the bet/day9dlc.rpy:2190
    old "1. <When we live together, I'll get the shelves \nstocked with original noodles. Got it.>"
    new "1. <Cuando vivamos juntos, llenaré los estantes con fideos originales. Entendido.>"

    # game/beyond the bet/day9dlc.rpy:2198
    old "1. <Awww.>"
    new "1. <Awww.>"

    # game/beyond the bet/day9dlc.rpy:2200
    old "2. <I'm nearly swooning.>"
    new "2. <Casi me desmayo.>"

    # game/beyond the bet/day9dlc.rpy:2203
    old "1. <It's almost romantic, but then I remember \nwe're talking about noodles.>"
    new "1. <Es casi romántico, pero luego recuerdo que estamos hablando de fideos.>"

    # game/beyond the bet/day9dlc.rpy:2208
    old "1. <Okay, I gotta hear the explanation for this one.>"
    new "1. <Okey, tengo que oír la explicación de esto.>"

    # game/beyond the bet/day9dlc.rpy:2212
    old "2. <We could name our soul baby 'Original'.>"
    new "2. <Podríamos llamar a nuestro bebé alma 'Original'.>"

    # game/beyond the bet/day9dlc.rpy:2215
    old "1. <It's a little unconventional, but it is...>"
    new "1. <Es poco convencional, pero es...>"

    # game/beyond the bet/day9dlc.rpy:2218
    old "1. <Original.>"
    new "1. <Original.>"

    # game/beyond the bet/day9dlc.rpy:2228
    old "1. <You're starting to sound like you agree they exist.>"
    new "1. <Empiezas a hablar como si admitieras que existen.>"

    # game/beyond the bet/day9dlc.rpy:2234
    old "3. <I know one that could beat the original.>"
    new "3. <Conozco uno que podría vencer al original.>"

    # game/beyond the bet/day9dlc.rpy:2236
    old "1. <Teriyaki chicken flavor.>"
    new "1. <Sabor pollo teriyaki.>"

    # game/beyond the bet/day9dlc.rpy:2238
    old "2. <Curry flavor.>"
    new "2. <Sabor curry.>"

    # game/beyond the bet/day9dlc.rpy:2244
    old "1. <Ah, yes.>"
    new "1. <Ah, sí.>"

    # game/beyond the bet/day9dlc.rpy:2247
    old "1. <The cup-noodle eating, white bread snacking \nreaper out here with the refined tastebuds.>"
    new "1. <La Parca que come fideos instantáneos y pan blanco con papilas gustativas refinadas, por aquí.>"

    # game/beyond the bet/day9dlc.rpy:2252
    old "1. <Sorry. I spend so much time talking to you, you're starting to rub off on me.>"
    new "1. <Perdón. Paso tanto tiempo hablando contigo que se me está pegando.>"

    # game/beyond the bet/day9dlc.rpy:2255
    old "1. <Actually, if we're asking random questions, there \nwas something I wanted to know.>"
    new "1. <En realidad, ya que estamos haciendo preguntas al azar, había algo que quería saber.>"

    # game/beyond the bet/day9dlc.rpy:2260
    old "1. <How did you get your scythe?>"
    new "1. <¿Cómo conseguiste tu guadaña?>"

    # game/beyond the bet/day9dlc.rpy:2263
    old "1. <Not gonna lie, it's pretty cool.>"
    new "1. <No voy a mentir, es bastante genial.>"

    # game/beyond the bet/day9dlc.rpy:2265
    old "2. <I kinda want one.>"
    new "2. <Como que quiero una.>"

    # game/beyond the bet/day9dlc.rpy:2271
    old "1. <Can I have yours?>"
    new "1. <¿Puedo tener la tuya?>"

    # game/beyond the bet/day9dlc.rpy:2274
    old "2. <I've seen them for sale around Halloween time, though.>"
    new "2. <Aunque las he visto a la venta por Halloween.>"

    # game/beyond the bet/day9dlc.rpy:2291
    old "1. <Man, that's so cool.>"
    new "1. <Oye, qué genial.>"

    # game/beyond the bet/day9dlc.rpy:2293
    old "2. <I gotta get me one of those.>"
    new "2. <Tengo que conseguirme una de esas.>"

    # game/beyond the bet/day9dlc.rpy:2299
    old "1. <They should.>"
    new "1. <Deberían.>"

    # game/beyond the bet/day9dlc.rpy:2301
    old "1. <Maybe that could be my new side hustle.>"
    new "1. <Quizás eso podría ser mi nuevo trabajo extra.>"

    # game/beyond the bet/day9dlc.rpy:2304
    old "1. <I'm gonna be rich, Grimmy.>"
    new "1. <Me voy a hacer millonari[letra], Parquita.>"

    # game/beyond the bet/day9dlc.rpy:2309
    old "2. <Hopefully you do.>"
    new "2. <Ojalá lo hagas.>"

    # game/beyond the bet/day9dlc.rpy:2314
    old "1. <Come in mortals~>"
    new "1. <Entren, mortales~>"

    # game/beyond the bet/day9dlc.rpy:2358
    old "1. <Casper, the call disconnected!>"
    new "1. <¡Casper, la llamada se desconectó!>"

    # game/beyond the bet/day9dlc.rpy:2361
    old "1. <Why is it RED?>"
    new "1. <¿POR QUÉ está en ROJO?>"

    # game/beyond the bet/day9dlc.rpy:2363
    old "2. <Something is wrong with your app, Grimmy...>"
    new "2. <Algo le pasa a tu aplicación, Parquita...>"

    # game/beyond the bet/day9dlc.rpy:2366
    old "1. <Wait, did you hang up on me?>"
    new "1. <Espera, ¿me colgaste?>"

    # game/beyond the bet/day9dlc.rpy:2369
    old "1. <Hellloooo?>"
    new "1. <¿¿Holaaaa??>"

    # game/beyond the bet/day9dlc.rpy:2384
    old "1. <Who are you?>"
    new "1. <¿Quién eres?>"

    # game/beyond the bet/day9dlc.rpy:2392
    old "1. <You're a... Grim Reaper?>"
    new "1. <¿Eres... una Parca?>"

    # game/beyond the bet/day9dlc.rpy:2398
    old "1. <You think you can just threaten me?>"
    new "1. <¿Crees que puedes simplemente amenazarme?>"

    # game/beyond the bet/day9dlc.rpy:2401
    old "2. <Why are you doing this?>"
    new "2. <¿Por qué haces esto?>"

    # game/beyond the bet/day9dlc.rpy:2410
    old "1. <I'll never bow down to your stupid system.>"
    new "1. <Jamás me someteré a tu estúpido sistema.>"

    # game/beyond the bet/day9dlc.rpy:2416
    old "2. <I won't let you take our future!>"
    new "2. <¡No dejaré que te lleves nuestro futuro!>"

    # game/beyond the bet/day9dlc.rpy:2422
    old "3. <...If I do, will you let Casper go?>"
    new "3. <...Si lo hago, ¿dejarás ir a Casper?>"

    # game/beyond the bet/day9dlc.rpy:2429
    old "1. <I won't do anything for a 'perhaps'.>"
    new "1. <No haré nada por un 'quizás'.>"

    # game/beyond the bet/day9dlc.rpy:2436
    old "1. <WAIT!>"
    new "1. <¡ESPERA!>"

    # game/beyond the bet/day9dlc.rpy:2439
    old "1. <Please, just leave Casper alone!>"
    new "1. <¡Por favor, deja a Casper en paz!>"

    # game/beyond the bet/day9dlc.rpy:2441
    old "2. <Just leave us alone!>"
    new "2. <¡Déjanos en paz!>"

    # game/beyond the bet/day9dlc.rpy:2478
    old "1. <{i}Stay very still.{/i}>"
    new "1. <{i}No moverte ni un centímetro.{/i}>"

    # game/beyond the bet/day9dlc.rpy:2480
    old "2. <{i}Get down low.{/i}>"
    new "2. <{i}Agacharte.{/i}>"

    # game/beyond the bet/day9dlc.rpy:2487
    old "1. <...?>"
    new "1. <...?>"

    # game/beyond the bet/day9dlc.rpy:2497
    old "1. <What's your axolotl called?>"
    new "1. <¿Cómo se llama tu ajolote?>"

    # game/beyond the bet/day9dlc.rpy:2501
    old "1. <Answer the question, then I'll open the door.>"
    new "1. <Responde la pregunta y luego abriré la puerta.>"

    # game/beyond the bet/day9dlc.rpy:2508
    old "1. <I've never heard the rest of his name!>"
    new "1. <¡Nunca había oído su nombre completo!>"

    # game/beyond the bet/day9dlc.rpy:2516
    old "1. <Shhh!>"
    new "1. <¡Shhh!>"

    # game/beyond the bet/day9dlc.rpy:2520
    old "1. <Someone else messaged me.>"
    new "1. <Alguien más me escribió.>"

    # game/beyond the bet/day9dlc.rpy:2525
    old "1. <{i}Show Casper the messages.{/i}>"
    new "1. <{i}Mostrarle los mensajes a Casper.{/i}>"

    # game/beyond the bet/day9dlc.rpy:2532
    old "1. <What do we do?>"
    new "1. <¿Qué hacemos?>"

    # game/beyond the bet/day9dlc.rpy:2534
    old "2. <I don't want anything bad to happen to you...>"
    new "2. <No quiero que te pase nada malo...>"

    # game/beyond the bet/day9dlc.rpy:2541
    old "1. <You always find me so easily. Where could be safe?>"
    new "1. <Siempre me encuentras con tanta facilidad. ¿Dónde estaría a salvo?>"

    # game/beyond the bet/day9dlc.rpy:2543
    old "2. <Is there... some kind of safe house? A hideout we could use?>"
    new "2. <¿Hay... algún tipo de refugio? ¿Un escondite que podamos usar?>"

    # game/beyond the bet/day9dlc.rpy:2552
    old "1. <I love terrible ideas.>"
    new "1. <Me encantan las malas ideas.>"

    # game/beyond the bet/day9dlc.rpy:2554
    old "2. <Hit me with it.>"
    new "2. <Dime.>"

    # game/beyond the bet/day9dlc.rpy:2559
    old "1. <Wow, you're using this as a chance to flirt?>"
    new "1. <Wow, ¿estás aprovechando esto para coquetear?>"

    # game/beyond the bet/day9dlc.rpy:2561
    old "2. <Your place...? Grimmy...>"
    new "2. <¿Tu casa...? Parquita...>"

    # game/beyond the bet/day9dlc.rpy:2568
    old "1. <What about [pet_name]?>"
    new "1. <¿Y [pet_name]?>"

    # game/beyond the bet/day9dlc.rpy:2575
    old "1. <Let me pack a few things.>"
    new "1. <Déjame empacar unas cosas.>"

    # game/beyond the bet/day9dlc.rpy:2577
    old "2. <This is so sudden...>"
    new "2. <Esto es tan repentino...>"

    # game/beyond the bet/day9dlc.rpy:2579
    old "1. <Alright, let me grab some stuff.>"
    new "1. <Bueno, déjame agarrar algunas cosas.>"

    # game/beyond the bet/day9dlc.rpy:2585
    old "1. <Okay, I'm good to go.>"
    new "1. <Okey, ya tengo todo.>"

    # game/beyond the bet/day9dlc.rpy:2588
    old "1. <I can't believe I'm going to the UNDERWORLD.>"
    new "1. <No puedo creer que voy al INFRAMUNDO.>"

    # game/beyond the bet/day9dlc.rpy:2591
    old "1. <This is cool as fuck.>"
    new "1. <Esto es genial.>"

    # game/beyond the bet/day9dlc.rpy:2593
    old "2. <I can't even imagine what it'll look like...>"
    new "2. <Ni siquiera puedo imaginar cómo será...>"

    # game/beyond the bet/day9dlc.rpy:2600
    old "1. <How do we actually get there?>"
    new "1. <¿Cómo se llega allí realmente?>"

    # game/beyond the bet/day9dlc.rpy:2605
    old "1. <WE WHAT?>"
    new "1. <¿NOSOTROS QUÉ?>"

    # game/beyond the bet/day9dlc.rpy:2611
    old "1. <Watching you scramble over my desk is hilarious, you know.>"
    new "1. <Verte trepar por mi escritorio es hilarante, ¿sabes?>"

    # game/beyond the bet/day9dlc.rpy:2616
    old "1. <{i}Take his hand.{/i}>"
    new "1. <{i}Tomar su mano.{/i}>"

    # game/beyond the bet/day9dlc.rpy:2632
    old "1. <{i}You look down at him.{/i}>"
    new "1. <{i}Bajas la mirada hacia él.{/i}>"

    # game/beyond the bet/day9dlc.rpy:2634
    old "1. <You're so short.>"
    new "1. <Eres tan bajito.>"

    # game/beyond the bet/day9dlc.rpy:2639
    old "2. <{i}You look up at him.{/i}>"
    new "2. <{i}Alzas la mirada hacia él.{/i}>"

    # game/beyond the bet/day9dlc.rpy:2641
    old "1. <My knight in shining armor~>"
    new "1. <Mi caballero de brillante armadura~>"

    # game/beyond the bet/day9dlc.rpy:2646
    old "1. <Didn't you say you'd never take me flying, by the way?!>"
    new "1. <¡¿No dijiste que nunca me llevarías a volar, por cierto?!>"

    # game/beyond the bet/day9dlc.rpy:2655
    old "1. <This is amazing!>"
    new "1. <¡Esto es increíble!>"

    # game/beyond the bet/day9dlc.rpy:2658
    old "1. <Wait, can people see us?>"
    new "1. <Espera, ¿nos puede ver la gente?>"

    # game/beyond the bet/day9dlc.rpy:2662
    old "1. <I don't like the way you're saying that.>"
    new "1. <No me gusta cómo suena eso cuando lo dices.>"

    # game/beyond the bet/day9dlc.rpy:2670
    old "1. <If I'm on the morning news, it'll be all your fault.>"
    new "1. <Si salgo en las noticias de la mañana, será toda tu culpa.>"

    # game/beyond the bet/day9dlc.rpy:2691
    old "1. <Holy shit!>"
    new "1. <¡Mierda!>"

    # game/beyond the bet/day9dlc.rpy:2693
    old "2. <A word of warning would've been nice!>"
    new "2. <¡Una advertencia habría estado bien!>"

    # game/beyond the bet/day9dlc.rpy:2713
    old "1. <You're scared.>"
    new "1. <Tienes miedo.>"

    # game/beyond the bet/day9dlc.rpy:2716
    old "2. <Are you doing alright, Casper?>"
    new "2. <¿Estás bien, Casper?>"

    # game/beyond the bet/day9dlc.rpy:2722
    old "3. <We'll figure it out.>"
    new "3. <Lo resolveremos.>"

    # game/beyond the bet/day9dlc.rpy:2735
    old "1. <You know, Casper...>"
    new "1. <Sabes, Casper...>"

    # game/beyond the bet/day9dlc.rpy:2738
    old "1. <There's one thing I'm really good at.>"
    new "1. <Hay una cosa que se me da muy bien.>"

    # game/beyond the bet/day9dlc.rpy:2745
    old "1. <I wasn't even going to make a joke!>"
    new "1. <¡Ni siquiera iba a hacer un chiste!>"

    # game/beyond the bet/day9dlc.rpy:2747
    old "2. <Well, yes...>"
    new "2. <Bueno, sí...>"

    # game/beyond the bet/day9dlc.rpy:2749
    old "1. <But that wasn't what I was going for.>"
    new "1. <Pero no iba por ahí.>"

    # game/beyond the bet/day9dlc.rpy:2752
    old "1. <It's avoiding death. Ya know, it's kinda my thing.>"
    new "1. <Es evitar la muerte. Ya sabes, es un poco lo mío.>"

    # game/beyond the bet/day9dlc.rpy:2755
    old "1. <Since we're so wrapped up together now, maybe you'll get a bit of my good luck.>"
    new "1. <Ya que ahora estamos tan unidos, quizás te contagies un poco de mi buena suerte.>"

    # game/beyond the bet/day9dlc.rpy:2761
    old "1. <It's one of my charm points.>"
    new "1. <Es uno de mis encantos.>"

    # game/beyond the bet/day9dlc.rpy:2763
    old "2. <You've always loved it.>"
    new "2. <Siempre te ha encantado.>"

    # game/beyond the bet/day9dlc.rpy:2768
    old "1. <I keep you on your toes, huh?>"
    new "1. <Siempre te mantengo alerta, ¿eh?>"

    # game/beyond the bet/day9dlc.rpy:2773
    old "1. <Putting that aside, though...>"
    new "1. <Pero, dejando eso de lado...>"

    # game/beyond the bet/day9dlc.rpy:2776
    old "1. <What's the plan here?>"
    new "1. <¿Cuál es el plan?>"

    # game/beyond the bet/day9dlc.rpy:2779
    old "1. <Lock all the doors and stay inside forever?>"
    new "1. <¿Cerrar todas las puertas y quedarnos dentro para siempre?>"

    # game/beyond the bet/day9dlc.rpy:2786
    old "1. <What, staying inside forever?>"
    new "1. <¿Qué, quedarnos dentro para siempre?>"

    # game/beyond the bet/day9dlc.rpy:2790
    old "1. <Awww, you're such a flirt.>"
    new "1. <Awww, eres un coqueto.>"

    # game/beyond the bet/day9dlc.rpy:2796
    old "2. <Sounds good to me, too.>"
    new "2. <A mí también me parece bien.>"

    # game/beyond the bet/day9dlc.rpy:2799
    old "2. <Pack some bags and hide out somewhere in superhell?>"
    new "2. <¿Hacer las maletas y escondernos en algún lugar del superinfierno?>"

    # game/beyond the bet/day9dlc.rpy:2804
    old "1. <There's nothing wrong with running away.>"
    new "1. <No hay nada malo en huir.>"

    # game/beyond the bet/day9dlc.rpy:2807
    old "1. <But, yes.>"
    new "1. <Pero, sí.>"

    # game/beyond the bet/day9dlc.rpy:2814
    old "3. <I'd really just like to go home...>"
    new "3. <La verdad solo quisiera volver a casa...>"

    # game/beyond the bet/day9dlc.rpy:2819
    old "1. <With you.>"
    new "1. <Contigo.>"

    # game/beyond the bet/day9dlc.rpy:2821
    old "2. <Not alone.>"
    new "2. <Acompañad[letra].>"

    # game/beyond the bet/day9dlc.rpy:2824
    old "1. <I mean, being here is kinda awesome, I'm not gonna lie.>"
    new "1. <O sea, estar aquí es genial, no voy a mentir.>"

    # game/beyond the bet/day9dlc.rpy:2827
    old "1. <But I still want to show you more of human life.>"
    new "1. <Pero aún quiero mostrarte más de la vida humana.>"

    # game/beyond the bet/day9dlc.rpy:2836
    old "1. <What about you?>"
    new "1. <¿Y tú?>"

    # game/beyond the bet/day9dlc.rpy:2841
    old "1. <Don't go.>"
    new "1. <No te vayas.>"

    # game/beyond the bet/day9dlc.rpy:2843
    old "1. <Stay, just for a little while?>"
    new "1. <¿Quédate, solo un ratito?>"

    # game/beyond the bet/day9dlc.rpy:2845
    old "2. <I don't want to be alone...>"
    new "2. <No quiero quedarme sol[letra]...>"

    # game/beyond the bet/day9dlc.rpy:2882
    old "1. <Be safe, okay?>"
    new "1. <Cuídate, ¿okey?>"

    # game/beyond the bet/day9dlc.rpy:2885
    old "1. <If you die, I'm going to kill you.>"
    new "1. <Si te mueres, te voy a matar.>"

    # game/beyond the bet/day9dlc.rpy:2889
    old "2. <I can't lose you now.>"
    new "2. <No puedo perderte ahora.>"

    # game/beyond the bet/day9dlc.rpy:2896
    old "1. <I had fun doing it, too.>"
    new "1. <Yo también me divertí haciéndolo.>"

    # game/beyond the bet/day9dlc.rpy:2898
    old "2. <We both know you don't mind.>"
    new "2. <Ambos sabemos que no te molesta.>"

    # game/beyond the bet/day9dlc.rpy:2903
    old "1. <I won't.>"
    new "1. <No lo haré.>"

    # game/beyond the bet/day9dlc.rpy:2905
    old "2. <Don't be gone too long, then.>"
    new "2. <No tardes mucho, entonces.>"

