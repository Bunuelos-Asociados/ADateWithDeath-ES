# TODO: Translation updated at 2026-10-15 18:36

# game/beyond the bet/day8dlc.rpy:7
translate Spanish day8dlc_start_d41d8cd9:

    # nvl clear
    nvl clear

# game/beyond the bet/day8dlc.rpy:17
translate Spanish day8dlc_start_165dcdd7:

    # center_text "The dawn of a new day - an eighth day to your bet that should never have existed."
    center_text "El amanecer de un nuevo día: un octavo día para tu apuesta, un día que nunca debería haber existido."

# game/beyond the bet/day8dlc.rpy:22
translate Spanish day8dlc_start_7660bfb5:

    # center_text "You roll out of bed, put on your favorite outfit, and can't help but grin when you see the sun shining in your window."
    center_text "Sales de la cama, te pones tu atuendo favorito y no puedes evitar sonreír al ver el sol brillar en tu ventana."

# game/beyond the bet/day8dlc.rpy:23
translate Spanish day8dlc_start_0442e6bd:

    # center_text "Was it always so warm, so bright?"
    center_text "¿Siempre ha sido tan cálido, tan brillante?"

# game/beyond the bet/day8dlc.rpy:24
translate Spanish day8dlc_start_42d16a66:

    # center_text "Likely, but it still feels especially nice today."
    center_text "Probablemente, pero hoy se siente especialmente agradable."

# game/beyond the bet/day8dlc.rpy:25
translate Spanish day8dlc_start_08cf37c2:

    # center_text "You are alive."
    center_text "Estás viv[letra]."

# game/beyond the bet/day8dlc.rpy:65
translate Spanish day8dlc_start3_499f7592:

    # player "The sun is shining ~ the sky is blue ~ my little reaper ~ how are you?"
    player "El sol brilla ~ el cielo es azul ~ mi parquita ~ ¿cómo estás tú?"

# game/beyond the bet/day8dlc.rpy:68
translate Spanish day8dlc_start3_dfde9d58:

    # player "What do you think of my merry little song?"
    player "¿Qué te parece mi alegre cancioncita?"

# game/beyond the bet/day8dlc.rpy:70
translate Spanish day8dlc_start3_45538fce:

    # player "Not bad, eh?"
    player "Nada mal, ¿eh?"

# game/beyond the bet/day8dlc.rpy:73
translate Spanish day8dlc_start3_44faafa6:

    # player "Just imagine I'm singing it."
    player "Imagina que la estoy cantando."

# game/beyond the bet/day8dlc.rpy:76
translate Spanish day8dlc_start3_10d66be7:

    # player "I could even do a little dance at the same time."
    player "Hasta podría bailar un poquito al mismo tiempo."

# game/beyond the bet/day8dlc.rpy:79
translate Spanish day8dlc_start3_ff7daa5d:

    # player "Can you dance?"
    player "¿Sabes bailar?"

# game/beyond the bet/day8dlc.rpy:82
translate Spanish day8dlc_start3_7f102762:

    # player "Even if you can't, I bet you'd say you could."
    player "Aunque no sepas, seguro dirías que sí."

# game/beyond the bet/day8dlc.rpy:85
translate Spanish day8dlc_start3_9255a3e0:

    # player "You'd be all 'i can do anything i want to do'."
    player "Dirías: 'puedo hacer lo que quiera'."

# game/beyond the bet/day8dlc.rpy:86
translate Spanish day8dlc_start3_93717213:

    # GR "i am glad to hear you know me so well. i indeed could if i wanted to."
    GR "me alegra saber que me conoces tan bien. en efecto, podría si quisiera."

# game/beyond the bet/day8dlc.rpy:87
translate Spanish day8dlc_start3_4d7f8df4:

    # GR "but what good would dancing do me? none, likely."
    GR "pero ¿de qué me serviría bailar? de nada, probablemente."

# game/beyond the bet/day8dlc.rpy:88
translate Spanish day8dlc_start3_7d26e104:

    # GR "so i will refrain."
    GR "así que me abstendré."

# game/beyond the bet/day8dlc.rpy:89
translate Spanish day8dlc_start3_37776fd1:

    # GR "as for your little song..."
    GR "en cuanto a tu cancioncita..."

# game/beyond the bet/day8dlc.rpy:90
translate Spanish day8dlc_start3_c03b7c07:

    # GR "the sky is black, as it always is."
    GR "el cielo es negro, como siempre."

# game/beyond the bet/day8dlc.rpy:93
translate Spanish day8dlc_start3_0913b524:

    # player "Suits you. A little bit extra, a little bit emo."
    player "Te queda bien. Un poco exagerado, un poco emo."

# game/beyond the bet/day8dlc.rpy:95
translate Spanish day8dlc_start3_b5637a3c:

    # player "Wait, really? That's a little sad."
    player "Espera, ¿en serio? Qué triste."

# game/beyond the bet/day8dlc.rpy:98
translate Spanish day8dlc_start3_0c98c898:

    # player "You can jump over here and check out the blue skies, then."
    player "Entonces puedes pasarte por aquí y echarle un vistazo al cielo azul."

# game/beyond the bet/day8dlc.rpy:101
translate Spanish day8dlc_start3_1faf9f7f:

    # player "I know they say the grass is always greener on the other side..."
    player "Ya sé que dicen que el pasto del vecino siempre es más verde..."

# game/beyond the bet/day8dlc.rpy:104
translate Spanish day8dlc_start3_1c90c936:

    # player "But it literally is, in this case."
    player "Pero en este caso, literalmente, lo es."

# game/beyond the bet/day8dlc.rpy:107
translate Spanish day8dlc_start3_517fb42d:

    # player "Wakey wakey! Grim-o, do you feel better?"
    player "¡Arriba, arriba! Parquit-o, ¿te sientes mejor?"

# game/beyond the bet/day8dlc.rpy:110
translate Spanish day8dlc_start3_969adeb1:

    # player "Grim-a."
    player "Parquit-a."

# game/beyond the bet/day8dlc.rpy:113
translate Spanish day8dlc_start3_b8e572dc:

    # player "Grim-e."
    player "Parquit-e."

# game/beyond the bet/day8dlc.rpy:116
translate Spanish day8dlc_start3_54a30571:

    # player "Grim-i."
    player "Parquit-i."

# game/beyond the bet/day8dlc.rpy:119
translate Spanish day8dlc_start3_254df9d4:

    # player "Grim-o."
    player "Parquit-o."

# game/beyond the bet/day8dlc.rpy:120
translate Spanish day8dlc_start3_edecb2f7:

    # GR "you've used that one already."
    GR "esa ya la usaste."

# game/beyond the bet/day8dlc.rpy:123
translate Spanish day8dlc_start3_c08b1112:

    # player "Grim-u."
    player "Parquit-u."

# game/beyond the bet/day8dlc.rpy:124
translate Spanish day8dlc_start3_53c84dad:

    # GR "congratulations, mortal, you know what vowels are."
    GR "felicidades, mortal, sabes lo que son las vocales."

# game/beyond the bet/day8dlc.rpy:127
translate Spanish day8dlc_start3_27674b3c:

    # player "Grim-y."
    player "Parquit-y."

# game/beyond the bet/day8dlc.rpy:128
translate Spanish day8dlc_start3_55ca2198:

    # GR "...nevermind."
    GR "...olvídalo."

# game/beyond the bet/day8dlc.rpy:131
translate Spanish day8dlc_start3_1b6b63a7:

    # player "Sometimes Y is used as a sneaky vowel."
    player "A veces la Y se cuela como vocal."

# game/beyond the bet/day8dlc.rpy:135
translate Spanish day8dlc_start3_bda58e38:

    # player "I wouldn't want it to feel left out."
    player "No quisiera que se sintiera excluida."

# game/beyond the bet/day8dlc.rpy:136
translate Spanish day8dlc_start3_11bc5193:

    # GR "it is a letter, it cannot feel left out."
    GR "es una letra, no puede sentirse excluida."

# game/beyond the bet/day8dlc.rpy:137
translate Spanish day8dlc_start3_2cdfdfad:

    # GR "in fact, it cannot feel anything at all."
    GR "de hecho, no puede sentir nada en absoluto."

# game/beyond the bet/day8dlc.rpy:140
translate Spanish day8dlc_start3_0b17e34e:

    # player "I'd like to see you do better."
    player "Me gustaría verte hacerlo mejor."

# game/beyond the bet/day8dlc.rpy:141
translate Spanish day8dlc_start3_b3df64a2:

    # GR "sunshine-a, sunshine-e, sunshine-i, sunshine-o, sunshine-u."
    GR "solecit-a, solecit-e, solecit-i, solecit-o, solecit-u."

# game/beyond the bet/day8dlc.rpy:145
translate Spanish day8dlc_start3_420d87f1:

    # player "You've been practicing, I see..."
    player "Has estado practicando, ya veo..."

# game/beyond the bet/day8dlc.rpy:147
translate Spanish day8dlc_start3_620403e3:

    # GR "??????"
    GR "??????"

# game/beyond the bet/day8dlc.rpy:148
translate Spanish day8dlc_start3_82adebd7:

    # GR "i feel like i shouldn't be surprised by your stupid comments any longer..."
    GR "siento que ya no debería sorprenderme con tus estúpidos comentarios..."

# game/beyond the bet/day8dlc.rpy:149
translate Spanish day8dlc_start3_2081bb75:

    # GR "and yet i am. every time."
    GR "y sin embargo me sorprendo. cada vez."

# game/beyond the bet/day8dlc.rpy:152
translate Spanish day8dlc_start3_10ea24f5:

    # player "Seeing as I've lived through the night, I'd say the cold didn't snuff you out."
    player "Ya que sobreviví a la noche, diría que el resfriado no acabó contigo."

# game/beyond the bet/day8dlc.rpy:155
translate Spanish day8dlc_start3_8516a8dc:

    # player "My big strong boy <3"
    player "Mi chico grande y fuerte <3"

# game/beyond the bet/day8dlc.rpy:158
translate Spanish day8dlc_start3_ae044bfc:

    # player "Are you feeling any better?"
    player "¿Te sientes mejor?"

# game/beyond the bet/day8dlc.rpy:161
translate Spanish day8dlc_start3_b486a7a1:

    # player "Ah, damn..."
    player "Ah, maldición..."

# game/beyond the bet/day8dlc.rpy:164
translate Spanish day8dlc_start3_728dbbbf:

    # player "I missed my chance to send you a 'get well soon' card and chocolates."
    player "Se me pasó la oportunidad de mandarte una tarjeta de 'mejórate pronto' y chocolates."

# game/beyond the bet/day8dlc.rpy:167
translate Spanish day8dlc_start3_825a72a4:

    # player "Next time, for sure."
    player "La próxima vez, seguro."

# game/beyond the bet/day8dlc.rpy:168
translate Spanish day8dlc_start3_c9bb71a2:

    # GR "hello to you as well."
    GR "hola a ti también."

# game/beyond the bet/day8dlc.rpy:169
translate Spanish day8dlc_start3_dcde61c6:

    # GR "i'm ever so sorry to disappoint, but i have no intention on ever experiencing that again."
    GR "lamento muchísimo decepcionarte, pero no tengo intención alguna de volver a experimentar eso."

# game/beyond the bet/day8dlc.rpy:170
translate Spanish day8dlc_start3_89360fd9:

    # GR "but, chocolates, hmm. curious."
    GR "pero chocolates, hmm. curioso."

# game/beyond the bet/day8dlc.rpy:171
translate Spanish day8dlc_start3_4f9f22c8:

    # GR "that need not be limited to a time when i am sick."
    GR "eso no tiene por qué limitarse a cuando estoy enfermo."

# game/beyond the bet/day8dlc.rpy:174
translate Spanish day8dlc_start3_43e02391:

    # player "A sweet tooth? Unexpected."
    player "¿Eres goloso? Inesperado."

# game/beyond the bet/day8dlc.rpy:176
translate Spanish day8dlc_start3_0be5145d:

    # player "You like chocolate? :O"
    player "¿Te gusta el chocolate? :O"

# game/beyond the bet/day8dlc.rpy:177
translate Spanish day8dlc_start3_6c6e83fa:

    # GR "even i can admit that mortals have brought some excellent things into existence."
    GR "incluso yo puedo admitir que los mortales han creado cosas excelentes."

# game/beyond the bet/day8dlc.rpy:178
translate Spanish day8dlc_start3_af361b11:

    # GR "chocolate being one of them."
    GR "el chocolate es una de esas."

# game/beyond the bet/day8dlc.rpy:179
translate Spanish day8dlc_start3_d05a19bb:

    # GR "it is relatively high up the list."
    GR "está bastante arriba en la lista."

# game/beyond the bet/day8dlc.rpy:180
translate Spanish day8dlc_start3_3ba94c36:

    # GR "much like the computer i use now, or cup noodles."
    GR "al igual que la computadora que uso ahora, o los fideos instantáneos."

# game/beyond the bet/day8dlc.rpy:181
translate Spanish day8dlc_start3_ebc0c3ba:

    # GR "fantastic inventions."
    GR "inventos fantásticos."

# game/beyond the bet/day8dlc.rpy:183
translate Spanish day8dlc_start3_cd4786bc:

    # GR "as for your question..."
    GR "en cuanto a tu pregunta..."

# game/beyond the bet/day8dlc.rpy:184
translate Spanish day8dlc_start3_60dc4e09:

    # GR "did you spend your entire night worrying about me?"
    GR "¿pasaste toda la noche preocupándote por mí?"

# game/beyond the bet/day8dlc.rpy:185
translate Spanish day8dlc_start3_0712d990:

    # GR "do i consume that much of your thoughts?"
    GR "¿ocupo tanto espacio en tus pensamientos?"

# game/beyond the bet/day8dlc.rpy:188
translate Spanish day8dlc_start3_ba2ca68c:

    # player "Honestly, yeah."
    player "Sinceramente, sí."

# game/beyond the bet/day8dlc.rpy:191
translate Spanish day8dlc_start3_05f67ef6:

    # player "I WAS worried about you."
    player "SÍ me preocupé por ti."

# game/beyond the bet/day8dlc.rpy:194
translate Spanish day8dlc_start3_0e1ebc3e:

    # player "Like you said, you've never been sick."
    player "Como dijiste, nunca te has enfermado."

# game/beyond the bet/day8dlc.rpy:197
translate Spanish day8dlc_start3_4949f54d:

    # player "Being sick alone sucks."
    player "Enfermarse estando solo es un asco."

# game/beyond the bet/day8dlc.rpy:200
translate Spanish day8dlc_start3_8991a2d4:

    # player "Being sick alone after never being sick before?"
    player "¿Enfermarse estando solo después de no haberse enfermado nunca?"

# game/beyond the bet/day8dlc.rpy:203
translate Spanish day8dlc_start3_8fa4ee53:

    # player "That sounds shitty."
    player "Eso suena fatal."

# game/beyond the bet/day8dlc.rpy:204
translate Spanish day8dlc_start3_3f7ad2f6:

    # GR "oh."
    GR "oh."

# game/beyond the bet/day8dlc.rpy:205
translate Spanish day8dlc_start3_253a54d3:

    # GR "well... i...."
    GR "bueno... yo...."

# game/beyond the bet/day8dlc.rpy:206
translate Spanish day8dlc_start3_0b16bee0:

    # GR "ahem."
    GR "ejem."

# game/beyond the bet/day8dlc.rpy:207
translate Spanish day8dlc_start3_d77568d9:

    # GR "thank you for... thinking of me, then."
    GR "gracias por... pensar en mí, entonces."

# game/beyond the bet/day8dlc.rpy:210
translate Spanish day8dlc_start3_d9a2f790:

    # player "Sounds like you were thinking about me, buddy."
    player "Suena como si estuvieras pensando en mí, amigo."

# game/beyond the bet/day8dlc.rpy:213
translate Spanish day8dlc_start3_88d4bc54:

    # player "You're sitting there, imagining me imagining you."
    player "Estás ahí sentado, imaginándome imaginándote."

# game/beyond the bet/day8dlc.rpy:216
translate Spanish day8dlc_start3_b175d79f:

    # player "Do you like me that much?"
    player "¿Tanto te gusto?"

# game/beyond the bet/day8dlc.rpy:217
translate Spanish day8dlc_start3_14774a80:

    # GR "........"
    GR "........"

# game/beyond the bet/day8dlc.rpy:218
translate Spanish day8dlc_start3_19aaa62c:

    # GR "i do not know what you are talking about."
    GR "no sé de qué hablas."

# game/beyond the bet/day8dlc.rpy:221
translate Spanish day8dlc_start3_3b682eba:

    # player "You liiiike me."
    player "Te guuuusto."

# game/beyond the bet/day8dlc.rpy:222
translate Spanish day8dlc_start3_ba78256f:

    # GR "who? me?"
    GR "¿quién? ¿yo?"

# game/beyond the bet/day8dlc.rpy:223
translate Spanish day8dlc_start3_efec73fe:

    # GR "i like your soul."
    GR "me gusta tu alma."

# game/beyond the bet/day8dlc.rpy:224
translate Spanish day8dlc_start3_9d985190:

    # GR "i like the idea of taking it."
    GR "me gusta la idea de tomarla."

# game/beyond the bet/day8dlc.rpy:227
translate Spanish day8dlc_start3_4fdb4472:

    # player "What about me as a whole?"
    player "¿Y yo en general?"

# game/beyond the bet/day8dlc.rpy:228
translate Spanish day8dlc_start3_c7fa2116:

    # GR "you are... satisfactory."
    GR "eres... satisfactori[letra]."

# game/beyond the bet/day8dlc.rpy:231
translate Spanish day8dlc_start3_f4e56a4e:

    # player "Well, you're right about that."
    player "Bueno, en eso tienes razón."

# game/beyond the bet/day8dlc.rpy:234
translate Spanish day8dlc_start3_dff22d9f:

    # player "I would be very good at satisfying you."
    player "Se me daría muy bien satisfacerte."

# game/beyond the bet/day8dlc.rpy:237
translate Spanish day8dlc_start3_f15b2bd1:

    # player "Like, I could cook you a meal."
    player "Por ejemplo, podría cocinarte una comida."

# game/beyond the bet/day8dlc.rpy:239
translate Spanish day8dlc_start3_8ad18795:

    # player "I could brush your hair! That would be satisfying."
    player "¡Podría cepillarte el cabello! Eso sería satisfactorio."

# game/beyond the bet/day8dlc.rpy:240
translate Spanish day8dlc_start3_3f7ad2f6_1:

    # GR "oh."
    GR "oh."

# game/beyond the bet/day8dlc.rpy:241
translate Spanish day8dlc_start3_a014c73b:

    # GR "you meant... that kind of thing."
    GR "te referías... a ese tipo de cosas."

# game/beyond the bet/day8dlc.rpy:244
translate Spanish day8dlc_start3_f9445d79:

    # player "What did you think I meant?"
    player "¿A qué creíste que me refería?"

# game/beyond the bet/day8dlc.rpy:245
translate Spanish day8dlc_start3_cb968cf8:

    # GR "n... nothing! nothing at all!"
    GR "n... ¡nada! ¡nada en absoluto!"

# game/beyond the bet/day8dlc.rpy:249
translate Spanish day8dlc_start3_24760b95:

    # player "Hahaha. You're so cute."
    player "Jajaja. Eres tan lindo."

# game/beyond the bet/day8dlc.rpy:253
translate Spanish day8dlc_start3_186b4a5f:

    # player "Fantasize all you wish~"
    player "Fantasea todo lo que quieras~"

# game/beyond the bet/day8dlc.rpy:255
translate Spanish day8dlc_start3_03581afb:

    # player "So cute, yet such a dirty boy."
    player "Tan lindo, pero tan pervertido."

# game/beyond the bet/day8dlc.rpy:257
translate Spanish day8dlc_start3_2ef80459:

    # GR "MOVING ON!"
    GR "¡CAMBIEMOS DE TEMA!"

# game/beyond the bet/day8dlc.rpy:261
translate Spanish day8dlc_start3_ce59e0ce:

    # player "Yeah, yeah. How are you feeling today, then?"
    player "Sí, sí. ¿Cómo te sientes hoy, entonces?"

# game/beyond the bet/day8dlc.rpy:265
translate Spanish day8dlc_start3_1cc5a4af:

    # player "I was more worried about myself, truthfully."
    player "Estaba más preocupad[letra] por mí, la verdad."

# game/beyond the bet/day8dlc.rpy:268
translate Spanish day8dlc_start3_d874054c:

    # player "If you were suddenly better..."
    player "Si de pronto estabas mejor..."

# game/beyond the bet/day8dlc.rpy:271
translate Spanish day8dlc_start3_77e927ae:

    # player "What was stopping you from turning up at 11:59PM and taking my soul?"
    player "¿Qué te impedía aparecer a las 11:59 p. m. y llevarte mi alma?"

# game/beyond the bet/day8dlc.rpy:274
translate Spanish day8dlc_start3_5aa1ab60:

    # player "I really hate losing, you know."
    player "De verdad odio perder, ¿sabes?"

# game/beyond the bet/day8dlc.rpy:275
translate Spanish day8dlc_start3_2c82efcf:

    # GR "you and i are alike in that matter."
    GR "tú y yo somos iguales en eso."

# game/beyond the bet/day8dlc.rpy:276
translate Spanish day8dlc_start3_d8f444bb:

    # GR "i do not lose."
    GR "yo no pierdo."

# game/beyond the bet/day8dlc.rpy:279
translate Spanish day8dlc_start3_ae37e44c:

    # player "Except to me <3"
    player "Excepto conmigo <3"

# game/beyond the bet/day8dlc.rpy:280
translate Spanish day8dlc_start3_7c0db849:

    # GR "no, i said what i meant."
    GR "no, dije lo que quise decir."

# game/beyond the bet/day8dlc.rpy:281
translate Spanish day8dlc_start3_eae1f610:

    # GR "i do not lose, even to you."
    GR "no pierdo, ni siquiera contra ti."

# game/beyond the bet/day8dlc.rpy:284
translate Spanish day8dlc_start3_3e67254c:

    # player "Alright, let's see then."
    player "Bien, veamos entonces."

# game/beyond the bet/day8dlc.rpy:287
translate Spanish day8dlc_start3_160a53bb:

    # player "Rock paper scissors?"
    player "¿Piedra, papel o tijera?"

# game/beyond the bet/day8dlc.rpy:288
translate Spanish day8dlc_start3_88e22104:

    # GR "that is a game for children."
    GR "ese es un juego de niños."

# game/beyond the bet/day8dlc.rpy:291
translate Spanish day8dlc_start3_97c88730:

    # player "And for the Grim Reaper and his favorite Sunshine."
    player "Y para la Parca y su Solecito favorito."

# game/beyond the bet/day8dlc.rpy:294
translate Spanish day8dlc_start3_711b043c:

    # player "Ready?"
    player "¿Listo?"

# game/beyond the bet/day8dlc.rpy:297
translate Spanish day8dlc_start3_faf5db40:

    # player "3..."
    player "3..."

# game/beyond the bet/day8dlc.rpy:300
translate Spanish day8dlc_start3_c1a3424f:

    # player "2..."
    player "2..."

# game/beyond the bet/day8dlc.rpy:303
translate Spanish day8dlc_start3_9c21b0eb:

    # player "1..."
    player "1..."

# game/beyond the bet/day8dlc.rpy:306
translate Spanish day8dlc_start3_349c3b41:

    # player "GO!"
    player "¡YA!"

# game/beyond the bet/day8dlc.rpy:307
translate Spanish day8dlc_start3_d0a4ae30:

    # GR "Rock"
    GR "Piedra"

# game/beyond the bet/day8dlc.rpy:310
translate Spanish day8dlc_start3_294723b6:

    # player "Rock"
    player "Piedra"

# game/beyond the bet/day8dlc.rpy:311
translate Spanish day8dlc_start3_330b9010:

    # GR "ah. a tie."
    GR "ah. un empate."

# game/beyond the bet/day8dlc.rpy:312
translate Spanish day8dlc_start3_f3527857:

    # GR "quite fitting for the two of us."
    GR "muy apropiado para nosotros dos."

# game/beyond the bet/day8dlc.rpy:313
translate Spanish day8dlc_start3_35337b16:

    # GR "two people who refuse to lose, even to each other."
    GR "dos personas que se niegan a perder, incluso entre sí."

# game/beyond the bet/day8dlc.rpy:314
translate Spanish day8dlc_start3_064d0baf:

    # GR "i will respect this tie."
    GR "respetaré este empate."

# game/beyond the bet/day8dlc.rpy:317
translate Spanish day8dlc_start3_2359d293:

    # player "You don't really have any choice."
    player "En realidad no tienes opción."

# game/beyond the bet/day8dlc.rpy:320
translate Spanish day8dlc_start3_39c7d66b:

    # player "No rematches."
    player "Sin revancha."

# game/beyond the bet/day8dlc.rpy:321
translate Spanish day8dlc_start3_d07e1a9d:

    # GR "why would i want a rematch?"
    GR "¿por qué iba a querer una revancha?"

# game/beyond the bet/day8dlc.rpy:322
translate Spanish day8dlc_start3_f2a9539b:

    # GR "a tie is sacred for something like this."
    GR "un empate es sagrado en algo así."

# game/beyond the bet/day8dlc.rpy:323
translate Spanish day8dlc_start3_8542bc4f:

    # GR "you and i are now on equal footing. "
    GR "tú y yo estamos ahora en igualdad de condiciones."

# game/beyond the bet/day8dlc.rpy:324
translate Spanish day8dlc_start3_0f7f0626:

    # GR "i see you differently."
    GR "te veo de otra manera."

# game/beyond the bet/day8dlc.rpy:327
translate Spanish day8dlc_start3_11a87106:

    # player "Because... because of rock paper scissors...?"
    player "¿Porque... por piedra, papel o tijera...?"

# game/beyond the bet/day8dlc.rpy:328
translate Spanish day8dlc_start3_feec4b51:

    # GR "correct."
    GR "correcto."

# game/beyond the bet/day8dlc.rpy:331
translate Spanish day8dlc_start3_b2ad81c4:

    # player "You sound stupid as flip again today."
    player "Hoy otra vez hablas como un tonto de remate."

# game/beyond the bet/day8dlc.rpy:334
translate Spanish day8dlc_start3_39bea715:

    # player "You must be feeling better."
    player "Debes de estar sintiéndote mejor."

# game/beyond the bet/day8dlc.rpy:338
translate Spanish day8dlc_start3_2d2a5559:

    # player "Paper"
    player "Papel"

# game/beyond the bet/day8dlc.rpy:339
translate Spanish day8dlc_start3_32c8e3c5:

    # GR "wait a second."
    GR "espera un segundo."

# game/beyond the bet/day8dlc.rpy:340
translate Spanish day8dlc_start3_989a6a22:

    # GR "wait."
    GR "espera."

# game/beyond the bet/day8dlc.rpy:341
translate Spanish day8dlc_start3_6929b229:

    # GR "there is a flaw in this system!"
    GR "¡hay un defecto en este sistema!"

# game/beyond the bet/day8dlc.rpy:342
translate Spanish day8dlc_start3_910a29c2:

    # GR "you were waiting for me to send my answer first!"
    GR "¡estabas esperando a que yo enviara mi respuesta primero!"

# game/beyond the bet/day8dlc.rpy:345
translate Spanish day8dlc_start3_2a0809d1:

    # player "You saying I'm a cheater?"
    player "¿Estás diciendo que hice trampa?"

# game/beyond the bet/day8dlc.rpy:346
translate Spanish day8dlc_start3_7772a27d:

    # GR "..."
    GR "..."

# game/beyond the bet/day8dlc.rpy:347
translate Spanish day8dlc_start3_2658d818:

    # GR "i am saying that the match was unfair."
    GR "estoy diciendo que la partida fue injusta."

# game/beyond the bet/day8dlc.rpy:350
translate Spanish day8dlc_start3_6630dd05:

    # player "You're just saying that cause I won."
    player "Solo lo dices porque gané."

# game/beyond the bet/day8dlc.rpy:353
translate Spanish day8dlc_start3_714b12f9:

    # player "How about this..."
    player "¿Qué tal esto...?"

# game/beyond the bet/day8dlc.rpy:356
translate Spanish day8dlc_start3_13fa2b9c:

    # player "Rematch in person?"
    player "¿Revancha en persona?"

# game/beyond the bet/day8dlc.rpy:357
translate Spanish day8dlc_start3_8af43da9:

    # GR "...yes. rematch in person."
    GR "...sí. revancha en persona."

# game/beyond the bet/day8dlc.rpy:361
translate Spanish day8dlc_start3_59a5fc2d:

    # player "I'll have you know, I am a rock paper scissors world champion."
    player "Que sepas que he ganado el campeonato mundial de piedra, papel o tijera."

# game/beyond the bet/day8dlc.rpy:362
translate Spanish day8dlc_start3_e2be6a81:

    # GR "you are?"
    GR "¿en serio?"

# game/beyond the bet/day8dlc.rpy:365
translate Spanish day8dlc_start3_e843712c:

    # player "I might be."
    player "Puede que sí."

# game/beyond the bet/day8dlc.rpy:368
translate Spanish day8dlc_start3_bbc84da9:

    # player "Or I might not be."
    player "O puede que no."

# game/beyond the bet/day8dlc.rpy:371
translate Spanish day8dlc_start3_f4977e3d:

    # player "Or... maybe I'm both!"
    player "O... ¡quizás ambas cosas!"

# game/beyond the bet/day8dlc.rpy:374
translate Spanish day8dlc_start3_4d0ae047:

    # player "I'm like, Schrödinger's rock paper scissors champion."
    player "Soy como el gato de Schrödinger, pero de piedra, papel o tijera."

# game/beyond the bet/day8dlc.rpy:375
translate Spanish day8dlc_start3_690ac370:

    # GR "that is the most stupid use of schrödinger's cat i have ever heard."
    GR "ese es el uso más estúpido del gato de schrödinger que he oído jamás."

# game/beyond the bet/day8dlc.rpy:376
translate Spanish day8dlc_start3_05c52fb5:

    # GR "anyway... to leave behind the stupid cat thing..."
    GR "en fin... para dejar atrás lo del estúpido gato..."

# game/beyond the bet/day8dlc.rpy:379
translate Spanish day8dlc_start3_1c04ffe9:

    # player "I'll go easy on you next time."
    player "La próxima vez voy a ir más suave contigo."

# game/beyond the bet/day8dlc.rpy:380
translate Spanish day8dlc_start3_ade66a42:

    # GR "do not go easy on me."
    GR "no me trates con indulgencia."

# game/beyond the bet/day8dlc.rpy:381
translate Spanish day8dlc_start3_3c7006f7:

    # GR "i will beat you, fair and square."
    GR "te venceré limpiamente."

# game/beyond the bet/day8dlc.rpy:384
translate Spanish day8dlc_start3_10d1c3c6:

    # player "You can try ;D"
    player "Puedes intentarlo ;D"

# game/beyond the bet/day8dlc.rpy:385
translate Spanish day8dlc_start3_7772a27d_1:

    # GR "..."
    GR "..."

# game/beyond the bet/day8dlc.rpy:386
translate Spanish day8dlc_start3_a5dc54b5:

    # GR "you talk too much, you know that?"
    GR "hablas demasiado, ¿lo sabías?"

# game/beyond the bet/day8dlc.rpy:389
translate Spanish day8dlc_start3_dca96d80:

    # player "You like it."
    player "Te gusta."

# game/beyond the bet/day8dlc.rpy:392
translate Spanish day8dlc_start3_21aa5680:

    # player "Honestly, you talk way more."
    player "Sinceramente, tú hablas mucho más."

# game/beyond the bet/day8dlc.rpy:395
translate Spanish day8dlc_start3_d296d75b:

    # player "You loooove the sound of your own voice."
    player "Te encaaanta el sonido de tu propia voz."

# game/beyond the bet/day8dlc.rpy:396
translate Spanish day8dlc_start3_8dc3254e:

    # GR "i do, yes."
    GR "sí, me encanta."

# game/beyond the bet/day8dlc.rpy:397
translate Spanish day8dlc_start3_def425b7:

    # GR "is it not the perfect tone?"
    GR "¿no es el tono perfecto?"

# game/beyond the bet/day8dlc.rpy:400
translate Spanish day8dlc_start3_2063a3e9:

    # player "Maybe."
    player "Tal vez."

# game/beyond the bet/day8dlc.rpy:403
translate Spanish day8dlc_start3_9ab169e5:

    # player "Though it did sound a little funny yesterday."
    player "Aunque ayer sonaba un poco gracioso."

# game/beyond the bet/day8dlc.rpy:404
translate Spanish day8dlc_start3_e1274a58:

    # GR "i cannot help the illness."
    GR "no puedo evitar la enfermedad."

# game/beyond the bet/day8dlc.rpy:405
translate Spanish day8dlc_start3_1c568bce:

    # GR "the one you gave me."
    GR "la que me contagiaste."

# game/beyond the bet/day8dlc.rpy:406
translate Spanish day8dlc_start3_2311a31e:

    # GR "the one that was your fault."
    GR "la que fue culpa tuya."

# game/beyond the bet/day8dlc.rpy:409
translate Spanish day8dlc_start3_c0e503ba:

    # player "Okay, okay, I'm sorry."
    player "Okey, okey, lo siento."

# game/beyond the bet/day8dlc.rpy:412
translate Spanish day8dlc_start3_c5b7258e:

    # player "Are you feeling better yet?"
    player "¿Ya te sientes mejor?"

# game/beyond the bet/day8dlc.rpy:416
translate Spanish day8dlc_start3_cf7eea42:

    # player "Scissors"
    player "Tijera"

# game/beyond the bet/day8dlc.rpy:417
translate Spanish day8dlc_start3_a63d62f1:

    # GR "AHA!"
    GR "¡AJÁ!"

# game/beyond the bet/day8dlc.rpy:418
translate Spanish day8dlc_start3_76ef3f79:

    # GR "I AM THE WINNER!"
    GR "¡GANÉ!"

# game/beyond the bet/day8dlc.rpy:419
translate Spanish day8dlc_start3_ba3b11e2:

    # GR "YES!"
    GR "¡SÍ!"

# game/beyond the bet/day8dlc.rpy:422
translate Spanish day8dlc_start3_3feacb5f:

    # player "Okay no need to gloat."
    player "Okey, no hace falta presumir."

# game/beyond the bet/day8dlc.rpy:423
translate Spanish day8dlc_start3_6ce3355f:

    # GR "there is plenty of reason to gloat."
    GR "hay motivos de sobra para presumir."

# game/beyond the bet/day8dlc.rpy:424
translate Spanish day8dlc_start3_46daaf52:

    # GR "of course, it is only natural that i won."
    GR "por supuesto, es natural que yo ganara."

# game/beyond the bet/day8dlc.rpy:425
translate Spanish day8dlc_start3_7f26162c:

    # GR "i was created to win. you, on the other hand, are just a mortal."
    GR "fui creado para ganar. tú, en cambio, eres solo [arti_2] mortal."

# game/beyond the bet/day8dlc.rpy:428
translate Spanish day8dlc_start3_939b9794:

    # player "A mortal with superpowers..."
    player "[arti_2!c] mortal con superpoderes..."

# game/beyond the bet/day8dlc.rpy:429
translate Spanish day8dlc_start3_f6ec215d:

    # GR "superpowers or not, i am still the winner."
    GR "con o sin superpoderes, sigo siendo el ganador."

# game/beyond the bet/day8dlc.rpy:430
translate Spanish day8dlc_start3_1fb2660a:

    # GR "go on. bow down. worship my greatness."
    GR "adelante. inclínate. venera mi grandeza."

# game/beyond the bet/day8dlc.rpy:433
translate Spanish day8dlc_start3_0ab1c245:

    # player "O, great lord of rock-paper-scissors, your radiance astounds me!"
    player "Oh, gran señor de piedra, papel o tijera, ¡tu resplandor me asombra!"

# game/beyond the bet/day8dlc.rpy:434
translate Spanish day8dlc_start3_5116a366:

    # GR "more."
    GR "más."

# game/beyond the bet/day8dlc.rpy:437
translate Spanish day8dlc_start3_b42c579d:

    # player "You are wonderful, and just, and so deserving of this win!"
    player "¡Eres maravilloso, justo y muy merecedor de esta victoria!"

# game/beyond the bet/day8dlc.rpy:438
translate Spanish day8dlc_start3_334deacf:

    # GR "a little more."
    GR "un poco más."

# game/beyond the bet/day8dlc.rpy:441
translate Spanish day8dlc_start3_14fee6f6:

    # player "You're also kinda cute."
    player "También eres medio lindo."

# game/beyond the bet/day8dlc.rpy:442
translate Spanish day8dlc_start3_7772a27d_2:

    # GR "..."
    GR "..."

# game/beyond the bet/day8dlc.rpy:443
translate Spanish day8dlc_start3_e8e2a56b:

    # GR "i am more than 'kinda' cute."
    GR "soy más que 'medio' lindo."

# game/beyond the bet/day8dlc.rpy:446
translate Spanish day8dlc_start3_0df5d46a:

    # player "I thought you'd argue again."
    player "Pensé que volverías a discutir."

# game/beyond the bet/day8dlc.rpy:449
translate Spanish day8dlc_start3_7b37ef4f:

    # player "'I'm not cute! I'm sexy! Handsome! Gorgeous!'"
    player "'¡No soy lindo! ¡Soy sexy! ¡Guapo! ¡Precioso!'"

# game/beyond the bet/day8dlc.rpy:450
translate Spanish day8dlc_start3_e4b233ee:

    # GR "all of those things are true."
    GR "todas esas cosas son ciertas."

# game/beyond the bet/day8dlc.rpy:451
translate Spanish day8dlc_start3_f6ba0000:

    # GR "but i am starting to be willing to accept cute."
    GR "pero empiezo a estar dispuesto a aceptar lo de lindo."

# game/beyond the bet/day8dlc.rpy:454
translate Spanish day8dlc_start3_451108af:

    # player "Well, you ARE cute."
    player "Pues sí que ERES lindo."

# game/beyond the bet/day8dlc.rpy:455
translate Spanish day8dlc_start3_3d0eb0ca:

    # GR "sure."
    GR "claro."

# game/beyond the bet/day8dlc.rpy:456
translate Spanish day8dlc_start3_34eb492f:

    # GR "as cute as death can be."
    GR "tan lindo como puede serlo la muerte."

# game/beyond the bet/day8dlc.rpy:459
translate Spanish day8dlc_start3_39bea715_1:

    # player "You must be feeling better."
    player "Debes de estar sintiéndote mejor."

# game/beyond the bet/day8dlc.rpy:463
translate Spanish day8dlc_start3_813a8fa5:

    # player "Maybe you cheated."
    player "Quizás hiciste trampa."

# game/beyond the bet/day8dlc.rpy:464
translate Spanish day8dlc_start3_4291c4fd:

    # GR "CHEATED?"
    GR "¡¿TRAMPA?!"

# game/beyond the bet/day8dlc.rpy:465
translate Spanish day8dlc_start3_0544a645:

    # GR "how would i have cheated???"
    GR "¿¿¿cómo habría hecho trampa???"

# game/beyond the bet/day8dlc.rpy:468
translate Spanish day8dlc_start3_737d0d75:

    # player "Maybe you're secretly a time traveller."
    player "Quizás eres un viajero del tiempo en secreto."

# game/beyond the bet/day8dlc.rpy:469
translate Spanish day8dlc_start3_da43a66a:

    # GR "if i was a time traveller, why would i use it to win rock paper scissors?"
    GR "si fuera un viajero en el tiempo, ¿por qué lo usaría para ganar en piedra, papel o tijera?"

# game/beyond the bet/day8dlc.rpy:472
translate Spanish day8dlc_start3_1760dd05:

    # player "I dunno."
    player "Ni idea."

# game/beyond the bet/day8dlc.rpy:475
translate Spanish day8dlc_start3_9be4d326:

    # player "You're petty like that."
    player "Eres así de infantil."

# game/beyond the bet/day8dlc.rpy:476
translate Spanish day8dlc_start3_e9a35980:

    # GR "i am not petty."
    GR "no soy infantil."

# game/beyond the bet/day8dlc.rpy:479
translate Spanish day8dlc_start3_d038ce40:

    # player "You kind of are."
    player "Un poco sí."

# game/beyond the bet/day8dlc.rpy:482
translate Spanish day8dlc_start3_c1f75cc7:

    # player "You seem like the kind of guy who would abuse time travel for trivial things..."
    player "Pareces el tipo de chico que abusaría de los viajes en el tiempo para cosas triviales..."

# game/beyond the bet/day8dlc.rpy:486
translate Spanish day8dlc_start3_e64378d2:

    # player "Then destroy the universe in the process."
    player "Y de paso destruiría el universo."

# game/beyond the bet/day8dlc.rpy:489
translate Spanish day8dlc_start3_0889bd55:

    # GR "i am unsure if that is a compliment or an insult."
    GR "no estoy seguro si eso es un cumplido o un insulto."

# game/beyond the bet/day8dlc.rpy:492
translate Spanish day8dlc_start3_0c081e71:

    # player "Yes."
    player "Sí."

# game/beyond the bet/day8dlc.rpy:493
translate Spanish day8dlc_start3_2eff24ce:

    # GR "then i will take it as both."
    GR "entonces lo tomaré como ambos."

# game/beyond the bet/day8dlc.rpy:494
translate Spanish day8dlc_start3_a13a80f5:

    # GR "how dare you! and also, thank you very much."
    GR "¡cómo te atreves! y además, muchas gracias."

# game/beyond the bet/day8dlc.rpy:497
translate Spanish day8dlc_start3_09ee759f:

    # player "Very humble of you, Grim."
    player "Muy humilde de tu parte, Parca."

# game/beyond the bet/day8dlc.rpy:500
translate Spanish day8dlc_start3_39bea715_2:

    # player "You must be feeling better."
    player "Debes de estar sintiéndote mejor."

# game/beyond the bet/day8dlc.rpy:503
translate Spanish day8dlc_start3_64c6f307:

    # player "Maybe you used our little mind soul connection bridge!"
    player "¡Quizás usaste nuestro puentecito de conexión mental y de almas!"

# game/beyond the bet/day8dlc.rpy:506
translate Spanish day8dlc_start3_67eada5c:

    # player "Had a little spy on what I was thinking."
    player "¡Espiaste un poco lo que pensaba!"

# game/beyond the bet/day8dlc.rpy:507
translate Spanish day8dlc_start3_8d286a39:

    # GR "i did not."
    GR "no lo hice."

# game/beyond the bet/day8dlc.rpy:508
translate Spanish day8dlc_start3_34bde287:

    # GR "i would not intrude into your consciousness without explicit permission."
    GR "no me entrometería en tu consciencia sin permiso explícito."

# game/beyond the bet/day8dlc.rpy:511
translate Spanish day8dlc_start3_c8cf66b9:

    # player "Hmmmm."
    player "Mmmm."

# game/beyond the bet/day8dlc.rpy:512
translate Spanish day8dlc_start3_619d2a0d:

    # GR "and it does not work like that anyways."
    GR "y de todos modos no funciona así."

# game/beyond the bet/day8dlc.rpy:513
translate Spanish day8dlc_start3_afb5930c:

    # GR "it does not allow me read your mind."
    GR "no me permite leer tu mente."

# game/beyond the bet/day8dlc.rpy:514
translate Spanish day8dlc_start3_759ef3aa:

    # GR "just the thought of that sends a shiver down my spine."
    GR "solo pensarlo me provoca un escalofrío."

# game/beyond the bet/day8dlc.rpy:517
translate Spanish day8dlc_start3_70189c3d:

    # player "In a good way, right?"
    player "En el buen sentido, ¿verdad?"

# game/beyond the bet/day8dlc.rpy:520
translate Spanish day8dlc_start3_9adf5f01:

    # player "My thoughts are lovely, what are you talking about?"
    player "Mis pensamientos son encantadores, ¿de qué hablas?"

# game/beyond the bet/day8dlc.rpy:521
translate Spanish day8dlc_start3_51182ba2:

    # GR "i think not."
    GR "creo que no."

# game/beyond the bet/day8dlc.rpy:524
translate Spanish day8dlc_start3_5d7edbb6:

    # player "Fine fine."
    player "Bueno, bueno."

# game/beyond the bet/day8dlc.rpy:527
translate Spanish day8dlc_start3_f0dafe98:

    # player "Since you can't read my mind, I'll have to ask outright. Are you feeling better?"
    player "Ya que no puedes leerme la mente, tendré que preguntarte directamente. ¿Te sientes mejor?"

# game/beyond the bet/day8dlc.rpy:530
translate Spanish day8dlc_start3_acbb0efb:

    # player "Ohoho. Imagine what it'd feel like in the bedroom with our connection."
    player "Ohoho. Imagina cómo sería en la cama con nuestra conexión."

# game/beyond the bet/day8dlc.rpy:531
translate Spanish day8dlc_start3_cab64d64:

    # GR "i... i suppose you do not mean sleeping..."
    GR "yo... yo supongo que no te refieres a dormir..."

# game/beyond the bet/day8dlc.rpy:534
translate Spanish day8dlc_start3_f7ba74af:

    # player "Don't you think that sounds amazing?"
    player "¿No crees que suena increíble?"

# game/beyond the bet/day8dlc.rpy:536
translate Spanish day8dlc_start3_180ba909:

    # player "Would it be, like, amplified?"
    player "¿Sería, como, amplificado?"

# game/beyond the bet/day8dlc.rpy:537
translate Spanish day8dlc_start3_193aca33:

    # GR "i... i... admit the idea is... intriguing."
    GR "yo... yo... admito que la idea es... intrigante."

# game/beyond the bet/day8dlc.rpy:538
translate Spanish day8dlc_start3_bf7f378f:

    # GR "layer upon layer of pleasure..."
    GR "capa sobre capa de placer..."

# game/beyond the bet/day8dlc.rpy:539
translate Spanish day8dlc_start3_8a22cb27:

    # GR "AHEM!"
    GR "¡EJEM!"

# game/beyond the bet/day8dlc.rpy:540
translate Spanish day8dlc_start3_f95f2289:

    # GR "what i mean to say is... is..."
    GR "lo que quiero decir es... es..."

# game/beyond the bet/day8dlc.rpy:541
translate Spanish day8dlc_start3_c88f9693:

    # GR "i have never heard a first hand account of something like that..."
    GR "nunca he oído un relato de primera mano de algo así..."

# game/beyond the bet/day8dlc.rpy:542
translate Spanish day8dlc_start3_9bae5e06:

    # GR "and our connection is incredibly strong."
    GR "y nuestra conexión es increíblemente fuerte."

# game/beyond the bet/day8dlc.rpy:543
translate Spanish day8dlc_start3_56b441ad:

    # GR "who knows what it would be like."
    GR "quién sabe cómo sería."

# game/beyond the bet/day8dlc.rpy:547
translate Spanish day8dlc_start3_d282c2ef:

    # player "We won't know unless we try, will we?"
    player "No lo sabremos si no lo intentamos, ¿verdad?"

# game/beyond the bet/day8dlc.rpy:550
translate Spanish day8dlc_start3_4520836e:

    # player "But, in the mean time..."
    player "Pero, mientras tanto..."

# game/beyond the bet/day8dlc.rpy:553
translate Spanish day8dlc_start3_5ffbf0f2:

    # player "How are you feeling?"
    player "¿Cómo te sientes?"

# game/beyond the bet/day8dlc.rpy:556
translate Spanish day8dlc_start3_46c4d22f:

    # player "A bit better, I assume?"
    player "¿Un poco mejor, supongo?"

# game/beyond the bet/day8dlc.rpy:560
translate Spanish day8dlc_start3_967b5f3d:

    # player "I kinda wanna keep it."
    player "La verdad es que me gustaría quedármela."

# game/beyond the bet/day8dlc.rpy:561
translate Spanish day8dlc_start3_84b0f806:

    # GR "that is only natural."
    GR "es lo natural."

# game/beyond the bet/day8dlc.rpy:562
translate Spanish day8dlc_start3_8702591c:

    # GR "honestly, i think people are far too attached to their souls."
    GR "sinceramente, creo que la gente está demasiado apegada a sus almas."

# game/beyond the bet/day8dlc.rpy:565
translate Spanish day8dlc_start3_4c863770:

    # player "Not everyone believes in them, you know."
    player "No todos creen en ellas, ¿sabes?"

# game/beyond the bet/day8dlc.rpy:568
translate Spanish day8dlc_start3_3be05930:

    # player "In fact, it's hotly debated what actually happens after you die."
    player "De hecho, lo que pasa realmente después de morir es muy debatido."

# game/beyond the bet/day8dlc.rpy:569
translate Spanish day8dlc_start3_091c3bfb:

    # GR "is it not obvious?"
    GR "¿acaso no es obvio?"

# game/beyond the bet/day8dlc.rpy:572
translate Spanish day8dlc_start3_299868d3:

    # player "No!"
    player "¡No!"

# game/beyond the bet/day8dlc.rpy:574
translate Spanish day8dlc_start3_f165438c:

    # player "How would it be obvious..."
    player "¿Cómo va a ser obvio...?"

# game/beyond the bet/day8dlc.rpy:575
translate Spanish day8dlc_start3_8ef36cc5:

    # GR "well, i think you humans should stop debating about things that really do not matter."
    GR "bueno, creo que los humanos deberían dejar de debatir sobre cosas que realmente no importan."

# game/beyond the bet/day8dlc.rpy:576
translate Spanish day8dlc_start3_545f6baa:

    # GR "and instead focus on important things."
    GR "y centrarse en cosas importantes."

# game/beyond the bet/day8dlc.rpy:579
translate Spanish day8dlc_start3_c5e195ef:

    # player "Like?"
    player "¿Como qué?"

# game/beyond the bet/day8dlc.rpy:580
translate Spanish day8dlc_start3_95ef950c:

    # GR "inventing a way to automate my job so i can retire already."
    GR "inventar una forma de automatizar mi trabajo para poder retirarme ya."

# game/beyond the bet/day8dlc.rpy:581
translate Spanish day8dlc_start3_42ad9826:

    # GR "or, alternatively, an ice cream that stays cold and never melts."
    GR "o, alternativamente, un helado que se mantenga frío y nunca se derrita."

# game/beyond the bet/day8dlc.rpy:584
translate Spanish day8dlc_start3_972e4ea8:

    # player "I thought you were gonna say fixing the housing crisis, or curing diseases, or global warming..."
    player "Pensé que ibas a decir arreglar la crisis de la vivienda, curar enfermedades o frenar el calentamiento global..."

# game/beyond the bet/day8dlc.rpy:585
translate Spanish day8dlc_start3_722338e7:

    # GR "those are important too."
    GR "esas también son importantes."

# game/beyond the bet/day8dlc.rpy:588
translate Spanish day8dlc_start3_8e547ebc:

    # player "You have your priorities. I respect that."
    player "Tienes tus prioridades. Lo respeto."

# game/beyond the bet/day8dlc.rpy:591
translate Spanish day8dlc_start3_6e70d251:

    # player "But you never answered."
    player "Pero nunca respondiste."

# game/beyond the bet/day8dlc.rpy:594
translate Spanish day8dlc_start3_5ffbf0f2_1:

    # player "How are you feeling?"
    player "¿Cómo te sientes?"

# game/beyond the bet/day8dlc.rpy:597
translate Spanish day8dlc_start3_dd46df88:

    # player "How is what happens after you die unimportant?"
    player "¿Cómo puede no importar lo que pasa después de morir?"

# game/beyond the bet/day8dlc.rpy:598
translate Spanish day8dlc_start3_4d2a4f8d:

    # GR "because you can do nothing about it."
    GR "porque no puedes hacer nada al respecto."

# game/beyond the bet/day8dlc.rpy:599
translate Spanish day8dlc_start3_b25439ee:

    # GR "you will all die eventually. there is no point in worrying about what comes after."
    GR "todos morirán tarde o temprano. no tiene sentido preocuparse por lo que viene después."

# game/beyond the bet/day8dlc.rpy:600
translate Spanish day8dlc_start3_fbca7ccf:

    # GR "simply enjoy your time there for what it is."
    GR "simplemente disfruten del tiempo que tienen tal como es."

# game/beyond the bet/day8dlc.rpy:601
translate Spanish day8dlc_start3_0a5acf8b:

    # GR "the journey is oftentimes more fulfilling than the ending."
    GR "el camino suele ser más gratificante que el final."

# game/beyond the bet/day8dlc.rpy:602
translate Spanish day8dlc_start3_f8ca0baa:

    # GR "but, to answer your original question..."
    GR "pero, para responder tu pregunta original..."

# game/beyond the bet/day8dlc.rpy:604
translate Spanish day8dlc_start3_00fbbac6:

    # GR "i am feeling much better."
    GR "me siento mucho mejor."

# game/beyond the bet/day8dlc.rpy:605
translate Spanish day8dlc_start3_6f8fbed2:

    # GR "i hadn't known how... unlike yourself you feel, when sick."
    GR "no sabía cuánto... deja uno de sentirse uno mismo cuando está enfermo."

# game/beyond the bet/day8dlc.rpy:606
translate Spanish day8dlc_start3_5d2334a7:

    # GR "like my hands were not my own. my body was someone else's..."
    GR "como si mis manos no fueran mías. mi cuerpo era de otra persona..."

# game/beyond the bet/day8dlc.rpy:607
translate Spanish day8dlc_start3_3c543b77:

    # GR "but now i feel much more like myself, thank the lords."
    GR "pero ahora me siento mucho más yo mismo, gracias a los dioses."

# game/beyond the bet/day8dlc.rpy:610
translate Spanish day8dlc_start3_e783e03b:

    # player "Not keen on getting sick again anytime soon?"
    player "¿No te gustaría volver a enfermarte pronto?"

# game/beyond the bet/day8dlc.rpy:611
translate Spanish day8dlc_start3_6f74a0bb:

    # GR "absolutely not."
    GR "de ninguna manera."

# game/beyond the bet/day8dlc.rpy:612
translate Spanish day8dlc_start3_7e7b4372:

    # GR "but..."
    GR "pero..."

# game/beyond the bet/day8dlc.rpy:613
translate Spanish day8dlc_start3_f1c8f353:

    # GR "there were a few good things to come from us both being sick."
    GR "hubo algunas cosas buenas de que ambos nos enfermáramos."

# game/beyond the bet/day8dlc.rpy:616
translate Spanish day8dlc_start3_c4cfd6ba:

    # player "You touched me!"
    player "¡Me tocaste!"

# game/beyond the bet/day8dlc.rpy:619
translate Spanish day8dlc_start3_338caedd:

    # player "I bet you enjoyed that."
    player "Seguro que lo disfrutaste."

# game/beyond the bet/day8dlc.rpy:620
translate Spanish day8dlc_start3_e851a257:

    # GR "touched you... barely..."
    GR "te toqué... apenas..."

# game/beyond the bet/day8dlc.rpy:621
translate Spanish day8dlc_start3_3c1d6348:

    # GR "i... ahem..."
    GR "yo... ejem..."

# game/beyond the bet/day8dlc.rpy:622
translate Spanish day8dlc_start3_7e5b5794:

    # GR "your skin is... surprisingly soft."
    GR "tu piel es... sorprendentemente suave."

# game/beyond the bet/day8dlc.rpy:623
translate Spanish day8dlc_start3_61651d61:

    # GR "even with that brief touch, i..."
    GR "incluso con ese breve roce, yo..."

# game/beyond the bet/day8dlc.rpy:624
translate Spanish day8dlc_start3_3d234743:

    # GR "find myself wanting to explore it further."
    GR "me descubro queriendo explorarla más."

# game/beyond the bet/day8dlc.rpy:627
translate Spanish day8dlc_start3_3828a2f6:

    # player "Then why don't you?"
    player "¿Entonces por qué no lo haces?"

# game/beyond the bet/day8dlc.rpy:630
translate Spanish day8dlc_start3_45eaa0c7:

    # player "Be my guest."
    player "Adelante."

# game/beyond the bet/day8dlc.rpy:631
translate Spanish day8dlc_start3_cafe63a8:

    # GR "it is not appropriate."
    GR "no es apropiado."

# game/beyond the bet/day8dlc.rpy:634
translate Spanish day8dlc_start3_e57df250:

    # player "Pretend it is for a second."
    player "Finge que lo es por un segundo."

# game/beyond the bet/day8dlc.rpy:637
translate Spanish day8dlc_start3_232d4716:

    # player "What would you do?"
    player "¿Qué harías?"

# game/beyond the bet/day8dlc.rpy:638
translate Spanish day8dlc_start3_f4342c20:

    # GR "this is a foolish game, mortal."
    GR "este es un juego necio, mortal."

# game/beyond the bet/day8dlc.rpy:641
translate Spanish day8dlc_start3_e23ae3c7:

    # player "Then call yourself a fool and play along."
    player "Pues llámate necio y sigue el juego."

# game/beyond the bet/day8dlc.rpy:642
translate Spanish day8dlc_start3_a35d18cc:

    # GR "if... it were appropriate..."
    GR "si... fuera apropiado..."

# game/beyond the bet/day8dlc.rpy:643
translate Spanish day8dlc_start3_1fc7f539:

    # GR "then touching your hand would be nice. running my fingers down your palm..."
    GR "entonces tocar tu mano sería agradable. deslizar mis dedos por tu palma..."

# game/beyond the bet/day8dlc.rpy:646
translate Spanish day8dlc_start3_16784f93:

    # player "Holding hands? Scandalous, Casper."
    player "¿Tomarse de las manos? Escandaloso, Casper."

# game/beyond the bet/day8dlc.rpy:647
translate Spanish day8dlc_start3_390b0233:

    # GR "i am unused to touching people with my bare hands."
    GR "no estoy acostumbrado a tocar a la gente con las manos desnudas."

# game/beyond the bet/day8dlc.rpy:648
translate Spanish day8dlc_start3_62a5f8b1:

    # GR "even when i take souls, i do not touch."
    GR "incluso cuando tomo almas, no toco."

# game/beyond the bet/day8dlc.rpy:649
translate Spanish day8dlc_start3_eac0a6db:

    # GR "touch is for the living."
    GR "el tacto es para los vivos."

# game/beyond the bet/day8dlc.rpy:650
translate Spanish day8dlc_start3_72bd023d:

    # GR "that warmth isn't for me."
    GR "esa calidez no es para mí."

# game/beyond the bet/day8dlc.rpy:653
translate Spanish day8dlc_start3_789e3d86:

    # player "I think you're the only one putting that restriction on yourself."
    player "Creo que eres el único que se impone esa restricción."

# game/beyond the bet/day8dlc.rpy:656
translate Spanish day8dlc_start3_a654fbd5:

    # player "I'm Sunshine, right?"
    player "Soy Solecito, ¿no?"

# game/beyond the bet/day8dlc.rpy:659
translate Spanish day8dlc_start3_64e9eab0:

    # player "Of course I'm gonna get ya with my warmth every now and then."
    player "Claro que de vez en cuando te voy a agarrar desprevenido con mi calidez."

# game/beyond the bet/day8dlc.rpy:661
translate Spanish day8dlc_start3_39099dc1:

    # player "That's what I do. Warm you up."
    player "Es lo que hago. Calentarte."

# game/beyond the bet/day8dlc.rpy:662
translate Spanish day8dlc_start3_08f7f97d:

    # GR "mayhaps it is inevitable..."
    GR "quizás sea inevitable..."

# game/beyond the bet/day8dlc.rpy:663
translate Spanish day8dlc_start3_62387767:

    # GR "still, i know it should not be for me."
    GR "aun así, sé que no debería ser para mí."

# game/beyond the bet/day8dlc.rpy:668
translate Spanish day8dlc_start3_f8d2475e:

    # player "We got to comfort each other!"
    player "¡Nos consolamos el uno al otro!"

# game/beyond the bet/day8dlc.rpy:669
translate Spanish day8dlc_start3_5649ab72:

    # GR "i would not say that is exactly true."
    GR "no diría que eso es exactamente cierto."

# game/beyond the bet/day8dlc.rpy:672
translate Spanish day8dlc_start3_5a5fe269:

    # player "I would!"
    player "¡Yo sí lo diría!"

# game/beyond the bet/day8dlc.rpy:674
translate Spanish day8dlc_start3_fb301420:

    # player "Then you'd be wrong."
    player "Entonces estarías equivocado."

# game/beyond the bet/day8dlc.rpy:677
translate Spanish day8dlc_start3_29097398:

    # player "Mister Wrong Reaper."
    player "Señor Parca Equivocado."

# game/beyond the bet/day8dlc.rpy:680
translate Spanish day8dlc_start3_adde7df1:

    # player "You made me dinner."
    player "Me hiciste la cena."

# game/beyond the bet/day8dlc.rpy:683
translate Spanish day8dlc_start3_22a2de6d:

    # player "I let you sleep beside me in bed."
    player "Te dejé dormir a mi lado en la cama."

# game/beyond the bet/day8dlc.rpy:686
translate Spanish day8dlc_start3_f9f9c64f:

    # player "I'd say that's both of us comforted."
    player "Diría que nos consolamos los dos."

# game/beyond the bet/day8dlc.rpy:687
translate Spanish day8dlc_start3_7772a27d_3:

    # GR "..."
    GR "..."

# game/beyond the bet/day8dlc.rpy:688
translate Spanish day8dlc_start3_c6ee59db:

    # GR "did you enjoy it?"
    GR "¿lo disfrutaste?"

# game/beyond the bet/day8dlc.rpy:689
translate Spanish day8dlc_start3_292b9c49:

    # GR "having me... in your space?"
    GR "¿tenerme... en tu espacio?"

# game/beyond the bet/day8dlc.rpy:692
translate Spanish day8dlc_start3_0b877e4f:

    # player "I loved it."
    player "Me encantó."

# game/beyond the bet/day8dlc.rpy:695
translate Spanish day8dlc_start3_179ba8ab:

    # player "It felt nice."
    player "Se sintió bien."

# game/beyond the bet/day8dlc.rpy:698
translate Spanish day8dlc_start3_a36fa359:

    # player "You know, to have someone there when I'm sick."
    player "Ya sabes, tener a alguien ahí cuando uno está enfermo."

# game/beyond the bet/day8dlc.rpy:701
translate Spanish day8dlc_start3_5c292ed2:

    # player "I only wish I could've done the same for you."
    player "Solo desearía haber podido hacer lo mismo por ti."

# game/beyond the bet/day8dlc.rpy:702
translate Spanish day8dlc_start3_b7330c4e:

    # GR "there is no need to feel like that."
    GR "no hay necesidad de sentirse así."

# game/beyond the bet/day8dlc.rpy:703
translate Spanish day8dlc_start3_01e14a80:

    # GR "having you speak to me yesterday while i was ill..."
    GR "que me hablaras ayer mientras estaba enfermo..."

# game/beyond the bet/day8dlc.rpy:704
translate Spanish day8dlc_start3_d6838dca:

    # GR "well, it was worth more than you know."
    GR "bueno, valió más de lo que imaginas."

# game/beyond the bet/day8dlc.rpy:707
translate Spanish day8dlc_start3_b2d7af42:

    # player "You're always welcome, Casper."
    player "Siempre eres bienvenido, Casper."

# game/beyond the bet/day8dlc.rpy:708
translate Spanish day8dlc_start3_a8233594:

    # GR "you may come to regret that."
    GR "podrías llegar a arrepentirte."

# game/beyond the bet/day8dlc.rpy:709
translate Spanish day8dlc_start3_d210e434:

    # GR "what if i take that as an invitation?"
    GR "¿y si lo tomo como una invitación?"

# game/beyond the bet/day8dlc.rpy:712
translate Spanish day8dlc_start3_8d15836f:

    # player "It IS an invitation."
    player "ES una invitación."

# game/beyond the bet/day8dlc.rpy:715
translate Spanish day8dlc_start3_dac667a4:

    # player "Come on over, big boy."
    player "Ven, grandulón."

# game/beyond the bet/day8dlc.rpy:718
translate Spanish day8dlc_start3_2dac4736:

    # player "Whenever you want ;D"
    player "Cuando quieras ;D"

# game/beyond the bet/day8dlc.rpy:719
translate Spanish day8dlc_start3_8a06456f:

    # GR "...maybe i will take you up on that offer."
    GR "...quizás acepte esa oferta."

# game/beyond the bet/day8dlc.rpy:722
translate Spanish day8dlc_start3_f953831b:

    # player "You got to lay in my bed ;)"
    player "Pudiste acostarte en mi cama ;)"

# game/beyond the bet/day8dlc.rpy:725
translate Spanish day8dlc_start3_3c7ba169:

    # player "It's pretty comfy, don't you think?"
    player "Es bastante cómoda, ¿no crees?"

# game/beyond the bet/day8dlc.rpy:726
translate Spanish day8dlc_start3_99676df8:

    # GR "i could barely tell..."
    GR "apenas pude notarlo..."

# game/beyond the bet/day8dlc.rpy:729
translate Spanish day8dlc_start3_6e3a4bf3:

    # player "Oh, were you uncomfortable?"
    player "Ah, ¿estabas incómodo?"

# game/beyond the bet/day8dlc.rpy:730
translate Spanish day8dlc_start3_bb4574d3:

    # GR "uncomfortable is... not exactly the right word."
    GR "incómodo no es... exactamente la palabra correcta."

# game/beyond the bet/day8dlc.rpy:731
translate Spanish day8dlc_start3_14652ca5:

    # GR "was it slightly excruciating? yes."
    GR "¿fue ligeramente insoportable? sí."

# game/beyond the bet/day8dlc.rpy:734
translate Spanish day8dlc_start3_ea589afe:

    # player "My... bed?"
    player "¿Mi... cama?"

# game/beyond the bet/day8dlc.rpy:735
translate Spanish day8dlc_start3_5d364529:

    # GR "no."
    GR "no."

# game/beyond the bet/day8dlc.rpy:736
translate Spanish day8dlc_start3_4d197382:

    # GR "sleeping beside you."
    GR "dormir a tu lado."

# game/beyond the bet/day8dlc.rpy:739
translate Spanish day8dlc_start3_230c0659:

    # player "Oh. Sorry."
    player "Ah. Perdón."

# game/beyond the bet/day8dlc.rpy:742
translate Spanish day8dlc_start3_d7bf89bc:

    # player "I didn't know you wouldn't like it."
    player "No sabía que no te gustaría."

# game/beyond the bet/day8dlc.rpy:743
translate Spanish day8dlc_start3_fe5ce676:

    # GR "no!"
    GR "¡no!"

# game/beyond the bet/day8dlc.rpy:744
translate Spanish day8dlc_start3_2425e7d8:

    # GR "it is... ugh..."
    GR "es... ugh..."

# game/beyond the bet/day8dlc.rpy:745
translate Spanish day8dlc_start3_f236177f:

    # GR "it is not that."
    GR "no es eso."

# game/beyond the bet/day8dlc.rpy:746
translate Spanish day8dlc_start3_13f64a57:

    # GR "i am just... unused to being close to someone."
    GR "simplemente no estoy acostumbrado a estar cerca de alguien."

# game/beyond the bet/day8dlc.rpy:747
translate Spanish day8dlc_start3_6be08bf7:

    # GR "and when that someone is you, i..."
    GR "y cuando ese alguien eres tú, yo..."

# game/beyond the bet/day8dlc.rpy:748
translate Spanish day8dlc_start3_2a652623:

    # GR "how would i be able to sleep?"
    GR "¿cómo podría dormir?"

# game/beyond the bet/day8dlc.rpy:751
translate Spanish day8dlc_start3_ceb56e38:

    # player "OH!"
    player "¡OH!"

# game/beyond the bet/day8dlc.rpy:754
translate Spanish day8dlc_start3_00d04ce1:

    # player "So you actually liked it."
    player "O sea que sí te gustó."

# game/beyond the bet/day8dlc.rpy:755
translate Spanish day8dlc_start3_7ac05c09:

    # GR "...no further comment."
    GR "...sin comentarios."

# game/beyond the bet/day8dlc.rpy:758
translate Spanish day8dlc_start3_ae185b46:

    # player "Awww, little Casper liked sleeping next to me <3"
    player "Awww, al pequeño Casper le gustó dormir a mi lado <3"

# game/beyond the bet/day8dlc.rpy:761
translate Spanish day8dlc_start3_f712e82f:

    # player "You're a cutie."
    player "Eres un encanto."

# game/beyond the bet/day8dlc.rpy:762
translate Spanish day8dlc_start3_f643e055:

    # GR "hardly."
    GR "ni de lejos."

# game/beyond the bet/day8dlc.rpy:765
translate Spanish day8dlc_start3_f6ab2dd0:

    # player "You got to experience something new?"
    player "¿Pudiste vivir algo nuevo?"

# game/beyond the bet/day8dlc.rpy:766
translate Spanish day8dlc_start3_7772a27d_4:

    # GR "..."
    GR "..."

# game/beyond the bet/day8dlc.rpy:767
translate Spanish day8dlc_start3_caa40e52:

    # GR "i did get to experience a few things new to me."
    GR "sí pude vivir algunas cosas nuevas para mí."

# game/beyond the bet/day8dlc.rpy:768
translate Spanish day8dlc_start3_7f5783d0:

    # GR "being sick was an experience unto itself."
    GR "estar enfermo fue toda una experiencia en sí misma."

# game/beyond the bet/day8dlc.rpy:769
translate Spanish day8dlc_start3_e4d3d911:

    # GR "i cooked for you a human meal."
    GR "te cociné una comida humana."

# game/beyond the bet/day8dlc.rpy:770
translate Spanish day8dlc_start3_a01bb40b:

    # GR "that was interesting."
    GR "eso fue interesante."

# game/beyond the bet/day8dlc.rpy:771
translate Spanish day8dlc_start3_c30211c0:

    # GR "i..."
    GR "yo..."

# game/beyond the bet/day8dlc.rpy:772
translate Spanish day8dlc_start3_b7703208:

    # GR "nevermind."
    GR "no importa."

# game/beyond the bet/day8dlc.rpy:775
translate Spanish day8dlc_start3_be470620:

    # player "You can't leave me hanging!"
    player "¡No puedes dejarme con la duda!"

# game/beyond the bet/day8dlc.rpy:777
translate Spanish day8dlc_start3_87a78b22:

    # player "Casper..."
    player "Casper..."

# game/beyond the bet/day8dlc.rpy:778
translate Spanish day8dlc_start3_f379e3a1:

    # GR "i... am loathe to admit something so shameful..."
    GR "yo... me cuesta admitir algo tan vergonzoso..."

# game/beyond the bet/day8dlc.rpy:781
translate Spanish day8dlc_start3_4f3de55c:

    # player "Go on..."
    player "Continúa..."

# game/beyond the bet/day8dlc.rpy:782
translate Spanish day8dlc_start3_d07a627a:

    # GR "while you slept, i..."
    GR "mientras dormías, yo..."

# game/beyond the bet/day8dlc.rpy:783
translate Spanish day8dlc_start3_862fcadf:

    # GR "i did watch you, for a time. just for a bit."
    GR "sí te observé, durante un rato. solo un poco."

# game/beyond the bet/day8dlc.rpy:784
translate Spanish day8dlc_start3_7fd7c006:

    # GR "i found it hard to sleep, and your face was so..."
    GR "me costó dormir, y tu rostro era tan..."

# game/beyond the bet/day8dlc.rpy:785
translate Spanish day8dlc_start3_20069d59:

    # GR "peaceful."
    GR "apacible."

# game/beyond the bet/day8dlc.rpy:786
translate Spanish day8dlc_start3_92d0bc55:

    # GR "a peace i didn't know existed."
    GR "una paz que no sabía que existía."

# game/beyond the bet/day8dlc.rpy:789
translate Spanish day8dlc_start3_b467a8cc:

    # player "Phew..."
    player "Uf..."

# game/beyond the bet/day8dlc.rpy:791
translate Spanish day8dlc_start3_93b3f5c5:

    # player "You made me think it was something bad!"
    player "¡Me hiciste pensar que era algo malo!"

# game/beyond the bet/day8dlc.rpy:794
translate Spanish day8dlc_start3_36d4d447:

    # player "I don't mind you watching me."
    player "No me molesta que me mires."

# game/beyond the bet/day8dlc.rpy:797
translate Spanish day8dlc_start3_e522e74b:

    # player "It's kinda what you do, right?"
    player "Es como lo tuyo, ¿no?"

# game/beyond the bet/day8dlc.rpy:798
translate Spanish day8dlc_start3_5b63cc99:

    # GR "i... suppose so."
    GR "yo... supongo que sí."

# game/beyond the bet/day8dlc.rpy:799
translate Spanish day8dlc_start3_cc833949:

    # GR "but this was not a hunter watching its prey."
    GR "pero esto no era un cazador observando a su presa."

# game/beyond the bet/day8dlc.rpy:800
translate Spanish day8dlc_start3_c250a52f:

    # GR "it was..."
    GR "era..."

# game/beyond the bet/day8dlc.rpy:801
translate Spanish day8dlc_start3_2968f2c4:

    # GR "something different."
    GR "algo diferente."

# game/beyond the bet/day8dlc.rpy:802
translate Spanish day8dlc_start3_3c80dd7e:

    # GR "something new to me."
    GR "algo nuevo para mí."

# game/beyond the bet/day8dlc.rpy:803
translate Spanish day8dlc_start3_892dbc19:

    # GR "so, i feel ashamed of my actions."
    GR "por eso me avergüenzo de mis actos."

# game/beyond the bet/day8dlc.rpy:806
translate Spanish day8dlc_start3_dce265f8:

    # player "That's unlike you."
    player "Eso no es propio de ti."

# game/beyond the bet/day8dlc.rpy:809
translate Spanish day8dlc_start3_4bf9ffff:

    # player "You're the most confident person I know."
    player "Eres la persona más segura de sí misma que conozco."

# game/beyond the bet/day8dlc.rpy:812
translate Spanish day8dlc_start3_9f124299:

    # player "Er, reaper."
    player "Digo, parca."

# game/beyond the bet/day8dlc.rpy:813
translate Spanish day8dlc_start3_5143dfe7:

    # GR "...you are right, of course."
    GR "...tienes razón, por supuesto."

# game/beyond the bet/day8dlc.rpy:814
translate Spanish day8dlc_start3_b108c167:

    # GR "it is not fitting of my station."
    GR "no es digno de mi rango."

# game/beyond the bet/day8dlc.rpy:815
translate Spanish day8dlc_start3_7772a27d_5:

    # GR "..."
    GR "..."

# game/beyond the bet/day8dlc.rpy:816
translate Spanish day8dlc_start3_3357fa20:

    # GR "anyways."
    GR "en fin."

# game/beyond the bet/day8dlc.rpy:818
translate Spanish day8dlc_start3_ddbb61dc:

    # GR "sunshine, what do you know about birthdays?"
    GR "solecito, ¿qué sabes sobre los cumpleaños?"

# game/beyond the bet/day8dlc.rpy:821
translate Spanish day8dlc_start3_6f34b144:

    # player "Birthdays?"
    player "¿Cumpleaños?"

# game/beyond the bet/day8dlc.rpy:824
translate Spanish day8dlc_start3_08f3816c:

    # player "That is 'the day of one's birth', Casper."
    player "Es 'el día del nacimiento de alguien', Casper."

# game/beyond the bet/day8dlc.rpy:825
translate Spanish day8dlc_start3_edd2204c:

    # GR "ah!"
    GR "¡ah!"

# game/beyond the bet/day8dlc.rpy:826
translate Spanish day8dlc_start3_7378b963:

    # GR "i forgot i was talking to the monarch of sarcasm."
    GR "olvidé que hablaba con [arti] monarca del sarcasmo."

# game/beyond the bet/day8dlc.rpy:829
translate Spanish day8dlc_start3_57f3b757:

    # player "I think we can both have that title."
    player "Creo que los dos podemos tener ese título."

# game/beyond the bet/day8dlc.rpy:830
translate Spanish day8dlc_start3_64f82abd:

    # GR "if it is you, i suppose i do not mind sharing..."
    GR "si eres tú, supongo que no me importa compartirlo..."

# game/beyond the bet/day8dlc.rpy:831
translate Spanish day8dlc_start3_d065f545:

    # GR "but, birthdays..."
    GR "pero, los cumpleaños..."

# game/beyond the bet/day8dlc.rpy:834
translate Spanish day8dlc_start3_fcdd689f:

    # player "They're fun!"
    player "¡Son divertidos!"

# game/beyond the bet/day8dlc.rpy:837
translate Spanish day8dlc_start3_0e795765:

    # player "I guess it depends on your age, but..."
    player "Supongo que depende de tu edad, pero..."

# game/beyond the bet/day8dlc.rpy:840
translate Spanish day8dlc_start3_44163fcc:

    # player "You get some presents, eat some cake, and have fun with your friends."
    player "Recibes regalos, comes pastel y te diviertes con tus amigos."

# game/beyond the bet/day8dlc.rpy:843
translate Spanish day8dlc_start3_7204d8e6:

    # player "I love birthdays."
    player "Me encantan los cumpleaños."

# game/beyond the bet/day8dlc.rpy:846
translate Spanish day8dlc_start3_bff78b82:

    # player "They're a time to celebrate."
    player "Son un momento para celebrar."

# game/beyond the bet/day8dlc.rpy:849
translate Spanish day8dlc_start3_3fce7da4:

    # player "You lived another whole year."
    player "Viviste un año más."

# game/beyond the bet/day8dlc.rpy:852
translate Spanish day8dlc_start3_7123480e:

    # player "The best way to celebrate, of course, is to stuff your face with cake."
    player "La mejor forma de celebrar, claro, es comer pastel hasta reventar."

# game/beyond the bet/day8dlc.rpy:855
translate Spanish day8dlc_start3_ba2eec90:

    # player "Until you're so sick you can't walk."
    player "Hasta que te sientas tan mal que no puedas caminar."

# game/beyond the bet/day8dlc.rpy:858
translate Spanish day8dlc_start3_ffaf3a7b:

    # player "I've never really done much on my birthday."
    player "Nunca he hecho mucho en mi cumpleaños."

# game/beyond the bet/day8dlc.rpy:861
translate Spanish day8dlc_start3_13f4a24b:

    # player "It's always been kind of lowkey."
    player "Siempre ha sido algo tranquilo."

# game/beyond the bet/day8dlc.rpy:864
translate Spanish day8dlc_start3_3f2b0cb2:

    # player "I like it like that, though."
    player "Aunque así me gusta."

# game/beyond the bet/day8dlc.rpy:866
translate Spanish day8dlc_start3_4ebfe9f7:

    # player "I wish I celebrated it more."
    player "Ojalá lo celebrara más."

# game/beyond the bet/day8dlc.rpy:869
translate Spanish day8dlc_start3_126f7089:

    # GR "what kind of things do people do on the days of their birth?"
    GR "¿qué suelen hacer las personas el día de su nacimiento?"

# game/beyond the bet/day8dlc.rpy:870
translate Spanish day8dlc_start3_4440df66:

    # GR "live sacrifices?"
    GR "¿sacrificios en vivo?"

# game/beyond the bet/day8dlc.rpy:871
translate Spanish day8dlc_start3_a92cae14:

    # GR "feasts?"
    GR "¿banquetes?"

# game/beyond the bet/day8dlc.rpy:874
translate Spanish day8dlc_start3_e70a0812:

    # player "Um."
    player "Eh."

# game/beyond the bet/day8dlc.rpy:877
translate Spanish day8dlc_start3_2b06b065:

    # player "Maybe not the live sacrifices thing."
    player "Quizás lo de los sacrificios en vivo no."

# game/beyond the bet/day8dlc.rpy:880
translate Spanish day8dlc_start3_c86fe665:

    # player "At least, the last party I went to at McDougals didn't have any..."
    player "Al menos, en la última fiesta a la que fui en McDougals no había ninguno..."

# game/beyond the bet/day8dlc.rpy:883
translate Spanish day8dlc_start3_847d7c58:

    # player "I'm starting to feel like I'm missing out."
    player "Estoy empezando a sentir que me estoy perdiendo de algo."

# game/beyond the bet/day8dlc.rpy:884
translate Spanish day8dlc_start3_653f30fa:

    # GR "perhaps that is an opportunity."
    GR "quizás sea una oportunidad."

# game/beyond the bet/day8dlc.rpy:885
translate Spanish day8dlc_start3_02fc4d18:

    # GR "a gap in the market, so to speak."
    GR "un nicho de mercado, por así decirlo."

# game/beyond the bet/day8dlc.rpy:888
translate Spanish day8dlc_start3_83d78db4:

    # player "You think I should start offering children's birthday party live sacrifices?"
    player "¿Crees que debería empezar a ofrecer sacrificios en vivo en fiestas infantiles de cumpleaños?"

# game/beyond the bet/day8dlc.rpy:889
translate Spanish day8dlc_start3_ba18a67c:

    # GR "i'm not saying you shouldn't."
    GR "no digo que no debas."

# game/beyond the bet/day8dlc.rpy:892
translate Spanish day8dlc_start3_d033c074:

    # player "Noted, I'll start considering it."
    player "Anotado, empezaré a considerarlo."

# game/beyond the bet/day8dlc.rpy:894
translate Spanish day8dlc_start3_febd602b:

    # player "I think I'll pass this time."
    player "Creo que esta vez paso."

# game/beyond the bet/day8dlc.rpy:897
translate Spanish day8dlc_start3_45ac6b4c:

    # player "If my boss ever caught wind of it..."
    player "Si mi jefe llegara a enterarse..."

# game/beyond the bet/day8dlc.rpy:900
translate Spanish day8dlc_start3_ca433fdc:

    # player "I think I'd never be allowed to teach children ever again."
    player "Creo que nunca más me dejarían dar clases a niños."

# game/beyond the bet/day8dlc.rpy:901
translate Spanish day8dlc_start3_14e74063:

    # GR "ah! you should definitely consider it, then."
    GR "¡ah! entonces deberías considerarlo seriamente."

# game/beyond the bet/day8dlc.rpy:902
translate Spanish day8dlc_start3_bd97098f:

    # GR "you would be doing yourself a huge favor."
    GR "te harías un enorme favor."

# game/beyond the bet/day8dlc.rpy:903
translate Spanish day8dlc_start3_a4ed39a4:

    # GR "vermin = eradicated."
    GR "alimañas = erradicadas."

# game/beyond the bet/day8dlc.rpy:906
translate Spanish day8dlc_start3_2e160acf:

    # player "You can't just call children vermin 😭"
    player "No puedes simplemente llamar alimañas a los niños 😭"

# game/beyond the bet/day8dlc.rpy:910
translate Spanish day8dlc_start3_7b2a5cfb:

    # player "I'd like to remind you, I quite like my job!!!"
    player "¡¡¡Te recuerdo que me gusta bastante mi trabajo!!!"

# game/beyond the bet/day8dlc.rpy:911
translate Spanish day8dlc_start3_b4e4c1cd:

    # GR "save the idea for a rainy day, then."
    GR "guarda la idea para otro día, entonces."

# game/beyond the bet/day8dlc.rpy:914
translate Spanish day8dlc_start3_cdf41eac:

    # player "I might have to pass for now, but thanks..."
    player "Quizá por ahora tenga que decir que no, pero gracias..."

# game/beyond the bet/day8dlc.rpy:917
translate Spanish day8dlc_start3_70bdf0ea:

    # player "Yeah, there's loads of live sacrifices."
    player "Sí, hay montones de sacrificios en vivo."

# game/beyond the bet/day8dlc.rpy:920
translate Spanish day8dlc_start3_595f87c6:

    # player "Huge birthday issue. Too many sacrifices."
    player "Un enorme problema de cumpleaños. Demasiados sacrificios."

# game/beyond the bet/day8dlc.rpy:921
translate Spanish day8dlc_start3_56b79c7c:

    # GR "ah, so it is common?"
    GR "ah, ¿entonces es común?"

# game/beyond the bet/day8dlc.rpy:924
translate Spanish day8dlc_start3_9acebfc4:

    # player "Definitely."
    player "Definitivamente."

# game/beyond the bet/day8dlc.rpy:925
translate Spanish day8dlc_start3_7ef82f5b:

    # GR "i cannot tell if you are lying or not."
    GR "no puedo saber si mientes o no."

# game/beyond the bet/day8dlc.rpy:927
translate Spanish day8dlc_start3_78b14cea:

    # player "No, I'm pulling your leg again."
    player "No, te estoy tomando el pelo otra vez."

# game/beyond the bet/day8dlc.rpy:928
translate Spanish day8dlc_start3_2dede0ef:

    # GR "my leg will fall off from how much you pull it."
    GR "se me caerá el pelo de tanto que me lo jalas."

# game/beyond the bet/day8dlc.rpy:932
translate Spanish day8dlc_start3_c1c459fe:

    # player "Feasts, though..."
    player "Los banquetes, en cambio..."

# game/beyond the bet/day8dlc.rpy:935
translate Spanish day8dlc_start3_16200055:

    # player "Yeah, in a way those are pretty common."
    player "Sí, en cierto modo esos son bastante comunes."

# game/beyond the bet/day8dlc.rpy:938
translate Spanish day8dlc_start3_38a8c395:

    # player "Like, going out to a restaurant on your birthday."
    player "Como ir a un restaurante en tu cumpleaños."

# game/beyond the bet/day8dlc.rpy:939
translate Spanish day8dlc_start3_c6ac936b:

    # GR "why do that over eating what you enjoy at home?"
    GR "¿por qué hacer eso en lugar de comer en casa lo que disfrutas?"

# game/beyond the bet/day8dlc.rpy:942
translate Spanish day8dlc_start3_f23868db:

    # player "Some people suck at cooking."
    player "Algunas personas cocinan fatal."

# game/beyond the bet/day8dlc.rpy:945
translate Spanish day8dlc_start3_214f4ce5:

    # player "They'll sit at home eating cup noodles all day..."
    player "Se quedan en casa comiendo fideos instantáneos todo el día..."

# game/beyond the bet/day8dlc.rpy:948
translate Spanish day8dlc_start3_37bcad8a:

    # player "And never eat a good meal."
    player "Y nunca comen una buena comida."

# game/beyond the bet/day8dlc.rpy:951
translate Spanish day8dlc_start3_a2d0dd62:

    # player "So going out somewhere is nice."
    player "Así que salir a algún lado está bien."

# game/beyond the bet/day8dlc.rpy:952
translate Spanish day8dlc_start3_3bf634cc:

    # GR "that feels very pointed."
    GR "eso suena a indirecta."

# game/beyond the bet/day8dlc.rpy:953
translate Spanish day8dlc_start3_a12f24eb:

    # GR "what is wrong with eating cup noodles?"
    GR "¿qué tiene de malo comer fideos instantáneos?"

# game/beyond the bet/day8dlc.rpy:956
translate Spanish day8dlc_start3_22710738:

    # player "They're tasty, but..."
    player "Son ricos, pero..."

# game/beyond the bet/day8dlc.rpy:958
translate Spanish day8dlc_start3_869f5ec5:

    # player "They're not super nutritional."
    player "No son muy nutritivos."

# game/beyond the bet/day8dlc.rpy:961
translate Spanish day8dlc_start3_631c8527:

    # player "If that's all you eat, that can't be good for you."
    player "Si es lo único que comes, no puede ser bueno para ti."

# game/beyond the bet/day8dlc.rpy:962
translate Spanish day8dlc_start3_626e2915:

    # GR "i would disagree."
    GR "discreparía."

# game/beyond the bet/day8dlc.rpy:963
translate Spanish day8dlc_start3_8142ad58:

    # GR "i am in peak physical form."
    GR "estoy en mi forma física óptima."

# game/beyond the bet/day8dlc.rpy:966
translate Spanish day8dlc_start3_af514589:

    # player "Imagine the even PEAKER physical form you COULD be in, then."
    player "Imagina la forma física AÚN MÁS ÓPTIMA en la que PODRÍAS estar, entonces."

# game/beyond the bet/day8dlc.rpy:967
translate Spanish day8dlc_start3_4229a73c:

    # GR "hm."
    GR "hm."

# game/beyond the bet/day8dlc.rpy:968
translate Spanish day8dlc_start3_06e4a93e:

    # GR "i will consider it."
    GR "lo consideraré."

# game/beyond the bet/day8dlc.rpy:969
translate Spanish day8dlc_start3_1cafd11e:

    # GR "though i cannot imagine my body being any more perfect than it is now."
    GR "aunque no puedo imaginar que mi cuerpo sea más perfecto de lo que es ahora."

# game/beyond the bet/day8dlc.rpy:972
translate Spanish day8dlc_start3_15bc2d72:

    # player "tbh neither can I."
    player "la verdad, yo tampoco."

# game/beyond the bet/day8dlc.rpy:973
translate Spanish day8dlc_start3_a492f95b:

    # GR "i admire mortals who are honest, you know."
    GR "admiro a los mortales que son honestos, ¿sabes?"

# game/beyond the bet/day8dlc.rpy:976
translate Spanish day8dlc_start3_eeae8cd0:

    # player "Keep admirin' me then, Grimmy."
    player "Entonces sigue admirándome, Parquita."

# game/beyond the bet/day8dlc.rpy:979
translate Spanish day8dlc_start3_15595de9:

    # player "I don't mind being honest about your looks."
    player "No tengo problema en decir la verdad sobre tu aspecto."

# game/beyond the bet/day8dlc.rpy:982
translate Spanish day8dlc_start3_b7ba42c4:

    # player "Trust in the vegetables, Grim."
    player "Confía en las verduras, Parca."

# game/beyond the bet/day8dlc.rpy:983
translate Spanish day8dlc_start3_056e1882:

    # GR "there are plenty of vegetables that come with the noodles."
    GR "hay muchas verduras que vienen con los fideos."

# game/beyond the bet/day8dlc.rpy:986
translate Spanish day8dlc_start3_47433386:

    # player "Trust in the FRESH vegetables, Grim."
    player "Confía en las verduras FRESCAS, Parca."

# game/beyond the bet/day8dlc.rpy:987
translate Spanish day8dlc_start3_7645ebbc:

    # GR "i do not want to. anyway..."
    GR "no quiero. en fin..."

# game/beyond the bet/day8dlc.rpy:990
translate Spanish day8dlc_start3_51ecb884:

    # player "The atmosphere of restaurants makes it enjoyable."
    player "El ambiente de los restaurantes lo hace agradable."

# game/beyond the bet/day8dlc.rpy:993
translate Spanish day8dlc_start3_36df403d:

    # player "The lights, the company, sometimes there's live music..."
    player "Las luces, la compañía, a veces hay música en vivo..."

# game/beyond the bet/day8dlc.rpy:996
translate Spanish day8dlc_start3_0df53748:

    # player "It's a different experience than sitting at home to eat."
    player "Es una experiencia diferente a comer en casa."

# game/beyond the bet/day8dlc.rpy:997
translate Spanish day8dlc_start3_2ebdc6ca:

    # GR "and you do this often?"
    GR "¿y haces esto a menudo?"

# game/beyond the bet/day8dlc.rpy:1000
translate Spanish day8dlc_start3_77de8e94:

    # player "All the time!"
    player "¡Todo el tiempo!"

# game/beyond the bet/day8dlc.rpy:1001
translate Spanish day8dlc_start3_012abb6f:

    # GR "with whom?"
    GR "¿con quién?"

# game/beyond the bet/day8dlc.rpy:1004
translate Spanish day8dlc_start3_2724ffca:

    # player "Why, you jealous?"
    player "¿Por qué, estás celoso?"

# game/beyond the bet/day8dlc.rpy:1005
translate Spanish day8dlc_start3_34e1a8ee:

    # GR "that is preposterous."
    GR "eso es absurdo."

# game/beyond the bet/day8dlc.rpy:1006
translate Spanish day8dlc_start3_18d203f3:

    # GR "do i look like a man who would be jealous over something so insignificant?"
    GR "¿acaso parezco un hombre que sentiría celos de algo tan insignificante?"

# game/beyond the bet/day8dlc.rpy:1009
translate Spanish day8dlc_start3_0c081e71_1:

    # player "Yes."
    player "Sí."

# game/beyond the bet/day8dlc.rpy:1010
translate Spanish day8dlc_start3_7772a27d_6:

    # GR "..."
    GR "..."

# game/beyond the bet/day8dlc.rpy:1013
translate Spanish day8dlc_start3_908780fe:

    # player "To be honest, I usually go by myself lol."
    player "A decir verdad, normalmente voy por mi cuenta jaja."

# game/beyond the bet/day8dlc.rpy:1016
translate Spanish day8dlc_start3_6744779a:

    # player "I'm the best company anyone could have, after all B)"
    player "Soy la mejor compañía que alguien podría tener, después de todo B)"

# game/beyond the bet/day8dlc.rpy:1017
translate Spanish day8dlc_start3_496b2841:

    # GR "no one invites you?"
    GR "¿nadie te invita?"

# game/beyond the bet/day8dlc.rpy:1020
translate Spanish day8dlc_start3_94acdead:

    # player "Eh, not that much."
    player "Eh, no mucho."

# game/beyond the bet/day8dlc.rpy:1022
translate Spanish day8dlc_start3_f55e41d3:

    # player "Not really."
    player "La verdad es que no."

# game/beyond the bet/day8dlc.rpy:1025
translate Spanish day8dlc_start3_973f8bc7:

    # player "But that's alright."
    player "Pero está bien."

# game/beyond the bet/day8dlc.rpy:1027
translate Spanish day8dlc_start3_249434b9:

    # player "Their loss!"
    player "¡Ellos se lo pierden!"

# game/beyond the bet/day8dlc.rpy:1028
translate Spanish day8dlc_start3_7772a27d_7:

    # GR "..."
    GR "..."

# game/beyond the bet/day8dlc.rpy:1029
translate Spanish day8dlc_start3_1b300d39:

    # GR "that is outrageous. irrational. illogical. completely unthinkable."
    GR "eso es indignante. irracional. ilógico. completamente impensable."

# game/beyond the bet/day8dlc.rpy:1030
translate Spanish day8dlc_start3_be49c641:

    # GR "you should be asked to these human restaurants at least five times a day."
    GR "deberían invitarte a estos restaurantes humanos al menos cinco veces al día."

# game/beyond the bet/day8dlc.rpy:1031
translate Spanish day8dlc_start3_61e91400:

    # GR "if i was a mortal, i know i would be in constant demand."
    GR "si fuera mortal, sé que estaría muy solicitado todo el tiempo."

# game/beyond the bet/day8dlc.rpy:1034
translate Spanish day8dlc_start3_d0d7f334:

    # player "Then start asking me, Grimmy."
    player "Entonces empieza a invitarme, Parquita."

# game/beyond the bet/day8dlc.rpy:1035
translate Spanish day8dlc_start3_9a0f839b:

    # GR "...perhaps i will."
    GR "...quizás lo haga."

# game/beyond the bet/day8dlc.rpy:1038
translate Spanish day8dlc_start3_209b30fc:

    # player "Oh, you'd be mega popular."
    player "Oh, serías megapopular."

# game/beyond the bet/day8dlc.rpy:1041
translate Spanish day8dlc_start3_19ebcf5d:

    # player "Red eyes, long eyelashes, long hair, great bod..."
    player "Ojos rojos, pestañas largas, cabello largo, gran cuerpazo..."

# game/beyond the bet/day8dlc.rpy:1044
translate Spanish day8dlc_start3_7df81121:

    # player "Yeah, you'd never want for a date."
    player "Sí, nunca te faltarían citas."

# game/beyond the bet/day8dlc.rpy:1045
translate Spanish day8dlc_start3_393ee526:

    # GR "and i would turn them all down."
    GR "y los rechazaría a todos."

# game/beyond the bet/day8dlc.rpy:1048
translate Spanish day8dlc_start3_801f6f4f:

    # player "Why? Am I the only one for you?"
    player "¿Por qué? ¿Soy [arti] únic[letra] para ti?"

# game/beyond the bet/day8dlc.rpy:1049
translate Spanish day8dlc_start3_091c3bfb_1:

    # GR "is it not obvious?"
    GR "¿acaso no es obvio?"

# game/beyond the bet/day8dlc.rpy:1050
translate Spanish day8dlc_start3_18fcab60:

    # GR "i am above any and all who would want me."
    GR "estoy por encima de todos los que me desearían."

# game/beyond the bet/day8dlc.rpy:1051
translate Spanish day8dlc_start3_9002e649:

    # GR "i will not lower my standards for anyone."
    GR "no bajaré mis estándares por nadie."

# game/beyond the bet/day8dlc.rpy:1054
translate Spanish day8dlc_start3_6904bfd5:

    # player "What about me?"
    player "¿Qué hay de mí?"

# game/beyond the bet/day8dlc.rpy:1055
translate Spanish day8dlc_start3_7772a27d_8:

    # GR "..."
    GR "..."

# game/beyond the bet/day8dlc.rpy:1056
translate Spanish day8dlc_start3_4771f8f6:

    # GR "there would be no lowering of standards necessary."
    GR "no sería necesario bajar ningún estándar."

# game/beyond the bet/day8dlc.rpy:1059
translate Spanish day8dlc_start3_5a83f73d:

    # player "Rarely, unfortunately..."
    player "Pocas veces, por desgracia..."

# game/beyond the bet/day8dlc.rpy:1062
translate Spanish day8dlc_start3_5b4a0e81:

    # player "I don't go out to eat nearly as much as I'd like to."
    player "No salgo a comer ni de cerca tanto como me gustaría."

# game/beyond the bet/day8dlc.rpy:1063
translate Spanish day8dlc_start3_decc05cc:

    # GR "would you like that to change?"
    GR "¿te gustaría que eso cambiara?"

# game/beyond the bet/day8dlc.rpy:1066
translate Spanish day8dlc_start3_1b98eb03:

    # player "Well..."
    player "Bueno..."

# game/beyond the bet/day8dlc.rpy:1069
translate Spanish day8dlc_start3_7ef00766:

    # player "It depends who's asking."
    player "Depende de quién lo pida."

# game/beyond the bet/day8dlc.rpy:1070
translate Spanish day8dlc_start3_d953253b:

    # GR "what if it was i?"
    GR "¿y si fuera yo?"

# game/beyond the bet/day8dlc.rpy:1073
translate Spanish day8dlc_start3_4fe4a170:

    # player "If you say pretty please."
    player "Si dices porfis."

# game/beyond the bet/day8dlc.rpy:1074
translate Spanish day8dlc_start3_84203650:

    # GR "...pretty please."
    GR "...porfis."

# game/beyond the bet/day8dlc.rpy:1077
translate Spanish day8dlc_start3_8e2731c7:

    # player "Pretty pretty please."
    player "Porfis, porfis."

# game/beyond the bet/day8dlc.rpy:1078
translate Spanish day8dlc_start3_76d3e3c6:

    # GR "what...."
    GR "¿qué....?"

# game/beyond the bet/day8dlc.rpy:1079
translate Spanish day8dlc_start3_13329bdf:

    # GR "pretty, pretty please."
    GR "porfis, porfis."

# game/beyond the bet/day8dlc.rpy:1082
translate Spanish day8dlc_start3_ceca8b3e:

    # player "With sugar on top."
    player "Con un poquito de azúcar."

# game/beyond the bet/day8dlc.rpy:1083
translate Spanish day8dlc_start3_4028485b:

    # GR "why would you put sugar on top of a please?"
    GR "¿por qué pondrías un poquito de azúcar en un por favor?"

# game/beyond the bet/day8dlc.rpy:1084
translate Spanish day8dlc_start3_eeab2306:

    # GR "HOW do you put sugar on top of a please?"
    GR "¿CÓMO se pone un poquito de azúcar en un por favor?"

# game/beyond the bet/day8dlc.rpy:1087
translate Spanish day8dlc_start3_d10ec513:

    # player "Like this: pretty please with sugar on top?"
    player "Así: ¿porfis, con un poquito de azúcar?"

# game/beyond the bet/day8dlc.rpy:1088
translate Spanish day8dlc_start3_0dfa4e9c:

    # GR "...pretty please with sugar on top."
    GR "...porfis, con un poquito de azúcar."

# game/beyond the bet/day8dlc.rpy:1091
translate Spanish day8dlc_start3_054d1354:

    # player "I gotta hear you say that later."
    player "Tengo que oírte decir eso después."

# game/beyond the bet/day8dlc.rpy:1092
translate Spanish day8dlc_start3_04ff5f1d:

    # GR "no one in any of the realms has the ability to make a grim reaper beg as you do, you know."
    GR "nadie en ningún reino tiene la capacidad de hacer suplicar a una parca como tú, ¿sabes?"

# game/beyond the bet/day8dlc.rpy:1095
translate Spanish day8dlc_start3_6f92678b:

    # player "I will use my power wisely (I won't)."
    player "Usaré mi poder con sabiduría (mentira)."

# game/beyond the bet/day8dlc.rpy:1098
translate Spanish day8dlc_start3_4c822b9f:

    # player "Then, yes. I would like to go to dinner with you sometime, Casper."
    player "Entonces, sí. Me gustaría ir a cenar contigo algún día, Casper."

# game/beyond the bet/day8dlc.rpy:1101
translate Spanish day8dlc_start3_c6966eb7:

    # player "It's a date."
    player "Es una cita."

# game/beyond the bet/day8dlc.rpy:1102
translate Spanish day8dlc_start3_f03bdaed:

    # GR "wait a second, i... i didn't say we should actually..."
    GR "espera un segundo, yo... yo no dije que de verdad deberíamos..."

# game/beyond the bet/day8dlc.rpy:1103
translate Spanish day8dlc_start3_4a025a00:

    # GR "...i will... keep the date in mind for later. wait for me."
    GR "...tendré... presente la cita para más adelante. espérame."

# game/beyond the bet/day8dlc.rpy:1106
translate Spanish day8dlc_start3_ace610be:

    # GR "let us put aside other people's birthday activities."
    GR "dejemos de lado las actividades de cumpleaños de otros."

# game/beyond the bet/day8dlc.rpy:1107
translate Spanish day8dlc_start3_3175a936:

    # GR "what is your birthday activity of choice?"
    GR "¿cuál es tu actividad de cumpleaños preferida?"

# game/beyond the bet/day8dlc.rpy:1110
translate Spanish day8dlc_start3_c8cf66b9_1:

    # player "Hmmmm."
    player "Mmmm."

# game/beyond the bet/day8dlc.rpy:1113
translate Spanish day8dlc_start3_b28797a4:

    # player "If I had to pick anything..."
    player "Si tuviera que elegir algo..."

# game/beyond the bet/day8dlc.rpy:1116
translate Spanish day8dlc_start3_92328e2f:

    # player "I'd go on a fancy overseas vacation!"
    player "¡Me iría de vacaciones de lujo al extranjero!"

# game/beyond the bet/day8dlc.rpy:1119
translate Spanish day8dlc_start3_9629b369:

    # player "Maybe somewhere tropical..."
    player "Tal vez a algún lugar tropical..."

# game/beyond the bet/day8dlc.rpy:1122
translate Spanish day8dlc_start3_ae8496ee:

    # player "Or a big city!"
    player "¡O a una ciudad grande!"

# game/beyond the bet/day8dlc.rpy:1125
translate Spanish day8dlc_start3_257e9855:

    # player "Or the countryside..."
    player "O al campo..."

# game/beyond the bet/day8dlc.rpy:1126
translate Spanish day8dlc_start3_371c6cd6:

    # GR "those are all quite different."
    GR "esos lugares son todos bastante distintos."

# game/beyond the bet/day8dlc.rpy:1129
translate Spanish day8dlc_start3_1f29b3ef:

    # player "But they all sound so good..."
    player "Pero todos suenan tan bien..."

# game/beyond the bet/day8dlc.rpy:1132
translate Spanish day8dlc_start3_389882ec:

    # player "Maybe a trip all around the world!"
    player "¡Tal vez un viaje alrededor del mundo!"

# game/beyond the bet/day8dlc.rpy:1133
translate Spanish day8dlc_start3_2b474f02:

    # GR "it sounds expensive and tiring."
    GR "suena caro y agotador."

# game/beyond the bet/day8dlc.rpy:1136
translate Spanish day8dlc_start3_873c14e0:

    # player "Right on both counts."
    player "Tienes razón en ambas cosas."

# game/beyond the bet/day8dlc.rpy:1139
translate Spanish day8dlc_start3_387806d8:

    # player "But fun, too."
    player "Pero también divertido."

# game/beyond the bet/day8dlc.rpy:1142
translate Spanish day8dlc_start3_dde725c6:

    # player "But also quite unrealistic for a birthday."
    player "Pero también bastante poco realista para un cumpleaños."

# game/beyond the bet/day8dlc.rpy:1145
translate Spanish day8dlc_start3_88815f78:

    # player "A [girl] can dream..."
    player "Soñar no cuesta nada..."

# game/beyond the bet/day8dlc.rpy:1149
translate Spanish day8dlc_start3_0311f833:

    # player "I'd stay at home and play games alllll day."
    player "Me quedaría en casa jugando todo el día."

# game/beyond the bet/day8dlc.rpy:1150
translate Spanish day8dlc_start3_43a23dbd:

    # GR "is that so different to any other day?"
    GR "¿eso es tan diferente de cualquier otro día?"

# game/beyond the bet/day8dlc.rpy:1153
translate Spanish day8dlc_start3_0c081e71_2:

    # player "Yes."
    player "Sí."

# game/beyond the bet/day8dlc.rpy:1156
translate Spanish day8dlc_start3_4dc8540c:

    # player "I also get to stuff my face with cake."
    player "También puedo comer pastel hasta reventar."

# game/beyond the bet/day8dlc.rpy:1157
translate Spanish day8dlc_start3_62a46a15:

    # GR "if nothing else, it sounds relaxing."
    GR "al menos suena relajante."

# game/beyond the bet/day8dlc.rpy:1160
translate Spanish day8dlc_start3_2ee68cbe:

    # player "You get it!"
    player "¡Eso es!"

# game/beyond the bet/day8dlc.rpy:1164
translate Spanish day8dlc_start3_6e8b66c1:

    # player "I'd go and see a movie."
    player "Iría a ver una película."

# game/beyond the bet/day8dlc.rpy:1167
translate Spanish day8dlc_start3_9eff2172:

    # player "I mean, I could do that whenever, I guess..."
    player "O sea, podría hacerlo en cualquier momento, supongo..."

# game/beyond the bet/day8dlc.rpy:1170
translate Spanish day8dlc_start3_b3fefab4:

    # player "But there's something nice about doing it on your birthday."
    player "Pero hay algo especial en hacerlo el día de tu cumpleaños."

# game/beyond the bet/day8dlc.rpy:1173
translate Spanish day8dlc_start3_b3bc8f20:

    # player "Buying the overpriced popcorn..."
    player "Comprar las palomitas carísimas..."

# game/beyond the bet/day8dlc.rpy:1176
translate Spanish day8dlc_start3_c7576af0:

    # player "Watching the stupid ads and trailers."
    player "Ver los anuncios y trailers tontos."

# game/beyond the bet/day8dlc.rpy:1179
translate Spanish day8dlc_start3_c090e850:

    # player "It's fun."
    player "Es divertido."

# game/beyond the bet/day8dlc.rpy:1180
translate Spanish day8dlc_start3_d643cff4:

    # GR "a movie."
    GR "una película."

# game/beyond the bet/day8dlc.rpy:1181
translate Spanish day8dlc_start3_94e90ea0:

    # GR "i must admit, i've never been to one of your cinemas."
    GR "debo admitir que nunca he ido a uno de sus cines."

# game/beyond the bet/day8dlc.rpy:1184
translate Spanish day8dlc_start3_f2f47468:

    # player "WHAT?"
    player "¡¿QUÉ?!"

# game/beyond the bet/day8dlc.rpy:1187
translate Spanish day8dlc_start3_a427fbb9:

    # player "We have to go!"
    player "¡Tenemos que ir!"

# game/beyond the bet/day8dlc.rpy:1190
translate Spanish day8dlc_start3_638e72ac:

    # player "I'll get to be your first!"
    player "¡Voy a ser tu primer[letra]!"

# game/beyond the bet/day8dlc.rpy:1191
translate Spanish day8dlc_start3_94585204:

    # GR "my first what???"
    GR "¿¿¿mi primer[letra] qué???"

# game/beyond the bet/day8dlc.rpy:1194
translate Spanish day8dlc_start3_ce43f590:

    # player "First person to see a movie with you!"
    player "¡[arti!c] primer[letra] en ir al cine contigo!"

# game/beyond the bet/day8dlc.rpy:1195
translate Spanish day8dlc_start3_e54ab642:

    # GR "ah. right."
    GR "ah. claro."

# game/beyond the bet/day8dlc.rpy:1196
translate Spanish day8dlc_start3_3dc91824:

    # GR "well, mortal, consider yourself lucky, because i would let you take my first time like that."
    GR "bueno, mortal, considérate afortunad[letra], porque dejaría que tomaras mi primera vez así."

# game/beyond the bet/day8dlc.rpy:1199
translate Spanish day8dlc_start3_03775ec8:

    # player "..."
    player "..."

# game/beyond the bet/day8dlc.rpy:1200
translate Spanish day8dlc_start3_14774a80_1:

    # GR "........"
    GR "........"

# game/beyond the bet/day8dlc.rpy:1201
translate Spanish day8dlc_start3_d2f158dc:

    # GR "my first time at a cinema."
    GR "mi primera vez en un cine."

# game/beyond the bet/day8dlc.rpy:1202
translate Spanish day8dlc_start3_d5c7eb26:

    # GR "...watching a movie."
    GR "...viendo una película."

# game/beyond the bet/day8dlc.rpy:1203
translate Spanish day8dlc_start3_be853df4:

    # GR "not anything else."
    GR "nada más."

# game/beyond the bet/day8dlc.rpy:1208
translate Spanish day8dlc_start3_27a1c553:

    # player "It doesn't matter, as long as I spend it with someone I love."
    player "No importa, mientras lo pase con alguien a quien quiero."

# game/beyond the bet/day8dlc.rpy:1212
translate Spanish day8dlc_start3_c5e74255:

    # player "We could be doing anything and I'll be having a great time."
    player "Podríamos estar haciendo cualquier cosa y lo pasaré genial."

# game/beyond the bet/day8dlc.rpy:1213
translate Spanish day8dlc_start3_d59ab879:

    # GR "did you... have someone in mind already?"
    GR "¿ya... tenías a alguien en mente?"

# game/beyond the bet/day8dlc.rpy:1216
translate Spanish day8dlc_start3_3994d0cd:

    # player "Hmmm..."
    player "Mmm..."

# game/beyond the bet/day8dlc.rpy:1219
translate Spanish day8dlc_start3_1cbe5d7d:

    # player "There's a certain Grim Reaper..."
    player "Hay cierta Parca..."

# game/beyond the bet/day8dlc.rpy:1222
translate Spanish day8dlc_start3_a967338b:

    # player "He's a bit of an edgelord, but he's kinda cute too..."
    player "Es un poco edgy, pero también tiene su encanto..."

# game/beyond the bet/day8dlc.rpy:1223
translate Spanish day8dlc_start3_5eaf87c0:

    # GR "i do not know who you mean."
    GR "no sé a quién te refieres."

# game/beyond the bet/day8dlc.rpy:1226
translate Spanish day8dlc_start3_2b436b4b:

    # player "Handsome face, terrible attitude."
    player "Cara guapa, actitud terrible."

# game/beyond the bet/day8dlc.rpy:1227
translate Spanish day8dlc_start3_8aaa4606:

    # GR "who?????"
    GR "¿¿¿¿quién????"

# game/beyond the bet/day8dlc.rpy:1230
translate Spanish day8dlc_start3_84f79ff6:

    # player "Long white hair, red eyes."
    player "Cabello largo y blanco, ojos rojos."

# game/beyond the bet/day8dlc.rpy:1231
translate Spanish day8dlc_start3_edd2204c_1:

    # GR "ah!"
    GR "¡ah!"

# game/beyond the bet/day8dlc.rpy:1232
translate Spanish day8dlc_start3_eb9a647a:

    # GR "of course, you mean me."
    GR "por supuesto, te refieres a mí."

# game/beyond the bet/day8dlc.rpy:1233
translate Spanish day8dlc_start3_53128e61:

    # GR "who else would catch your eye like i could?"
    GR "¿quién más podría captar tu atención como yo?"

# game/beyond the bet/day8dlc.rpy:1236
translate Spanish day8dlc_start3_bd5299ef:

    # player "What if I told you I was talking about my new neighbor?"
    player "¿Y si te dijera que hablaba de mi nuevo vecino?"

# game/beyond the bet/day8dlc.rpy:1237
translate Spanish day8dlc_start3_aeb8777a:

    # GR "i would say you are doing as all mortals do. lie."
    GR "diría que estás haciendo lo que hacen todos los mortales. mentir."

# game/beyond the bet/day8dlc.rpy:1238
translate Spanish day8dlc_start3_6ff0e641:

    # GR "go on, shower me with praise. tell me how much you adore me."
    GR "adelante, cólmame de elogios. dime cuánto me adoras."

# game/beyond the bet/day8dlc.rpy:1241
translate Spanish day8dlc_start3_e5369d65:

    # player "You're alright."
    player "No estás nada mal."

# game/beyond the bet/day8dlc.rpy:1245
translate Spanish day8dlc_start3_d938c0c8:

    # player "I really did mean my new neighbor."
    player "De verdad me refería a mi nuevo vecino."

# game/beyond the bet/day8dlc.rpy:1249
translate Spanish day8dlc_start3_6465aeb8:

    # player "You're the cutest, Grimmy <3"
    player "Eres lo más lindo, Parquita <3"

# game/beyond the bet/day8dlc.rpy:1252
translate Spanish day8dlc_start3_62bb07e8:

    # player "You are THE babygirl."
    player "Eres LA babygirl."

# game/beyond the bet/day8dlc.rpy:1255
translate Spanish day8dlc_start3_4f5c5dc4:

    # player "And my favorite one, too."
    player "Y también mi favorito."

# game/beyond the bet/day8dlc.rpy:1256
translate Spanish day8dlc_start3_7772a27d_9:

    # GR "..."
    GR "..."

# game/beyond the bet/day8dlc.rpy:1257
translate Spanish day8dlc_start3_f0532520:

    # GR "now you are being too honest."
    GR "ahora estás siendo demasiado honest[letra]."

# game/beyond the bet/day8dlc.rpy:1258
translate Spanish day8dlc_start3_9e52245e:

    # GR "go back to lying, please."
    GR "vuelve a mentir, por favor."

# game/beyond the bet/day8dlc.rpy:1259
translate Spanish day8dlc_start3_5faef636:

    # GR "it is much easier to deal with."
    GR "es mucho más fácil de manejar."

# game/beyond the bet/day8dlc.rpy:1262
translate Spanish day8dlc_start3_895c6cf1:

    # player "No <3"
    player "No <3"

# game/beyond the bet/day8dlc.rpy:1268
translate Spanish day8dlc_start3_1f0c5979:

    # player "His name is... Jeremy."
    player "Se llama... Jeremy."

# game/beyond the bet/day8dlc.rpy:1269
translate Spanish day8dlc_start3_6a95593f:

    # GR "NOT JEREMY AGAIN!"
    GR "¡JEREMY OTRA VEZ NO!"

# game/beyond the bet/day8dlc.rpy:1270
translate Spanish day8dlc_start3_a33b0822:

    # GR "curse him, curse his name, curse all that he stands for!"
    GR "¡maldito sea, maldito sea su nombre, maldito sea todo lo que representa!"

# game/beyond the bet/day8dlc.rpy:1273
translate Spanish day8dlc_start3_372770a8:

    # player "Jeremy would never talk so crudely, you know."
    player "Jeremy nunca hablaría de una forma tan vulgar, ¿sabes?"

# game/beyond the bet/day8dlc.rpy:1274
translate Spanish day8dlc_start3_913fb509:

    # GR "i care not!"
    GR "¡no me importa!"

# game/beyond the bet/day8dlc.rpy:1275
translate Spanish day8dlc_start3_ffb683b4:

    # GR "i hope jeremy suffers the cruelest fate imaginable."
    GR "espero que jeremy sufra el destino más cruel imaginable."

# game/beyond the bet/day8dlc.rpy:1278
translate Spanish day8dlc_start3_16228c1e:

    # player "What would that be?"
    player "¿Cuál sería?"

# game/beyond the bet/day8dlc.rpy:1279
translate Spanish day8dlc_start3_2d33b387:

    # GR "i hope his favorite video game shuts down within the next two months."
    GR "espero que cierren su videojuego favorito en los próximos dos meses."

# game/beyond the bet/day8dlc.rpy:1282
translate Spanish day8dlc_start3_04b457a1:

    # player "Ouch, that hurts."
    player "Auch, eso duele."

# game/beyond the bet/day8dlc.rpy:1285
translate Spanish day8dlc_start3_d35f7e86:

    # player "You're a cruel man, Grimmy."
    player "Eres cruel, Parquita."

# game/beyond the bet/day8dlc.rpy:1288
translate Spanish day8dlc_start3_05794405:

    # player "btw I was just kidding."
    player "Por cierto, solo bromeaba."

# game/beyond the bet/day8dlc.rpy:1291
translate Spanish day8dlc_start3_eb691990:

    # player "I mean you, of course."
    player "Me refería a ti, claro."

# game/beyond the bet/day8dlc.rpy:1294
translate Spanish day8dlc_start3_838a0b99:

    # player "<3"
    player "<3"

# game/beyond the bet/day8dlc.rpy:1295
translate Spanish day8dlc_start3_3f7ad2f6_2:

    # GR "oh."
    GR "oh."

# game/beyond the bet/day8dlc.rpy:1296
translate Spanish day8dlc_start3_bb1421c8:

    # GR "then jeremy can continue as he was."
    GR "entonces jeremy puede seguir como hasta ahora."

# game/beyond the bet/day8dlc.rpy:1302
translate Spanish day8dlclie_d348302a:

    # GR "lying once again i see."
    GR "mintiendo otra vez, ya veo."

# game/beyond the bet/day8dlc.rpy:1303
translate Spanish day8dlclie_3ac10d2c:

    # GR "{image=grumpy}"
    GR "{image=grumpy}"

# game/beyond the bet/day8dlc.rpy:1304
translate Spanish day8dlclie_4d8de191:

    # GR "an immensely annoying and negative trait in mortals."
    GR "un rasgo inmensamente molesto y negativo en los mortales."

# game/beyond the bet/day8dlc.rpy:1305
translate Spanish day8dlclie_77733419:

    # GR "hopefully, one day your kind will be cured of it."
    GR "ojalá algún día tu especie se cure de eso."

# game/beyond the bet/day8dlc.rpy:1308
translate Spanish day8dlclie_83bc9f70:

    # player "But I LIKE lying."
    player "Pero me GUSTA mentir."

# game/beyond the bet/day8dlc.rpy:1311
translate Spanish day8dlclie_36b39f86:

    # player "Sometimes."
    player "A veces."

# game/beyond the bet/day8dlc.rpy:1314
translate Spanish day8dlclie_3269a044:

    # player "Just small lies, you know?"
    player "Solo mentiras pequeñas, ¿sabes?"

# game/beyond the bet/day8dlc.rpy:1317
translate Spanish day8dlclie_a1bc8ce8:

    # player "Like telling the Grim Reaper he's a smelly loser."
    player "Como decirle a la Parca que es un perdedor apestoso."

# game/beyond the bet/day8dlc.rpy:1318
translate Spanish day8dlclie_f94badc6:

    # GR "shut up."
    GR "cállate."

# game/beyond the bet/day8dlc.rpy:1324
translate Spanish day8dlcchatcont_0140b952:

    # player "But why all this talk of birthdays?"
    player "¿Pero a qué viene tanta charla sobre cumpleaños?"

# game/beyond the bet/day8dlc.rpy:1325
translate Spanish day8dlcchatcont_9e49ccdc:

    # GR "that is..."
    GR "eso es..."

# game/beyond the bet/day8dlc.rpy:1326
translate Spanish day8dlcchatcont_71e5eb97:

    # GR "i was walking amongst the halls of my workplace last night..."
    GR "anoche caminaba por los pasillos de mi lugar de trabajo..."

# game/beyond the bet/day8dlc.rpy:1329
translate Spanish day8dlcchatcont_cf0a7d9f:

    # player "While you were sick???"
    player "¿¿¿Mientras estabas enfermo???"

# game/beyond the bet/day8dlc.rpy:1330
translate Spanish day8dlcchatcont_8027ae90:

    # GR "there is not enough time to worry about that."
    GR "no hay tiempo suficiente para preocuparse por eso."

# game/beyond the bet/day8dlc.rpy:1331
translate Spanish day8dlcchatcont_37c2acb6:

    # GR "i had to find out more. about our strange... connection."
    GR "tenía que averiguar más. sobre nuestra extraña... conexión."

# game/beyond the bet/day8dlc.rpy:1332
translate Spanish day8dlcchatcont_942248a6:

    # GR "the link beyond the one i created between us."
    GR "el vínculo más allá del que yo creé entre nosotros."

# game/beyond the bet/day8dlc.rpy:1333
translate Spanish day8dlcchatcont_169fda3d:

    # GR "it was late. i happened to overhear some superiors talking quietly..."
    GR "era tarde. casualmente escuché a unos superiores hablando en voz baja..."

# game/beyond the bet/day8dlc.rpy:1334
translate Spanish day8dlcchatcont_eb451a5b:

    # GR "for context, i am of the 13th station, grim reaper number 8394."
    GR "para dar contexto, pertenezco a la estación 13, parca número 8394."

# game/beyond the bet/day8dlc.rpy:1335
translate Spanish day8dlcchatcont_ae98984c:

    # GR "...they said that..."
    GR "...dijeron que..."

# game/beyond the bet/day8dlc.rpy:1336
translate Spanish day8dlcchatcont_27433513:

    # GR "those numbered 8100-8400 of the 13th station were created on this day, many decades ago."
    GR "los numerados del 8100 al 8400 de la estación 13 fueron creados este mismo día, hace muchas décadas."

# game/beyond the bet/day8dlc.rpy:1339
translate Spanish day8dlcchatcont_03775ec8:

    # player "..."
    player "..."

# game/beyond the bet/day8dlc.rpy:1341
translate Spanish day8dlcchatcont_998f96ed:

    # player "Wait a second..."
    player "Espera un segundo..."

# game/beyond the bet/day8dlc.rpy:1343
translate Spanish day8dlcchatcont_720609f2:

    # player "You're telling me..."
    player "Me estás diciendo..."

# game/beyond the bet/day8dlc.rpy:1346
translate Spanish day8dlcchatcont_cc08f46b:

    # player "TODAY IS YOUR BIRTHDAY??????"
    player "¡¿HOY ES TU CUMPLEAÑOS??????"

# game/beyond the bet/day8dlc.rpy:1347
translate Spanish day8dlcchatcont_c76e5f47:

    # GR "it is a stretch of the word, perhaps, but..."
    GR "quizá no sea exactamente la palabra adecuada, pero..."

# game/beyond the bet/day8dlc.rpy:1348
translate Spanish day8dlcchatcont_83c22eb8:

    # GR "it is something like that."
    GR "es algo así."

# game/beyond the bet/day8dlc.rpy:1349
translate Spanish day8dlcchatcont_d29e466b:

    # GR "an anniversary day for my creation."
    GR "un día de aniversario de mi creación."

# game/beyond the bet/day8dlc.rpy:1352
translate Spanish day8dlcchatcont_953ab193:

    # player "Happy Birthday Casper!!!!"
    player "¡¡¡¡Feliz cumpleaños, Casper!!!!"

# game/beyond the bet/day8dlc.rpy:1355
translate Spanish day8dlcchatcont_23748847:

    # player "You never knew before???"
    player "¿¿¿Nunca lo habías sabido???"

# game/beyond the bet/day8dlc.rpy:1356
translate Spanish day8dlcchatcont_fb937206:

    # GR "thank you."
    GR "gracias."

# game/beyond the bet/day8dlc.rpy:1357
translate Spanish day8dlcchatcont_70b55bbd:

    # GR "and... no. i did not."
    GR "y... no. no lo sabía."

# game/beyond the bet/day8dlc.rpy:1358
translate Spanish day8dlcchatcont_0edbbbfe:

    # GR "things like birthdays, names, these do not matter to a grim reaper."
    GR "cosas como los cumpleaños, los nombres, no le importan a una parca."

# game/beyond the bet/day8dlc.rpy:1361
translate Spanish day8dlcchatcont_3706b912:

    # player "Not including you, right?"
    player "Tú eres la excepción, ¿verdad?"

# game/beyond the bet/day8dlc.rpy:1362
translate Spanish day8dlcchatcont_7772a27d:

    # GR "..."
    GR "..."

# game/beyond the bet/day8dlc.rpy:1363
translate Spanish day8dlcchatcont_ee6ccac3:

    # GR "i am becoming more... different from my brethren each day..."
    GR "cada día me vuelvo más... diferente de mis semejantes..."

# game/beyond the bet/day8dlc.rpy:1364
translate Spanish day8dlcchatcont_16f9bc35:

    # GR "it is worrisome."
    GR "es preocupante."

# game/beyond the bet/day8dlc.rpy:1367
translate Spanish day8dlcchatcont_a099fa1e:

    # player "I think it's great."
    player "Yo creo que es genial."

# game/beyond the bet/day8dlc.rpy:1369
translate Spanish day8dlcchatcont_cc4c3ef4:

    # player "Is it so bad?"
    player "¿Es tan malo?"

# game/beyond the bet/day8dlc.rpy:1371
translate Spanish day8dlcchatcont_a57fa986:

    # player "You're more and more human every day."
    player "Cada día eres más y más humano."

# game/beyond the bet/day8dlc.rpy:1372
translate Spanish day8dlcchatcont_7772a27d_1:

    # GR "..."
    GR "..."

# game/beyond the bet/day8dlc.rpy:1373
translate Spanish day8dlcchatcont_b2957e6b:

    # GR "i worry that what i was content with previously will no longer fulfill me."
    GR "me preocupa que lo que antes me bastaba ya no me satisfaga."

# game/beyond the bet/day8dlc.rpy:1374
translate Spanish day8dlcchatcont_46fd8d11:

    # GR "and that changes everything i am. everything i live for."
    GR "y eso lo cambia todo en mí. todo por lo que vivo."

# game/beyond the bet/day8dlc.rpy:1375
translate Spanish day8dlcchatcont_fc415828:

    # GR "it is... concerning. disconcerting."
    GR "es... inquietante. desconcertante."

# game/beyond the bet/day8dlc.rpy:1378
translate Spanish day8dlcchatcont_f944213b:

    # player "Well, I'm sorry you feel like that."
    player "Bueno, lamento que te sientas así."

# game/beyond the bet/day8dlc.rpy:1381
translate Spanish day8dlcchatcont_22ee8f9c:

    # player "I, for one, am enjoying this Grim Reaper with unexpected emotions and attachments."
    player "Yo, por mi parte, estoy disfrutando de esta Parca con emociones y vínculos inesperados."

# game/beyond the bet/day8dlc.rpy:1384
translate Spanish day8dlcchatcont_8aaec1d3:

    # player "If you could do anything..."
    player "Si pudieras hacer lo que quisieras..."

# game/beyond the bet/day8dlc.rpy:1387
translate Spanish day8dlcchatcont_a1679093:

    # player "What would you do for your birthday, Casper?"
    player "¿Qué harías por tu cumpleaños, Casper?"

# game/beyond the bet/day8dlc.rpy:1390
translate Spanish day8dlcchatcont_62c6e2f6:

    # player "Hey, Casper..."
    player "Oye, Casper..."

# game/beyond the bet/day8dlc.rpy:1393
translate Spanish day8dlcchatcont_8f1e81e3:

    # player "Forget other people. What would YOU do for your birthday, if you could?"
    player "Olvida a los demás. ¿Qué harías TÚ por tu cumpleaños, si pudieras?"

# game/beyond the bet/day8dlc.rpy:1395
translate Spanish day8dlcchatcont_8e011b10:

    # GR "i... hmm..."
    GR "yo... hmm..."

# game/beyond the bet/day8dlc.rpy:1396
translate Spanish day8dlcchatcont_b6d4ee61:

    # GR "i am unsure of what to pick..."
    GR "no estoy seguro de qué elegir..."

# game/beyond the bet/day8dlc.rpy:1397
translate Spanish day8dlcchatcont_f3905d0e:

    # GR "it seems there are many options."
    GR "parece que hay muchas opciones."

# game/beyond the bet/day8dlc.rpy:1400
translate Spanish day8dlcchatcont_b9079108:

    # player "It doesn't need to be that deep."
    player "No hay que darle tantas vueltas."

# game/beyond the bet/day8dlc.rpy:1402
translate Spanish day8dlcchatcont_b0e0d192:

    # player "Don't think too hard."
    player "No lo pienses tanto."

# game/beyond the bet/day8dlc.rpy:1405
translate Spanish day8dlcchatcont_21ef13c8:

    # player "It could be anything."
    player "Puede ser cualquier cosa."

# game/beyond the bet/day8dlc.rpy:1407
translate Spanish day8dlcchatcont_f46d97cc:

    # player "Your imagination's the limit."
    player "Tu imaginación es el límite."

# game/beyond the bet/day8dlc.rpy:1408
translate Spanish day8dlcchatcont_2cfbaea0:

    # GR "well..."
    GR "bueno..."

# game/beyond the bet/day8dlc.rpy:1409
translate Spanish day8dlcchatcont_1c3ada68:

    # GR "i would enjoy seeing a sight i have never seen before."
    GR "disfrutaría ver algo que nunca he visto antes."

# game/beyond the bet/day8dlc.rpy:1412
translate Spanish day8dlcchatcont_a59a422e:

    # player "Like...?"
    player "¿Como qué...?"

# game/beyond the bet/day8dlc.rpy:1413
translate Spanish day8dlcchatcont_945d5813:

    # GR "you are awfully pressing."
    GR "eres terriblemente insistente."

# game/beyond the bet/day8dlc.rpy:1414
translate Spanish day8dlcchatcont_8b9d65c5:

    # GR "something very... human."
    GR "algo muy... humano."

# game/beyond the bet/day8dlc.rpy:1415
translate Spanish day8dlcchatcont_868b04e6:

    # GR "something fleeting."
    GR "algo fugaz."

# game/beyond the bet/day8dlc.rpy:1418
translate Spanish day8dlcchatcont_37fc2ad0:

    # player "Love?"
    player "¿Amor?"

# game/beyond the bet/day8dlc.rpy:1419
translate Spanish day8dlcchatcont_01d33b20:

    # GR "would you say love is fleeting?"
    GR "¿dirías que el amor es fugaz?"

# game/beyond the bet/day8dlc.rpy:1422
translate Spanish day8dlcchatcont_59e489a6:

    # player "It can be."
    player "Puede serlo."

# game/beyond the bet/day8dlc.rpy:1424
translate Spanish day8dlcchatcont_d2503af0:

    # player "It depends who you love."
    player "Depende de a quién ames."

# game/beyond the bet/day8dlc.rpy:1427
translate Spanish day8dlcchatcont_a54e5c51:

    # player "Feelings can change, newness can wear off..."
    player "Los sentimientos pueden cambiar, la novedad puede desgastarse..."

# game/beyond the bet/day8dlc.rpy:1428
translate Spanish day8dlcchatcont_ab67337a:

    # GR "i would like to think that newness wearing off leads to comfort."
    GR "me gustaría pensar que el desgaste de la novedad conduce a la comodidad."

# game/beyond the bet/day8dlc.rpy:1429
translate Spanish day8dlcchatcont_d5e8d32b:

    # GR "so something deeper, to something more... real."
    GR "y de ahí a algo más profundo, a algo más... real."

# game/beyond the bet/day8dlc.rpy:1430
translate Spanish day8dlcchatcont_4b583710:

    # GR "does change mean less love? or is being changed by love something less fleeting?"
    GR "¿cambiar significa menos amor? ¿o ser cambiado por el amor es algo menos fugaz?"

# game/beyond the bet/day8dlc.rpy:1433
translate Spanish day8dlcchatcont_1b98eb03:

    # player "Well..."
    player "Bueno..."

# game/beyond the bet/day8dlc.rpy:1436
translate Spanish day8dlcchatcont_c35a9639:

    # player "I think true love is eternal."
    player "Creo que el amor verdadero es eterno."

# game/beyond the bet/day8dlc.rpy:1439
translate Spanish day8dlcchatcont_e028b885:

    # player "Sure, I mean, everyone dies..."
    player "Claro, o sea, todos morimos..."

# game/beyond the bet/day8dlc.rpy:1442
translate Spanish day8dlcchatcont_84ba9458:

    # player "Maybe not you?"
    player "¿Quizás tú no?"

# game/beyond the bet/day8dlc.rpy:1445
translate Spanish day8dlcchatcont_8e79fec7:

    # player "But love leaves a mark on you that goes past that."
    player "Pero el amor deja en ti una huella que va más allá de eso."

# game/beyond the bet/day8dlc.rpy:1448
translate Spanish day8dlcchatcont_ccdf9f54:

    # player "Don't you think?"
    player "¿No crees?"

# game/beyond the bet/day8dlc.rpy:1449
translate Spanish day8dlcchatcont_0806b5a1:

    # GR "those that die surrounded by love have warmer souls, you know."
    GR "quienes mueren rodeados de amor tienen almas más cálidas, ¿sabes?"

# game/beyond the bet/day8dlc.rpy:1450
translate Spanish day8dlcchatcont_84c640eb:

    # GR "brighter ones."
    GR "más brillantes."

# game/beyond the bet/day8dlc.rpy:1451
translate Spanish day8dlcchatcont_9ef0513c:

    # GR "your hypothesis may be correct."
    GR "tu hipótesis puede ser correcta."

# game/beyond the bet/day8dlc.rpy:1455
translate Spanish day8dlcchatcont_0ddc84ce:

    # player "I think everything ends."
    player "Creo que todo termina."

# game/beyond the bet/day8dlc.rpy:1458
translate Spanish day8dlcchatcont_e5f770c0:

    # player "But the destination doesn't make the journey any less worth pursuing."
    player "Pero el destino no hace que el camino valga menos la pena."

# game/beyond the bet/day8dlc.rpy:1461
translate Spanish day8dlcchatcont_ba2c282e:

    # player "That's the nice thing about something being fleeting."
    player "Eso es lo bonito de algo fugaz."

# game/beyond the bet/day8dlc.rpy:1464
translate Spanish day8dlcchatcont_5ea6bebc:

    # player "You appreciate it all the more when you reach your destination."
    player "Lo aprecias aún más cuando llegas a tu destino."

# game/beyond the bet/day8dlc.rpy:1468
translate Spanish day8dlcchatcont_42d092de:

    # player "Fireflies!"
    player "¡Luciérnagas!"

# game/beyond the bet/day8dlc.rpy:1469
translate Spanish day8dlcchatcont_322cb5e7:

    # GR "fireflies?"
    GR "¿luciérnagas?"

# game/beyond the bet/day8dlc.rpy:1472
translate Spanish day8dlcchatcont_a501292e:

    # player "Have you ever heard of synchronous fireflies?"
    player "¿Has oído hablar de las luciérnagas sincrónicas?"

# game/beyond the bet/day8dlc.rpy:1473
translate Spanish day8dlcchatcont_681113d3:

    # GR "i cannot say i have."
    GR "no puedo decir que sí."

# game/beyond the bet/day8dlc.rpy:1476
translate Spanish day8dlcchatcont_c4576b0a:

    # player "They're a kind of firefly that, for a couple of months a year..."
    player "Son un tipo de luciérnaga que, un par de meses al año..."

# game/beyond the bet/day8dlc.rpy:1479
translate Spanish day8dlcchatcont_1f9a6e9f:

    # player "All blink at the same time!"
    player "¡Parpadean todas al mismo tiempo!"

# game/beyond the bet/day8dlc.rpy:1480
translate Spanish day8dlcchatcont_e930b2cc:

    # GR "that is... fascinating."
    GR "eso es... fascinante."

# game/beyond the bet/day8dlc.rpy:1483
translate Spanish day8dlcchatcont_c3819796:

    # player "I've never seen it, but it sounds beautiful."
    player "Nunca las he visto, pero suena hermoso."

# game/beyond the bet/day8dlc.rpy:1485
translate Spanish day8dlcchatcont_7fddb2fb:

    # player "I went and saw them once."
    player "Fui a verlas una vez."

# game/beyond the bet/day8dlc.rpy:1486
translate Spanish day8dlcchatcont_7e3de6c6:

    # GR "why do they do that?"
    GR "¿por qué hacen eso?"

# game/beyond the bet/day8dlc.rpy:1489
translate Spanish day8dlcchatcont_3704a528:

    # player "Um..."
    player "Eh..."

# game/beyond the bet/day8dlc.rpy:1492
translate Spanish day8dlcchatcont_c870ab29:

    # player "It's a mating thing, actually..."
    player "En realidad, es cosa de apareamiento..."

# game/beyond the bet/day8dlc.rpy:1493
translate Spanish day8dlcchatcont_a6de612c:

    # GR "ah."
    GR "ah."

# game/beyond the bet/day8dlc.rpy:1494
translate Spanish day8dlcchatcont_16c4b8e0:

    # GR "your knowledge of mating rituals is vast, mortal."
    GR "tu conocimiento de los rituales de apareamiento es vasto, mortal."

# game/beyond the bet/day8dlc.rpy:1497
translate Spanish day8dlcchatcont_383a7b75:

    # player "Oh, you don't know the half of it."
    player "Oh, no sabes ni la mitad."

# game/beyond the bet/day8dlc.rpy:1498
translate Spanish day8dlcchatcont_ef3db055:

    # GR "i believe i do, after all the things you have said to me."
    GR "creo que sí, después de todas las cosas que me has dicho."

# game/beyond the bet/day8dlc.rpy:1501
translate Spanish day8dlcchatcont_6df9b52a:

    # player "I've got a lot more I could tell you about."
    player "Tengo mucho más que podría contarte."

# game/beyond the bet/day8dlc.rpy:1504
translate Spanish day8dlcchatcont_2f1c4429:

    # player "A special birthday treat."
    player "Un regalo especial de cumpleaños."

# game/beyond the bet/day8dlc.rpy:1505
translate Spanish day8dlcchatcont_d4e24c22:

    # GR "AHEM..."
    GR "EJEM..."

# game/beyond the bet/day8dlc.rpy:1509
translate Spanish day8dlcchatcont_d9eef235:

    # player "Maybe we can learn more together?"
    player "¿Tal vez podamos aprender más juntos?"

# game/beyond the bet/day8dlc.rpy:1510
translate Spanish day8dlcchatcont_c760d76f:

    # GR "about fireflies mating?"
    GR "¿sobre el apareamiento de luciérnagas?"

# game/beyond the bet/day8dlc.rpy:1513
translate Spanish day8dlcchatcont_e70a0812:

    # player "Um."
    player "Eh."

# game/beyond the bet/day8dlc.rpy:1516
translate Spanish day8dlcchatcont_6f13cba8:

    # player "I was thinking humans."
    player "Estaba pensando en humanos."

# game/beyond the bet/day8dlc.rpy:1519
translate Spanish day8dlcchatcont_5a6c8a8f:

    # player "Or... reapers?"
    player "O... ¿parcas?"

# game/beyond the bet/day8dlc.rpy:1522
translate Spanish day8dlcchatcont_d21a77dc:

    # player "Or both together."
    player "O ambos juntos."

# game/beyond the bet/day8dlc.rpy:1525
translate Spanish day8dlcchatcont_41892cc7:

    # player ";)"
    player ";)"

# game/beyond the bet/day8dlc.rpy:1529
translate Spanish day8dlcchatcont_8cdb99d7:

    # player "How about the Aurora Borealis?"
    player "¿Y qué tal la aurora boreal?"

# game/beyond the bet/day8dlc.rpy:1530
translate Spanish day8dlcchatcont_fd68b219:

    # GR "i have seen the northern lights before."
    GR "ya he visto las auroras boreales."

# game/beyond the bet/day8dlc.rpy:1531
translate Spanish day8dlcchatcont_16210a3d:

    # GR "they are very beautiful."
    GR "son muy hermosas."

# game/beyond the bet/day8dlc.rpy:1534
translate Spanish day8dlcchatcont_09cb4046:

    # player "WOAH! I'm jealous!"
    player "¡UY! ¡Qué envidia!"

# game/beyond the bet/day8dlc.rpy:1535
translate Spanish day8dlcchatcont_bafc8370:

    # GR "being jealous of me is like a natural state for others."
    GR "sentir envidia de mí es como un estado natural para los demás."

# game/beyond the bet/day8dlc.rpy:1538
translate Spanish day8dlcchatcont_49407c3c:

    # player "Alright Mr Showoff!"
    player "¡Está bien, señor presumido!"

# game/beyond the bet/day8dlc.rpy:1540
translate Spanish day8dlcchatcont_038a504e:

    # player "Blah blah blah."
    player "Bla, bla, bla."

# game/beyond the bet/day8dlc.rpy:1541
translate Spanish day8dlcchatcont_bcac2884:

    # GR "you would like to see it?"
    GR "¿te gustaría verla?"

# game/beyond the bet/day8dlc.rpy:1544
translate Spanish day8dlcchatcont_9c8b3212:

    # player "Yeah!"
    player "¡Sí!"

# game/beyond the bet/day8dlc.rpy:1546
translate Spanish day8dlcchatcont_800fb37c:

    # player "I'd love to."
    player "Me encantaría."

# game/beyond the bet/day8dlc.rpy:1549
translate Spanish day8dlcchatcont_a560ecfa:

    # player "One day, I hope."
    player "Algún día, espero."

# game/beyond the bet/day8dlc.rpy:1553
translate Spanish day8dlcchatcont_c77d22c7:

    # player "You know, if this whole dying thing doesn't work out."
    player "Ya sabes, si todo esto de morir no resulta."

# game/beyond the bet/day8dlc.rpy:1557
translate Spanish day8dlcchatcont_aa97933d:

    # player "I feel like it won't ever happen..."
    player "Siento que nunca va a pasar..."

# game/beyond the bet/day8dlc.rpy:1561
translate Spanish day8dlcchatcont_b92094a0:

    # player "It's an expensive trip."
    player "Es un viaje caro."

# game/beyond the bet/day8dlc.rpy:1563
translate Spanish day8dlcchatcont_2f67896b:

    # GR "i could take you there."
    GR "podría llevarte allí."

# game/beyond the bet/day8dlc.rpy:1566
translate Spanish day8dlcchatcont_11ea400e:

    # player "You could...?"
    player "¿Podrías...?"

# game/beyond the bet/day8dlc.rpy:1570
translate Spanish day8dlcchatcont_ae014d05:

    # player "I saw it once, too!"
    player "¡Yo también las vi una vez!"

# game/beyond the bet/day8dlc.rpy:1573
translate Spanish day8dlcchatcont_893be241:

    # player "I've never seen something so beautiful."
    player "Nunca he visto algo tan hermoso."

# game/beyond the bet/day8dlc.rpy:1575
translate Spanish day8dlcchatcont_5058681f:

    # player "I want to see it again, one day..."
    player "Quiero volver a verlas algún día..."

# game/beyond the bet/day8dlc.rpy:1576
translate Spanish day8dlcchatcont_936c67e6:

    # GR "it is rather magnificent."
    GR "son bastante magníficas."

# game/beyond the bet/day8dlc.rpy:1577
translate Spanish day8dlcchatcont_a02f0c96:

    # GR "i could take you to it again, if you wanted."
    GR "podría llevarte de nuevo, si quisieras."

# game/beyond the bet/day8dlc.rpy:1580
translate Spanish day8dlcchatcont_e4104706:

    # player "It's kinda pretty far away."
    player "Queda bastante lejos."

# game/beyond the bet/day8dlc.rpy:1582
translate Spanish day8dlcchatcont_d918fd05:

    # player "It's on the other side of the world!"
    player "¡Está al otro lado del mundo!"

# game/beyond the bet/day8dlc.rpy:1587
translate Spanish loveafter_e3727722:

    # GR "either way..."
    GR "de cualquier modo..."

# game/beyond the bet/day8dlc.rpy:1588
translate Spanish loveafter_6936effa:

    # GR "i think that is something i..."
    GR "creo que eso es algo que yo..."

# game/beyond the bet/day8dlc.rpy:1589
translate Spanish loveafter_0b16bee0:

    # GR "ahem."
    GR "ejem."

# game/beyond the bet/day8dlc.rpy:1590
translate Spanish loveafter_6964a2cd:

    # GR "don't worry about it."
    GR "no te preocupes por eso."

# game/beyond the bet/day8dlc.rpy:1594
translate Spanish aurora_9fa1a707:

    # GR "it is a simple trip for someone like me."
    GR "es un viaje sencillo para alguien como yo."

# game/beyond the bet/day8dlc.rpy:1597
translate Spanish aurora_3a0fc26e:

    # player "I thought you wouldn't let me fly with you!"
    player "¡Pensé que no me dejarías volar contigo!"

# game/beyond the bet/day8dlc.rpy:1598
translate Spanish aurora_7772a27d:

    # GR "..."
    GR "..."

# game/beyond the bet/day8dlc.rpy:1599
translate Spanish aurora_511092c8:

    # GR "perhaps i have reconsidered."
    GR "quizás lo he reconsiderado."

# game/beyond the bet/day8dlc.rpy:1600
translate Spanish aurora_ad209625:

    # GR "if you fall, you will only have yourself to blame, though."
    GR "si te caes, solo podrás culparte a ti, eso sí."

# game/beyond the bet/day8dlc.rpy:1603
translate Spanish aurora_5f833a74:

    # player "What if you drop me?"
    player "¿Y si me sueltas?"

# game/beyond the bet/day8dlc.rpy:1604
translate Spanish aurora_e632753e:

    # GR "it will be because of something you have done, not the other way around."
    GR "será por algo que hayas hecho tú, no al revés."

# game/beyond the bet/day8dlc.rpy:1605
translate Spanish aurora_8941f845:

    # GR "i do not make mistakes."
    GR "yo no cometo errores."

# game/beyond the bet/day8dlc.rpy:1608
translate Spanish aurora_bcef9dee:

    # player "Then count me in!"
    player "¡Entonces cuenta conmigo!"

# game/beyond the bet/day8dlc.rpy:1612
translate Spanish day8dlcchatmore_6a79b94e:

    # GR "that can... come later."
    GR "eso puede... quedar para más adelante."

# game/beyond the bet/day8dlc.rpy:1613
translate Spanish day8dlcchatmore_b757df9e:

    # GR "for celebrating the day of my creation, i am still not sure what i would do."
    GR "en cuanto a celebrar el día de mi creación, aún no estoy seguro de qué haría."

# game/beyond the bet/day8dlc.rpy:1614
translate Spanish day8dlcchatmore_ced20603:

    # GR "i mean, i won't be doing anything."
    GR "o sea, no haré nada."

# game/beyond the bet/day8dlc.rpy:1617
translate Spanish day8dlcchatmore_89d48a0a:

    # player "No hell-themed birthday party :( ?"
    player "¿Nada de fiesta de cumpleaños temática del infierno? :("

# game/beyond the bet/day8dlc.rpy:1618
translate Spanish day8dlcchatmore_5d364529:

    # GR "no."
    GR "no."

# game/beyond the bet/day8dlc.rpy:1621
translate Spanish day8dlcchatmore_0d8c2ee1:

    # player "How about putting on a party hat?"
    player "¿Y ponerte un gorrito de fiesta?"

# game/beyond the bet/day8dlc.rpy:1622
translate Spanish day8dlcchatmore_3b3dfa36:

    # GR "no. that would look stupid."
    GR "no. se vería estúpido."

# game/beyond the bet/day8dlc.rpy:1625
translate Spanish day8dlcchatmore_2909941a:

    # player "Pin the tail on the imp?"
    player "¿Ponerle la cola al diablito?"

# game/beyond the bet/day8dlc.rpy:1626
translate Spanish day8dlcchatmore_26275723:

    # GR "what? that's preposterous."
    GR "¿qué? eso es absurdo."

# game/beyond the bet/day8dlc.rpy:1627
translate Spanish day8dlcchatmore_20139923:

    # GR "imps would not appreciate that in the slightest."
    GR "a los diablitos no les haría ni pizca de gracia."

# game/beyond the bet/day8dlc.rpy:1630
translate Spanish day8dlcchatmore_942552db:

    # player "It's not a real imp, dummy."
    player "No es un diablito de verdad, tonto."

# game/beyond the bet/day8dlc.rpy:1631
translate Spanish day8dlcchatmore_376bd036:

    # GR "it is a fake imp?"
    GR "¿es un diablito falso?"

# game/beyond the bet/day8dlc.rpy:1632
translate Spanish day8dlcchatmore_2ab8ae27:

    # GR "why would you want to stick a tail on a fake imp?"
    GR "¿por qué le pondrías una cola a un diablito falso?"

# game/beyond the bet/day8dlc.rpy:1633
translate Spanish day8dlcchatmore_1a98d515:

    # GR "mortals games are inferior beyond words."
    GR "los juegos de los mortales son inferiores más allá de toda descripción."

# game/beyond the bet/day8dlc.rpy:1636
translate Spanish day8dlcchatmore_d8cf5efa:

    # player "Alright, what would you underworld dwellers do at a kid's birthday party?"
    player "Está bien, ¿qué harían ustedes, los habitantes del inframundo, en una fiesta infantil?"

# game/beyond the bet/day8dlc.rpy:1637
translate Spanish day8dlcchatmore_21c54691:

    # GR "there are no kids to have a birthday party for!"
    GR "¡no hay niños a quienes hacer una fiesta de cumpleaños!"

# game/beyond the bet/day8dlc.rpy:1640
translate Spanish day8dlcchatmore_6a4dd5ec:

    # player "Not even any, like..."
    player "Ni siquiera, como..."

# game/beyond the bet/day8dlc.rpy:1643
translate Spanish day8dlcchatmore_7b967190:

    # player "Child demons or something?"
    player "¿Niños demonio o algo así?"

# game/beyond the bet/day8dlc.rpy:1644
translate Spanish day8dlcchatmore_5d364529_1:

    # GR "no."
    GR "no."

# game/beyond the bet/day8dlc.rpy:1647
translate Spanish day8dlcchatmore_8d4e76e6:

    # player "You guys have to do SOMETHING for fun!"
    player "¡Ustedes tienen que hacer ALGO para divertirse!"

# game/beyond the bet/day8dlc.rpy:1648
translate Spanish day8dlcchatmore_4e0392e9:

    # GR "some of the reapers celebrate things with bets."
    GR "algunas parcas celebran las cosas con apuestas."

# game/beyond the bet/day8dlc.rpy:1651
translate Spanish day8dlcchatmore_335f658e:

    # player "AH!"
    player "¡AH!"

# game/beyond the bet/day8dlc.rpy:1654
translate Spanish day8dlcchatmore_12e2c003:

    # player "Is that why you were so into our bet?"
    player "¿Es por eso que te interesó tanto nuestra apuesta?"

# game/beyond the bet/day8dlc.rpy:1655
translate Spanish day8dlcchatmore_82d3425d:

    # GR "yes, bets are an honored, sacred tradition."
    GR "sí, las apuestas son una tradición honorable y sagrada."

# game/beyond the bet/day8dlc.rpy:1658
translate Spanish day8dlcchatmore_53910387:

    # player "What do they bet over?"
    player "¿Sobre qué apuestan?"

# game/beyond the bet/day8dlc.rpy:1659
translate Spanish day8dlcchatmore_eba139e9:

    # GR "when a mortal will die, or how quickly they can take a soul."
    GR "sobre cuándo morirá un mortal, o con qué rapidez pueden tomar un alma."

# game/beyond the bet/day8dlc.rpy:1662
translate Spanish day8dlcchatmore_58f26849:

    # player "Morbid. Nice."
    player "Macabro. Genial."

# game/beyond the bet/day8dlc.rpy:1667
translate Spanish day8dlcchatmore_0fa79698:

    # player "How do you know?"
    player "¿Cómo lo sabes?"

# game/beyond the bet/day8dlc.rpy:1670
translate Spanish day8dlcchatmore_463fb653:

    # player "You ever asked an imp?"
    player "¿Alguna vez le has preguntado a un diablito?"

# game/beyond the bet/day8dlc.rpy:1671
translate Spanish day8dlcchatmore_9b73914f:

    # GR "i... have not... but who would appreciate anything being stuck in them like that?!"
    GR "yo... no lo he hecho... ¡¿pero a quién le gustaría que le metieran algo así?!"

# game/beyond the bet/day8dlc.rpy:1674
translate Spanish day8dlcchatmore_c0a8bcf3:

    # player "You never know if you don't ask."
    player "Nunca lo sabrás si no preguntas."

# game/beyond the bet/day8dlc.rpy:1675
translate Spanish day8dlcchatmore_3d0eb0ca:

    # GR "sure."
    GR "claro."

# game/beyond the bet/day8dlc.rpy:1676
translate Spanish day8dlcchatmore_153442a2:

    # GR "i will stroll up to an imp, and say 'hello, fine imp. would you allow me to stick a tail into your rear?'."
    GR "me acercaré a un diablito y le diré 'hola, distinguido diablito. ¿me permitiría colocarle una cola en el trasero?'."

# game/beyond the bet/day8dlc.rpy:1677
translate Spanish day8dlcchatmore_a1dccba4:

    # GR "im sure it will be well received."
    GR "seguro que será bien recibido."

# game/beyond the bet/day8dlc.rpy:1680
translate Spanish day8dlcchatmore_7848dedf:

    # player "Yeah, you should try it. Really."
    player "Sí, deberías intentarlo. En serio."

# game/beyond the bet/day8dlc.rpy:1681
translate Spanish day8dlcchatmore_15232f00:

    # GR "are you being totally serious right now?"
    GR "¿hablas totalmente en serio ahora?"

# game/beyond the bet/day8dlc.rpy:1684
translate Spanish day8dlcchatmore_034a30ac:

    # player "I am."
    player "Sí."

# game/beyond the bet/day8dlc.rpy:1687
translate Spanish day8dlcchatmore_e09594e9:

    # player "I, for one, would relish in the opportunity."
    player "Yo, por mi parte, disfrutaría la oportunidad."

# game/beyond the bet/day8dlc.rpy:1688
translate Spanish day8dlcchatmore_04c1bfd7:

    # GR "i am surprised, mortal."
    GR "me sorprendes, mortal."

# game/beyond the bet/day8dlc.rpy:1689
translate Spanish day8dlcchatmore_6087182f:

    # GR "i did not think anyone would want to have a tail stuck in them."
    GR "no pensé que a alguien le gustaría que le colocaran una cola."

# game/beyond the bet/day8dlc.rpy:1690
translate Spanish day8dlcchatmore_3d4e2e0b:

    # GR "now you are making me feel like I'M the wrong one."
    GR "ahora me estás haciendo sentir como si YO fuera el equivocado."

# game/beyond the bet/day8dlc.rpy:1693
translate Spanish day8dlcchatmore_74e7a31f:

    # player "Gaslighting = success?"
    player "¿Gaslighting = éxito?"

# game/beyond the bet/day8dlc.rpy:1694
translate Spanish day8dlcchatmore_20c56e61:

    # GR "what is that word?"
    GR "¿qué es esa palabra?"

# game/beyond the bet/day8dlc.rpy:1697
translate Spanish day8dlcchatmore_6ef2e76f:

    # player "What word?"
    player "¿Qué palabra?"

# game/beyond the bet/day8dlc.rpy:1698
translate Spanish day8dlcchatmore_612572c2:

    # GR "you said it above."
    GR "la dijiste arriba."

# game/beyond the bet/day8dlc.rpy:1699
translate Spanish day8dlcchatmore_be8c31d1:

    # GR "gaslighting."
    GR "gaslighting."

# game/beyond the bet/day8dlc.rpy:1702
translate Spanish day8dlcchatmore_c2d74f20:

    # player "What do you mean?"
    player "¿Qué quieres decir?"

# game/beyond the bet/day8dlc.rpy:1705
translate Spanish day8dlcchatmore_931510c7:

    # player "I've never seen that before."
    player "Nunca había visto eso."

# game/beyond the bet/day8dlc.rpy:1706
translate Spanish day8dlcchatmore_6ad9d842:

    # GR "you just said it!"
    GR "¡acabas de decirlo!"

# game/beyond the bet/day8dlc.rpy:1709
translate Spanish day8dlcchatmore_9f8b7b96:

    # player "No I didn't."
    player "No, no lo dije."

# game/beyond the bet/day8dlc.rpy:1710
translate Spanish day8dlcchatmore_f0d9deb7:

    # GR "you are making no sense."
    GR "lo que dices no tiene sentido."

# game/beyond the bet/day8dlc.rpy:1711
translate Spanish day8dlcchatmore_4454b7cc:

    # GR "i can see it."
    GR "puedo verla."

# game/beyond the bet/day8dlc.rpy:1712
translate Spanish day8dlcchatmore_d8433fb8:

    # GR "it's right there."
    GR "está ahí mismo."

# game/beyond the bet/day8dlc.rpy:1715
translate Spanish day8dlcchatmore_9edb757d:

    # player "Hehe."
    player "Jeje."

# game/beyond the bet/day8dlc.rpy:1718
translate Spanish day8dlcchatmore_40f25801:

    # player "A practical example of gaslighting."
    player "Un ejemplo práctico de gaslighting."

# game/beyond the bet/day8dlc.rpy:1721
translate Spanish day8dlcchatmore_027a2ae0:

    # player "Not bad, huh?"
    player "Nada mal, ¿eh?"

# game/beyond the bet/day8dlc.rpy:1722
translate Spanish day8dlcchatmore_ba09e762:

    # GR "i do not understand and you are a brainless fool."
    GR "no entiendo y eres [arti_2] tont[letra] sin cerebro."

# game/beyond the bet/day8dlc.rpy:1725
translate Spanish day8dlcchatmore_d78d49b7:

    # player "Thank you <3"
    player "Gracias <3"

# game/beyond the bet/day8dlc.rpy:1729
translate Spanish day8dlcchatmore_d7860d65:

    # player "You'd look cute with a tail, Grimmy."
    player "Te verías lindo con cola, Parquita."

# game/beyond the bet/day8dlc.rpy:1730
translate Spanish day8dlcchatmore_78c73be9:

    # GR "i... would?"
    GR "¿yo... me vería?"

# game/beyond the bet/day8dlc.rpy:1733
translate Spanish day8dlcchatmore_b5c02a9b:

    # player "Yeah."
    player "Sí."

# game/beyond the bet/day8dlc.rpy:1735
translate Spanish day8dlcchatmore_de59ad52:

    # player "100 percent."
    player "Al cien por ciento."

# game/beyond the bet/day8dlc.rpy:1738
translate Spanish day8dlcchatmore_676141bb:

    # player "Super cute."
    player "Súper lindo."

# game/beyond the bet/day8dlc.rpy:1741
translate Spanish day8dlcchatmore_da0f4f70:

    # player "If you were an animal, I bet you'd be..."
    player "Si fueras un animal, apuesto a que serías..."

# game/beyond the bet/day8dlc.rpy:1744
translate Spanish day8dlcchatmore_fb521b33:

    # player "A fluffy white cat."
    player "Un gato blanco esponjoso."

# game/beyond the bet/day8dlc.rpy:1747
translate Spanish day8dlcchatmore_45ffa26c:

    # player "Something regal looking with a huge, sweeping tail."
    player "Algo de aspecto elegante con una cola enorme y majestuosa."

# game/beyond the bet/day8dlc.rpy:1749
translate Spanish day8dlcchatmore_67434f2f:

    # player "An axolotl! A white one!"
    player "¡Un ajolote! ¡Uno blanco!"

# game/beyond the bet/day8dlc.rpy:1752
translate Spanish day8dlcchatmore_979dd090:

    # player "You'd be matching with Azrael!"
    player "¡Combinarías con Azrael!"

# game/beyond the bet/day8dlc.rpy:1754
translate Spanish day8dlcchatmore_21f131a2:

    # player "A little dog."
    player "Un perrito."

# game/beyond the bet/day8dlc.rpy:1757
translate Spanish day8dlcchatmore_2cc63a67:

    # player "One with a big attitude, obviously."
    player "Uno con mucho carácter, obviamente."

# game/beyond the bet/day8dlc.rpy:1758
translate Spanish day8dlcchatmore_b29d458c:

    # GR "i still don't think a tail would suit me."
    GR "sigo sin creer que una cola me quedaría bien."

# game/beyond the bet/day8dlc.rpy:1761
translate Spanish day8dlcchatmore_008263be:

    # player "You could be like, a little devil."
    player "Podrías ser, como, un pequeño demonio."

# game/beyond the bet/day8dlc.rpy:1764
translate Spanish day8dlcchatmore_66a63cbf:

    # player "Tiny horns and a tail would suit you too."
    player "Unos cuernitos y una cola también te quedarían bien."

# game/beyond the bet/day8dlc.rpy:1765
translate Spanish day8dlcchatmore_8f5079b9:

    # GR "me?"
    GR "¿a mí?"

# game/beyond the bet/day8dlc.rpy:1766
translate Spanish day8dlcchatmore_718ed4ad:

    # GR "they would suit you far greater."
    GR "a ti te quedarían mucho mejor."

# game/beyond the bet/day8dlc.rpy:1769
translate Spanish day8dlcchatmore_885500ed:

    # player "How so?"
    player "¿Cómo así?"

# game/beyond the bet/day8dlc.rpy:1770
translate Spanish day8dlcchatmore_6145ca26:

    # GR "from the moment we met, you have been like a little devil."
    GR "desde el momento en que nos conocimos, has sido como [arti_2] pequeñ[letra] demonio."

# game/beyond the bet/day8dlc.rpy:1771
translate Spanish day8dlcchatmore_d3a9e071:

    # GR "a trickster."
    GR "una persona embaucadora."

# game/beyond the bet/day8dlc.rpy:1774
translate Spanish day8dlcchatmore_2b65a7d0:

    # player "I've been nice from the start!"
    player "¡Yo he sido amable desde el principio!"

# game/beyond the bet/day8dlc.rpy:1776
translate Spanish day8dlcchatmore_75c622f7:

    # player "Okay, that's fair."
    player "Okey, tienes razón."

# game/beyond the bet/day8dlc.rpy:1777
translate Spanish day8dlcchatmore_15d89be6:

    # GR "you have been my little terror."
    GR "has sido mi pequeño terror."

# game/beyond the bet/day8dlc.rpy:1778
translate Spanish day8dlcchatmore_5c850d03:

    # GR "fortunately for you, i would have you no other way."
    GR "por suerte para ti, no te cambiaría por nada del mundo."

# game/beyond the bet/day8dlc.rpy:1783
translate Spanish day8dlcchatmore_3ab89977:

    # player "Me B)"
    player "A mí B)"

# game/beyond the bet/day8dlc.rpy:1786
translate Spanish day8dlcchatmore_7607f021:

    # player "You can stick whatever you want in me."
    player "Puedes meterme lo que quieras."

# game/beyond the bet/day8dlc.rpy:1787
translate Spanish day8dlcchatmore_9dc17148:

    # GR "are we still talking about pin the tail on the imp?"
    GR "¿seguimos hablando de ponerle la cola al diablito?"

# game/beyond the bet/day8dlc.rpy:1790
translate Spanish day8dlcchatmore_ad89c912:

    # player "I meant a different kind of tail."
    player "Me refería a otro tipo de cola."

# game/beyond the bet/day8dlc.rpy:1793
translate Spanish day8dlcchatmore_94eabfd3:

    # player "And I'm the imp."
    player "Y el diablito soy yo."

# game/beyond the bet/day8dlc.rpy:1794
translate Spanish day8dlcchatmore_d1e996fa:

    # GR "and what makes you think you'd be able to handle what i could give you?"
    GR "¿y qué te hace pensar que podrías soportar lo que yo podría darte?"

# game/beyond the bet/day8dlc.rpy:1797
translate Spanish day8dlcchatmore_3789a9cd:

    # player "I'm pretty good at taking what's given to me, Caspy-waspy."
    player "Se me da muy bien aceptar lo que me dan, Caspy-waspy."

# game/beyond the bet/day8dlc.rpy:1800
translate Spanish day8dlcchatmore_0651a3cc:

    # player "Try me ;)"
    player "Ponme a prueba ;)"

# game/beyond the bet/day8dlc.rpy:1801
translate Spanish day8dlcchatmore_bae508e6:

    # GR "you are tempting fate, you know that?"
    GR "estás tentando al destino, ¿lo sabías?"

# game/beyond the bet/day8dlc.rpy:1804
translate Spanish day8dlcchatmore_5b1faf87:

    # player "I don't mind."
    player "No me importa."

# game/beyond the bet/day8dlc.rpy:1806
translate Spanish day8dlcchatmore_b5621b2d:

    # player "Oh, I do hope so."
    player "Oh, eso espero."

# game/beyond the bet/day8dlc.rpy:1810
translate Spanish day8dlcchatmore_9fc73780:

    # player "You, when I'm done with you."
    player "A ti, cuando termine contigo."

# game/beyond the bet/day8dlc.rpy:1811
translate Spanish day8dlcchatmore_b2766aa4:

    # GR "???"
    GR "???"

# game/beyond the bet/day8dlc.rpy:1812
translate Spanish day8dlcchatmore_96af1cb0:

    # GR "you want to pin a tail on me?"
    GR "¿quieres ponerme una cola?"

# game/beyond the bet/day8dlc.rpy:1815
translate Spanish day8dlcchatmore_8e4f7135:

    # player "More like pin you down to the bed."
    player "Más bien inmovilizarte en la cama."

# game/beyond the bet/day8dlc.rpy:1816
translate Spanish day8dlcchatmore_30c12fb1:

    # GR "and then?"
    GR "¿y luego?"

# game/beyond the bet/day8dlc.rpy:1819
translate Spanish day8dlcchatmore_8921aacd:

    # player "Well, what would you like me to do?"
    player "Bueno, ¿qué te gustaría que hiciera?"

# game/beyond the bet/day8dlc.rpy:1820
translate Spanish day8dlcchatmore_7772a27d:

    # GR "..."
    GR "..."

# game/beyond the bet/day8dlc.rpy:1821
translate Spanish day8dlcchatmore_2c35785c:

    # GR "what would you desire?"
    GR "¿qué desearías?"

# game/beyond the bet/day8dlc.rpy:1824
translate Spanish day8dlcchatmore_70be3593:

    # player "You shouldn't answer a question with a question!"
    player "¡No deberías responder una pregunta con otra pregunta!"

# game/beyond the bet/day8dlc.rpy:1825
translate Spanish day8dlcchatmore_3a219a0a:

    # GR "why not?"
    GR "¿por qué no?"

# game/beyond the bet/day8dlc.rpy:1828
translate Spanish day8dlcchatmore_ac3b3355:

    # player "Fine."
    player "Está bien."

# game/beyond the bet/day8dlc.rpy:1831
translate Spanish day8dlcchatmore_21d0a30d:

    # player "I want to touch your hair, first."
    player "Quiero tocarte el cabello, primero."

# game/beyond the bet/day8dlc.rpy:1834
translate Spanish day8dlcchatmore_731e5396:

    # player "Run my fingers all the way down to the ends..."
    player "Deslizar mis dedos hasta las puntas..."

# game/beyond the bet/day8dlc.rpy:1835
translate Spanish day8dlcchatmore_b1273988:

    # GR "and... and then?"
    GR "¿y... y luego?"

# game/beyond the bet/day8dlc.rpy:1838
translate Spanish day8dlcchatmore_357c6705:

    # player "And then..."
    player "Y luego..."

# game/beyond the bet/day8dlc.rpy:1841
translate Spanish day8dlcchatmore_2c8337a5:

    # player "You'll have to come over and see :)"
    player "Tendrás que venir a verlo por ti mismo :)"

# game/beyond the bet/day8dlc.rpy:1844
translate Spanish day8dlcchatmore_765f7cdf:

    # player "Can't spoil all the fun, can I?"
    player "No puedo arruinar toda la diversión, ¿o sí?"

# game/beyond the bet/day8dlc.rpy:1848
translate Spanish dlc8naughty_82d04796:

    # GR "you are frustrating, mortal."
    GR "eres frustrante, mortal."

# game/beyond the bet/day8dlc.rpy:1849
translate Spanish dlc8naughty_efc98cb2:

    # GR "and i believe we are barely talking about pin the tail on the imp any longer."
    GR "y creo que apenas seguimos hablando de ponerle la cola al diablito."

# game/beyond the bet/day8dlc.rpy:1899
translate Spanish call1_day8_edfb442d:

    # GRC "I grow sick of typing, and I longed to see your face."
    GRC "Me canso de escribir, y anhelaba ver tu rostro."

# game/beyond the bet/day8dlc.rpy:1919
translate Spanish call1_day8_6400ac26:

    # GRC "I am always honest."
    GRC "Siempre soy sincero."

# game/beyond the bet/day8dlc.rpy:1930
translate Spanish call1_day8_64940766:

    # GRC "You know me so well, Sunshine."
    GRC "Me conoces tan bien, Solecito."

# game/beyond the bet/day8dlc.rpy:1940
translate Spanish call1_day8_c4058962:

    # GRC "Strangely, I feel the same way."
    GRC "Curiosamente, siento lo mismo."

# game/beyond the bet/day8dlc.rpy:1944
translate Spanish call1_day8_e11e77a4:

    # GRC "Perhaps an aftereffect of our souls being linked."
    GRC "Quizás sea un efecto secundario de que nuestras almas estén unidas."

# game/beyond the bet/day8dlc.rpy:1952
translate Spanish call1_day8_a4044b29:

    # GRC "Fireworks?"
    GRC "¿Fuegos artificiales?"

# game/beyond the bet/day8dlc.rpy:1953
translate Spanish call1_day8_b70cd858:

    # GRC "I cannot say I have."
    GRC "No puedo decir que los haya visto."

# game/beyond the bet/day8dlc.rpy:1955
translate Spanish call1_day8_dc3ae94d:

    # GRC "They're usually used in celebrations. Not a lot of overlap with my line of work."
    GRC "Suelen usarse en celebraciones. No tienen mucho que ver con mi trabajo."

# game/beyond the bet/day8dlc.rpy:1956
translate Spanish call1_day8_28e3c646:

    # GRC "Why?"
    GRC "¿Por qué?"

# game/beyond the bet/day8dlc.rpy:1964
translate Spanish call1_day8_64f6f650:

    # GRC "Huh..."
    GRC "Huh..."

# game/beyond the bet/day8dlc.rpy:1966
translate Spanish call1_day8_dafb2170:

    # GRC "Then I would like to see these fireworks, sometime."
    GRC "Entonces me gustaría ver esos fuegos artificiales algún día."

# game/beyond the bet/day8dlc.rpy:1970
translate Spanish call1_day8_0e5bbd24:

    # GRC "...Perhaps."
    GRC "...Quizás."

# game/beyond the bet/day8dlc.rpy:1986
translate Spanish call1_day8_90e15539:

    # GRC "I believe even if I wanted to stop you, I could not."
    GRC "Creo que, aunque quisiera detenerte, no podría."

# game/beyond the bet/day8dlc.rpy:1999
translate Spanish call1_day8_cc4ed920:

    # GRC "You know more than enough. Too much, some would say."
    GRC "Sabes más que suficiente. Demasiado, dirían algunos."

# game/beyond the bet/day8dlc.rpy:2009
translate Spanish call1_day8_168538c2:

    # GRC "Correct. It is a vast city, bigger than many of your countries."
    GRC "Correcto. Es una ciudad vasta, más grande que muchos de sus países."

# game/beyond the bet/day8dlc.rpy:2014
translate Spanish call1_day8_646acf03:

    # GRC "Most of the time, yes."
    GRC "La mayor parte del tiempo, sí."

# game/beyond the bet/day8dlc.rpy:2019
translate Spanish call1_day8_74e09bd9:

    # GRC "We cannot die through aging, and most of the time cannot be injured."
    GRC "No podemos morir por envejecimiento, y la mayor parte del tiempo no podemos resultar heridos."

# game/beyond the bet/day8dlc.rpy:2021
translate Spanish call1_day8_7044c3e2:

    # GRC "But the soulsickness can take us. It takes many."
    GRC "Pero la enfermedad del alma puede llevarnos. Se lleva a muchos."

# game/beyond the bet/day8dlc.rpy:2032
translate Spanish call1_day8_07283614:

    # GRC "Correct."
    GRC "Correcto."

# game/beyond the bet/day8dlc.rpy:2041
translate Spanish call1_day8_5bb35c42:

    # GRC "Having to travel all the way to the mortal plane for food would be tedious."
    GRC "Tener que viajar hasta el plano mortal por comida sería tedioso."

# game/beyond the bet/day8dlc.rpy:2048
translate Spanish call1_day8_32aa2fca:

    # GRC "We do, yes."
    GRC "Sí, así es."

# game/beyond the bet/day8dlc.rpy:2049
translate Spanish call1_day8_b8ad99c7:

    # GRC "Though I believe much of our food is still imported from your world, in bulk."
    GRC "Aunque creo que gran parte de nuestra comida sigue importándose de su mundo, al por mayor."

# game/beyond the bet/day8dlc.rpy:2054
translate Spanish call1_day8_5614dd03:

    # GRC "Er..."
    GRC "Eh..."

# game/beyond the bet/day8dlc.rpy:2056
translate Spanish call1_day8_bc7cc18f:

    # GRC "I do not think you should move here, Sunshine."
    GRC "No creo que debas mudarte aquí, Solecito."

# game/beyond the bet/day8dlc.rpy:2061
translate Spanish call1_day8_4733dc56:

    # GRC "It is not a place for mortals."
    GRC "No es un lugar para mortales."

# game/beyond the bet/day8dlc.rpy:2066
translate Spanish call1_day8_afb05019:

    # GRC "I think your picture of the Underworld is incorrect."
    GRC "Creo que tu imagen del Inframundo es incorrecta."

# game/beyond the bet/day8dlc.rpy:2067
translate Spanish call1_day8_0ac6f156:

    # GRC "It is not some firey hellscape."
    GRC "No es un infierno ardiente."

# game/beyond the bet/day8dlc.rpy:2078
translate Spanish call1_day8_37b7c159:

    # GRC "I believe many listen to your mortal music, but there are bands here, yes."
    GRC "Creo que muchos escuchan su música mortal, pero sí hay bandas aquí."

# game/beyond the bet/day8dlc.rpy:2083
translate Spanish call1_day8_77c4872a:

    # GRC "They are indeed, though I cannot say I know much about them. I was given them."
    GRC "Lo son, en efecto, aunque no puedo decir que sepa mucho sobre ellas. Simplemente me los dieron."

# game/beyond the bet/day8dlc.rpy:2086
translate Spanish call1_day8_089af514:

    # GRC "I imagine they are not too different to your own concerts."
    GRC "Imagino que no son muy diferentes a sus conciertos."

# game/beyond the bet/day8dlc.rpy:2091
translate Spanish call1_day8_b0d3ba12:

    # GRC "...I'm a busy man."
    GRC "...Soy un hombre ocupado."

# game/beyond the bet/day8dlc.rpy:2099
translate Spanish call1_day8_008afe10:

    # GRC "..."
    GRC "…"

# game/beyond the bet/day8dlc.rpy:2101
translate Spanish call1_day8_61de790b:

    # GRC "Reapers do not get time off. The concerts and such are for..."
    GRC "Las parcas no tienen tiempo libre. Los conciertos y demás son para..."

# game/beyond the bet/day8dlc.rpy:2103
translate Spanish call1_day8_beb0af70:

    # GRC "Higher ranking people."
    GRC "Personas de rango superior."

# game/beyond the bet/day8dlc.rpy:2105
translate Spanish call1_day8_f9da7521:

    # GRC "Even if I were to be invited, there is not enough hours in the day to waste on music."
    GRC "Aunque me invitaran, no hay horas suficientes en el día para desperdiciarlas en música."

# game/beyond the bet/day8dlc.rpy:2106
translate Spanish call1_day8_a7b3db2c:

    # GRC "And if there WERE more hours in a day, it would be required for me to work them."
    GRC "Y si HUBIERA más horas en el día, se me exigiría trabajarlas."

# game/beyond the bet/day8dlc.rpy:2114
translate Spanish call1_day8_f762f0d4:

    # GRC "Did... did you just hear what I said...?"
    GRC "¿Tú... tú acabas de oír lo que dije...?"

# game/beyond the bet/day8dlc.rpy:2115
translate Spanish call1_day8_2124c4f4:

    # GRC "I DON'T have time for-"
    GRC "NO tengo tiempo para-"

# game/beyond the bet/day8dlc.rpy:2123
translate Spanish call1_day8_dbc34f6f:

    # GRC "A... date?"
    GRC "¿Una... cita?"

# game/beyond the bet/day8dlc.rpy:2124
translate Spanish call1_day8_e4351498:

    # GRC "Do not be silly, mortal. Humans do not... come on dates to the Underworld..."
    GRC "No seas tont[letra], mortal. Los humanos no... van de citas al Inframundo..."

# game/beyond the bet/day8dlc.rpy:2126
translate Spanish call1_day8_c5066cfb:

    # GRC "Least of all with Grim Reapers."
    GRC "Y menos aún con Parcas."

# game/beyond the bet/day8dlc.rpy:2131
translate Spanish call1_day8_00315e53:

    # GRC "What? No you don't."
    GRC "¿Qué? No, no lo hacen."

# game/beyond the bet/day8dlc.rpy:2136
translate Spanish call1_day8_44404ffc:

    # GRC "You don't!"
    GRC "¡No lo hacen!"

# game/beyond the bet/day8dlc.rpy:2138
translate Spanish call1_day8_91330efa:

    # GRC "Ugh..."
    GRC "Ugh..."

# game/beyond the bet/day8dlc.rpy:2139
translate Spanish call1_day8_aec3fac5:

    # GRC "Besides, even if we were to go together... you would be sorely disappointed."
    GRC "Además, aunque fuéramos juntos... te decepcionarías mucho."

# game/beyond the bet/day8dlc.rpy:2141
translate Spanish call1_day8_34cb0441:

    # GRC "The Underworld is not so different to your own world."
    GRC "El Inframundo no es tan diferente de tu propio mundo."

# game/beyond the bet/day8dlc.rpy:2146
translate Spanish call1_day8_15a43d79:

    # GRC "Hmmm."
    GRC "Mmm."

# game/beyond the bet/day8dlc.rpy:2147
translate Spanish call1_day8_06e0c243:

    # GRC "I've never particularly thought on the matter."
    GRC "Nunca he pensado en ello en particular."

# game/beyond the bet/day8dlc.rpy:2148
translate Spanish call1_day8_b690657b:

    # GRC "Whatever sounds good, I suppose. I don't listen to much music."
    GRC "Lo que suene bien, supongo. No escucho mucha música."

# game/beyond the bet/day8dlc.rpy:2152
translate Spanish call1_day8_cf18133e:

    # GRC "....Bro? Bestie?"
    GRC "....¿Bro? ¿Bestie?"

# game/beyond the bet/day8dlc.rpy:2154
translate Spanish call1_day8_beb99dd0:

    # GRC "You cannot be talking about me. I am neither your brother, nor your best friend."
    GRC "No puedes estar hablando de mí. No soy tu hermano ni tu mejor amigo."

# game/beyond the bet/day8dlc.rpy:2164
translate Spanish call1_day8_a8fdcda4:

    # GRC "I fear you're going to tell me."
    GRC "Temo que vas a decírmelo."

# game/beyond the bet/day8dlc.rpy:2179
translate Spanish call1_day8_4cf7c335:

    # GRC "Can I be truthful with you?"
    GRC "¿Puedo ser sincero contigo?"

# game/beyond the bet/day8dlc.rpy:2184
translate Spanish call1_day8_79a339aa:

    # GRC "Hah. A fair comment."
    GRC "Ja. Un comentario justo."

# game/beyond the bet/day8dlc.rpy:2186
translate Spanish call1_day8_f4546507:

    # GRC "When you're that excited about something, it makes me nervous."
    GRC "Cuando te emocionas tanto por algo, me pongo nervioso."

# game/beyond the bet/day8dlc.rpy:2187
translate Spanish call1_day8_d38349ba:

    # GRC "For a mortal, you are truly frightening."
    GRC "Para ser [arti_2] mortal, das verdadero miedo."

# game/beyond the bet/day8dlc.rpy:2195
translate Spanish call1_day8_66898153:

    # GRC "Many others have feared me, you know."
    GRC "Muchos otros me han temido, ¿sabes?"

# game/beyond the bet/day8dlc.rpy:2209
translate Spanish call1_day8_4fdb8d69:

    # GRC "What is an arcade?"
    GRC "¿Qué es un arcade?"

# game/beyond the bet/day8dlc.rpy:2217
translate Spanish call1_day8_21fc7dc3:

    # GRC "Ah. An amusement arcade."
    GRC "Ah. Un salón recreativo."

# game/beyond the bet/day8dlc.rpy:2218
translate Spanish call1_day8_a046d342:

    # GRC "It is likely they are around. Many things that exist in your world are reflected here."
    GRC "Es probable que existan. Muchas cosas de tu mundo se reflejan aquí."

# game/beyond the bet/day8dlc.rpy:2220
translate Spanish call1_day8_234319e2:

    # GRC "But I've never been to one."
    GRC "Pero nunca he estado en uno."

# game/beyond the bet/day8dlc.rpy:2227
translate Spanish call1_day8_a84133b4:

    # GRC "Uh... is it not a little pathetic to go to such a place alone?"
    GRC "Eh... ¿no es un poco patético ir solo a un lugar así?"

# game/beyond the bet/day8dlc.rpy:2235
translate Spanish call1_day8_145f8a58:

    # GRC "And what would we do at this mortal arcade?"
    GRC "¿Y qué haríamos en este arcade de mortales?"

# game/beyond the bet/day8dlc.rpy:2242
translate Spanish call1_day8_9c8c62d7:

    # GRC "Then why would you want to play it?"
    GRC "Entonces, ¿por qué quieres jugarlo?"

# game/beyond the bet/day8dlc.rpy:2246
translate Spanish call1_day8_a1830b8c:

    # GRC "Mortal, there is nothing I 'suck' at."
    GRC "Mortal, no hay nada que se me dé 'fatal'."

# game/beyond the bet/day8dlc.rpy:2265
translate Spanish call1_day8_a48e9e5a:

    # GRC "Perhaps I am naturally good at it, like most, if not all other things?"
    GRC "¿Quizás soy naturalmente bueno en eso, como en la mayoría, si no en todas las demás cosas?"

# game/beyond the bet/day8dlc.rpy:2273
translate Spanish call1_day8_ee70bbbf:

    # GRC "Doubtful."
    GRC "Lo dudo."

# game/beyond the bet/day8dlc.rpy:2290
translate Spanish call1_day8_005edcdd:

    # GRC "I do not think your soul has anything to do with it."
    GRC "No creo que tu alma tenga nada que ver con eso."

# game/beyond the bet/day8dlc.rpy:2295
translate Spanish call1_day8_d952dd18:

    # GRC "Souls are kind of my thing."
    GRC "Las almas son lo mío."

# game/beyond the bet/day8dlc.rpy:2300
translate Spanish call1_day8_549be88b:

    # GRC "Hah! That much is true."
    GRC "¡Ja! Eso es cierto."

# game/beyond the bet/day8dlc.rpy:2301
translate Spanish call1_day8_65f97917:

    # GRC "Fine. Say we went to this arcade of yours. What would we do?"
    GRC "Bien. Digamos que fuéramos a este arcade tuyo. ¿Qué haríamos?"

# game/beyond the bet/day8dlc.rpy:2306
translate Spanish call1_day8_7586a1c8:

    # GRC "I blame myself for asking a question you could answer sarcastically. That's on me."
    GRC "Me culpo por hacer una pregunta que podías responder con sarcasmo. Es culpa mía."

# game/beyond the bet/day8dlc.rpy:2308
translate Spanish call1_day8_11afc7fe:

    # GRC "I meant, what kind of games are there?"
    GRC "Me refería a qué tipo de juegos hay."

# game/beyond the bet/day8dlc.rpy:2319
translate Spanish call1_day8_eee413d0:

    # GRC "You bet, hmmm? Fine. I accept your challenge."
    GRC "Apuestas, ¿mmm? Bien. Acepto tu desafío."

# game/beyond the bet/day8dlc.rpy:2334
translate Spanish call1_day8_47b0af8a:

    # GRC "WHAT?"
    GRC "¡¿QUÉ?!"

# game/beyond the bet/day8dlc.rpy:2343
translate Spanish call1_day8_745b3fcd:

    # GRC "From who?!"
    GRC "¡¿De quién?!"

# game/beyond the bet/day8dlc.rpy:2344
translate Spanish call1_day8_c0be7684:

    # GRC "Who would spread such rubbish?!"
    GRC "¡¿Quién difundiría tales tonterías?!"

# game/beyond the bet/day8dlc.rpy:2350
translate Spanish call1_day8_b9e13549:

    # GRC "Of could you did."
    GRC "Por supuesto que lo hiciste."

# game/beyond the bet/day8dlc.rpy:2351
translate Spanish call1_day8_516b84cf:

    # GRC "YOU would spread such rubbish. It makes perfect sense."
    GRC "TÚ difundirías tales tonterías. Tiene todo el sentido."

# game/beyond the bet/day8dlc.rpy:2360
translate Spanish call1_day8_55c9a737:

    # GRC "You ask again!!! Your shame knows no bounds..."
    GRC "¡¡¡Vuelves a preguntar!!! Tu desvergüenza no tiene límites..."

# game/beyond the bet/day8dlc.rpy:2361
translate Spanish call1_day8_3d67db7b:

    # GRC "...I... I did not say no..."
    GRC "...Yo... no dije que no..."

# game/beyond the bet/day8dlc.rpy:2363
translate Spanish call1_day8_4c2a6e3b:

    # GRC "I just... do not see why it has to be an arcade..."
    GRC "Solo que... no veo por qué tiene que ser un arcade..."

# game/beyond the bet/day8dlc.rpy:2371
translate Spanish call1_day8_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day8dlc.rpy:2372
translate Spanish call1_day8_b3bd3767:

    # GRC "............."
    GRC "............."

# game/beyond the bet/day8dlc.rpy:2374
translate Spanish call1_day8_d196e863:

    # GRC "Right. The Underworld. Suddenly I want to share each and every secret about it with you."
    GRC "Claro. El Inframundo. De repente quiero compartir contigo todos y cada uno de sus secretos."

# game/beyond the bet/day8dlc.rpy:2389
translate Spanish call1_day8_45ccd536:

    # GRC "To be reduced to such falsehoods..."
    GRC "Verme reducido a tales falsedades..."

# game/beyond the bet/day8dlc.rpy:2397
translate Spanish call1_day8_7ba8a353:

    # GRC "...Sometimes."
    GRC "...A veces."

# game/beyond the bet/day8dlc.rpy:2402
translate Spanish call1_day8_c0b53282:

    # GRC "On... on occassion..."
    GRC "En... en ocasiones..."

# game/beyond the bet/day8dlc.rpy:2406
translate Spanish call1_day8_7b29dcff:

    # GRC "What about my good looks? My award-winning personality? How about the fact I'm a GRIM REAPER?"
    GRC "¿Y mi buen aspecto? ¿Mi personalidad galardonada? ¿Y el hecho de que soy una PARCA?"

# game/beyond the bet/day8dlc.rpy:2418
translate Spanish call1_day8_008afe10_2:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day8dlc.rpy:2419
translate Spanish call1_day8_c1f5f89f:

    # GRC "Gods, you are the only person who can get to me so."
    GRC "Dioses, eres la única persona que puede afectarme así."

# game/beyond the bet/day8dlc.rpy:2420
translate Spanish call1_day8_233363fa:

    # GRC "How infuriating..."
    GRC "Qué exasperante..."

# game/beyond the bet/day8dlc.rpy:2428
translate Spanish call1_day8_73195a5d:

    # GRC "?????????????????"
    GRC "?????????????????"

# game/beyond the bet/day8dlc.rpy:2436
translate Spanish call1_day8_91330efa_1:

    # GRC "Ugh..."
    GRC "Ugh..."

# game/beyond the bet/day8dlc.rpy:2449
translate Spanish musicinside_6a21dccb:

    # GRC "Haaaa..."
    GRC "Haaaa..."

# game/beyond the bet/day8dlc.rpy:2450
translate Spanish musicinside_d887677d:

    # GRC "I have given up trying to be frightening to you."
    GRC "He renunciado a intentar ser aterrador para ti."

# game/beyond the bet/day8dlc.rpy:2452
translate Spanish musicinside_84c60681:

    # GRC "At this point, I just have to accept whatever you say."
    GRC "A estas alturas, solo tengo que aceptar todo lo que digas."

# game/beyond the bet/day8dlc.rpy:2466
translate Spanish underworld_b9dec347:

    # GRC "It is... warm, I suppose."
    GRC "Es... cálido, supongo."

# game/beyond the bet/day8dlc.rpy:2468
translate Spanish underworld_be91b247:

    # GRC "In a literal sense. There is no fire or lava, but the climate leans towards warm."
    GRC "En sentido literal. No hay fuego ni lava, pero el clima tiende a ser cálido."

# game/beyond the bet/day8dlc.rpy:2481
translate Spanish underworld_815ff8a2:

    # GRC "You have many nonsensical thoughts in that head of yours."
    GRC "Tienes muchos pensamientos sin sentido en esa cabeza tuya."

# game/beyond the bet/day8dlc.rpy:2486
translate Spanish underworld_f255c2da:

    # GRC "There is no sun, so our days are filled with near pitch darkness."
    GRC "No hay sol, así que nuestros días están llenos de una oscuridad casi total."

# game/beyond the bet/day8dlc.rpy:2495
translate Spanish underworld_16ee7c54:

    # GRC "But we do have a moon. No stars, though."
    GRC "Pero sí tenemos una luna. Estrellas, no."

# game/beyond the bet/day8dlc.rpy:2503
translate Spanish underworld_cae8a691:

    # GRC "I suppose so."
    GRC "Supongo que sí."

# game/beyond the bet/day8dlc.rpy:2504
translate Spanish underworld_5d1b8c9f:

    # GRC "Is that so strange?"
    GRC "¿Es tan extraño?"

# game/beyond the bet/day8dlc.rpy:2513
translate Spanish underworld_7ac9b70a:

    # GRC "I said it was warm in climate, but I would say the atmosphere leans towards cold."
    GRC "Dije que el clima era cálido, pero diría que el ambiente tiende a ser frío."

# game/beyond the bet/day8dlc.rpy:2514
translate Spanish underworld_63c06ff3:

    # GRC "The people who live here are many things, but most keep to themselves."
    GRC "Quienes viven aquí son muchas cosas, pero la mayoría se mantiene aparte."

# game/beyond the bet/day8dlc.rpy:2528
translate Spanish underworld_de074b90:

    # GRC "Maybe if the people who lived here were more likeable, then I would give them a chance."
    GRC "Quizás si quienes vivieran aquí fueran más agradables, les daría una oportunidad."

# game/beyond the bet/day8dlc.rpy:2530
translate Spanish underworld_fd3c41c4:

    # GRC "A big maybe. A very unlikely one."
    GRC "Un gran quizás. Uno muy improbable."

# game/beyond the bet/day8dlc.rpy:2535
translate Spanish underworld_8e1ed12f:

    # GRC "I would rather gouge out my eyes and then eat them."
    GRC "Prefiero sacarme los ojos y luego comérmelos."

# game/beyond the bet/day8dlc.rpy:2540
translate Spanish underworld_c69b2d38:

    # GRC "...I have one important person anyway. That's plenty for me."
    GRC "...De todos modos, tengo a una sola persona importante. Con eso me basta."

# game/beyond the bet/day8dlc.rpy:2552
translate Spanish underworld_c1fd5ab1:

    # GRC "Nothing."
    GRC "Nada."

# game/beyond the bet/day8dlc.rpy:2559
translate Spanish underworld_84d5eac4:

    # GRC "One is... terrible. And perfect. Mostly terrible."
    GRC "Uno es... terrible. Y perfecto. Sobre todo terrible."

# game/beyond the bet/day8dlc.rpy:2564
translate Spanish underworld_b9ca59ec:

    # GRC "I do not want a 'big birthday party'."
    GRC "No quiero una 'gran fiesta de cumpleaños'."

# game/beyond the bet/day8dlc.rpy:2568
translate Spanish underworld_082ed2b3:

    # GRC "Ugh. You just made me shiver."
    GRC "Ugh. Acabas de hacerme estremecer."

# game/beyond the bet/day8dlc.rpy:2573
translate Spanish underworld_dbc30b24:

    # GRC "In fear."
    GRC "De miedo."

# game/beyond the bet/day8dlc.rpy:2578
translate Spanish underworld_8aea422b:

    # GRC "A... party pooper? That sounds stupid."
    GRC "¿Un... aguafiestas? Eso suena estúpido."

# game/beyond the bet/day8dlc.rpy:2590
translate Spanish underworld_4ec879b3:

    # GRC "I don't know what that is but I'm scared."
    GRC "No sé qué es eso pero tengo miedo."

# game/beyond the bet/day8dlc.rpy:2597
translate Spanish underworld_008975f5:

    # GRC "Once again, no."
    GRC "Otra vez, no."

# game/beyond the bet/day8dlc.rpy:2598
translate Spanish underworld_6a3e5622:

    # GRC "Party games are made for children."
    GRC "Los juegos de fiesta están hechos para niños."

# game/beyond the bet/day8dlc.rpy:2600
translate Spanish underworld_406bff24:

    # GRC "Perhaps you are easily confused, as I am far from a child."
    GRC "Quizás te confundes con facilidad, ya que estoy lejos de ser un niño."

# game/beyond the bet/day8dlc.rpy:2601
translate Spanish underworld_aa01fb11:

    # GRC "I am-"
    GRC "Soy-"

# game/beyond the bet/day8dlc.rpy:2623
translate Spanish underworld_3a43e484:

    # GRC "What a stupid name for a game. Wolves would not tell humans the time."
    GRC "Qué nombre tan estúpido para un juego. Los lobos no le dirían la hora a los humanos."

# game/beyond the bet/day8dlc.rpy:2630
translate Spanish underworld_7cf6032c:

    # GRC "Yes, well, I do not."
    GRC "Sí, bueno, yo no."

# game/beyond the bet/day8dlc.rpy:2635
translate Spanish underworld_8af9bdb3:

    # GRC "No, please enlighten me. This should be entertaining."
    GRC "No, por favor, ilústrame. Esto debería ser entretenido."

# game/beyond the bet/day8dlc.rpy:2649
translate Spanish underworld_55267837:

    # GRC "How would that be therapeutic?"
    GRC "¿Cómo sería eso terapéutico?"

# game/beyond the bet/day8dlc.rpy:2654
translate Spanish underworld_13a36a76:

    # GRC "Well..."
    GRC "Bueno..."

# game/beyond the bet/day8dlc.rpy:2656
translate Spanish underworld_076fa80c:

    # GRC "I was always quite good at splitting a pinata in two, I'll give you that."
    GRC "Siempre fui bastante bueno partiendo una piñata en dos, eso te lo concedo."

# game/beyond the bet/day8dlc.rpy:2664
translate Spanish underworld_7ed7c79d:

    # GRC "Ah... wait a second, no..."
    GRC "Ah... espera un segundo, no..."

# game/beyond the bet/day8dlc.rpy:2665
translate Spanish underworld_131c6ad8:

    # GRC "...I have not."
    GRC "...No lo he hecho."

# game/beyond the bet/day8dlc.rpy:2667
translate Spanish underworld_a9f94965:

    # GRC "What... why...."
    GRC "Qué... por qué...."

# game/beyond the bet/day8dlc.rpy:2671
translate Spanish underworld_7c041891:

    # GRC "I... I'm certain I've never..."
    GRC "Yo... estoy seguro de que nunca he..."

# game/beyond the bet/day8dlc.rpy:2673
translate Spanish underworld_06631c35:

    # GRC "But for a moment there, a memory just... appeared."
    GRC "Pero por un momento, un recuerdo simplemente... apareció."

# game/beyond the bet/day8dlc.rpy:2674
translate Spanish underworld_48269559:

    # GRC "That is not a memory I recognise, and yet it lingers in my subconsious."
    GRC "Ese no es un recuerdo que reconozca, y sin embargo permanece en mi subconsciente."

# game/beyond the bet/day8dlc.rpy:2676
translate Spanish underworld_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day8dlc.rpy:2677
translate Spanish underworld_d5978bba:

    # GRC "Why do I remember something I have never experienced?"
    GRC "¿Por qué recuerdo algo que nunca he vivido?"

# game/beyond the bet/day8dlc.rpy:2686
translate Spanish underworld_dcbe5833:

    # GRC "But I... I've never had a birthday, nor celebrated someone else's! Of that, I am certain."
    GRC "¡Pero yo... nunca he tenido un cumpleaños, ni he celebrado el de otra persona! De eso estoy seguro."

# game/beyond the bet/day8dlc.rpy:2688
translate Spanish underworld_200a1d2f:

    # GRC "But.... I remember being good at it. Excellent, in fact."
    GRC "Pero.... recuerdo ser bueno en eso. Excelente, de hecho."

# game/beyond the bet/day8dlc.rpy:2690
translate Spanish underworld_677cb963:

    # GRC "My aim was always true. They would... praise me for it..."
    GRC "Mi puntería siempre fue certera. Me... elogiaban por ello..."

# game/beyond the bet/day8dlc.rpy:2698
translate Spanish underworld_719f7c57:

    # GRC "Exactly as you see me now, yes."
    GRC "Exactamente como me ves ahora, sí."

# game/beyond the bet/day8dlc.rpy:2702
translate Spanish underworld_cc974d9e:

    # GRC "I have lived many years and I have never changed."
    GRC "He vivido muchos años y nunca he cambiado."

# game/beyond the bet/day8dlc.rpy:2707
translate Spanish underworld_151f2aee:

    # GRC "There was no before that."
    GRC "No hubo un antes."

# game/beyond the bet/day8dlc.rpy:2709
translate Spanish underworld_41bc98bc:

    # GRC "I was created to be a reaper. I have always been... this."
    GRC "Fui creado para ser una parca. Siempre he sido... esto."

# game/beyond the bet/day8dlc.rpy:2734
translate Spanish underworld_c3d8a29f:

    # GRC "What are you getting at?"
    GRC "¿A dónde quieres llegar?"

# game/beyond the bet/day8dlc.rpy:2741
translate Spanish underworld_d5bcda3d:

    # GRC "That..."
    GRC "Eso..."

# game/beyond the bet/day8dlc.rpy:2743
translate Spanish underworld_14b85343:

    # GRC "That is a... large accusation to just throw around, Sunshine."
    GRC "Eso es una... acusación muy grande para soltarla así como así, Solecito."

# game/beyond the bet/day8dlc.rpy:2745
translate Spanish underworld_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day8dlc.rpy:2750
translate Spanish underworld_b76ccc87:

    # GRC "And yet.... it could be plausible..."
    GRC "Y sin embargo.... podría ser plausible..."

# game/beyond the bet/day8dlc.rpy:2752
translate Spanish underworld_dd364f89:

    # GRC "I have always wondered how we were given souls, being artificially created like we are..."
    GRC "Siempre me he preguntado cómo nos dieron almas, siendo creados artificialmente como somos..."

# game/beyond the bet/day8dlc.rpy:2754
translate Spanish underworld_62b28c75:

    # GRC "Gods..."
    GRC "Dioses..."

# game/beyond the bet/day8dlc.rpy:2761
translate Spanish underworld_d8bf50f2:

    # GRC "I'm just... running some things through my head, I suppose."
    GRC "Solo estoy... dándole vueltas a algunas cosas, supongo."

# game/beyond the bet/day8dlc.rpy:2762
translate Spanish underworld_2799df13:

    # GRC "And I cannot deny the probability being zero. It is unlikely, but more unlikely things have been true."
    GRC "Y no puedo negar que la probabilidad no sea cero. Es improbable, pero han sido ciertas cosas aún más improbables."

# game/beyond the bet/day8dlc.rpy:2764
translate Spanish underworld_7ecc04f2:

    # GRC "This organization has always been... secretive, selective about what information is shared."
    GRC "Esta organización siempre ha sido... reservada, selectiva sobre qué información se comparte."

# game/beyond the bet/day8dlc.rpy:2765
translate Spanish underworld_a03540b4:

    # GRC "Perhaps there is apt reason for their unwillingness to disclose information."
    GRC "Quizás haya una razón apropiada para su renuencia a revelar información."

# game/beyond the bet/day8dlc.rpy:2767
translate Spanish underworld_872805e1:

    # GRC "If they caught wind of this conversation, though..."
    GRC "Pero si se enteraran de esta conversación..."

# game/beyond the bet/day8dlc.rpy:2769
translate Spanish underworld_0fb4a1a8:

    # GRC "This is something of a taboo subject. Reapers follow strict protocols and don't ask questions."
    GRC "Este es un tema casi tabú. Las parcas siguen protocolos estrictos y no hacen preguntas."

# game/beyond the bet/day8dlc.rpy:2771
translate Spanish underworld_da12d074:

    # GRC "We do not question authority. We simply obey."
    GRC "No cuestionamos a la autoridad. Simplemente obedecemos."

# game/beyond the bet/day8dlc.rpy:2776
translate Spanish underworld_3506db29:

    # GRC "There could be dire consequences."
    GRC "Podría haber consecuencias terribles."

# game/beyond the bet/day8dlc.rpy:2778
translate Spanish underworld_ff9a710d:

    # GRC "They could question my loyalty to the organization, and that could... lead to my termination."
    GRC "Podrían cuestionar mi lealtad a la organización, y eso podría... llevar a mi terminación."

# game/beyond the bet/day8dlc.rpy:2780
translate Spanish underworld_fa6b5f48:

    # GRC "But there is also you to consider. Ugh, what a mess..."
    GRC "Pero también estás tú, a quien debo considerar. Ugh, qué desastre..."

# game/beyond the bet/day8dlc.rpy:2781
translate Spanish underworld_da0bf856:

    # GRC "I am breaking so many rules here, Sunshine."
    GRC "Estoy rompiendo tantas reglas aquí, Solecito."

# game/beyond the bet/day8dlc.rpy:2783
translate Spanish underworld_63105df2:

    # GRC "I don't like the thought of anything happening to you."
    GRC "No me gusta la idea de que te pase algo."

# game/beyond the bet/day8dlc.rpy:2784
translate Spanish underworld_cb387363:

    # GRC "Bad things happen to me? Fine. To you? I could not accept it."
    GRC "¿Me pasan cosas malas a mí? Bien. ¿A ti? No podría aceptarlo."

# game/beyond the bet/day8dlc.rpy:2791
translate Spanish underworld_8bc505b2:

    # GRC "No, no... I'm thankful, really."
    GRC "No, no... estoy agradecido, de verdad."

# game/beyond the bet/day8dlc.rpy:2793
translate Spanish underworld_93b8c130:

    # GRC "For you."
    GRC "Por ti."

# game/beyond the bet/day8dlc.rpy:2794
translate Spanish underworld_5220a86c:

    # GRC "For this."
    GRC "Por esto."

# game/beyond the bet/day8dlc.rpy:2796
translate Spanish underworld_b66f5828:

    # GRC "I have always been my job."
    GRC "Siempre he sido mi trabajo."

# game/beyond the bet/day8dlc.rpy:2798
translate Spanish underworld_be9a99bb:

    # GRC "But with you, I am Casper."
    GRC "Pero contigo, soy Casper."

# game/beyond the bet/day8dlc.rpy:2799
translate Spanish underworld_d8da7868:

    # GRC "I have never felt such... happiness, I suppose. What a foreign word."
    GRC "Nunca había sentido tal... felicidad, supongo. Qué palabra tan extranjera."

# game/beyond the bet/day8dlc.rpy:2804
translate Spanish underworld_1462bd0c:

    # GRC "I feel I have many decisions to make."
    GRC "Siento que tengo muchas decisiones que tomar."

# game/beyond the bet/day8dlc.rpy:2805
translate Spanish underworld_c71169d8:

    # GRC "And you are beyond distracting. In the best ways, I promise."
    GRC "Y me distraes más allá de lo imaginable. En el mejor de los sentidos, lo prometo."

# game/beyond the bet/day8dlc.rpy:2807
translate Spanish underworld_3ab872d7:

    # GRC "I'll talk to you soon, okay?"
    GRC "Hablamos pronto, ¿okey?"

# game/beyond the bet/day8dlc.rpy:2811
translate Spanish underworld_6b9b2252:

    # GRC "I won't be gone long. You know me."
    GRC "No me ausentaré mucho. Ya me conoces."

# game/beyond the bet/day8dlc.rpy:2813
translate Spanish underworld_d946557f:

    # GRC "Try as I might, I cannot bring myself to stay away."
    GRC "Por más que lo intente, no logro mantenerme alejado."

# game/beyond the bet/day8dlc.rpy:2815
translate Spanish underworld_0ecbb916:

    # GRC "You are an addicting ray of light."
    GRC "Eres un rayo de luz adictivo."

# game/beyond the bet/day8dlc.rpy:2822
translate Spanish underworld_3f4ace82:

    # GRC "I... I'm..."
    GRC "Yo... estoy..."

# game/beyond the bet/day8dlc.rpy:2824
translate Spanish underworld_90c72959:

    # GRC "I'm okay. Please, don't worry about me."
    GRC "Estoy bien. Por favor, no te preocupes por mí."

# game/beyond the bet/day8dlc.rpy:2826
translate Spanish underworld_85c275d9:

    # GRC "Hey. Don't give me that look. Stop pouting."
    GRC "Oye. No me pongas esa cara. Deja de hacer pucheros."

# game/beyond the bet/day8dlc.rpy:2827
translate Spanish underworld_38b45649:

    # GRC "Just... wait for me, alright?"
    GRC "Solo... espérame, ¿de acuerdo?"

# game/beyond the bet/day8dlc.rpy:2828
translate Spanish underworld_bed74406:

    # GRC "I'll see you soon, Sunshine. "
    GRC "Nos vemos pronto, Solecito."

# game/beyond the bet/day8dlc.rpy:2854
translate Spanish chat2_day8dlc_e46f1b0e:

    # "As the call comes to an end, you see your reflection on the black screen."
    "Cuando la llamada termina, ves tu reflejo en la pantalla negra."

# game/beyond the bet/day8dlc.rpy:2855
translate Spanish chat2_day8dlc_af19c051:

    # "That's always the worst part."
    "Siempre es la peor parte."

# game/beyond the bet/day8dlc.rpy:2856
translate Spanish chat2_day8dlc_f436f1a6:

    # "At the end, you're back to just being by yourself."
    "Al final, vuelves a estar a sol[letra]."

# game/beyond the bet/day8dlc.rpy:2857
translate Spanish chat2_day8dlc_b8a80451:

    # "You look out the window - already the sun is beginning to set."
    "Miras por la ventana: el sol ya empieza a ponerse."

# game/beyond the bet/day8dlc.rpy:2858
translate Spanish chat2_day8dlc_002915d1:

    # "It's funny how fast time seems to pass when you talk to Casper."
    "Es curioso lo rápido que parece pasar el tiempo cuando hablas con Casper."

# game/beyond the bet/day8dlc.rpy:2859
translate Spanish chat2_day8dlc_07044e1e:

    # "For a moment, you imagine drifting through time forever to be with him."
    "Por un momento, imaginas flotar por el tiempo para siempre para estar con él."

# game/beyond the bet/day8dlc.rpy:2860
translate Spanish chat2_day8dlc_88da2a90:

    # "A silly thought, really."
    "Un pensamiento tonto, la verdad."

# game/beyond the bet/day8dlc.rpy:2861
translate Spanish chat2_day8dlc_61c51dd5:

    # "The soft glow of moonlight slowly begins to drift across your desk as you watch time bleed across the sky."
    "El suave resplandor de la luz de la luna comienza a deslizarse lentamente por tu escritorio mientras ves cómo el tiempo se derrama por el cielo."

# game/beyond the bet/day8dlc.rpy:2862
translate Spanish chat2_day8dlc_a84c319a:

    # "There's never enough time."
    "Nunca hay suficiente tiempo."

# game/beyond the bet/day8dlc.rpy:2863
translate Spanish chat2_day8dlc_ed30bfe1:

    # "You suppose that's why it's important to make the most of the time you have."
    "Supones que por eso es importante aprovechar al máximo el tiempo que tienes."

# game/beyond the bet/day8dlc.rpy:2865
translate Spanish chat2_day8dlc_5bbec9ce:

    # "A knock on your apartment door pulls you from your thoughts."
    "Un golpe en la puerta de tu apartamento te saca de tus pensamientos."

# game/beyond the bet/day8dlc.rpy:2881
translate Spanish chat2_day8dlc_cc8c15ce:

    # GRC "I told you, didn't I? You'd see me soon."
    GRC "Te lo dije, ¿no? Me verías pronto."

# game/beyond the bet/day8dlc.rpy:2895
translate Spanish chat2_day8dlc_cce1ba5c:

    # GRC "Are you coming or not?"
    GRC "¿Vienes o no?"

# game/beyond the bet/day8dlc.rpy:2903
translate Spanish chat2_day8dlc_193386c8:

    # GRC "Wha..."
    GRC "Qué..."

# game/beyond the bet/day8dlc.rpy:2905
translate Spanish chat2_day8dlc_db177ed5:

    # GRC "I did not mean it like that! Gods, I need to watch what I say around you, don't I?"
    GRC "¡No lo dije en ese sentido! Dioses, tengo que cuidar lo que digo a tu alrededor, ¿verdad?"

# game/beyond the bet/day8dlc.rpy:2907
translate Spanish chat2_day8dlc_21d9751f:

    # GRC "Are you... will you... ugh! Just come with me already!"
    GRC "¿Tú... vas a...? ¡Ugh! ¡Solo ven conmigo de una vez!"

# game/beyond the bet/day8dlc.rpy:2909
translate Spanish chat2_day8dlc_28dd2188:

    # GRC "You wanted to go to this festival, correct?" id chat2_day8dlc_28dd2188
    GRC "Querías ir a este festival, ¿correcto?" id chat2_day8dlc_28dd2188

# game/beyond the bet/day8dlc.rpy:2911
translate Spanish chat2_day8dlc_ac629d94:

    # GRC "I'm here. To go with you. To the festival."
    GRC "Estoy aquí. Para ir contigo. Al festival."

# game/beyond the bet/day8dlc.rpy:2916
translate Spanish chat2_day8dlc_cd9f25b7:

    # GRC "...I... yes. You could call it that."
    GRC "...Yo... sí. Podrías llamarlo así."

# game/beyond the bet/day8dlc.rpy:2918
translate Spanish chat2_day8dlc_5437923f:

    # GRC "This... festival. You and me. A... date."
    GRC "Este... festival. Tú y yo. Una... cita."

# game/beyond the bet/day8dlc.rpy:2919
translate Spanish chat2_day8dlc_d352f08b:

    # GRC "If you'd like. If you don't want to, then I... I might not care."
    GRC "Si quieres. Si no quieres, entonces yo... podría no importarme."

# game/beyond the bet/day8dlc.rpy:2926
translate Spanish chat2_day8dlc_bf0cfef8:

    # GRC "There is no need. You always look effortlessly perfect."
    GRC "No hace falta. Siempre te ves impecable sin esfuerzo."

# game/beyond the bet/day8dlc.rpy:2931
translate Spanish chat2_day8dlc_18bd9087:

    # GRC "Mortal, perhaps you are unaware, but you are utterly bewitching."
    GRC "Mortal, quizás no lo sepas, pero eres absolutamente hechizante."

# game/beyond the bet/day8dlc.rpy:2935
translate Spanish chat2_day8dlc_a4952818:

    # GRC "A shame I didn't bring flowers this time."
    GRC "Qué lástima no haber traído flores esta vez."

# game/beyond the bet/day8dlc.rpy:2945
translate Spanish chat2_day8dlc_60c533ff:

    # GRC "So... that's a yes?"
    GRC "Entonces... ¿eso es un sí?"

# game/beyond the bet/day8dlc.rpy:2949
translate Spanish chat2_day8dlc_77bf1baf:

    # GRC "No, of course not. But it is a risk I am willing to take."
    GRC "No, claro que no. Pero es un riesgo que estoy dispuesto a correr."

# game/beyond the bet/day8dlc.rpy:2951
translate Spanish chat2_day8dlc_9bda19a8:

    # GRC "I want to go with you. I want to... experience this human fleetingness with you."
    GRC "Quiero ir contigo. Quiero... experimentar esta fugacidad humana contigo."

# game/beyond the bet/day8dlc.rpy:2959
translate Spanish chat2_day8dlc_047c8004:

    # "{i}The two of you exit your apartment and Casper leads you to the staircase.{/i}"
    "{i}Los dos salen de tu apartamento y Casper te guía hacia las escaleras.{/i}"

# game/beyond the bet/day8dlc.rpy:2969
translate Spanish chat2_day8dlc_bab48214:

    # GRC "Elevator? No, it's out of order still. You know, after I tried to kill you."
    GRC "¿Ascensor? No, sigue fuera de servicio. Ya sabes, después de que intenté matarte."

# game/beyond the bet/day8dlc.rpy:2976
translate Spanish chat2_day8dlc_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day8dlc.rpy:2977
translate Spanish chat2_day8dlc_7e7ea33d:

    # GRC "Besides, I do not trust the things."
    GRC "Además, no confío en esas cosas."

# game/beyond the bet/day8dlc.rpy:2979
translate Spanish chat2_day8dlc_83c76607:

    # GRC "They are evil contraptions."
    GRC "Son artefactos malignos."

# game/beyond the bet/day8dlc.rpy:2988
translate Spanish chat2_day8dlc_21d197c3:

    # GRC "How truly gracious of you."
    GRC "Qué generoso de tu parte."

# game/beyond the bet/day8dlc.rpy:2991
translate Spanish chat2_day8dlc_d7ebd4fa:

    # GRC "Wha - wait!"
    GRC "Qué... ¡espera!"

# game/beyond the bet/day8dlc.rpy:2993
translate Spanish chat2_day8dlc_5f1c5fb2:

    # GRC "You are going to slip and fall, you idiot!"
    GRC "¡Te vas a resbalar y a caer, idiota!"

# game/beyond the bet/day8dlc.rpy:2994
translate Spanish chat2_day8dlc_af4a450b:

    # "{i}You start running anyway.{/i}"
    "{i}Echas a correr de todos modos.{/i}"

# game/beyond the bet/day8dlc.rpy:2995
translate Spanish chat2_day8dlc_20f738cc:

    # "{i}You hear him curse behind you.{/i}"
    "{i}Lo oyes maldecir a tus espaldas.{/i}"

# game/beyond the bet/day8dlc.rpy:2996
translate Spanish chat2_day8dlc_3b1603fb:

    # GRC "I'm not chasing after you!"
    GRC "¡No te estoy persiguiendo!"

# game/beyond the bet/day8dlc.rpy:3001
translate Spanish chat2_day8dlc_6e762138:

    # GRC "What...!"
    GRC "¡Qué...!"

# game/beyond the bet/day8dlc.rpy:3003
translate Spanish chat2_day8dlc_9442060a:

    # GRC "I'm... I'm not a rotten egg!"
    GRC "¡Yo... no soy un huevo podrido!"

# game/beyond the bet/day8dlc.rpy:3005
translate Spanish chat2_day8dlc_bacab946:

    # "{i}You hear him running too and giggle to yourself.{/i}"
    "{i}Lo oyes correr también y te ríes para tus adentros.{/i}"

# game/beyond the bet/day8dlc.rpy:3006
translate Spanish chat2_day8dlc_72567515:

    # "{i}With a head start, you (of course) win.{/i}"
    "{i}Con ventaja de salida, (por supuesto) ganas.{/i}"

# game/beyond the bet/day8dlc.rpy:3012
translate Spanish chat2_day8dlc_0e22d375:

    # "{i}The two of you start the short walk towards the festival, catching some curious glances on the way.{/i}"
    "{i}Los dos emprenden la corta caminata hacia el festival, atrayendo algunas miradas curiosas por el camino.{/i}"

# game/beyond the bet/day8dlc.rpy:3013
translate Spanish chat2_day8dlc_3a570948:

    # "{i}You aren't too surprised - Casper is somewhat unique in appearance. And also hot. You can't forget that.{/i}"
    "{i}No te sorprende demasiado: Casper tiene una apariencia bastante peculiar. Y además es guapísimo. No puedes olvidar eso.{/i}"

# game/beyond the bet/day8dlc.rpy:3014
translate Spanish chat2_day8dlc_9931fce9:

    # "{i}You don't miss the way he takes a step closer to walk beside you.{/i}"
    "{i}No se te escapa que da un paso más cerca para caminar a tu lado.{/i}"

# game/beyond the bet/day8dlc.rpy:3015
translate Spanish chat2_day8dlc_dda49637:

    # "{i}The sky above is dark, but there is still a slight warmth to the air despite the departed sun.{/i}"
    "{i}El cielo está oscuro, pero aún hay un ligero calor en el aire a pesar de que el sol se ha ido.{/i}"

# game/beyond the bet/day8dlc.rpy:3023
translate Spanish chat2_day8dlc_40d38adb:

    # "{i}It's easy to find where the festival is taking place, as music and laughter carry on the breeze.{/i}"
    "{i}Es fácil encontrar dónde se celebra el festival, pues la música y las risas viajan en la brisa.{/i}"

# game/beyond the bet/day8dlc.rpy:3024
translate Spanish chat2_day8dlc_8ab25fa4:

    # "{i}The walk is short and before long you arrive at a street filled with booths with little knick-knacks, food and carnival games.{/i}"
    "{i}El camino es corto y antes de que te des cuenta llegas a una calle llena de puestos con baratijas, comida y juegos de feria.{/i}"

# game/beyond the bet/day8dlc.rpy:3025
translate Spanish chat2_day8dlc_9bb975ea:

    # "{i}Lanterns hanging from strings above cast the area in a soft orange glow.{/i}"
    "{i}Faroles colgados de cuerdas bañan la zona con un suave resplandor anaranjado.{/i}"

# game/beyond the bet/day8dlc.rpy:3026
translate Spanish chat2_day8dlc_ef70fc13:

    # "{i}It's bustling with activity - there are people dancing and singing, and the atmosphere is contagious. The moment the two of you enter, you can't help but grin.{/i}"
    "{i}Está rebosante de actividad: hay gente bailando y cantando, y el ambiente es contagioso. En cuanto entran los dos, no puedes evitar sonreír.{/i}"

# game/beyond the bet/day8dlc.rpy:3030
translate Spanish chat2_day8dlc_2474b4ba:

    # GRC "That suits you."
    GRC "Te sienta bien."

# game/beyond the bet/day8dlc.rpy:3034
translate Spanish chat2_day8dlc_170935ea:

    # GRC "A smile."
    GRC "Una sonrisa."

# game/beyond the bet/day8dlc.rpy:3041
translate Spanish chat2_day8dlc_2efbd9e9:

    # "{i}You note a small frown forming between Casper's eyes as his gaze darts around the crowd.{/i}"
    "{i}Notas un pequeño ceño formándose entre los ojos de Casper mientras su mirada recorre la multitud.{/i}"

# game/beyond the bet/day8dlc.rpy:3046
translate Spanish chat2_day8dlc_fbf550fc:

    # GRC "It's not that. I just..."
    GRC "No es eso. Es solo que..."

# game/beyond the bet/day8dlc.rpy:3048
translate Spanish chat2_day8dlc_a05f364f:

    # GRC "I tend to avoid such gatherings of mortals. "
    GRC "Suelo evitar estas reuniones de mortales."

# game/beyond the bet/day8dlc.rpy:3050
translate Spanish chat2_day8dlc_05b4b29c:

    # GRC "Their auras are a tad overwhelming, but beyond that..."
    GRC "Sus auras son un poco abrumadoras, pero más allá de eso..."

# game/beyond the bet/day8dlc.rpy:3051
translate Spanish chat2_day8dlc_2b7a6951:

    # GRC "I feel as if I cannot ever truly fit in."
    GRC "Siento que nunca podré encajar de verdad."

# game/beyond the bet/day8dlc.rpy:3053
translate Spanish chat2_day8dlc_25b5aa68:

    # GRC "Do not mistake it for me not enjoying myself, though. To be here by your side is..."
    GRC "No lo malinterpretes como que no estoy disfrutando, sin embargo. Estar aquí a tu lado es..."

# game/beyond the bet/day8dlc.rpy:3055
translate Spanish chat2_day8dlc_bc52bc60:

    # GRC "...Yes."
    GRC "...Sí."

# game/beyond the bet/day8dlc.rpy:3060
translate Spanish chat2_day8dlc_32f44438:

    # GRC "Yes."
    GRC "Sí."

# game/beyond the bet/day8dlc.rpy:3065
translate Spanish chat2_day8dlc_8baf5f41:

    # GRC "Good."
    GRC "Bien."

# game/beyond the bet/day8dlc.rpy:3067
translate Spanish chat2_day8dlc_9a0607ee:

    # GRC "If this... is... supposed to be a date, then..."
    GRC "Si esto... se supone que es una cita, entonces..."

# game/beyond the bet/day8dlc.rpy:3068
translate Spanish chat2_day8dlc_ae82ad43:

    # "{i}The already shrinking distance between the two of you shortens again when he takes your hand in his tentatively.{/i}"
    "{i}La distancia ya reducida entre los dos se acorta de nuevo cuando él toma tu mano en la suya con timidez.{/i}"

# game/beyond the bet/day8dlc.rpy:3069
translate Spanish chat2_day8dlc_fda623c9:

    # GRC "...It's for the true festival experience."
    GRC "...Es para la verdadera experiencia del festival."

# game/beyond the bet/day8dlc.rpy:3073
translate Spanish chat2_day8dlc_7f3650b5:

    # "{i}You squeeze his hand. He squeezes it back.{/i}"
    "{i}Aprietas su mano. Él te la aprieta de vuelta.{/i}"

# game/beyond the bet/day8dlc.rpy:3078
translate Spanish chat2_day8dlc_1b3dc6bb:

    # GRC "That doesn't sound family friendly."
    GRC "Eso no suena apto para toda la familia."

# game/beyond the bet/day8dlc.rpy:3094
translate Spanish chat2_day8dlc_24d9d64c:

    # "{i}You lead Casper towards a stall with balloons attached to the backwall.{/i}"
    "{i}Guías a Casper hacia un puesto con globos pegados a la pared del fondo.{/i}"

# game/beyond the bet/day8dlc.rpy:3115
translate Spanish chat2_day8dlc_9aa77683:

    # GRC "You just... pop them?"
    GRC "¿Simplemente... los revientas?"

# game/beyond the bet/day8dlc.rpy:3120
translate Spanish chat2_day8dlc_c504293c:

    # GRC "And if I win, what do you offer me?"
    GRC "Y si gano yo, ¿qué me ofreces?"

# game/beyond the bet/day8dlc.rpy:3127
translate Spanish chat2_day8dlc_28dbe70d:

    # GRC "You were the one saying you could beat me."
    GRC "Fuiste tú quien dijo que podías vencerme."

# game/beyond the bet/day8dlc.rpy:3141
translate Spanish chat2_day8dlc_c436cd64:

    # GRC "Simple it is, then."
    GRC "Entonces que sea simple."

# game/beyond the bet/day8dlc.rpy:3142
translate Spanish chat2_day8dlc_dceba27a:

    # GRC "What would you ask of me?"
    GRC "¿Qué me pedirías?"

# game/beyond the bet/day8dlc.rpy:3150
translate Spanish chat2_day8dlc_b45c168c:

    # GRC "And the bragging rights I shall win."
    GRC "Y los derechos de presumir que ganaré."

# game/beyond the bet/day8dlc.rpy:3151
translate Spanish chat2_day8dlc_c5330ce8:

    # GRC "I accept these terms."
    GRC "Acepto estos términos."

# game/beyond the bet/day8dlc.rpy:3153
translate Spanish chat2_day8dlc_6d49bdd7:

    # GRC "Prepare yourself, my little human."
    GRC "Prepárate, mi humanit[letra]."

# game/beyond the bet/day8dlc.rpy:3157
translate Spanish chat2_day8dlc_1a3fefc3:

    # "{i}Together with Casper, the two of you pay the person running the booth, and receive six darts - three each.{/i}"
    "{i}Junto a Casper, pagan a la persona que atiende el puesto y reciben seis dardos: tres cada uno.{/i}"

# game/beyond the bet/day8dlc.rpy:3158
translate Spanish chat2_day8dlc_e0cc4b71:

    # "{i}You can't help but notice as he explains the rules that Casper has an extremely serious look on his face. Oh yeah, he's ready for this.{/i}"
    "{i}No puedes evitar notar, mientras explica las reglas, que Casper tiene una expresión extremadamente seria. Sí, está listo para esto.{/i}"

# game/beyond the bet/day8dlc.rpy:3166
translate Spanish chat2_day8dlc_4c80359e:

    # "{i}You hear a puff of air leave Casper's lips as he glances at your display. A laugh. It's like music to your ears.{/i}"
    "{i}Oyes escapar un soplo de aire de los labios de Casper al mirar tu postura. Una risa. Es como música para tus oídos.{/i}"

# game/beyond the bet/day8dlc.rpy:3167
translate Spanish chat2_day8dlc_fb1daafa:

    # "{i}You both stare down the multicolored balloons.{/i}"
    "{i}Los dos miran fijamente los globos multicolores.{/i}"

# game/beyond the bet/day8dlc.rpy:3169
translate Spanish chat2_day8dlc_fd26e9a0:

    # GRC "You should know that I have an immaculate aim."
    GRC "Deberías saber que tengo una puntería impecable."

# game/beyond the bet/day8dlc.rpy:3170
translate Spanish chat2_day8dlc_dadab6af:

    # GRC "Any other game, perhaps you would have had a chance at winning. What a shame for you."
    GRC "En cualquier otro juego, quizás habrías tenido una oportunidad de ganar. Qué lástima para ti."

# game/beyond the bet/day8dlc.rpy:3176
translate Spanish chat2_day8dlc_c35ba1f8:

    # "{i}You watch the smirk come over Casper's face as he throws his first dart.{/i}"
    "{i}Ves cómo la sonrisa burlona se dibuja en el rostro de Casper al lanzar su primer dardo.{/i}"

# game/beyond the bet/day8dlc.rpy:3178
translate Spanish chat2_day8dlc_3b3cb264:

    # "{i}POP. A balloon dies for your amusement.{/i}"
    "{i}POP. Un globo muere para tu diversión.{/i}"

# game/beyond the bet/day8dlc.rpy:3182
translate Spanish chat2_day8dlc_27846b5d:

    # GRC "Lucky? Luck does not play into this, Sunshine. That was skill."
    GRC "¿Suerte? La suerte no interviene en esto, Solecito. Eso fue habilidad."

# game/beyond the bet/day8dlc.rpy:3185
translate Spanish chat2_day8dlc_57013e47:

    # GRC "Cheating? It is below me. I always play by the rules."
    GRC "¿Trampa? Eso está por debajo de mí. Siempre juego según las reglas."

# game/beyond the bet/day8dlc.rpy:3186
translate Spanish chat2_day8dlc_7ebb8eac:

    # "{i}You lift your arm and stare down one of the balloons.{/i}"
    "{i}Levantas el brazo y apuntas a uno de los globos.{/i}"

# game/beyond the bet/day8dlc.rpy:3194
translate Spanish chat2_day8dlc_d9784f90:

    # "{i}You pause a little bit, for dramatic effect.{/i}"
    "{i}Haces una pequeña pausa, para dar dramatismo.{/i}"

# game/beyond the bet/day8dlc.rpy:3195
translate Spanish chat2_day8dlc_c0149199:

    # "{i}Casper laughes besides you.{/i}"
    "{i}Casper se ríe a tu lado.{/i}"

# game/beyond the bet/day8dlc.rpy:3198
translate Spanish chat2_day8dlc_82437dd7:

    # "{i}Your dart flies towards its target.{/i}" id chat2_day8dlc_82437dd7
    "{i}Tu dardo vuela hacia su objetivo.{/i}" id chat2_day8dlc_82437dd7

# game/beyond the bet/day8dlc.rpy:3200
translate Spanish chat2_day8dlc_c8839506:

    # "{i}And with a satisfying POP, finds purchase!{/i}"
    "{i}¡Y con un satisfactorio POP, da en el blanco!{/i}"

# game/beyond the bet/day8dlc.rpy:3218
translate Spanish chat2_day8dlc_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day8dlc.rpy:3219
translate Spanish chat2_day8dlc_325488f4:

    # GRC "Ah. I have heard of this."
    GRC "Ah. He oído hablar de esto."

# game/beyond the bet/day8dlc.rpy:3221
translate Spanish chat2_day8dlc_56237447:

    # GRC "They call it beginner's luck."
    GRC "Lo llaman suerte de principiante."

# game/beyond the bet/day8dlc.rpy:3227
translate Spanish chat2_day8dlc_a647105a:

    # GRC "I have not. Er. I do not think I have, anyway."
    GRC "Yo no. Eh. No creo haberlo hecho, en todo caso."

# game/beyond the bet/day8dlc.rpy:3233
translate Spanish chat2_day8dlc_88556952:

    # GRC "An incredibly lame title for an incredibly lame mortal."
    GRC "Un título increíblemente soso para [arti_2] mortal increíblemente sos[letra]."

# game/beyond the bet/day8dlc.rpy:3236
translate Spanish chat2_day8dlc_28a692f0:

    # GRC "Do not get too overconfident."
    GRC "No te confíes demasiado."

# game/beyond the bet/day8dlc.rpy:3237
translate Spanish chat2_day8dlc_a631007e:

    # "{i}Casper raises both his hands, a dart in each.{/i}"
    "{i}Casper levanta ambas manos, con un dardo en cada una.{/i}"

# game/beyond the bet/day8dlc.rpy:3250
translate Spanish chat2_day8dlc_349cb44a:

    # GRC "Shh. You truly never stop yapping."
    GRC "Shh. De verdad que nunca dejas de parlotear."

# game/beyond the bet/day8dlc.rpy:3251
translate Spanish chat2_day8dlc_40940dff:

    # GRC "Do not distract me."
    GRC "No me distraigas."

# game/beyond the bet/day8dlc.rpy:3261
translate Spanish chat2_day8dlc_008afe10_2:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day8dlc.rpy:3262
translate Spanish chat2_day8dlc_ef882394:

    # GRC "A worthy effort, but I am not afraid."
    GRC "Un esfuerzo digno, pero no tengo miedo."

# game/beyond the bet/day8dlc.rpy:3271
translate Spanish chat2_day8dlc_b088320f:

    # "{i}Both darts leave his hands.{/i}"
    "{i}Ambos dardos salen de sus manos.{/i}"

# game/beyond the bet/day8dlc.rpy:3275
translate Spanish chat2_day8dlc_b6ba2d0e:

    # "{i}And two balloons go POP.{/i}"
    "{i}Y dos globos hacen POP.{/i}"

# game/beyond the bet/day8dlc.rpy:3291
translate Spanish chat2_day8dlc_fa1492ac:

    # "{i}You mimic his posture and raise two darts.{/i}"
    "{i}Imitas su postura y levantas dos dardos.{/i}"

# game/beyond the bet/day8dlc.rpy:3292
translate Spanish chat2_day8dlc_5be17c3e:

    # "{i}You feel strong. Powerful.{/i}"
    "{i}Sientes fuerza. Sientes poder.{/i}"

# game/beyond the bet/day8dlc.rpy:3293
translate Spanish chat2_day8dlc_bbbe2202:

    # "{i}This will be easy. You let the darts fly.{i}"
    "{i}Esto será fácil. Dejas volar los dardos.{/i}"

# game/beyond the bet/day8dlc.rpy:3294
translate Spanish chat2_day8dlc_8570079f:

    # "{i}The moment would have been epic - a tale to pass down the ages - had any balloons popped.{/i}"
    "{i}El momento habría sido épico, una historia para transmitir por generaciones, si algún globo hubiera reventado.{/i}"

# game/beyond the bet/day8dlc.rpy:3295
translate Spanish chat2_day8dlc_d22ce85a:

    # "{i}They did not.{/i}"
    "{i}No lo hicieron.{/i}"

# game/beyond the bet/day8dlc.rpy:3296
translate Spanish chat2_day8dlc_3394e8fd:

    # GRC "Hah! Unsurprising, honestly."
    GRC "¡Ja! Poco sorprendente, la verdad."

# game/beyond the bet/day8dlc.rpy:3298
translate Spanish chat2_day8dlc_873385f2:

    # GRC "We'll need to work on honing these so called 'skills' of yours, Sunshine."
    GRC "Tendremos que trabajar en perfeccionar esas supuestas 'habilidades' tuyas, Solecito."

# game/beyond the bet/day8dlc.rpy:3301
translate Spanish chat2_day8dlc_0a0c868d:

    # GRC "This game was made for me."
    GRC "Este juego fue hecho para mí."

# game/beyond the bet/day8dlc.rpy:3302
translate Spanish chat2_day8dlc_39f06bed:

    # GRC "There is no need to feel shame."
    GRC "No hay necesidad de sentir vergüenza."

# game/beyond the bet/day8dlc.rpy:3303
translate Spanish chat2_day8dlc_add2153e:

    # GRC "You had already lost before you even attempted the shot."
    GRC "Ya habías perdido antes siquiera de intentar el tiro."

# game/beyond the bet/day8dlc.rpy:3308
translate Spanish chat2_day8dlc_b63c8d1e:

    # GRC "That sounds like an excuse."
    GRC "Eso suena a excusa."

# game/beyond the bet/day8dlc.rpy:3320
translate Spanish chat2_day8dlc_1965947a:

    # GRC "Lying once again?"
    GRC "¿Mintiendo otra vez?"

# game/beyond the bet/day8dlc.rpy:3329
translate Spanish chat2_day8dlc_5e6447f6:

    # GRC "It is no matter."
    GRC "No importa."

# game/beyond the bet/day8dlc.rpy:3330
translate Spanish chat2_day8dlc_989654b8:

    # GRC "I have won this bet, Sunshine."
    GRC "He ganado esta apuesta, Solecito."

# game/beyond the bet/day8dlc.rpy:3342
translate Spanish chat2_day8dlc_cdf8d112:

    # "{i}Taking Casper's hand, the two of you continue to stroll around the festival.{/i}"
    "{i}Tomando la mano de Casper, los dos siguen paseando por el festival.{/i}"

# game/beyond the bet/day8dlc.rpy:3343
translate Spanish chat2_day8dlc_6081e271:

    # "{i}You take in the lights, the colors, the smells, and the sights.{/i}"
    "{i}Absorbes las luces, los colores, los olores y las vistas.{/i}"

# game/beyond the bet/day8dlc.rpy:3344
translate Spanish chat2_day8dlc_8fa5c0ec:

    # "{i}But more importantly, you take in Casper's reaction to everything.{/i}"
    "{i}Pero, más importante, absorbes la reacción de Casper ante todo.{/i}"

# game/beyond the bet/day8dlc.rpy:3345
translate Spanish chat2_day8dlc_48c6e66c:

    # "{i}There is a wide-eyed look of awe on his face. It's as if he is seeing a new world for the first time.{/i}"
    "{i}Hay una mirada de asombro con los ojos muy abiertos en su rostro. Es como si viera un mundo nuevo por primera vez.{/i}"

# game/beyond the bet/day8dlc.rpy:3346
translate Spanish chat2_day8dlc_29778c41:

    # "{i}It is decidedly human of him.{/i}"
    "{i}Es decididamente humano de su parte.{/i}"

# game/beyond the bet/day8dlc.rpy:3347
translate Spanish chat2_day8dlc_7b0fd615:

    # "{i}Every now and then, he brags about winning your bet, but mostly he just lets you pull him from one booth to the next, enjoying the atmosphere.{/i}"
    "{i}De vez en cuando presume de haber ganado tu apuesta, pero sobre todo se deja llevar por ti de un puesto al siguiente, disfrutando del ambiente.{/i}"

# game/beyond the bet/day8dlc.rpy:3348
translate Spanish chat2_day8dlc_ec09caf2:

    # "{i}It's endearing.{/i}"
    "{i}Es entrañable.{/i}"

# game/beyond the bet/day8dlc.rpy:3349
translate Spanish chat2_day8dlc_6d14f210:

    # "{i}He is genuinely.... excited. Having a good time.{/i}"
    "{i}Está genuinamente.... emocionado. Pasándola bien.{/i}"

# game/beyond the bet/day8dlc.rpy:3350
translate Spanish chat2_day8dlc_1811154c:

    # "{i}Together, with you.{/i}"
    "{i}Juntos, contigo.{/i}"

# game/beyond the bet/day8dlc.rpy:3351
translate Spanish chat2_day8dlc_3e235bf6:

    # "{i}Your heart hammers away in your chest and you try to think of the last time you had so much fun.{/i}"
    "{i}Tu corazón late con fuerza en tu pecho y tratas de recordar la última vez que te divertiste tanto.{/i}"

# game/beyond the bet/day8dlc.rpy:3352
translate Spanish chat2_day8dlc_1cd8097e:

    # "{i}How long has it been?{/i}"
    "{i}¿Cuánto tiempo ha pasado?{/i}"

# game/beyond the bet/day8dlc.rpy:3353
translate Spanish chat2_day8dlc_5ecda8be:

    # "{i}Too long. Far too long.{/i}"
    "{i}Demasiado. Muchísimo.{/i}"

# game/beyond the bet/day8dlc.rpy:3354
translate Spanish chat2_day8dlc_f227377c:

    # "{i}This frustratingly charming (yet surprisingly easily flustered) man is to blame. He has you grinning from ear to ear before you even realize it.{/i}"
    "{i}Este hombre exasperantemente encantador (pero sorprendentemente fácil de avergonzar) tiene la culpa. Te tiene sonriendo de oreja a oreja antes de que te des cuenta.{/i}"

# game/beyond the bet/day8dlc.rpy:3355
translate Spanish chat2_day8dlc_fea0ec34:

    # "{i}Your train of thought is interrupted as a streak of light soars up into the night sky, then erupts into a colorful firework.{/i}"
    "{i}Tu hilo de pensamientos se interrumpe cuando una estela de luz se eleva hacia el cielo nocturno y luego estalla en un colorido fuego artificial.{/i}"

# game/beyond the bet/day8dlc.rpy:3356
translate Spanish chat2_day8dlc_d3150aa7:

    # "{i}Casper sucks in a breath, his eyes wide as he watches.{/i}"
    "{i}Casper inspira hondo, con los ojos muy abiertos mientras observa.{/i}"

# game/beyond the bet/day8dlc.rpy:3370
translate Spanish chat2_day8dlc_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/beyond the bet/day8dlc.rpy:3372
translate Spanish chat2_day8dlc_07a90e50:

    # GRC "They are... so fleeting. So brief."
    GRC "Son... tan fugaces. Tan breves."

# game/beyond the bet/day8dlc.rpy:3379
translate Spanish chat2_day8dlc_440777de:

    # GRC "They're... beautiful."
    GRC "Son... hermosos."

# game/beyond the bet/day8dlc.rpy:3380
translate Spanish chat2_day8dlc_4536ce04:

    # GRC "There one moment, then gone the next."
    GRC "Están ahí un momento y al siguiente se han ido."

# game/beyond the bet/day8dlc.rpy:3384
translate Spanish chat2_day8dlc_270c4d33:

    # GRC "Very human, indeed."
    GRC "Muy humano, en efecto."

# game/beyond the bet/day8dlc.rpy:3387
translate Spanish chat2_day8dlc_c4a93af8:

    # GRC "I can see why you humans like these festivals."
    GRC "Entiendo por qué a los humanos les gustan estos festivales."

# game/beyond the bet/day8dlc.rpy:3393
translate Spanish chat2_day8dlc_348c09b1:

    # GRC "They're different where I'm from."
    GRC "Son diferentes de donde vengo."

# game/beyond the bet/day8dlc.rpy:3394
translate Spanish chat2_day8dlc_892af85f:

    # GRC "They're not a celebration of life, really. There are no fireworks, or balloons, or..."
    GRC "No son realmente una celebración de la vida. No hay fuegos artificiales, ni globos, ni..."

# game/beyond the bet/day8dlc.rpy:3395
translate Spanish chat2_day8dlc_45784de5:

    # GRC "Charming dates..."
    GRC "Citas encantadoras..."

# game/beyond the bet/day8dlc.rpy:3398
translate Spanish chat2_day8dlc_e212b647:

    # GRC "...Thank you for coming with me."
    GRC "...Gracias por venir conmigo."

# game/beyond the bet/day8dlc.rpy:3405
translate Spanish chat2_day8dlc_27481b1f:

    # GRC "I wouldn't have thought to come if not for you."
    GRC "No se me habría ocurrido venir si no fuera por ti."

# game/beyond the bet/day8dlc.rpy:3406
translate Spanish chat2_day8dlc_65122790_1:

    # GRC "I..."
    GRC "Yo..."

# game/beyond the bet/day8dlc.rpy:3407
translate Spanish chat2_day8dlc_9d4e143e:

    # GRC "There's so much I wouldn't have done if not for you."
    GRC "Hay tantas cosas que no habría hecho si no fuera por ti."

# game/beyond the bet/day8dlc.rpy:3408
translate Spanish chat2_day8dlc_e33200b4:

    # GRC "You are..."
    GRC "Eres..."

# game/beyond the bet/day8dlc.rpy:3416
translate Spanish chat2_day8dlc_56e1cbf5:

    # GRC "Everything."
    GRC "Todo."

# game/beyond the bet/day8dlc.rpy:3417
translate Spanish chat2_day8dlc_1afbdb93:

    # GRC "You really embody the best parts of mortality. The best parts of life."
    GRC "Realmente encarnas lo mejor de la mortalidad. Lo mejor de la vida."

# game/beyond the bet/day8dlc.rpy:3418
translate Spanish chat2_day8dlc_14a0432b:

    # GRC "I feel lucky to have met you, despite how much it... pains me to admit that."
    GRC "Me siento afortunado de haberte conocido, a pesar de lo mucho que me... duele admitirlo."

# game/beyond the bet/day8dlc.rpy:3419
translate Spanish chat2_day8dlc_dcd1ad3c:

    # GRC "You were supposed to be another job."
    GRC "Se suponía que serías otro trabajo."

# game/beyond the bet/day8dlc.rpy:3427
translate Spanish chat2_day8dlc_faf4a0ab:

    # GRC "Gods, you're an idiot."
    GRC "Dioses, eres [arti_2] idiota."

# game/beyond the bet/day8dlc.rpy:3431
translate Spanish chat2_day8dlc_9def08fc:

    # GRC "For some reason..."
    GRC "Por alguna razón..."

# game/beyond the bet/day8dlc.rpy:3432
translate Spanish chat2_day8dlc_72509e84:

    # GRC "No, it's beyond reason."
    GRC "No, está más allá de la razón."

# game/beyond the bet/day8dlc.rpy:3433
translate Spanish chat2_day8dlc_3a2c8aa7:

    # GRC "You're an idiot, but I like it."
    GRC "Eres [arti_2] idiota, pero me gusta."

# game/beyond the bet/day8dlc.rpy:3434
translate Spanish chat2_day8dlc_f513e4e5:

    # GRC "How stupid."
    GRC "Qué estupidez."

# game/beyond the bet/day8dlc.rpy:3437
translate Spanish chat2_day8dlc_675894e8:

    # GRC "Ah.... shit."
    GRC "Ah.... mierda."

# game/beyond the bet/day8dlc.rpy:3445
translate Spanish chat2_day8dlc_4bf13968:

    # GRC "I... I cannot help but have these.... thoughts. These unwanted feelings."
    GRC "Yo... no puedo evitar tener estos.... pensamientos. Estos sentimientos no deseados."

# game/beyond the bet/day8dlc.rpy:3453
translate Spanish chat2_day8dlc_008afe10_3:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day8dlc.rpy:3454
translate Spanish chat2_day8dlc_2a31d3e5:

    # GRC "I... enjoy spending time with you."
    GRC "Yo... disfruto pasar tiempo contigo."

# game/beyond the bet/day8dlc.rpy:3455
translate Spanish chat2_day8dlc_a5de1da8:

    # GRC "Like... this."
    GRC "Así... como esto."

# game/beyond the bet/day8dlc.rpy:3456
translate Spanish chat2_day8dlc_89966f3d:

    # GRC "Online, too, of course. But here, together, in person... it is... wonderful."
    GRC "En línea también, claro. Pero aquí, juntos, en persona... es... maravilloso."

# game/beyond the bet/day8dlc.rpy:3457
translate Spanish chat2_day8dlc_e5b25cd6:

    # GRC "This was... not supposed to happen. It still should not happen."
    GRC "Esto... no se suponía que pasara. Todavía no debería pasar."

# game/beyond the bet/day8dlc.rpy:3458
translate Spanish chat2_day8dlc_44ebe9d9:

    # GRC "And yet I want to throw that to the wind. To just... do what I wish to, for once in my long life."
    GRC "Y sin embargo quiero echarlo todo al viento. Simplemente... hacer lo que quiero, por una vez en mi larga vida."

# game/beyond the bet/day8dlc.rpy:3462
translate Spanish chat2_day8dlc_900446c7:

    # "{i}The fireworks continue to burst above you. The colors dance across Casper's face.{/i}"
    "{i}Los fuegos artificiales siguen estallando sobre ustedes. Los colores bailan sobre el rostro de Casper.{/i}"

# game/beyond the bet/day8dlc.rpy:3463
translate Spanish chat2_day8dlc_0b409f4b:

    # GRC "Sunshine, I..."
    GRC "Solecito, yo..."

# game/beyond the bet/day8dlc.rpy:3466
translate Spanish chat2_day8dlc_11fb7d24:

    # GRC "I like you. I really... really like you."
    GRC "Me gustas. De verdad... de verdad me gustas."

# game/beyond the bet/day8dlc.rpy:3467
translate Spanish chat2_day8dlc_930e3829:

    # GRC "I... I love you. I never meant to, but I do."
    GRC "Yo... te amo. Nunca quise, pero es así."

# game/beyond the bet/day8dlc.rpy:3468
translate Spanish chat2_day8dlc_0e6fedda:

    # GRC "Every day I wanted to wake up and hate you."
    GRC "Cada día quería despertar y odiarte."

# game/beyond the bet/day8dlc.rpy:3469
translate Spanish chat2_day8dlc_f0873875:

    # GRC "But there has always been a part of me that is drawn to you, like moth to a flame."
    GRC "Pero siempre ha habido una parte de mí que se siente atraída hacia ti, como una polilla hacia la llama."

# game/beyond the bet/day8dlc.rpy:3470
translate Spanish chat2_day8dlc_453bf6e4:

    # GRC "I thought if I... if I could just win our bet, then I would rid myself of these feelings."
    GRC "Pensé que si... si lograba ganar nuestra apuesta, me libraría de estos sentimientos."

# game/beyond the bet/day8dlc.rpy:3471
translate Spanish chat2_day8dlc_f23062f7:

    # GRC "But now, I..."
    GRC "Pero ahora yo..."

# game/beyond the bet/day8dlc.rpy:3472
translate Spanish chat2_day8dlc_f56e37a8:

    # GRC "I do not want to win."
    GRC "No quiero ganar."

# game/beyond the bet/day8dlc.rpy:3473
translate Spanish chat2_day8dlc_f154fcf2:

    # GRC "I wouldn't mind losing."
    GRC "No me importaría perder."

# game/beyond the bet/day8dlc.rpy:3474
translate Spanish chat2_day8dlc_2ee47092:

    # GRC "Not to you."
    GRC "No contra ti."

# game/beyond the bet/day8dlc.rpy:3475
translate Spanish chat2_day8dlc_813096dd:

    # GRC "Because the thought of losing you for even a moment tears me apart."
    GRC "Porque la idea de perderte, aunque sea por un instante, me destroza."

# game/beyond the bet/day8dlc.rpy:3476
translate Spanish chat2_day8dlc_5ebda5fe:

    # "{i}His words hang in the warm air. The fireworks continue.{/i}"
    "{i}Sus palabras quedan suspendidas en el aire cálido. Los fuegos artificiales continúan.{/i}"

# game/beyond the bet/day8dlc.rpy:3477
translate Spanish chat2_day8dlc_89727a19:

    # "{i}He looks... scared. Fragile, for only this moment. Nervous.{/i}"
    "{i}Parece... asustado. Frágil, solo por este momento. Nervioso.{/i}"

# game/beyond the bet/day8dlc.rpy:3481
translate Spanish chat2_day8dlc_8fb992b4:

    # GRC "You... you... what?"
    GRC "Tú... tú... ¿qué?"

# game/beyond the bet/day8dlc.rpy:3498
translate Spanish chat2_day8dlc_0cdc59a3:

    # GRC "I... yes."
    GRC "Yo... sí."

# game/beyond the bet/day8dlc.rpy:3502
translate Spanish chat2_day8dlc_62b28c75:

    # GRC "Gods..."
    GRC "Dioses..."

# game/beyond the bet/day8dlc.rpy:3503
translate Spanish chat2_day8dlc_a9593bbf:

    # GRC "To hear those words, spoken from those lips, in your voice..."
    GRC "Oír esas palabras, dichas por esos labios, con tu voz..."

# game/beyond the bet/day8dlc.rpy:3505
translate Spanish chat2_day8dlc_6458870c:

    # GRC "It is enough to destroy a man."
    GRC "Es suficiente para destruir a un hombre."

# game/beyond the bet/day8dlc.rpy:3509
translate Spanish chat2_day8dlc_008afe10_4:

    # GRC "..." id chat2_day8dlc_008afe10_4
    GRC "..." id chat2_day8dlc_008afe10_4

# game/beyond the bet/day8dlc.rpy:3510
translate Spanish chat2_day8dlc_2b2a3d69:

    # GRC "I... have hoped. I have prayed, even if I know no one listens to me."
    GRC "Yo... he tenido esperanzas. He rezado, aunque sé que nadie me escucha."

# game/beyond the bet/day8dlc.rpy:3511
translate Spanish chat2_day8dlc_e9dce02a:

    # GRC "That's what you have done to me."
    GRC "Eso es lo que me has hecho."

# game/beyond the bet/day8dlc.rpy:3515
translate Spanish chat2_day8dlc_d3c46d0a:

    # GRC "Sunshine..."
    GRC "Solecito..."

# game/beyond the bet/day8dlc.rpy:3517
translate Spanish chat2_day8dlc_7a733696:

    # GRC "I... love you."
    GRC "Yo... te amo."

# game/beyond the bet/day8dlc.rpy:3539
translate Spanish chat2_day8dlc_1253f4a3:

    # GRC "Love is... extremely dangerous, Sunshine."
    GRC "El amor es... extremadamente peligroso, Solecito."

# game/beyond the bet/day8dlc.rpy:3543
translate Spanish chat2_day8dlc_7b74c335:

    # GRC "For us, it will be."
    GRC "Para nosotros, lo será."

# game/beyond the bet/day8dlc.rpy:3550
translate Spanish chat2_day8dlc_ab0c2411:

    # GRC "You seriously lack self preservation skills."
    GRC "De verdad te falta instinto de conservación."

# game/beyond the bet/day8dlc.rpy:3557
translate Spanish chat2_day8dlc_008afe10_5:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day8dlc.rpy:3558
translate Spanish chat2_day8dlc_2a230ec0:

    # GRC "I... don't plan on letting headquarters find out."
    GRC "Yo... no pienso dejar que la central se entere."

# game/beyond the bet/day8dlc.rpy:3559
translate Spanish chat2_day8dlc_de63ec93:

    # GRC "If they remain unaware, then... we'll have some time. I hope."
    GRC "Si siguen sin saberlo, entonces... tendremos algo de tiempo. Eso espero."

# game/beyond the bet/day8dlc.rpy:3564
translate Spanish chat2_day8dlc_01c9dfe1:

    # GRC "Can you be careful, Sunshine? It's not really like you."
    GRC "¿Puedes tener cuidado, Solecito? No es muy propio de ti."

# game/beyond the bet/day8dlc.rpy:3572
translate Spanish chat2_day8dlc_07b463e1:

    # GRC "Haaah... please, if anyone IS listening, allow me this one happiness."
    GRC "Haaah... por favor, si ALGUIEN está escuchando, permítanme esta única felicidad."

# game/beyond the bet/day8dlc.rpy:3580
translate Spanish chat2_day8dlc_b52ee780:

    # GRC "...Good. I'm glad. You deserve only the best."
    GRC "...Bien. Me alegro. Mereces solo lo mejor."

# game/beyond the bet/day8dlc.rpy:3587
translate Spanish chat2_day8dlc_96114d86:

    # GRC "If I could have my way, I... would be with you forever."
    GRC "Si fuera por mí, yo... estaría contigo para siempre."

# game/beyond the bet/day8dlc.rpy:3589
translate Spanish chat2_day8dlc_4249ba47:

    # GRC "But... with the way I was made..."
    GRC "Pero... con la forma en que fui hecho..."

# game/beyond the bet/day8dlc.rpy:3590
translate Spanish chat2_day8dlc_5b3e6aeb:

    # GRC "Well, I'll take whatever moments we are given."
    GRC "Bueno, aceptaré todos los momentos que nos den."

# game/beyond the bet/day8dlc.rpy:3595
translate Spanish chat2_day8dlc_422bf31a:

    # GRC "To... your apartment?"
    GRC "¿A... tu apartamento?"

# game/beyond the bet/day8dlc.rpy:3603
translate Spanish chat2_day8dlc_eff224c4:

    # GRC "I... I'll come back with you..."
    GRC "Yo... volveré contigo..."

# game/beyond the bet/day8dlc.rpy:3607
translate Spanish chat2_day8dlc_008afe10_6:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day8dlc.rpy:3608
translate Spanish chat2_day8dlc_d62f28fa:

    # GRC "You... want me to stay?"
    GRC "Tú... ¿quieres que me quede?"

# game/beyond the bet/day8dlc.rpy:3612
translate Spanish chat2_day8dlc_5c704fc1:

    # GRC "...Okay. I... must admit, I do desire to... be close to you."
    GRC "...Okey. Yo... debo admitir que sí deseo... estar cerca de ti."

# game/beyond the bet/day8dlc.rpy:3616
translate Spanish chat2_day8dlc_b2742a6f:

    # GRC "Shut up."
    GRC "Cállate."

# game/beyond the bet/day8dlc.rpy:3627
translate Spanish chat2_day8dlc_008afe10_7:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day8dlc.rpy:3628
translate Spanish chat2_day8dlc_96199420:

    # GRC "I... I want that too."
    GRC "Yo... yo también quiero eso."

# game/beyond the bet/day8dlc.rpy:3629
translate Spanish chat2_day8dlc_fc6e88fc:

    # GRC "To feel everything, with you."
    GRC "Sentirlo todo, contigo."

# game/beyond the bet/day8dlc.rpy:3640
translate Spanish afterfestival_dae5a2bc:

    # "{i}Your chest feels... warm. Your heart, full.{/i}"
    "{i}Tu pecho se siente... cálido. Tu corazón, lleno.{/i}"

# game/beyond the bet/day8dlc.rpy:3641
translate Spanish afterfestival_4722f30e:

    # "{i}He holds your hand so delicately.{/i}"
    "{i}Él sostiene tu mano con tanta delicadeza.{/i}"

# game/beyond the bet/day8dlc.rpy:3642
translate Spanish afterfestival_186726ad:

    # "{i}Like it's only natural that the two of you are connected like this.{/i}"
    "{i}Como si fuera de lo más natural que ustedes dos estén conectados así.{/i}"

# game/beyond the bet/day8dlc.rpy:3643
translate Spanish afterfestival_5278fa15:

    # "{i}A happy feeling blooms from inside of you as you break into a run, pulling Casper along through the streets.{/i}"
    "{i}Una sensación de felicidad florece en tu interior mientras echas a correr, arrastrando a Casper por las calles.{/i}"

# game/beyond the bet/day8dlc.rpy:3644
translate Spanish afterfestival_7d961325:

    # "{i}You laugh. He laughs.{/i}"
    "{i}Tú ríes. Él ríe.{/i}"

# game/beyond the bet/day8dlc.rpy:3645
translate Spanish afterfestival_61231281:

    # "{i}Life is fleeting, but good.{/i}"
    "{i}La vida es fugaz, pero buena.{/i}"

# game/beyond the bet/day8dlc.rpy:3646
translate Spanish afterfestival_5848edc0:

    # "{i}You reach your apartment and pull Casper inside, closing the door behind you for the night.{/i}"
    "{i}Llegas a tu apartamento y haces entrar a Casper, cerrando la puerta tras de ti por esta noche.{/i}"

translate Spanish strings:

    # game/beyond the bet/day8dlc.rpy:35
    old "illness BEGONE!!!"
    new "{size=18}¡¡¡fuera, ENFERMEDAD!!!{/size}"

    # game/beyond the bet/day8dlc.rpy:64
    old "1. <The sun is shining ~ the sky is blue ~ my little reaper ~ how are you?>"
    new "1. <El sol brilla ~ el cielo es azul ~ mi parquita ~ ¿cómo estás tú?>"

    # game/beyond the bet/day8dlc.rpy:67
    old "1. <What do you think of my merry little song?>"
    new "1. <¿Qué te parece mi alegre cancioncita?>"

    # game/beyond the bet/day8dlc.rpy:69
    old "2. <Not bad, eh?>"
    new "2. <Nada mal, ¿eh?>"

    # game/beyond the bet/day8dlc.rpy:72
    old "1. <Just imagine I'm singing it.>"
    new "1. <Imagina que la estoy cantando.>"

    # game/beyond the bet/day8dlc.rpy:75
    old "1. <I could even do a little dance at the same time.>"
    new "1. <Hasta podría bailar un poquito al mismo tiempo.>"

    # game/beyond the bet/day8dlc.rpy:78
    old "1. <Can you dance?>"
    new "1. <¿Sabes bailar?>"

    # game/beyond the bet/day8dlc.rpy:81
    old "1. <Even if you can't, I bet you'd say you could.>"
    new "1. <Aunque no sepas, seguro dirías que sí.>"

    # game/beyond the bet/day8dlc.rpy:84
    old "1. <You'd be all 'i can do anything i want to do'.>"
    new "1. <Dirías: 'puedo hacer lo que quiera'.>"

    # game/beyond the bet/day8dlc.rpy:92
    old "1. <Suits you. A little bit extra, a little bit emo.>"
    new "1. <Te queda bien. Un poco exagerado, un poco emo.>"

    # game/beyond the bet/day8dlc.rpy:94
    old "2. <Wait, really? That's a little sad.>"
    new "2. <Espera, ¿en serio? Qué triste.>"

    # game/beyond the bet/day8dlc.rpy:97
    old "1. <You can jump over here and check out the blue skies, then.>"
    new "1. <Entonces puedes pasarte por aquí y echarle un vistazo al cielo azul.>"

    # game/beyond the bet/day8dlc.rpy:100
    old "1. <I know they say the grass is always greener on the other side...>"
    new "1. <Ya sé que dicen que el pasto del vecino siempre es más verde...>"

    # game/beyond the bet/day8dlc.rpy:103
    old "1. <But it literally is, in this case.>"
    new "1. <Pero en este caso, literalmente, lo es.>"

    # game/beyond the bet/day8dlc.rpy:106
    old "2. <Wakey wakey! Grim-o, do you feel better?>"
    new "2. <¡Arriba, arriba! Parquit-o, ¿te sientes mejor?>"

    # game/beyond the bet/day8dlc.rpy:109
    old "1. <Grim-a.>"
    new "1. <Parquit-a.>"

    # game/beyond the bet/day8dlc.rpy:112
    old "1. <Grim-e.>"
    new "1. <Parquit-e.>"

    # game/beyond the bet/day8dlc.rpy:115
    old "1. <Grim-i.>"
    new "1. <Parquit-i.>"

    # game/beyond the bet/day8dlc.rpy:118
    old "1. <Grim-o.>"
    new "1. <Parquit-o.>"

    # game/beyond the bet/day8dlc.rpy:122
    old "1. <Grim-u.>"
    new "1. <Parquit-u.>"

    # game/beyond the bet/day8dlc.rpy:126
    old "1. <Grim-y.>"
    new "1. <Parquit-y.>"

    # game/beyond the bet/day8dlc.rpy:130
    old "1. <Sometimes Y is used as a sneaky vowel.>"
    new "1. <A veces la Y se cuela como vocal.>"

    # game/beyond the bet/day8dlc.rpy:134
    old "1. <I wouldn't want it to feel left out.>"
    new "1. <No quisiera que se sintiera excluida.>"

    # game/beyond the bet/day8dlc.rpy:139
    old "2. <I'd like to see you do better.>"
    new "2. <Me gustaría verte hacerlo mejor.>"

    # game/beyond the bet/day8dlc.rpy:144
    old "1. <You've been practicing, I see...>"
    new "1. <Has estado practicando, ya veo...>"

    # game/beyond the bet/day8dlc.rpy:151
    old "3. <Seeing as I've lived through the night, I'd say \nthe cold didn't snuff you out.>"
    new "3. <Ya que sobreviví a la noche, diría que el resfriado no acabó contigo.>"

    # game/beyond the bet/day8dlc.rpy:154
    old "1. <My big strong boy <3>"
    new "1. <Mi chico grande y fuerte <3>"

    # game/beyond the bet/day8dlc.rpy:157
    old "1. <Are you feeling any better?>"
    new "1. <¿Te sientes mejor?>"

    # game/beyond the bet/day8dlc.rpy:160
    old "1. <Ah, damn...>"
    new "1. <Ah, maldición...>"

    # game/beyond the bet/day8dlc.rpy:163
    old "1. <I missed my chance to send you a 'get well soon' card and chocolates.>"
    new "1. <Se me pasó la oportunidad de mandarte una tarjeta de 'mejórate pronto' y chocolates.>"

    # game/beyond the bet/day8dlc.rpy:166
    old "1. <Next time, for sure.>"
    new "1. <La próxima vez, seguro.>"

    # game/beyond the bet/day8dlc.rpy:173
    old "1. <A sweet tooth? Unexpected.>"
    new "1. <¿Eres goloso? Inesperado.>"

    # game/beyond the bet/day8dlc.rpy:175
    old "2. <You like chocolate? :O>"
    new "2. <¿Te gusta el chocolate? :O>"

    # game/beyond the bet/day8dlc.rpy:187
    old "1. <Honestly, yeah.>"
    new "1. <Sinceramente, sí.>"

    # game/beyond the bet/day8dlc.rpy:190
    old "1. <I WAS worried about you.>"
    new "1. <SÍ me preocupé por ti.>"

    # game/beyond the bet/day8dlc.rpy:193
    old "1. <Like you said, you've never been sick.>"
    new "1. <Como dijiste, nunca te has enfermado.>"

    # game/beyond the bet/day8dlc.rpy:196
    old "1. <Being sick alone sucks.>"
    new "1. <Enfermarse estando solo es un asco.>"

    # game/beyond the bet/day8dlc.rpy:199
    old "1. <Being sick alone after never being sick before?>"
    new "1. <¿Enfermarse estando solo después de no haberse enfermado nunca?>"

    # game/beyond the bet/day8dlc.rpy:202
    old "1. <That sounds shitty.>"
    new "1. <Eso suena fatal.>"

    # game/beyond the bet/day8dlc.rpy:209
    old "2. <Sounds like you were thinking about me, buddy.>"
    new "2. <Suena como si estuvieras pensando en mí, amigo.>"

    # game/beyond the bet/day8dlc.rpy:212
    old "1. <You're sitting there, imagining me imagining you.>"
    new "1. <Estás ahí sentado, imaginándome imaginándote.>"

    # game/beyond the bet/day8dlc.rpy:215
    old "1. <Do you like me that much?>"
    new "1. <¿Tanto te gusto?>"

    # game/beyond the bet/day8dlc.rpy:220
    old "1. <You liiiike me.>"
    new "1. <Te guuuusto.>"

    # game/beyond the bet/day8dlc.rpy:226
    old "1. <What about me as a whole?>"
    new "1. <¿Y yo en general?>"

    # game/beyond the bet/day8dlc.rpy:230
    old "1. <Well, you're right about that.>"
    new "1. <Bueno, en eso tienes razón.>"

    # game/beyond the bet/day8dlc.rpy:233
    old "1. <I would be very good at satisfying you.>"
    new "1. <Se me daría muy bien satisfacerte.>"

    # game/beyond the bet/day8dlc.rpy:236
    old "1. <Like, I could cook you a meal.>"
    new "1. <Por ejemplo, podría cocinarte una comida.>"

    # game/beyond the bet/day8dlc.rpy:238
    old "2. <I could brush your hair! That would be satisfying.>"
    new "2. <¡Podría cepillarte el cabello! Eso sería satisfactorio.>"

    # game/beyond the bet/day8dlc.rpy:243
    old "1. <What did you think I meant?>"
    new "1. <¿A qué creíste que me refería?>"

    # game/beyond the bet/day8dlc.rpy:248
    old "1. <Hahaha. You're so cute.>"
    new "1. <Jajaja. Eres tan lindo.>"

    # game/beyond the bet/day8dlc.rpy:252
    old "1. <Fantasize all you wish~>"
    new "1. <Fantasea todo lo que quieras~>"

    # game/beyond the bet/day8dlc.rpy:254
    old "2. <So cute, yet such a dirty boy.>"
    new "2. <Tan lindo, pero tan pervertido.>"

    # game/beyond the bet/day8dlc.rpy:260
    old "1. <Yeah, yeah. How are you feeling today, then?>"
    new "1. <Sí, sí. ¿Cómo te sientes hoy, entonces?>"

    # game/beyond the bet/day8dlc.rpy:264
    old "3. <I was more worried about myself, truthfully.>"
    new "3. <Estaba más preocupad[letra] por mí, la verdad.>"

    # game/beyond the bet/day8dlc.rpy:267
    old "1. <If you were suddenly better...>"
    new "1. <Si de pronto estabas mejor...>"

    # game/beyond the bet/day8dlc.rpy:270
    old "1. <What was stopping you from turning up at 11:59PM and taking my soul?>"
    new "1. <¿Qué te impedía aparecer a las 11:59 p. m. y llevarte mi alma?>"

    # game/beyond the bet/day8dlc.rpy:273
    old "1. <I really hate losing, you know.>"
    new "1. <De verdad odio perder, ¿sabes?>"

    # game/beyond the bet/day8dlc.rpy:278
    old "1. <Except to me <3>"
    new "1. <Excepto conmigo <3>"

    # game/beyond the bet/day8dlc.rpy:283
    old "1. <Alright, let's see then.>"
    new "1. <Bien, veamos entonces.>"

    # game/beyond the bet/day8dlc.rpy:286
    old "1. <Rock paper scissors?>"
    new "1. <¿Piedra, papel o tijera?>"

    # game/beyond the bet/day8dlc.rpy:290
    old "1. <And for the Grim Reaper and his favorite Sunshine.>"
    new "1. <Y para la Parca y su Solecito favorito.>"

    # game/beyond the bet/day8dlc.rpy:293
    old "1. <Ready?>"
    new "1. <¿Listo?>"

    # game/beyond the bet/day8dlc.rpy:296
    old "1. <3...>"
    new "1. <3...>"

    # game/beyond the bet/day8dlc.rpy:299
    old "1. <2...>"
    new "1. <2...>"

    # game/beyond the bet/day8dlc.rpy:302
    old "1. <1...>"
    new "1. <1...>"

    # game/beyond the bet/day8dlc.rpy:305
    old "1. <GO!>"
    new "1. <¡YA!>"

    # game/beyond the bet/day8dlc.rpy:309
    old "1. <Rock>"
    new "1. <Piedra>"

    # game/beyond the bet/day8dlc.rpy:316
    old "1. <You don't really have any choice.>"
    new "1. <En realidad no tienes opción.>"

    # game/beyond the bet/day8dlc.rpy:319
    old "1. <No rematches.>"
    new "1. <Sin revancha.>"

    # game/beyond the bet/day8dlc.rpy:326
    old "1. <Because... because of rock paper scissors...?>"
    new "1. <¿Porque... por piedra, papel o tijera...?>"

    # game/beyond the bet/day8dlc.rpy:330
    old "1. <You sound stupid as flip again today.>"
    new "1. <Hoy otra vez hablas como un tonto de remate.>"

    # game/beyond the bet/day8dlc.rpy:333
    old "1. <You must be feeling better.>"
    new "1. <Debes de estar sintiéndote mejor.>"

    # game/beyond the bet/day8dlc.rpy:337
    old "2. <Paper>"
    new "2. <Papel>"

    # game/beyond the bet/day8dlc.rpy:344
    old "1. <You saying I'm a cheater?>"
    new "1. <¿Estás diciendo que hice trampa?>"

    # game/beyond the bet/day8dlc.rpy:349
    old "1. <You're just saying that cause I won.>"
    new "1. <Solo lo dices porque gané.>"

    # game/beyond the bet/day8dlc.rpy:352
    old "1. <How about this...>"
    new "1. <¿Qué tal esto...?>"

    # game/beyond the bet/day8dlc.rpy:355
    old "1. <Rematch in person?>"
    new "1. <¿Revancha en persona?>"

    # game/beyond the bet/day8dlc.rpy:360
    old "1. <I'll have you know, I am a rock paper scissors world champion.>"
    new "1. <Que sepas que he ganado el campeonato mundial de piedra, papel o tijera.>"

    # game/beyond the bet/day8dlc.rpy:367
    old "1. <Or I might not be.>"
    new "1. <O puede que no.>"

    # game/beyond the bet/day8dlc.rpy:370
    old "1. <Or... maybe I'm both!>"
    new "1. <O... ¡quizás ambas cosas!>"

    # game/beyond the bet/day8dlc.rpy:373
    old "1. <I'm like, Schrödinger's rock paper scissors champion.>"
    new "1. <Soy como el gato de Schrödinger, pero de piedra, papel o tijera.>"

    # game/beyond the bet/day8dlc.rpy:378
    old "2. <I'll go easy on you next time.>"
    new "2. <La próxima vez voy a ir más suave contigo.>"

    # game/beyond the bet/day8dlc.rpy:383
    old "1. <You can try ;D>"
    new "1. <Puedes intentarlo ;D>"

    # game/beyond the bet/day8dlc.rpy:388
    old "1. <You like it.>"
    new "1. <Te gusta.>"

    # game/beyond the bet/day8dlc.rpy:391
    old "1. <Honestly, you talk way more.>"
    new "1. <Sinceramente, tú hablas mucho más.>"

    # game/beyond the bet/day8dlc.rpy:394
    old "1. <You loooove the sound of your own voice.>"
    new "1. <Te encaaanta el sonido de tu propia voz.>"

    # game/beyond the bet/day8dlc.rpy:402
    old "1. <Though it did sound a little funny yesterday.>"
    new "1. <Aunque ayer sonaba un poco gracioso.>"

    # game/beyond the bet/day8dlc.rpy:408
    old "1. <Okay, okay, I'm sorry.>"
    new "1. <Okey, okey, lo siento.>"

    # game/beyond the bet/day8dlc.rpy:411
    old "1. <Are you feeling better yet?>"
    new "1. <¿Ya te sientes mejor?>"

    # game/beyond the bet/day8dlc.rpy:415
    old "3. <Scissors>"
    new "3. <Tijera>"

    # game/beyond the bet/day8dlc.rpy:421
    old "1. <Okay no need to gloat.>"
    new "1. <Okey, no hace falta presumir.>"

    # game/beyond the bet/day8dlc.rpy:427
    old "1. <A mortal with superpowers...>"
    new "1. <[arti_2!c] mortal con superpoderes...>"

    # game/beyond the bet/day8dlc.rpy:432
    old "1. <O, great lord of rock-paper-scissors, your radiance astounds me!>"
    new "1. <Oh, gran señor de piedra, papel o tijera, ¡tu resplandor me asombra!>"

    # game/beyond the bet/day8dlc.rpy:436
    old "1. <You are wonderful, and just, and so deserving of this win!>"
    new "1. <¡Eres maravilloso, justo y muy merecedor de esta victoria!>"

    # game/beyond the bet/day8dlc.rpy:440
    old "1. <You're also kinda cute.>"
    new "1. <También eres medio lindo.>"

    # game/beyond the bet/day8dlc.rpy:445
    old "1. <I thought you'd argue again.>"
    new "1. <Pensé que volverías a discutir.>"

    # game/beyond the bet/day8dlc.rpy:448
    old "1. <'I'm not cute! I'm sexy! Handsome! Gorgeous!'>"
    new "1. <'¡No soy lindo! ¡Soy sexy! ¡Guapo! ¡Precioso!'>"

    # game/beyond the bet/day8dlc.rpy:453
    old "1. <Well, you ARE cute.>"
    new "1. <Pues sí que ERES lindo.>"

    # game/beyond the bet/day8dlc.rpy:462
    old "2. <Maybe you cheated.>"
    new "2. <Quizás hiciste trampa.>"

    # game/beyond the bet/day8dlc.rpy:467
    old "1. <Maybe you're secretly a time traveller.>"
    new "1. <Quizás eres un viajero del tiempo en secreto.>"

    # game/beyond the bet/day8dlc.rpy:474
    old "1. <You're petty like that.>"
    new "1. <Eres así de infantil.>"

    # game/beyond the bet/day8dlc.rpy:478
    old "1. <You kind of are.>"
    new "1. <Un poco sí.>"

    # game/beyond the bet/day8dlc.rpy:481
    old "1. <You seem like the kind of guy who would abuse time travel for trivial things...>"
    new "1. <Pareces el tipo de chico que abusaría de los viajes en el tiempo para cosas triviales...>"

    # game/beyond the bet/day8dlc.rpy:485
    old "1. <Then destroy the universe in the process.>"
    new "1. <Y de paso destruiría el universo.>"

    # game/beyond the bet/day8dlc.rpy:496
    old "1. <Very humble of you, Grim.>"
    new "1. <Muy humilde de tu parte, Parca.>"

    # game/beyond the bet/day8dlc.rpy:502
    old "2. <Maybe you used our little mind soul connection bridge!>"
    new "2. <¡Quizás usaste nuestro puentecito de conexión mental y de almas!>"

    # game/beyond the bet/day8dlc.rpy:505
    old "1. <Had a little spy on what I was thinking.>"
    new "1. <¡Espiaste un poco lo que pensaba!>"

    # game/beyond the bet/day8dlc.rpy:510
    old "1. <Hmmmm.>"
    new "1. <Mmmm.>"

    # game/beyond the bet/day8dlc.rpy:516
    old "1. <In a good way, right?>"
    new "1. <En el buen sentido, ¿verdad?>"

    # game/beyond the bet/day8dlc.rpy:519
    old "1. <My thoughts are lovely, what are you talking about?>"
    new "1. <Mis pensamientos son encantadores, ¿de qué hablas?>"

    # game/beyond the bet/day8dlc.rpy:523
    old "1. <Fine fine.>"
    new "1. <Bueno, bueno.>"

    # game/beyond the bet/day8dlc.rpy:526
    old "1. <Since you can't read my mind, I'll have to ask outright. Are you feeling better?>"
    new "1. <Ya que no puedes leerme la mente, tendré que preguntarte directamente. ¿Te sientes mejor?>"

    # game/beyond the bet/day8dlc.rpy:529
    old "2. <Ohoho. Imagine what it'd feel like in the bedroom with our connection.>"
    new "2. <Ohoho. Imagina cómo sería en la cama con nuestra conexión.>"

    # game/beyond the bet/day8dlc.rpy:533
    old "1. <Don't you think that sounds amazing?>"
    new "1. <¿No crees que suena increíble?>"

    # game/beyond the bet/day8dlc.rpy:535
    old "2. <Would it be, like, amplified?>"
    new "2. <¿Sería, como, amplificado?>"

    # game/beyond the bet/day8dlc.rpy:546
    old "1. <We won't know unless we try, will we?>"
    new "1. <No lo sabremos si no lo intentamos, ¿verdad?>"

    # game/beyond the bet/day8dlc.rpy:549
    old "1. <But, in the mean time...>"
    new "1. <Pero, mientras tanto...>"

    # game/beyond the bet/day8dlc.rpy:552
    old "1. <How are you feeling?>"
    new "1. <¿Cómo te sientes?>"

    # game/beyond the bet/day8dlc.rpy:555
    old "1. <A bit better, I assume?>"
    new "1. <¿Un poco mejor, supongo?>"

    # game/beyond the bet/day8dlc.rpy:559
    old "2. <I kinda wanna keep it.>"
    new "2. <La verdad es que me gustaría quedármela.>"

    # game/beyond the bet/day8dlc.rpy:564
    old "1. <Not everyone believes in them, you know.>"
    new "1. <No todos creen en ellas, ¿sabes?>"

    # game/beyond the bet/day8dlc.rpy:567
    old "1. <In fact, it's hotly debated what actually happens after you die.>"
    new "1. <De hecho, lo que pasa realmente después de morir es muy debatido.>"

    # game/beyond the bet/day8dlc.rpy:571
    old "1. <No!>"
    new "1. <¡No!>"

    # game/beyond the bet/day8dlc.rpy:573
    old "2. <How would it be obvious...>"
    new "2. <¿Cómo va a ser obvio...?>"

    # game/beyond the bet/day8dlc.rpy:578
    old "1. <Like?>"
    new "1. <¿Como qué?>"

    # game/beyond the bet/day8dlc.rpy:583
    old "1. <I thought you were gonna say fixing the housing crisis, or curing \ndiseases, or global warming...>"
    new "1. <Pensé que ibas a decir arreglar la crisis de la vivienda, curar enfermedades o frenar el calentamiento global...>"

    # game/beyond the bet/day8dlc.rpy:587
    old "1. <You have your priorities. I respect that.>"
    new "1. <Tienes tus prioridades. Lo respeto.>"

    # game/beyond the bet/day8dlc.rpy:590
    old "1. <But you never answered.>"
    new "1. <Pero nunca respondiste.>"

    # game/beyond the bet/day8dlc.rpy:596
    old "2. <How is what happens after you die unimportant?>"
    new "2. <¿Cómo puede no importar lo que pasa después de morir?>"

    # game/beyond the bet/day8dlc.rpy:609
    old "1. <Not keen on getting sick again anytime soon?>"
    new "1. <¿No te gustaría volver a enfermarte pronto?>"

    # game/beyond the bet/day8dlc.rpy:615
    old "1. <You touched me!>"
    new "1. <¡Me tocaste!>"

    # game/beyond the bet/day8dlc.rpy:618
    old "1. <I bet you enjoyed that.>"
    new "1. <Seguro que lo disfrutaste.>"

    # game/beyond the bet/day8dlc.rpy:626
    old "1. <Then why don't you?>"
    new "1. <¿Entonces por qué no lo haces?>"

    # game/beyond the bet/day8dlc.rpy:629
    old "2. <Be my guest.>"
    new "2. <Adelante.>"

    # game/beyond the bet/day8dlc.rpy:633
    old "1. <Pretend it is for a second.>"
    new "1. <Finge que lo es por un segundo.>"

    # game/beyond the bet/day8dlc.rpy:636
    old "1. <What would you do?>"
    new "1. <¿Qué harías?>"

    # game/beyond the bet/day8dlc.rpy:640
    old "1. <Then call yourself a fool and play along.>"
    new "1. <Pues llámate necio y sigue el juego.>"

    # game/beyond the bet/day8dlc.rpy:645
    old "1. <Holding hands? Scandalous, Casper.>"
    new "1. <¿Tomarse de las manos? Escandaloso, Casper.>"

    # game/beyond the bet/day8dlc.rpy:652
    old "1. <I think you're the only one putting that restriction on yourself.>"
    new "1. <Creo que eres el único que se impone esa restricción.>"

    # game/beyond the bet/day8dlc.rpy:655
    old "1. <I'm Sunshine, right?>"
    new "1. <Soy Solecito, ¿no?>"

    # game/beyond the bet/day8dlc.rpy:658
    old "1. <Of course I'm gonna get ya with my warmth every now and then.>"
    new "1. <Claro que de vez en cuando te voy a agarrar desprevenido con mi calidez.>"

    # game/beyond the bet/day8dlc.rpy:660
    old "2. <That's what I do. Warm you up.>"
    new "2. <Es lo que hago. Calentarte.>"

    # game/beyond the bet/day8dlc.rpy:667
    old "2. <We got to comfort each other!>"
    new "2. <¡Nos consolamos el uno al otro!>"

    # game/beyond the bet/day8dlc.rpy:671
    old "1. <I would!>"
    new "1. <¡Yo sí lo diría!>"

    # game/beyond the bet/day8dlc.rpy:673
    old "2. <Then you'd be wrong.>"
    new "2. <Entonces estarías equivocado.>"

    # game/beyond the bet/day8dlc.rpy:676
    old "1. <Mister Wrong Reaper.>"
    new "1. <Señor Parca Equivocado.>"

    # game/beyond the bet/day8dlc.rpy:679
    old "1. <You made me dinner.>"
    new "1. <Me hiciste la cena.>"

    # game/beyond the bet/day8dlc.rpy:682
    old "1. <I let you sleep beside me in bed.>"
    new "1. <Te dejé dormir a mi lado en la cama.>"

    # game/beyond the bet/day8dlc.rpy:685
    old "1. <I'd say that's both of us comforted.>"
    new "1. <Diría que nos consolamos los dos.>"

    # game/beyond the bet/day8dlc.rpy:691
    old "1. <I loved it.>"
    new "1. <Me encantó.>"

    # game/beyond the bet/day8dlc.rpy:694
    old "1. <It felt nice.>"
    new "1. <Se sintió bien.>"

    # game/beyond the bet/day8dlc.rpy:697
    old "1. <You know, to have someone there when I'm sick.>"
    new "1. <Ya sabes, tener a alguien ahí cuando uno está enfermo.>"

    # game/beyond the bet/day8dlc.rpy:700
    old "1. <I only wish I could've done the same for you.>"
    new "1. <Solo desearía haber podido hacer lo mismo por ti.>"

    # game/beyond the bet/day8dlc.rpy:706
    old "2. <You're always welcome, Casper.>"
    new "2. <Siempre eres bienvenido, Casper.>"

    # game/beyond the bet/day8dlc.rpy:711
    old "1. <It IS an invitation.>"
    new "1. <ES una invitación.>"

    # game/beyond the bet/day8dlc.rpy:714
    old "1. <Come on over, big boy.>"
    new "1. <Ven, grandulón.>"

    # game/beyond the bet/day8dlc.rpy:717
    old "1. <Whenever you want ;D>"
    new "1. <Cuando quieras ;D>"

    # game/beyond the bet/day8dlc.rpy:721
    old "3. <You got to lay in my bed ;)>"
    new "3. <Pudiste acostarte en mi cama ;)>"

    # game/beyond the bet/day8dlc.rpy:724
    old "1. <It's pretty comfy, don't you think?>"
    new "1. <Es bastante cómoda, ¿no crees?>"

    # game/beyond the bet/day8dlc.rpy:728
    old "1. <Oh, were you uncomfortable?>"
    new "1. <Ah, ¿estabas incómodo?>"

    # game/beyond the bet/day8dlc.rpy:733
    old "1. <My... bed?>"
    new "1. <¿Mi... cama?>"

    # game/beyond the bet/day8dlc.rpy:738
    old "1. <Oh. Sorry.>"
    new "1. <Ah. Perdón.>"

    # game/beyond the bet/day8dlc.rpy:741
    old "1. <I didn't know you wouldn't like it.>"
    new "1. <No sabía que no te gustaría.>"

    # game/beyond the bet/day8dlc.rpy:750
    old "1. <OH!>"
    new "1. <¡OH!>"

    # game/beyond the bet/day8dlc.rpy:753
    old "1. <So you actually liked it.>"
    new "1. <O sea que sí te gustó.>"

    # game/beyond the bet/day8dlc.rpy:757
    old "1. <Awww, little Casper liked sleeping next to me <3>"
    new "1. <Awww, al pequeño Casper le gustó dormir a mi lado <3>"

    # game/beyond the bet/day8dlc.rpy:760
    old "1. <You're a cutie.>"
    new "1. <Eres un encanto.>"

    # game/beyond the bet/day8dlc.rpy:764
    old "4. <You got to experience something new?>"
    new "4. <¿Pudiste vivir algo nuevo?>"

    # game/beyond the bet/day8dlc.rpy:774
    old "1. <You can't leave me hanging!>"
    new "1. <¡No puedes dejarme con la duda!>"

    # game/beyond the bet/day8dlc.rpy:776
    old "2. <Casper...>"
    new "2. <Casper...>"

    # game/beyond the bet/day8dlc.rpy:780
    old "1. <Go on...>"
    new "1. <Continúa...>"

    # game/beyond the bet/day8dlc.rpy:788
    old "1. <Phew...>"
    new "1. <Uf...>"

    # game/beyond the bet/day8dlc.rpy:790
    old "2. <You made me think it was something bad!>"
    new "2. <¡Me hiciste pensar que era algo malo!>"

    # game/beyond the bet/day8dlc.rpy:793
    old "1. <I don't mind you watching me.>"
    new "1. <No me molesta que me mires.>"

    # game/beyond the bet/day8dlc.rpy:796
    old "1. <It's kinda what you do, right?>"
    new "1. <Es como lo tuyo, ¿no?>"

    # game/beyond the bet/day8dlc.rpy:805
    old "1. <That's unlike you.>"
    new "1. <Eso no es propio de ti.>"

    # game/beyond the bet/day8dlc.rpy:808
    old "1. <You're the most confident person I know.>"
    new "1. <Eres la persona más segura de sí misma que conozco.>"

    # game/beyond the bet/day8dlc.rpy:811
    old "1. <Er, reaper.>"
    new "1. <Digo, parca.>"

    # game/beyond the bet/day8dlc.rpy:820
    old "1. <Birthdays?>"
    new "1. <¿Cumpleaños?>"

    # game/beyond the bet/day8dlc.rpy:823
    old "1. <That is 'the day of one's birth', Casper.>"
    new "1. <Es 'el día del nacimiento de alguien', Casper.>"

    # game/beyond the bet/day8dlc.rpy:828
    old "1. <I think we can both have that title.>"
    new "1. <Creo que los dos podemos tener ese título.>"

    # game/beyond the bet/day8dlc.rpy:833
    old "2. <They're fun!>"
    new "2. <¡Son divertidos!>"

    # game/beyond the bet/day8dlc.rpy:836
    old "1. <I guess it depends on your age, but...>"
    new "1. <Supongo que depende de tu edad, pero...>"

    # game/beyond the bet/day8dlc.rpy:839
    old "1. <You get some presents, eat some cake, and have fun with your friends.>"
    new "1. <Recibes regalos, comes pastel y te diviertes con tus amigos.>"

    # game/beyond the bet/day8dlc.rpy:842
    old "1. <I love birthdays.>"
    new "1. <Me encantan los cumpleaños.>"

    # game/beyond the bet/day8dlc.rpy:845
    old "3. <They're a time to celebrate.>"
    new "3. <Son un momento para celebrar.>"

    # game/beyond the bet/day8dlc.rpy:848
    old "1. <You lived another whole year.>"
    new "1. <Viviste un año más.>"

    # game/beyond the bet/day8dlc.rpy:851
    old "1. <The best way to celebrate, of course, is to stuff your face with cake.>"
    new "1. <La mejor forma de celebrar, claro, es comer pastel hasta reventar.>"

    # game/beyond the bet/day8dlc.rpy:854
    old "1. <Until you're so sick you can't walk.>"
    new "1. <Hasta que te sientas tan mal que no puedas caminar.>"

    # game/beyond the bet/day8dlc.rpy:857
    old "4. <I've never really done much on my birthday.>"
    new "4. <Nunca he hecho mucho en mi cumpleaños.>"

    # game/beyond the bet/day8dlc.rpy:860
    old "1. <It's always been kind of lowkey.>"
    new "1. <Siempre ha sido algo tranquilo.>"

    # game/beyond the bet/day8dlc.rpy:863
    old "1. <I like it like that, though.>"
    new "1. <Aunque así me gusta.>"

    # game/beyond the bet/day8dlc.rpy:865
    old "2. <I wish I celebrated it more.>"
    new "2. <Ojalá lo celebrara más.>"

    # game/beyond the bet/day8dlc.rpy:876
    old "1. <Maybe not the live sacrifices thing.>"
    new "1. <Quizás lo de los sacrificios en vivo no.>"

    # game/beyond the bet/day8dlc.rpy:879
    old "1. <At least, the last party I went to at McDougals didn't have any...>"
    new "1. <Al menos, en la última fiesta a la que fui en McDougals no había ninguno...>"

    # game/beyond the bet/day8dlc.rpy:882
    old "1. <I'm starting to feel like I'm missing out.>"
    new "1. <Estoy empezando a sentir que me estoy perdiendo de algo.>"

    # game/beyond the bet/day8dlc.rpy:887
    old "1. <You think I should start offering children's birthday party live sacrifices?>"
    new "1. <¿Crees que debería empezar a ofrecer sacrificios en vivo en fiestas infantiles de cumpleaños?>"

    # game/beyond the bet/day8dlc.rpy:891
    old "1. <Noted, I'll start considering it.>"
    new "1. <Anotado, empezaré a considerarlo.>"

    # game/beyond the bet/day8dlc.rpy:893
    old "2. <I think I'll pass this time.>"
    new "2. <Creo que esta vez paso.>"

    # game/beyond the bet/day8dlc.rpy:896
    old "2. <If my boss ever caught wind of it...>"
    new "2. <Si mi jefe llegara a enterarse...>"

    # game/beyond the bet/day8dlc.rpy:899
    old "1. <I think I'd never be allowed to teach children ever again.>"
    new "1. <Creo que nunca más me dejarían dar clases a niños.>"

    # game/beyond the bet/day8dlc.rpy:905
    old "1. <You can't just call children vermin 😭>"
    new "1. <No puedes simplemente llamar alimañas a los niños 😭>"

    # game/beyond the bet/day8dlc.rpy:909
    old "1. <I'd like to remind you, I quite like my job!!!>"
    new "1. <¡¡¡Te recuerdo que me gusta bastante mi trabajo!!!>"

    # game/beyond the bet/day8dlc.rpy:913
    old "2. <I might have to pass for now, but thanks...>"
    new "2. <Quizá por ahora tenga que decir que no, pero gracias...>"

    # game/beyond the bet/day8dlc.rpy:916
    old "2. <Yeah, there's loads of live sacrifices.>"
    new "2. <Sí, hay montones de sacrificios en vivo.>"

    # game/beyond the bet/day8dlc.rpy:919
    old "1. <Huge birthday issue. Too many sacrifices.>"
    new "1. <Un enorme problema de cumpleaños. Demasiados sacrificios.>"

    # game/beyond the bet/day8dlc.rpy:923
    old "1. <Definitely.>"
    new "1. <Definitivamente.>"

    # game/beyond the bet/day8dlc.rpy:926
    old "2. <No, I'm pulling your leg again.>"
    new "2. <No, te estoy tomando el pelo otra vez.>"

    # game/beyond the bet/day8dlc.rpy:931
    old "1. <Feasts, though...>"
    new "1. <Los banquetes, en cambio...>"

    # game/beyond the bet/day8dlc.rpy:934
    old "1. <Yeah, in a way those are pretty common.>"
    new "1. <Sí, en cierto modo esos son bastante comunes.>"

    # game/beyond the bet/day8dlc.rpy:937
    old "1. <Like, going out to a restaurant on your birthday.>"
    new "1. <Como ir a un restaurante en tu cumpleaños.>"

    # game/beyond the bet/day8dlc.rpy:941
    old "1. <Some people suck at cooking.>"
    new "1. <Algunas personas cocinan fatal.>"

    # game/beyond the bet/day8dlc.rpy:944
    old "1. <They'll sit at home eating cup noodles all day...>"
    new "1. <Se quedan en casa comiendo fideos instantáneos todo el día...>"

    # game/beyond the bet/day8dlc.rpy:947
    old "1. <And never eat a good meal.>"
    new "1. <Y nunca comen una buena comida.>"

    # game/beyond the bet/day8dlc.rpy:950
    old "1. <So going out somewhere is nice.>"
    new "1. <Así que salir a algún lado está bien.>"

    # game/beyond the bet/day8dlc.rpy:955
    old "1. <They're tasty, but...>"
    new "1. <Son ricos, pero...>"

    # game/beyond the bet/day8dlc.rpy:957
    old "2. <They're not super nutritional.>"
    new "2. <No son muy nutritivos.>"

    # game/beyond the bet/day8dlc.rpy:960
    old "1. <If that's all you eat, that can't be good for you.>"
    new "1. <Si es lo único que comes, no puede ser bueno para ti.>"

    # game/beyond the bet/day8dlc.rpy:965
    old "1. <Imagine the even PEAKER physical form you COULD be in, then.>"
    new "1. <Imagina la forma física AÚN MÁS ÓPTIMA en la que PODRÍAS estar, entonces.>"

    # game/beyond the bet/day8dlc.rpy:971
    old "1. <tbh neither can I.>"
    new "1. <la verdad, yo tampoco.>"

    # game/beyond the bet/day8dlc.rpy:975
    old "1. <Keep admirin' me then, Grimmy.>"
    new "1. <Entonces sigue admirándome, Parquita.>"

    # game/beyond the bet/day8dlc.rpy:978
    old "1. <I don't mind being honest about your looks.>"
    new "1. <No tengo problema en decir la verdad sobre tu aspecto.>"

    # game/beyond the bet/day8dlc.rpy:981
    old "2. <Trust in the vegetables, Grim.>"
    new "2. <Confía en las verduras, Parca.>"

    # game/beyond the bet/day8dlc.rpy:985
    old "1. <Trust in the FRESH vegetables, Grim.>"
    new "1. <Confía en las verduras FRESCAS, Parca.>"

    # game/beyond the bet/day8dlc.rpy:989
    old "2. <The atmosphere of restaurants makes it enjoyable.>"
    new "2. <El ambiente de los restaurantes lo hace agradable.>"

    # game/beyond the bet/day8dlc.rpy:992
    old "1. <The lights, the company, sometimes there's live music...>"
    new "1. <Las luces, la compañía, a veces hay música en vivo...>"

    # game/beyond the bet/day8dlc.rpy:995
    old "1. <It's a different experience than sitting at home to eat.>"
    new "1. <Es una experiencia diferente a comer en casa.>"

    # game/beyond the bet/day8dlc.rpy:999
    old "1. <All the time!>"
    new "1. <¡Todo el tiempo!>"

    # game/beyond the bet/day8dlc.rpy:1003
    old "1. <Why, you jealous?>"
    new "1. <¿Por qué, estás celoso?>"

    # game/beyond the bet/day8dlc.rpy:1012
    old "1. <To be honest, I usually go by myself lol.>"
    new "1. <A decir verdad, normalmente voy por mi cuenta jaja.>"

    # game/beyond the bet/day8dlc.rpy:1015
    old "1. <I'm the best company anyone could have, after all B)>"
    new "1. <Soy la mejor compañía que alguien podría tener, después de todo B)>"

    # game/beyond the bet/day8dlc.rpy:1019
    old "1. <Eh, not that much.>"
    new "1. <Eh, no mucho.>"

    # game/beyond the bet/day8dlc.rpy:1021
    old "2. <Not really.>"
    new "2. <La verdad es que no.>"

    # game/beyond the bet/day8dlc.rpy:1024
    old "1. <But that's alright.>"
    new "1. <Pero está bien.>"

    # game/beyond the bet/day8dlc.rpy:1026
    old "2. <Their loss!>"
    new "2. <¡Ellos se lo pierden!>"

    # game/beyond the bet/day8dlc.rpy:1033
    old "1. <Then start asking me, Grimmy.>"
    new "1. <Entonces empieza a invitarme, Parquita.>"

    # game/beyond the bet/day8dlc.rpy:1037
    old "2. <Oh, you'd be mega popular.>"
    new "2. <Oh, serías megapopular.>"

    # game/beyond the bet/day8dlc.rpy:1040
    old "1. <Red eyes, long eyelashes, long hair, great bod...>"
    new "1. <Ojos rojos, pestañas largas, cabello largo, gran cuerpazo...>"

    # game/beyond the bet/day8dlc.rpy:1043
    old "1. <Yeah, you'd never want for a date.>"
    new "1. <Sí, nunca te faltarían citas.>"

    # game/beyond the bet/day8dlc.rpy:1047
    old "1. <Why? Am I the only one for you?>"
    new "1. <¿Por qué? ¿Soy [arti] únic[letra] para ti?>"

    # game/beyond the bet/day8dlc.rpy:1053
    old "1. <What about me?>"
    new "1. <¿Qué hay de mí?>"

    # game/beyond the bet/day8dlc.rpy:1058
    old "2. <Rarely, unfortunately...>"
    new "2. <Pocas veces, por desgracia...>"

    # game/beyond the bet/day8dlc.rpy:1061
    old "1. <I don't go out to eat nearly as much as I'd like to.>"
    new "1. <No salgo a comer ni de cerca tanto como me gustaría.>"

    # game/beyond the bet/day8dlc.rpy:1068
    old "1. <It depends who's asking.>"
    new "1. <Depende de quién lo pida.>"

    # game/beyond the bet/day8dlc.rpy:1072
    old "1. <If you say pretty please.>"
    new "1. <Si dices porfis.>"

    # game/beyond the bet/day8dlc.rpy:1076
    old "1. <Pretty pretty please.>"
    new "1. <Porfis, porfis.>"

    # game/beyond the bet/day8dlc.rpy:1081
    old "1. <With sugar on top.>"
    new "1. <Con un poquito de azúcar.>"

    # game/beyond the bet/day8dlc.rpy:1086
    old "1. <Like this: pretty please with sugar on top?>"
    new "1. <Así: ¿porfis, con un poquito de azúcar?>"

    # game/beyond the bet/day8dlc.rpy:1090
    old "1. <I gotta hear you say that later.>"
    new "1. <Tengo que oírte decir eso después.>"

    # game/beyond the bet/day8dlc.rpy:1094
    old "1. <I will use my power wisely (I won't).>"
    new "1. <Usaré mi poder con sabiduría (mentira).>"

    # game/beyond the bet/day8dlc.rpy:1097
    old "1. <Then, yes. I would like to go to dinner with you sometime, Casper.>"
    new "1. <Entonces, sí. Me gustaría ir a cenar contigo algún día, Casper.>"

    # game/beyond the bet/day8dlc.rpy:1100
    old "1. <It's a date.>"
    new "1. <Es una cita.>"

    # game/beyond the bet/day8dlc.rpy:1112
    old "1. <If I had to pick anything...>"
    new "1. <Si tuviera que elegir algo...>"

    # game/beyond the bet/day8dlc.rpy:1115
    old "1. <I'd go on a fancy overseas vacation!>"
    new "1. <¡Me iría de vacaciones de lujo al extranjero!>"

    # game/beyond the bet/day8dlc.rpy:1118
    old "1. <Maybe somewhere tropical...>"
    new "1. <Tal vez a algún lugar tropical...>"

    # game/beyond the bet/day8dlc.rpy:1121
    old "1. <Or a big city!>"
    new "1. <¡O a una ciudad grande!>"

    # game/beyond the bet/day8dlc.rpy:1124
    old "1. <Or the countryside...>"
    new "1. <O el campo...>"

    # game/beyond the bet/day8dlc.rpy:1128
    old "1. <But they all sound so good...>"
    new "1. <Pero todos suenan tan bien...>"

    # game/beyond the bet/day8dlc.rpy:1131
    old "1. <Maybe a trip all around the world!>"
    new "1. <¡Tal vez un viaje alrededor del mundo!>"

    # game/beyond the bet/day8dlc.rpy:1135
    old "1. <Right on both counts.>"
    new "1. <Tienes razón en ambas cosas.>"

    # game/beyond the bet/day8dlc.rpy:1138
    old "1. <But fun, too.>"
    new "1. <Pero también divertido.>"

    # game/beyond the bet/day8dlc.rpy:1141
    old "1. <But also quite unrealistic for a birthday.>"
    new "1. <Pero también bastante poco realista para un cumpleaños.>"

    # game/beyond the bet/day8dlc.rpy:1144
    old "1. <A [girl] can dream...>"
    new "1. <Soñar no cuesta nada...>"

    # game/beyond the bet/day8dlc.rpy:1148
    old "2. <I'd stay at home and play games alllll day.>"
    new "2. <Me quedaría en casa jugando todo el día.>"

    # game/beyond the bet/day8dlc.rpy:1155
    old "1. <I also get to stuff my face with cake.>"
    new "1. <También puedo comer pastel hasta reventar.>"

    # game/beyond the bet/day8dlc.rpy:1159
    old "1. <You get it!>"
    new "1. <¡Eso es!>"

    # game/beyond the bet/day8dlc.rpy:1163
    old "3. <I'd go and see a movie.>"
    new "3. <Iría a ver una película.>"

    # game/beyond the bet/day8dlc.rpy:1166
    old "1. <I mean, I could do that whenever, I guess...>"
    new "1. <O sea, podría hacerlo en cualquier momento, supongo...>"

    # game/beyond the bet/day8dlc.rpy:1169
    old "1. <But there's something nice about doing it on your birthday.>"
    new "1. <Pero hay algo especial en hacerlo el día de tu cumpleaños.>"

    # game/beyond the bet/day8dlc.rpy:1172
    old "1. <Buying the overpriced popcorn...>"
    new "1. <Comprar las palomitas carísimas...>"

    # game/beyond the bet/day8dlc.rpy:1175
    old "1. <Watching the stupid ads and trailers.>"
    new "1. <Ver los anuncios y trailers tontos.>"

    # game/beyond the bet/day8dlc.rpy:1178
    old "1. <It's fun.>"
    new "1. <Es divertido.>"

    # game/beyond the bet/day8dlc.rpy:1186
    old "1. <We have to go!>"
    new "1. <¡Tenemos que ir!>"

    # game/beyond the bet/day8dlc.rpy:1189
    old "1. <I'll get to be your first!>"
    new "1. <¡Voy a ser tu primer[letra]!>"

    # game/beyond the bet/day8dlc.rpy:1193
    old "1. <First person to see a movie with you!>"
    new "1. <¡[arti!c] primer[letra] en ir al cine contigo!>"

    # game/beyond the bet/day8dlc.rpy:1207
    old "4. <It doesn't matter, as long as I spend it with someone I love.>"
    new "4. <No importa, mientras lo pase con alguien a quien quiero.>"

    # game/beyond the bet/day8dlc.rpy:1211
    old "1. <We could be doing anything and I'll be having a great time.>"
    new "1. <Podríamos estar haciendo cualquier cosa y lo pasaré genial.>"

    # game/beyond the bet/day8dlc.rpy:1218
    old "1. <There's a certain Grim Reaper...>"
    new "1. <Hay cierta Parca...>"

    # game/beyond the bet/day8dlc.rpy:1221
    old "1. <He's a bit of an edgelord, but he's kinda cute too...>"
    new "1. <Es un poco edgy, pero también tiene su encanto...>"

    # game/beyond the bet/day8dlc.rpy:1225
    old "1. <Handsome face, terrible attitude.>"
    new "1. <Cara guapa, actitud terrible.>"

    # game/beyond the bet/day8dlc.rpy:1229
    old "1. <Long white hair, red eyes.>"
    new "1. <Cabello largo y blanco, ojos rojos.>"

    # game/beyond the bet/day8dlc.rpy:1235
    old "1. <What if I told you I was talking about my new neighbor?>"
    new "1. <¿Y si te dijera que hablaba de mi nuevo vecino?>"

    # game/beyond the bet/day8dlc.rpy:1240
    old "1. <You're alright.>"
    new "1. <No estás nada mal.>"

    # game/beyond the bet/day8dlc.rpy:1244
    old "2. <I really did mean my new neighbor.>"
    new "2. <De verdad me refería a mi nuevo vecino.>"

    # game/beyond the bet/day8dlc.rpy:1248
    old "3. <You're the cutest, Grimmy <3>"
    new "3. <Eres lo más lindo, Parquita <3>"

    # game/beyond the bet/day8dlc.rpy:1251
    old "1. <You are THE babygirl.>"
    new "1. <Eres LA babygirl.>"

    # game/beyond the bet/day8dlc.rpy:1254
    old "1. <And my favorite one, too.>"
    new "1. <Y también mi favorito.>"

    # game/beyond the bet/day8dlc.rpy:1261
    old "1. <No <3>"
    new "1. <No <3>"

    # game/beyond the bet/day8dlc.rpy:1267
    old "2. <His name is... Jeremy.>"
    new "2. <Se llama... Jeremy.>"

    # game/beyond the bet/day8dlc.rpy:1272
    old "1. <Jeremy would never talk so crudely, you know.>"
    new "1. <Jeremy nunca hablaría de una forma tan vulgar, ¿sabes?>"

    # game/beyond the bet/day8dlc.rpy:1277
    old "1. <What would that be?>"
    new "1. <¿Cuál sería?>"

    # game/beyond the bet/day8dlc.rpy:1281
    old "1. <Ouch, that hurts.>"
    new "1. <Auch, eso duele.>"

    # game/beyond the bet/day8dlc.rpy:1284
    old "1. <You're a cruel man, Grimmy.>"
    new "1. <Eres cruel, Parquita.>"

    # game/beyond the bet/day8dlc.rpy:1287
    old "1. <btw I was just kidding.>"
    new "1. <Por cierto, solo bromeaba.>"

    # game/beyond the bet/day8dlc.rpy:1290
    old "1. <I mean you, of course.>"
    new "1. <Me refería a ti, claro.>"

    # game/beyond the bet/day8dlc.rpy:1293
    old "1. <<3>"
    new "1. <<3>"

    # game/beyond the bet/day8dlc.rpy:1307
    old "1. <But I LIKE lying.>"
    new "1. <Pero me GUSTA mentir.>"

    # game/beyond the bet/day8dlc.rpy:1310
    old "1. <Sometimes.>"
    new "1. <A veces.>"

    # game/beyond the bet/day8dlc.rpy:1313
    old "1. <Just small lies, you know?>"
    new "1. <Solo mentiras pequeñas, ¿sabes?>"

    # game/beyond the bet/day8dlc.rpy:1316
    old "1. <Like telling the Grim Reaper he's a smelly loser.>"
    new "1. <Como decirle a la Parca que es un perdedor apestoso.>"

    # game/beyond the bet/day8dlc.rpy:1323
    old "1. <But why all this talk of birthdays?>"
    new "1. <¿Pero a qué viene tanta charla sobre cumpleaños?>"

    # game/beyond the bet/day8dlc.rpy:1328
    old "1. <While you were sick???>"
    new "1. <¿¿¿Mientras estabas enfermo???>"

    # game/beyond the bet/day8dlc.rpy:1340
    old "2. <Wait a second...>"
    new "2. <Espera un segundo...>"

    # game/beyond the bet/day8dlc.rpy:1342
    old "3. <You're telling me...>"
    new "3. <Me estás diciendo...>"

    # game/beyond the bet/day8dlc.rpy:1345
    old "1. <TODAY IS YOUR BIRTHDAY??????>"
    new "1. <¡¿HOY ES TU CUMPLEAÑOS??????>"

    # game/beyond the bet/day8dlc.rpy:1351
    old "1. <Happy Birthday Casper!!!!>"
    new "1. <¡¡¡¡Feliz cumpleaños, Casper!!!!>"

    # game/beyond the bet/day8dlc.rpy:1354
    old "1. <You never knew before???>"
    new "1. <¿¿¿Nunca lo habías sabido???>"

    # game/beyond the bet/day8dlc.rpy:1360
    old "1. <Not including you, right?>"
    new "1. <Tú eres la excepción, ¿verdad?>"

    # game/beyond the bet/day8dlc.rpy:1366
    old "1. <I think it's great.>"
    new "1. <Yo creo que es genial.>"

    # game/beyond the bet/day8dlc.rpy:1368
    old "2. <Is it so bad?>"
    new "2. <¿Es tan malo?>"

    # game/beyond the bet/day8dlc.rpy:1370
    old "3. <You're more and more human every day.>"
    new "3. <Cada día eres más y más humano.>"

    # game/beyond the bet/day8dlc.rpy:1377
    old "1. <Well, I'm sorry you feel like that.>"
    new "1. <Bueno, lamento que te sientas así.>"

    # game/beyond the bet/day8dlc.rpy:1380
    old "1. <I, for one, am enjoying this Grim Reaper with unexpected emotions and attachments.>"
    new "1. <Yo, por mi parte, estoy disfrutando de esta Parca con emociones y vínculos inesperados.>"

    # game/beyond the bet/day8dlc.rpy:1383
    old "1. <If you could do anything...>"
    new "1. <Si pudieras hacer lo que quisieras...>"

    # game/beyond the bet/day8dlc.rpy:1386
    old "1. <What would you do for your birthday, Casper?>"
    new "1. <¿Qué harías por tu cumpleaños, Casper?>"

    # game/beyond the bet/day8dlc.rpy:1389
    old "2. <Hey, Casper...>"
    new "2. <Oye, Casper...>"

    # game/beyond the bet/day8dlc.rpy:1392
    old "1. <Forget other people. What would YOU do for your birthday, if you could?>"
    new "1. <Olvida a los demás. ¿Qué harías TÚ por tu cumpleaños, si pudieras?>"

    # game/beyond the bet/day8dlc.rpy:1399
    old "1. <It doesn't need to be that deep.>"
    new "1. <No hay que darle tantas vueltas.>"

    # game/beyond the bet/day8dlc.rpy:1401
    old "2. <Don't think too hard.>"
    new "2. <No lo pienses tanto.>"

    # game/beyond the bet/day8dlc.rpy:1404
    old "1. <It could be anything.>"
    new "1. <Puede ser cualquier cosa.>"

    # game/beyond the bet/day8dlc.rpy:1406
    old "2. <Your imagination's the limit.>"
    new "2. <Tu imaginación es el límite.>"

    # game/beyond the bet/day8dlc.rpy:1411
    old "1. <Like...?>"
    new "1. <¿Como qué...?>"

    # game/beyond the bet/day8dlc.rpy:1417
    old "1. <Love?>"
    new "1. <¿Amor?>"

    # game/beyond the bet/day8dlc.rpy:1421
    old "1. <It can be.>"
    new "1. <Puede serlo.>"

    # game/beyond the bet/day8dlc.rpy:1423
    old "2. <It depends who you love.>"
    new "2. <Depende de a quién ames.>"

    # game/beyond the bet/day8dlc.rpy:1426
    old "1. <Feelings can change, newness can wear off...>"
    new "1. <Los sentimientos pueden cambiar, la novedad puede desgastarse...>"

    # game/beyond the bet/day8dlc.rpy:1435
    old "1. <I think true love is eternal.>"
    new "1. <Creo que el amor verdadero es eterno.>"

    # game/beyond the bet/day8dlc.rpy:1438
    old "1. <Sure, I mean, everyone dies...>"
    new "1. <Claro, o sea, todos morimos...>"

    # game/beyond the bet/day8dlc.rpy:1441
    old "1. <Maybe not you?>"
    new "1. <¿Quizás tú no?>"

    # game/beyond the bet/day8dlc.rpy:1444
    old "1. <But love leaves a mark on you that goes past that.>"
    new "1. <Pero el amor deja en ti una huella que va más allá de eso.>"

    # game/beyond the bet/day8dlc.rpy:1447
    old "1. <Don't you think?>"
    new "1. <¿No crees?>"

    # game/beyond the bet/day8dlc.rpy:1454
    old "2. <I think everything ends.>"
    new "2. <Creo que todo termina.>"

    # game/beyond the bet/day8dlc.rpy:1457
    old "1. <But the destination doesn't make the journey any less worth pursuing.>"
    new "1. <Pero el destino no hace que el camino valga menos la pena.>"

    # game/beyond the bet/day8dlc.rpy:1460
    old "1. <That's the nice thing about something being fleeting.>"
    new "1. <Eso es lo bonito de algo fugaz.>"

    # game/beyond the bet/day8dlc.rpy:1463
    old "1. <You appreciate it all the more when you reach your destination.>"
    new "1. <Lo aprecias aún más cuando llegas a tu destino.>"

    # game/beyond the bet/day8dlc.rpy:1467
    old "2. <Fireflies!>"
    new "2. <¡Luciérnagas!>"

    # game/beyond the bet/day8dlc.rpy:1471
    old "1. <Have you ever heard of synchronous fireflies?>"
    new "1. <¿Has oído hablar de las luciérnagas sincrónicas?>"

    # game/beyond the bet/day8dlc.rpy:1475
    old "1. <They're a kind of firefly that, for a couple of months a year...>"
    new "1. <Son un tipo de luciérnaga que, un par de meses al año...>"

    # game/beyond the bet/day8dlc.rpy:1478
    old "1. <All blink at the same time!>"
    new "1. <¡Parpadean todas al mismo tiempo!>"

    # game/beyond the bet/day8dlc.rpy:1482
    old "1. <I've never seen it, but it sounds beautiful.>"
    new "1. <Nunca las he visto, pero suena hermoso.>"

    # game/beyond the bet/day8dlc.rpy:1484
    old "2. <I went and saw them once.>"
    new "2. <Fui a verlas una vez.>"

    # game/beyond the bet/day8dlc.rpy:1491
    old "1. <It's a mating thing, actually...>"
    new "1. <En realidad, es cosa de apareamiento...>"

    # game/beyond the bet/day8dlc.rpy:1496
    old "1. <Oh, you don't know the half of it.>"
    new "1. <Oh, no sabes ni la mitad.>"

    # game/beyond the bet/day8dlc.rpy:1500
    old "1. <I've got a lot more I could tell you about.>"
    new "1. <Tengo mucho más que podría contarte.>"

    # game/beyond the bet/day8dlc.rpy:1503
    old "1. <A special birthday treat.>"
    new "1. <Un regalo especial de cumpleaños.>"

    # game/beyond the bet/day8dlc.rpy:1508
    old "2. <Maybe we can learn more together?>"
    new "2. <¿Tal vez podamos aprender más juntos?>"

    # game/beyond the bet/day8dlc.rpy:1515
    old "1. <I was thinking humans.>"
    new "1. <Estaba pensando en humanos.>"

    # game/beyond the bet/day8dlc.rpy:1518
    old "1. <Or... reapers?>"
    new "1. <O... ¿parcas?>"

    # game/beyond the bet/day8dlc.rpy:1521
    old "1. <Or both together.>"
    new "1. <O ambos juntos.>"

    # game/beyond the bet/day8dlc.rpy:1524
    old "1. <;)>"
    new "1. <;)>"

    # game/beyond the bet/day8dlc.rpy:1528
    old "3. <How about the Aurora Borealis?>"
    new "3. <¿Y qué tal la aurora boreal?>"

    # game/beyond the bet/day8dlc.rpy:1533
    old "1. <WOAH! I'm jealous!>"
    new "1. <¡UY! ¡Qué envidia!>"

    # game/beyond the bet/day8dlc.rpy:1537
    old "1. <Alright Mr Showoff!>"
    new "1. <¡Está bien, señor presumido!>"

    # game/beyond the bet/day8dlc.rpy:1539
    old "2. <Blah blah blah.>"
    new "2. <Bla, bla, bla.>"

    # game/beyond the bet/day8dlc.rpy:1543
    old "1. <Yeah!>"
    new "1. <¡Sí!>"

    # game/beyond the bet/day8dlc.rpy:1545
    old "2. <I'd love to.>"
    new "2. <Me encantaría.>"

    # game/beyond the bet/day8dlc.rpy:1548
    old "1. <One day, I hope.>"
    new "1. <Algún día, espero.>"

    # game/beyond the bet/day8dlc.rpy:1552
    old "1. <You know, if this whole dying thing doesn't work out.>"
    new "1. <Ya sabes, si todo esto de morir no resulta.>"

    # game/beyond the bet/day8dlc.rpy:1556
    old "2. <I feel like it won't ever happen...>"
    new "2. <Siento que nunca va a pasar...>"

    # game/beyond the bet/day8dlc.rpy:1560
    old "1. <It's an expensive trip.>"
    new "1. <Es un viaje caro.>"

    # game/beyond the bet/day8dlc.rpy:1565
    old "1. <You could...?>"
    new "1. <¿Podrías...?>"

    # game/beyond the bet/day8dlc.rpy:1569
    old "2. <I saw it once, too!>"
    new "2. <¡Yo también las vi una vez!>"

    # game/beyond the bet/day8dlc.rpy:1572
    old "1. <I've never seen something so beautiful.>"
    new "1. <Nunca he visto algo tan hermoso.>"

    # game/beyond the bet/day8dlc.rpy:1574
    old "2. <I want to see it again, one day...>"
    new "2. <Quiero volver a verlas algún día...>"

    # game/beyond the bet/day8dlc.rpy:1579
    old "1. <It's kinda pretty far away.>"
    new "1. <Queda bastante lejos.>"

    # game/beyond the bet/day8dlc.rpy:1581
    old "2. <It's on the other side of the world!>"
    new "2. <¡Está al otro lado del mundo!>"

    # game/beyond the bet/day8dlc.rpy:1596
    old "1. <I thought you wouldn't let me fly with you!>"
    new "1. <¡Pensé que no me dejarías volar contigo!>"

    # game/beyond the bet/day8dlc.rpy:1602
    old "1. <What if you drop me?>"
    new "1. <¿Y si me sueltas?>"

    # game/beyond the bet/day8dlc.rpy:1607
    old "1. <Then count me in!>"
    new "1. <¡Entonces cuenta conmigo!>"

    # game/beyond the bet/day8dlc.rpy:1616
    old "1. <No hell-themed birthday party :( ?>"
    new "1. <¿Nada de fiesta de cumpleaños temática del infierno? :(>"

    # game/beyond the bet/day8dlc.rpy:1620
    old "1. <How about putting on a party hat?>"
    new "1. <¿Y ponerte un gorrito de fiesta?>"

    # game/beyond the bet/day8dlc.rpy:1624
    old "1. <Pin the tail on the imp?>"
    new "1. <¿Ponerle la cola al diablito?>"

    # game/beyond the bet/day8dlc.rpy:1629
    old "1. <It's not a real imp, dummy.>"
    new "1. <No es un diablito de verdad, tonto.>"

    # game/beyond the bet/day8dlc.rpy:1635
    old "1. <Alright, what would you underworld dwellers do at a kid's birthday party?>"
    new "1. <Está bien, ¿qué harían ustedes, los habitantes del inframundo, en una fiesta infantil?>"

    # game/beyond the bet/day8dlc.rpy:1639
    old "1. <Not even any, like...>"
    new "1. <Ni siquiera, como...>"

    # game/beyond the bet/day8dlc.rpy:1642
    old "1. <Child demons or something?>"
    new "1. <¿Niños demonio o algo así?>"

    # game/beyond the bet/day8dlc.rpy:1646
    old "1. <You guys have to do SOMETHING for fun!>"
    new "1. <¡Ustedes tienen que hacer ALGO para divertirse!>"

    # game/beyond the bet/day8dlc.rpy:1653
    old "1. <Is that why you were so into our bet?>"
    new "1. <¿Es por eso que te interesó tanto nuestra apuesta?>"

    # game/beyond the bet/day8dlc.rpy:1657
    old "1. <What do they bet over?>"
    new "1. <¿Sobre qué apuestan?>"

    # game/beyond the bet/day8dlc.rpy:1661
    old "1. <Morbid. Nice.>"
    new "1. <Macabro. Genial.>"

    # game/beyond the bet/day8dlc.rpy:1666
    old "2. <How do you know?>"
    new "2. <¿Cómo lo sabes?>"

    # game/beyond the bet/day8dlc.rpy:1669
    old "1. <You ever asked an imp?>"
    new "1. <¿Alguna vez le has preguntado a un diablito?>"

    # game/beyond the bet/day8dlc.rpy:1673
    old "1. <You never know if you don't ask.>"
    new "1. <Nunca lo sabrás si no preguntas.>"

    # game/beyond the bet/day8dlc.rpy:1679
    old "1. <Yeah, you should try it. Really.>"
    new "1. <Sí, deberías intentarlo. En serio.>"

    # game/beyond the bet/day8dlc.rpy:1683
    old "1. <I am.>"
    new "1. <Sí.>"

    # game/beyond the bet/day8dlc.rpy:1686
    old "1. <I, for one, would relish in the opportunity.>"
    new "1. <Yo, por mi parte, disfrutaría la oportunidad.>"

    # game/beyond the bet/day8dlc.rpy:1692
    old "1. <Gaslighting = success?>"
    new "1. <¿Gaslighting = éxito?>"

    # game/beyond the bet/day8dlc.rpy:1696
    old "1. <What word?>"
    new "1. <¿Qué palabra?>"

    # game/beyond the bet/day8dlc.rpy:1701
    old "1. <What do you mean?>"
    new "1. <¿Qué quieres decir?>"

    # game/beyond the bet/day8dlc.rpy:1704
    old "1. <I've never seen that before.>"
    new "1. <Nunca había visto eso.>"

    # game/beyond the bet/day8dlc.rpy:1708
    old "1. <No I didn't.>"
    new "1. <No, no lo dije.>"

    # game/beyond the bet/day8dlc.rpy:1717
    old "1. <A practical example of gaslighting.>"
    new "1. <Un ejemplo práctico de gaslighting.>"

    # game/beyond the bet/day8dlc.rpy:1720
    old "1. <Not bad, huh?>"
    new "1. <Nada mal, ¿eh?>"

    # game/beyond the bet/day8dlc.rpy:1724
    old "1. <Thank you <3>"
    new "1. <Gracias <3>"

    # game/beyond the bet/day8dlc.rpy:1728
    old "2. <You'd look cute with a tail, Grimmy.>"
    new "2. <Te verías lindo con cola, Parquita.>"

    # game/beyond the bet/day8dlc.rpy:1734
    old "2. <100 percent.>"
    new "2. <Al cien por ciento.>"

    # game/beyond the bet/day8dlc.rpy:1737
    old "1. <Super cute.>"
    new "1. <Súper lindo.>"

    # game/beyond the bet/day8dlc.rpy:1740
    old "1. <If you were an animal, I bet you'd be...>"
    new "1. <Si fueras un animal, apuesto a que serías...>"

    # game/beyond the bet/day8dlc.rpy:1743
    old "1. <A fluffy white cat.>"
    new "1. <Un gato blanco esponjoso.>"

    # game/beyond the bet/day8dlc.rpy:1746
    old "1. <Something regal looking with a huge, sweeping tail.>"
    new "1. <Algo de aspecto elegante con una cola enorme y majestuosa.>"

    # game/beyond the bet/day8dlc.rpy:1748
    old "2. <An axolotl! A white one!>"
    new "2. <¡Un ajolote! ¡Uno blanco!>"

    # game/beyond the bet/day8dlc.rpy:1751
    old "1. <You'd be matching with Azrael!>"
    new "1. <¡Combinarías con Azrael!>"

    # game/beyond the bet/day8dlc.rpy:1753
    old "3. <A little dog.>"
    new "3. <Un perrito.>"

    # game/beyond the bet/day8dlc.rpy:1756
    old "1. <One with a big attitude, obviously.>"
    new "1. <Uno con mucho carácter, obviamente.>"

    # game/beyond the bet/day8dlc.rpy:1760
    old "1. <You could be like, a little devil.>"
    new "1. <Podrías ser, como, un pequeño demonio.>"

    # game/beyond the bet/day8dlc.rpy:1763
    old "1. <Tiny horns and a tail would suit you too.>"
    new "1. <Unos cuernitos y una cola también te quedarían bien.>"

    # game/beyond the bet/day8dlc.rpy:1773
    old "1. <I've been nice from the start!>"
    new "1. <¡Yo he sido amable desde el principio!>"

    # game/beyond the bet/day8dlc.rpy:1775
    old "2. <Okay, that's fair.>"
    new "2. <Okey, tienes razón.>"

    # game/beyond the bet/day8dlc.rpy:1782
    old "3. <Me B)>"
    new "3. <A mí B)>"

    # game/beyond the bet/day8dlc.rpy:1785
    old "1. <You can stick whatever you want in me.>"
    new "1. <Puedes meterme lo que quieras.>"

    # game/beyond the bet/day8dlc.rpy:1789
    old "1. <I meant a different kind of tail.>"
    new "1. <Me refería a otro tipo de cola.>"

    # game/beyond the bet/day8dlc.rpy:1792
    old "1. <And I'm the imp.>"
    new "1. <Y el diablito soy yo.>"

    # game/beyond the bet/day8dlc.rpy:1796
    old "1. <I'm pretty good at taking what's given to me, Caspy-waspy.>"
    new "1. <Se me da muy bien aceptar lo que me dan, Caspy-waspy.>"

    # game/beyond the bet/day8dlc.rpy:1799
    old "1. <Try me ;)>"
    new "1. <Ponme a prueba ;)>"

    # game/beyond the bet/day8dlc.rpy:1805
    old "2. <Oh, I do hope so.>"
    new "2. <Oh, eso espero.>"

    # game/beyond the bet/day8dlc.rpy:1809
    old "4. <You, when I'm done with you.>"
    new "4. <A ti, cuando termine contigo.>"

    # game/beyond the bet/day8dlc.rpy:1814
    old "1. <More like pin you down to the bed.>"
    new "1. <Más bien inmovilizarte en la cama.>"

    # game/beyond the bet/day8dlc.rpy:1818
    old "1. <Well, what would you like me to do?>"
    new "1. <Bueno, ¿qué te gustaría que hiciera?>"

    # game/beyond the bet/day8dlc.rpy:1823
    old "1. <You shouldn't answer a question with a question!>"
    new "1. <¡No deberías responder una pregunta con otra pregunta!>"

    # game/beyond the bet/day8dlc.rpy:1830
    old "1. <I want to touch your hair, first.>"
    new "1. <Quiero tocarte el cabello, primero.>"

    # game/beyond the bet/day8dlc.rpy:1833
    old "1. <Run my fingers all the way down to the ends...>"
    new "1. <Deslizar mis dedos hasta las puntas...>"

    # game/beyond the bet/day8dlc.rpy:1837
    old "1. <And then...>"
    new "1. <Y luego...>"

    # game/beyond the bet/day8dlc.rpy:1840
    old "1. <You'll have to come over and see :)>"
    new "1. <Tendrás que venir a verlo por ti mismo :)>"

    # game/beyond the bet/day8dlc.rpy:1843
    old "1. <Can't spoil all the fun, can I?>"
    new "1. <No puedo arruinar toda la diversión, ¿o sí?>"

    # game/beyond the bet/day8dlc.rpy:1885
    old "1. <Wow, way to call out of the blue!>"
    new "1. <¡Wow, qué llamada tan repentina!>"

    # game/beyond the bet/day8dlc.rpy:1903
    old "2. <Oh.>"
    new "2. <Oh.>"

    # game/beyond the bet/day8dlc.rpy:1906
    old "1. <That is... awfully honest of you, Grimmy.>"
    new "1. <Eso es... terriblemente sincero de tu parte, Parquita.>"

    # game/beyond the bet/day8dlc.rpy:1908
    old "2. <I didn't expect you to just say it...>"
    new "2. <No esperaba que lo dijeras así sin más...>"

    # game/beyond the bet/day8dlc.rpy:1921
    old "1. <No, you're always truthful. Definitely not always \nhonest.>"
    new "1. <No, siempre dices la verdad. Pero no siempre eres sincero.>"

    # game/beyond the bet/day8dlc.rpy:1924
    old "1. <They're different things.>"
    new "1. <Son cosas distintas.>"

    # game/beyond the bet/day8dlc.rpy:1932
    old "1. <Somehow.>"
    new "1. <De algún modo.>"

    # game/beyond the bet/day8dlc.rpy:1934
    old "2. <It's weird, isn't it?>"
    new "2. <Es raro, ¿no?>"

    # game/beyond the bet/day8dlc.rpy:1937
    old "1. <It really does feel like we've known each other forever.>"
    new "1. <De verdad se siente como si nos conociéramos desde siempre.>"

    # game/beyond the bet/day8dlc.rpy:1946
    old "1. <Hey, Casper?>"
    new "1. <Oye, ¿Casper?>"

    # game/beyond the bet/day8dlc.rpy:1949
    old "1. <Have you ever seen fireworks?>"
    new "1. <¿Alguna vez has visto fuegos artificiales?>"

    # game/beyond the bet/day8dlc.rpy:1958
    old "1. <I was just thinking that it'd be perfect for your birthday.>"
    new "1. <Justo estaba pensando que serían perfectos para tu cumpleaños.>"

    # game/beyond the bet/day8dlc.rpy:1961
    old "1. <It's fleeting, it's beautiful, it's human.>"
    new "1. <Son fugaces, hermosos, humanos.>"

    # game/beyond the bet/day8dlc.rpy:1968
    old "1. <Together, then!>"
    new "1. <¡Juntos, entonces!>"

    # game/beyond the bet/day8dlc.rpy:1972
    old "1. <Not very committed, but I'll take it.>"
    new "1. <No te comprometes mucho, pero me conformo.>"

    # game/beyond the bet/day8dlc.rpy:1975
    old "1. <Anyway, Casper, can I ask you something?>"
    new "1. <En fin, Casper, ¿puedo preguntarte algo?>"

    # game/beyond the bet/day8dlc.rpy:1989
    old "1. <I really want to know more about reapers.>"
    new "1. <De verdad quiero saber más sobre las parcas.>"

    # game/beyond the bet/day8dlc.rpy:2001
    old "1. <Well, those 'some' should zip their yappers.>"
    new "1. <Pues esos 'algunos' deberían cerrar el pico.>"

    # game/beyond the bet/day8dlc.rpy:2003
    old "2. <It's nowhere near more than enough!>"
    new "2. <¡Ni de lejos es más que suficiente!>"

    # game/beyond the bet/day8dlc.rpy:2006
    old "1. <I know you guys have a whole ass city? State? Country? Down there.>"
    new "1. <Sé que ustedes tienen toda una ciudad... ¿estado? ¿país? ahí abajo.>"

    # game/beyond the bet/day8dlc.rpy:2011
    old "1. <I know you guys live forever.>"
    new "1. <Sé que ustedes viven para siempre.>"

    # game/beyond the bet/day8dlc.rpy:2016
    old "1. <Most of the time?>"
    new "1. <¿La mayor parte del tiempo?>"

    # game/beyond the bet/day8dlc.rpy:2026
    old "1. <What else do I even know?>"
    new "1. <¿Qué más sé siquiera?>"

    # game/beyond the bet/day8dlc.rpy:2029
    old "1. <You eat cup noodles, so you have grocery stores.>"
    new "1. <Comen fideos instantáneos, así que tienen supermercados.>"

    # game/beyond the bet/day8dlc.rpy:2043
    old "1. <Do you have... farms?>"
    new "1. <¿Tienen... granjas?>"

    # game/beyond the bet/day8dlc.rpy:2045
    old "1. <Like, do you grow your own food?>"
    new "1. <O sea, ¿cultivan su propia comida?>"

    # game/beyond the bet/day8dlc.rpy:2051
    old "1. <So if I suddenly moved there, I'd be good for food?>"
    new "1. <Entonces, si me mudara allí de repente, ¿tendría comida?>"

    # game/beyond the bet/day8dlc.rpy:2063
    old "1. <Is the food all made of fire?>"
    new "1. <¿Toda la comida está hecha de fuego?>"

    # game/beyond the bet/day8dlc.rpy:2071
    old "2. <Is there an Underworld music industry?>"
    new "2. <¿Hay una industria musical del Inframundo?>"

    # game/beyond the bet/day8dlc.rpy:2073
    old "1. <I wonder if it's all rock, or metal, or something.>"
    new "1. <Me pregunto si todo es rock, o metal, o algo así.>"

    # game/beyond the bet/day8dlc.rpy:2075
    old "2. <I bet you're secretly into hell-pop or hell-country.>"
    new "2. <Apuesto a que en secreto te gusta el hell-pop o el hell-country.>"

    # game/beyond the bet/day8dlc.rpy:2080
    old "1. <Are your posters from Underworld bands?>"
    new "1. <¿Tus pósteres son de bandas del Inframundo?>"

    # game/beyond the bet/day8dlc.rpy:2085
    old "1. <Man. I want to go to a concert in hell.>"
    new "1. <Uf. Quiero ir a un concierto en el infierno.>"

    # game/beyond the bet/day8dlc.rpy:2088
    old "1. <Wait, you've never been to one?>"
    new "1. <Espera, ¿nunca has ido a uno?>"

    # game/beyond the bet/day8dlc.rpy:2093
    old "1. <Too busy for a few hours off???>"
    new "1. <¿¿¿Demasiado ocupado para unas horas libres???>"

    # game/beyond the bet/day8dlc.rpy:2108
    old "1. <Alright, alright, I get it. I see what you're saying here.>"
    new "1. <Está bien, está bien, ya entiendo. Veo lo que dices.>"

    # game/beyond the bet/day8dlc.rpy:2111
    old "1. <I'm adding it to our todo list.>"
    new "1. <Lo estoy agregando a nuestra lista de pendientes.>"

    # game/beyond the bet/day8dlc.rpy:2117
    old "1. <I heard you, and I'm adding it to the list anyway.>"
    new "1. <Te oí, y de todos modos lo estoy agregando a la lista.>"

    # game/beyond the bet/day8dlc.rpy:2120
    old "1. <You. Me. Hell concert date.>"
    new "1. <Tú. Yo. Cita en un concierto del infierno.>"

    # game/beyond the bet/day8dlc.rpy:2128
    old "1. <Yes we do.>"
    new "1. <Claro que sí.>"

    # game/beyond the bet/day8dlc.rpy:2133
    old "1. <We do.>"
    new "1. <Claro que sí.>"

    # game/beyond the bet/day8dlc.rpy:2144
    old "2. <Grimmy, what kind of music do you like?>"
    new "2. <Parquita, ¿qué tipo de música te gusta?>"

    # game/beyond the bet/day8dlc.rpy:2150
    old "1. <Grimmy. Bro. Bestie. You are MISSING OUT.>"
    new "1. <Parquita. Bro. Bestie. Te lo estás PERDIENDO.>"

    # game/beyond the bet/day8dlc.rpy:2156
    old "1. <I'm gonna introduce you to SO MUCH music.>"
    new "1. <Te voy a presentar TANTA música.>"

    # game/beyond the bet/day8dlc.rpy:2159
    old "2. <To be fair, I've never been much into music either.>"
    new "2. <A decir verdad, a mí tampoco me ha interesado mucho la música.>"

    # game/beyond the bet/day8dlc.rpy:2161
    old "1. <Do you know what that means?>"
    new "1. <¿Sabes lo que eso significa?>"

    # game/beyond the bet/day8dlc.rpy:2166
    old "1. <That I am.>"
    new "1. <Y lo voy a hacer.>"

    # game/beyond the bet/day8dlc.rpy:2169
    old "1. <You. Me. Discovering our love for music together.>"
    new "1. <Tú. Yo. Descubriendo juntos nuestro amor por la música.>"

    # game/beyond the bet/day8dlc.rpy:2172
    old "1. <This is exciting.>"
    new "1. <Esto es emocionante.>"

    # game/beyond the bet/day8dlc.rpy:2174
    old "2. <Wait, we could go to some musicals. You'd hate musicals.>"
    new "2. <Espera, podríamos ir a algunos musicales. Los odiarías.>"

    # game/beyond the bet/day8dlc.rpy:2181
    old "1. <Aren't you always?>"
    new "1. <¿No lo eres siempre?>"

    # game/beyond the bet/day8dlc.rpy:2189
    old "1. <Thank you. That's a big compliment, coming from Mr Big Bad Grim Reaper himself.>"
    new "1. <Gracias. Es un gran cumplido, viniendo del mismísimo Señor Parca Grande y Malvado.>"

    # game/beyond the bet/day8dlc.rpy:2192
    old "1. <You know, you really aren't scary for a personification of death.>"
    new "1. <Sabes, la verdad es que no das miedo para ser una personificación de la muerte.>"

    # game/beyond the bet/day8dlc.rpy:2197
    old "1. <You?>"
    new "1. <¿Tú?>"

    # game/beyond the bet/day8dlc.rpy:2200
    old "1. <My favorite babygirl?>"
    new "1. <¿Mi babygirl favorita?>"

    # game/beyond the bet/day8dlc.rpy:2203
    old "2. <Sweet, innocent, baby Casper?>"
    new "2. <¿El dulce e inocente bebé Casper?>"

    # game/beyond the bet/day8dlc.rpy:2207
    old "3. <Wait, do you have arcades?>"
    new "3. <Espera, ¿tienen arcades?>"

    # game/beyond the bet/day8dlc.rpy:2211
    old "1. <Are you joking right now?>"
    new "1. <¿Estás bromeando ahora?>"

    # game/beyond the bet/day8dlc.rpy:2214
    old "1. <You know, a building where you go and play on arcade machines. Games and stuff.>"
    new "1. <Ya sabes, un edificio al que vas a jugar en máquinas recreativas. Juegos y esas cosas.>"

    # game/beyond the bet/day8dlc.rpy:2222
    old "1. <WHAT?!>"
    new "1. <¡¿QUÉ?!>"

    # game/beyond the bet/day8dlc.rpy:2224
    old "1. <You've gotta go! I love arcades!>"
    new "1. <¡Tienes que ir! ¡Me encantan los arcades!>"

    # game/beyond the bet/day8dlc.rpy:2229
    old "1. <Who said you had to go alone?>"
    new "1. <¿Quién dijo que tenías que ir solo?>"

    # game/beyond the bet/day8dlc.rpy:2232
    old "1. <I'll come!>"
    new "1. <¡Iré yo!>"

    # game/beyond the bet/day8dlc.rpy:2237
    old "1. <How about DDR?>"
    new "1. <¿Qué tal DDR?>"

    # game/beyond the bet/day8dlc.rpy:2240
    old "1. <I flippin' suck at DDR.>"
    new "1. <Se me da fatal el DDR.>"

    # game/beyond the bet/day8dlc.rpy:2244
    old "1. <I wanna suck at it with you.>"
    new "1. <Quiero hacerlo fatal contigo.>"

    # game/beyond the bet/day8dlc.rpy:2248
    old "1. <I dunno about that one, chief.>"
    new "1. <Eso no lo tengo tan claro, jefe.>"

    # game/beyond the bet/day8dlc.rpy:2250
    old "2. <Sure, Casper. Sure.>"
    new "2. <Claro, Casper. Claro.>"

    # game/beyond the bet/day8dlc.rpy:2253
    old "1. <So, you have arcades... I really can't picture it.>"
    new "1. <O sea, tienen arcades... De verdad no puedo imaginarlo.>"

    # game/beyond the bet/day8dlc.rpy:2257
    old "2. <I'm SO GOOD at DDR.>"
    new "2. <Se me da SÚPER BIEN el DDR.>"

    # game/beyond the bet/day8dlc.rpy:2259
    old "1. <I'm gonna walk circles around you.>"
    new "1. <Te voy a hacer morder el polvo.>"

    # game/beyond the bet/day8dlc.rpy:2262
    old "1. <Me, the mighty [playerfirstname], beating the Grim Reaper once again! >"
    new "1. <¡Yo, [playerfirstname], con mi inmenso poder, venciendo a la Parca una vez más!>"

    # game/beyond the bet/day8dlc.rpy:2267
    old "1. <I doubt it.>"
    new "1. <Lo dudo.>"

    # game/beyond the bet/day8dlc.rpy:2270
    old "1. <You're gonna fall flat on your face.>"
    new "1. <Te vas a caer de bruces.>"

    # game/beyond the bet/day8dlc.rpy:2275
    old "1. <But go on, you were gonna tell me more about the Underworld.>"
    new "1. <Pero sigue, ibas a contarme más sobre el Inframundo.>"

    # game/beyond the bet/day8dlc.rpy:2280
    old "2. <To be honest, me neither.>"
    new "2. <La verdad, yo tampoco.>"

    # game/beyond the bet/day8dlc.rpy:2282
    old "1. <BUT...>"
    new "1. <PERO...>"

    # game/beyond the bet/day8dlc.rpy:2286
    old "1. <I just know, deep in my soul, I would love going to an arcade.>"
    new "1. <Solo sé, en lo más profundo de mi alma, que me encantaría ir a un arcade.>"

    # game/beyond the bet/day8dlc.rpy:2298
    old "1. <Yeah well, being delusional is kinda my thing.>"
    new "1. <Bueno, sí, hacerme ilusiones es un poco lo mío.>"

    # game/beyond the bet/day8dlc.rpy:2304
    old "1. <Play... games...?>"
    new "1. <¿Jugar... juegos...?>"

    # game/beyond the bet/day8dlc.rpy:2313
    old "1. <Shooting games, dancing games, racing games.>"
    new "1. <Juegos de disparos, de baile, de carreras.>"

    # game/beyond the bet/day8dlc.rpy:2316
    old "1. <Even without practice I bet I could beat you at anything.>"
    new "1. <Incluso sin práctica, apuesto a que podría vencerte en lo que sea.>"

    # game/beyond the bet/day8dlc.rpy:2322
    old "1. <You and your bets.>"
    new "1. <Tú y tus apuestas.>"

    # game/beyond the bet/day8dlc.rpy:2325
    old "1. <That can come later, though. You were going to tell me about the Underworld.>"
    new "1. <Eso puede venir después. Ibas a contarme sobre el Inframundo.>"

    # game/beyond the bet/day8dlc.rpy:2329
    old "2. <We could just make out in the corner.>"
    new "2. <Podríamos simplemente besuquearnos en un rincón.>"

    # game/beyond the bet/day8dlc.rpy:2337
    old "1. <Everyone has to makeout in the corner of a dingy little arcade once in their life.>"
    new "1. <Todo el mundo tiene que besuquearse en un rincón de un arcade cutre al menos una vez en la vida.>"

    # game/beyond the bet/day8dlc.rpy:2340
    old "1. <Or so I've heard.>"
    new "1. <O eso he oído.>"

    # game/beyond the bet/day8dlc.rpy:2347
    old "1. <I made it up.>"
    new "1. <Me lo inventé.>"

    # game/beyond the bet/day8dlc.rpy:2354
    old "1. <Awww. You really do know me so well. I'm blushing.>"
    new "1. <Awww. De verdad me conoces muy bien. Me estoy sonrojando.>"

    # game/beyond the bet/day8dlc.rpy:2357
    old "1. <So that's a no?>"
    new "1. <¿Entonces es un no?>"

    # game/beyond the bet/day8dlc.rpy:2365
    old "1. <Oh? Planning to kiss me somewhere else?>"
    new "1. <¿Oh? ¿Planeas besarme en otro lugar?>"

    # game/beyond the bet/day8dlc.rpy:2376
    old "1. <While kissing?>"
    new "1. <¿Mientras nos besamos?>"

    # game/beyond the bet/day8dlc.rpy:2378
    old "1. <Just kidding. Go on, then.>"
    new "1. <Es broma. Adelante, entonces.>"

    # game/beyond the bet/day8dlc.rpy:2380
    old "2. <My plan worked, then.>"
    new "2. <Mi plan funcionó, entonces.>"

    # game/beyond the bet/day8dlc.rpy:2382
    old "1. <Mwhahaha.>"
    new "1. <Mwajaja.>"

    # game/beyond the bet/day8dlc.rpy:2387
    old "2. <I dunno. Your thing is more blushing and cuddling Azrael.>"
    new "2. <No sé. Lo tuyo es más sonrojarte y abrazar a Azrael.>"

    # game/beyond the bet/day8dlc.rpy:2391
    old "1. <What do you mean falsehoods?>"
    new "1. <¿Qué quieres decir con falsedades?>"

    # game/beyond the bet/day8dlc.rpy:2394
    old "1. <Do you cuddle Azrael?>"
    new "1. <¿Abrazas a Azrael?>"

    # game/beyond the bet/day8dlc.rpy:2399
    old "1. <Do you blush?>"
    new "1. <¿Te sonrojas?>"

    # game/beyond the bet/day8dlc.rpy:2404
    old "1. <Then I'd say my description of you is spot on.>"
    new "1. <Entonces diría que mi descripción de ti es acertadísima.>"

    # game/beyond the bet/day8dlc.rpy:2409
    old "1. <That all comes second to babygirl.>"
    new "1. <Todo eso queda en segundo lugar frente a babygirl.>"

    # game/beyond the bet/day8dlc.rpy:2411
    old "2. <Some of that is debatable.>"
    new "2. <Algo de eso es discutible.>"

    # game/beyond the bet/day8dlc.rpy:2413
    old "3. <Award-winning is a little much...>"
    new "3. <Lo de galardonada es un poco exagerado...>"

    # game/beyond the bet/day8dlc.rpy:2415
    old "4. <Okay. Your thing is blushing, cuddling Azrael, and being full of yourself.>"
    new "4. <Okey. Lo tuyo es sonrojarte, abrazar a Azrael y creerte la gran cosa.>"

    # game/beyond the bet/day8dlc.rpy:2422
    old "1. <I love you too.>"
    new "1. <Yo también te amo.>"

    # game/beyond the bet/day8dlc.rpy:2438
    old "1. <Now, the Underworld?>"
    new "1. <¿Y ahora, el Inframundo?>"

    # game/beyond the bet/day8dlc.rpy:2446
    old "1. <Who could ever!>"
    new "1. <¡Quién podría!>"

    # game/beyond the bet/day8dlc.rpy:2454
    old "1. <Hehe. You're the best, Caspy-Waspy.>"
    new "1. <Jeje. Eres lo mejor, Caspy-Waspy.>"

    # game/beyond the bet/day8dlc.rpy:2457
    old "1. <But back to reapers and the Underworld and all that...>"
    new "1. <Pero volviendo a las parcas y al Inframundo y todo eso...>"

    # game/beyond the bet/day8dlc.rpy:2463
    old "1. <What {i}is{/i} it actually like?>"
    new "1. <¿Cómo {i}es{/i} en realidad?>"

    # game/beyond the bet/day8dlc.rpy:2470
    old "1. <I really was picturing rivers of lava.>"
    new "1. <De verdad me imaginaba ríos de lava.>"

    # game/beyond the bet/day8dlc.rpy:2483
    old "1. <Yeah, I do. Thanks for noticing.>"
    new "1. <Sí, los tengo. Gracias por notarlo.>"

    # game/beyond the bet/day8dlc.rpy:2500
    old "1. <It's dark during the day.... and lighter at night?>"
    new "1. <Es oscuro de día.... ¿y más claro de noche?>"

    # game/beyond the bet/day8dlc.rpy:2506
    old "1. <It's cool!>"
    new "1. <¡Qué genial!>"

    # game/beyond the bet/day8dlc.rpy:2508
    old "2. <It's... I can't imagine it.>"
    new "2. <Eso... no puedo imaginarlo.>"

    # game/beyond the bet/day8dlc.rpy:2510
    old "3. <It sounds... cold.>"
    new "3. <Suena... frío.>"

    # game/beyond the bet/day8dlc.rpy:2516
    old "1. <Maybe that's just what you think, seeing as you're not much of a people person.>"
    new "1. <Quizás eso es lo que piensas, ya que no eres muy sociable.>"

    # game/beyond the bet/day8dlc.rpy:2532
    old "1. <Hmmm. Maybe SOMEONE just needs to give people a chance.>"
    new "1. <Mmm. Quizás ALGUIEN solo necesita darle una oportunidad a la gente.>"

    # game/beyond the bet/day8dlc.rpy:2537
    old "1. <Ew. Kinda weird, Casper.>"
    new "1. <Ew. Qué raro, Casper.>"

    # game/beyond the bet/day8dlc.rpy:2542
    old "1. <What was that?>"
    new "1. <¿Qué dijiste?>"

    # game/beyond the bet/day8dlc.rpy:2554
    old "1. <I think you saaaaid something.>"
    new "1. <Creo que dijiiiiste algo.>"

    # game/beyond the bet/day8dlc.rpy:2557
    old "1. <Awww, am I your one and only?>"
    new "1. <Awww, ¿soy la única persona en tu vida?>"

    # game/beyond the bet/day8dlc.rpy:2561
    old "1. <But... but... if you had more friends, we could throw a BIIIIG birthday party for you!>"
    new "1. <Pero... pero... ¡si tuvieras más amigos, podríamos hacerte una GRAAAN fiesta de cumpleaños!>"

    # game/beyond the bet/day8dlc.rpy:2566
    old "2. <Imagine if I cloned myself.>"
    new "2. <Imagina que me clonara.>"

    # game/beyond the bet/day8dlc.rpy:2570
    old "1. <In delight?>"
    new "1. <¿De alegría?>"

    # game/beyond the bet/day8dlc.rpy:2575
    old "1. <Don't be a party pooper, Casper.>"
    new "1. <No seas aguafiestas, Casper.>"

    # game/beyond the bet/day8dlc.rpy:2581
    old "1. <Wait, wait, wait.>"
    new "1. <Espera, espera, espera.>"

    # game/beyond the bet/day8dlc.rpy:2584
    old "1. <I bet you'd be really into stupid party games.>"
    new "1. <Apuesto a que te gustarían mucho los juegos de fiesta tontos.>"

    # game/beyond the bet/day8dlc.rpy:2587
    old "1. <I can picture it.>"
    new "1. <Puedo imaginarlo.>"

    # game/beyond the bet/day8dlc.rpy:2589
    old "2. <Yeah, that's the gap moe I signed up for.>"
    new "2. <Sí, ese es el gap moe por el que me inscribí.>"

    # game/beyond the bet/day8dlc.rpy:2593
    old "1. <A grumpy grim reaper who's secretly into party games.>"
    new "1. <Una parca gruñona a la que en secreto le gustan los juegos de fiesta.>"

    # game/beyond the bet/day8dlc.rpy:2606
    old "1. <A poor boy deprived of party games!>"
    new "1. <¡Un pobre chico privado de los juegos de fiesta!>"

    # game/beyond the bet/day8dlc.rpy:2611
    old "1. <But with just the two of us... hmm...>"
    new "1. <Pero siendo solo los dos... mmm...>"

    # game/beyond the bet/day8dlc.rpy:2614
    old "1. <What party games can we play?>"
    new "1. <¿A qué juegos de fiesta podemos jugar?>"

    # game/beyond the bet/day8dlc.rpy:2617
    old "1. <Pass the parcel would be kinda lame.>"
    new "1. <Pasar el paquete sería medio soso.>"

    # game/beyond the bet/day8dlc.rpy:2620
    old "1. <So would 'What's the time, Mr Wolf?'.>"
    new "1. <Y '¿Qué hora es, señor Lobo?' también.>"

    # game/beyond the bet/day8dlc.rpy:2625
    old "1. <Yeah, well, kids like it!>"
    new "1. <Sí, bueno, ¡a los niños les gusta!>"

    # game/beyond the bet/day8dlc.rpy:2627
    old "2. <I like it, and I'm not a kid!>"
    new "2. <¡A mí me gusta, y ya dejé atrás la infancia!>"

    # game/beyond the bet/day8dlc.rpy:2632
    old "1. <You know what?>"
    new "1. <¿Sabes qué?>"

    # game/beyond the bet/day8dlc.rpy:2637
    old "1. <I bet you'd enjoy a pinata!>"
    new "1. <¡Apuesto a que disfrutarías una piñata!>"

    # game/beyond the bet/day8dlc.rpy:2640
    old "1. <You can beat the crap outta it.>"
    new "1. <Puedes molerla a golpes.>"

    # game/beyond the bet/day8dlc.rpy:2642
    old "1. <Let loose that inner reaper rage.>"
    new "1. <Desata esa furia interior de parca.>"

    # game/beyond the bet/day8dlc.rpy:2645
    old "2. <Oh, you could use your scythe on it!>"
    new "2. <¡Oh, podrías usar tu guadaña con ella!>"

    # game/beyond the bet/day8dlc.rpy:2647
    old "1. <Maybe it could be therapeutic for you?>"
    new "1. <¿Quizás podría ser terapéutico para ti?>"

    # game/beyond the bet/day8dlc.rpy:2651
    old "1. <Like a rage room? But in pinata form. I don't know.>"
    new "1. <¿Como una sala de furia? Pero en forma de piñata. No sé.>"

    # game/beyond the bet/day8dlc.rpy:2658
    old "1. <Oh? You were?>"
    new "1. <¿Ah, sí? ¿De verdad lo eras?>"

    # game/beyond the bet/day8dlc.rpy:2661
    old "1. <You've had a pinata before, then? That's surprising.>"
    new "1. <¿Entonces ya has tenido una piñata? Qué sorpresa.>"

    # game/beyond the bet/day8dlc.rpy:2679
    old "1. <Hmmm... maybe you forgot?>"
    new "1. <Mmm... ¿quizás lo olvidaste?>"

    # game/beyond the bet/day8dlc.rpy:2681
    old "2. <Maybe it was kinda lame so you pretend it \nnever happened?>"
    new "2. <¿Quizás fue medio patético y finges que nunca pasó?>"

    # game/beyond the bet/day8dlc.rpy:2683
    old "1. <I've had some things like that before...>"
    new "1. <Me han pasado cosas así antes...>"

    # game/beyond the bet/day8dlc.rpy:2695
    old "1. <You've always been like you are now, right?>"
    new "1. <Siempre has sido como eres ahora, ¿no?>"

    # game/beyond the bet/day8dlc.rpy:2700
    old "1. <Are you sure?>"
    new "1. <¿Estás seguro?>"

    # game/beyond the bet/day8dlc.rpy:2704
    old "1. <And before that?>"
    new "1. <¿Y antes de eso?>"

    # game/beyond the bet/day8dlc.rpy:2714
    old "1. <What if you're wrong?>"
    new "1. <¿Y si te equivocas?>"

    # game/beyond the bet/day8dlc.rpy:2716
    old "2. <And if that isn't the case?>"
    new "2. <¿Y si ese no es el caso?>"

    # game/beyond the bet/day8dlc.rpy:2719
    old "1. <You can't lie.>"
    new "1. <No puedes mentir.>"

    # game/beyond the bet/day8dlc.rpy:2722
    old "1. <But you say you remember this. That means it's true, right?>"
    new "1. <Pero dices que recuerdas eso. Eso significa que es cierto, ¿no?>"

    # game/beyond the bet/day8dlc.rpy:2725
    old "1. <And yet it's also not a memory you should have.>"
    new "1. <Y sin embargo, tampoco es un recuerdo que deberías tener.>"

    # game/beyond the bet/day8dlc.rpy:2736
    old "1. <I'm not trying to cause any alarm here, but do \nyou think....>"
    new "1. <No quiero alarmar a nadie, pero ¿tú crees que....>"

    # game/beyond the bet/day8dlc.rpy:2739
    old "1. <They could have altered your memories?>"
    new "1. <¿Pudieron haber alterado tus recuerdos?>"

    # game/beyond the bet/day8dlc.rpy:2747
    old "1. <It's just a guess. It's not like I have any evidence here.>"
    new "1. <Es solo una suposición. No es que tenga alguna prueba.>"

    # game/beyond the bet/day8dlc.rpy:2756
    old "1. <Sorry, you seem stressed now.>"
    new "1. <Perdón, ahora pareces estresado.>"

    # game/beyond the bet/day8dlc.rpy:2758
    old "2. <Are you okay?>"
    new "2. <¿Estás bien?>"

    # game/beyond the bet/day8dlc.rpy:2773
    old "1. <You think you'd be in trouble for having this \nconversation?>"
    new "1. <¿Crees que te meterías en problemas por tener esta conversación?>"

    # game/beyond the bet/day8dlc.rpy:2786
    old "1. <Sorry, Casper.>"
    new "1. <Lo siento, Casper.>"

    # game/beyond the bet/day8dlc.rpy:2788
    old "2. <Maybe I should have kept my thoughts to myself...>"
    new "2. <Quizás debí haberme guardado mis pensamientos...>"

    # game/beyond the bet/day8dlc.rpy:2809
    old "1. <You're going already?>"
    new "1. <¿Ya te vas?>"

    # game/beyond the bet/day8dlc.rpy:2817
    old "1. <Are you sure you're okay?>"
    new "1. <¿Seguro que estás bien?>"

    # game/beyond the bet/day8dlc.rpy:2819
    old "2. <I don't want to leave you alone...>"
    new "2. <No quiero dejarte solo...>"

    # game/beyond the bet/day8dlc.rpy:2879
    old "1. <CASPER?>"
    new "1. <¿CASPER?>"

    # game/beyond the bet/day8dlc.rpy:2883
    old "1. <What the hell are you doing here?>"
    new "1. <¿Qué demonios haces aquí?>"

    # game/beyond the bet/day8dlc.rpy:2885
    old "2. <Why do you always turn up out of nowhere?!>"
    new "2. <¡¿Por qué siempre apareces de la nada?!>"

    # game/beyond the bet/day8dlc.rpy:2889
    old "1. <Not that I mind...>"
    new "1. <No es que me importe...>"

    # game/beyond the bet/day8dlc.rpy:2892
    old "1. <Hey! You know how to use a door. That's impressive.>"
    new "1. <¡Oye! Sabes usar una puerta. Eso es impresionante.>"

    # game/beyond the bet/day8dlc.rpy:2897
    old "1. <What do you mean?!>"
    new "1. <¡¿Qué quieres decir?!>"

    # game/beyond the bet/day8dlc.rpy:2899
    old "1. <Where are we going?>"
    new "1. <¿A dónde vamos?>"

    # game/beyond the bet/day8dlc.rpy:2901
    old "2. <Right here? Casper, you gotta build up to that!>"
    new "2. <¿Aquí mismo? ¡Casper, tienes que ir preparando el terreno!>"

    # game/beyond the bet/day8dlc.rpy:2913
    old "1. <Like... a date?>"
    new "1. <¿O sea... una cita?>"

    # game/beyond the bet/day8dlc.rpy:2921
    old "1. <Of course I want to, but you could've warned me ahead of time!!!>"
    new "1. <¡¡¡Claro que quiero, pero podrías haberme avisado con antelación!!!>"

    # game/beyond the bet/day8dlc.rpy:2923
    old "1. <Then I could've dressed up or something.>"
    new "1. <Así habría podido arreglarme o algo.>"

    # game/beyond the bet/day8dlc.rpy:2933
    old "1. <Wow, what a gentleman.>"
    new "1. <Wow, qué caballero.>"

    # game/beyond the bet/day8dlc.rpy:2937
    old "2. <There's... nothing I want more right now.>"
    new "2. <No hay... nada que quiera más en este momento.>"

    # game/beyond the bet/day8dlc.rpy:2939
    old "1. <Man, who would've thought.>"
    new "1. <Uf, quién lo hubiera dicho.>"

    # game/beyond the bet/day8dlc.rpy:2942
    old "1. <Little old me going on a date with an immortal man who lives in the Underworld.>"
    new "1. <Mi humilde persona yendo a una cita con un hombre inmortal que vive en el Inframundo.>"

    # game/beyond the bet/day8dlc.rpy:2947
    old "3. <Is it... safe? For you?>"
    new "3. <¿Es... seguro? ¿Para ti?>"

    # game/beyond the bet/day8dlc.rpy:2955
    old "1. <Let's go, then. A date.>"
    new "1. <Vamos, entonces. Una cita.>"

    # game/beyond the bet/day8dlc.rpy:2961
    old "1. <Don't wanna use the elevator?>"
    new "1. <¿No quieres usar el ascensor?>"

    # game/beyond the bet/day8dlc.rpy:2971
    old "1. <Right.>"
    new "1. <Cierto.>"

    # game/beyond the bet/day8dlc.rpy:2973
    old "2. <I forgot about that.>"
    new "2. <Se me había olvidado eso.>"

    # game/beyond the bet/day8dlc.rpy:2981
    old "1. <Right. Big evil hunks of metal.>"
    new "1. <Cierto. Enormes bloques de metal malignos.>"

    # game/beyond the bet/day8dlc.rpy:2984
    old "1. <Well, I need to get my steps up anyway.>"
    new "1. <Bueno, de todos modos necesito sumar pasos.>"

    # game/beyond the bet/day8dlc.rpy:2986
    old "2. <I.... hate... stairs.... but I'll do it for you.>"
    new "2. <Odio... las... escaleras.... pero lo haré por ti.>"

    # game/beyond the bet/day8dlc.rpy:2989
    old "3. <Race you to the bottom!>"
    new "3. <¡A ver quién llega primero abajo!>"

    # game/beyond the bet/day8dlc.rpy:2998
    old "1. <Last one to the bottom is a rotten egg!>"
    new "1. <¡El último en llegar abajo es un huevo podrido!>"

    # game/beyond the bet/day8dlc.rpy:3032
    old "1. <What does?>"
    new "1. <¿Qué cosa?>"

    # game/beyond the bet/day8dlc.rpy:3036
    old "1. <It'd suit you too, you know.>"
    new "1. <A ti también te quedaría bien, ¿sabes?>"

    # game/beyond the bet/day8dlc.rpy:3039
    old "1. <How about giving it a try?>"
    new "1. <¿Qué tal si lo intentas?>"

    # game/beyond the bet/day8dlc.rpy:3043
    old "1. <Not your kinda place after all?>"
    new "1. <¿No es tu estilo, entonces?>"

    # game/beyond the bet/day8dlc.rpy:3057
    old "1. <It's yes?>"
    new "1. <¿Es un sí?>"

    # game/beyond the bet/day8dlc.rpy:3062
    old "1. <That doesn't make any sense.>"
    new "1. <Eso no tiene ningún sentido.>"

    # game/beyond the bet/day8dlc.rpy:3071
    old "1. <Right, of course.>"
    new "1. <Claro, por supuesto.>"

    # game/beyond the bet/day8dlc.rpy:3075
    old "1. <This is a perfect opportunity to introduce you to little mortal delights!>"
    new "1. <¡Esta es una oportunidad perfecta para presentarte los pequeños placeres mortales!>"

    # game/beyond the bet/day8dlc.rpy:3080
    old "1. <Casper!>"
    new "1. <¡Casper!>"

    # game/beyond the bet/day8dlc.rpy:3082
    old "2. <Wow, look who's being dirty now.>"
    new "2. <Wow, mira quién se pone pervertido ahora.>"

    # game/beyond the bet/day8dlc.rpy:3096
    old "1. <Behold!>"
    new "1. <¡Contempla!>"

    # game/beyond the bet/day8dlc.rpy:3098
    old "2. <Ta-da!>"
    new "2. <¡Tachán!>"

    # game/beyond the bet/day8dlc.rpy:3101
    old "1. <This is as close to a party game as we'll find here, I think.>"
    new "1. <Creo que esto es lo más parecido a un juego de fiesta que vamos a encontrar aquí.>"

    # game/beyond the bet/day8dlc.rpy:3104
    old "1. <Let's try it!>"
    new "1. <¡Probémoslo!>"

    # game/beyond the bet/day8dlc.rpy:3107
    old "1. <I bet I can pop more than you.>"
    new "1. <Apuesto a que puedo reventar más que tú.>"

    # game/beyond the bet/day8dlc.rpy:3117
    old "1. <With darts, yeah.>"
    new "1. <Con dardos, sí.>"

    # game/beyond the bet/day8dlc.rpy:3125
    old "1. <You really do like bets.>"
    new "1. <De verdad te gustan las apuestas.>"

    # game/beyond the bet/day8dlc.rpy:3135
    old "1. <How about we keep it simple this time?>"
    new "1. <¿Qué tal si lo mantenemos simple esta vez?>"

    # game/beyond the bet/day8dlc.rpy:3138
    old "1. <Considering our last bet has gone a little... uh... you know.>"
    new "1. <Considerando que nuestra última apuesta ha salido un poco... eh... ya sabes.>"

    # game/beyond the bet/day8dlc.rpy:3144
    old "1. <Bragging rights! Whoever wins has a lifetime of bragging rights over it.>"
    new "1. <¡Derechos de presumir! El que gane tendrá derecho a presumir de por vida.>"

    # game/beyond the bet/day8dlc.rpy:3147
    old "1. <Simple enough, eh?>"
    new "1. <Bastante simple, ¿eh?>"

    # game/beyond the bet/day8dlc.rpy:3155
    old "1. <People are gonna look at you funny if you call me that, stupid.>"
    new "1. <La gente te va a mirar raro si me llamas así, tonto.>"

    # game/beyond the bet/day8dlc.rpy:3160
    old "1. <{i}Try to look TOUGH{/i}.>"
    new "1. <{i}Intentar parecer RUD[letra!c]{/i}.>"

    # game/beyond the bet/day8dlc.rpy:3162
    old "2. <{i}Try to look PREPARED FOR WAR{/i}.>"
    new "2. <{i}Intentar parecer list[letra] PARA LA GUERRA{/i}.>"

    # game/beyond the bet/day8dlc.rpy:3164
    old "3. <{i}Try to look effortlessly cool.... through putting in some effort{/i}.>"
    new "3. <{i}Intentar parecer genial sin esfuerzo.... esforzándote un poco{/i}.>"

    # game/beyond the bet/day8dlc.rpy:3172
    old "1. <You...!>"
    new "1. <¡Tú...!>"

    # game/beyond the bet/day8dlc.rpy:3174
    old "2. <You talk big, but we'll see.>"
    new "2. <Hablas mucho, pero ya veremos.>"

    # game/beyond the bet/day8dlc.rpy:3180
    old "1. <It was just a lucky shot!>"
    new "1. <¡Solo fue un tiro de suerte!>"

    # game/beyond the bet/day8dlc.rpy:3183
    old "2. <You better not be cheating!>"
    new "2. <¡Más te vale que no estés haciendo trampa!>"

    # game/beyond the bet/day8dlc.rpy:3188
    old "1. <Target acquired.>"
    new "1. <Objetivo fijado.>"

    # game/beyond the bet/day8dlc.rpy:3192
    old "1. <.........>"
    new "1. <.........>"

    # game/beyond the bet/day8dlc.rpy:3196
    old "3. <Well, here goes nothing!>"
    new "3. <Bueno, ¡aquí vamos, pase lo que pase!>"

    # game/beyond the bet/day8dlc.rpy:3202
    old "1. <{i}Take a little bow{/i}.>"
    new "1. <{i}Hacer una pequeña reverencia{/i}.>"

    # game/beyond the bet/day8dlc.rpy:3204
    old "2. <{i}Wink at Casper.{/i}>"
    new "2. <{i}Guiñarle un ojo a Casper.{/i}>"

    # game/beyond the bet/day8dlc.rpy:3207
    old "1. <Easy peasy lemon squeezy!>"
    new "1. <¡Pan comido!>"

    # game/beyond the bet/day8dlc.rpy:3209
    old "1. <I was made for this.>"
    new "1. <Nací para esto.>"

    # game/beyond the bet/day8dlc.rpy:3211
    old "2. <Honestly, am I a god?>"
    new "2. <Sinceramente, ¿tengo poderes divinos o qué?>"

    # game/beyond the bet/day8dlc.rpy:3213
    old "3. <The pressure is on now, huh?>"
    new "3. <Ahora hay presión, ¿eh?>"

    # game/beyond the bet/day8dlc.rpy:3215
    old "1. <Don't lose now, little reaper.>"
    new "1. <No pierdas ahora, parquita.>"

    # game/beyond the bet/day8dlc.rpy:3223
    old "1. <The same could be said for you.>"
    new "1. <Lo mismo podría decirse de ti.>"

    # game/beyond the bet/day8dlc.rpy:3225
    old "1. <Unless you {i}have{/i} done this before?>"
    new "1. <¿A menos que {i}ya{/i} hayas hecho esto antes?>"

    # game/beyond the bet/day8dlc.rpy:3228
    old "2. <I've played this plenty of times, Casper.>"
    new "2. <He jugado esto muchísimas veces, Casper.>"

    # game/beyond the bet/day8dlc.rpy:3230
    old "1. <I'm the ultimate balloon destroyer.>"
    new "1. <Soy el destructor de globos definitivo.>"

    # game/beyond the bet/day8dlc.rpy:3234
    old "3. <Well, I am feeling pretty lucky.>"
    new "3. <Bueno, siento que hoy la suerte me acompaña.>"

    # game/beyond the bet/day8dlc.rpy:3239
    old "1. <Don't be foolish! It's impossible!>"
    new "1. <¡No seas necio! ¡Es imposible!>"

    # game/beyond the bet/day8dlc.rpy:3241
    old "1. <I was trying to sound like you. Did it work?>"
    new "1. <Intentaba sonar como tú. ¿Funcionó?>"

    # game/beyond the bet/day8dlc.rpy:3243
    old "2. <Oho. Someone is picking up their game.>"
    new "2. <Oho. Alguien está subiendo el nivel.>"

    # game/beyond the bet/day8dlc.rpy:3245
    old "3. <This'll be funny when they both miss.>"
    new "3. <Esto será gracioso cuando ambos fallen.>"

    # game/beyond the bet/day8dlc.rpy:3247
    old "1. <Popcorn: prepared.>"
    new "1. <Palomitas: preparadas.>"

    # game/beyond the bet/day8dlc.rpy:3256
    old "1. <.......>"
    new "1. <.......>"

    # game/beyond the bet/day8dlc.rpy:3258
    old "1. <................>"
    new "1. <................>"

    # game/beyond the bet/day8dlc.rpy:3260
    old "2. <BOO.>"
    new "2. <BU.>"

    # game/beyond the bet/day8dlc.rpy:3263
    old "3. <Lalalala~>"
    new "3. <Lalalala~>"

    # game/beyond the bet/day8dlc.rpy:3265
    old "1. <Ohhhh I'm sooo noisy.....>"
    new "1. <Ohhhh hago tanto ruido.....>"

    # game/beyond the bet/day8dlc.rpy:3268
    old "1. <Don't miss....!>"
    new "1. <¡No falles....!>"

    # game/beyond the bet/day8dlc.rpy:3277
    old "1. <What a show off.>"
    new "1. <Qué presumido.>"

    # game/beyond the bet/day8dlc.rpy:3279
    old "1. <I'm sure it's easy!>"
    new "1. <¡Seguro que es fácil!>"

    # game/beyond the bet/day8dlc.rpy:3281
    old "2. <Well.>"
    new "2. <Bueno.>"

    # game/beyond the bet/day8dlc.rpy:3285
    old "3. <I... can absolutely do that too.>"
    new "3. <Yo... también puedo hacer eso, sin duda.>"

    # game/beyond the bet/day8dlc.rpy:3287
    old "1. <Marvel at my skills.>"
    new "1. <Maravíllate con mis habilidades.>"

    # game/beyond the bet/day8dlc.rpy:3289
    old "2. <Watch this.>"
    new "2. <Mira esto.>"

    # game/beyond the bet/day8dlc.rpy:3300
    old "1. <Ah... embarrassing...>"
    new "1. <Ah... qué vergüenza...>"

    # game/beyond the bet/day8dlc.rpy:3304
    old "2. <I... I missed on purpose! Obviously!>"
    new "2. <¡Yo... fallé a propósito! ¡Obviamente!>"

    # game/beyond the bet/day8dlc.rpy:3306
    old "1. <Can't have you losing your first festival game, after all.>"
    new "1. <No podía dejar que perdieras tu primer juego de festival, después de todo.>"

    # game/beyond the bet/day8dlc.rpy:3310
    old "1. <Noooo. Never.>"
    new "1. <Noooo. Nunca.>"

    # game/beyond the bet/day8dlc.rpy:3312
    old "2. <I don't mind you having bragging rights.>"
    new "2. <No me importa que tengas derecho a presumir.>"

    # game/beyond the bet/day8dlc.rpy:3314
    old "1. <You looked so serious about winning.>"
    new "1. <Parecías tan serio en querer ganar.>"

    # game/beyond the bet/day8dlc.rpy:3317
    old "1. <I mean, you're losing our other bet, so it's only fair.>"
    new "1. <O sea, estás perdiendo nuestra otra apuesta, así que es justo.>"

    # game/beyond the bet/day8dlc.rpy:3322
    old "1. <All the time, yes.>"
    new "1. <Todo el tiempo, sí.>"

    # game/beyond the bet/day8dlc.rpy:3324
    old "2. <Not about anything serious.>"
    new "2. <No sobre nada serio.>"

    # game/beyond the bet/day8dlc.rpy:3326
    old "3. <Hah, me? Never!>"
    new "3. <Ja, ¿yo? ¡Nunca!>"

    # game/beyond the bet/day8dlc.rpy:3332
    old "1. <Don't get too used to the feeling, little reaper.>"
    new "1. <No te acostumbres demasiado a esa sensación, parquita.>"

    # game/beyond the bet/day8dlc.rpy:3358
    old "1. <Pretty, huh?>"
    new "1. <Bonito, ¿eh?>"

    # game/beyond the bet/day8dlc.rpy:3362
    old "1. <I knew you'd like them.>"
    new "1. <Sabía que te gustarían.>"

    # game/beyond the bet/day8dlc.rpy:3364
    old "2. <What do you think?>"
    new "2. <¿Qué te parece?>"

    # game/beyond the bet/day8dlc.rpy:3377
    old "1. <All the good things are.>"
    new "1. <Todas las cosas buenas lo son.>"

    # game/beyond the bet/day8dlc.rpy:3382
    old "1. <But we keep the memory of them forever.>"
    new "1. <Pero conservamos el recuerdo de ellas para siempre.>"

    # game/beyond the bet/day8dlc.rpy:3389
    old "1. <Surely you have festivals in the Underworld, too.>"
    new "1. <Seguro que ustedes también tienen festivales en el Inframundo.>"

    # game/beyond the bet/day8dlc.rpy:3391
    old "2. <You've really never been to one?>"
    new "2. <¿De verdad nunca has ido a uno?>"

    # game/beyond the bet/day8dlc.rpy:3400
    old "1. <I should be thanking you, Casper.>"
    new "1. <Debería agradecerte yo, Casper.>"

    # game/beyond the bet/day8dlc.rpy:3403
    old "1. <You're the reason we're here.>"
    new "1. <Tú eres la razón por la que estamos aquí.>"

    # game/beyond the bet/day8dlc.rpy:3410
    old "1. <[beautiful!c]?>"
    new "1. <[beautiful!c!t]?>"

    # game/beyond the bet/day8dlc.rpy:3412
    old "2. <Amazing?>"
    new "2. <¿Increíble?>"

    # game/beyond the bet/day8dlc.rpy:3414
    old "3. <The best mortal in the whole world?>"
    new "3. <¿[arti!c] mejor mortal del mundo entero?>"

    # game/beyond the bet/day8dlc.rpy:3421
    old "1. <I'm good at playing hard to get, hey?>"
    new "1. <Se me da bien hacerme de rogar, ¿eh?>"

    # game/beyond the bet/day8dlc.rpy:3423
    old "2. <Sorry, I'm an overachiever.>"
    new "2. <Perdón, siempre doy más de lo esperado.>"

    # game/beyond the bet/day8dlc.rpy:3429
    old "1. <You like it, though.>"
    new "1. <Aunque te gusta.>"

    # game/beyond the bet/day8dlc.rpy:3439
    old "1. <Is something wrong?>"
    new "1. <¿Pasa algo?>"

    # game/beyond the bet/day8dlc.rpy:3443
    old "3. <What now?>"
    new "3. <¿Y ahora qué?>"

    # game/beyond the bet/day8dlc.rpy:3447
    old "1. <That sounds dangerous.>"
    new "1. <Eso suena peligroso.>"

    # game/beyond the bet/day8dlc.rpy:3449
    old "1. <You're leaving me hanging here, Grim.>"
    new "1. <Me estás dejando en suspenso, Parca.>"

    # game/beyond the bet/day8dlc.rpy:3451
    old "2. <Thoughts of...?>"
    new "2. <¿Pensamientos de...?>"

    # game/beyond the bet/day8dlc.rpy:3460
    old "1. <You mean...?>"
    new "1. <¿Quieres decir...?>"

    # game/beyond the bet/day8dlc.rpy:3479
    old "1. <...I love you, too.>"
    new "1. <...Yo también te amo.>"

    # game/beyond the bet/day8dlc.rpy:3483
    old "1. <I said I love you. And I do.>"
    new "1. <Dije que te amo. Y es verdad.>"

    # game/beyond the bet/day8dlc.rpy:3485
    old "2. <I feel the same. You know that.>"
    new "2. <Siento lo mismo. Lo sabes.>"

    # game/beyond the bet/day8dlc.rpy:3488
    old "1. <Even if I tried, I couldn't stay away from you.>"
    new "1. <Aunque lo intentara, no podría alejarme de ti.>"

    # game/beyond the bet/day8dlc.rpy:3491
    old "1. <I've never felt a love like this, but I'm sure that's what it is.>"
    new "1. <Nunca he sentido un amor así, pero no tengo dudas de que eso es lo que es.>"

    # game/beyond the bet/day8dlc.rpy:3494
    old "1. <I love you. Really.>"
    new "1. <Te amo. De verdad.>"

    # game/beyond the bet/day8dlc.rpy:3496
    old "3. <Do you really love me?>"
    new "3. <¿De verdad me amas?>"

    # game/beyond the bet/day8dlc.rpy:3500
    old "1. <Good. Because I love you too. So much.>"
    new "1. <Bien. Porque yo también te amo. Muchísimo.>"

    # game/beyond the bet/day8dlc.rpy:3507
    old "1. <Don't go getting destroyed on me now, Casper.>"
    new "1. <No te vayas a destruir ahora, Casper.>"

    # game/beyond the bet/day8dlc.rpy:3513
    old "1. <...Say it one more time, please?>"
    new "1. <...¿Puedes decirlo una vez más, por favor?>"

    # game/beyond the bet/day8dlc.rpy:3519
    old "1. <I can't tell you how much I've wanted to hear you say that.>"
    new "1. <No puedo decirte cuánto he querido oírte decir eso.>"

    # game/beyond the bet/day8dlc.rpy:3521
    old "1. <I was hoping, too. Without even realizing I was hoping.>"
    new "1. <Yo también tenía esperanzas. Sin siquiera darme cuenta de que las tenía.>"

    # game/beyond the bet/day8dlc.rpy:3524
    old "1. <This feels like a dream.>"
    new "1. <Esto se siente como un sueño.>"

    # game/beyond the bet/day8dlc.rpy:3526
    old "2. <I feel like I've known for awhile, but...>"
    new "2. <Siento que lo sabía desde hace un tiempo, pero...>"

    # game/beyond the bet/day8dlc.rpy:3528
    old "1. <Hearing you say it aloud...>"
    new "1. <Oírte decirlo en voz alta...>"

    # game/beyond the bet/day8dlc.rpy:3531
    old "1. <It feels special. Thank you, Casper.>"
    new "1. <Se siente especial. Gracias, Casper.>"

    # game/beyond the bet/day8dlc.rpy:3533
    old "3. <I've dreamt of a moment like this.>"
    new "3. <He soñado con un momento como este.>"

    # game/beyond the bet/day8dlc.rpy:3535
    old "1. <And yet, this is better than I ever could've imagined.>"
    new "1. <Y aun así, esto es mejor de lo que jamás habría imaginado.>"

    # game/beyond the bet/day8dlc.rpy:3541
    old "1. <It shouldn't be.>"
    new "1. <No debería serlo.>"

    # game/beyond the bet/day8dlc.rpy:3548
    old "1. <I'm sure between the two of our huge brains, we can work something out.>"
    new "1. <Seguro que entre nuestros dos enormes cerebros podemos encontrar una solución.>"

    # game/beyond the bet/day8dlc.rpy:3552
    old "1. <... Are you going to be in trouble?>"
    new "1. <... ¿Te vas a meter en problemas?>"

    # game/beyond the bet/day8dlc.rpy:3555
    old "1. <Are you breaking rules, if we're together?>"
    new "1. <¿Estás rompiendo reglas si estamos juntos?>"

    # game/beyond the bet/day8dlc.rpy:3561
    old "1. <We can be careful.>"
    new "1. <Podemos ser cuidadosos.>"

    # game/beyond the bet/day8dlc.rpy:3566
    old "1. <No, but I can try.>"
    new "1. <No, pero puedo intentarlo.>"

    # game/beyond the bet/day8dlc.rpy:3568
    old "2. <Of course, careful {i}is{/i} one of my middle names, after all.>"
    new "2. <Por supuesto, la cautela {i}es{/i} uno de mis segundos nombres, después de todo.>"

    # game/beyond the bet/day8dlc.rpy:3574
    old "1. <You know, this is the best date I've ever been on.>"
    new "1. <Sabes, esta es la mejor cita a la que he ido.>"

    # game/beyond the bet/day8dlc.rpy:3577
    old "1. <Truly.>"
    new "1. <De verdad.>"

    # game/beyond the bet/day8dlc.rpy:3582
    old "1. <I got to witness you experiencing so much for the first time. That's the best.>"
    new "1. <Pude presenciar cómo vivías tantas cosas por primera vez. Eso es lo mejor.>"

    # game/beyond the bet/day8dlc.rpy:3585
    old "1. <And, well, I'm just glad to be here with you for the time we have.>"
    new "1. <Y, bueno, me alegra estar aquí contigo el tiempo que tengamos.>"

    # game/beyond the bet/day8dlc.rpy:3592
    old "1. <Do you wanna go back?>"
    new "1. <¿Quieres volver?>"

    # game/beyond the bet/day8dlc.rpy:3600
    old "1. <Unless you need to go?>"
    new "1. <¿A menos que necesites irte?>"

    # game/beyond the bet/day8dlc.rpy:3605
    old "1. <Stay the night with me, please?>"
    new "1. <Quédate a pasar la noche conmigo, por favor.>"

    # game/beyond the bet/day8dlc.rpy:3610
    old "1. <I just want to be beside you for a little longer. Please?>"
    new "1. <Solo quiero estar a tu lado un poco más. ¿Por favor?>"

    # game/beyond the bet/day8dlc.rpy:3614
    old "1. <Wow. How indecent, Casper. I bet you're thinking dirty thoughts right now.>"
    new "1. <Wow. Qué indecente, Casper. Seguro que estás pensando cosas pervertidas ahora mismo.>"

    # game/beyond the bet/day8dlc.rpy:3618
    old "1. <Haha. You like me so much, don't you?>"
    new "1. <Jaja. Te gusto tanto, ¿verdad?>"

    # game/beyond the bet/day8dlc.rpy:3620
    old "2. <You know I can't do that.>"
    new "2. <Sabes que no puedo hacer eso.>"

    # game/beyond the bet/day8dlc.rpy:3625
    old "2. <I want to feel you. Every part of you.>"
    new "2. <Quiero sentirte. Cada parte de ti.>"

    # game/beyond the bet/day8dlc.rpy:3631
    old "1. <...Then let's go.>"
    new "1. <...Entonces vamos.>"

    # game/beyond the bet/day8dlc.rpy:3634
    old "1. <I'll show you everything.>"
    new "1. <Te lo mostraré todo.>"

    # game/beyond the bet/day8dlc.rpy:3651
    old "1. <{i}Kiss Casper.{/i} (Begins NSFW scene)>"
    new "1. <{i}Besar a Casper.{/i} (Inicia escena NSFW)>"

    # game/beyond the bet/day8dlc.rpy:3653
    old "2. <{i}Sleep for the night.{/i} (Skips NSFW scene)>"
    new "2. <{i}Dormir por esta noche.{/i} (Omite la escena NSFW)>"

