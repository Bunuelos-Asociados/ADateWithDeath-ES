# TODO: Translation updated at 2026-10-15 18:36

# game/beyond the bet/undergroundorgend.rpy:4
translate Spanish dlc_undergroundend_start_99d59f27:

    # center_text "You dream of... fire."
    center_text "Sueñas con... fuego."

# game/beyond the bet/undergroundorgend.rpy:7
translate Spanish dlc_undergroundend_start_5ae38692:

    # center_text "But it's not scary."
    center_text "Pero no da miedo."

# game/beyond the bet/undergroundorgend.rpy:8
translate Spanish dlc_undergroundend_start_c107a8e8:

    # center_text "It's warm. Comfortable."
    center_text "Es cálido. Reconfortante."

# game/beyond the bet/undergroundorgend.rpy:9
translate Spanish dlc_undergroundend_start_078f45db:

    # center_text "It burns things away, yes, but it also makes something new."
    center_text "Consume cosas, sí, pero también crea algo nuevo."

# game/beyond the bet/undergroundorgend.rpy:10
translate Spanish dlc_undergroundend_start_437fd4fe:

    # center_text "You sit beside the fire, watching the old ways burn."
    center_text "Te sientas junto al fuego, viendo arder las viejas costumbres."

# game/beyond the bet/undergroundorgend.rpy:11
translate Spanish dlc_undergroundend_start_fa504c13:

    # center_text "Next to you is Casper. You watch the fire reflect in his eyes."
    center_text "A tu lado está Casper. Ves cómo el fuego se refleja en sus ojos."

# game/beyond the bet/undergroundorgend.rpy:12
translate Spanish dlc_undergroundend_start_87547998:

    # center_text "It feels right."
    center_text "Se siente correcto."

# game/beyond the bet/undergroundorgend.rpy:13
translate Spanish dlc_undergroundend_start_2a8fc19a:

    # center_text "He is change. You are change. So much will change, when the two of you work together."
    center_text "Él es cambio. Tú eres cambio. Tanto cambiará cuando los dos trabajen juntos."

# game/beyond the bet/undergroundorgend.rpy:45
translate Spanish dlc_undergroundend_start_6ea18ec8:

    # "You wake to the feeling of heat under you."
    "Despiertas con la sensación de calor bajo ti."

# game/beyond the bet/undergroundorgend.rpy:50
translate Spanish dlc_undergroundend_start_1ac7da31:

    # "Which is, honestly, not always the best feeling."
    "Lo cual, siendo sinceros, no siempre es la mejor sensación."

# game/beyond the bet/undergroundorgend.rpy:51
translate Spanish dlc_undergroundend_start_5ad14c9e:

    # "You remember a time in a past apartment you were renting where the place under yours went up in flames."
    "Recuerdas una vez, en un apartamento que alquilabas, en que el piso de abajo se incendió."

# game/beyond the bet/undergroundorgend.rpy:52
translate Spanish dlc_undergroundend_start_d0d317c1:

    # "Somehow, you didn't even get burned."
    "De alguna manera, ni siquiera te quemaste."

# game/beyond the bet/undergroundorgend.rpy:53
translate Spanish dlc_undergroundend_start_2ac2c1ae:

    # "Your eyes flutter open, and you see..."
    "Abres los ojos con un parpadeo y ves..."

# game/beyond the bet/undergroundorgend.rpy:54
translate Spanish dlc_undergroundend_start_9b5c8dc7:

    # "Someone's chest."
    "El pecho de alguien."

# game/beyond the bet/undergroundorgend.rpy:55
translate Spanish dlc_undergroundend_start_3c4e7b4a:

    # "Casper's chest."
    "El pecho de Casper."

# game/beyond the bet/undergroundorgend.rpy:56
translate Spanish dlc_undergroundend_start_d5d0e794:

    # "You're sleeping half on top of him!"
    "¡Estás durmiendo medio encima de él!"

# game/beyond the bet/undergroundorgend.rpy:67
translate Spanish dlc_undergroundend_start_511fe5c2:

    # GRC "Holy shit!"
    GRC "¡Mierda!"

# game/beyond the bet/undergroundorgend.rpy:69
translate Spanish dlc_undergroundend_start_aedde058:

    # GRC "Why in the nine hells are you yelling as soon as you open your eyes?!"
    GRC "¡¿Por qué en los nueve infiernos gritas apenas abres los ojos?!"

# game/beyond the bet/undergroundorgend.rpy:70
translate Spanish dlc_undergroundend_start_451ca1a1:

    # GRC "Do you always do that?"
    GRC "¿Siempre haces eso?"

# game/beyond the bet/undergroundorgend.rpy:71
translate Spanish dlc_undergroundend_start_0ab54a2f:

    # GRC "Awaken, then just YELL?"
    GRC "¿Despertar y ponerte a GRITAR sin más?"

# game/beyond the bet/undergroundorgend.rpy:86
translate Spanish dlc_undergroundend_start_8add7c3b:

    # GRC "I think we should NOT make it a thing."
    GRC "Creo que NO deberíamos convertirlo en costumbre."

# game/beyond the bet/undergroundorgend.rpy:87
translate Spanish dlc_undergroundend_start_38a1e06e:

    # GRC "I would much prefer you to not make me near jump out of my skin each and every morning."
    GRC "Preferiría mucho más que no me hicieras casi salirme de la piel cada santa mañana."

# game/beyond the bet/undergroundorgend.rpy:95
translate Spanish dlc_undergroundend_start_8a29bfdc:

    # GRC "Anything else."
    GRC "Cualquier otra cosa."

# game/beyond the bet/undergroundorgend.rpy:99
translate Spanish dlc_undergroundend_start_12fecb11:

    # "{i}You put your head back down and close your eyes, pretending to sleep.{/i}"
    "{i}Vuelves a apoyar la cabeza y cierras los ojos, fingiendo dormir.{/i}"

# game/beyond the bet/undergroundorgend.rpy:107
translate Spanish dlc_undergroundend_start_7e41287b:

    # GRC "I... "
    GRC "Yo... "

# game/beyond the bet/undergroundorgend.rpy:108
translate Spanish dlc_undergroundend_start_a0dac247:

    # GRC "You, I..."
    GRC "Tú, yo..."

# game/beyond the bet/undergroundorgend.rpy:109
translate Spanish dlc_undergroundend_start_5ef42e23:

    # GRC "That is... "
    GRC "Eso es... "

# game/beyond the bet/undergroundorgend.rpy:110
translate Spanish dlc_undergroundend_start_edf9d86e:

    # GRC "Great... news..."
    GRC "Excelentes... noticias..."

# game/beyond the bet/undergroundorgend.rpy:119
translate Spanish awake_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/undergroundorgend.rpy:129
translate Spanish afterawake_80c21d5a:

    # GRC "Perhaps... perhaps the yelling was fine..."
    GRC "Quizá... quizá los gritos no estaban tan mal..."

# game/beyond the bet/undergroundorgend.rpy:134
translate Spanish afterawake_9670b0b0:

    # GRC "That goal may only extend as far as today, if we do not work out a solution to our problems."
    GRC "Esa meta quizá solo llegue hasta hoy, si no encontramos una solución a nuestros problemas."

# game/beyond the bet/undergroundorgend.rpy:141
translate Spanish afterawake_48525368:

    # GRC "Ever the optimist."
    GRC "Siempre tan optimista."

# game/beyond the bet/undergroundorgend.rpy:143
translate Spanish afterawake_058ae1db:

    # GRC "I wonder if that is a mortal thing or a you thing."
    GRC "Me pregunto si es cosa de mortales o cosa tuya."

# game/beyond the bet/undergroundorgend.rpy:150
translate Spanish afterawake_8a58bba6:

    # GRC "H... hey..."
    GRC "E... eh..."

# game/beyond the bet/undergroundorgend.rpy:151
translate Spanish afterawake_3b05039d:

    # GRC "Watch where you're rubbing..."
    GRC "Cuidado con dónde frotas..."

# game/beyond the bet/undergroundorgend.rpy:153
translate Spanish afterawake_b46038b7:

    # GRC "Though, frankly, I could use the luck..."
    GRC "Aunque, siendo sincero, me vendría bien algo de suerte..."

# game/beyond the bet/undergroundorgend.rpy:161
translate Spanish afterawake_fb84f122:

    # GRC "I would love to tell you I not only solved all of our problems, but all of the world's problems, too."
    GRC "Me encantaría decirte que no solo resolví todos nuestros problemas, sino también los del mundo entero."

# game/beyond the bet/undergroundorgend.rpy:162
translate Spanish afterawake_f421e8ee:

    # GRC "But that would be a lie."
    GRC "Pero eso sería mentira."

# game/beyond the bet/undergroundorgend.rpy:164
translate Spanish afterawake_b9244896:

    # GRC "It's... complicated."
    GRC "Es... complicado."

# game/beyond the bet/undergroundorgend.rpy:166
translate Spanish afterawake_57aa41cf:

    # GRC "...You know, a long time ago, when I first became a Reaper, I had a friend."
    GRC "...Sabes, hace mucho tiempo, cuando me convertí en Parca, tuve un amigo."

# game/beyond the bet/undergroundorgend.rpy:170
translate Spanish afterawake_83dc6450:

    # GRC "Very funny."
    GRC "Muy gracioso."

# game/beyond the bet/undergroundorgend.rpy:177
translate Spanish afterawake_cb45fffb:

    # GRC "Well, thank you."
    GRC "Bueno, gracias."

# game/beyond the bet/undergroundorgend.rpy:180
translate Spanish afterawake_7ba8a353:

    # GRC "...Sometimes."
    GRC "...A veces."

# game/beyond the bet/undergroundorgend.rpy:181
translate Spanish afterawake_c8f55df4:

    # GRC "Sometimes having friends just makes life more complicated."
    GRC "A veces tener amigos solo complica más la vida."

# game/beyond the bet/undergroundorgend.rpy:184
translate Spanish afterawake_84a9a0b2:

    # GRC "I don't."
    GRC "No me caen bien."

# game/beyond the bet/undergroundorgend.rpy:185
translate Spanish afterawake_946ee283:

    # GRC "But it was a different time. "
    GRC "Pero eran otros tiempos. "

# game/beyond the bet/undergroundorgend.rpy:186
translate Spanish afterawake_ce74eb15:

    # GRC "I loathe to say this, but he was... 'not like other reapers'."
    GRC "Detesto decirlo, pero era... 'distinto a las otras parcas'."

# game/beyond the bet/undergroundorgend.rpy:187
translate Spanish afterawake_fb7b793c:

    # GRC "He was very... human, I suppose."
    GRC "Era muy... humano, supongo."

# game/beyond the bet/undergroundorgend.rpy:188
translate Spanish afterawake_14cbb985:

    # GRC "Anyway..."
    GRC "De todos modos..."

# game/beyond the bet/undergroundorgend.rpy:190
translate Spanish afterawake_33de9ee4:

    # GRC "He had a crush on a mortal."
    GRC "Estaba encaprichado con alguien mortal."

# game/beyond the bet/undergroundorgend.rpy:191
translate Spanish afterawake_8172a500:

    # GRC "It wasn't a big thing. He didn't want to run away with her or anything."
    GRC "No era nada grave. No quería huir con ella ni nada por el estilo."

# game/beyond the bet/undergroundorgend.rpy:193
translate Spanish afterawake_d8993117:

    # GRC "He just wanted to speak to her, spend time with her, just once."
    GRC "Solo quería hablar con ella, pasar tiempo con ella, aunque fuera una sola vez."

# game/beyond the bet/undergroundorgend.rpy:195
translate Spanish afterawake_c65a58a6:

    # GRC "He was terminated."
    GRC "Fue eliminado."

# game/beyond the bet/undergroundorgend.rpy:199
translate Spanish afterawake_32f44438:

    # GRC "Yes."
    GRC "Sí."

# game/beyond the bet/undergroundorgend.rpy:201
translate Spanish afterawake_786c37df:

    # GRC "My organization takes our rules very seriously."
    GRC "Mi organización se toma muy en serio sus reglas."

# game/beyond the bet/undergroundorgend.rpy:203
translate Spanish afterawake_fc190aa5:

    # GRC "The fact I have gotten away with breaking so many rules is... unheard of."
    GRC "Que me haya salido con la mía rompiendo tantas reglas es... inaudito."

# game/beyond the bet/undergroundorgend.rpy:208
translate Spanish afterawake_ec5a5b8e:

    # GRC "Because I'm a silly fool who fell in love with a mortal."
    GRC "Porque soy un necio sin remedio que se enamoró de alguien mortal."

# game/beyond the bet/undergroundorgend.rpy:212
translate Spanish afterawake_89e8213d:

    # GRC "I know."
    GRC "Lo sé."

# game/beyond the bet/undergroundorgend.rpy:214
translate Spanish afterawake_d0d9ce32:

    # GRC "I had a tough time when I first awakened as a Reaper."
    GRC "Lo pasé mal cuando desperté por primera vez como Parca."

# game/beyond the bet/undergroundorgend.rpy:215
translate Spanish afterawake_b7a484fc:

    # GRC "All of these rules, the coldness of taking souls..."
    GRC "Todas estas reglas, la frialdad de arrebatar almas..."

# game/beyond the bet/undergroundorgend.rpy:216
translate Spanish afterawake_b3ae54be:

    # GRC "It did not feel right to me."
    GRC "No me parecía correcto."

# game/beyond the bet/undergroundorgend.rpy:218
translate Spanish afterawake_271d5ade:

    # GRC "But I became numb over time."
    GRC "Pero con el tiempo me fui insensibilizando."

# game/beyond the bet/undergroundorgend.rpy:220
translate Spanish afterawake_4566b410:

    # GRC "I got used to it. Taking souls became methodical."
    GRC "Me acostumbré. Tomar almas se volvió algo metódico."

# game/beyond the bet/undergroundorgend.rpy:222
translate Spanish afterawake_3173cc6f:

    # GRC "As it was supposed to be."
    GRC "Como se suponía que debía ser."

# game/beyond the bet/undergroundorgend.rpy:224
translate Spanish afterawake_2bb204db:

    # GRC "I suppose my heart became ice, and you were the one who began to make it thaw."
    GRC "Supongo que mi corazón se volvió hielo, y fuiste tú quien empezó a derretirlo."

# game/beyond the bet/undergroundorgend.rpy:230
translate Spanish afterawake_b8511fca:

    # GRC "Perhaps you and I complete each other in ways neither of us truly understand."
    GRC "Quizá tú y yo nos complementamos de maneras que ninguno de los dos comprende del todo."

# game/beyond the bet/undergroundorgend.rpy:232
translate Spanish afterawake_a0e9d300:

    # GRC "I suppose I don't mind not understanding, if I can spend the rest of whatever time we have together."
    GRC "Supongo que no me importa no entenderlo, si puedo pasar juntos el tiempo que nos quede."

# game/beyond the bet/undergroundorgend.rpy:240
translate Spanish afterawake_f1d6a89f:

    # GRC "The hacker?"
    GRC "¿El hacker?"

# game/beyond the bet/undergroundorgend.rpy:252
translate Spanish afterawake_f7507b35:

    # GRC "What?"
    GRC "¿Qué?"

# game/beyond the bet/undergroundorgend.rpy:256
translate Spanish afterawake_0c3345a3:

    # "{i}You stand, then show the letter to Casper.{/i}"
    "{i}Te levantas y le muestras la carta a Casper.{/i}"

# game/beyond the bet/undergroundorgend.rpy:257
translate Spanish afterawake_2a68093b:

    # "{i}His frown becomes deeper and deeper as he reads the letter.{/i}"
    "{i}Su ceño se frunce cada vez más mientras lee la carta.{/i}"

# game/beyond the bet/undergroundorgend.rpy:259
translate Spanish afterawake_14301eed:

    # GRC "I hope you understand that there's no way I would let you go to this alone."
    GRC "Espero que entiendas que no hay manera de que te deje ir a esto sol[letra]."

# game/beyond the bet/undergroundorgend.rpy:267
translate Spanish afterawake_3e554653:

    # GRC "I just wish I knew who it was..."
    GRC "Ojalá supiera quién es..."

# game/beyond the bet/undergroundorgend.rpy:268
translate Spanish afterawake_ee7243c5:

    # GRC "And there's no mention of where this meeting will take place."
    GRC "Y no se menciona dónde tendrá lugar esta reunión."

# game/beyond the bet/undergroundorgend.rpy:273
translate Spanish afterawake_f034338d:

    # GRC "Hmm..."
    GRC "Hmm..."

# game/beyond the bet/undergroundorgend.rpy:274
translate Spanish afterawake_fb997ec2:

    # GRC "The library?"
    GRC "¿La biblioteca?"

# game/beyond the bet/undergroundorgend.rpy:275
translate Spanish afterawake_57bd21e0:

    # GRC "Though it's called a library, it's not public facing."
    GRC "Aunque se llame biblioteca, no está abierta al público."

# game/beyond the bet/undergroundorgend.rpy:276
translate Spanish afterawake_aac6c8fc:

    # GRC "There would be countless secrets, and thousands of years of records about our kind there."
    GRC "Habría incontables secretos y miles de años de registros sobre los de nuestra especie."

# game/beyond the bet/undergroundorgend.rpy:278
translate Spanish afterawake_17a25927:

    # GRC "It would have to be someone with enough clearance to be allowed in there..."
    GRC "Tendría que ser alguien con autorización suficiente para entrar ahí..."

# game/beyond the bet/undergroundorgend.rpy:282
translate Spanish afterawake_8da5b6d4:

    # GRC "This is obviously a trap."
    GRC "Esto es obviamente una trampa."

# game/beyond the bet/undergroundorgend.rpy:292
translate Spanish afterawake_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/undergroundorgend.rpy:293
translate Spanish afterawake_25eec6b4:

    # GRC "Fine."
    GRC "Está bien."

# game/beyond the bet/undergroundorgend.rpy:295
translate Spanish afterawake_50ea17e1:

    # GRC "But we will need to disguise you."
    GRC "Pero tendremos que disfrazarte."

# game/beyond the bet/undergroundorgend.rpy:301
translate Spanish afterawake_54fa329f:

    # GRC "Anyone walking beside me will draw attention, let alone a mortal who matches the description of my target."
    GRC "Cualquiera que camine a mi lado llamará la atención, y más aún alguien mortal que coincide con la descripción de mi objetivo."

# game/beyond the bet/undergroundorgend.rpy:302
translate Spanish afterawake_ce83dfe2:

    # GRC "Here."
    GRC "Aquí."

# game/beyond the bet/undergroundorgend.rpy:303
translate Spanish afterawake_35883173:

    # "{i}He throws you a black hooded cloak.{/i}"
    "{i}Te lanza una capa negra con capucha.{/i}"

# game/beyond the bet/undergroundorgend.rpy:304
translate Spanish afterawake_4b67fe57:

    # "{i}It smells like him, too.{/i}"
    "{i}También huele a él.{/i}"

# game/beyond the bet/undergroundorgend.rpy:305
translate Spanish afterawake_807f8a0b:

    # "{i}Like home.{/i}"
    "{i}Como a casa.{/i}"

# game/beyond the bet/undergroundorgend.rpy:306
translate Spanish afterawake_673374bd:

    # "{i}You quickly put it on.{/i}"
    "{i}Te la pones rápidamente.{/i}"

# game/beyond the bet/undergroundorgend.rpy:307
translate Spanish afterawake_e9da17d8:

    # GRC "There. With the hood, no one should be able to see your face easily."
    GRC "Listo. Con la capucha, nadie debería poder verte la cara con facilidad."

# game/beyond the bet/undergroundorgend.rpy:311
translate Spanish afterawake_96d495e0:

    # "{i}He reaches out, then tilts your chin slightly, so the light hits your features.{/i}"
    "{i}Extiende la mano y te inclina ligeramente la barbilla, de modo que la luz ilumine tus facciones.{/i}"

# game/beyond the bet/undergroundorgend.rpy:313
translate Spanish afterawake_7c9ce686:

    # GRC "Every moment I do not see it, I miss it."
    GRC "Cada momento que no la veo, la extraño."

# game/beyond the bet/undergroundorgend.rpy:314
translate Spanish afterawake_df6fac7e:

    # GRC "It's truly a problem."
    GRC "Es realmente un problema."

# game/beyond the bet/undergroundorgend.rpy:316
translate Spanish afterawake_af3848ab:

    # GRC "You get on my nerves immensely."
    GRC "Me sacas de quicio enormemente."

# game/beyond the bet/undergroundorgend.rpy:323
translate Spanish afterawake_c0b55a51:

    # GRC "Fortunately or unfortunately."
    GRC "Por fortuna o por desgracia."

# game/beyond the bet/undergroundorgend.rpy:325
translate Spanish afterawake_f69af645:

    # GRC "Come on. If we get there before your mysterious reaper, then perhaps we can take a look around."
    GRC "Vamos. Si llegamos antes que tu misteriosa parca, quizá podamos echar un vistazo."

# game/beyond the bet/undergroundorgend.rpy:327
translate Spanish afterawake_27df96f9:

    # GRC "And, Sunshine?"
    GRC "¿Y, Solecito?"

# game/beyond the bet/undergroundorgend.rpy:332
translate Spanish afterawake_7c89acf7:

    # GRC "I... do not know if you and I were destined to meet, or if everything is just one big coincidence, but..." id afterawake_7c89acf7
    GRC "Yo... no sé si tú y yo estábamos destinados a conocernos, o si todo es una gran coincidencia, pero..." id afterawake_7c89acf7

# game/beyond the bet/undergroundorgend.rpy:333
translate Spanish afterawake_da4cf3d6:

    # GRC "No matter what, in this lifetime or the next I'm said not to have, I would always choose you."
    GRC "Pase lo que pase, en esta vida o en la siguiente que dicen que no tengo, siempre te elegiría a ti."

# game/beyond the bet/undergroundorgend.rpy:334
translate Spanish afterawake_74fdf5fd:

    # GRC "Through any hardship. No matter the trouble I would get myself into."
    GRC "A través de cualquier adversidad. Sin importar en qué problemas me metiera."

# game/beyond the bet/undergroundorgend.rpy:336
translate Spanish afterawake_3cf48863:

    # GRC "You would always be my choice."
    GRC "Siempre serías mi elección."

# game/beyond the bet/undergroundorgend.rpy:337
translate Spanish afterawake_7a733696:

    # GRC "I... love you."
    GRC "Yo... te amo."

# game/beyond the bet/undergroundorgend.rpy:362
translate Spanish afterawake_0848197a:

    # "You keep your head down as the two of you head out into the busy streets of the Underworld."
    "Mantienes la cabeza gacha mientras los dos salen a las concurridas calles del Inframundo."

# game/beyond the bet/undergroundorgend.rpy:364
translate Spanish afterawake_5b08c3c3:

    # "You're surprised at how 'human' it feels - even if it is bigger than any city you've ever seen."
    "Te sorprende lo 'humano' que se siente, aunque sea más grande que cualquier ciudad que hayas visto."

# game/beyond the bet/undergroundorgend.rpy:365
translate Spanish afterawake_17e35a05:

    # "Casper reaches out his hand and takes yours in his."
    "Casper extiende la mano y toma la tuya en la suya."

# game/beyond the bet/undergroundorgend.rpy:366
translate Spanish afterawake_ebf6783f:

    # "It's warm."
    "Es cálida."

# game/beyond the bet/undergroundorgend.rpy:367
translate Spanish afterawake_788beee8:

    # "Despite being morning time, there's no sun in the sky. Above you is just blackness, without a single star."
    "Aunque es de mañana, no hay sol en el cielo. Sobre ti solo hay oscuridad, sin una sola estrella."

# game/beyond the bet/undergroundorgend.rpy:368
translate Spanish afterawake_a4abcb53:

    # "The atmosphere is cold, but the spot where you're touching Casper is anything but."
    "El ambiente es frío, pero el punto donde tocas a Casper es todo lo contrario."

# game/beyond the bet/undergroundorgend.rpy:369
translate Spanish afterawake_9d56ace1:

    # "It feels like your lifeline in this strange world."
    "Se siente como tu salvavidas en este mundo extraño."

# game/beyond the bet/undergroundorgend.rpy:370
translate Spanish afterawake_42df6023:

    # "Quickly, the two of you find yourself outside the library."
    "En poco tiempo, los dos se encuentran frente a la biblioteca."

# game/beyond the bet/undergroundorgend.rpy:371
translate Spanish afterawake_44866125:

    # "From the outside, the library is a large and imposing building, with wide steps and tall columns."
    "Desde fuera, la biblioteca es un edificio grande e imponente, con amplias escalinatas y altas columnas."

# game/beyond the bet/undergroundorgend.rpy:372
translate Spanish afterawake_8dfefc90:

    # "There's also not a single person around."
    "Tampoco hay ni una sola persona alrededor."

# game/beyond the bet/undergroundorgend.rpy:373
translate Spanish afterawake_1a55b326:

    # "The closer you got to this building, the more the crowds began to thin out."
    "Cuanto más te acercabas a este edificio, más se iba despejando la multitud."

# game/beyond the bet/undergroundorgend.rpy:374
translate Spanish afterawake_7aaa1ef3:

    # "The two of you walk up the stairs, and you scan your keycard, then try the door."
    "Suben las escaleras, pasas tu tarjeta de acceso y pruebas la puerta."

# game/beyond the bet/undergroundorgend.rpy:375
translate Spanish afterawake_163b28af:

    # "It comes open."
    "Se abre."

# game/beyond the bet/undergroundorgend.rpy:382
translate Spanish afterawake_98889ac1:

    # "The library is... immense. Like Casper said, calling it a library is an understatement."
    "La biblioteca es... inmensa. Como dijo Casper, llamarla biblioteca se queda corto."

# game/beyond the bet/undergroundorgend.rpy:383
translate Spanish afterawake_a50a29b7:

    # "From the outside, the building was imposing, and the inside is no different."
    "Desde fuera el edificio era imponente, y el interior no es distinto."

# game/beyond the bet/undergroundorgend.rpy:384
translate Spanish afterawake_5be484cf:

    # "A high ceiling looms above you, and the hall stretches forward."
    "Un techo altísimo se cierne sobre ti y el salón se extiende hacia delante."

# game/beyond the bet/undergroundorgend.rpy:385
translate Spanish afterawake_b9897097:

    # "Bookcases tower high against each and every wall, and the books all look old, thick, and heavy from a distance."
    "Las estanterías se alzan contra todas y cada una de las paredes, y desde lejos todos los libros se ven viejos, gruesos y pesados."

# game/beyond the bet/undergroundorgend.rpy:386
translate Spanish afterawake_67954452:

    # "You could spend a lifetime in here, and it still wouldn't be enough time."
    "Podrías pasar una vida entera aquí y aun así no sería suficiente."

# game/beyond the bet/undergroundorgend.rpy:396
translate Spanish afterawake_ddcaa900:

    # GRC "It's... huge."
    GRC "Es... enorme."

# game/beyond the bet/undergroundorgend.rpy:400
translate Spanish afterawake_0bced4a5:

    # GRC "I do not know who 'she' is."
    GRC "No sé quién es 'ella'."

# game/beyond the bet/undergroundorgend.rpy:401
translate Spanish afterawake_0a490a3d:

    # GRC "And why did she say it?"
    GRC "¿Y por qué lo dijo?"

# game/beyond the bet/undergroundorgend.rpy:406
translate Spanish afterawake_38585712:

    # GRC "Where is the funny part?"
    GRC "¿Dónde está la gracia?"

# game/beyond the bet/undergroundorgend.rpy:409
translate Spanish afterawake_695f69a7:

    # GRC "Just slightly."
    GRC "Solo un poco."

# game/beyond the bet/undergroundorgend.rpy:411
translate Spanish afterawake_4f1abb81:

    # GRC "I couldn't even guess how many secrets sit here, gathering dust..."
    GRC "Ni siquiera podría adivinar cuántos secretos hay aquí, acumulando polvo..."

# game/beyond the bet/undergroundorgend.rpy:415
translate Spanish afterawake_768dd78b:

    # GRC "With...?"
    GRC "¿Con...?"

# game/beyond the bet/undergroundorgend.rpy:429
translate Spanish afterawake_5a03e9fb:

    # GRC "I am condemned to second place..."
    GRC "Estoy condenado al segundo lugar..."

# game/beyond the bet/undergroundorgend.rpy:431
translate Spanish afterawake_e2d0b8ec:

    # "{i}Casper's eyes scan the room, overwhelmed.{/i}"
    "{i}Los ojos de Casper recorren la sala, abrumados.{/i}"

# game/beyond the bet/undergroundorgend.rpy:433
translate Spanish afterawake_405f2c32:

    # GRC "With just the two of us, I don't see how we'll be able to get through even a quarter of all this..."
    GRC "Siendo solo los dos, no veo cómo vamos a poder revisar ni una cuarta parte de todo esto..."

# game/beyond the bet/undergroundorgend.rpy:438
translate Spanish afterawake_aaf9587f:

    # GRC "You really cannot get enough of your little bets, can you?"
    GRC "De verdad no te cansas de tus apuestitas, ¿cierto?"

# game/beyond the bet/undergroundorgend.rpy:443
translate Spanish afterawake_25eec6b4_1:

    # GRC "Fine."
    GRC "Está bien."

# game/beyond the bet/undergroundorgend.rpy:444
translate Spanish afterawake_0832e403:

    # GRC "And what does the winner get?"
    GRC "¿Y qué gana el ganador?"

# game/beyond the bet/undergroundorgend.rpy:452
translate Spanish afterawake_fc9dcd4b:

    # GRC "A wish?"
    GRC "¿Un deseo?"

# game/beyond the bet/undergroundorgend.rpy:459
translate Spanish afterawake_1782c027:

    # GRC "Give me an example."
    GRC "Dame un ejemplo."

# game/beyond the bet/undergroundorgend.rpy:463
translate Spanish afterawake_9503c735:

    # GRC "That sounds terrible."
    GRC "Eso suena terrible."

# game/beyond the bet/undergroundorgend.rpy:466
translate Spanish afterawake_118ebac4:

    # GRC "You assume you'll win!"
    GRC "¡Das por hecho que ganarás!"

# game/beyond the bet/undergroundorgend.rpy:468
translate Spanish afterawake_ec040548:

    # GRC "You came up with the idea!"
    GRC "¡Fuiste tú quien tuvo la idea!"

# game/beyond the bet/undergroundorgend.rpy:470
translate Spanish afterawake_3ecb891b:

    # GRC "What I will wish for is a secret. "
    GRC "Lo que desearé es un secreto. "

# game/beyond the bet/undergroundorgend.rpy:471
translate Spanish afterawake_40c061a9:

    # GRC "Don't worry, you'll know soon enough."
    GRC "No te preocupes, lo sabrás muy pronto."

# game/beyond the bet/undergroundorgend.rpy:486
translate Spanish afterawake_46566fd2:

    # "{i}The two of you split up - Casper goes to the rightside wall, while you go to the left.{/i}"
    "{i}Se separan: Casper va hacia la pared derecha y tú hacia la izquierda.{/i}"

# game/beyond the bet/undergroundorgend.rpy:487
translate Spanish afterawake_7475e19b:

    # "{i}The amount of work is... immense. It's hard not to feel overwhelmed, but you continue on.{/i}"
    "{i}La cantidad de trabajo es... inmensa. Es difícil no sentir que todo te supera, pero sigues adelante.{/i}"

# game/beyond the bet/undergroundorgend.rpy:488
translate Spanish afterawake_2bca3a9c:

    # "{i}Not all of the books here are in languages you can understand - in fact, most aren't.{/i}"
    "{i}No todos los libros están en idiomas que puedas entender; de hecho, la mayoría no.{/i}"

# game/beyond the bet/undergroundorgend.rpy:489
translate Spanish afterawake_0f94dd15:

    # "{i}Still, you do your best, flipping through the pages, looking for anything that might help.{/i}"
    "{i}Aun así, haces lo que puedes, hojeando las páginas en busca de cualquier cosa que pueda ayudar.{/i}"

# game/beyond the bet/undergroundorgend.rpy:490
translate Spanish afterawake_28a49735:

    # "{i}There's a lot of boring books and journals here - accounts of past Reapers, and how they handled their jobs, as well as notes on expenditure and the management of the Underworld.{/i}"
    "{i}Hay muchísimos libros y diarios aburridos: relatos de parcas anteriores y de cómo llevaron a cabo su trabajo, además de notas sobre gastos y la administración del Inframundo.{/i}"

# game/beyond the bet/undergroundorgend.rpy:495
translate Spanish afterawake_9015aff9:

    # GRC "No, nothing that could help us, but..."
    GRC "No, nada que pueda ayudarnos, pero..."

# game/beyond the bet/undergroundorgend.rpy:496
translate Spanish afterawake_17d44bae:

    # GRC "There are many secrets in these halls. "
    GRC "Hay muchos secretos en estas salas. "

# game/beyond the bet/undergroundorgend.rpy:498
translate Spanish afterawake_1862def2:

    # GRC "Enough to bring down my entire organization, and more, I'm sure."
    GRC "Suficientes para derribar a toda mi organización, y más, estoy seguro."

# game/beyond the bet/undergroundorgend.rpy:501
translate Spanish afterawake_4327afc5:

    # "{i}You continue searching, pulling books from shelves, scanning the spines, the pages, the covers.{/i}"
    "{i}Sigues buscando, sacando libros de los estantes, revisando los lomos, las páginas, las cubiertas.{/i}"

# game/beyond the bet/undergroundorgend.rpy:502
translate Spanish afterawake_ef7c41a4:

    # "{i}And you notice something strange behind the book you just pulled out.{/i}"
    "{i}Y notas algo extraño detrás del libro que acabas de sacar.{/i}"

# game/beyond the bet/undergroundorgend.rpy:503
translate Spanish afterawake_06d3ba1a:

    # "{i}A tiny gap in the otherwise solid walls.{/i}"
    "{i}Una pequeña rendija en las paredes por lo demás macizas.{/i}"

# game/beyond the bet/undergroundorgend.rpy:504
translate Spanish afterawake_61697ed9:

    # "{i}You frown, then pull a few more books from their places.{/i}"
    "{i}Frunces el ceño y sacas algunos libros más de su sitio.{/i}"

# game/beyond the bet/undergroundorgend.rpy:505
translate Spanish afterawake_e71a8cd8:

    # "{i}Reaching into the gap, you push aside a hidden panel, and a section of the wall slides away.{/i}"
    "{i}Metes la mano en la rendija, empujas un panel oculto y una sección de la pared se desliza.{/i}"

# game/beyond the bet/undergroundorgend.rpy:506
translate Spanish afterawake_a90c383c:

    # "{i}You see a book."
    "{i}Ves un libro."

# game/beyond the bet/undergroundorgend.rpy:511
translate Spanish afterawake_6734c129:

    # "{i}You blow on the book. Nothing seems to happen.{/i}"
    "{i}Soplas el libro. Parece que no pasa nada.{/i}"

# game/beyond the bet/undergroundorgend.rpy:512
translate Spanish afterawake_d8732aba:

    # "{i}You wait a few more seconds before deciding maybe it isn't booby trapped.{/i}"
    "{i}Esperas unos segundos más antes de decidir que quizá no tiene trampa.{/i}"

# game/beyond the bet/undergroundorgend.rpy:517
translate Spanish afterawake_c3f00cc2:

    # "{i}You flip it over in your hands. It look incredibly old and fragile.{/i}"
    "{i}Lo giras entre tus manos. Se ve increíblemente viejo y frágil.{/i}"

# game/beyond the bet/undergroundorgend.rpy:518
translate Spanish afterawake_3d6ecd1b:

    # "{i}But the cover is blank.{/i}"
    "{i}Pero la cubierta está en blanco.{/i}"

# game/beyond the bet/undergroundorgend.rpy:519
translate Spanish afterawake_d8b4fa56:

    # "{i}In fact, it does look more like a journal than a book. Flicking through the delicate pages, its all handwritten.{/i}"
    "{i}De hecho, parece más un diario que un libro. Al pasar las frágiles páginas, ves que todo está escrito a mano.{/i}"

# game/beyond the bet/undergroundorgend.rpy:523
translate Spanish afterawake_c2c8088c:

    # "{i}You open the book to the first page, and read the words:{/i}"
    "{i}Abres el libro en la primera página y lees las palabras:{/i}"

# game/beyond the bet/undergroundorgend.rpy:524
translate Spanish afterawake_03bc8c34:

    # "'Humans spread like wildfire around the realm. Struggles have turned to impossibility, and there are no longer enough of us to deal with them. I have been tasked with finding a solution.'"
    "'Los humanos se extienden como un incendio por el reino. Las dificultades se han vuelto imposibles y ya no somos suficientes para ocuparnos de ellas. Se me ha encomendado encontrar una solución.'"

# game/beyond the bet/undergroundorgend.rpy:525
translate Spanish afterawake_8ef4895b:

    # "'The answer, I believe, lies in the problem. Humans. Their souls.'"
    "'La respuesta, creo, está en el propio problema. Los humanos. Sus almas.'"

# game/beyond the bet/undergroundorgend.rpy:526
translate Spanish afterawake_4b903bfd:

    # "'But what if, instead of allowing souls to move on, we took those souls, and used them to create beings that could serve us?'"
    "'¿Y si, en lugar de permitir que las almas sigan su camino, las tomáramos y las usáramos para crear seres que pudieran servirnos?'"

# game/beyond the bet/undergroundorgend.rpy:527
translate Spanish afterawake_c6d2347b:

    # "'Reapers, created from human souls. We would have to erase their memories, of course, but it would be a simple matter.'"
    "'Parcas, creadas a partir de almas humanas. Tendríamos que borrar sus recuerdos, por supuesto, pero sería un asunto sencillo.'"

# game/beyond the bet/undergroundorgend.rpy:528
translate Spanish afterawake_89e48665:

    # "'They could collect souls and send them to the afterlife, and the burden on us would lessen.'"
    "'Podrían recolectar almas y enviarlas al más allá, y nuestra carga se aliviaría.'"

# game/beyond the bet/undergroundorgend.rpy:529
translate Spanish afterawake_8fef9e1e:

    # "'They would be, for all intents and purposes, immortal. Never able to age or die. They would simply exist.'"
    "'Serían, a todos los efectos, inmortales. Incapaces de envejecer o morir. Simplemente existirían.'"

# game/beyond the bet/undergroundorgend.rpy:530
translate Spanish afterawake_4b1d5c93:

    # "'But this is all theory, for now. More testing is required.'"
    "'Pero por ahora todo esto es teoría. Se requieren más pruebas.'"

# game/beyond the bet/undergroundorgend.rpy:531
translate Spanish afterawake_cb0f6e3b:

    # "{i}You frown, then flip a few more pages in.{/i}"
    "{i}Frunces el ceño y pasas unas cuantas páginas más.{/i}"

# game/beyond the bet/undergroundorgend.rpy:532
translate Spanish afterawake_a3feca46:

    # "'Testing has gone poorly. Most subjects perish in the early stages of the experiments.'"
    "'Las pruebas han ido mal. La mayoría de los sujetos perece en las primeras etapas de los experimentos.'"

# game/beyond the bet/undergroundorgend.rpy:533
translate Spanish afterawake_f715a319:

    # "'Perhaps a special kind of soul is required. More testing is required.'"
    "'Quizá se necesite un tipo especial de alma. Se requieren más pruebas.'"

# game/beyond the bet/undergroundorgend.rpy:534
translate Spanish afterawake_e85c5122:

    # "{i}Another few pages. You're already reaching the end of the journal.{/i}"
    "{i}Unas cuantas páginas más. Ya estás llegando al final del diario.{/i}"

# game/beyond the bet/undergroundorgend.rpy:535
translate Spanish afterawake_5fd7222e:

    # "'I hypothesize that souls exist on a spectrum of density. The strongest souls, those bathed in more of this mortal 'light' that we still do not understand, are more likely to survive the transformation process.'"
    "'Planteo la hipótesis de que las almas existen en un espectro de densidad. Las almas más fuertes, aquellas bañadas en más de esa 'luz' mortal que aún no comprendemos, tienen más probabilidades de sobrevivir al proceso de transformación.'"

# game/beyond the bet/undergroundorgend.rpy:536
translate Spanish afterawake_498d01a8:

    # "'We have found a few stronger souls, but we believe that out there, souls of pure 'light' may exist. Those souls would be the ideal candidates, with their density, but we have never encountered such a soul.'"
    "'Hemos encontrado algunas almas más fuertes, pero creemos que ahí fuera pueden existir almas de 'luz' pura. Esas almas serían las candidatas ideales, por su densidad, pero nunca nos hemos topado con una así.'"

# game/beyond the bet/undergroundorgend.rpy:537
translate Spanish afterawake_f332fde1:

    # "'They may not exist.'"
    "'Puede que no existan.'"

# game/beyond the bet/undergroundorgend.rpy:538
translate Spanish afterawake_6c40d9dc:

    # "'For now, testing continues.'"
    "'Por ahora, las pruebas continúan.'"

# game/beyond the bet/undergroundorgend.rpy:539
translate Spanish afterawake_80bca3a1:

    # "{i}You flick through the final few pages, then stop.{/i}"
    "{i}Pasas las últimas páginas y te detienes.{/i}"

# game/beyond the bet/undergroundorgend.rpy:540
translate Spanish afterawake_f30b4665:

    # "'Success. Our latest test subject seems to have survived the process. Their memories are shaky, and perhaps require a stronger method of erasing, but we can deal with that. It seems our efforts have paid off, and we have created a reaper.'"
    "'Éxito. Nuestro último sujeto de pruebas parece haber sobrevivido al proceso. Sus recuerdos son inestables y quizá requieran un método de borrado más fuerte, pero podemos ocuparnos de eso. Parece que nuestros esfuerzos han dado fruto y hemos creado una parca.'"

# game/beyond the bet/undergroundorgend.rpy:541
translate Spanish afterawake_311298d9:

    # "'I believe the future will be brighter. Soon, we will have an army of unfeeling, unthinking servants to help us. The cycle of rebirth will no longer be a burden on us, nor the humans.'"
    "'Creo que el futuro será más brillante. Pronto tendremos un ejército de sirvientes sin sentimientos ni pensamiento que nos ayuden. El ciclo de renacimiento dejará de ser una carga para nosotros y para los humanos.'"

# game/beyond the bet/undergroundorgend.rpy:560
translate Spanish afterawake_89055293:

    # GRC "What is it?"
    GRC "¿Qué es?"

# game/beyond the bet/undergroundorgend.rpy:566
translate Spanish afterawake_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/undergroundorgend.rpy:568
translate Spanish afterawake_9467829c:

    # GRC "....."
    GRC "....."

# game/beyond the bet/undergroundorgend.rpy:570
translate Spanish afterawake_403d8e74:

    # GRC "............"
    GRC "............"

# game/beyond the bet/undergroundorgend.rpy:578
translate Spanish afterawake_afc4bf1d:

    # GRC "I... was human."
    GRC "Yo... era humano."

# game/beyond the bet/undergroundorgend.rpy:590
translate Spanish afterawake_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/beyond the bet/undergroundorgend.rpy:592
translate Spanish afterawake_790500a0:

    # GRC "Was human."
    GRC "Era humano."

# game/beyond the bet/undergroundorgend.rpy:594
translate Spanish afterawake_9a578e34:

    # GRC "I had a life I cannot even remember..."
    GRC "Tuve una vida que ni siquiera puedo recordar..."

# game/beyond the bet/undergroundorgend.rpy:595
translate Spanish afterawake_0b5b988a:

    # GRC "A... family?"
    GRC "¿Una... familia?"

# game/beyond the bet/undergroundorgend.rpy:596
translate Spanish afterawake_9251ac42:

    # GRC "People who cared for me?"
    GRC "¿Gente que se preocupaba por mí?"

# game/beyond the bet/undergroundorgend.rpy:602
translate Spanish afterawake_65122790_1:

    # GRC "I..."
    GRC "Yo..."

# game/beyond the bet/undergroundorgend.rpy:603
translate Spanish afterawake_0ca72a32:

    # GRC "I suppose this changes little."
    GRC "Supongo que esto cambia poco."

# game/beyond the bet/undergroundorgend.rpy:605
translate Spanish afterawake_7f815fb8:

    # GRC "I am still a Reaper."
    GRC "Sigo siendo una Parca."

# game/beyond the bet/undergroundorgend.rpy:609
translate Spanish afterawake_9c5e6188:

    # GRC "I feel I should be more upset than I am."
    GRC "Siento que debería estar más afectado de lo que estoy."

# game/beyond the bet/undergroundorgend.rpy:610
translate Spanish afterawake_29bf54c3:

    # GRC "I... lost so much."
    GRC "Yo... perdí tanto."

# game/beyond the bet/undergroundorgend.rpy:611
translate Spanish afterawake_b0c4d38e:

    # GRC "But..."
    GRC "Pero..."

# game/beyond the bet/undergroundorgend.rpy:613
translate Spanish afterawake_099135e7:

    # GRC "If it did not happen, then I never would have met you."
    GRC "Si no hubiera ocurrido, nunca te habría conocido."

# game/beyond the bet/undergroundorgend.rpy:615
translate Spanish afterawake_827b26f6:

    # GRC "You are the most infuriating, annoying, bothersome mortal I have ever had the pleasure of knowing."
    GRC "Eres la persona más exasperante, irritante y molesta que he tenido el placer de conocer."

# game/beyond the bet/undergroundorgend.rpy:616
translate Spanish afterawake_50c62326:

    # GRC "And I love you dearly."
    GRC "Y te amo profundamente."

# game/beyond the bet/undergroundorgend.rpy:617
translate Spanish afterawake_b0e747b4:

    # GRC "As I said... I would always choose you."
    GRC "Como dije... siempre te elegiría a ti."

# game/beyond the bet/undergroundorgend.rpy:619
translate Spanish afterawake_3b7c251e:

    # GRC "No matter what my past held, that is still true."
    GRC "Sea lo que sea que guardara mi pasado, eso sigue siendo cierto."

# game/beyond the bet/undergroundorgend.rpy:634
translate Spanish afterawake_4a379846:

    # GRC "...This is something people should decide for themselves."
    GRC "...Esto es algo que las personas deberían decidir por sí mismas."

# game/beyond the bet/undergroundorgend.rpy:635
translate Spanish afterawake_47b56b69:

    # GRC "Not be forced into."
    GRC "No algo que se les imponga."

# game/beyond the bet/undergroundorgend.rpy:637
translate Spanish afterawake_5011ff37:

    # GRC "I... have to do something about this—"
    GRC "Yo... tengo que hacer algo al respecto—"

# game/beyond the bet/undergroundorgend.rpy:641
translate Spanish afterawake_5203954e:

    # "You hear the sound of a door opening, then closing."
    "Oyes el sonido de una puerta que se abre y luego se cierra."

# game/beyond the bet/undergroundorgend.rpy:642
translate Spanish afterawake_c60c371d:

    # "You and Casper spin around at the same time, and you see... someone."
    "Tú y Casper se giran al mismo tiempo y ven... a alguien."

# game/beyond the bet/undergroundorgend.rpy:643
translate Spanish afterawake_d46d929b:

    # "Someone walking towards the two of you."
    "Alguien que camina hacia ustedes."

# game/beyond the bet/undergroundorgend.rpy:645
translate Spanish afterawake_b0e22e97:

    # GRC "...5012?"
    GRC "...¿5012?"

# game/beyond the bet/undergroundorgend.rpy:660
translate Spanish afterawake_d27af9ca:

    # O_ip "Hello, 'Casper'."
    O_ip "Hola, 'Casper'."

# game/beyond the bet/undergroundorgend.rpy:661
translate Spanish afterawake_6115ce30:

    # O_ip "And lest I be called impolite, hello to you as well, 'Sunshine'."
    O_ip "Y para que no me tachen de descortés, hola a ti también, 'Solecito'."

# game/beyond the bet/undergroundorgend.rpy:663
translate Spanish afterawake_57f28af0:

    # O_ip "Thank you for taking my invitation seriously."
    O_ip "Gracias por tomarte en serio mi invitación."

# game/beyond the bet/undergroundorgend.rpy:664
translate Spanish afterawake_076aade5:

    # O_ip "Though, I do remember asking you to come alone."
    O_ip "Aunque recuerdo haberte pedido que vinieras sol[letra]."

# game/beyond the bet/undergroundorgend.rpy:665
translate Spanish afterawake_9d62c0d7:

    # O_ip "Well, it's no matter. Really, you've just made my job that much easier."
    O_ip "En fin, no importa. En realidad, me han puesto el trabajo mucho más fácil."

# game/beyond the bet/undergroundorgend.rpy:683
translate Spanish afterawake_849eb7ab:

    # GRC "You were the one who hacked my app?"
    GRC "¿Fuiste tú quien hackeó mi aplicación?"

# game/beyond the bet/undergroundorgend.rpy:697
translate Spanish afterawake_357c98a6:

    # O_ip "'Hacked' is a little much, 8394. Your little chatting application was pretty much open to anyone."
    O_ip "'Hackear' es mucho decir, 8394. Tu aplicacioncita de chat estaba prácticamente abierta a cualquiera."

# game/beyond the bet/undergroundorgend.rpy:704
translate Spanish afterawake_185e907b:

    # GRC "...I... trained under him, for a time."
    GRC "...Yo... me formé bajo su mando durante un tiempo."

# game/beyond the bet/undergroundorgend.rpy:706
translate Spanish afterawake_229146bb:

    # O_ip "Skirting around the truth, I see."
    O_ip "Rodeando la verdad, ya veo."

# game/beyond the bet/undergroundorgend.rpy:707
translate Spanish afterawake_009ed865:

    # O_ip "Your 'little reaper' here was taken under my wing as a disciplinary action many years ago."
    O_ip "Tu 'parquita' aquí presente fue puesta bajo mi tutela como medida disciplinaria hace muchos años."

# game/beyond the bet/undergroundorgend.rpy:708
translate Spanish afterawake_730bd5c5:

    # O_ip "I thought you'd learned your lesson, 8394. We do not suffer traitors lightly."
    O_ip "Creí que habías aprendido la lección, 8394. No toleramos a los traidores a la ligera."

# game/beyond the bet/undergroundorgend.rpy:715
translate Spanish afterawake_bf8984a0:

    # GRC "It was... a long time ago."
    GRC "Fue... hace mucho tiempo."

# game/beyond the bet/undergroundorgend.rpy:717
translate Spanish afterawake_99e8d09c:

    # GRC "And it has nothing to do with this."
    GRC "Y no tiene nada que ver con esto."

# game/beyond the bet/undergroundorgend.rpy:719
translate Spanish afterawake_7b96bbdb:

    # O_ip "You struggled as a newborn Reaper, like a fawn who couldn't quite find its feet."
    O_ip "Tuviste dificultades como Parca recién nacida, como un cervatillo que no termina de encontrar sus patas."

# game/beyond the bet/undergroundorgend.rpy:720
translate Spanish afterawake_23a3b732:

    # O_ip "You always were too soft for this, 'Casper'. Too attached to humans."
    O_ip "Siempre fuiste demasiado blando para esto, 'Casper'. Demasiado apegado a los humanos."

# game/beyond the bet/undergroundorgend.rpy:723
translate Spanish afterawake_84955e07:

    # O_ip "A fault in his creation, likely."
    O_ip "Un defecto en su creación, seguramente."

# game/beyond the bet/undergroundorgend.rpy:728
translate Spanish afterawake_7ed1e4a4:

    # GRC "...I've met many other Reapers throughout my long years here that were attached to humans, you know."
    GRC "...He conocido a muchas otras parcas a lo largo de mis largos años aquí que estaban apegadas a los humanos, ¿sabes?"

# game/beyond the bet/undergroundorgend.rpy:729
translate Spanish afterawake_99858083:

    # GRC "They were all treated like the problem."
    GRC "A todos los trataron como si ellos fueran el problema."

# game/beyond the bet/undergroundorgend.rpy:730
translate Spanish afterawake_396c4175:

    # GRC "They were terminated before their feelings could spread."
    GRC "Los eliminaron antes de que sus sentimientos pudieran propagarse."

# game/beyond the bet/undergroundorgend.rpy:731
translate Spanish afterawake_db89ab3c:

    # GRC "At the time I was conflicted about it."
    GRC "En ese momento yo tenía sentimientos encontrados al respecto."

# game/beyond the bet/undergroundorgend.rpy:733
translate Spanish afterawake_7f3e61a3:

    # GRC "They had broken the rules. There are prices to pay for breaking rules."
    GRC "Habían roto las reglas. Romper las reglas tiene un precio."

# game/beyond the bet/undergroundorgend.rpy:734
translate Spanish afterawake_69d86de0:

    # GRC "But now it just makes me feel... bitter. Angry. Regretful."
    GRC "Pero ahora solo me hace sentir... amargura. Rabia. Arrepentimiento."

# game/beyond the bet/undergroundorgend.rpy:736
translate Spanish afterawake_560d7a51:

    # GRC "Because they were not the broken ones."
    GRC "Porque ellos no eran los defectuosos."

# game/beyond the bet/undergroundorgend.rpy:737
translate Spanish afterawake_79a94cb1:

    # GRC "If anything, it is people like you and me who are broken."
    GRC "En todo caso, los rotos somos personas como tú y yo."

# game/beyond the bet/undergroundorgend.rpy:740
translate Spanish afterawake_5d7966cf:

    # O_ip "What are you talking about now?"
    O_ip "¿De qué estás hablando ahora?"

# game/beyond the bet/undergroundorgend.rpy:741
translate Spanish afterawake_d5f199d0:

    # O_ip "You can try to stall for time all you like, but it won't change a thing. The both of you will pay for your crimes."
    O_ip "Puedes intentar ganar tiempo cuanto quieras, pero no cambiará nada. Los dos pagarán por sus crímenes."

# game/beyond the bet/undergroundorgend.rpy:742
translate Spanish afterawake_d03b5ee7:

    # GRC "I will not let you touch my mortal."
    GRC "No permitiré que toques a mi mortal."

# game/beyond the bet/undergroundorgend.rpy:743
translate Spanish afterawake_76d303e2:

    # O_ip "You have no say in the matter."
    O_ip "No tienes voz en este asunto."

# game/beyond the bet/undergroundorgend.rpy:744
translate Spanish afterawake_0a4be928:

    # GRC "Call me 'too soft' all you like. I know that I could beat you in a fight if I need to."
    GRC "Llámame 'demasiado blando' cuanto quieras. Sé que podría vencerte en una pelea si es necesario."

# game/beyond the bet/undergroundorgend.rpy:746
translate Spanish afterawake_b752195e:

    # O_ip "Can you do it without your precious mortal getting stuck in the middle, though?"
    O_ip "¿Pero podrías hacerlo sin que tu preciad[letra] mortal quede atrapad[letra] en medio?"

# game/beyond the bet/undergroundorgend.rpy:747
translate Spanish afterawake_8da23161:

    # GRC "...."
    GRC "..."

# game/beyond the bet/undergroundorgend.rpy:748
translate Spanish afterawake_777817df:

    # GRC "5012, listen to me."
    GRC "5012, escúchame."

# game/beyond the bet/undergroundorgend.rpy:749
translate Spanish afterawake_3627dded:

    # GRC "We were human, once."
    GRC "Fuimos humanos, alguna vez."

# game/beyond the bet/undergroundorgend.rpy:751
translate Spanish afterawake_a865d2bd:

    # O_ip "So, this is how far gone you are."
    O_ip "Así que hasta aquí has caído."

# game/beyond the bet/undergroundorgend.rpy:752
translate Spanish afterawake_c27090c0:

    # O_ip "Pitiful, 8394. I trained you myself, for a time. I expected greatness from you."
    O_ip "Lamentable, 8394. Yo mismo te formé durante un tiempo. Esperaba grandeza de ti."

# game/beyond the bet/undergroundorgend.rpy:763
translate Spanish afterawake_f371a439:

    # GRC "I have proof."
    GRC "Tengo pruebas."

# game/beyond the bet/undergroundorgend.rpy:764
translate Spanish afterawake_8ccf352d:

    # GRC "Look, we found it here."
    GRC "Mira, lo encontramos aquí."

# game/beyond the bet/undergroundorgend.rpy:765
translate Spanish afterawake_e56c7961:

    # O_ip "..."
    O_ip "..."

# game/beyond the bet/undergroundorgend.rpy:767
translate Spanish afterawake_f47e2a00:

    # GRC "We were humans. It's true."
    GRC "Éramos humanos. Es verdad."

# game/beyond the bet/undergroundorgend.rpy:768
translate Spanish afterawake_ad5ef5cd:

    # GRC "We were taken and made like this against our wills."
    GRC "Nos tomaron y nos hicieron así contra nuestra voluntad."

# game/beyond the bet/undergroundorgend.rpy:770
translate Spanish afterawake_8bcac6e9:

    # GRC "You know, I came to love this job."
    GRC "Sabes, llegué a amar este trabajo."

# game/beyond the bet/undergroundorgend.rpy:771
translate Spanish afterawake_8369c3cc:

    # GRC "You obviously thrive in it."
    GRC "Es evidente que tú floreces en él."

# game/beyond the bet/undergroundorgend.rpy:773
translate Spanish afterawake_1abc5d09:

    # O_ip "This is simply preposterous. You waste my time, trying desperately to stall me for no reason whatsoever."
    O_ip "Esto es sencillamente absurdo. Me hacen perder el tiempo, intentando desesperadamente retenerme sin razón alguna."

# game/beyond the bet/undergroundorgend.rpy:774
translate Spanish afterawake_eb08caf2:

    # O_ip "Humans are humans. Reapers are reapers."
    O_ip "Los humanos son humanos. Las parcas son parcas."

# game/beyond the bet/undergroundorgend.rpy:779
translate Spanish afterawake_c51b2867:

    # O_ip "Fine. But once I am done, I will do what I came here to do."
    O_ip "Bien. Pero cuando termine, haré lo que vine a hacer."

# game/beyond the bet/undergroundorgend.rpy:780
translate Spanish afterawake_de3d1d77:

    # O_ip "Your soul, 'Sunshine', will be forfeit, and 8394 will be sent for termination."
    O_ip "Tu alma, 'Solecito', quedará perdida, y 8394 será enviado a su eliminación."

# game/beyond the bet/undergroundorgend.rpy:781
translate Spanish afterawake_e56c7961_1:

    # O_ip "..."
    O_ip "..."

# game/beyond the bet/undergroundorgend.rpy:782
translate Spanish afterawake_f8938121:

    # O_ip "......"
    O_ip "......"

# game/beyond the bet/undergroundorgend.rpy:783
translate Spanish afterawake_4cdcf840:

    # O_ip "This... how do I know this is not fake?"
    O_ip "Esto... ¿cómo sé que no es falso?"

# game/beyond the bet/undergroundorgend.rpy:784
translate Spanish afterawake_2231d7f8:

    # GRC "We found it here. You know we can't lie. It's real."
    GRC "Lo encontramos aquí. Sabes que no podemos mentir. Es real."

# game/beyond the bet/undergroundorgend.rpy:785
translate Spanish afterawake_a6cf8252:

    # O_ip "You want me to believe that I was once human?"
    O_ip "¿Quieres que crea que alguna vez fui humano?"

# game/beyond the bet/undergroundorgend.rpy:789
translate Spanish afterawake_e56c7961_2:

    # O_ip "..."
    O_ip "..."

# game/beyond the bet/undergroundorgend.rpy:790
translate Spanish afterawake_25499222:

    # O_ip "But... how could..."
    O_ip "Pero... cómo pudo..."

# game/beyond the bet/undergroundorgend.rpy:791
translate Spanish afterawake_c06456db:

    # GRC "Do you honestly think this is fair?"
    GRC "¿De verdad crees que esto es justo?"

# game/beyond the bet/undergroundorgend.rpy:792
translate Spanish afterawake_5c93d940:

    # GRC "Do you believe that no one deserves to choose this for themselves?"
    GRC "¿Crees que nadie merece elegir esto por sí mismo?"

# game/beyond the bet/undergroundorgend.rpy:793
translate Spanish afterawake_23a01eac:

    # O_ip "It's more complicated than you make it out to be, even if we were once humans."
    O_ip "Es más complicado de lo que lo haces ver, aunque alguna vez hayamos sido humanos."

# game/beyond the bet/undergroundorgend.rpy:794
translate Spanish afterawake_d29b66bb:

    # O_ip "Without us, society would collapse. There must always be Grim Reapers."
    O_ip "Sin nosotros, la sociedad colapsaría. Siempre debe haber Parcas."

# game/beyond the bet/undergroundorgend.rpy:804
translate Spanish afterawake_04e23ae0:

    # O_ip "Then what do you suggest?"
    O_ip "Entonces, ¿qué sugieres?"

# game/beyond the bet/undergroundorgend.rpy:815
translate Spanish afterawake_be116637:

    # GRC "You know, I consider myself more of a follower than a leader..."
    GRC "Sabes, me considero más un seguidor que un líder..."

# game/beyond the bet/undergroundorgend.rpy:816
translate Spanish afterawake_5417dc28:

    # GRC "But I do not think I could sit back and just forget about this."
    GRC "Pero no creo que pueda quedarme de brazos cruzados y olvidarme de esto."

# game/beyond the bet/undergroundorgend.rpy:817
translate Spanish afterawake_22bee92d:

    # GRC "I... we have to do something."
    GRC "Yo... tenemos que hacer algo."

# game/beyond the bet/undergroundorgend.rpy:820
translate Spanish afterawake_679ace0c:

    # O_ip "Why not just run away from this all?"
    O_ip "¿Por qué no simplemente huir de todo esto?"

# game/beyond the bet/undergroundorgend.rpy:821
translate Spanish afterawake_0186eaf0:

    # O_ip "You two wanted a future together - you could easily drop the truth about us and then leave in the ensuing chaos."
    O_ip "Ustedes dos querían un futuro juntos: podrían soltar sin más la verdad sobre nosotros y luego marcharse en medio del caos resultante."

# game/beyond the bet/undergroundorgend.rpy:828
translate Spanish afterawake_cce57f51:

    # GRC "There will be time for that later."
    GRC "Habrá tiempo para eso más tarde."

# game/beyond the bet/undergroundorgend.rpy:829
translate Spanish afterawake_4940acd6:

    # GRC "...If you'll help us."
    GRC "...Si nos ayudas."

# game/beyond the bet/undergroundorgend.rpy:830
translate Spanish afterawake_d506f6c5:

    # O_ip "Help you what exactly?"
    O_ip "¿Ayudarlos en qué exactamente?"

# game/beyond the bet/undergroundorgend.rpy:831
translate Spanish afterawake_3c0a44e4:

    # GRC "Help me spread this around. "
    GRC "Ayúdame a difundir esto. "

# game/beyond the bet/undergroundorgend.rpy:835
translate Spanish afterawake_0e498441:

    # O_ip "And then what?"
    O_ip "¿Y luego qué?"

# game/beyond the bet/undergroundorgend.rpy:845
translate Spanish afterawake_7aa5d355:

    # O_ip "I have always been a perfect reaper."
    O_ip "Siempre he sido una parca perfecta."

# game/beyond the bet/undergroundorgend.rpy:852
translate Spanish afterawake_c9ab2ee1:

    # O_ip "And now I should throw it all away, just because we were once human?"
    O_ip "¿Y ahora debería tirarlo todo por la borda solo porque alguna vez fuimos humanos?"

# game/beyond the bet/undergroundorgend.rpy:854
translate Spanish afterawake_ee9e3f04:

    # GRC "They lied to you, 5012."
    GRC "Te mintieron, 5012."

# game/beyond the bet/undergroundorgend.rpy:855
translate Spanish afterawake_0eda5b54:

    # GRC "While you followed every rule perfectly, they lied to you."
    GRC "Mientras seguías cada regla a la perfección, te mintieron."

# game/beyond the bet/undergroundorgend.rpy:856
translate Spanish afterawake_d9a37920:

    # GRC "Doesn't a perfect reaper deserve better than that?"
    GRC "¿Una parca perfecta no merece algo mejor que eso?"

# game/beyond the bet/undergroundorgend.rpy:857
translate Spanish afterawake_e56c7961_3:

    # O_ip "..."
    O_ip "..."

# game/beyond the bet/undergroundorgend.rpy:859
translate Spanish afterawake_d592328b:

    # O_ip "...Well, I doubt I have much choice now."
    O_ip "...Bueno, dudo que tenga muchas opciones ahora."

# game/beyond the bet/undergroundorgend.rpy:861
translate Spanish afterawake_453fdc8e:

    # O_ip "You two alone are a mess. You will get nothing done without someone competent by your side."
    O_ip "Ustedes dos solos son un desastre. No lograrán nada sin alguien competente a su lado."

# game/beyond the bet/undergroundorgend.rpy:863
translate Spanish afterawake_7765bbf7:

    # GRC "You think you're more competent than me?" id afterawake_7765bbf7
    GRC "¿Crees que eres más competente que yo?" id afterawake_7765bbf7

# game/beyond the bet/undergroundorgend.rpy:865
translate Spanish afterawake_9beb24b4:

    # O_ip "I do not think it. I know it."
    O_ip "No lo creo. Lo sé."

# game/beyond the bet/undergroundorgend.rpy:871
translate Spanish afterawake_493a595e:

    # O_ip "Since I am the competent one, I will begin by finding us somewhere to work out of." id afterawake_493a595e
    O_ip "Como soy el competente, empezaré por encontrarnos un lugar desde donde trabajar." id afterawake_493a595e

# game/beyond the bet/undergroundorgend.rpy:877
translate Spanish afterawake_34905736:

    # O_ip "...Right. As I said, only competent one and whatnot." id afterawake_34905736
    O_ip "...Bien. Como dije, el único competente y todo eso." id afterawake_34905736

# game/beyond the bet/undergroundorgend.rpy:879
translate Spanish afterawake_7131bf8e:

    # O_ip "I'll collect you both soon."
    O_ip "Pronto vendré a recogerlos a ambos."

# game/beyond the bet/undergroundorgend.rpy:883
translate Spanish afterawake_c0827013:

    # GRC "Yeah, run away!"
    GRC "¡Sí, huye!"

# game/beyond the bet/undergroundorgend.rpy:885
translate Spanish afterawake_97962d80:

    # GRC "Asshole."
    GRC "Imbécil."

# game/beyond the bet/undergroundorgend.rpy:892
translate Spanish afterawake_787fc139:

    # GRC "...Are you sure this is what you want?"
    GRC "...¿Estás segur[letra] de que esto es lo que quieres?"

# game/beyond the bet/undergroundorgend.rpy:897
translate Spanish afterawake_dd8b730f:

    # GRC "You know exactly what I'm talking about."
    GRC "Sabes perfectamente de qué estoy hablando."

# game/beyond the bet/undergroundorgend.rpy:902
translate Spanish afterawake_a4b46e6c:

    # GRC "Ah, playing stupid, are we?"
    GRC "Ah, ¿fingiendo que no sabes, entonces?"

# game/beyond the bet/undergroundorgend.rpy:918
translate Spanish afterawake_b6c29f0e:

    # GRC "That is what I was thinking, too."
    GRC "Eso mismo estaba pensando yo."

# game/beyond the bet/undergroundorgend.rpy:919
translate Spanish afterawake_8f43750e:

    # GRC "If doing this helps people, that's great."
    GRC "Si hacer esto ayuda a la gente, es genial."

# game/beyond the bet/undergroundorgend.rpy:921
translate Spanish afterawake_1d12122f:

    # GRC "But if it helps you, then it's truly worth doing."
    GRC "Pero si te ayuda a ti, entonces de verdad vale la pena."

# game/beyond the bet/undergroundorgend.rpy:929
translate Spanish afterawake_75a72c93:

    # GRC "Underground mob bosses...?"
    GRC "¿Jefes de la mafia subterránea...?"

# game/beyond the bet/undergroundorgend.rpy:933
translate Spanish afterawake_008afe10_2:

    # GRC "..."
    GRC "..."

# game/beyond the bet/undergroundorgend.rpy:935
translate Spanish afterawake_315a39a5:

    # GRC "You're such an idiot."
    GRC "Eres [arti_2] idiota."

# game/beyond the bet/undergroundorgend.rpy:936
translate Spanish afterawake_eaaca790:

    # GRC "And I mean that in the kindest, most endearing way possible."
    GRC "Y lo digo de la manera más amable y entrañable posible."

# game/beyond the bet/undergroundorgend.rpy:940
translate Spanish afterawake_6a3169e8:

    # GRC "Yeah. Let's do this."
    GRC "Sí. Hagámoslo."

# game/beyond the bet/undergroundorgend.rpy:963
translate Spanish metamorphosis_end_after_f496ba80:

    # "{i}Over the past few months, you've come to call this realm your home.{/i}"
    "{i}Durante los últimos meses, has llegado a llamar hogar a este reino.{/i}"

# game/beyond the bet/undergroundorgend.rpy:966
translate Spanish metamorphosis_end_after_9ed27b6b:

    # "{i}In a place that should be devoid of light, you've found... something warm. Something comfortable.{/i}"
    "{i}En un lugar que debería carecer de luz, has encontrado... algo cálido. Algo reconfortante.{/i}"

# game/beyond the bet/undergroundorgend.rpy:967
translate Spanish metamorphosis_end_after_27c4573b:

    # "{i}It's been hard work, of course. Always being in hiding, recruiting people to your cause...{/i}"
    "{i}Ha sido mucho trabajo, claro. Vivir siempre escondidos, reclutando gente para tu causa...{/i}"

# game/beyond the bet/undergroundorgend.rpy:968
translate Spanish metamorphosis_end_after_0b5c849a:

    # "{i}But the whole time, you've been by Casper's side.{/i}"
    "{i}Pero todo el tiempo has estado al lado de Casper.{/i}"

# game/beyond the bet/undergroundorgend.rpy:969
translate Spanish metamorphosis_end_after_f5bd417f:

    # "{i}Sure, you also have to listen to Casper arguing with '5012', who STILL hasn't picked a name...{/i}"
    "{i}Claro, también tienes que oír a Casper discutir con '5012', que TODAVÍA no ha elegido un nombre...{/i}"

# game/beyond the bet/undergroundorgend.rpy:970
translate Spanish metamorphosis_end_after_6124b311:

    # "{i}Yet, somehow, things feel alright.{/i}"
    "{i}Aun así, de algún modo, las cosas parecen ir bien.{/i}"

# game/beyond the bet/undergroundorgend.rpy:974
translate Spanish metamorphosis_end_after_7dda3073:

    # "{i}And now, you stand on what feels like the edge of the world, looking down at the city lights below.{/i}"
    "{i}Y ahora estás de pie en lo que parece el borde del mundo, mirando las luces de la ciudad allá abajo.{/i}"

# game/beyond the bet/undergroundorgend.rpy:975
translate Spanish metamorphosis_end_after_05fce9fb:

    # "{i}It's beautiful.{/i}"
    "{i}Es hermoso.{/i}"

# game/beyond the bet/undergroundorgend.rpy:976
translate Spanish metamorphosis_end_after_16a69f63:

    # "{i}Or perhaps it's just him that's beautiful. You're not sure.{/i}"
    "{i}O quizá solo es él quien es hermoso. No lo tienes claro.{/i}"

# game/beyond the bet/undergroundorgend.rpy:977
translate Spanish metamorphosis_end_after_21ef89b4:

    # "{i}Either way, you look over the world you've come to call home, and you know you're close.{/i}"
    "{i}Sea como sea, contemplas el mundo que has llegado a llamar hogar y sabes que estás cerca.{/i}"

# game/beyond the bet/undergroundorgend.rpy:978
translate Spanish metamorphosis_end_after_6454d013:

    # "{i}Close to being able to change things here.{/i}"
    "{i}Cerca de poder cambiar las cosas aquí.{/i}"

# game/beyond the bet/undergroundorgend.rpy:979
translate Spanish metamorphosis_end_after_d9cb6577:

    # "{i}And then, the two of you will go back to your home. Or maybe you'll decide to stay here, after all?{/i}"
    "{i}Y entonces, los dos volverán a su hogar. ¿O quizá decidan quedarse aquí, después de todo?{/i}"

# game/beyond the bet/undergroundorgend.rpy:980
translate Spanish metamorphosis_end_after_5649614d:

    # "{i}Who knows.{/i}"
    "{i}Quién sabe.{/i}"

# game/beyond the bet/undergroundorgend.rpy:981
translate Spanish metamorphosis_end_after_2ad71ed2:

    # "{i}That's the funny thing about the future.{/i}"
    "{i}Eso es lo curioso del futuro.{/i}"

# game/beyond the bet/undergroundorgend.rpy:982
translate Spanish metamorphosis_end_after_452cbaa5:

    # "{i}No one really knows what will happen. You can guess, or hope, or pray, but no one can really know.{/i}"
    "{i}Nadie sabe realmente qué pasará. Puedes adivinar, esperar o rezar, pero nadie puede saberlo de verdad.{/i}"

# game/beyond the bet/undergroundorgend.rpy:983
translate Spanish metamorphosis_end_after_b24fbeff:

    # "{i}There is something you DO know, though.{/i}"
    "{i}Hay algo que SÍ sabes, sin embargo.{/i}"

# game/beyond the bet/undergroundorgend.rpy:984
translate Spanish metamorphosis_end_after_62ed529f:

    # "{i}That no matter what, you will be by Casper's side.{/i}"
    "{i}Que pase lo que pase, estarás al lado de Casper.{/i}"

# game/beyond the bet/undergroundorgend.rpy:986
translate Spanish metamorphosis_end_after_cc781759:

    # GRC "...Is that you, Sunshine?"
    GRC "...¿Eres tú, Solecito?"

# game/beyond the bet/undergroundorgend.rpy:994
translate Spanish metamorphosis_end_after_3a8daded:

    # GRC "That's perfect, because that's exactly where I like you to be."
    GRC "Perfecto, porque ahí es exactamente donde me gusta que estés."

# game/beyond the bet/undergroundorgend.rpy:995
translate Spanish metamorphosis_end_after_afed862f:

    # GRC "Come on, we have a world to change."
    GRC "Vamos, tenemos un mundo que cambiar."

translate Spanish strings:

    # game/beyond the bet/undergroundorgend.rpy:73
    old "1. <Only when I see you.>"
    new "1. <Solo cuando te veo.>"

    # game/beyond the bet/undergroundorgend.rpy:75
    old "2. <Yeah, I love yelling.>"
    new "2. <Sí, me encanta gritar.>"

    # game/beyond the bet/undergroundorgend.rpy:77
    old "3. <Is that a problem?>"
    new "3. <¿Es un problema?>"

    # game/beyond the bet/undergroundorgend.rpy:80
    old "1. <Nah, honestly I usually just roll over and say good morning to [pet_name].>"
    new "1. <Nah, la verdad es que normalmente solo me doy la vuelta y le doy los buenos días a [pet_name].>"

    # game/beyond the bet/undergroundorgend.rpy:83
    old "1. <But I think we should make it a thing.>"
    new "1. <Pero creo que deberíamos convertirlo en costumbre.>"

    # game/beyond the bet/undergroundorgend.rpy:89
    old "1. <You still look like you have skin to me.>"
    new "1. <Pues a mí me sigue pareciendo que tienes piel.>"

    # game/beyond the bet/undergroundorgend.rpy:92
    old "1. <What would you prefer, then?>"
    new "1. <¿Qué preferirías, entonces?>"

    # game/beyond the bet/undergroundorgend.rpy:97
    old "1. <Okay, let's have a redo.>"
    new "1. <Okey, repitámoslo.>"

    # game/beyond the bet/undergroundorgend.rpy:101
    old "1. <...You're already awake, my love?>"
    new "1. <...¿Ya estás despierto, mi amor?>"

    # game/beyond the bet/undergroundorgend.rpy:103
    old "2. <Good morning, my favorite Grim Reaper in the whole world.>"
    new "2. <Buenos días, mi Parca favorita de todo el mundo.>"

    # game/beyond the bet/undergroundorgend.rpy:105
    old "3. <I had such a good time last night, Casper.>"
    new "3. <Anoche lo pasé muy bien, Casper.>"

    # game/beyond the bet/undergroundorgend.rpy:115
    old "1. <I was dreaming about you.>"
    new "1. <Estaba soñando contigo.>"

    # game/beyond the bet/undergroundorgend.rpy:118
    old "1. <If I told you about my dreams, though, we'd have to put up the age rating.>"
    new "1. <Aunque si te contara mis sueños, tendríamos que subir la clasificación de edad.>"

    # game/beyond the bet/undergroundorgend.rpy:120
    old "2. <It was nice, but I prefer seeing you like this.>"
    new "2. <Estuvo bien, pero prefiero verte así.>"

    # game/beyond the bet/undergroundorgend.rpy:126
    old "1. <How was it?>"
    new "1. <¿Cómo estuvo?>"

    # game/beyond the bet/undergroundorgend.rpy:131
    old "1. <Nope. It's now my goal to wake up and fluster you. Every. Single. Day.>"
    new "1. <Nop. Ahora mi meta es despertarme y ponerte nervioso. Todos. Y. Cada. Día.>"

    # game/beyond the bet/undergroundorgend.rpy:136
    old "1. <You know, I'm pretty lucky.>"
    new "1. <Sabes, tengo bastante suerte.>"

    # game/beyond the bet/undergroundorgend.rpy:139
    old "1. <I feel like everything will be okay.>"
    new "1. <Siento que todo va a salir bien.>"

    # game/beyond the bet/undergroundorgend.rpy:145
    old "1. <A bit of both?>"
    new "1. <¿Un poco de ambas?>"

    # game/beyond the bet/undergroundorgend.rpy:148
    old "2. <Maybe if I rub you a lot, you'll get some of it.>"
    new "2. <Quizá si te froto mucho, se te pegue un poco.>"

    # game/beyond the bet/undergroundorgend.rpy:155
    old "1. <How did you go, anyway?>"
    new "1. <¿Cómo te fue, por cierto?>"

    # game/beyond the bet/undergroundorgend.rpy:158
    old "1. <With whatever you were doing.>"
    new "1. <Con lo que estuvieras haciendo.>"

    # game/beyond the bet/undergroundorgend.rpy:168
    old "1. <No... you?!>"
    new "1. <¡¿No... tú?!>"

    # game/beyond the bet/undergroundorgend.rpy:172
    old "1. <I'm just kidding.>"
    new "1. <Solo bromeaba.>"

    # game/beyond the bet/undergroundorgend.rpy:175
    old "1. <I'm glad to hear you had a friend.>"
    new "1. <Me alegra saber que tenías un amigo.>"

    # game/beyond the bet/undergroundorgend.rpy:179
    old "2. <It's good to have friends.>"
    new "2. <Es bueno tener amigos.>"

    # game/beyond the bet/undergroundorgend.rpy:183
    old "3. <I thought you didn't like the other reapers.>"
    new "3. <Pensé que no te caían bien las otras parcas.>"

    # game/beyond the bet/undergroundorgend.rpy:197
    old "1. <Just for that...?>"
    new "1. <¿Solo por eso...?>"

    # game/beyond the bet/undergroundorgend.rpy:205
    old "1. <Why did you decide to break all of those rules, anyway?>"
    new "1. <¿Por qué decidiste romper todas esas reglas, por cierto?>"

    # game/beyond the bet/undergroundorgend.rpy:210
    old "1. <You broke the rules from the start!>"
    new "1. <¡Rompiste las reglas desde el principio!>"

    # game/beyond the bet/undergroundorgend.rpy:226
    old "1. <You did the same thing to me.>"
    new "1. <Tú hiciste lo mismo conmigo.>"

    # game/beyond the bet/undergroundorgend.rpy:228
    old "2. <I'm happy I could help you get back to who you really are.>"
    new "2. <Me alegra haber podido ayudarte a volver a ser quien realmente eres.>"

    # game/beyond the bet/undergroundorgend.rpy:234
    old "1. <That does sound nice.>"
    new "1. <Eso suena muy bien.>"

    # game/beyond the bet/undergroundorgend.rpy:237
    old "1. <Casper, you know that person who contacted me yesterday?>"
    new "1. <Casper, ¿recuerdas a esa persona que me contactó ayer?>"

    # game/beyond the bet/undergroundorgend.rpy:242
    old "1. <Hacker might be an overstatement.>"
    new "1. <Quizá 'hacker' sea exagerar.>"

    # game/beyond the bet/undergroundorgend.rpy:244
    old "1. <But yes.>"
    new "1. <Pero sí.>"

    # game/beyond the bet/undergroundorgend.rpy:246
    old "2. <Yeah, them.>"
    new "2. <Sí, esa persona.>"

    # game/beyond the bet/undergroundorgend.rpy:249
    old "1. <They want me to meet up with them.>"
    new "1. <Quiere que me reúna con esa persona.>"

    # game/beyond the bet/undergroundorgend.rpy:254
    old "1. <Let me show you.>"
    new "1. <Déjame mostrártelo.>"

    # game/beyond the bet/undergroundorgend.rpy:261
    old "1. <Well, I'd hope not!>"
    new "1. <¡Pues eso espero!>"

    # game/beyond the bet/undergroundorgend.rpy:263
    old "2. <I'm pretty sneaky. I bet I could've crept out to it alone.>"
    new "2. <Tengo mucho sigilo. Seguro que habría podido escabullirme sol[letra].>"

    # game/beyond the bet/undergroundorgend.rpy:265
    old "3. <I know. I wanted you to come.>"
    new "3. <Lo sé. Quería que vinieras.>"

    # game/beyond the bet/undergroundorgend.rpy:270
    old "1. <There was also this keycard...>"
    new "1. <También había esta tarjeta de acceso...>"

    # game/beyond the bet/undergroundorgend.rpy:280
    old "1. <We should go. Together.>"
    new "1. <Deberíamos ir. Juntos.>"

    # game/beyond the bet/undergroundorgend.rpy:286
    old "2. <I don't mind.>"
    new "2. <No me importa.>"

    # game/beyond the bet/undergroundorgend.rpy:289
    old "1. <Even if it is a trap, it could be our chance to get out of this.>"
    new "1. <Aunque sea una trampa, podría ser nuestra oportunidad de salir de esto.>"

    # game/beyond the bet/undergroundorgend.rpy:297
    old "1. <What? What's wrong with how I look?>"
    new "1. <¿Qué? ¿Qué tiene de malo mi aspecto?>"

    # game/beyond the bet/undergroundorgend.rpy:299
    old "2. <I thought you said something about reapers looking like ordinary people?>"
    new "2. <¿No habías dicho algo sobre que las parcas parecen personas normales?>"

    # game/beyond the bet/undergroundorgend.rpy:309
    old "1. <Don't you miss my [pretty] face?>"
    new "1. <¿No extrañas mi [pretty!t] [cara]?>"

    # game/beyond the bet/undergroundorgend.rpy:318
    old "1. <Hehe. You like me.>"
    new "1. <Jeje. Te gusto.>"

    # game/beyond the bet/undergroundorgend.rpy:320
    old "2. <You can't help but think of meeeee.>"
    new "2. <No puedes evitar pensar en míííí.>"

    # game/beyond the bet/undergroundorgend.rpy:329
    old "1. <Yeah?>"
    new "1. <¿Sí?>"

    # game/beyond the bet/undergroundorgend.rpy:339
    old "1. <Sometimes you really are such a romantic.>"
    new "1. <A veces sí que eres todo un romántico.>"

    # game/beyond the bet/undergroundorgend.rpy:341
    old "2. <You're so cheesy.>"
    new "2. <Eres tan cursi.>"

    # game/beyond the bet/undergroundorgend.rpy:343
    old "3. <Ah...>"
    new "3. <Ah...>"

    # game/beyond the bet/undergroundorgend.rpy:398
    old "1. <That's what she said.>"
    new "1. <Eso dijo ella.>"

    # game/beyond the bet/undergroundorgend.rpy:403
    old "1. <It's a joke...>"
    new "1. <Es un chiste...>"

    # game/beyond the bet/undergroundorgend.rpy:408
    old "2. <And overwhelming.>"
    new "2. <Y abrumadora.>"

    # game/beyond the bet/undergroundorgend.rpy:413
    old "3. <I think I'm in love.>"
    new "3. <Creo que estoy enamorad[letra].>"

    # game/beyond the bet/undergroundorgend.rpy:417
    old "1. <All of these books!>"
    new "1. <¡Todos estos libros!>"

    # game/beyond the bet/undergroundorgend.rpy:420
    old "1. <I love books.>"
    new "1. <Amo los libros.>"

    # game/beyond the bet/undergroundorgend.rpy:426
    old "1. <And with you too, I guess.>"
    new "1. <Y contigo también, supongo.>"

    # game/beyond the bet/undergroundorgend.rpy:435
    old "1. <We could make a competition of it.>"
    new "1. <Podríamos convertirlo en una competencia.>"

    # game/beyond the bet/undergroundorgend.rpy:440
    old "1. <You like them too.>"
    new "1. <A ti también te gustan.>"

    # game/beyond the bet/undergroundorgend.rpy:449
    old "1. <One wish from the other person!>"
    new "1. <¡Un deseo de la otra persona!>"

    # game/beyond the bet/undergroundorgend.rpy:461
    old "1. <You could make the other person eat something gross.>"
    new "1. <Podrías hacer que la otra persona coma algo asqueroso.>"

    # game/beyond the bet/undergroundorgend.rpy:464
    old "2. <I'd make you wear an apron and give me breakfast in bed for a whole week.>"
    new "2. <Yo te haría ponerte un delantal y servirme el desayuno en la cama durante una semana entera.>"

    # game/beyond the bet/undergroundorgend.rpy:467
    old "3. <No, you give ME an example.>"
    new "3. <No, dame TÚ un ejemplo a MÍ.>"

    # game/beyond the bet/undergroundorgend.rpy:473
    old "1. <Ooooh, confidence. I like it.>"
    new "1. <Ooooh, confianza. Me gusta.>"

    # game/beyond the bet/undergroundorgend.rpy:492
    old "1. <Anything yet?>"
    new "1. <¿Algo todavía?>"

    # game/beyond the bet/undergroundorgend.rpy:508
    old "1. <{i}Reach for the book.{/i}>"
    new "1. <{i}Alcanzar el libro.{/i}>"

    # game/beyond the bet/undergroundorgend.rpy:510
    old "2. <{i}Blow on the book.{/i}>"
    new "2. <{i}Soplar el libro.{/i}>"

    # game/beyond the bet/undergroundorgend.rpy:521
    old "1. <{i}Open to the first page.{/i}>"
    new "1. <{i}Abrir en la primera página.{/i}>"

    # game/beyond the bet/undergroundorgend.rpy:546
    old "2. <Casper, I've found something...>"
    new "2. <Casper, encontré algo...>"

    # game/beyond the bet/undergroundorgend.rpy:548
    old "3. <Well, I win, but this doesn't seem like the time for celebrating...>"
    new "3. <Bueno, gano yo, pero no parece el momento de celebrar...>"

    # game/beyond the bet/undergroundorgend.rpy:562
    old "1. <Here, read it.>"
    new "1. <Toma, léelo.>"

    # game/beyond the bet/undergroundorgend.rpy:572
    old "1. <It's true...>"
    new "1. <Es verdad...>"

    # game/beyond the bet/undergroundorgend.rpy:575
    old "1. <You were human!>"
    new "1. <¡Eras humano!>"

    # game/beyond the bet/undergroundorgend.rpy:580
    old "1. <You died and were meant to go to the afterlife, but instead...>"
    new "1. <Moriste y debías ir al más allá, pero en cambio...>"

    # game/beyond the bet/undergroundorgend.rpy:583
    old "1. <They brought you here.>"
    new "1. <Te trajeron aquí.>"

    # game/beyond the bet/undergroundorgend.rpy:586
    old "1. <Against your will.>"
    new "1. <Contra tu voluntad.>"

    # game/beyond the bet/undergroundorgend.rpy:588
    old "2. <They never asked you if that was okay.>"
    new "2. <Nunca te preguntaron si te parecía bien.>"

    # game/beyond the bet/undergroundorgend.rpy:598
    old "1. <...I'm sorry, Casper.>"
    new "1. <...Lo siento, Casper.>"

    # game/beyond the bet/undergroundorgend.rpy:600
    old "2. <Are you doing alright?>"
    new "2. <¿Estás bien?>"

    # game/beyond the bet/undergroundorgend.rpy:607
    old "1. <A Reaper who was human.>"
    new "1. <Una Parca que fue humana.>"

    # game/beyond the bet/undergroundorgend.rpy:623
    old "2. <I love you, as well.>"
    new "2. <Yo también te amo.>"

    # game/beyond the bet/undergroundorgend.rpy:626
    old "1. <This is just so unfair.>"
    new "1. <Esto es tan injusto.>"

    # game/beyond the bet/undergroundorgend.rpy:629
    old "1. <You should get a choice. >"
    new "1. <Deberías poder elegir. >"

    # game/beyond the bet/undergroundorgend.rpy:631
    old "2. <A whole past that you'll never remember...>"
    new "2. <Todo un pasado que nunca recordarás...>"

    # game/beyond the bet/undergroundorgend.rpy:701
    old "2. <What, the two of you are friends?>"
    new "2. <¿Qué, ustedes dos son amigos?>"

    # game/beyond the bet/undergroundorgend.rpy:710
    old "1. <You were in trouble before?>"
    new "1. <¿Ya habías tenido problemas antes?>"

    # game/beyond the bet/undergroundorgend.rpy:712
    old "2. <Did something happen?>"
    new "2. <¿Pasó algo?>"

    # game/beyond the bet/undergroundorgend.rpy:722
    old "1. <And why do you think that is?>"
    new "1. <¿Y por qué crees que es así?>"

    # game/beyond the bet/undergroundorgend.rpy:725
    old "1. <Ironic, considering how you were all created.>"
    new "1. <Irónico, considerando cómo fueron creados todos ustedes.>"

    # game/beyond the bet/undergroundorgend.rpy:727
    old "2. <{i}Wait for Casper to speak up.{/i}>"
    new "2. <{i}Esperar a que Casper hable.{/i}>"

    # game/beyond the bet/undergroundorgend.rpy:754
    old "1. <Will you just listen for a second?!>"
    new "1. <¡¿Puedes escuchar un segundo?!>"

    # game/beyond the bet/undergroundorgend.rpy:756
    old "2. <He's not making it up.>"
    new "2. <No se lo está inventando.>"

    # game/beyond the bet/undergroundorgend.rpy:758
    old "3. <God, do all of you reapers love the sound of your own voice so much?!>"
    new "3. <¡Dios, ¿a todas las parcas les encanta tanto oírse hablar?!>"

    # game/beyond the bet/undergroundorgend.rpy:760
    old "1. <Just be quiet and listen to Casper!>"
    new "1. <¡Solo cállate y escucha a Casper!>"

    # game/beyond the bet/undergroundorgend.rpy:776
    old "1. <Just read the book already.>"
    new "1. <Solo lee el libro de una vez.>"

    # game/beyond the bet/undergroundorgend.rpy:787
    old "1. <You were.>"
    new "1. <Lo fuiste.>"

    # game/beyond the bet/undergroundorgend.rpy:796
    old "1. <There has to be another solution.>"
    new "1. <Tiene que haber otra solución.>"

    # game/beyond the bet/undergroundorgend.rpy:798
    old "1. <Anything other than this.>"
    new "1. <Cualquier cosa menos esto.>"

    # game/beyond the bet/undergroundorgend.rpy:800
    old "2. <Are you and the rest of the Reapers not a part of that society?>"
    new "2. <¿Ustedes y el resto de las parcas no forman parte de esa sociedad?>"

    # game/beyond the bet/undergroundorgend.rpy:802
    old "1. <Do you not deserve to get a say in it?>"
    new "1. <¿No merecen tener voz en esto?>"

    # game/beyond the bet/undergroundorgend.rpy:809
    old "1. <I'm just a human, but...>"
    new "1. <Solo soy human[letra], pero...>"

    # game/beyond the bet/undergroundorgend.rpy:811
    old "1. <I think you all need new management.>"
    new "1. <Creo que todos ustedes necesitan una nueva dirección.>"

    # game/beyond the bet/undergroundorgend.rpy:823
    old "1. <I don't know about Casper, but that doesn't feel right to me.>"
    new "1. <No sé qué piense Casper, pero eso a mí no me parece correcto.>"

    # game/beyond the bet/undergroundorgend.rpy:825
    old "2. <I've always wanted to help lead a revolt or something, don't worry.>"
    new "2. <Siempre quise ayudar a liderar una revuelta o algo así, tranquilo.>"

    # game/beyond the bet/undergroundorgend.rpy:833
    old "1. <We can find more people who agree that this is wrong.>"
    new "1. <Podemos encontrar a más personas que estén de acuerdo en que esto está mal.>"

    # game/beyond the bet/undergroundorgend.rpy:837
    old "1. <Overthrow your management?>"
    new "1. <¿Derrocar a su dirección?>"

    # game/beyond the bet/undergroundorgend.rpy:839
    old "2. <Fix the whole 'forced into being a Grim Reaper' thing.>"
    new "2. <Arreglar todo eso de 'ser obligado a ser una Parca'.>"

    # game/beyond the bet/undergroundorgend.rpy:841
    old "3. <What do you want me to say, bake a cake?>"
    new "3. <¿Y yo qué sé? ¿Hacemos un pastel o qué?>"

    # game/beyond the bet/undergroundorgend.rpy:843
    old "1. <Obviously the next step is making change.>"
    new "1. <Obviamente el siguiente paso es provocar un cambio.>"

    # game/beyond the bet/undergroundorgend.rpy:847
    old "1. <Oh god, it's Casper 2.0...>"
    new "1. <Ay, Dios, es Casper 2.0...>"

    # game/beyond the bet/undergroundorgend.rpy:849
    old "2. <Here we go...>"
    new "2. <Ya empezamos...>"

    # game/beyond the bet/undergroundorgend.rpy:867
    old "1. <Oh, boy...>"
    new "1. <Ay, caramba...>"

    # game/beyond the bet/undergroundorgend.rpy:869
    old "2. <This is going to be interesting, isn't it...>"
    new "2. <Esto va a ser interesante, ¿verdad?...>"

    # game/beyond the bet/undergroundorgend.rpy:873
    old "1. <A secret hide out?!>"
    new "1. <¡¿Un escondite secreto?!>"

    # game/beyond the bet/undergroundorgend.rpy:875
    old "2. <Like an underground bunker?!>"
    new "2. <¡¿Como un búnker subterráneo?!>"

    # game/beyond the bet/undergroundorgend.rpy:887
    old "1. <It must be like looking in a mirror to you.>"
    new "1. <Debe de ser como mirarte en un espejo.>"

    # game/beyond the bet/undergroundorgend.rpy:889
    old "2. <He really is an asshole.>"
    new "2. <De verdad es un imbécil.>"

    # game/beyond the bet/undergroundorgend.rpy:894
    old "1. <Which thing?>"
    new "1. <¿Qué cosa?>"

    # game/beyond the bet/undergroundorgend.rpy:904
    old "1. <I'm pretty good at it, eh?>"
    new "1. <Se me da bastante bien, ¿eh?>"

    # game/beyond the bet/undergroundorgend.rpy:907
    old "1. <...Yes, I'm sure.>"
    new "1. <...Sí, estoy segur[letra].>"

    # game/beyond the bet/undergroundorgend.rpy:910
    old "1. <If it's important to you, it's important to me.>"
    new "1. <Si es importante para ti, es importante para mí.>"

    # game/beyond the bet/undergroundorgend.rpy:912
    old "2. <I want to help your people.>"
    new "2. <Quiero ayudar a tu gente.>"

    # game/beyond the bet/undergroundorgend.rpy:915
    old "1. <And maybe this will lead to an official way of us getting off their systems.>"
    new "1. <Y quizá esto nos lleve a una forma oficial de salir de sus sistemas.>"

    # game/beyond the bet/undergroundorgend.rpy:923
    old "1. <You and me, Casper.>"
    new "1. <Tú y yo, Casper.>"

    # game/beyond the bet/undergroundorgend.rpy:926
    old "1. <Underground mob bosses.>"
    new "1. <Jefes de la mafia subterránea.>"

    # game/beyond the bet/undergroundorgend.rpy:931
    old "1. <Yes. Underground mob bosses.>"
    new "1. <Sí. Jefes de la mafia subterránea.>"

    # game/beyond the bet/undergroundorgend.rpy:938
    old "1. <Let's do this, Casper.>"
    new "1. <Hagámoslo, Casper.>"

    # game/beyond the bet/undergroundorgend.rpy:988
    old "1. <Yeah, I'm here.>"
    new "1. <Sí, aquí estoy.>"

    # game/beyond the bet/undergroundorgend.rpy:990
    old "2. <Where else would I be but by your side?>"
    new "2. <¿Dónde más estaría sino a tu lado?>"

    # game/beyond the bet/undergroundorgend.rpy:997
    old "1. <Just a normal Tuesday afternoon with my boyfriend.>"
    new "1. <Solo una tarde normal de martes con mi novio.>"

    # game/beyond the bet/undergroundorgend.rpy:1000
    old "1. <Yeah. Let's change the world.>"
    new "1. <Sí. Cambiemos el mundo.>"
