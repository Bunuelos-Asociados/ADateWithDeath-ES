# TODO: Translation updated at 2026-10-15 18:36

# game/beyond the bet/8dlc_roomexplore.rpy:225
translate Spanish bed_hub8_50c1a7d9:

    # "Sitting on the edge of your bed, you find yourself glad to be feeling better."
    "Sentad[letra] al borde de tu cama, te alegras de sentirte mejor."

# game/beyond the bet/8dlc_roomexplore.rpy:226
translate Spanish bed_hub8_3c141cfb:

    # "You lean over and smell the flowers that Casper gave you."
    "Te inclinas y hueles las flores que te dio Casper."

# game/beyond the bet/8dlc_roomexplore.rpy:227
translate Spanish bed_hub8_a7068cf3:

    # "They're already drying out a little, but that's okay."
    "Ya se están secando un poco, pero no pasa nada."

# game/beyond the bet/8dlc_roomexplore.rpy:232
translate Spanish bed_hub8_b0470a30:

    # "Then you'll get to keep them forever."
    "Así podrás conservarlas para siempre."

# game/beyond the bet/8dlc_roomexplore.rpy:235
translate Spanish bed_hub8_8a3f5a60:

    # "Then you get to keep the smell for months!"
    "¡Así podrás conservar su aroma durante meses!"

# game/beyond the bet/8dlc_roomexplore.rpy:238
translate Spanish bed_hub8_f8a5f59b:

    # "It'll be fun to look back at, one day."
    "Será divertido volver a mirarlas algún día."

# game/beyond the bet/8dlc_roomexplore.rpy:241
translate Spanish bed_hub8_ea9b02a1:

    # "But the memory of them will live in your mind forever."
    "Pero el recuerdo de ellas vivirá en tu mente para siempre."

# game/beyond the bet/8dlc_roomexplore.rpy:243
translate Spanish bed_hub8_c3e8854d:

    # "For now, you enjoy the beautiful bouquet, the image of Casper outside your window burnt into your mind."
    "Por ahora, disfrutas del hermoso ramo, con la imagen de Casper frente a tu ventana grabada a fuego en tu mente."

# game/beyond the bet/8dlc_roomexplore.rpy:254
translate Spanish door_hub8_7e5b7401:

    # "You can't help but put your ear to the door when you hear someone coming down the staircase."
    "No puedes evitar pegar la oreja a la puerta cuando oyes a alguien bajar por la escalera."

# game/beyond the bet/8dlc_roomexplore.rpy:255
translate Spanish door_hub8_112b82bd:

    # "You hear a voice, though muffled. A different voice to any of your previous eavesdropping sessions."
    "Oyes una voz, aunque amortiguada. Distinta a cualquiera de tus anteriores sesiones de espionaje."

# game/beyond the bet/8dlc_roomexplore.rpy:256
translate Spanish door_hub8_5481fd6c:

    # "A different neighbor?"
    "¿Un vecino distinto?"

# game/beyond the bet/8dlc_roomexplore.rpy:257
translate Spanish door_hub8_eeca6305:

    # "'Mom, I promise, it'll be fine. Yeah, yeah, I know it's far away.'"
    "'Mamá, te lo prometo, todo saldrá bien. Sí, sí, ya sé que queda lejos.'"

# game/beyond the bet/8dlc_roomexplore.rpy:258
translate Spanish door_hub8_90d04736:

    # "You can only hear half of the conversation - a phone call?"
    "Solo puedes oír la mitad de la conversación... ¿una llamada telefónica?"

# game/beyond the bet/8dlc_roomexplore.rpy:259
translate Spanish door_hub8_2c651367:

    # "'It's only for a few months, then I'll be coming back. You're acting like I'm moving to another country or something. It's only a state away.'"
    "'Será solo por unos meses, luego volveré. Actúas como si me fuera a mudar a otro país o algo así. ¡Ni siquiera me voy tan lejos, solo a otro estado!'"

# game/beyond the bet/8dlc_roomexplore.rpy:260
translate Spanish door_hub8_3cd75bb4:

    # "'What do you mean, why are you going?'"
    "'¿Cómo que por qué me voy?'"

# game/beyond the bet/8dlc_roomexplore.rpy:261
translate Spanish door_hub8_3aba33d3:

    # "'Because I was asked to, and to be totally honest, I'm a little tired of all the traffic, and the rent in this city is insane.'"
    "'Porque me lo pidieron y, honestamente, ya me cansa un poco el tráfico y el alquiler de esta ciudad es una locura.'"

# game/beyond the bet/8dlc_roomexplore.rpy:262
translate Spanish door_hub8_1ccd2745:

    # "'I promise, it'll just be a few months. Help run the antique store until Auntie gets back, get some fresh air, then come home.'"
    "'Te lo prometo, solo serán unos meses. Ayudaré a llevar la tienda de antigüedades hasta que vuelva la tía, aprovecharé para respirar aire fresco y después regresaré a casa.'"

# game/beyond the bet/8dlc_roomexplore.rpy:263
translate Spanish door_hub8_e804025c:

    # "'...No, I've never run a store before, but her letter said she has some staff who can help me. Plus, it's just an antique store in a tiny town in the middle of nowhere, it's not exactly rocket science.'"
    "'...No, nunca he estado a cargo de una tienda, pero en su carta decía que tiene empleados que pueden ayudarme. Además, es solo una tienda de antigüedades en un pueblito perdido en medio de la nada. Tampoco es que sea tan complicado.'"

# game/beyond the bet/8dlc_roomexplore.rpy:264
translate Spanish door_hub8_09f29b00:

    # "The voice lets out a soft sigh."
    "La voz suelta un suave suspiro."

# game/beyond the bet/8dlc_roomexplore.rpy:265
translate Spanish door_hub8_a8375964:

    # "'Alright, mom. I'll talk to you later. Yeah, love you too.'"
    "'Está bien, mamá. Hablamos luego. Sí, yo también te quiero.'"

# game/beyond the bet/8dlc_roomexplore.rpy:266
translate Spanish door_hub8_5fbe38b6:

    # "And with that, the person finishes their call."
    "Y con eso, la persona termina su llamada."

# game/beyond the bet/8dlc_roomexplore.rpy:267
translate Spanish door_hub8_3136afc2:

    # "'God, she worries too much. What's the worst that can happen?'"
    "'Dios, se preocupa demasiado. ¿Qué es lo peor que podría pasar?'"

# game/beyond the bet/8dlc_roomexplore.rpy:268
translate Spanish door_hub8_ac335645:

    # "The footsteps continue, descending the staircase until they reach the bottom, and a door creaks open, then shuts."
    "Los pasos continúan, bajando la escalera hasta llegar abajo, y una puerta cruje al abrirse y luego se cierra."

# game/beyond the bet/8dlc_roomexplore.rpy:269
translate Spanish door_hub8_c4e05c2d:

    # "Then, silence."
    "Luego, silencio."

# game/beyond the bet/8dlc_roomexplore.rpy:275
translate Spanish door_hub8_aa7fd0ac:

    # "It's quiet outside your door. No one else is walking by for now."
    "Afuera de tu puerta está tranquilo. Por ahora no pasa nadie más."

# game/beyond the bet/8dlc_roomexplore.rpy:288
translate Spanish pet_hub8_b4bb8599:

    # "You sit down beside [pet_name] and start prattling on about your day, your thoughts, your feelings, anything that comes to mind."
    "Te sientas junto a [pet_name] y empiezas a parlotear sobre tu día, tus pensamientos, tus sentimientos, lo que se te ocurra."

# game/beyond the bet/8dlc_roomexplore.rpy:289
translate Spanish pet_hub8_351de06c:

    # "The best thing about a pet is that they have to sit there and listen to it."
    "Lo mejor de tener una mascota es que no le queda más remedio que quedarse ahí y escucharte."

# game/beyond the bet/8dlc_roomexplore.rpy:290
translate Spanish pet_hub8_7f437f2b:

    # "But you think [pet_name] doesn't really mind."
    "Pero crees que a [pet_name] en realidad no le molesta."

# game/beyond the bet/8dlc_roomexplore.rpy:295
translate Spanish pet_hub8_5fe34944:

    # "You lay down on your bed beside [pet_name], kicking your legs behind you."
    "Te tumbas en tu cama junto a [pet_name], moviendo las piernas hacia atrás."

# game/beyond the bet/8dlc_roomexplore.rpy:296
translate Spanish pet_hub8_be10b995:

    # "It's still early, and [pet_name] is dozing. You smile, then run a finger down their head."
    "Aún es temprano y [pet_name] está dormitando. Sonríes y deslizas un dedo por su cabeza."

# game/beyond the bet/8dlc_roomexplore.rpy:297
translate Spanish pet_hub8_5d9af816:

    # "You're struck with a sudden happiness - a cozy one. It's a warmth that spreads through your chest."
    "Te invade una felicidad repentina, una acogedora. Es un calor que se extiende por tu pecho."

# game/beyond the bet/8dlc_roomexplore.rpy:298
translate Spanish pet_hub8_9ff48153:

    # "You feel very lucky to have gotten to know [pet_name]."
    "Te sientes muy afortunad[letra] de haber llegado a conocer a [pet_name]."

# game/beyond the bet/8dlc_roomexplore.rpy:299
translate Spanish pet_hub8_602f140e:

    # "You're [pet_name]'s entire life, and you're honored to be by their side."
    "Eres toda la vida de [pet_name], y te sientes honrad[letra] de estar a su lado."

# game/beyond the bet/8dlc_roomexplore.rpy:324
translate Spanish plant_hub8_c1229c6a:

    # "You give your little sprout a big drink of water."
    "Le das a tu pequeño retoño un gran trago de agua."

# game/beyond the bet/8dlc_roomexplore.rpy:325
translate Spanish plant_hub8_c5de961c:

    # "Though you don't speak sprout, it seems to say thank you."
    "Aunque no hablas el idioma de los retoños, parece darte las gracias."

# game/beyond the bet/8dlc_roomexplore.rpy:327
translate Spanish plant_hub8_518e64fd:

    # "Your little sprout has grown some leaves!"
    "¡A tu pequeño retoño le han salido hojas!"

# game/beyond the bet/8dlc_roomexplore.rpy:328
translate Spanish plant_hub8_8036dce1:

    # "You can't help but feel proud as you give it a big drink of water."
    "No puedes evitar sentir orgullo mientras le das un gran trago de agua."

# game/beyond the bet/8dlc_roomexplore.rpy:330
translate Spanish plant_hub8_adaac543:

    # "Even more leaves have appeared now!"
    "¡Aún más hojas han aparecido ahora!"

# game/beyond the bet/8dlc_roomexplore.rpy:331
translate Spanish plant_hub8_a4970463:

    # "You water it generously and feel excited that, this time, you didn't kill your plant instantly."
    "La riegas abundantemente y te emociona comprobar que esta vez no has matado tu planta nada más empezar."

# game/beyond the bet/8dlc_roomexplore.rpy:333
translate Spanish plant_hub8_2087a70f:

    # "Your little plant is growing healthily!"
    "¡Tu pequeña planta está creciendo sana y fuerte!"

# game/beyond the bet/8dlc_roomexplore.rpy:334
translate Spanish plant_hub8_80d209cf:

    # "You give it a big drink of water, excited about its growth."
    "Le das un buen trago de agua, con entusiasmo por su crecimiento."

# game/beyond the bet/8dlc_roomexplore.rpy:336
translate Spanish plant_hub8_41affa3b:

    # "Your little plant has sprouted some buds!"
    "¡A tu pequeña planta le han salido algunos botones florales!"

# game/beyond the bet/8dlc_roomexplore.rpy:337
translate Spanish plant_hub8_75fbf720:

    # "You almost tear up when you notice them. They're so cute - you can't wait to see what the flowers will look like."
    "Casi se te saltan las lágrimas al verlos. ¡Son tan adorables! No puedes esperar a ver cómo serán las flores."

# game/beyond the bet/8dlc_roomexplore.rpy:339
translate Spanish plant_hub8_33ab5804:

    # "The buds on your little plant seem to be doing well!"
    "¡Los botones florales de tu pequeña planta parecen estar desarrollándose bien!"

# game/beyond the bet/8dlc_roomexplore.rpy:340
translate Spanish plant_hub8_8b2d7914:

    # "You can't believe how healthy it is... though after what Casper told you, you're starting to understand why..."
    "No puedes creer lo bien que está creciendo... aunque, después de lo que te contó Casper, empiezas a entender por qué..."

# game/beyond the bet/8dlc_roomexplore.rpy:342
translate Spanish plant_hub8_3a8cf5f3:

    # "Your little sprout has grown up happily and healthily all because of you, and today..."
    "Tu pequeño retoño ha crecido feliz y saludable gracias a ti, y hoy..."

# game/beyond the bet/8dlc_roomexplore.rpy:349
translate Spanish plant_hub8_3542ab9b:

    # "It rewards you with four beautiful flowers!"
    "¡Te recompensa con cuatro hermosas flores!"

# game/beyond the bet/8dlc_roomexplore.rpy:350
translate Spanish plant_hub8_c9e73e13:

    # "You water your plant and feel a sense of accomplishment."
    "Riegas tu planta y sientes una gran satisfacción."

# game/beyond the bet/8dlc_roomexplore.rpy:353
translate Spanish plant_hub8_8a980ec9:

    # "You give your beautiful flower a healthy dose of water."
    "Le das a tu hermosa flor una buena dosis de agua."

# game/beyond the bet/8dlc_roomexplore.rpy:354
translate Spanish plant_hub8_51a7614d:

    # "It seems to lean towards you in thanks, as if bowing, but you're probably just imagining that."
    "Parece inclinarse hacia ti en señal de agradecimiento, como si hiciera una reverencia, pero seguramente solo lo estás imaginando."

# game/beyond the bet/8dlc_roomexplore.rpy:369
translate Spanish plant_hub8_7e50e02a:

    # "You continue watering your plant."
    "Sigues regando tu planta."

# game/beyond the bet/8dlc_roomexplore.rpy:370
translate Spanish plant_hub8_f059833a:

    # "More is ALWAYS better than less."
    "Más es SIEMPRE mejor que menos."

# game/beyond the bet/8dlc_roomexplore.rpy:384
translate Spanish plant_hub8_43f3b05b:

    # "In your mind, you hear a tiny scream."
    "En tu mente, oyes un diminuto grito."

# game/beyond the bet/8dlc_roomexplore.rpy:385
translate Spanish plant_hub8_6d8cc4c7:

    # "'No, please. No more! I have enough water!'"
    "'¡No, por favor! ¡Basta! ¡Ya tengo suficiente agua!'"

# game/beyond the bet/8dlc_roomexplore.rpy:386
translate Spanish plant_hub8_46037c6d:

    # "You don't listen to those screams. You just continue pouring water into the plant pot."
    "No haces caso a esos gritos. Simplemente sigues vertiendo agua en la maceta."

translate Spanish strings:

    # game/beyond the bet/8dlc_roomexplore.rpy:96
    old "Your Pet"
    new "Tu Mascota"

    # game/beyond the bet/8dlc_roomexplore.rpy:231
    old "1. You plan to press some of them into a bookmark."
    new "1. Planeas prensar algunas flores para hacer un marcapáginas."

    # game/beyond the bet/8dlc_roomexplore.rpy:234
    old "2. Now is a great time to try making potpourri."
    new "2. Es un buen momento para intentar hacer popurrí."

    # game/beyond the bet/8dlc_roomexplore.rpy:237
    old "3. You want to use them in your journal."
    new "3. Quieres usarlas en tu diario."

    # game/beyond the bet/8dlc_roomexplore.rpy:240
    old "4. Everything dies eventually."
    new "4. Todo muere tarde o temprano."

    # game/beyond the bet/8dlc_roomexplore.rpy:286
    old "Talk to [pet_name]."
    new "Hablar con [pet_name]."

    # game/beyond the bet/8dlc_roomexplore.rpy:293
    old "Hang out with [pet_name]."
    new "Pasar el rato con [pet_name]."

