# TODO: Translation updated at 2026-10-15 18:36

# game/beyond the bet/day7dlc.rpy:8
translate Spanish day7dlc_start_d41d8cd9:

    # nvl clear
    nvl clear

# game/beyond the bet/day7dlc.rpy:19
translate Spanish day7dlc_start_abab08ef:

    # center_text "You woke up this morning to find Casper... gone!"
    center_text "Esta mañana te despertaste y descubriste que Casper... ¡se había ido!"

# game/beyond the bet/day7dlc.rpy:23
translate Spanish day7dlc_start_5916f3d1:

    # center_text "At first you stressed out, thinking that something happened to him."
    center_text "Al principio te angustiaste, pensando que le había pasado algo."

# game/beyond the bet/day7dlc.rpy:24
translate Spanish day7dlc_start_92054814:

    # center_text "Or worse, you imagined him all along..."
    center_text "O peor, que lo habías imaginado todo este tiempo..."

# game/beyond the bet/day7dlc.rpy:25
translate Spanish day7dlc_start_d8fb2ae6:

    # center_text "But, as it turns out, Casper's just in a career that doesn't wait for anybody."
    center_text "Pero resulta que Casper simplemente tiene un trabajo que no espera a nadie."

# game/beyond the bet/day7dlc.rpy:26
translate Spanish day7dlc_start_3ddcb108:

    # center_text "You found a note on your side table that said he left food in the fridge."
    center_text "Encontraste una nota en tu mesita de noche que decía que había dejado comida en la nevera."

# game/beyond the bet/day7dlc.rpy:27
translate Spanish day7dlc_start_0f972733:

    # center_text "You shiver a little, scared, but it's the thought that counts, right?"
    center_text "Te estremeces un poco, con miedo, pero lo que cuenta es la intención, ¿no?"

# game/beyond the bet/day7dlc.rpy:28
translate Spanish day7dlc_start_56d7bf38:

    # center_text "After getting up, stretching, and spending some time with [pet_name], you notice a flyer under your door."
    center_text "Después de levantarte, estirarte y pasar un rato con [pet_name], notas un folleto debajo de tu puerta."

# game/beyond the bet/day7dlc.rpy:29
translate Spanish day7dlc_start_b27bce80:

    # center_text "There's a big festival on tomorrow night. Fireworks, stalls, and a fun time await."
    center_text "Mañana por la noche hay un gran festival. Te esperan fuegos artificiales, puestos y diversión."

# game/beyond the bet/day7dlc.rpy:30
translate Spanish day7dlc_start_41486173:

    # center_text "You sigh, just a little. That would be nice, but technically... today is the day you're supposed to die."
    center_text "Suspiras, solo un poco. Sería lindo, pero técnicamente... hoy es el día en que se supone que vas a morir."

# game/beyond the bet/day7dlc.rpy:70
translate Spanish day7dlc_start2_1139fed8:

    # GR "[playerfirstname!l], are you awake yet?"
    GR "[playerfirstname!l], ¿ya despertaste?"

# game/beyond the bet/day7dlc.rpy:71
translate Spanish day7dlc_start2_13362482:

    # GR "i hope you are feeling better this morning."
    GR "espero que te sientas mejor esta mañana."

# game/beyond the bet/day7dlc.rpy:72
translate Spanish day7dlc_start2_f270cb25:

    # GR "i know i left a note, but i still feel it is proper to also apologize for leaving so abruptly here, too."
    GR "sé que dejé una nota, pero aun así considero apropiado disculparme también por aquí por haberme ido tan de repente."

# game/beyond the bet/day7dlc.rpy:73
translate Spanish day7dlc_start2_e7c25412:

    # GR "work calls, as it does, and you..."
    GR "el trabajo llama, como suele hacerlo, y tú..."

# game/beyond the bet/day7dlc.rpy:74
translate Spanish day7dlc_start2_00f94f74:

    # GR "well, you were sleeping very soundly."
    GR "bueno, dormías muy profundamente."

# game/beyond the bet/day7dlc.rpy:75
translate Spanish day7dlc_start2_1fd3d9ae:

    # GR "i could not bring myself to wake you."
    GR "no fui capaz de despertarte."

# game/beyond the bet/day7dlc.rpy:78
translate Spanish day7dlc_start2_d188f16f:

    # player "I'm awake!"
    player "¡Ya desperté!"

# game/beyond the bet/day7dlc.rpy:80
translate Spanish day7dlc_start2_af091050:

    # player "Did you miss me?"
    player "¿Me extrañaste?"

# game/beyond the bet/day7dlc.rpy:83
translate Spanish day7dlc_start2_c715ad07:

    # player "Thanks for making me breakfast."
    player "Gracias por prepararme el desayuno."

# game/beyond the bet/day7dlc.rpy:84
translate Spanish day7dlc_start2_47f16c4b:

    # GR "there is no need to thank me."
    GR "no hay nada que agradecer."

# game/beyond the bet/day7dlc.rpy:85
translate Spanish day7dlc_start2_267a2bd7:

    # GR "it was not difficult."
    GR "no fue difícil."

# game/beyond the bet/day7dlc.rpy:88
translate Spanish day7dlc_start2_77af9244:

    # player "The remains of my kitchen say otherwise."
    player "Las ruinas de mi cocina dicen lo contrario."

# game/beyond the bet/day7dlc.rpy:89
translate Spanish day7dlc_start2_a6de612c:

    # GR "ah."
    GR "ah."

# game/beyond the bet/day7dlc.rpy:90
translate Spanish day7dlc_start2_ebc9eb7a:

    # GR "yes."
    GR "sí."

# game/beyond the bet/day7dlc.rpy:91
translate Spanish day7dlc_start2_d406d359:

    # GR "as i said last night, your kitchen and i engaged in a manner of battle over who would be the dominated..."
    GR "como dije anoche, tu cocina y yo libramos una especie de batalla para decidir quién sería el dominado..."

# game/beyond the bet/day7dlc.rpy:92
translate Spanish day7dlc_start2_ecd743fa:

    # GR "and who would be the dominatee."
    GR "y quién el dominatario."

# game/beyond the bet/day7dlc.rpy:93
translate Spanish day7dlc_start2_022f1b1c:

    # GR "once again, i have found myself superior."
    GR "una vez más, he resultado superior."

# game/beyond the bet/day7dlc.rpy:96
translate Spanish day7dlc_start2_311ffce3:

    # player "To my kitchen?"
    player "¿A mi cocina?"

# game/beyond the bet/day7dlc.rpy:97
translate Spanish day7dlc_start2_feec4b51:

    # GR "correct."
    GR "correcto."

# game/beyond the bet/day7dlc.rpy:100
translate Spanish day7dlc_start2_1760dd05:

    # player "I dunno."
    player "No sé."

# game/beyond the bet/day7dlc.rpy:103
translate Spanish day7dlc_start2_69981310:

    # player "My kitchen can throw some hands when it wants to."
    player "Mi cocina sabe repartir golpes cuando quiere."

# game/beyond the bet/day7dlc.rpy:104
translate Spanish day7dlc_start2_0cd90f76:

    # GR "i found that out myself."
    GR "yo mismo lo descubrí."

# game/beyond the bet/day7dlc.rpy:105
translate Spanish day7dlc_start2_0f987ae0:

    # GR "and i conquered it."
    GR "y la conquisté."

# game/beyond the bet/day7dlc.rpy:108
translate Spanish day7dlc_start2_fca161e2:

    # player "Congrats."
    player "Felicidades."

# game/beyond the bet/day7dlc.rpy:111
translate Spanish day7dlc_start2_255a4dc4:

    # player "Casper, conqueror of kitchens."
    player "Casper, conquistador de cocinas."

# game/beyond the bet/day7dlc.rpy:112
translate Spanish day7dlc_start2_fa864652:

    # GR "i imagine you are saying that in jest, but it is true."
    GR "imagino que lo dices en broma, pero es cierto."

# game/beyond the bet/day7dlc.rpy:113
translate Spanish day7dlc_start2_b3ba22cc:

    # GR "in fact, i may put that title on my resume."
    GR "de hecho, quizá ponga ese título en mi currículum."

# game/beyond the bet/day7dlc.rpy:117
translate Spanish day7dlc_start2_c8c0aec0:

    # player "Oh, oh. Put me as a reference!"
    player "Oh, oh. ¡Ponme de referencia!"

# game/beyond the bet/day7dlc.rpy:119
translate Spanish day7dlc_start2_db26758e:

    # GR "and what will you say if anyone calls you about me?"
    GR "¿y qué dirás si alguien te llama para preguntar por mí?"

# game/beyond the bet/day7dlc.rpy:123
translate Spanish day7dlc_start2_430e1e1b:

    # player "I'm scared of phone calls. I wouldn't pick up."
    player "Me dan miedo las llamadas. No contestaría."

# game/beyond the bet/day7dlc.rpy:126
translate Spanish day7dlc_start2_048be376:

    # player "I'd say your track record work-wise is a little iffy."
    player "Diría que tu historial laboral es un poco dudoso."

# game/beyond the bet/day7dlc.rpy:130
translate Spanish day7dlc_start2_7c0524d2:

    # player "I mean, you're not doing a very good job with me, are you?"
    player "O sea, no estás haciendo un muy buen trabajo conmigo, ¿verdad?"

# game/beyond the bet/day7dlc.rpy:133
translate Spanish day7dlc_start2_77e85f8a:

    # player "I'd put on a funny voice and pretend they called the wrong number."
    player "Pondría una voz graciosa y fingiría que se equivocaron de número."

# game/beyond the bet/day7dlc.rpy:135
translate Spanish day7dlc_start2_95151b2c:

    # GR "....."
    GR "....."

# game/beyond the bet/day7dlc.rpy:136
translate Spanish day7dlc_start2_16257690:

    # GR "you are hopeless."
    GR "eres un caso perdido."

# game/beyond the bet/day7dlc.rpy:142
translate Spanish day7dlc_start2_e654c14a:

    # player "I still want to thank you."
    player "Aun así quiero agradecerte."

# game/beyond the bet/day7dlc.rpy:145
translate Spanish day7dlc_start2_3dc2cff6:

    # player "I haven't had someone cook for me in years."
    player "Hace años que nadie cocina para mí."

# game/beyond the bet/day7dlc.rpy:146
translate Spanish day7dlc_start2_471de712:

    # GR "that makes no sense."
    GR "eso no tiene sentido."

# game/beyond the bet/day7dlc.rpy:149
translate Spanish day7dlc_start2_00eed014:

    # player "In what way?"
    player "¿En qué sentido?"

# game/beyond the bet/day7dlc.rpy:150
translate Spanish day7dlc_start2_a375ac6f:

    # GR "you are the kind of person anyone and everyone should want to cook for."
    GR "eres el tipo de persona para quien todo el mundo, sin excepción, debería querer cocinar."

# game/beyond the bet/day7dlc.rpy:151
translate Spanish day7dlc_start2_21855cf8:

    # GR "i do not understand why you are not being treated as you deserve."
    GR "no entiendo por qué no te tratan como mereces."

# game/beyond the bet/day7dlc.rpy:154
translate Spanish day7dlc_start2_9b78b9b3:

    # player "A couple of days ago you thought I was an idiot."
    player "Hace un par de días pensabas que yo era [arti_2] idiota."

# game/beyond the bet/day7dlc.rpy:155
translate Spanish day7dlc_start2_13f739a3:

    # GR "did i ever say i changed my mind?"
    GR "¿acaso dije alguna vez que había cambiado de opinión?"

# game/beyond the bet/day7dlc.rpy:158
translate Spanish day7dlc_start2_c87ddf10:

    # player "Wow."
    player "Wow."

# game/beyond the bet/day7dlc.rpy:161
translate Spanish day7dlc_start2_23d0c991:

    # player "You're a bigger idiot."
    player "Tú eres más idiota."

# game/beyond the bet/day7dlc.rpy:162
translate Spanish day7dlc_start2_23639830:

    # GR "that is beside the point."
    GR "eso es irrelevante."

# game/beyond the bet/day7dlc.rpy:163
translate Spanish day7dlc_start2_086a6f13:

    # GR "you are an idiot who deserves breakfast in bed and flowers every evening."
    GR "eres [arti_2] idiota que merece desayuno en la cama y flores todas las noches."

# game/beyond the bet/day7dlc.rpy:166
translate Spanish day7dlc_start2_ae6c7a60:

    # player "...Oh."
    player "...Oh."

# game/beyond the bet/day7dlc.rpy:169
translate Spanish day7dlc_start2_38dc5552:

    # player "Well, thanks Casper."
    player "Bueno, gracias, Casper."

# game/beyond the bet/day7dlc.rpy:172
translate Spanish day7dlc_start2_e95dec11:

    # player "That's nice of you to say."
    player "Qué amable que lo digas."

# game/beyond the bet/day7dlc.rpy:175
translate Spanish day7dlc_start2_cf07461a:

    # player "I'd like to try cooking for you, sometime."
    player "Me gustaría intentar cocinar para ti, algún día."

# game/beyond the bet/day7dlc.rpy:176
translate Spanish day7dlc_start2_837fce23:

    # GR "if we are given the chance, then that would be... nice."
    GR "si se nos da la oportunidad, eso sería... agradable."

# game/beyond the bet/day7dlc.rpy:179
translate Spanish day7dlc_start2_3a950dfb:

    # player "I'd make something super spicy."
    player "Haría algo súper picante."

# game/beyond the bet/day7dlc.rpy:180
translate Spanish day7dlc_start2_d8dc5554:

    # GR "i am quite fond of spice."
    GR "soy bastante aficionado al picante."

# game/beyond the bet/day7dlc.rpy:183
translate Spanish day7dlc_start2_17419a65:

    # player "How spicy are we talking?"
    player "¿De qué nivel de picante estamos hablando?"

# game/beyond the bet/day7dlc.rpy:184
translate Spanish day7dlc_start2_4229a73c:

    # GR "hm."
    GR "hm."

# game/beyond the bet/day7dlc.rpy:185
translate Spanish day7dlc_start2_c78a5175:

    # GR "on a scale of 1-10, perhaps... an 8, or so."
    GR "en una escala del 1 al 10, quizá... un 8, más o menos."

# game/beyond the bet/day7dlc.rpy:188
translate Spanish day7dlc_start2_93ddb0c6:

    # player "Not bad, not bad."
    player "Nada mal, nada mal."

# game/beyond the bet/day7dlc.rpy:191
translate Spanish day7dlc_start2_8351c9b3:

    # player "Alright, I'll cook you something that'll make your tongue fall off :D"
    player "Muy bien, te cocinaré algo que hará que se te caiga la lengua :D"

# game/beyond the bet/day7dlc.rpy:192
translate Spanish day7dlc_start2_d2817595:

    # GR "what."
    GR "¿qué?"

# game/beyond the bet/day7dlc.rpy:193
translate Spanish day7dlc_start2_82aa12b1:

    # GR "i need that."
    GR "la necesito."

# game/beyond the bet/day7dlc.rpy:196
translate Spanish day7dlc_start2_66a22e58:

    # player "For?"
    player "¿Para qué?"

# game/beyond the bet/day7dlc.rpy:197
translate Spanish day7dlc_start2_ab1a6bd8:

    # GR "talking??? eating???? tongue related activities?????"
    GR "¿¿¿hablar??? ¿¿¿comer???? ¿¿¿actividades relacionadas con la lengua?????"

# game/beyond the bet/day7dlc.rpy:200
translate Spanish day7dlc_start2_3994d0cd:

    # player "Hmmm..."
    player "Hmmm..."

# game/beyond the bet/day7dlc.rpy:203
translate Spanish day7dlc_start2_ac3b3355:

    # player "Fine."
    player "Está bien."

# game/beyond the bet/day7dlc.rpy:206
translate Spanish day7dlc_start2_6a409ecd:

    # player "I'll spare your tongue... this time."
    player "Perdonaré tu lengua... esta vez."

# game/beyond the bet/day7dlc.rpy:209
translate Spanish day7dlc_start2_02e4ce9f:

    # player "But you better watch it, pretty boy."
    player "Pero más te vale tener cuidado, chico bonito."

# game/beyond the bet/day7dlc.rpy:212
translate Spanish day7dlc_start2_c7396062:

    # player "I'll get you with my cooking one day."
    player "Algún día te voy a vencer con mi cocina."

# game/beyond the bet/day7dlc.rpy:213
translate Spanish day7dlc_start2_1faaefd9:

    # GR "please don't."
    GR "por favor, no."

# game/beyond the bet/day7dlc.rpy:217
translate Spanish day7dlc_start2_bec60862:

    # player "I want to bake you something sweet!"
    player "¡Quiero hornearte algo dulce!"

# game/beyond the bet/day7dlc.rpy:220
translate Spanish day7dlc_start2_804a659e:

    # player "Cake, or muffins, or cookies, maybe?"
    player "¿Pastel, muffins o galletas, quizás?"

# game/beyond the bet/day7dlc.rpy:221
translate Spanish day7dlc_start2_413cdaac:

    # GR "i don't believe i've ever had any of those."
    GR "no creo que haya probado nada de eso nunca."

# game/beyond the bet/day7dlc.rpy:224
translate Spanish day7dlc_start2_f2f47468:

    # player "WHAT?"
    player "¡¿QUÉ?!"

# game/beyond the bet/day7dlc.rpy:227
translate Spanish day7dlc_start2_c0bb3548:

    # player "HOW?"
    player "¿CÓMO?"

# game/beyond the bet/day7dlc.rpy:228
translate Spanish day7dlc_start2_6c69b8a5:

    # GR "there is not an excess of bakeries in the underworld."
    GR "no hay muchas panaderías en el inframundo."

# game/beyond the bet/day7dlc.rpy:231
translate Spanish day7dlc_start2_3bf47e79:

    # player "I'm sure you could find SOME baked goods!"
    player "¡Seguro que podrías encontrar ALGO de pan o pasteles!"

# game/beyond the bet/day7dlc.rpy:232
translate Spanish day7dlc_start2_312fdf2d:

    # GR "likely."
    GR "probablemente."

# game/beyond the bet/day7dlc.rpy:233
translate Spanish day7dlc_start2_917fd2d7:

    # GR "but it is time i do not have and effort that could be used elsewhere."
    GR "pero es tiempo que no tengo y esfuerzo que podría usarse en otra cosa."

# game/beyond the bet/day7dlc.rpy:236
translate Spanish day7dlc_start2_9f5d7fc9:

    # player "What exactly do you EAT?"
    player "¿Qué COMES exactamente?"

# game/beyond the bet/day7dlc.rpy:237
translate Spanish day7dlc_start2_00149f2c:

    # GR "whatever i have around."
    GR "lo que tenga a mano."

# game/beyond the bet/day7dlc.rpy:238
translate Spanish day7dlc_start2_dad3f552:

    # GR "usually something instant or prepackaged."
    GR "normalmente algo instantáneo o de paquete."

# game/beyond the bet/day7dlc.rpy:239
translate Spanish day7dlc_start2_b1d4bd4a:

    # GR "noodles are my go-to."
    GR "los fideos son mi opción de siempre."

# game/beyond the bet/day7dlc.rpy:242
translate Spanish day7dlc_start2_1862eff8:

    # player "How can the Grim Reaper be such a mess of a man?"
    player "¿Cómo puede la Parca ser un hombre tan desastroso?"

# game/beyond the bet/day7dlc.rpy:243
translate Spanish day7dlc_start2_055258cd:

    # GR "what's wrong with instant meals?"
    GR "¿qué tienen de malo las comidas instantáneas?"

# game/beyond the bet/day7dlc.rpy:246
translate Spanish day7dlc_start2_b9cf2b97:

    # player "It's not exactly a balanced diet, is it?"
    player "No es precisamente una dieta balanceada, ¿o sí?"

# game/beyond the bet/day7dlc.rpy:247
translate Spanish day7dlc_start2_e9960c7a:

    # GR "my body hardly needs a balanced diet."
    GR "mi cuerpo casi no necesita una dieta equilibrada."

# game/beyond the bet/day7dlc.rpy:250
translate Spanish day7dlc_start2_b7f74a9f:

    # player "Okay, I can't lie, you definitely have a good body."
    player "Okey, no te voy a mentir, tienes muy buen cuerpo."

# game/beyond the bet/day7dlc.rpy:253
translate Spanish day7dlc_start2_f705307e:

    # player "But you should still eat a vegetable or something every now and then."
    player "Pero igual deberías comer una verdura o algo de vez en cuando."

# game/beyond the bet/day7dlc.rpy:254
translate Spanish day7dlc_start2_1543fae1:

    # GR "there are vegetables within the cup noodles."
    GR "hay verduras en los vasitos de fideos."

# game/beyond the bet/day7dlc.rpy:257
translate Spanish day7dlc_start2_64fe5695:

    # player "That's not enough!"
    player "¡Eso no es suficiente!"

# game/beyond the bet/day7dlc.rpy:259
translate Spanish day7dlc_start2_d2c57a0e:

    # GR "you are a nag. i do not see the appeal of vegetables."
    GR "eres [arti_2] fastidios[letra]. no le veo el atractivo a las verduras."

# game/beyond the bet/day7dlc.rpy:263
translate Spanish day7dlc_start2_10936f15:

    # player "I'm gonna make you eat vegetables, one way or another."
    player "Voy a hacer que comas verduras, de una forma u otra."

# game/beyond the bet/day7dlc.rpy:265
translate Spanish day7dlc_start2_33321b13:

    # GR "you can try."
    GR "puedes intentarlo."

# game/beyond the bet/day7dlc.rpy:266
translate Spanish day7dlc_start2_aca91df9:

    # GR "by the way..."
    GR "por cierto..."

# game/beyond the bet/day7dlc.rpy:269
translate Spanish day7dlc_start2_5979a8fc:

    # player "Well, I wouldn't mind taking a bite of your eggplant 🍆"
    player "Pues no me importaría darle un mordisco a tu berenjena 🍆"

# game/beyond the bet/day7dlc.rpy:271
translate Spanish day7dlc_start2_a95a98cf:

    # GR "huh?"
    GR "¿eh?"

# game/beyond the bet/day7dlc.rpy:272
translate Spanish day7dlc_start2_079b050c:

    # GR "my... eggplant?"
    GR "mi... ¿berenjena?"

# game/beyond the bet/day7dlc.rpy:276
translate Spanish day7dlc_start2_8d2703ff:

    # player "Yes. I definitely mean the vegetable. Nothing else. No sir."
    player "Sí. Me refiero definitivamente a la verdura. Nada más. No, señor."

# game/beyond the bet/day7dlc.rpy:278
translate Spanish day7dlc_start2_f0a65109:

    # GR "something tells me you don't mean the vegetable."
    GR "algo me dice que no te refieres a la verdura."

# game/beyond the bet/day7dlc.rpy:282
translate Spanish day7dlc_start2_a9d4a2fd:

    # player "I just said I DID mean the vegetable!"
    player "¡Acabo de decir que SÍ me refería a la verdura!"

# game/beyond the bet/day7dlc.rpy:284
translate Spanish day7dlc_start2_a8ffdb3c:

    # GR "you are lying."
    GR "estás mintiendo."

# game/beyond the bet/day7dlc.rpy:288
translate Spanish day7dlc_start2_381db6fa:

    # player "Okay, you caught me, Detective Casper."
    player "Okey, me atrapaste, Detective Casper."

# game/beyond the bet/day7dlc.rpy:292
translate Spanish day7dlc_start2_a7f79f14:

    # player "You're so perceptive."
    player "Eres muy perspicaz."

# game/beyond the bet/day7dlc.rpy:294
translate Spanish day7dlc_start2_075831c9:

    # GR "if you do not mean the vegetable, i believe i understand what you are insinuating."
    GR "si no te refieres a la verdura, creo que entiendo lo que insinúas."

# game/beyond the bet/day7dlc.rpy:296
translate Spanish day7dlc_start2_6251daa9:

    # GR "just to curb disappointment, it is not purple."
    GR "para evitar decepciones, no es morada."

# game/beyond the bet/day7dlc.rpy:300
translate Spanish day7dlc_start2_3c30ef97:

    # player "Your eggplant?"
    player "¿Tu berenjena?"

# game/beyond the bet/day7dlc.rpy:302
translate Spanish day7dlc_start2_2053b22a:

    # GR "yes, my... eggplant."
    GR "sí, mi... berenjena."

# game/beyond the bet/day7dlc.rpy:306
translate Spanish day7dlc_start2_597a112a:

    # player "Are we really having a conversation about your eggplant right now?"
    player "¿De verdad estamos hablando de tu berenjena ahora mismo?"

# game/beyond the bet/day7dlc.rpy:308
translate Spanish day7dlc_start2_18cb16bd:

    # GR "you brought it up in the first place!"
    GR "¡tú la sacaste a colación primero!"

# game/beyond the bet/day7dlc.rpy:309
translate Spanish day7dlc_start2_922e5b37:

    # GR "ugh. that's enough about this... this phallic conversation..."
    GR "ugh. basta de esto... de esta conversación fálica..."

# game/beyond the bet/day7dlc.rpy:310
translate Spanish day7dlc_start2_067918b7:

    # GR "i will perish if we continue."
    GR "pereceré si continuamos."

# game/beyond the bet/day7dlc.rpy:314
translate Spanish day7dlc_start2_4cf9fbe6:

    # player "That sounds unhealthy."
    player "Eso suena poco saludable."

# game/beyond the bet/day7dlc.rpy:315
translate Spanish day7dlc_start2_a6de612c_1:

    # GR "ah."
    GR "ah."

# game/beyond the bet/day7dlc.rpy:316
translate Spanish day7dlc_start2_e79ed355:

    # GR "speaking of unhealthy..."
    GR "hablando de cosas poco saludables..."

# game/beyond the bet/day7dlc.rpy:320
translate Spanish day7dlc_start2_79cd0297:

    # player "I want to give you flowers, too."
    player "También quiero regalarte flores."

# game/beyond the bet/day7dlc.rpy:321
translate Spanish day7dlc_start2_41558a74:

    # GR "hey."
    GR "oye."

# game/beyond the bet/day7dlc.rpy:322
translate Spanish day7dlc_start2_0c021ef4:

    # GR "come up with your own token of affection."
    GR "invéntate tu propia muestra de afecto."

# game/beyond the bet/day7dlc.rpy:325
translate Spanish day7dlc_start2_4e75a05f:

    # player "Did you invent giving flowers as a gift?"
    player "¿Inventaste tú lo de regalar flores?"

# game/beyond the bet/day7dlc.rpy:326
translate Spanish day7dlc_start2_149250fb:

    # GR "maybe i did."
    GR "quizá sí."

# game/beyond the bet/day7dlc.rpy:329
translate Spanish day7dlc_start2_01a7f29d:

    # player "I don't think you did."
    player "No creo que lo hayas hecho."

# game/beyond the bet/day7dlc.rpy:330
translate Spanish day7dlc_start2_34967b5b:

    # GR "no one will ever do it like i do it."
    GR "nadie lo hará jamás como yo."

# game/beyond the bet/day7dlc.rpy:333
translate Spanish day7dlc_start2_ffc5479d:

    # player "Okay, that I can agree with."
    player "Okey, en eso estoy de acuerdo."

# game/beyond the bet/day7dlc.rpy:336
translate Spanish day7dlc_start2_cc2f208d:

    # player "I doubt anyone will ever be outside my window FLYING with flowers again."
    player "Dudo que alguien vuelva a estar frente a mi ventana VOLANDO con flores."

# game/beyond the bet/day7dlc.rpy:337
translate Spanish day7dlc_start2_e715a57b:

    # GR "see."
    GR "ves."

# game/beyond the bet/day7dlc.rpy:338
translate Spanish day7dlc_start2_bd853dc7:

    # GR "i set standards."
    GR "yo fijo los estándares."

# game/beyond the bet/day7dlc.rpy:341
translate Spanish day7dlc_start2_2cf7d4f1:

    # player "Trendsetter over here."
    player "Aquí tenemos a un creador de tendencias."

# game/beyond the bet/day7dlc.rpy:344
translate Spanish day7dlc_start2_766d2c0e:

    # player "I could get used to this kind of treatment."
    player "Podría acostumbrarme a este tipo de trato."

# game/beyond the bet/day7dlc.rpy:347
translate Spanish day7dlc_start2_e04089e2:

    # player "I'm gonna give you a run for your money."
    player "Te voy a dar pelea."

# game/beyond the bet/day7dlc.rpy:350
translate Spanish day7dlc_start2_8178233c:

    # player "Keep an eye out your window, Grimmy boy."
    player "Vigila tu ventana, Parquita."

# game/beyond the bet/day7dlc.rpy:353
translate Spanish day7dlc_start2_9ea0d832:

    # player "I'm gonna be there any second."
    player "Voy a estar ahí en cualquier segundo."

# game/beyond the bet/day7dlc.rpy:354
translate Spanish day7dlc_start2_fa08f3c2:

    # GR "jokes on you, i have no windows."
    GR "mala suerte, no tengo ventanas."

# game/beyond the bet/day7dlc.rpy:357
translate Spanish day7dlc_start2_6306a6ba:

    # player "What?"
    player "¿Qué?"

# game/beyond the bet/day7dlc.rpy:360
translate Spanish day7dlc_start2_3b361ce9:

    # player "No windows?"
    player "¿No tienes ventanas?"

# game/beyond the bet/day7dlc.rpy:361
translate Spanish day7dlc_start2_158b7714:

    # GR "there is no sunlight to come in through them anyway, so it makes little difference."
    GR "igual no entra luz del sol por ellas, así que da casi lo mismo."

# game/beyond the bet/day7dlc.rpy:364
translate Spanish day7dlc_start2_bdeea199:

    # player "Don't you feel kinda boxed in?"
    player "¿No te sientes un poco encerrado?"

# game/beyond the bet/day7dlc.rpy:365
translate Spanish day7dlc_start2_d37cb47f:

    # GR "it is the only way i have known to live."
    GR "es la única forma de vivir que he conocido."

# game/beyond the bet/day7dlc.rpy:366
translate Spanish day7dlc_start2_0523c762:

    # GR "though, i must admit that your apartment is quite... refreshing."
    GR "aunque debo admitir que tu apartamento es bastante... refrescante."

# game/beyond the bet/day7dlc.rpy:368
translate Spanish day7dlc_start2_52a01e80:

    # GR "...are you feeling any better?"
    GR "...¿te sientes mejor?"

# game/beyond the bet/day7dlc.rpy:371
translate Spanish day7dlc_start2_bae0534a:

    # player "Surprisingly, I feel as fit as a fiddle."
    player "Sorprendentemente, me siento san[letra] como una manzana."

# game/beyond the bet/day7dlc.rpy:372
translate Spanish day7dlc_start2_db77a5ae:

    # GR "how can a fiddle be fit or unfit?"
    GR "¿cómo puede una manzana estar sana o enferma?"

# game/beyond the bet/day7dlc.rpy:375
translate Spanish day7dlc_start2_f90be0db:

    # player "Great question."
    player "Buena pregunta."

# game/beyond the bet/day7dlc.rpy:378
translate Spanish day7dlc_start2_9133ca4d:

    # player "I'm sure someone smarter than me knows the answer."
    player "Seguro que alguien más listo que yo sabe la respuesta."

# game/beyond the bet/day7dlc.rpy:381
translate Spanish day7dlc_start2_6f483f9b:

    # player "But, yeah, I feel... good, actually."
    player "Pero sí, me siento... bien, la verdad."

# game/beyond the bet/day7dlc.rpy:382
translate Spanish day7dlc_start2_12bb6bf0:

    # GR "good. yes, that's good news."
    GR "bien. sí, son buenas noticias."

# game/beyond the bet/day7dlc.rpy:383
translate Spanish day7dlc_start2_7867315a:

    # GR "very good..."
    GR "muy bien..."

# game/beyond the bet/day7dlc.rpy:386
translate Spanish day7dlc_start2_19b5c19e:

    # player "So, I guess this is it then, right?"
    player "Entonces, supongo que este es el momento, ¿no?"

# game/beyond the bet/day7dlc.rpy:389
translate Spanish day7dlc_start2_c1657347:

    # player "Day 7."
    player "Día 7."

# game/beyond the bet/day7dlc.rpy:392
translate Spanish day7dlc_start2_2f0611a7:

    # player "You coming to take my soul?"
    player "¿Vienes a llevarte mi alma?"

# game/beyond the bet/day7dlc.rpy:393
translate Spanish day7dlc_start2_7772a27d:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:396
translate Spanish day7dlc_start2_f9a578b3:

    # player "Or will I get yours instead :D ?"
    player "¿O me quedaré yo con la tuya :D ?"

# game/beyond the bet/day7dlc.rpy:397
translate Spanish day7dlc_start2_7772a27d_1:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:398
translate Spanish day7dlc_start2_b458fb84:

    # GR "there is a complication."
    GR "hay una complicación."

# game/beyond the bet/day7dlc.rpy:401
translate Spanish day7dlc_start2_faa0641e:

    # player "Huh?"
    player "¿Eh?"

# game/beyond the bet/day7dlc.rpy:404
translate Spanish day7dlc_start2_089ef023:

    # player "Are you trying to weasel out of our bet?"
    player "¿Estás intentando escaparte de nuestra apuesta?"

# game/beyond the bet/day7dlc.rpy:405
translate Spanish day7dlc_start2_f643e055:

    # GR "hardly."
    GR "para nada."

# game/beyond the bet/day7dlc.rpy:406
translate Spanish day7dlc_start2_69239407:

    # GR "i told you, i am honor bound to accept the outcome of our bet."
    GR "te lo dije, estoy obligado por honor a aceptar el resultado de nuestra apuesta."

# game/beyond the bet/day7dlc.rpy:407
translate Spanish day7dlc_start2_7747ad78:

    # GR "but i'm afraid that currently, i am dying, and i believe it is your fault."
    GR "pero me temo que en este momento me estoy muriendo, y creo que es tu culpa."

# game/beyond the bet/day7dlc.rpy:410
translate Spanish day7dlc_start2_f2f47468_1:

    # player "WHAT?"
    player "¡¿QUÉ?!"

# game/beyond the bet/day7dlc.rpy:413
translate Spanish day7dlc_start2_441af9a2:

    # player "Is it that soulsickness thing? Did you spend too much time here?"
    player "¿Es lo de la enfermedad del alma? ¿Pasaste demasiado tiempo aquí?"

# game/beyond the bet/day7dlc.rpy:416
translate Spanish day7dlc_start2_04f2d9eb:

    # player "Now I feel bad for asking you to stay..."
    player "Ahora me siento mal por haberte pedido que te quedaras..."

# game/beyond the bet/day7dlc.rpy:417
translate Spanish day7dlc_start2_c58ebc07:

    # GR "it is... something far, far worse."
    GR "es... algo mucho, mucho peor."

# game/beyond the bet/day7dlc.rpy:420
translate Spanish day7dlc_start2_e2fc9576:

    # player "What?????"
    player "¿¿¿Qué???"

# game/beyond the bet/day7dlc.rpy:421
translate Spanish day7dlc_start2_75160ba2:

    # GR "i have caught what you may refer to as the 'common cold'."
    GR "he contraído lo que podrías llamar el 'resfriado común'."

# game/beyond the bet/day7dlc.rpy:424
translate Spanish day7dlc_start2_eaba0a47:

    # player "Oh."
    player "Oh."

# game/beyond the bet/day7dlc.rpy:426
translate Spanish day7dlc_start2_03775ec8:

    # player "..."
    player "..."

# game/beyond the bet/day7dlc.rpy:429
translate Spanish day7dlc_start2_86277d6f:

    # player "Casper, you made me worry it was something serious!"
    player "¡Casper, me hiciste pensar que era algo grave!"

# game/beyond the bet/day7dlc.rpy:430
translate Spanish day7dlc_start2_ae1c369c:

    # GR "it IS serious!"
    GR "¡SÍ es grave!"

# game/beyond the bet/day7dlc.rpy:433
translate Spanish day7dlc_start2_94687aeb:

    # player "It's a cold!"
    player "¡Es un resfriado!"

# game/beyond the bet/day7dlc.rpy:434
translate Spanish day7dlc_start2_321055da:

    # GR "a reaper does not catch colds!"
    GR "¡una parca no se resfría!"

# game/beyond the bet/day7dlc.rpy:435
translate Spanish day7dlc_start2_dd936ab2:

    # GR "i told you. it is impossible for mortal viruses to take hold in my body."
    GR "te lo dije. es imposible que los virus de los mortales echen raíces en mi cuerpo."

# game/beyond the bet/day7dlc.rpy:436
translate Spanish day7dlc_start2_1cda6b21:

    # GR "it has never happened before in all of history."
    GR "nunca había pasado en toda la historia."

# game/beyond the bet/day7dlc.rpy:437
translate Spanish day7dlc_start2_6dbc8832:

    # GR "i have taken the souls of hundreds, thousands infected with illnesses."
    GR "he tomado las almas de cientos, de miles de personas infectadas de enfermedades."

# game/beyond the bet/day7dlc.rpy:438
translate Spanish day7dlc_start2_92d80380:

    # GR "they have never touched me."
    GR "jamás me han afectado."

# game/beyond the bet/day7dlc.rpy:439
translate Spanish day7dlc_start2_41d4fc37:

    # GR "it's impossible. it should be impossible."
    GR "es imposible. debería ser imposible."

# game/beyond the bet/day7dlc.rpy:440
translate Spanish day7dlc_start2_1c0a2aa6:

    # GR "but right now, i am sick."
    GR "pero ahora mismo, estoy enfermo."

# game/beyond the bet/day7dlc.rpy:441
translate Spanish day7dlc_start2_a7cac735:

    # GR "it is terrible."
    GR "es terrible."

# game/beyond the bet/day7dlc.rpy:444
translate Spanish day7dlc_start2_0169d44d:

    # player "How could you have caught it then???"
    player "¿¿¿Entonces cómo pudiste contagiarte???"

# game/beyond the bet/day7dlc.rpy:447
translate Spanish day7dlc_start2_738fc6c3:

    # player "From sleeping next to me?"
    player "¿Por dormir a mi lado?"

# game/beyond the bet/day7dlc.rpy:448
translate Spanish day7dlc_start2_de1903e8:

    # GR "i do not know."
    GR "no lo sé."

# game/beyond the bet/day7dlc.rpy:449
translate Spanish day7dlc_start2_b2374fd6:

    # GR "all i know is that i'm certain that i may perish by the end of the day."
    GR "lo único que sé es que estoy seguro de que podría perecer antes de que acabe el día."

# game/beyond the bet/day7dlc.rpy:452
translate Spanish day7dlc_start2_64a400d2:

    # player "That seems a little dramatic."
    player "Eso suena un poco dramático."

# game/beyond the bet/day7dlc.rpy:453
translate Spanish day7dlc_start2_c2efcdec:

    # GR "me? dramatic? never."
    GR "¿yo? ¿dramático? jamás."

# game/beyond the bet/day7dlc.rpy:454
translate Spanish day7dlc_start2_924b02ba:

    # GR "i am being completely serious."
    GR "hablo con total seriedad."

# game/beyond the bet/day7dlc.rpy:457
translate Spanish day7dlc_start2_36236ed2:

    # player "I know you are."
    player "Ya lo sé."

# game/beyond the bet/day7dlc.rpy:460
translate Spanish day7dlc_start2_11fc9c59:

    # player "Trust me, it'll pass."
    player "Confía en mí, se te pasará."

# game/beyond the bet/day7dlc.rpy:461
translate Spanish day7dlc_start2_5fc0b41c:

    # GR "and if it does not?"
    GR "¿y si no?"

# game/beyond the bet/day7dlc.rpy:464
translate Spanish day7dlc_start2_133e3c39:

    # player "Then I guess I win the bet ;)"
    player "Entonces supongo que gano la apuesta ;)"

# game/beyond the bet/day7dlc.rpy:466
translate Spanish day7dlc_start2_b22e9793:

    # GR "yes, well..."
    GR "sí, bueno..."

# game/beyond the bet/day7dlc.rpy:470
translate Spanish day7dlc_start2_630b304e:

    # player "Come here, I'll kiss it better."
    player "Ven acá, te lo curo con un beso."

# game/beyond the bet/day7dlc.rpy:471
translate Spanish day7dlc_start2_8b572d1b:

    # GR "wha... what...?"
    GR "¿qu... qué...?"

# game/beyond the bet/day7dlc.rpy:472
translate Spanish day7dlc_start2_9a9a7875:

    # GR "i do not believe something like... like {i}kissing{/i}... cures an illness!"
    GR "¡no creo que algo como... como {i}besar{/i}... cure una enfermedad!"

# game/beyond the bet/day7dlc.rpy:475
translate Spanish day7dlc_start2_fa4fc031:

    # player "Have you ever tried it?"
    player "¿Alguna vez lo has intentado?"

# game/beyond the bet/day7dlc.rpy:476
translate Spanish day7dlc_start2_6472c257:

    # GR "i... no, of course not..."
    GR "yo... no, claro que no..."

# game/beyond the bet/day7dlc.rpy:479
translate Spanish day7dlc_start2_7187edad:

    # player "Then it might work!"
    player "¡Entonces podría funcionar!"

# game/beyond the bet/day7dlc.rpy:482
translate Spanish day7dlc_start2_d3b073b1:

    # player "Come on over ;)"
    player "Ven acá ;)"

# game/beyond the bet/day7dlc.rpy:483
translate Spanish day7dlc_start2_7772a27d_2:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:484
translate Spanish day7dlc_start2_7772a27d_3:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:485
translate Spanish day7dlc_start2_117b6216:

    # GR "if this sickness isn't the death of me, you will be..."
    GR "si esta enfermedad no es mi final, tú lo serás..."

# game/beyond the bet/day7dlc.rpy:487
translate Spanish day7dlc_start2_1bbb973a:

    # GR "perhaps you will 'win' this bet of ours, mortal."
    GR "quizá 'ganes' esta apuesta nuestra, mortal."

# game/beyond the bet/day7dlc.rpy:489
translate Spanish day7dlc_start2_2d539279:

    # GR "we agreed the limit was a week. that is only a few more hours from now."
    GR "acordamos que el límite era una semana. de ahora a entonces solo faltan unas pocas horas."

# game/beyond the bet/day7dlc.rpy:492
translate Spanish day7dlc_start2_b34b8802:

    # player "That means..."
    player "Eso significa..."

# game/beyond the bet/day7dlc.rpy:496
translate Spanish day7dlc_start2_23c3e75b:

    # player "Your soul is all mine!"
    player "¡Tu alma es toda mía!"

# game/beyond the bet/day7dlc.rpy:497
translate Spanish day7dlc_start2_7772a27d_4:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:498
translate Spanish day7dlc_start2_feec4b51_1:

    # GR "correct."
    GR "correcto."

# game/beyond the bet/day7dlc.rpy:499
translate Spanish day7dlc_start2_487cd499:

    # GR "it is what we agreed to, and it is perfectly fair."
    GR "es lo que acordamos, y es perfectamente justo."

# game/beyond the bet/day7dlc.rpy:500
translate Spanish day7dlc_start2_bae94e7e:

    # GR "but let me tell you now..."
    GR "pero déjame decirte desde ahora..."

# game/beyond the bet/day7dlc.rpy:501
translate Spanish day7dlc_start2_5983070a:

    # GR "if this happens, it will not stop another reaper from being assigned to your case."
    GR "si esto sucede, no evitará que se asigne a otra parca a tu caso."

# game/beyond the bet/day7dlc.rpy:502
translate Spanish day7dlc_start2_34f475f9:

    # GR "i loathe the idea, more than anything."
    GR "detesto la idea, más que cualquier otra cosa."

# game/beyond the bet/day7dlc.rpy:503
translate Spanish day7dlc_start2_485d10e2:

    # GR "someone else viewing you as i have."
    GR "alguien más viéndote como yo lo he hecho."

# game/beyond the bet/day7dlc.rpy:504
translate Spanish day7dlc_start2_ed36b9ba:

    # GR "but i made the deal, and i will stick to it."
    GR "pero hice el trato, y lo cumpliré."

# game/beyond the bet/day7dlc.rpy:507
translate Spanish day7dlc_start2_33032fb8:

    # player "It's finally soul baby time!"
    player "¡Por fin es hora del bebé alma!"

# game/beyond the bet/day7dlc.rpy:508
translate Spanish day7dlc_start2_771282ed:

    # GR "WHAT?"
    GR "¡¿QUÉ?!"

# game/beyond the bet/day7dlc.rpy:509
translate Spanish day7dlc_start2_d3c7f820:

    # GR "on and on and on you obsess with this... this... soul baby, of all things!"
    GR "sigues y sigues obsesionándote con este... este... ¡bebé alma, de entre todas las cosas!"

# game/beyond the bet/day7dlc.rpy:510
translate Spanish day7dlc_start2_8da06a12:

    # GR "there is no soul baby!"
    GR "¡no hay ningún bebé alma!"

# game/beyond the bet/day7dlc.rpy:513
translate Spanish day7dlc_start2_acce17b0:

    # player "Not yet."
    player "Todavía no."

# game/beyond the bet/day7dlc.rpy:514
translate Spanish day7dlc_start2_836188db:

    # GR "it is not possible!"
    GR "¡no es posible!"

# game/beyond the bet/day7dlc.rpy:517
translate Spanish day7dlc_start2_8fa580a2:

    # player "I regularly do the impossible, Grim."
    player "Hago lo imposible con regularidad, Parca."

# game/beyond the bet/day7dlc.rpy:518
translate Spanish day7dlc_start2_5eb54651:

    # GR "there is no basis for this soul baby idea of yours."
    GR "tu idea del bebé alma no tiene ningún fundamento."

# game/beyond the bet/day7dlc.rpy:519
translate Spanish day7dlc_start2_ecc78a9e:

    # GR "if our souls mixed, there would be no baby."
    GR "si nuestras almas se mezclaran, no habría ningún bebé."

# game/beyond the bet/day7dlc.rpy:522
translate Spanish day7dlc_start2_6a54b10b:

    # player "I don't think you're certain about that."
    player "No creo que estés tan seguro de eso."

# game/beyond the bet/day7dlc.rpy:523
translate Spanish day7dlc_start2_7772a27d_5:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:524
translate Spanish day7dlc_start2_90548d5d:

    # GR "i worry about you."
    GR "me preocupo por ti."

# game/beyond the bet/day7dlc.rpy:525
translate Spanish day7dlc_start2_85da4a1a:

    # GR "and once i am gone, i fear i'll worry for you even more."
    GR "y una vez que me haya ido, temo preocuparme aún más."

# game/beyond the bet/day7dlc.rpy:529
translate Spanish day7dlc_start2_d89db7f9:

    # player "What do you mean...?"
    player "¿A qué te refieres...?"

# game/beyond the bet/day7dlc.rpy:532
translate Spanish day7dlc_start2_55f239f7:

    # player "Won't you stick around if I win...? :("
    player "¿No te quedarás si gano...? :("

# game/beyond the bet/day7dlc.rpy:533
translate Spanish day7dlc_start2_7677fc3a:

    # GR "mortal, do you not understand our arrangement?"
    GR "mortal, ¿no entiendes nuestro acuerdo?"

# game/beyond the bet/day7dlc.rpy:534
translate Spanish day7dlc_start2_372434cb:

    # GR "one of us must die at the end of it."
    GR "uno de nosotros debe morir al final."

# game/beyond the bet/day7dlc.rpy:537
translate Spanish day7dlc_start2_56a224ce:

    # player "HUH?"
    player "¿EH?"

# game/beyond the bet/day7dlc.rpy:539
translate Spanish day7dlc_start2_3d8591a1:

    # player "Wait a second!"
    player "¡Espera un segundo!"

# game/beyond the bet/day7dlc.rpy:542
translate Spanish day7dlc_start2_72295d61:

    # player "That's not what I want!"
    player "¡Eso no es lo que quiero!"

# game/beyond the bet/day7dlc.rpy:545
translate Spanish day7dlc_start2_bf675b6c:

    # player "When I said I wanted your soul, I was mostly joking."
    player "Cuando dije que quería tu alma, casi todo era broma."

# game/beyond the bet/day7dlc.rpy:548
translate Spanish day7dlc_start2_b6257152:

    # player "I don't want you to DIE for me."
    player "No quiero que MUERAS por mí."

# game/beyond the bet/day7dlc.rpy:549
translate Spanish day7dlc_start2_2d81483f:

    # GR "you asked for my soul. there is little way to give a soul but dying."
    GR "pediste mi alma. hay pocas formas de entregar un alma que no sea muriendo."

# game/beyond the bet/day7dlc.rpy:550
translate Spanish day7dlc_start2_9314525a:

    # GR "that was our agreement."
    GR "ese era nuestro acuerdo."

# game/beyond the bet/day7dlc.rpy:553
translate Spanish day7dlc_start2_39b6e890:

    # player "Well."
    player "Bueno."

# game/beyond the bet/day7dlc.rpy:556
translate Spanish day7dlc_start2_5ac41dda:

    # player "I've decided I don't like our agreement anymore."
    player "He decidido que ya no me gusta nuestro acuerdo."

# game/beyond the bet/day7dlc.rpy:557
translate Spanish day7dlc_start2_18d54299:

    # GR "that matters little."
    GR "eso importa poco."

# game/beyond the bet/day7dlc.rpy:560
translate Spanish day7dlc_start2_4ffc1c96:

    # player "It matters a lot!"
    player "¡Importa mucho!"

# game/beyond the bet/day7dlc.rpy:561
translate Spanish day7dlc_start2_cce5218c:

    # GR "we agreed to it."
    GR "lo acordamos."

# game/beyond the bet/day7dlc.rpy:564
translate Spanish day7dlc_start2_ed7428eb:

    # player "Come on, I'm giving us both an out!"
    player "¡Vamos, estoy buscando una salida para los dos!"

# game/beyond the bet/day7dlc.rpy:567
translate Spanish day7dlc_start2_c2d80ab8:

    # player "I don't want you to die, and I also don't want to die."
    player "No quiero que mueras, y tampoco quiero morir yo."

# game/beyond the bet/day7dlc.rpy:570
translate Spanish day7dlc_start2_3077c074:

    # player "Let's call it off."
    player "Cancelémoslo."

# game/beyond the bet/day7dlc.rpy:571
translate Spanish day7dlc_start2_7772a27d_6:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:572
translate Spanish day7dlc_start2_4dac5a78:

    # GR "it just..."
    GR "es solo que..."

# game/beyond the bet/day7dlc.rpy:573
translate Spanish day7dlc_start2_dfb0ead2:

    # GR "wouldn't matter."
    GR "no importaría."

# game/beyond the bet/day7dlc.rpy:574
translate Spanish day7dlc_start2_1d7414ed:

    # GR "if i don't take your soul, i am as good as dead anyway."
    GR "si no tomo tu alma, es como si estuviera muerto igual."

# game/beyond the bet/day7dlc.rpy:575
translate Spanish day7dlc_start2_d9188914:

    # GR "there is no happy ending for either of us in this."
    GR "no hay un final feliz para ninguno de los dos."

# game/beyond the bet/day7dlc.rpy:578
translate Spanish day7dlc_start2_3da7c9bd:

    # player ":("
    player ":("

# game/beyond the bet/day7dlc.rpy:581
translate Spanish day7dlc_start2_c1471ae7:

    # player "I don't like this."
    player "No me gusta esto."

# game/beyond the bet/day7dlc.rpy:583
translate Spanish day7dlc_start2_372abc74:

    # player "But there could be! You don't know for certain."
    player "¡Pero podría haberlo! No lo sabes con certeza."

# game/beyond the bet/day7dlc.rpy:584
translate Spanish day7dlc_start2_b4ae69a5:

    # GR "...sorry, sunshine."
    GR "...lo siento, solecito."

# game/beyond the bet/day7dlc.rpy:585
translate Spanish day7dlc_start2_526666fc:

    # GR "i'll probably be dead from this gods-forsaken cold before the day is out, anyway."
    GR "igual, probablemente estaré muerto por este maldito resfriado antes de que acabe el día."

# game/beyond the bet/day7dlc.rpy:586
translate Spanish day7dlc_start2_81ce3567:

    # GR "before i die, there are some things i wanted to talk to you about, though."
    GR "aun así, antes de morir, hay algunas cosas de las que quería hablarte."

# game/beyond the bet/day7dlc.rpy:589
translate Spanish day7dlc_start2_f771ba83:

    # player "Stop saying you're gonna die."
    player "Deja de decir que te vas a morir."

# game/beyond the bet/day7dlc.rpy:592
translate Spanish day7dlc_start2_b9d1fc34:

    # player "I seriously won't let that happen."
    player "En serio, no voy a dejar que eso pase."

# game/beyond the bet/day7dlc.rpy:593
translate Spanish day7dlc_start2_e5f48e84:

    # GR "if you're good at anything, it IS not dying. that is actually what i wanted to talk about."
    GR "si hay algo en lo que destacas, ES en no morir. de eso justamente quería hablar."

# game/beyond the bet/day7dlc.rpy:594
translate Spanish day7dlc_start2_da47cc6d:

    # GR "i have always known there is something strange about you, mortal."
    GR "siempre he sabido que hay algo extraño en ti, mortal."

# game/beyond the bet/day7dlc.rpy:595
translate Spanish day7dlc_start2_30fc8e5c:

    # GR "i have... watched you for some time."
    GR "te he... observado durante algún tiempo."

# game/beyond the bet/day7dlc.rpy:598
translate Spanish day7dlc_start2_5e972554:

    # player "How long is that?"
    player "¿Cuánto tiempo es eso?"

# game/beyond the bet/day7dlc.rpy:600
translate Spanish day7dlc_start2_77b0d5b7:

    # player "You did say you picked my nickname a long time ago..."
    player "Sí dijiste que escogiste mi apodo hace mucho tiempo..."

# game/beyond the bet/day7dlc.rpy:601
translate Spanish day7dlc_start2_7772a27d_7:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:602
translate Spanish day7dlc_start2_41f0c86f:

    # GR "it's been a few years now."
    GR "ya hace unos años."

# game/beyond the bet/day7dlc.rpy:603
translate Spanish day7dlc_start2_a88a9f43:

    # GR "i was only ever supposed to take your soul..."
    GR "se suponía que solo debía tomar tu alma..."

# game/beyond the bet/day7dlc.rpy:604
translate Spanish day7dlc_start2_3f59c8b5:

    # GR "but i suppose even your radiance affects someone so shrouded in shadow, like me."
    GR "pero supongo que incluso tu resplandor afecta a alguien tan envuelto en sombras como yo."

# game/beyond the bet/day7dlc.rpy:605
translate Spanish day7dlc_start2_d787b2f6:

    # GR "it is... somewhat amazing, the way you capture people so."
    GR "es... algo asombroso, la forma en que cautivas así a la gente."

# game/beyond the bet/day7dlc.rpy:606
translate Spanish day7dlc_start2_60a76aa7:

    # GR "i had never thought i would meet someone who could do it to me."
    GR "nunca pensé que conocería a alguien capaz de cautivarme a mí."

# game/beyond the bet/day7dlc.rpy:607
translate Spanish day7dlc_start2_b8a86f17:

    # GR "ahem..."
    GR "ejem..."

# game/beyond the bet/day7dlc.rpy:608
translate Spanish day7dlc_start2_cafb73ae:

    # GR "i have done some research. i believe your soul is very unique, [playerfirstname!l]."
    GR "he investigado un poco. creo que tu alma es muy singular, [playerfirstname!l]."

# game/beyond the bet/day7dlc.rpy:609
translate Spanish day7dlc_start2_797bd3a9:

    # GR "have you ever had a sick friend, or a family member, or a colleague?"
    GR "¿alguna vez has tenido un amigo enfermo, o un familiar, o un compañero de trabajo?"

# game/beyond the bet/day7dlc.rpy:610
translate Spanish day7dlc_start2_4fb755b4:

    # GR "who then expressed that they feel better when they're around you?"
    GR "¿que luego te dijo que se sentía mejor cuando estaba cerca de ti?"

# game/beyond the bet/day7dlc.rpy:613
translate Spanish day7dlc_start2_55a0df4c:

    # player "Hmm..."
    player "Hmm..."

# game/beyond the bet/day7dlc.rpy:616
translate Spanish day7dlc_start2_64902a73:

    # player "Oh, there was one time, in school..."
    player "Oh, una vez, en la escuela..."

# game/beyond the bet/day7dlc.rpy:619
translate Spanish day7dlc_start2_d5351df3:

    # player "A friend of mine fell over and scuffed her knee, so I took her to the school nurse."
    player "Una amiga mía se cayó y se raspó la rodilla, así que la llevé a la enfermería de la escuela."

# game/beyond the bet/day7dlc.rpy:622
translate Spanish day7dlc_start2_6ef45bc3:

    # player "I swear there was so much blood, but by the time we got there it was a scratch."
    player "Juro que había muchísima sangre, pero cuando llegamos era solo un rasguño."

# game/beyond the bet/day7dlc.rpy:625
translate Spanish day7dlc_start2_64368662:

    # player "My friend said it must just have been my healing aura :D"
    player "Mi amiga dijo que seguro era mi aura sanadora :D"

# game/beyond the bet/day7dlc.rpy:628
translate Spanish day7dlc_start2_fab5a623:

    # player "I had a cousin like that!"
    player "¡Tenía un primo así!"

# game/beyond the bet/day7dlc.rpy:631
translate Spanish day7dlc_start2_b547212e:

    # player "I went over to hang out with him but when I got there, he had a fever."
    player "Fui a pasar el rato con él, pero cuando llegué tenía fiebre."

# game/beyond the bet/day7dlc.rpy:634
translate Spanish day7dlc_start2_3911c643:

    # player "So I went to say hi before I left, and then we just kept chatting, and he felt totally better by the end of it."
    player "Así que fui a saludarlo antes de irme, y terminamos charlando, y para el final ya se sentía totalmente mejor."

# game/beyond the bet/day7dlc.rpy:637
translate Spanish day7dlc_start2_6cd53022:

    # player "We got to hang out after all!"
    player "¡Al final sí pudimos pasar el rato!"

# game/beyond the bet/day7dlc.rpy:640
translate Spanish day7dlc_start2_24541921:

    # player "There was a stranger on the subway..."
    player "Había una desconocida en el metro..."

# game/beyond the bet/day7dlc.rpy:643
translate Spanish day7dlc_start2_6813d33c:

    # player "I didn't even get her name."
    player "Ni siquiera supe su nombre."

# game/beyond the bet/day7dlc.rpy:646
translate Spanish day7dlc_start2_d150adc5:

    # player "She was sitting across from me, and she didn't look very well."
    player "Estaba sentada frente a mí y no se veía muy bien."

# game/beyond the bet/day7dlc.rpy:649
translate Spanish day7dlc_start2_74ccc472:

    # player "Actually, she kept looking at me and it was giving me the creeps a little."
    player "En realidad, no dejaba de mirarme y me daba un poco de mala espina."

# game/beyond the bet/day7dlc.rpy:652
translate Spanish day7dlc_start2_7e8f15e4:

    # player "But when she got off, she thanked me and said that just sitting near me made her feel better."
    player "Pero cuando se bajó, me dio las gracias y dijo que con solo sentarse cerca de mí se sintió mejor."

# game/beyond the bet/day7dlc.rpy:655
translate Spanish day7dlc_start2_b8da05ea:

    # player "Still kinda weird but I guess it's... also kinda nice?"
    player "Sigue siendo medio raro, pero supongo que es... ¿también medio lindo?"

# game/beyond the bet/day7dlc.rpy:657
translate Spanish day7dlc_start2_011d48e3:

    # GR "perfect."
    GR "perfecto."

# game/beyond the bet/day7dlc.rpy:658
translate Spanish day7dlc_start2_a98c473b:

    # GR "i knew i was correct."
    GR "sabía que tenía razón."

# game/beyond the bet/day7dlc.rpy:661
translate Spanish day7dlc_start2_e8631bfa:

    # player "Correct about what?"
    player "¿Tenías razón en qué?"

# game/beyond the bet/day7dlc.rpy:662
translate Spanish day7dlc_start2_4b79a7d1:

    # GR "my soul is... well, i must balance it, but it is inherently darkness. it is death."
    GR "mi alma es... bueno, debo equilibrarla, pero es inherentemente oscuridad. es muerte."

# game/beyond the bet/day7dlc.rpy:663
translate Spanish day7dlc_start2_63a017ff:

    # GR "that is something every reaper must deal with."
    GR "es algo con lo que toda parca debe lidiar."

# game/beyond the bet/day7dlc.rpy:664
translate Spanish day7dlc_start2_40c99ce7:

    # GR "but i read of something even more rare than a reaper's soul."
    GR "pero leí sobre algo aún más raro que el alma de una parca."

# game/beyond the bet/day7dlc.rpy:665
translate Spanish day7dlc_start2_fd17a2fd:

    # GR "a soul that is lightness and life."
    GR "un alma que es luz y vida."

# game/beyond the bet/day7dlc.rpy:666
translate Spanish day7dlc_start2_e4bcf19a:

    # GR "one that directly opposes that which i possess."
    GR "una que se opone directamente a la que yo poseo."

# game/beyond the bet/day7dlc.rpy:667
translate Spanish day7dlc_start2_2ef910f0:

    # GR "i think that is what you have."
    GR "creo que eso es lo que tú tienes."

# game/beyond the bet/day7dlc.rpy:670
translate Spanish day7dlc_start2_8c2ca8d8:

    # player "I... what?"
    player "Yo... ¿qué?"

# game/beyond the bet/day7dlc.rpy:673
translate Spanish day7dlc_start2_c498db7d:

    # player "I don't think I have anything amazing like that..."
    player "No creo tener nada así de increíble..."

# game/beyond the bet/day7dlc.rpy:674
translate Spanish day7dlc_start2_fe4eb8a8:

    # GR "it is nearly impossible, i agree."
    GR "es casi imposible, estoy de acuerdo."

# game/beyond the bet/day7dlc.rpy:675
translate Spanish day7dlc_start2_e08373b3:

    # GR "but you have proven time and time again that the impossible is possible to you."
    GR "pero has demostrado una y otra vez que para ti lo imposible es posible."

# game/beyond the bet/day7dlc.rpy:676
translate Spanish day7dlc_start2_d33ba168:

    # GR "you should not be alive."
    GR "no deberías estar viv[letra]."

# game/beyond the bet/day7dlc.rpy:677
translate Spanish day7dlc_start2_67db0d40:

    # GR "i... do not like to admit that, for some reason, but you should have died a long time ago."
    GR "yo... no me gusta admitirlo, por alguna razón, pero deberías haber muerto hace mucho tiempo."

# game/beyond the bet/day7dlc.rpy:678
translate Spanish day7dlc_start2_78ad6cb8:

    # GR "but here you are."
    GR "pero aquí estás."

# game/beyond the bet/day7dlc.rpy:679
translate Spanish day7dlc_start2_c9550454:

    # GR "no matter what i throw at you, you live."
    GR "no importa lo que te lance, vives."

# game/beyond the bet/day7dlc.rpy:680
translate Spanish day7dlc_start2_45ed46be:

    # GR "life clings to you."
    GR "la vida se aferra a ti."

# game/beyond the bet/day7dlc.rpy:683
translate Spanish day7dlc_start2_36c54dd4:

    # player "So... what does that all mean?"
    player "Entonces... ¿qué significa todo eso?"

# game/beyond the bet/day7dlc.rpy:686
translate Spanish day7dlc_start2_d4bd8b91:

    # player "I HAVE SUPERPOWERS?"
    player "¿¿TENGO SUPERPODERES??"

# game/beyond the bet/day7dlc.rpy:687
translate Spanish day7dlc_start2_b3c893fe:

    # GR "{i}that{/i} is what you're getting from our conversation?"
    GR "¿{i}eso{/i} es lo que sacas de nuestra conversación?"

# game/beyond the bet/day7dlc.rpy:690
translate Spanish day7dlc_start2_09c85ddb:

    # player "You have superpowers! That must mean I do, too!"
    player "¡Tienes superpoderes! ¡Eso debe significar que yo también!"

# game/beyond the bet/day7dlc.rpy:691
translate Spanish day7dlc_start2_4ef93358:

    # GR "you are still human."
    GR "sigues siendo human[letra]."

# game/beyond the bet/day7dlc.rpy:692
translate Spanish day7dlc_start2_8072a2fd:

    # GR "and mortal... i think?"
    GR "y mortal... ¿creo?"

# game/beyond the bet/day7dlc.rpy:693
translate Spanish day7dlc_start2_9f60d096:

    # GR "whatever abilities your soul lends you will be much more... mute, i suppose, than mine."
    GR "las habilidades que tu alma te otorgue serán mucho más... tenues, supongo, que las mías."

# game/beyond the bet/day7dlc.rpy:696
translate Spanish day7dlc_start2_000965c7:

    # player "Can I fly?"
    player "¿Puedo volar?"

# game/beyond the bet/day7dlc.rpy:697
translate Spanish day7dlc_start2_5d364529:

    # GR "no."
    GR "no."

# game/beyond the bet/day7dlc.rpy:700
translate Spanish day7dlc_start2_9d4b5c24:

    # player "Can I go invisible?"
    player "¿Puedo volverme invisible?"

# game/beyond the bet/day7dlc.rpy:701
translate Spanish day7dlc_start2_b5244b4f:

    # GR "i doubt it."
    GR "lo dudo."

# game/beyond the bet/day7dlc.rpy:704
translate Spanish day7dlc_start2_e528d019:

    # player "Can I run suuuuuper fast?"
    player "¿Puedo correr súúúper rápido?"

# game/beyond the bet/day7dlc.rpy:705
translate Spanish day7dlc_start2_06d8c715:

    # GR "you tell me."
    GR "dímelo tú."

# game/beyond the bet/day7dlc.rpy:708
translate Spanish day7dlc_start2_9c861a0a:

    # player "Okay."
    player "Okey."

# game/beyond the bet/day7dlc.rpy:711
translate Spanish day7dlc_start2_f224096b:

    # player "I just ran around my room."
    player "Acabo de correr por mi cuarto."

# game/beyond the bet/day7dlc.rpy:714
translate Spanish day7dlc_start2_052d0cc8:

    # player "It was at a normal to less than normal speed."
    player "Fue a una velocidad normal o menos que normal."

# game/beyond the bet/day7dlc.rpy:715
translate Spanish day7dlc_start2_8c5af772:

    # GR "perhaps your superpower is running at a normal speed."
    GR "quizá tu superpoder es correr a velocidad normal."

# game/beyond the bet/day7dlc.rpy:718
translate Spanish day7dlc_start2_e327fe01:

    # player "That's a lame superpower!"
    player "¡Qué superpoder tan malo!"

# game/beyond the bet/day7dlc.rpy:719
translate Spanish day7dlc_start2_afebafb1:

    # GR "then perhaps your superpower is the power of annoyance."
    GR "entonces quizá tu superpoder es el poder de fastidiar."

# game/beyond the bet/day7dlc.rpy:720
translate Spanish day7dlc_start2_9aad80a8:

    # GR "you are pretty good at that."
    GR "se te da bastante bien."

# game/beyond the bet/day7dlc.rpy:723
translate Spanish day7dlc_start2_a292b860:

    # player "I think that power only works on you, Grim."
    player "Creo que ese poder solo funciona contigo, Parca."

# game/beyond the bet/day7dlc.rpy:724
translate Spanish day7dlc_start2_a895adbc:

    # GR "it certainly does."
    GR "así es, funciona."

# game/beyond the bet/day7dlc.rpy:725
translate Spanish day7dlc_start2_d9a8c3c8:

    # GR "but i do believe there is something you can do."
    GR "pero sí creo que hay algo que puedes hacer."

# game/beyond the bet/day7dlc.rpy:727
translate Spanish day7dlc_start2_623a1e51:

    # GR "i think you have the ability to give away parts of your soul."
    GR "creo que tienes la capacidad de regalar partes de tu alma."

# game/beyond the bet/day7dlc.rpy:728
translate Spanish day7dlc_start2_cb0f0136:

    # GR "yours is the power of healing, but at the cost of yourself."
    GR "lo tuyo es el poder de sanar, pero a costa de ti mism[letra]."

# game/beyond the bet/day7dlc.rpy:729
translate Spanish day7dlc_start2_fab1f29a:

    # GR "it is a dangerous ability."
    GR "es una habilidad peligrosa."

# game/beyond the bet/day7dlc.rpy:730
translate Spanish day7dlc_start2_fbf6f664:

    # GR "also, maybe you can't die. i'm unsure about that one."
    GR "además, quizá no puedas morir. de eso no estoy seguro."

# game/beyond the bet/day7dlc.rpy:733
translate Spanish day7dlc_start2_cad4e2fa:

    # player "This is insane."
    player "Esto es una locura."

# game/beyond the bet/day7dlc.rpy:734
translate Spanish day7dlc_start2_cb853af8:

    # GR "it is perfectly sane."
    GR "es perfectamente cuerdo."

# game/beyond the bet/day7dlc.rpy:735
translate Spanish day7dlc_start2_01a81c85:

    # GR "and finally, a reasonable explanation as to why i am struggling with you so much."
    GR "y por fin, una explicación razonable de por qué me está costando tanto contigo."

# game/beyond the bet/day7dlc.rpy:738
translate Spanish day7dlc_start2_74e1f4ef:

    # player "I dunno if that's the only reason."
    player "No sé si esa sea la única razón."

# game/beyond the bet/day7dlc.rpy:741
translate Spanish day7dlc_start2_9e32538c:

    # player "I think you just like me too much to kill me."
    player "Creo que simplemente te gusto demasiado como para matarme."

# game/beyond the bet/day7dlc.rpy:742
translate Spanish day7dlc_start2_7772a27d_8:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:743
translate Spanish day7dlc_start2_eea84d31:

    # GR "shut up..."
    GR "cállate..."

# game/beyond the bet/day7dlc.rpy:747
translate Spanish day7dlc_start2_4f12dbf7:

    # player "Like, really?"
    player "¿Pero en serio?"

# game/beyond the bet/day7dlc.rpy:748
translate Spanish day7dlc_start2_6524a48c:

    # GR "really."
    GR "en serio."

# game/beyond the bet/day7dlc.rpy:751
translate Spanish day7dlc_start2_2eb99e27:

    # player "Really really?"
    player "¿En serio en serio?"

# game/beyond the bet/day7dlc.rpy:752
translate Spanish day7dlc_start2_d9d34903:

    # GR "did i not already say as much? yes, really."
    GR "¿acaso no lo dije ya? sí, en serio."

# game/beyond the bet/day7dlc.rpy:756
translate Spanish day7dlc_start2_23ebfdfe:

    # player "Are you sure, though?"
    player "¿Pero seguro?"

# game/beyond the bet/day7dlc.rpy:759
translate Spanish day7dlc_start2_68316eee:

    # player "Like..."
    player "Como..."

# game/beyond the bet/day7dlc.rpy:762
translate Spanish day7dlc_start2_97fad506:

    # player "I know I'm hard to kill, but maybe this whole healing thing's just luck."
    player "Sé que soy difícil de matar, pero quizá esto de la sanación es pura suerte."

# game/beyond the bet/day7dlc.rpy:763
translate Spanish day7dlc_start2_9d17e08b:

    # GR "there was a second reason i brought you those flowers."
    GR "hubo una segunda razón por la que te traje esas flores."

# game/beyond the bet/day7dlc.rpy:764
translate Spanish day7dlc_start2_1bcde15a:

    # GR "my soul had become unbalanced, and i had a small bout of soulsickness."
    GR "mi alma se había desequilibrado, y tuve un leve episodio de enfermedad del alma."

# game/beyond the bet/day7dlc.rpy:765
translate Spanish day7dlc_start2_97a32171:

    # GR "and being near you took it away."
    GR "y estar cerca de ti me la quitó."

# game/beyond the bet/day7dlc.rpy:766
translate Spanish day7dlc_start2_a83a3ab5:

    # GR "just like that."
    GR "así, sin más."

# game/beyond the bet/day7dlc.rpy:769
translate Spanish day7dlc_start2_eaba0a47_1:

    # player "Oh."
    player "Oh."

# game/beyond the bet/day7dlc.rpy:772
translate Spanish day7dlc_start2_7a510fe0:

    # player "Here I thought you just liked me a lot :("
    player "Yo que pensaba que solo te gustaba mucho :("

# game/beyond the bet/day7dlc.rpy:773
translate Spanish day7dlc_start2_c30211c0:

    # GR "i..."
    GR "a mí..."

# game/beyond the bet/day7dlc.rpy:774
translate Spanish day7dlc_start2_ba553548:

    # GR "i do."
    GR "me gustas."

# game/beyond the bet/day7dlc.rpy:775
translate Spanish day7dlc_start2_0c5f7835:

    # GR "i wanted to test my theory, but i brought them to you because i thought you deserved them."
    GR "quería probar mi teoría, pero te las llevé porque pensé que las merecías."

# game/beyond the bet/day7dlc.rpy:776
translate Spanish day7dlc_start2_eeaf37f2:

    # GR "i mean, you deserve much more, but it is all i could give for the moment."
    GR "es decir, mereces mucho más, pero es todo lo que pude dar por el momento."

# game/beyond the bet/day7dlc.rpy:777
translate Spanish day7dlc_start2_9493a819:

    # GR "ugh, my brain is working incorrectly today. i cannot think straight."
    GR "ugh, mi cerebro funciona mal hoy. no puedo pensar con claridad."

# game/beyond the bet/day7dlc.rpy:778
translate Spanish day7dlc_start2_e13c4631:

    # GR "i don't know how you mortals handle all of these illnesses."
    GR "no sé cómo soportan ustedes los mortales todas estas enfermedades."

# game/beyond the bet/day7dlc.rpy:779
translate Spanish day7dlc_start2_0782708c:

    # GR "they are beyond inconvenient."
    GR "son más que inconvenientes."

# game/beyond the bet/day7dlc.rpy:780
translate Spanish day7dlc_start2_aace08d7:

    # GR "i cannot even go anywhere to buy medicine."
    GR "ni siquiera puedo ir a ningún lado a comprar medicina."

# game/beyond the bet/day7dlc.rpy:781
translate Spanish day7dlc_start2_1393874d:

    # GR "that medicine does not exist here."
    GR "esa medicina no existe aquí."

# game/beyond the bet/day7dlc.rpy:784
translate Spanish day7dlc_start2_0ff8092b:

    # player "I could always give you some."
    player "Yo te puedo dar un poco."

# game/beyond the bet/day7dlc.rpy:787
translate Spanish day7dlc_start2_04d23131:

    # player "I'll nurse you back to health."
    player "Te cuidaré hasta que te recuperes."

# game/beyond the bet/day7dlc.rpy:788
translate Spanish day7dlc_start2_daf32dde:

    # GR "that... doesn't sound so bad."
    GR "eso... no suena tan mal."

# game/beyond the bet/day7dlc.rpy:789
translate Spanish day7dlc_start2_b7de2a86:

    # GR "but i don't even know if your mortal medicines would make a difference to my body."
    GR "pero ni siquiera sé si sus medicinas mortales harían alguna diferencia en mi cuerpo."

# game/beyond the bet/day7dlc.rpy:792
translate Spanish day7dlc_start2_eb625d77:

    # player "Are we that different, deep down?"
    player "¿Somos tan distintos en el fondo?"

# game/beyond the bet/day7dlc.rpy:794
translate Spanish day7dlc_start2_9edd440b:

    # player "We have all the same parts, don't we?"
    player "Tenemos las mismas partes, ¿no?"

# game/beyond the bet/day7dlc.rpy:795
translate Spanish day7dlc_start2_05da7bac:

    # GR "i cannot say i spend much time fiddling around inside people to know."
    GR "no puedo decir que pase mucho tiempo hurgando dentro de la gente como para saberlo."

# game/beyond the bet/day7dlc.rpy:798
translate Spanish day7dlc_start2_8fadf7aa:

    # player "Oh? That's certainly one way of putting it..."
    player "¿Ah, sí? Esa es una forma de decirlo, sí..."

# game/beyond the bet/day7dlc.rpy:801
translate Spanish day7dlc_start2_c227e14d:

    # player "Seriously, you should work on your phrasing."
    player "En serio, deberías trabajar tu forma de expresarte."

# game/beyond the bet/day7dlc.rpy:802
translate Spanish day7dlc_start2_6f2155f3:

    # GR "how so?"
    GR "¿cómo así?"

# game/beyond the bet/day7dlc.rpy:803
translate Spanish day7dlc_start2_c43a4913:

    # GR "it is the truth."
    GR "es la verdad."

# game/beyond the bet/day7dlc.rpy:804
translate Spanish day7dlc_start2_41af5e2a:

    # GR "i have spent very little time inside..."
    GR "he pasado muy poco tiempo dentro de..."

# game/beyond the bet/day7dlc.rpy:805
translate Spanish day7dlc_start2_a6de612c_2:

    # GR "ah."
    GR "ah."

# game/beyond the bet/day7dlc.rpy:806
translate Spanish day7dlc_start2_5abd8d22:

    # GR "i see where your mind has gone, once again."
    GR "veo adónde se ha ido tu mente, una vez más."

# game/beyond the bet/day7dlc.rpy:807
translate Spanish day7dlc_start2_4c731d00:

    # GR "forget my phrasing, you ought to work on that imagination of yours."
    GR "olvida mi forma de expresarme, tú deberías trabajar esa imaginación tuya."

# game/beyond the bet/day7dlc.rpy:810
translate Spanish day7dlc_start2_6b5ee8d5:

    # player "We both know you like it."
    player "Ambos sabemos que te gusta."

# game/beyond the bet/day7dlc.rpy:811
translate Spanish day7dlc_start2_00d403c1:

    # GR "that is not true."
    GR "eso no es cierto."

# game/beyond the bet/day7dlc.rpy:812
translate Spanish day7dlc_start2_58adb964:

    # GR "you do not know that."
    GR "tú no lo sabes."

# game/beyond the bet/day7dlc.rpy:815
translate Spanish day7dlc_start2_3f846d4e:

    # player "I really do."
    player "Claro que lo sé."

# game/beyond the bet/day7dlc.rpy:818
translate Spanish day7dlc_start2_a824bec9:

    # player "Wait, what if normal medicine made you, like, mortal?"
    player "Espera, ¿y si la medicina normal te volviera, no sé, mortal?"

# game/beyond the bet/day7dlc.rpy:819
translate Spanish day7dlc_start2_d2817595_1:

    # GR "what."
    GR "¿qué?"

# game/beyond the bet/day7dlc.rpy:820
translate Spanish day7dlc_start2_ff943c98:

    # GR "what is the basis for that hypothesis?"
    GR "¿cuál es el fundamento de esa hipótesis?"

# game/beyond the bet/day7dlc.rpy:823
translate Spanish day7dlc_start2_a3cfb66d:

    # player "It came to me in a dream."
    player "Se me ocurrió en un sueño."

# game/beyond the bet/day7dlc.rpy:826
translate Spanish day7dlc_start2_19e1e59e:

    # player "A vision, pretty much."
    player "Una visión, básicamente."

# game/beyond the bet/day7dlc.rpy:827
translate Spanish day7dlc_start2_67a43305:

    # GR "that is not basis for any kind of decent research."
    GR "eso no es base para ninguna investigación decente."

# game/beyond the bet/day7dlc.rpy:828
translate Spanish day7dlc_start2_66f579bf:

    # GR "human medicine will not turn me human."
    GR "la medicina humana no me hará humano."

# game/beyond the bet/day7dlc.rpy:829
translate Spanish day7dlc_start2_65d38603:

    # GR "maybe it'll melt my organs, or make me ill..."
    GR "quizá me derrita los órganos, o me enferme..."

# game/beyond the bet/day7dlc.rpy:830
translate Spanish day7dlc_start2_3a99f912:

    # GR "but more likely, it would do nothing."
    GR "pero lo más probable es que no haga nada."

# game/beyond the bet/day7dlc.rpy:833
translate Spanish day7dlc_start2_37936e01:

    # player "I have a really good source."
    player "Tengo una fuente muy buena."

# game/beyond the bet/day7dlc.rpy:834
translate Spanish day7dlc_start2_5e498abb:

    # GR "which is?"
    GR "¿cuál?"

# game/beyond the bet/day7dlc.rpy:837
translate Spanish day7dlc_start2_c75d12b0:

    # player "This brain of mine. "
    player "Este cerebro mío."

# game/beyond the bet/day7dlc.rpy:840
translate Spanish day7dlc_start2_08d47919:

    # player "Wonderful thing."
    player "Maravilloso."

# game/beyond the bet/day7dlc.rpy:843
translate Spanish day7dlc_start2_6b7c9c9e:

    # player "Huge."
    player "Enorme."

# game/beyond the bet/day7dlc.rpy:846
translate Spanish day7dlc_start2_d2147213:

    # player "Wrinkly."
    player "Arrugado."

# game/beyond the bet/day7dlc.rpy:849
translate Spanish day7dlc_start2_b70a7f3e:

    # player "Pulsing."
    player "Palpitante."

# game/beyond the bet/day7dlc.rpy:850
translate Spanish day7dlc_start2_cc619133:

    # GR "shush."
    GR "shh."

# game/beyond the bet/day7dlc.rpy:851
translate Spanish day7dlc_start2_2e4552f3:

    # GR "every single word that comes from your 'huge, wrinkling, pulsing' brain is nonsense."
    GR "cada palabra que sale de tu 'enorme, arrugado y palpitante' cerebro es una tontería."

# game/beyond the bet/day7dlc.rpy:852
translate Spanish day7dlc_start2_322a24b6:

    # GR "how you actually live with that thing inside of your head, i do not know."
    GR "cómo vives con esa cosa dentro de la cabeza, no lo sé."

# game/beyond the bet/day7dlc.rpy:855
translate Spanish day7dlc_start2_45c60140:

    # player "But what if it DID work, huh?"
    player "Pero ¿y si SÍ funcionara, eh?"

# game/beyond the bet/day7dlc.rpy:858
translate Spanish day7dlc_start2_69160516:

    # player "No more 'Mr Grim Reaper'."
    player "Se acabó el 'Señor Parca'."

# game/beyond the bet/day7dlc.rpy:861
translate Spanish day7dlc_start2_934ea99b:

    # player "You'd just be Casper."
    player "Serías simplemente Casper."

# game/beyond the bet/day7dlc.rpy:862
translate Spanish day7dlc_start2_2cfbaea0:

    # GR "well..."
    GR "bueno..."

# game/beyond the bet/day7dlc.rpy:863
translate Spanish day7dlc_start2_16c68b4b:

    # GR "it does not sound so bad."
    GR "no suena tan mal."

# game/beyond the bet/day7dlc.rpy:866
translate Spanish day7dlc_start2_e8bd9cda:

    # player "Would you even survive in the human world?"
    player "¿Sobrevivirías siquiera en el mundo humano?"

# game/beyond the bet/day7dlc.rpy:869
translate Spanish day7dlc_start2_2c55aebf:

    # player "Do you have any practical skills?"
    player "¿Tienes alguna habilidad práctica?"

# game/beyond the bet/day7dlc.rpy:870
translate Spanish day7dlc_start2_d8954a14:

    # GR "what's that supposed to mean?"
    GR "¿qué se supone que significa eso?"

# game/beyond the bet/day7dlc.rpy:873
translate Spanish day7dlc_start2_4ab48d8a:

    # player "Uhh... you know..."
    player "Eeeh... ya sabes..."

# game/beyond the bet/day7dlc.rpy:876
translate Spanish day7dlc_start2_a24c67c7:

    # player "You're good at taking souls..."
    player "Eres bueno quitando almas..."

# game/beyond the bet/day7dlc.rpy:879
translate Spanish day7dlc_start2_747c4d26:

    # player "Wait, are you even good at that?"
    player "Espera, ¿acaso eres bueno en eso?"

# game/beyond the bet/day7dlc.rpy:882
translate Spanish day7dlc_start2_2a7557be:

    # player "Day 7 over here and I still have my soul."
    player "Llegamos al día 7 y todavía tengo mi alma."

# game/beyond the bet/day7dlc.rpy:883
translate Spanish day7dlc_start2_7772a27d_9:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:884
translate Spanish day7dlc_start2_f8d73d99:

    # GR "yes. i am very proficient in it."
    GR "sí. soy muy competente en ello."

# game/beyond the bet/day7dlc.rpy:887
translate Spanish day7dlc_start2_c4747f62:

    # player "Let's just pretend that's true for a second."
    player "Pretendamos que eso es verdad por un segundo."

# game/beyond the bet/day7dlc.rpy:889
translate Spanish day7dlc_start2_384f1206:

    # player "Sure, sure..."
    player "Claro, claro..."

# game/beyond the bet/day7dlc.rpy:890
translate Spanish day7dlc_start2_14774a80:

    # GR "........"
    GR "........"

# game/beyond the bet/day7dlc.rpy:893
translate Spanish day7dlc_start2_557f4533:

    # player "What else are you good at?"
    player "¿En qué más eres bueno?"

# game/beyond the bet/day7dlc.rpy:896
translate Spanish day7dlc_start2_b742f8f0:

    # player "Hacking computers with virus-filled apps, I guess."
    player "Hackear computadoras con aplicaciones llenas de virus, supongo."

# game/beyond the bet/day7dlc.rpy:897
translate Spanish day7dlc_start2_0496836b:

    # GR "i am good at plenty."
    GR "soy bueno en muchas cosas."

# game/beyond the bet/day7dlc.rpy:898
translate Spanish day7dlc_start2_5ab5493b:

    # GR "i am an accomplished cook."
    GR "soy un cocinero muy competente."

# game/beyond the bet/day7dlc.rpy:901
translate Spanish day7dlc_start2_096917ff:

    # player "Right..."
    player "Claro..."

# game/beyond the bet/day7dlc.rpy:903
translate Spanish day7dlc_start2_9acebfc4:

    # player "Definitely."
    player "Definitivamente."

# game/beyond the bet/day7dlc.rpy:904
translate Spanish day7dlc_start2_b3909ce4:

    # GR "i have a keen sense of style."
    GR "tengo un agudo sentido del estilo."

# game/beyond the bet/day7dlc.rpy:907
translate Spanish day7dlc_start2_1c58c2ce:

    # player "Well, that's true."
    player "Bueno, eso es cierto."

# game/beyond the bet/day7dlc.rpy:909
translate Spanish day7dlc_start2_b92c355a:

    # player "Questionable, but go off King."
    player "Cuestionable, pero adelante, rey."

# game/beyond the bet/day7dlc.rpy:910
translate Spanish day7dlc_start2_7772a27d_10:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:911
translate Spanish day7dlc_start2_c30211c0_1:

    # GR "i..."
    GR "yo..."

# game/beyond the bet/day7dlc.rpy:912
translate Spanish day7dlc_start2_41187a30:

    # GR "um."
    GR "um."

# game/beyond the bet/day7dlc.rpy:913
translate Spanish day7dlc_start2_e426b60f:

    # GR "people tell me i am... quite good looking..."
    GR "la gente me dice que soy... bastante apuesto..."

# game/beyond the bet/day7dlc.rpy:916
translate Spanish day7dlc_start2_ad486795:

    # player "Who tells you that?"
    player "¿Quién te dice eso?"

# game/beyond the bet/day7dlc.rpy:917
translate Spanish day7dlc_start2_8e21db9d:

    # GR "you."
    GR "tú."

# game/beyond the bet/day7dlc.rpy:918
translate Spanish day7dlc_start2_de38a1bc:

    # GR "azrael."
    GR "azrael."

# game/beyond the bet/day7dlc.rpy:921
translate Spanish day7dlc_start2_77207fb5:

    # player "Okay but that's not a skill."
    player "Okey, pero eso no es una habilidad."

# game/beyond the bet/day7dlc.rpy:924
translate Spanish day7dlc_start2_4566c82e:

    # player "What would you even do as a job?"
    player "¿Qué harías siquiera como trabajo?"

# game/beyond the bet/day7dlc.rpy:925
translate Spanish day7dlc_start2_8152e312:

    # GR "uh..."
    GR "uh…"

# game/beyond the bet/day7dlc.rpy:928
translate Spanish day7dlc_start2_177ce15f:

    # player "Could you even get a job? There's no proof you even exist, right?"
    player "¿Podrías siquiera conseguir un trabajo? No hay pruebas de que existas, ¿verdad?"

# game/beyond the bet/day7dlc.rpy:929
translate Spanish day7dlc_start2_f520d714:

    # GR "well, i was never born, so that is correct."
    GR "bueno, nunca nací, así que es correcto."

# game/beyond the bet/day7dlc.rpy:930
translate Spanish day7dlc_start2_b9b6af2d:

    # GR "i believe there are humans who can deal with these problems."
    GR "creo que hay humanos que pueden encargarse de esos problemas."

# game/beyond the bet/day7dlc.rpy:931
translate Spanish day7dlc_start2_caf0ef2d:

    # GR "create false documents, and such."
    GR "crear documentos falsos, y cosas así."

# game/beyond the bet/day7dlc.rpy:934
translate Spanish day7dlc_start2_cbf5137a:

    # player "That's mega illegal, but I respect it."
    player "Eso es mega ilegal, pero lo respeto."

# game/beyond the bet/day7dlc.rpy:936
translate Spanish day7dlc_start2_17416e72:

    # player "Right, it's that easy."
    player "Claro, así de fácil."

# game/beyond the bet/day7dlc.rpy:937
translate Spanish day7dlc_start2_4cff4000:

    # GR "and then i would get a normal human job like a regular mortal."
    GR "y entonces tendría un trabajo humano normal, como un mortal cualquiera."

# game/beyond the bet/day7dlc.rpy:938
translate Spanish day7dlc_start2_fc31f471:

    # GR "like being ceo of some large business."
    GR "como ser director ejecutivo de alguna gran empresa."

# game/beyond the bet/day7dlc.rpy:939
translate Spanish day7dlc_start2_911a7e71:

    # GR "and then i would be rich and famous."
    GR "y entonces sería rico y famoso."

# game/beyond the bet/day7dlc.rpy:942
translate Spanish day7dlc_start2_e74030b3:

    # player "Casper."
    player "Casper."

# game/beyond the bet/day7dlc.rpy:945
translate Spanish day7dlc_start2_bc3ce644:

    # player "You'd start out flipping burgers somewhere greasy."
    player "Empezarías volteando hamburguesas en algún local grasiento."

# game/beyond the bet/day7dlc.rpy:948
translate Spanish day7dlc_start2_44333e81:

    # player "You can't just walk in and get a job as a CEO."
    player "No puedes simplemente entrar y conseguir un trabajo de director ejecutivo."

# game/beyond the bet/day7dlc.rpy:949
translate Spanish day7dlc_start2_3a219a0a:

    # GR "why not?"
    GR "¿por qué no?"

# game/beyond the bet/day7dlc.rpy:950
translate Spanish day7dlc_start2_445f9f0e:

    # GR "plenty of mortals walk into establishments, hand over their human resume, then be hired on the spot."
    GR "muchos mortales entran a un establecimiento, entregan su currículum humano y los contratan en el acto."

# game/beyond the bet/day7dlc.rpy:953
translate Spanish day7dlc_start2_a365fd1a:

    # player "Maybe fifty years ago."
    player "Quizá hace cincuenta años."

# game/beyond the bet/day7dlc.rpy:955
translate Spanish day7dlc_start2_f376e5a7:

    # player "Uh huh, of course."
    player "Ajá, claro."

# game/beyond the bet/day7dlc.rpy:958
translate Spanish day7dlc_start2_8f21af31:

    # player "I guess you could be a model or something."
    player "Supongo que podrías ser modelo o algo así."

# game/beyond the bet/day7dlc.rpy:959
translate Spanish day7dlc_start2_34235ccf:

    # GR "a model?"
    GR "¿modelo?"

# game/beyond the bet/day7dlc.rpy:960
translate Spanish day7dlc_start2_ed1e5fdd:

    # GR "i suppose my good looks would be well suited to the industry."
    GR "supongo que mi buena apariencia encajaría bien en esa industria."

# game/beyond the bet/day7dlc.rpy:961
translate Spanish day7dlc_start2_057415c3:

    # GR "do you not find it unfair?"
    GR "¿no te parece injusto?"

# game/beyond the bet/day7dlc.rpy:964
translate Spanish day7dlc_start2_2518975d:

    # player "Find what unfair?"
    player "¿Qué cosa es injusta?"

# game/beyond the bet/day7dlc.rpy:965
translate Spanish day7dlc_start2_d0e55469:

    # GR "if i were to become a model, every other model in your realm would likely be forced to give up."
    GR "si me convirtiera en modelo, todos los demás modelos de tu reino probablemente se verían obligados a rendirse."

# game/beyond the bet/day7dlc.rpy:966
translate Spanish day7dlc_start2_7b45a13c:

    # GR "out of a job, how will they survive?"
    GR "sin trabajo, ¿cómo sobrevivirán?"

# game/beyond the bet/day7dlc.rpy:969
translate Spanish day7dlc_start2_84416d59:

    # player "You're such a piece of work, you know that?"
    player "Eres todo un personaje, ¿lo sabías?"

# game/beyond the bet/day7dlc.rpy:970
translate Spanish day7dlc_start2_fb937206:

    # GR "thank you."
    GR "gracias."

# game/beyond the bet/day7dlc.rpy:974
translate Spanish day7dlc_start2_a67dff9b:

    # player "Maybe stick with being a Grim Reaper."
    player "Quizá mejor quédate de Parca."

# game/beyond the bet/day7dlc.rpy:975
translate Spanish day7dlc_start2_135f6c29:

    # GR "that is the plan."
    GR "ese es el plan."

# game/beyond the bet/day7dlc.rpy:976
translate Spanish day7dlc_start2_758a8ee3:

    # GR "if this gods forsaken illness does not take me before then."
    GR "si esta maldita enfermedad no me lleva antes."

# game/beyond the bet/day7dlc.rpy:979
translate Spanish day7dlc_start2_df9beba8:

    # player "I wouldn't mind fiddling around inside you >:D"
    player "A mí no me importaría hurgar dentro de ti >:D"

# game/beyond the bet/day7dlc.rpy:980
translate Spanish day7dlc_start2_771282ed_1:

    # GR "WHAT?"
    GR "¡¿QUÉ?!"

# game/beyond the bet/day7dlc.rpy:983
translate Spanish day7dlc_start2_62942385:

    # player "You know. For science."
    player "Ya sabes. Por la ciencia."

# game/beyond the bet/day7dlc.rpy:986
translate Spanish day7dlc_start2_e6736941:

    # player "I do consider myself something of a scientist."
    player "Yo me considero algo así como [arti_2] científic[letra]."

# game/beyond the bet/day7dlc.rpy:987
translate Spanish day7dlc_start2_6d9857a3:

    # GR "And... and by that, you mean..."
    GR "Y... y con eso quieres decir..."

# game/beyond the bet/day7dlc.rpy:990
translate Spanish day7dlc_start2_83ed44d7:

    # player "Not to toot my own horn or anything..."
    player "Sin ánimo de presumir..."

# game/beyond the bet/day7dlc.rpy:993
translate Spanish day7dlc_start2_22d5e779:

    # player "But I'm certain that you'd forget about feeling sick once I'm done with you."
    player "Pero estoy segur[letra] de que olvidarías que estás enfermo una vez que termine contigo."

# game/beyond the bet/day7dlc.rpy:994
translate Spanish day7dlc_start2_de7fa73c:

    # GR "ARE YOU PROPOSITIONING ME RIGHT NOW?"
    GR "¿ME ESTÁS HACIENDO UNA PROPUESTA INDECENTE AHORA MISMO?"

# game/beyond the bet/day7dlc.rpy:997
translate Spanish day7dlc_start2_53585d5e:

    # player "I always know I'm hitting the right notes when you bring out the caps."
    player "Siempre sé que estoy dando en el blanco cuando sacas las mayúsculas."

# game/beyond the bet/day7dlc.rpy:1000
translate Spanish day7dlc_start2_4adb2577:

    # player "Maybe I am ;)"
    player "Quizá sí ;)"

# game/beyond the bet/day7dlc.rpy:1003
translate Spanish day7dlc_start2_684ec710:

    # player "Would you like that?"
    player "¿Te gustaría?"

# game/beyond the bet/day7dlc.rpy:1004
translate Spanish day7dlc_start2_73e1b695:

    # GR "......................."
    GR "......................."

# game/beyond the bet/day7dlc.rpy:1005
translate Spanish day7dlc_start2_672dfa14:

    # GR "you know i am supposed to be KILLING YOU TODAY, RIGHT?"
    GR "sabes que se supone que hoy debo MATARTE, ¿verdad?"

# game/beyond the bet/day7dlc.rpy:1008
translate Spanish day7dlc_start2_78f08c2c:

    # player "Well, yeah."
    player "Bueno, sí."

# game/beyond the bet/day7dlc.rpy:1011
translate Spanish day7dlc_start2_6a38d6c1:

    # player "That's the perfect time to bend over the Grim Reaper, right? 😇 "
    player "Ese es el momento perfecto para doblegar a la Parca, ¿no? 😇"

# game/beyond the bet/day7dlc.rpy:1012
translate Spanish day7dlc_start2_95151b2c_1:

    # GR "....."
    GR "....."

# game/beyond the bet/day7dlc.rpy:1013
translate Spanish day7dlc_start2_e9656f04:

    # GR "..............."
    GR "..............."

# game/beyond the bet/day7dlc.rpy:1014
translate Spanish day7dlc_start2_4e2e6a0f:

    # GR "........................................"
    GR "........................................"

# game/beyond the bet/day7dlc.rpy:1015
translate Spanish day7dlc_start2_22ffcf86:

    # GR "this is... you are..."
    GR "esto es... tú eres..."

# game/beyond the bet/day7dlc.rpy:1016
translate Spanish day7dlc_start2_dceac244:

    # GR "dear gods, my head is spinning far too much for this..."
    GR "por todos los dioses, la cabeza me da demasiadas vueltas para esto..."

# game/beyond the bet/day7dlc.rpy:1017
translate Spanish day7dlc_start2_4267e1b6:

    # GR "it... i am not saying no, HOWEVER...!"
    GR "yo... no estoy diciendo que no, ¡SIN EMBARGO...!"

# game/beyond the bet/day7dlc.rpy:1018
translate Spanish day7dlc_start2_cd982909:

    # GR "just so you know, i am literally DEATH INCARNATE!"
    GR "¡solo para que lo sepas, soy literalmente LA MUERTE ENCARNADA!"

# game/beyond the bet/day7dlc.rpy:1019
translate Spanish day7dlc_start2_3020bd63:

    # GR "i... am not so easy to dominate..."
    GR "yo... no soy tan fácil de dominar..."

# game/beyond the bet/day7dlc.rpy:1020
translate Spanish day7dlc_start2_784633c5:

    # GR "a single touch from me would consume your every waking thought from then on."
    GR "un solo roce mío consumiría cada pensamiento tuyo desde entonces, despiert[letra] o no."

# game/beyond the bet/day7dlc.rpy:1021
translate Spanish day7dlc_start2_ca957a38:

    # GR "are you ready to be that addicted to something? to someone?"
    GR "¿estás list[letra] para volverte tan adict[letra] a algo? ¿a alguien?"

# game/beyond the bet/day7dlc.rpy:1024
translate Spanish day7dlc_start2_bfe6abff:

    # player "Who's to say I'm not already addicted?"
    player "¿Y si ya lo estoy?"

# game/beyond the bet/day7dlc.rpy:1025
translate Spanish day7dlc_start2_949f2162:

    # GR "......."
    GR "......."

# game/beyond the bet/day7dlc.rpy:1026
translate Spanish day7dlc_start2_0b41e4a3:

    # GR "how did we get from medicine to... to..."
    GR "¿cómo pasamos de la medicina a... a...?"

# game/beyond the bet/day7dlc.rpy:1029
translate Spanish day7dlc_start2_f367882f:

    # player "Me consuming your body?"
    player "¿Yo consumiendo tu cuerpo?"

# game/beyond the bet/day7dlc.rpy:1030
translate Spanish day7dlc_start2_a174ea10:

    # GR "you are very forward, sunshine. so forward."
    GR "eres muy direct[letra], solecito. tan direct[letra]."

# game/beyond the bet/day7dlc.rpy:1031
translate Spanish day7dlc_start2_7f7ac258:

    # GR "you should watch what you ask for."
    GR "deberías tener cuidado con lo que pides."

# game/beyond the bet/day7dlc.rpy:1032
translate Spanish day7dlc_start2_acccabde:

    # GR "i doubt you would ever be fulfilled again if you had me."
    GR "dudo que alguna vez vuelvas a sentirte satisfech[letra] si me tuvieras a mí."

# game/beyond the bet/day7dlc.rpy:1035
translate Spanish day7dlc_start2_7de52b39:

    # player "Then I guess we'll just have to throw the bet to the side, and I'll keep you."
    player "Entonces supongo que tendremos que dejar la apuesta de lado, y me quedaré contigo."

# game/beyond the bet/day7dlc.rpy:1036
translate Spanish day7dlc_start2_7772a27d_11:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:1037
translate Spanish day7dlc_start2_17462448:

    # GR "i cannot say it sounds terrible..."
    GR "no puedo decir que suena terrible..."

# game/beyond the bet/day7dlc.rpy:1038
translate Spanish day7dlc_start2_b8a86f17_1:

    # GR "ahem..."
    GR "ejem..."

# game/beyond the bet/day7dlc.rpy:1039
translate Spanish day7dlc_start2_88da58c8:

    # GR "by that i mean."
    GR "con eso quiero decir."

# game/beyond the bet/day7dlc.rpy:1040
translate Spanish day7dlc_start2_9328d6ea:

    # GR "uh."
    GR "eh."

# game/beyond the bet/day7dlc.rpy:1041
translate Spanish day7dlc_start2_e6f24cc4:

    # GR "medicine. yes."
    GR "medicina. sí."

# game/beyond the bet/day7dlc.rpy:1042
translate Spanish day7dlc_start2_33d8006b:

    # GR "if only it would work."
    GR "ojalá funcionara."

# game/beyond the bet/day7dlc.rpy:1043
translate Spanish day7dlc_start2_3fa75501:

    # GR "i'm glad we talked about that and definitely not the idea of you and i..."
    GR "me alegra que hayamos hablado de eso y definitivamente no de la idea de ti y de mí..."

# game/beyond the bet/day7dlc.rpy:1044
translate Spanish day7dlc_start2_ebc9eb7a_1:

    # GR "yes."
    GR "sí."

# game/beyond the bet/day7dlc.rpy:1045
translate Spanish day7dlc_start2_509799c7:

    # GR "i'm going to be quiet now."
    GR "voy a quedarme callado ahora."

# game/beyond the bet/day7dlc.rpy:1048
translate Spanish day7dlc_start2_749647c3:

    # player ":)"
    player ":)"

# game/beyond the bet/day7dlc.rpy:1051
translate Spanish day7dlc_start2_67cea3ae:

    # player "I can be your learning experience ;)"
    player "Puedo ser tu experiencia de aprendizaje ;)"

# game/beyond the bet/day7dlc.rpy:1054
translate Spanish day7dlc_start2_fb5297d4:

    # player "We can come compare notes... and I'll let you explore whatever you want."
    player "Podemos venir a comparar notas... y te dejaré explorar lo que quieras."

# game/beyond the bet/day7dlc.rpy:1055
translate Spanish day7dlc_start2_e627f938:

    # GR "are... are you saying what i think you're saying?"
    GR "¿es... estás diciendo lo que creo que estás diciendo?"

# game/beyond the bet/day7dlc.rpy:1058
translate Spanish day7dlc_start2_2063a3e9:

    # player "Maybe."
    player "Quizá."

# game/beyond the bet/day7dlc.rpy:1061
translate Spanish day7dlc_start2_e843712c:

    # player "I might be."
    player "Podría ser."

# game/beyond the bet/day7dlc.rpy:1062
translate Spanish day7dlc_start2_fe580ce7:

    # GR "if you had my touch, you would do nothing but crave it for the rest of your life."
    GR "si recibieras mi toque, no harías más que anhelarlo por el resto de tu vida."

# game/beyond the bet/day7dlc.rpy:1065
translate Spanish day7dlc_start2_a678a4b9:

    # player "Checking my calendar... ah, yes, the rest of my life was SUPPOSED to end today."
    player "Déjame revisar mi calendario... ah, sí, se SUPONÍA que el resto de mi vida terminaba hoy."

# game/beyond the bet/day7dlc.rpy:1068
translate Spanish day7dlc_start2_46da4e1d:

    # player "So I think I could deal with that."
    player "Así que creo que podría lidiar con eso."

# game/beyond the bet/day7dlc.rpy:1069
translate Spanish day7dlc_start2_8c68c9c1:

    # GR "death approaches you rapidly and you can think of nothing but... bedding him?!"
    GR "¡¿la muerte se te acerca a toda velocidad y lo único en que piensas es en... llevártelo a la cama?!"

# game/beyond the bet/day7dlc.rpy:1072
translate Spanish day7dlc_start2_98c4e1d4:

    # player "Maaaaaybe."
    player "Quizááás."

# game/beyond the bet/day7dlc.rpy:1075
translate Spanish day7dlc_start2_fcf1bd2a:

    # player "Just saying, if you were curious about how we're different and how we're the same..."
    player "Solo digo, si tenías curiosidad por cómo somos diferentes y cómo somos iguales..."

# game/beyond the bet/day7dlc.rpy:1078
translate Spanish day7dlc_start2_0b09993a:

    # player "I wouldn't mind showing you."
    player "No me importaría mostrarte."

# game/beyond the bet/day7dlc.rpy:1081
translate Spanish day7dlc_start2_af95e483:

    # player "We can find a lot to explore together, I'm sure ;)"
    player "Seguro que podemos encontrar mucho que explorar juntos ;)"

# game/beyond the bet/day7dlc.rpy:1082
translate Spanish day7dlc_start2_7772a27d_12:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:1083
translate Spanish day7dlc_start2_8b3081a2:

    # GR "and what would you have me do?"
    GR "¿y qué esperas que haga?"

# game/beyond the bet/day7dlc.rpy:1086
translate Spanish day7dlc_start2_4d07b8ee:

    # player "Anything and everything you'd like."
    player "Todo lo que quieras."

# game/beyond the bet/day7dlc.rpy:1089
translate Spanish day7dlc_start2_225da406:

    # player "Why don't YOU tell me what you want to do, lover boy?"
    player "¿Por qué no me dices TÚ qué quieres hacer, galán?"

# game/beyond the bet/day7dlc.rpy:1090
translate Spanish day7dlc_start2_1c3c84bb:

    # GR "that is... i..."
    GR "eso es... yo..."

# game/beyond the bet/day7dlc.rpy:1091
translate Spanish day7dlc_start2_b76b05f7:

    # GR "you are a mortal(maybe...?) and i am not."
    GR "tú eres [arti_2] mortal (¿quizá...?) y yo no."

# game/beyond the bet/day7dlc.rpy:1092
translate Spanish day7dlc_start2_b8848097:

    # GR "no matter if i... did want what you say or not..."
    GR "sin importar si yo... quisiera lo que dices o no..."

# game/beyond the bet/day7dlc.rpy:1093
translate Spanish day7dlc_start2_6eb08efd:

    # GR "it... cannot happen."
    GR "eso... no puede suceder."

# game/beyond the bet/day7dlc.rpy:1096
translate Spanish day7dlc_start2_02b649d4:

    # player "Let's roleplay a little here."
    player "Hagamos un poco de roleplay."

# game/beyond the bet/day7dlc.rpy:1099
translate Spanish day7dlc_start2_78e0cdcc:

    # player "What if I was a reaper, too? Or you were human?"
    player "¿Y si yo también fuera una parca? ¿O si tú fueras humano?"

# game/beyond the bet/day7dlc.rpy:1102
translate Spanish day7dlc_start2_9367bc0d:

    # player "Then what would you want?"
    player "Entonces, ¿qué te gustaría?"

# game/beyond the bet/day7dlc.rpy:1103
translate Spanish day7dlc_start2_c30211c0_2:

    # GR "i..."
    GR "yo..."

# game/beyond the bet/day7dlc.rpy:1104
translate Spanish day7dlc_start2_ea14b7ee:

    # GR "would perhaps like to feel the warmth of your skin. the curve of your back."
    GR "quizá me gustaría sentir la calidez de tu piel. la curva de tu espalda."

# game/beyond the bet/day7dlc.rpy:1105
translate Spanish day7dlc_start2_24b0c42f:

    # GR "i would like to run my fingers across yours, to feel every inch of you beneath me..."
    GR "me gustaría pasar mis dedos por los tuyos, sentir cada centímetro de ti debajo de mí..."

# game/beyond the bet/day7dlc.rpy:1106
translate Spanish day7dlc_start2_0b16bee0:

    # GR "ahem."
    GR "ejem."

# game/beyond the bet/day7dlc.rpy:1107
translate Spanish day7dlc_start2_d4900279:

    # GR "hypothetically."
    GR "hipotéticamente."

# game/beyond the bet/day7dlc.rpy:1108
translate Spanish day7dlc_start2_2c8e2b5a:

    # GR "if we lived in a universe where that might happen."
    GR "si viviéramos en un universo donde eso pudiera suceder."

# game/beyond the bet/day7dlc.rpy:1109
translate Spanish day7dlc_start2_f659e1ff:

    # GR "i, naturally, do not mean i necessarily want that now."
    GR "naturalmente, no quiero decir que necesariamente lo quiera ahora."

# game/beyond the bet/day7dlc.rpy:1110
translate Spanish day7dlc_start2_ab1ea47d:

    # GR "this is just a human 'roleplay', as you called it."
    GR "esto es solo 'roleplay' humano, como lo llamaste."

# game/beyond the bet/day7dlc.rpy:1113
translate Spanish day7dlc_start2_f1fc5765:

    # player "Right, right."
    player "Claro, claro."

# game/beyond the bet/day7dlc.rpy:1116
translate Spanish day7dlc_start2_0aa153f6:

    # player "My Little Reaper doesn't REALLY want to join me in bed, of course."
    player "Mi Parquita no quiere DE VERDAD meterse en la cama conmigo, claro."

# game/beyond the bet/day7dlc.rpy:1117
translate Spanish day7dlc_start2_74d90298:

    # GR "i never said that!"
    GR "¡yo nunca dije eso!"

# game/beyond the bet/day7dlc.rpy:1120
translate Spanish day7dlc_start2_0493bf86:

    # player "Oh?"
    player "¿Ah, sí?"

# game/beyond the bet/day7dlc.rpy:1123
translate Spanish day7dlc_start2_f36b0043:

    # player "So you disagree?"
    player "¿Entonces no estás de acuerdo?"

# game/beyond the bet/day7dlc.rpy:1124
translate Spanish day7dlc_start2_7772a27d_13:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:1125
translate Spanish day7dlc_start2_fdee03b8:

    # GR "i swear, you are not human."
    GR "juro que no eres human[letra]."

# game/beyond the bet/day7dlc.rpy:1126
translate Spanish day7dlc_start2_7e524dcc:

    # GR "you must be a devil, or a demon, or some kind of... of... annoying imp!"
    GR "debes ser [arti_2] diabl[letra], o [arti_2] demoni[letra], o algún tipo de... de... ¡duendecit[letra] molest[letra]!"

# game/beyond the bet/day7dlc.rpy:1127
translate Spanish day7dlc_start2_e665bb91:

    # GR "you do not know what you do to me..."
    GR "no sabes lo que me haces..."

# game/beyond the bet/day7dlc.rpy:1130
translate Spanish day7dlc_start2_887170ab:

    # player "I know what I'd LIKE to do to you, though."
    player "Yo sí sé lo que me GUSTARÍA hacerte a ti."

# game/beyond the bet/day7dlc.rpy:1131
translate Spanish day7dlc_start2_dfc667e3:

    # GR "weren't we talking about medicine?"
    GR "¿no estábamos hablando de medicina?"

# game/beyond the bet/day7dlc.rpy:1132
translate Spanish day7dlc_start2_346cad2d:

    # GR "yes, human medicine. great thing, that."
    GR "sí, medicina humana. una gran cosa, esa."

# game/beyond the bet/day7dlc.rpy:1136
translate Spanish day7dlc_start2_390ef836:

    # player "Well, maybe you should fiddle some more."
    player "Bueno, quizá deberías hurgar un poco más."

# game/beyond the bet/day7dlc.rpy:1137
translate Spanish day7dlc_start2_db20bf13:

    # GR "i do not fancy myself much of a fiddler."
    GR "no me considero muy aficionado a hurgar."

# game/beyond the bet/day7dlc.rpy:1138
translate Spanish day7dlc_start2_6e7c6798:

    # GR "blood, gore and whatnot has little effect on me, before you accuse me of being soft."
    GR "la sangre, las vísceras y demás tienen poco efecto en mí, antes de que me acuses de ser blando."

# game/beyond the bet/day7dlc.rpy:1141
translate Spanish day7dlc_start2_1be67e9e:

    # player "I bet you've seen a lot of that stuff..."
    player "Apuesto a que has visto mucho de eso..."

# game/beyond the bet/day7dlc.rpy:1142
translate Spanish day7dlc_start2_b050671f:

    # GR "more than you'd be able to count."
    GR "más de lo que podrías contar."

# game/beyond the bet/day7dlc.rpy:1145
translate Spanish day7dlc_start2_710b900f:

    # player "Does it get easier?"
    player "¿Se vuelve más fácil?"

# game/beyond the bet/day7dlc.rpy:1146
translate Spanish day7dlc_start2_65971bbd:

    # GR "...yes and no."
    GR "...sí y no."

# game/beyond the bet/day7dlc.rpy:1147
translate Spanish day7dlc_start2_b5062e51:

    # GR "i have seen... much."
    GR "he visto... mucho."

# game/beyond the bet/day7dlc.rpy:1148
translate Spanish day7dlc_start2_81637a80:

    # GR "i am numb to it, i suppose, but terrible things happen to good people every day."
    GR "estoy insensibilizado, supongo, pero cosas terribles les pasan a las personas buenas todos los días."

# game/beyond the bet/day7dlc.rpy:1149
translate Spanish day7dlc_start2_a3dedbeb:

    # GR "but terrible things happen to everyone, i imagine."
    GR "pero imagino que cosas terribles le pasan a todo el mundo."

# game/beyond the bet/day7dlc.rpy:1150
translate Spanish day7dlc_start2_db01c77a:

    # GR "at least in this, death is fair."
    GR "al menos en esto, la muerte es justa."

# game/beyond the bet/day7dlc.rpy:1153
translate Spanish day7dlc_start2_4445b024:

    # player "I'm not sure I could do it."
    player "No sé si podría hacerlo."

# game/beyond the bet/day7dlc.rpy:1156
translate Spanish day7dlc_start2_2d92ff6b:

    # player "Blood and stuff grosses me outttt."
    player "La sangre y esas cosas me dan muuucho asco."

# game/beyond the bet/day7dlc.rpy:1157
translate Spanish day7dlc_start2_8250dc55:

    # GR "fair."
    GR "es válido."

# game/beyond the bet/day7dlc.rpy:1160
translate Spanish day7dlc_start2_09a97df4:

    # player "I thought you'd laugh at me for that."
    player "Pensé que te reirías de mí por eso."

# game/beyond the bet/day7dlc.rpy:1161
translate Spanish day7dlc_start2_aaa006e8:

    # GR "death is beautiful."
    GR "la muerte es hermosa."

# game/beyond the bet/day7dlc.rpy:1162
translate Spanish day7dlc_start2_85bcd0d9:

    # GR "but that does not stop it from sometimes also being frightful."
    GR "pero eso no impide que a veces también sea espantosa."

# game/beyond the bet/day7dlc.rpy:1163
translate Spanish day7dlc_start2_ec587b96:

    # GR "i cannot fault a human for not enjoying it."
    GR "no puedo culpar a un humano por no disfrutarla."

# game/beyond the bet/day7dlc.rpy:1166
translate Spanish day7dlc_start2_9332b5af:

    # player "Sometimes you're very reasonable."
    player "A veces eres muy razonable."

# game/beyond the bet/day7dlc.rpy:1167
translate Spanish day7dlc_start2_66930c3d:

    # GR "i ferry souls to the afterlife for a living."
    GR "transporto almas al más allá para ganarme la vida."

# game/beyond the bet/day7dlc.rpy:1170
translate Spanish day7dlc_start2_06db2e0c:

    # player "And other times you say things like that."
    player "Y otras veces dices cosas como esa."

# game/beyond the bet/day7dlc.rpy:1173
translate Spanish day7dlc_start2_4572ce6f:

    # player "Well, I guess it's true."
    player "Bueno, supongo que es cierto."

# game/beyond the bet/day7dlc.rpy:1177
translate Spanish day7dlc_start2_24397299:

    # player "I'm pretty numb to that kind of stuff myself."
    player "A mí ese tipo de cosas ya casi no me afectan."

# game/beyond the bet/day7dlc.rpy:1180
translate Spanish day7dlc_start2_a2a648b1:

    # player "Seen a few too many horror movies in my days."
    player "He visto unas cuantas películas de terror de más en mi vida."

# game/beyond the bet/day7dlc.rpy:1181
translate Spanish day7dlc_start2_b4bfe65f:

    # GR "horror movies, huh."
    GR "películas de terror, ¿eh?"

# game/beyond the bet/day7dlc.rpy:1182
translate Spanish day7dlc_start2_a453469c:

    # GR "i have never seen one of your human horror movies, though i have heard of them on occasion."
    GR "nunca he visto ninguna de sus películas de terror humanas, aunque he oído hablar de ellas de vez en cuando."

# game/beyond the bet/day7dlc.rpy:1185
translate Spanish day7dlc_start2_97d41b2e:

    # player "Some of them are pretty realistic."
    player "Algunas son bastante realistas."

# game/beyond the bet/day7dlc.rpy:1188
translate Spanish day7dlc_start2_82a38928:

    # player "You might like them."
    player "Quizá te gusten."

# game/beyond the bet/day7dlc.rpy:1189
translate Spanish day7dlc_start2_a19e8b5f:

    # GR "doubtful."
    GR "lo dudo."

# game/beyond the bet/day7dlc.rpy:1190
translate Spanish day7dlc_start2_37b722e4:

    # GR "if they are supposed to scare me, then i don't see what will be enjoyable about them."
    GR "si se supone que me asustan, no veo qué tendrían de disfrutables."

# game/beyond the bet/day7dlc.rpy:1191
translate Spanish day7dlc_start2_b8d3787e:

    # GR "i sincerely doubt that they could show me much i have not seen before."
    GR "dudo sinceramente que puedan mostrarme mucho que no haya visto antes."

# game/beyond the bet/day7dlc.rpy:1194
translate Spanish day7dlc_start2_14cf1d9b:

    # player "Oh man."
    player "Ay, hombre."

# game/beyond the bet/day7dlc.rpy:1197
translate Spanish day7dlc_start2_43ae9405:

    # player "Horror movie night?"
    player "¿Noche de películas de terror?"

# game/beyond the bet/day7dlc.rpy:1200
translate Spanish day7dlc_start2_fa0dd86d:

    # player "Horror movie night."
    player "Noche de películas de terror."

# game/beyond the bet/day7dlc.rpy:1203
translate Spanish day7dlc_start2_6d670d3b:

    # player "I'm gonna find something that'll make you cling to me in fear."
    player "Voy a encontrar algo que te haga aferrarte a mí del miedo."

# game/beyond the bet/day7dlc.rpy:1204
translate Spanish day7dlc_start2_ec53f319:

    # GR "cling... cling to you?!"
    GR "¡¿aferrarme... aferrarme a ti?!"

# game/beyond the bet/day7dlc.rpy:1205
translate Spanish day7dlc_start2_a23a44e5:

    # GR "you would surely cling to me!"
    GR "¡seguro que tú serías quien se aferrara a mí!"

# game/beyond the bet/day7dlc.rpy:1208
translate Spanish day7dlc_start2_c42b9571:

    # player "Would you like that, Grimmy :D ?"
    player "¿Te gustaría, Parquita :D ?"

# game/beyond the bet/day7dlc.rpy:1209
translate Spanish day7dlc_start2_f3b1f875:

    # GR "......"
    GR "......"

# game/beyond the bet/day7dlc.rpy:1210
translate Spanish day7dlc_start2_d1c5d8ba:

    # GR "next topic."
    GR "siguiente tema."

# game/beyond the bet/day7dlc.rpy:1213
translate Spanish day7dlc_start2_21462471:

    # player "But I like this topic!"
    player "¡Pero me gusta este tema!"

# game/beyond the bet/day7dlc.rpy:1214
translate Spanish day7dlc_start2_01eda210:

    # GR "next topic!"
    GR "¡siguiente tema!"

# game/beyond the bet/day7dlc.rpy:1215
translate Spanish day7dlc_start2_fe7a08aa:

    # GR "right. yes. medicine."
    GR "claro. sí. la medicina."

# game/beyond the bet/day7dlc.rpy:1216
translate Spanish day7dlc_start2_6ce4e20a:

    # GR "fantastic thing, that."
    GR "una cosa fantástica, esa."

# game/beyond the bet/day7dlc.rpy:1217
translate Spanish day7dlc_start2_17a7d0e5:

    # GR "definitely."
    GR "definitivamente."

# game/beyond the bet/day7dlc.rpy:1220
translate Spanish day7dlc_start2_c97473e5:

    # player "You just said you've never had it!"
    player "¡Acabas de decir que nunca la has probado!"

# game/beyond the bet/day7dlc.rpy:1221
translate Spanish day7dlc_start2_0cf5d6be:

    # GR "i'm sure it's great."
    GR "estoy seguro de que es genial."

# game/beyond the bet/day7dlc.rpy:1224
translate Spanish day7dlc_start2_7a79f9a1:

    # player "It's really not."
    player "La verdad es que no."

# game/beyond the bet/day7dlc.rpy:1227
translate Spanish day7dlc_start2_d53ebafd:

    # player "Most of it tastes pretty terrible."
    player "La mayoría sabe bastante mal."

# game/beyond the bet/day7dlc.rpy:1228
translate Spanish day7dlc_start2_3f7ad2f6:

    # GR "oh."
    GR "oh."

# game/beyond the bet/day7dlc.rpy:1235
translate Spanish day7dlc_start2_8b6aea6b:

    # player "I'm practically a doctor."
    player "Soy casi [arti_2] [doctor]."

# game/beyond the bet/day7dlc.rpy:1236
translate Spanish day7dlc_start2_7922f9d9:

    # GR "on what grounds can you say that?"
    GR "¿con qué fundamento puedes decir eso?"

# game/beyond the bet/day7dlc.rpy:1239
translate Spanish day7dlc_start2_b4b55989:

    # player "I just think I'd make a pretty good doctor."
    player "Solo creo que sería [arti_2] [doctor] bastante [buen]."

# game/beyond the bet/day7dlc.rpy:1240
translate Spanish day7dlc_start2_a9d006ad:

    # GR "does that make you an actual doctor?"
    GR "¿eso te hace [doctor] de verdad?"

# game/beyond the bet/day7dlc.rpy:1243
translate Spanish day7dlc_start2_cc2c0898:

    # player "Well, no."
    player "Bueno, no."

# game/beyond the bet/day7dlc.rpy:1246
translate Spanish day7dlc_start2_b37e0bd3:

    # player "Not literally."
    player "No literalmente."

# game/beyond the bet/day7dlc.rpy:1249
translate Spanish day7dlc_start2_b9298ab0:

    # player "But I do still feel like I'd do a good job of doctoring you."
    player "Pero igual siento que haría un buen trabajo curándote."

# game/beyond the bet/day7dlc.rpy:1250
translate Spanish day7dlc_start2_6f2155f3_1:

    # GR "how so?"
    GR "¿cómo así?"

# game/beyond the bet/day7dlc.rpy:1253
translate Spanish day7dlc_start2_ee95782c:

    # player "If you're feeling too weak to take the medicine, I can help you take it."
    player "Si te sientes demasiado débil para tomar la medicina, puedo ayudarte a tomarla."

# game/beyond the bet/day7dlc.rpy:1256
translate Spanish day7dlc_start2_7c184cf2:

    # player "Just let me guide your mouth open, okay?"
    player "Solo déjame guiar tu boca para que la abras, ¿okey?"

# game/beyond the bet/day7dlc.rpy:1257
translate Spanish day7dlc_start2_7772a27d_14:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:1260
translate Spanish day7dlc_start2_81188bf0:

    # player "I'll be gentle with you, okay?"
    player "Seré delicad[letra] contigo, ¿okey?"

# game/beyond the bet/day7dlc.rpy:1261
translate Spanish day7dlc_start2_5fc32114:

    # GR "this is sounding more and more like medical malpractice."
    GR "esto suena cada vez más a negligencia médica."

# game/beyond the bet/day7dlc.rpy:1264
translate Spanish day7dlc_start2_ff88f5f1:

    # player "Malpractice? No, no, no..."
    player "¿Negligencia? No, no, no..."

# game/beyond the bet/day7dlc.rpy:1267
translate Spanish day7dlc_start2_f6b2b29b:

    # player "I'll be totally professional, ethical and totally nothing bad will happen."
    player "Seré totalmente profesional, étic[letra], y no pasará absolutamente nada malo."

# game/beyond the bet/day7dlc.rpy:1270
translate Spanish day7dlc_start2_e6926e10:

    # player "Wait, do you have hospitals in the Underworld, anyway?"
    player "Espera, ¿tienen hospitales en el Inframundo, por cierto?"

# game/beyond the bet/day7dlc.rpy:1271
translate Spanish day7dlc_start2_2c13ff84:

    # GR "hospitals? there are some, but not for reapers."
    GR "¿hospitales? hay algunos, pero no para parcas."

# game/beyond the bet/day7dlc.rpy:1272
translate Spanish day7dlc_start2_9803dffc:

    # GR "they are not much use to us when we do not get sick."
    GR "no nos sirven de mucho si no nos enfermamos."

# game/beyond the bet/day7dlc.rpy:1275
translate Spanish day7dlc_start2_7b1b265f:

    # player "What about injured?"
    player "¿Y qué pasa con los heridos?"

# game/beyond the bet/day7dlc.rpy:1276
translate Spanish day7dlc_start2_b212f201:

    # GR "we are expected to deal with our injuries ourselves."
    GR "se espera que nos encarguemos de nuestras heridas por nuestra cuenta."

# game/beyond the bet/day7dlc.rpy:1279
translate Spanish day7dlc_start2_0cb18888:

    # player "That doesn't seem fair."
    player "Eso no parece justo."

# game/beyond the bet/day7dlc.rpy:1280
translate Spanish day7dlc_start2_20010dc1:

    # GR "yes, well, little is."
    GR "sí, bueno, poco lo es."

# game/beyond the bet/day7dlc.rpy:1281
translate Spanish day7dlc_start2_4fbc0d44:

    # GR "frankly, we get injured very little."
    GR "francamente, nos herimos muy poco."

# game/beyond the bet/day7dlc.rpy:1284
translate Spanish day7dlc_start2_9513c647:

    # player "Did you ever get hit by a plane while flying?"
    player "¿Alguna vez te golpeó un avión mientras volabas?"

# game/beyond the bet/day7dlc.rpy:1285
translate Spanish day7dlc_start2_8ede3c01:

    # GR "what?"
    GR "¿qué?"

# game/beyond the bet/day7dlc.rpy:1288
translate Spanish day7dlc_start2_5fa5176c:

    # player "You fly, right?"
    player "Tú vuelas, ¿no?"

# game/beyond the bet/day7dlc.rpy:1291
translate Spanish day7dlc_start2_06a92ca6:

    # player "And you make people think you're a bird. Did you ever accidentally fly into a plane?"
    player "Y haces que la gente piense que eres un pájaro. ¿Alguna vez chocaste sin querer con un avión?"

# game/beyond the bet/day7dlc.rpy:1292
translate Spanish day7dlc_start2_26ac4066:

    # GR "i... no?"
    GR "yo... ¿no?"

# game/beyond the bet/day7dlc.rpy:1295
translate Spanish day7dlc_start2_334bfc2a:

    # player "Is it a bird? Is it a plane???"
    player "¿Es un pájaro? ¿¿¿Es un avión???"

# game/beyond the bet/day7dlc.rpy:1298
translate Spanish day7dlc_start2_8a1f503e:

    # player "Nope, just Casper flying around again."
    player "Nop, es solo Casper volando otra vez."

# game/beyond the bet/day7dlc.rpy:1299
translate Spanish day7dlc_start2_46e1b498:

    # GR "what use would there be to flying around so high, anyway?"
    GR "¿de qué serviría volar tan alto, de todos modos?"

# game/beyond the bet/day7dlc.rpy:1302
translate Spanish day7dlc_start2_eaf81059:

    # player "I dunno, but you gotta watch out for those planes, man."
    player "No sé, pero hay que tener cuidado con los aviones, hombre."

# game/beyond the bet/day7dlc.rpy:1305
translate Spanish day7dlc_start2_1f440902:

    # player "They're killer."
    player "Son letales."

# game/beyond the bet/day7dlc.rpy:1306
translate Spanish day7dlc_start2_e0cadf39:

    # GR "i... imagine so..."
    GR "yo... imagino que sí..."

# game/beyond the bet/day7dlc.rpy:1307
translate Spanish day7dlc_start2_92bf19f7:

    # GR "uh... i will be on the lookout for stray planes, then."
    GR "eh... estaré pendiente de los aviones perdidos, entonces."

# game/beyond the bet/day7dlc.rpy:1310
translate Spanish day7dlc_start2_960444f7:

    # player "Good. Always best to be ready."
    player "Bien. Siempre es mejor tomar precauciones."

# game/beyond the bet/day7dlc.rpy:1314
translate Spanish day7dlc_start2_2921a387:

    # player "Wait, who else lives in the Underworld for the hospitals to be for?"
    player "Espera, ¿quién más vive en el Inframundo para que haya hospitales?"

# game/beyond the bet/day7dlc.rpy:1315
translate Spanish day7dlc_start2_f4765a76:

    # GR "many people and creatures, really."
    GR "mucha gente y criaturas, en realidad."

# game/beyond the bet/day7dlc.rpy:1316
translate Spanish day7dlc_start2_88cee319:

    # GR "we have animals you do not have on earth."
    GR "tenemos animales que ustedes no tienen en la tierra."

# game/beyond the bet/day7dlc.rpy:1317
translate Spanish day7dlc_start2_711726fb:

    # GR "there are devilish creatures, too, ones you would see in the strangest of fictions..."
    GR "también hay criaturas diabólicas, de las que verías en las ficciones más extrañas..."

# game/beyond the bet/day7dlc.rpy:1318
translate Spanish day7dlc_start2_c83ad317:

    # GR "ah, of course, there are also some minor and major gods. you know how it is."
    GR "ah, claro, también hay algunos dioses menores y mayores. ya sabes cómo son las cosas."

# game/beyond the bet/day7dlc.rpy:1321
translate Spanish day7dlc_start2_f2f47468_2:

    # player "WHAT?"
    player "¡¿QUÉ?!"

# game/beyond the bet/day7dlc.rpy:1322
translate Spanish day7dlc_start2_39b49fa9:

    # GR "what is so surprising about that?"
    GR "¿qué tiene eso de sorprendente?"

# game/beyond the bet/day7dlc.rpy:1325
translate Spanish day7dlc_start2_a3d60ea1:

    # player "You do realize that humans don't even know if the Underworld exists, right?"
    player "¿Te das cuenta de que los humanos ni siquiera saben si el Inframundo existe, verdad?"

# game/beyond the bet/day7dlc.rpy:1328
translate Spanish day7dlc_start2_36984a9c:

    # player "Like that's a hot debate."
    player "O sea, es un debate candente."

# game/beyond the bet/day7dlc.rpy:1331
translate Spanish day7dlc_start2_50927c98:

    # player "You're out here acting like it's obvious, and that OF COURSE there's gods there!"
    player "¡Tú actúas como si fuera obvio, y como si POR SUPUESTO hubiera dioses allí!"

# game/beyond the bet/day7dlc.rpy:1332
translate Spanish day7dlc_start2_d3574fe7:

    # GR "it is likely something that i should not be telling you, right."
    GR "probablemente sea algo que no debería contarte, cierto."

# game/beyond the bet/day7dlc.rpy:1333
translate Spanish day7dlc_start2_144d2dfd:

    # GR "but at this point, i see little reason in keeping secrets from you."
    GR "pero a estas alturas, veo pocas razones para guardarte secretos."

# game/beyond the bet/day7dlc.rpy:1336
translate Spanish day7dlc_start2_327aba1d:

    # player "Dude."
    player "Amigo."

# game/beyond the bet/day7dlc.rpy:1339
translate Spanish day7dlc_start2_ab877705:

    # player "I'm getting all the behind the scenes info on how the world works."
    player "Me estoy enterando de todo lo que pasa tras bambalinas sobre cómo funciona el mundo."

# game/beyond the bet/day7dlc.rpy:1342
translate Spanish day7dlc_start2_99ac0f61:

    # player "That's awesome."
    player "Eso es genial."

# game/beyond the bet/day7dlc.rpy:1343
translate Spanish day7dlc_start2_5526cf88:

    # GR "enjoy it while it lasts, i suppose."
    GR "disfrútalo mientras dure, supongo."

# game/beyond the bet/day7dlc.rpy:1344
translate Spanish day7dlc_start2_3652c218:

    # GR "gods, my head hurts too much right now."
    GR "dioses, me duele demasiado la cabeza ahora mismo."

# game/beyond the bet/day7dlc.rpy:1345
translate Spanish day7dlc_start2_30a8c874:

    # GR "i'm sure i will regret this tomorrow."
    GR "seguro que me arrepentiré de esto mañana."

# game/beyond the bet/day7dlc.rpy:1349
translate Spanish day7dlc_start2_8d02576b:

    # player "Practically yes."
    player "Prácticamente sí."

# game/beyond the bet/day7dlc.rpy:1350
translate Spanish day7dlc_start2_165c7832:

    # GR "what do you MEAN practically yes?"
    GR "¿qué quieres decir con PRÁCTICAMENTE sí?"

# game/beyond the bet/day7dlc.rpy:1351
translate Spanish day7dlc_start2_589a8dd7:

    # GR "have you done the years of training?"
    GR "¿has hecho los años de formación?"

# game/beyond the bet/day7dlc.rpy:1354
translate Spanish day7dlc_start2_29113672:

    # player "No."
    player "No."

# game/beyond the bet/day7dlc.rpy:1355
translate Spanish day7dlc_start2_70db17d1:

    # GR "Then how could you be practically a doctor?"
    GR "¿Entonces cómo puedes ser prácticamente [arti_2] [doctor]?"

# game/beyond the bet/day7dlc.rpy:1358
translate Spanish day7dlc_start2_12b36876:

    # player "I just feel it in my bones."
    player "Simplemente lo siento en los huesos."

# game/beyond the bet/day7dlc.rpy:1361
translate Spanish day7dlc_start2_b30477fa:

    # player "In my soul."
    player "En mi alma."

# game/beyond the bet/day7dlc.rpy:1364
translate Spanish day7dlc_start2_2ebbd63e:

    # player "I'd make a good doctor."
    player "Sería [arti_2] [buen] [doctor]."

# game/beyond the bet/day7dlc.rpy:1365
translate Spanish day7dlc_start2_b983ff2d:

    # GR "you make a good bullshitter, if nothing else."
    GR "al menos eres [arti_2] [buen] farsante."

# game/beyond the bet/day7dlc.rpy:1368
translate Spanish day7dlc_start2_5890fae1:

    # player "Man, I really have such a good list of talents."
    player "Hombre, de verdad tengo una lista de talentos buenísima."

# game/beyond the bet/day7dlc.rpy:1371
translate Spanish day7dlc_start2_ca992ae8:

    # player "Good doctor? Check."
    player "¿[buen!c] [doctor]? Listo."

# game/beyond the bet/day7dlc.rpy:1374
translate Spanish day7dlc_start2_5ee2d0a8:

    # player "Good bullshitter? Correct."
    player "¿Talento para soltar tonterías? Correcto."

# game/beyond the bet/day7dlc.rpy:1377
translate Spanish day7dlc_start2_3f8454df:

    # player "Good looking? Absolutely."
    player "¿Buen aspecto? Absolutamente."

# game/beyond the bet/day7dlc.rpy:1378
translate Spanish day7dlc_start2_368e8a60:

    # GR "you are insufferable."
    GR "eres insufrible."

# game/beyond the bet/day7dlc.rpy:1379
translate Spanish day7dlc_start2_f864225a:

    # GR "honestly, i do not know how you have survived this long."
    GR "sinceramente, no sé cómo has sobrevivido tanto tiempo."

# game/beyond the bet/day7dlc.rpy:1380
translate Spanish day7dlc_start2_59140cda:

    # GR "well, i do. that soul of yours."
    GR "bueno, sí lo sé. esa alma tuya."

# game/beyond the bet/day7dlc.rpy:1381
translate Spanish day7dlc_start2_bf1c83ae:

    # GR "but past that, you are just..."
    GR "pero aparte de eso, eres simplemente..."

# game/beyond the bet/day7dlc.rpy:1384
translate Spanish day7dlc_start2_333e9818:

    # player "Fantastic? Amazing? Gorgeous? Smart?"
    player "¿Fantástic[letra]? ¿Increíble? ¿Guap[letra]? ¿Inteligente?"

# game/beyond the bet/day7dlc.rpy:1385
translate Spanish day7dlc_start2_5d184a65:

    # GR "absolutely absurd."
    GR "absolutamente absurd[letra]."

# game/beyond the bet/day7dlc.rpy:1388
translate Spanish day7dlc_start2_83904ada:

    # player "Absurd for you <3"
    player "Absurd[letra] por ti <3"

# game/beyond the bet/day7dlc.rpy:1389
translate Spanish day7dlc_start2_f3b32683:

    # GR "that barely makes sense."
    GR "eso apenas tiene sentido."

# game/beyond the bet/day7dlc.rpy:1392
translate Spanish day7dlc_start2_7b6da43d:

    # player "Does anything I say make sense?"
    player "¿Algo de lo que digo tiene sentido?"

# game/beyond the bet/day7dlc.rpy:1393
translate Spanish day7dlc_start2_8e7ddd90:

    # GR "true."
    GR "cierto."

# game/beyond the bet/day7dlc.rpy:1394
translate Spanish day7dlc_start2_cde11d0f:

    # GR "how i have become so ingrained with you, i do not know."
    GR "cómo he llegado a estar tan ligado a ti, no lo sé."

# game/beyond the bet/day7dlc.rpy:1397
translate Spanish day7dlc_start2_06f4b86d:

    # player "I do."
    player "Yo sí."

# game/beyond the bet/day7dlc.rpy:1400
translate Spanish day7dlc_start2_f964b5f4:

    # player "Let me lay it out for you."
    player "Te lo explico."

# game/beyond the bet/day7dlc.rpy:1401
translate Spanish day7dlc_start2_ef1719f7:

    # GR "here we go..."
    GR "aquí vamos..."

# game/beyond the bet/day7dlc.rpy:1404
translate Spanish day7dlc_start2_7a3fdeb0:

    # player "In the beginning, there was a little reaper..."
    player "Al principio, había una parquita..."

# game/beyond the bet/day7dlc.rpy:1407
translate Spanish day7dlc_start2_a09717f1:

    # player "He was so lonely, sitting by himself in his windowless home deep in the underworld..."
    player "Estaba tan solo, sentado a solas en su casa sin ventanas en lo profundo del inframundo..."

# game/beyond the bet/day7dlc.rpy:1410
translate Spanish day7dlc_start2_3ce5d840:

    # player "He wondered if this was all life was - sitting, waiting..."
    player "Se preguntaba si la vida era solo eso: sentarse y esperar..."

# game/beyond the bet/day7dlc.rpy:1413
translate Spanish day7dlc_start2_121c0868:

    # player "Until he was given a job. A very important job..."
    player "Hasta que le dieron un trabajo. Un trabajo muy importante..."

# game/beyond the bet/day7dlc.rpy:1416
translate Spanish day7dlc_start2_c4617105:

    # player "To take the soul of a very important mortal..."
    player "Tomar el alma de un mortal muy importante..."

# game/beyond the bet/day7dlc.rpy:1419
translate Spanish day7dlc_start2_201c6d4b:

    # player "He accepted, because he must, and went off to take the soul. Just another job..."
    player "Aceptó, porque debía, y se fue a tomar el alma. Un trabajo más..."

# game/beyond the bet/day7dlc.rpy:1422
translate Spanish day7dlc_start2_b5ba11b5:

    # player "Until he laid eyes on the most wonderful mortal he'd ever seen."
    player "Hasta que posó los ojos en [arti] mortal más maravillos[letra] que había visto jamás."

# game/beyond the bet/day7dlc.rpy:1426
translate Spanish day7dlc_start2_e099e0a2:

    # player "The most wonderful person, full stop..."
    player "La persona más maravillosa, punto final..."

# game/beyond the bet/day7dlc.rpy:1430
translate Spanish day7dlc_start2_349b300a:

    # player "And he instantly fell in love!"
    player "¡Y se enamoró al instante!"

# game/beyond the bet/day7dlc.rpy:1433
translate Spanish day7dlc_start2_2bce745d:

    # player "He could not keep away, and grew desperate to talk to [her]..."
    player "No podía mantenerse alejado, y se desesperó por hablarle..."

# game/beyond the bet/day7dlc.rpy:1436
translate Spanish day7dlc_start2_f39c78b0:

    # player "And so, created an app where he could do just that..."
    player "Y así, creó una aplicación donde podría hacer justamente eso..."

# game/beyond the bet/day7dlc.rpy:1439
translate Spanish day7dlc_start2_48ff8ae1:

    # player "It was already over for him. He'd never be able to go back to that darkness."
    player "Ya estaba perdido. Nunca podría volver a esa oscuridad."

# game/beyond the bet/day7dlc.rpy:1442
translate Spanish day7dlc_start2_ab57e3c2:

    # player "He craved the sunlight much too badly."
    player "Anhelaba demasiado la luz del sol."

# game/beyond the bet/day7dlc.rpy:1445
translate Spanish day7dlc_start2_5d08af12:

    # player "The end!"
    player "¡Fin!"

# game/beyond the bet/day7dlc.rpy:1446
translate Spanish day7dlc_start2_95151b2c_2:

    # GR "....."
    GR "....."

# game/beyond the bet/day7dlc.rpy:1447
translate Spanish day7dlc_start2_dc1b78ad:

    # GR "............."
    GR "............."

# game/beyond the bet/day7dlc.rpy:1448
translate Spanish day7dlc_start2_1d1feefe:

    # GR "what... what nonsense are you spouting........"
    GR "qué... qué disparates estás diciendo........"

# game/beyond the bet/day7dlc.rpy:1451
translate Spanish day7dlc_start2_a853723e:

    # player "It's your story! What do you think?"
    player "¡Es tu historia! ¿Qué te parece?"

# game/beyond the bet/day7dlc.rpy:1454
translate Spanish day7dlc_start2_5e3325d8:

    # player "I took some creative liberties, but I kinda like it."
    player "Me tomé algunas libertades creativas, pero me gusta bastante."

# game/beyond the bet/day7dlc.rpy:1459
translate Spanish day7dlc_start2_3ca0b133:

    # player "I might clean this up and make a book out of it."
    player "Quizá la pula un poco y haga un libro con ella."

# game/beyond the bet/day7dlc.rpy:1462
translate Spanish day7dlc_start2_2cdeb88d:

    # player "What do you think?"
    player "¿Qué piensas?"

# game/beyond the bet/day7dlc.rpy:1463
translate Spanish day7dlc_start2_20e41447:

    # GR "i... i..."
    GR "yo... yo..."

# game/beyond the bet/day7dlc.rpy:1464
translate Spanish day7dlc_start2_cb3411ad:

    # GR "you... can do whatever you want..."
    GR "tú... puedes hacer lo que quieras..."

# game/beyond the bet/day7dlc.rpy:1465
translate Spanish day7dlc_start2_9b64f628:

    # GR "that is obviously not about me."
    GR "eso obviamente no trata de mí."

# game/beyond the bet/day7dlc.rpy:1466
translate Spanish day7dlc_start2_7667d68b:

    # GR "nope. not at all."
    GR "no. para nada."

# game/beyond the bet/day7dlc.rpy:1467
translate Spanish day7dlc_start2_58a0e839:

    # GR "i am perfectly content in the shadows."
    GR "estoy perfectamente a gusto en las sombras."

# game/beyond the bet/day7dlc.rpy:1470
translate Spanish day7dlc_start2_56f07859:

    # player "Uh huh. That's why you were here last night."
    player "Ajá. Por eso estuviste aquí anoche."

# game/beyond the bet/day7dlc.rpy:1471
translate Spanish day7dlc_start2_7772a27d_15:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:1475
translate Spanish day7dlc_start2_b60f8987:

    # player "Should I quit my day job and become an author?"
    player "¿Debería dejar mi trabajo y dedicarme a escribir libros?"

# game/beyond the bet/day7dlc.rpy:1476
translate Spanish day7dlc_start2_1e8fc5e4:

    # GR "no one can know i exist."
    GR "nadie puede saber que existo."

# game/beyond the bet/day7dlc.rpy:1479
translate Spanish day7dlc_start2_4549351d:

    # player "Okay, but like..."
    player "Okey, pero o sea..."

# game/beyond the bet/day7dlc.rpy:1482
translate Spanish day7dlc_start2_da2d4dfa:

    # player "I think 100 percent of people would take it as a work of fiction."
    player "Creo que el 100 por ciento de la gente lo tomaría como una obra de ficción."

# game/beyond the bet/day7dlc.rpy:1483
translate Spanish day7dlc_start2_4a30a3ac:

    # GR "then... do as you wish..."
    GR "entonces... haz lo que quieras..."

# game/beyond the bet/day7dlc.rpy:1484
translate Spanish day7dlc_start2_8e632624:

    # GR "it is obviously not about me anyway. not at all. must be someone else."
    GR "obviamente no trata de mí de todos modos. para nada. debe ser alguien más."

# game/beyond the bet/day7dlc.rpy:1489
translate Spanish day7dlc_start2_d50c0e5d:

    # player "Hey, answer this, okay?"
    player "Oye, contesta, ¿okey?"

# game/beyond the bet/day7dlc.rpy:1525
translate Spanish call1_day7dlc_b8d5f407:

    # GRC "...!"
    GRC "...!"

# game/beyond the bet/day7dlc.rpy:1529
translate Spanish call1_day7dlc_19e41f2b:

    # GRC "I... I didn't mean to hit accept!"
    GRC "¡Yo... no quise darle a aceptar!"

# game/beyond the bet/day7dlc.rpy:1542
translate Spanish call1_day7dlc_1f67efa5:

    # GRC "I meant to say no!"
    GRC "¡Quería decir que no!"

# game/beyond the bet/day7dlc.rpy:1558
translate Spanish call1_day7dlc_8b295c59:

    # GRC "How embarrassing..."
    GRC "Qué vergonzoso..."

# game/beyond the bet/day7dlc.rpy:1559
translate Spanish call1_day7dlc_fc732244:

    # GRC "I did not wish for you to see me in this... state."
    GRC "No deseaba que me vieras en este... estado."

# game/beyond the bet/day7dlc.rpy:1568
translate Spanish call1_day7dlc_012c6c74:

    # GRC "I... am fully capable of looking after myself."
    GRC "Soy... perfectamente capaz de cuidarme solo."

# game/beyond the bet/day7dlc.rpy:1576
translate Spanish call1_day7dlc_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day7dlc.rpy:1578
translate Spanish call1_day7dlc_f1c201d3:

    # GRC "I'll... keep it in mind."
    GRC "Lo... tendré en cuenta."

# game/beyond the bet/day7dlc.rpy:1588
translate Spanish call1_day7dlc_b08ff786:

    # GRC "But I'm hoping this is something I will only have to experience once."
    GRC "Pero espero que esto sea algo que solo tenga que experimentar una vez."

# game/beyond the bet/day7dlc.rpy:1593
translate Spanish call1_day7dlc_3bd8180b:

    # GRC "Once is plenty enough. Too much, even."
    GRC "Una vez es más que suficiente. Demasiado, incluso."

# game/beyond the bet/day7dlc.rpy:1597
translate Spanish call1_day7dlc_be126454:

    # GRC "It is... disgusting. It feels invasive. I do not know how you humans can just live with such a thing."
    GRC "Es... asqueroso. Se siente invasivo. No sé cómo los humanos pueden simplemente vivir con algo así."

# game/beyond the bet/day7dlc.rpy:1601
translate Spanish call1_day7dlc_22a6d63e:

    # GRC "You should all hurry up and eradicate your illnesses."
    GRC "Todos ustedes deberían apresurarse y erradicar sus enfermedades."

# game/beyond the bet/day7dlc.rpy:1606
translate Spanish call1_day7dlc_bfb457de:

    # GRC "And in the meantime, I will overcome these foul germs. Soon they will know who is truly in charge."
    GRC "Y mientras tanto, yo superaré estos asquerosos gérmenes. Pronto sabrán quién manda de verdad."

# game/beyond the bet/day7dlc.rpy:1611
translate Spanish call1_day7dlc_7176be62:

    # GRC "That much is obvious."
    GRC "Eso es obvio."

# game/beyond the bet/day7dlc.rpy:1621
translate Spanish call1_day7dlc_6510a655:

    # GRC "Why? I want to speak with you. "
    GRC "¿Por qué? Quiero hablar contigo."

# game/beyond the bet/day7dlc.rpy:1622
translate Spanish call1_day7dlc_cfdaebdf:

    # GRC "And I'm fine here, I won't let something so... so..."
    GRC "Y estoy bien aquí, no dejaré que algo tan... tan..."

# game/beyond the bet/day7dlc.rpy:1627
translate Spanish call1_day7dlc_2e7ca9b0:

    # GRC "Aggravating."
    GRC "Irritante."

# game/beyond the bet/day7dlc.rpy:1628
translate Spanish call1_day7dlc_37747c20:

    # GRC "Minuscule."
    GRC "Minúsculo."

# game/beyond the bet/day7dlc.rpy:1629
translate Spanish call1_day7dlc_21b91a12:

    # GRC "Inferior."
    GRC "Inferior."

# game/beyond the bet/day7dlc.rpy:1631
translate Spanish call1_day7dlc_de88ccb2:

    # GRC "Look. I will not be defeated by this, that's all I'm saying."
    GRC "Mira. No me derrotará esto, eso es todo lo que digo."

# game/beyond the bet/day7dlc.rpy:1634
translate Spanish call1_day7dlc_dffe097d:

    # GRC "Why'd you call me so suddenly, anyway...?"
    GRC "¿Por qué me llamaste tan de repente, por cierto...?"

# game/beyond the bet/day7dlc.rpy:1642
translate Spanish call1_day7dlc_b6fb7637:

    # GRC "...I was not prepared."
    GRC "...No estaba preparado."

# game/beyond the bet/day7dlc.rpy:1643
translate Spanish call1_day7dlc_4cf76b5f:

    # GRC "I need to lock down that feature."
    GRC "Necesito bloquear esa función."

# game/beyond the bet/day7dlc.rpy:1657
translate Spanish call1_day7dlc_f236c71f:

    # GRC "If I left it on you'd call every two seconds."
    GRC "Si la dejara activada, llamarías cada dos segundos."

# game/beyond the bet/day7dlc.rpy:1659
translate Spanish call1_day7dlc_0a23aed4:

    # GRC "An abuse of power, some may say."
    GRC "Un abuso de poder, dirían algunos."

# game/beyond the bet/day7dlc.rpy:1673
translate Spanish call1_day7dlc_2fa19145:

    # GRC "Don't let it get to your head."
    GRC "No dejes que se te suba a la cabeza."

# game/beyond the bet/day7dlc.rpy:1674
translate Spanish call1_day7dlc_9aaa63e4:

    # GRC "Maybe I've been going easy on you. Maybe I have become too soft."
    GRC "Quizá he sido blando contigo. Quizá me he vuelto demasiado blando."

# game/beyond the bet/day7dlc.rpy:1680
translate Spanish call1_day7dlc_7c2e82c9:

    # GRC "Unlikely."
    GRC "Poco probable."

# game/beyond the bet/day7dlc.rpy:1682
translate Spanish call1_day7dlc_65948d90:

    # GRC "You flatter yourself too much."
    GRC "Te halagas demasiado."

# game/beyond the bet/day7dlc.rpy:1692
translate Spanish call1_day7dlc_4b407e25:

    # GRC "Exactly my point."
    GRC "Exactamente mi punto."

# game/beyond the bet/day7dlc.rpy:1694
translate Spanish call1_day7dlc_ac40003e:

    # GRC "We both have duties to fulfill, aside from each other."
    GRC "Ambos tenemos deberes que cumplir, aparte del uno con el otro."

# game/beyond the bet/day7dlc.rpy:1696
translate Spanish call1_day7dlc_d734f38d:

    # GRC "Though I know you'd rather spend all of your time gazing into my eyes."
    GRC "Aunque sé que preferirías pasar todo tu tiempo mirándome a los ojos."

# game/beyond the bet/day7dlc.rpy:1698
translate Spanish call1_day7dlc_e0cb5c8d:

    # GRC "As nice as that would be, we... cannot."
    GRC "Por agradable que fuera, no... podemos."

# game/beyond the bet/day7dlc.rpy:1706
translate Spanish call1_day7dlc_de87c303:

    # GRC "Are you not afraid that if you stared too long, you would get lost in me?"
    GRC "¿No temes que si me miraras demasiado tiempo, te perderías en mí?"

# game/beyond the bet/day7dlc.rpy:1719
translate Spanish call1_day7dlc_8e4a7aba:

    # GRC "Oh? And how do I look at you, Sunshine?"
    GRC "¿Ah, sí? ¿Y cómo te miro, Solecito?"

# game/beyond the bet/day7dlc.rpy:1737
translate Spanish call1_day7dlc_7e543412:

    # GRC "...Right."
    GRC "...Cierto."

# game/beyond the bet/day7dlc.rpy:1738
translate Spanish call1_day7dlc_99109eaf:

    # GRC "Ahem... I see... uh huh..."
    GRC "Ejem... ya veo... ajá..."

# game/beyond the bet/day7dlc.rpy:1743
translate Spanish call1_day7dlc_29a9515e:

    # GRC "Oh, to be able to lie."
    GRC "Ah, poder mentir."

# game/beyond the bet/day7dlc.rpy:1747
translate Spanish call1_day7dlc_56e506ba:

    # GRC "That is what makes humans so scary."
    GRC "Eso es lo que hace a los humanos tan aterradores."

# game/beyond the bet/day7dlc.rpy:1749
translate Spanish call1_day7dlc_1af5c47e:

    # GRC "They cannot help but lie."
    GRC "No pueden evitar mentir."

# game/beyond the bet/day7dlc.rpy:1750
translate Spanish call1_day7dlc_0b7209a1:

    # GRC "Small lies, big lies, white lies..."
    GRC "Pequeñas mentiras, grandes mentiras, mentiras piadosas..."

# game/beyond the bet/day7dlc.rpy:1755
translate Spanish call1_day7dlc_7ba8a353:

    # GRC "...Sometimes."
    GRC "...A veces."

# game/beyond the bet/day7dlc.rpy:1757
translate Spanish call1_day7dlc_73080a1e:

    # GRC "Though I fear the effect you have on me more than anything else."
    GRC "Aunque temo el efecto que tienes en mí más que cualquier otra cosa."

# game/beyond the bet/day7dlc.rpy:1761
translate Spanish call1_day7dlc_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day7dlc.rpy:1766
translate Spanish call1_day7dlc_34d7b703:

    # GRC "How am I predictable?"
    GRC "¿En qué soy predecible?"

# game/beyond the bet/day7dlc.rpy:1776
translate Spanish call1_day7dlc_05761f49:

    # GRC "Can you now?"
    GRC "¿Ah, ahora sí puedes?"

# game/beyond the bet/day7dlc.rpy:1791
translate Spanish call1_day7dlc_8da23161:

    # GRC "...."
    GRC "...."

# game/beyond the bet/day7dlc.rpy:1806
translate Spanish call1_day7dlc_f90bbcfc:

    # GRC "That is not occasionally!"
    GRC "¡Eso no es de vez en cuando!"

# game/beyond the bet/day7dlc.rpy:1807
translate Spanish call1_day7dlc_9f2ab0b4:

    # GRC "That is constantly!"
    GRC "¡Eso es todo el tiempo!"

# game/beyond the bet/day7dlc.rpy:1812
translate Spanish call1_day7dlc_c337e5bd:

    # GRC "I... I..."
    GRC "Yo... yo..."

# game/beyond the bet/day7dlc.rpy:1819
translate Spanish call1_day7dlc_0d6af3b9:

    # GRC "A... reasonable answer."
    GRC "Una... respuesta razonable."

# game/beyond the bet/day7dlc.rpy:1820
translate Spanish call1_day7dlc_73dd6dd1:

    # GRC "I'm actually a little surprised."
    GRC "De hecho estoy un poco sorprendido."

# game/beyond the bet/day7dlc.rpy:1828
translate Spanish call1_day7dlc_ec00e7e9:

    # GRC "You are the biggest troublemaker I've ever had the displeasure of meeting..."
    GRC "Eres la persona más problemática que he tenido el disgusto de conocer..."

# game/beyond the bet/day7dlc.rpy:1833
translate Spanish call1_day7dlc_0e74ec89:

    # GRC "...Oh."
    GRC "...Oh."

# game/beyond the bet/day7dlc.rpy:1841
translate Spanish call1_day7dlc_3f3299aa:

    # GRC "You seem to think I have a lot of free time."
    GRC "Pareces pensar que tengo mucho tiempo libre."

# game/beyond the bet/day7dlc.rpy:1846
translate Spanish call1_day7dlc_2fa53e08:

    # GRC "Yes, and I'll have to make up for it later..."
    GRC "Sí, y tendré que compensarlo más tarde..."

# game/beyond the bet/day7dlc.rpy:1866
translate Spanish call1_day7dlc_bf9e76ce:

    # GRC "He is always handsome."
    GRC "Él siempre es apuesto."

# game/beyond the bet/day7dlc.rpy:1868
translate Spanish call1_day7dlc_be86196e:

    # GRC "It is good you are finally showing him the respect he deserves."
    GRC "Es bueno que por fin le muestres el respeto que merece."

# game/beyond the bet/day7dlc.rpy:1872
translate Spanish call1_day7dlc_f4899e57:

    # GRC "Cute? Yes, I suppose he is."
    GRC "¿Lindo? Sí, supongo que lo es."

# game/beyond the bet/day7dlc.rpy:1874
translate Spanish call1_day7dlc_998ee3fd:

    # GRC "Cute, handsome, immaculate... all of the above."
    GRC "Lindo, apuesto, inmaculado... todo lo anterior."

# game/beyond the bet/day7dlc.rpy:1878
translate Spanish call1_day7dlc_31823f81:

    # GRC "We are keeping each other company while I recover."
    GRC "Nos hacemos compañía mientras me recupero."

# game/beyond the bet/day7dlc.rpy:1887
translate Spanish call1_day7dlc_373fed2a:

    # GRC "I do not wish to restrict him too often."
    GRC "No deseo restringirlo con demasiada frecuencia."

# game/beyond the bet/day7dlc.rpy:1895
translate Spanish call1_day7dlc_50fa453b:

    # GRC "He is simply offering me... comfort in these dire times."
    GRC "Simplemente me ofrece... consuelo en estos tiempos aciagos."

# game/beyond the bet/day7dlc.rpy:1903
translate Spanish call1_day7dlc_4408c21a:

    # GRC "This is the most harrowing moment of my life."
    GRC "Este es el momento más desgarrador de mi vida."

# game/beyond the bet/day7dlc.rpy:1905
translate Spanish call1_day7dlc_bd689f7f:

    # GRC "But through it all, Azrael has been by my side. Through all of my highs and lows."
    GRC "Pero a través de todo, Azrael ha estado a mi lado. En todos mis altibajos."

# game/beyond the bet/day7dlc.rpy:1910
translate Spanish call1_day7dlc_f96933d0:

    # GRC "A long time."
    GRC "Mucho tiempo."

# game/beyond the bet/day7dlc.rpy:1915
translate Spanish call1_day7dlc_22b55913:

    # GRC "...I can't remember exactly. It's... difficult."
    GRC "...No recuerdo exactamente. Es... difícil."

# game/beyond the bet/day7dlc.rpy:1923
translate Spanish call1_day7dlc_fc939dfa:

    # GRC "Time seems to blend together until its meaning is lost, the more of it I have."
    GRC "El tiempo parece mezclarse hasta perder su significado, mientras más tengo."

# game/beyond the bet/day7dlc.rpy:1925
translate Spanish call1_day7dlc_02c1e5ce:

    # GRC "But many, many years."
    GRC "Pero muchos, muchos años."

# game/beyond the bet/day7dlc.rpy:1938
translate Spanish call1_day7dlc_e3581993:

    # GRC "Of course he is. I help him maintain his appearance."
    GRC "Por supuesto que sí. Yo le ayudo a mantener su apariencia."

# game/beyond the bet/day7dlc.rpy:1950
translate Spanish call1_day7dlc_008afe10_2:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day7dlc.rpy:1951
translate Spanish call1_day7dlc_81603f2c:

    # GRC "He is important to me."
    GRC "Es importante para mí."

# game/beyond the bet/day7dlc.rpy:1961
translate Spanish call1_day7dlc_8835fb1e:

    # GRC "Hm... I suppose so."
    GRC "Hm... supongo que sí."

# game/beyond the bet/day7dlc.rpy:1965
translate Spanish call1_day7dlc_77359255:

    # GRC "No and no."
    GRC "No y no."

# game/beyond the bet/day7dlc.rpy:1967
translate Spanish call1_day7dlc_f745814c:

    # GRC "He is a former resident of the mortal plane."
    GRC "Es un antiguo residente del plano mortal."

# game/beyond the bet/day7dlc.rpy:1977
translate Spanish call1_day7dlc_73c405fd:

    # GRC "Indeed, I did."
    GRC "En efecto, lo hice."

# game/beyond the bet/day7dlc.rpy:1993
translate Spanish call1_day7dlc_6c4d5337:

    # GRC "I didn't buy him."
    GRC "No lo compré."

# game/beyond the bet/day7dlc.rpy:1998
translate Spanish call1_day7dlc_12ae95c5:

    # GRC "No. I am not some seasoned thief."
    GRC "No. No soy ningún ladrón experimentado."

# game/beyond the bet/day7dlc.rpy:2006
translate Spanish call1_day7dlc_df58a1b8:

    # GRC "He was... gifted to me."
    GRC "Me lo... regalaron."

# game/beyond the bet/day7dlc.rpy:2007
translate Spanish call1_day7dlc_6e7f9810:

    # GRC "And I promised I would always care for him."
    GRC "Y prometí que siempre lo cuidaría."

# game/beyond the bet/day7dlc.rpy:2019
translate Spanish call1_day7dlc_9f6433fa:

    # GRC "It was a mortal child."
    GRC "Fue un niño mortal."

# game/beyond the bet/day7dlc.rpy:2023
translate Spanish call1_day7dlc_a1270393:

    # GRC "Yes, he did."
    GRC "Sí, lo hizo."

# game/beyond the bet/day7dlc.rpy:2025
translate Spanish call1_day7dlc_f3f87b52:

    # GRC "The story is... not a happy one."
    GRC "La historia... no es feliz."

# game/beyond the bet/day7dlc.rpy:2027
translate Spanish call1_day7dlc_99969ccf:

    # GRC "I... don't mind sharing it with you, if you understand that."
    GRC "Yo... no tengo problema en compartirla contigo, si entiendes lo que quiero decir."

# game/beyond the bet/day7dlc.rpy:2031
translate Spanish call1_day7dlc_f26f1e6a:

    # GRC "That child was... he was assigned to me. I've been assigned children many times before, so it wasn't anything out of the ordinary."
    GRC "Ese niño era... me fue asignado. Antes me han asignado niños muchas veces, así que no tenía nada de extraordinario."

# game/beyond the bet/day7dlc.rpy:2033
translate Spanish call1_day7dlc_c6a47818:

    # GRC "He was... quite young and was hospitalised when I went to ferry him over."
    GRC "Era... muy pequeño y estaba hospitalizado cuando fui a llevármelo."

# game/beyond the bet/day7dlc.rpy:2035
translate Spanish call1_day7dlc_2f75b940:

    # GRC "It is my preference to take young mortals in their sleep, so they don't have to... feel scared by my presence."
    GRC "Prefiero llevarme a los mortales jóvenes mientras duermen, para que no tengan que... sentir miedo ante mi presencia."

# game/beyond the bet/day7dlc.rpy:2036
translate Spanish call1_day7dlc_607a4529:

    # GRC "If they go in peace then the journey is easier on their soul."
    GRC "Si se van en paz, el viaje es más llevadero para su alma."

# game/beyond the bet/day7dlc.rpy:2038
translate Spanish call1_day7dlc_2da1f1b8:

    # GRC "But he was... awake."
    GRC "Pero él estaba... despierto."

# game/beyond the bet/day7dlc.rpy:2040
translate Spanish call1_day7dlc_fbe9917f:

    # GRC "I was cloaked in glamor, so it shouldn't have mattered, but..."
    GRC "Yo estaba cubierto por un hechizo de ilusión, así que no debería haber importado, pero..."

# game/beyond the bet/day7dlc.rpy:2042
translate Spanish call1_day7dlc_cef54f76:

    # GRC "He saw right through it, and he just smiled really softly and told me 'he had been waiting'."
    GRC "Vio a través de él sin problema, y simplemente sonrió con mucha suavidad y me dijo que 'había estado esperando'."

# game/beyond the bet/day7dlc.rpy:2048
translate Spanish call1_day7dlc_954da09e:

    # GRC "That is what he claimed at the time."
    GRC "Eso fue lo que afirmó en ese momento."

# game/beyond the bet/day7dlc.rpy:2049
translate Spanish call1_day7dlc_f0e3d17a:

    # GRC "I did not question it."
    GRC "No lo cuestioné."

# game/beyond the bet/day7dlc.rpy:2052
translate Spanish call1_day7dlc_82fa6e1f:

    # GRC "He was not scared."
    GRC "No tenía miedo."

# game/beyond the bet/day7dlc.rpy:2053
translate Spanish call1_day7dlc_fc344fa3:

    # GRC "His soul was... incredibly strong, and he was incredibly brave, but... his body was weak. It could not hold such a soul."
    GRC "Su alma era... increíblemente fuerte, y él era increíblemente valiente, pero... su cuerpo era débil. No podía contener un alma así."

# game/beyond the bet/day7dlc.rpy:2054
translate Spanish call1_day7dlc_a24ed7ab:

    # GRC "He handed me Azrael and made me promise to look after him."
    GRC "Me entregó a Azrael y me hizo prometer que lo cuidaría."

# game/beyond the bet/day7dlc.rpy:2058
translate Spanish call1_day7dlc_41f43436:

    # GRC "Of course I did."
    GRC "Por supuesto que sí."

# game/beyond the bet/day7dlc.rpy:2061
translate Spanish call1_day7dlc_7385a9bd:

    # GRC "It was my honor."
    GRC "Fue un honor para mí."

# game/beyond the bet/day7dlc.rpy:2063
translate Spanish call1_day7dlc_54c5f829:

    # GRC "Part of my duty is to show mortals to their best afterlife."
    GRC "Parte de mi deber es mostrarles a los mortales su mejor más allá."

# game/beyond the bet/day7dlc.rpy:2065
translate Spanish call1_day7dlc_8a620127:

    # GRC "And if that was the final tie keeping him bound to your plane, well..."
    GRC "Y si ese era el último lazo que lo mantenía atado a tu plano, pues..."

# game/beyond the bet/day7dlc.rpy:2066
translate Spanish call1_day7dlc_4a53c02b:

    # GRC "I was happy enough to ease that from his worries and ensure the safest possible passage for him."
    GRC "Me alegró aliviarlo de esa preocupación y asegurarle el paso más seguro posible."

# game/beyond the bet/day7dlc.rpy:2071
translate Spanish call1_day7dlc_69406ed6:

    # GRC "I... took him to a bright and colorful afterlife."
    GRC "Yo... lo llevé a un más allá luminoso y lleno de color."

# game/beyond the bet/day7dlc.rpy:2073
translate Spanish call1_day7dlc_bbf250a2:

    # GRC "He went peacefully, and even thanked me before I led him on his way."
    GRC "Se fue en paz, e incluso me dio las gracias antes de que lo guiara por su camino."

# game/beyond the bet/day7dlc.rpy:2074
translate Spanish call1_day7dlc_fac690c0:

    # GRC "It was a long time ago now, but he has... stuck with me."
    GRC "Ya pasó mucho tiempo, pero se ha... quedado conmigo."

# game/beyond the bet/day7dlc.rpy:2076
translate Spanish call1_day7dlc_ceca02d4:

    # GRC "It must be this illness, it's making me... sentimental."
    GRC "Debe de ser esta enfermedad, que me está volviendo... sentimental."

# game/beyond the bet/day7dlc.rpy:2084
translate Spanish call1_day7dlc_da5b3021:

    # GRC "Azrael? Yes, I do treasure him."
    GRC "¿Azrael? Sí, lo aprecio mucho."

# game/beyond the bet/day7dlc.rpy:2092
translate Spanish call1_day7dlc_008afe10_3:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day7dlc.rpy:2096
translate Spanish call1_day7dlc_ccbed814:

    # GRC "...Thanks, Sunshine."
    GRC "...Gracias, Solecito."

# game/beyond the bet/day7dlc.rpy:2100
translate Spanish call1_day7dlc_5c8696d9:

    # GRC "Then I will leave it at that."
    GRC "Entonces lo dejaré ahí."

# game/beyond the bet/day7dlc.rpy:2109
translate Spanish call1_day7dlc_887f8dba:

    # GRC "He was already named by his previous owner."
    GRC "Ya tenía nombre, puesto por su dueño anterior."

# game/beyond the bet/day7dlc.rpy:2111
translate Spanish call1_day7dlc_0774ad62:

    # GRC "A fine name, for a fine reaper of souls."
    GRC "Un nombre digno de un gran cosechador de almas."

# game/beyond the bet/day7dlc.rpy:2116
translate Spanish call1_day7dlc_35982120:

    # GRC "I wouldn't dare to rename him."
    GRC "No me atrevería a cambiárselo."

# game/beyond the bet/day7dlc.rpy:2117
translate Spanish call1_day7dlc_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/beyond the bet/day7dlc.rpy:2119
translate Spanish call1_day7dlc_5113bec0:

    # GRC "Uh... stitched it..."
    GRC "Eh... lo cosí..."

# game/beyond the bet/day7dlc.rpy:2130
translate Spanish call1_day7dlc_1ede1cee:

    # GRC "I... hand stitched his name on him, okay!"
    GRC "Yo... ¡le cosí su nombre a mano, okey!"

# game/beyond the bet/day7dlc.rpy:2131
translate Spanish call1_day7dlc_a16fcbc4:

    # GRC "So I would... never forget. My life is a long one. Forgetting is... too easy."
    GRC "Para... no olvidarlo nunca. Mi vida es larga. Olvidar es... demasiado fácil."

# game/beyond the bet/day7dlc.rpy:2138
translate Spanish call1_day7dlc_1751d555:

    # GRC "Not possible."
    GRC "No es posible."

# game/beyond the bet/day7dlc.rpy:2148
translate Spanish call1_day7dlc_8939cbf0:

    # GRC "If anything in life is true, it is that."
    GRC "Si algo en la vida es cierto, es eso."

# game/beyond the bet/day7dlc.rpy:2155
translate Spanish call1_day7dlc_56c266cd:

    # GRC "Don't... don't call me that..."
    GRC "No... no me llames así..."

# game/beyond the bet/day7dlc.rpy:2157
translate Spanish call1_day7dlc_4e5c9a27:

    # GRC "Just... repeat after me, okay?"
    GRC "Solo... repite después de mí, ¿okey?"

# game/beyond the bet/day7dlc.rpy:2158
translate Spanish call1_day7dlc_7f2c5439:

    # GRC "Handsome, stunning—"
    GRC "Apuesto, deslumbrante—"

# game/beyond the bet/day7dlc.rpy:2163
translate Spanish call1_day7dlc_61a6ac5c:

    # GRC "Well, you get the idea."
    GRC "Bueno, ya captas la idea."

# game/beyond the bet/day7dlc.rpy:2167
translate Spanish call1_day7dlc_49da7a1b:

    # GRC "Your name? Why would I do that?"
    GRC "¿Tu nombre? ¿Por qué haría eso?"

# game/beyond the bet/day7dlc.rpy:2168
translate Spanish call1_day7dlc_ff4d8584:

    # GRC "Azrael doesn't need your name bound into his very being."
    GRC "Azrael no necesita que tu nombre esté ligado a su mismísimo ser."

# game/beyond the bet/day7dlc.rpy:2178
translate Spanish call1_day7dlc_a5255545:

    # GRC "It does. You are a little creep, Sunshine."
    GRC "Sí que suena así. Eres un bicho raro, Solecito."

# game/beyond the bet/day7dlc.rpy:2185
translate Spanish call1_day7dlc_739463e6:

    # GRC "I... hardly need a reminder."
    GRC "Yo... difícilmente necesito un recordatorio."

# game/beyond the bet/day7dlc.rpy:2187
translate Spanish call1_day7dlc_6d36a9d6:

    # GRC "You are already on my mind too much. "
    GRC "Ya ocupas demasiado mi mente."

# game/beyond the bet/day7dlc.rpy:2188
translate Spanish call1_day7dlc_55461f30:

    # GRC "It is excruciating."
    GRC "Es insoportable."

# game/beyond the bet/day7dlc.rpy:2194
translate Spanish call1_day7dlc_16ed4ab3:

    # GRC "...No. Azrael is resting, just as I am."
    GRC "...No. Azrael está descansando, igual que yo."

# game/beyond the bet/day7dlc.rpy:2195
translate Spanish call1_day7dlc_f551f630:

    # GRC "If you must know, I stitched it in red."
    GRC "Si tanto quieres saberlo, lo cosí en rojo."

# game/beyond the bet/day7dlc.rpy:2203
translate Spanish call1_day7dlc_5da75e6c:

    # GRC "It is not knitting, mortal."
    GRC "No es tejer, mortal."

# game/beyond the bet/day7dlc.rpy:2204
translate Spanish call1_day7dlc_d488826e:

    # GRC "Sewing, and it was only one word."
    GRC "Es coser, y fue solo una palabra."

# game/beyond the bet/day7dlc.rpy:2209
translate Spanish call1_day7dlc_89cdc31f:

    # GRC "I have never tried, nor am I particularly interested in the idea of it."
    GRC "Nunca lo he intentado, ni me interesa particularmente la idea."

# game/beyond the bet/day7dlc.rpy:2213
translate Spanish call1_day7dlc_bdbc8410:

    # GRC "...You want a blanket?"
    GRC "...¿Quieres una manta?"

# game/beyond the bet/day7dlc.rpy:2220
translate Spanish call1_day7dlc_008afe10_4:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day7dlc.rpy:2222
translate Spanish call1_day7dlc_17bd6e29:

    # GRC "I... the future could hold any number of possibilities."
    GRC "Yo... el futuro podría traer cualquier cantidad de posibilidades."

# game/beyond the bet/day7dlc.rpy:2238
translate Spanish call1_day7dlc_acc7ce2e:

    # GRC "Yes, Sunshine?"
    GRC "¿Sí, Solecito?"

# game/beyond the bet/day7dlc.rpy:2276
translate Spanish call1_day7dlc_43db6ec9:

    # GRC "...Shut up. Gods, you're the worst."
    GRC "...Cállate. Dioses, eres lo peor."

# game/beyond the bet/day7dlc.rpy:2283
translate Spanish call1_day7dlc_008afe10_5:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day7dlc.rpy:2291
translate Spanish call1_day7dlc_1033f903:

    # GRC "They're... just hair clips."
    GRC "Son... solo pinzas para el cabello."

# game/beyond the bet/day7dlc.rpy:2292
translate Spanish call1_day7dlc_c9e6c4c5:

    # GRC "I was hot and wanted the hair off of my face."
    GRC "Tenía calor y quería quitarme el cabello de la cara."

# game/beyond the bet/day7dlc.rpy:2303
translate Spanish call1_day7dlc_09dc4b7f:

    # GRC "You would allow death to claim you over... hair clips?"
    GRC "¿Dejarías que la muerte te reclamara por... unas pinzas para el cabello?"

# game/beyond the bet/day7dlc.rpy:2305
translate Spanish call1_day7dlc_52783d34:

    # GRC "Everything I've tried, you found lacking, but... hair clips..."
    GRC "Todo lo que he probado, lo has encontrado insuficiente, pero... ¿pinzas para el cabello...?"

# game/beyond the bet/day7dlc.rpy:2320
translate Spanish call1_day7dlc_80ae23c2:

    # GRC "From time to time."
    GRC "De vez en cuando."

# game/beyond the bet/day7dlc.rpy:2325
translate Spanish call1_day7dlc_c5a756b7:

    # GRC "Gods, you are insistent."
    GRC "Dioses, eres insistente."

# game/beyond the bet/day7dlc.rpy:2330
translate Spanish call1_day7dlc_00b18a05:

    # GRC "I had no energy to begin with, and now I feel like you have sucked out any that is remaining..."
    GRC "Para empezar no tenía energía, y ahora siento que me has succionado la poca que quedaba..."

# game/beyond the bet/day7dlc.rpy:2331
translate Spanish call1_day7dlc_47cad6dc:

    # GRC "Fine. Yes, I clip it back when I wash my face and do my skincare."
    GRC "Bien. Sí, me lo sujeto hacia atrás cuando me lavo la cara y hago mi rutina de cuidado de la piel."

# game/beyond the bet/day7dlc.rpy:2333
translate Spanish call1_day7dlc_f9d84eaf:

    # GRC "Is that not a normal use of clips?"
    GRC "¿No es un uso normal de las pinzas?"

# game/beyond the bet/day7dlc.rpy:2341
translate Spanish call1_day7dlc_e648f0f1:

    # GRC "Common... no."
    GRC "¿Común?... no."

# game/beyond the bet/day7dlc.rpy:2342
translate Spanish call1_day7dlc_6aa25b72:

    # GRC "I... once knew a fellow reaper who was quite into all of this stuff. Perhaps it rubbed off on me."
    GRC "Yo... una vez conocí a otra parca muy aficionada a todo esto. Quizá se me pegó."

# game/beyond the bet/day7dlc.rpy:2346
translate Spanish call1_day7dlc_3030d164:

    # GRC "Skincare, hair accessories, those kinds of things."
    GRC "Cuidado de la piel, accesorios para el cabello, ese tipo de cosas."

# game/beyond the bet/day7dlc.rpy:2349
translate Spanish call1_day7dlc_deb108f7:

    # GRC "In regards to whether I tie my hair up... yes, every now and then."
    GRC "En cuanto a si me recojo el cabello... sí, de vez en cuando."

# game/beyond the bet/day7dlc.rpy:2350
translate Spanish call1_day7dlc_bfea7876:

    # GRC "Perhaps you haven't noticed, but I have an abundance of hair."
    GRC "Quizá no lo hayas notado, pero tengo muchísimo cabello."

# game/beyond the bet/day7dlc.rpy:2354
translate Spanish call1_day7dlc_f787f27d:

    # GRC "Ah... who... who says I would agree?"
    GRC "Ah... ¿quién... quién dice que aceptaría?"

# game/beyond the bet/day7dlc.rpy:2362
translate Spanish call1_day7dlc_0f4c0405:

    # GRC "...If anyone will be begging, it won't be me."
    GRC "...Si alguien va a suplicar, no seré yo."

# game/beyond the bet/day7dlc.rpy:2364
translate Spanish call1_day7dlc_0d3a0df1:

    # GRC "I'll go easy on you, Sunshine."
    GRC "Seré suave contigo, Solecito."

# game/beyond the bet/day7dlc.rpy:2369
translate Spanish call1_day7dlc_e16e0575:

    # GRC "What else would we be talking about?"
    GRC "¿De qué más estaríamos hablando?"

# game/beyond the bet/day7dlc.rpy:2385
translate Spanish call1_day7dlc_7b92f8b1:

    # GRC "...No. I have not had anyone like that."
    GRC "...No. No he tenido a nadie así."

# game/beyond the bet/day7dlc.rpy:2395
translate Spanish call1_day7dlc_97f87800:

    # GRC "There's that dirty mouth I like so much."
    GRC "Ahí está esa boquita sucia que tanto me gusta."

# game/beyond the bet/day7dlc.rpy:2396
translate Spanish call1_day7dlc_848e89fb:

    # GRC "You're quite seductive sometimes, you know that?"
    GRC "A veces tienes un poder de seducción considerable, ¿lo sabías?"

# game/beyond the bet/day7dlc.rpy:2409
translate Spanish call1_day7dlc_f5ffbfc6:

    # GRC "Something tells me you're not talking about hair anymore."
    GRC "Algo me dice que ya no estás hablando del cabello."

# game/beyond the bet/day7dlc.rpy:2421
translate Spanish call1_day7dlc_ab691125:

    # GRC "Hah. You agree to begging so easily! How cute."
    GRC "Ja. ¡Aceptas suplicar con tanta facilidad! Qué lindo."

# game/beyond the bet/day7dlc.rpy:2429
translate Spanish call1_day7dlc_65122790_1:

    # GRC "I..."
    GRC "Yo..."

# game/beyond the bet/day7dlc.rpy:2430
translate Spanish call1_day7dlc_03e2acd5:

    # GRC "You are... so filthy sometimes."
    GRC "A veces tienes la mente... tan sucia."

# game/beyond the bet/day7dlc.rpy:2431
translate Spanish call1_day7dlc_20430038:

    # GRC "Are all mortals like this?"
    GRC "¿Todos los mortales son así?"

# game/beyond the bet/day7dlc.rpy:2444
translate Spanish call1_day7dlc_c2773ccf:

    # GRC "You're getting a little too excited there."
    GRC "Te estás emocionando un poquito de más."

# game/beyond the bet/day7dlc.rpy:2446
translate Spanish call1_day7dlc_092daa57:

    # GRC "I feel like you may faint if I exposed my neck to you."
    GRC "Siento que podrías desmayarte si te expusiera el cuello."

# game/beyond the bet/day7dlc.rpy:2455
translate Spanish call1_day7dlc_d73480b1:

    # GRC "You... are all bark and no bite, mortal."
    GRC "Tú... ladras mucho pero no muerdes, mortal."

# game/beyond the bet/day7dlc.rpy:2459
translate Spanish call1_day7dlc_bda0436d:

    # GRC "Hah! Well, perhaps you're not the only one."
    GRC "¡Ja! Bueno, quizá no seas la única persona."

# game/beyond the bet/day7dlc.rpy:2460
translate Spanish call1_day7dlc_3f164660:

    # GRC "If things were different, then maybe I wouldn't mind sinking my teeth into you."
    GRC "Si las cosas fueran distintas, quizá no me importaría hundir los dientes en ti."

# game/beyond the bet/day7dlc.rpy:2472
translate Spanish call1_day7dlc_549f83da:

    # GRC "I'm all bite, Sunshine."
    GRC "Yo sí muerdo, Solecito."

# game/beyond the bet/day7dlc.rpy:2473
translate Spanish call1_day7dlc_d95d24af:

    # GRC "You ought to be more careful, else you get eaten up."
    GRC "Deberías tener más cuidado, o terminarás devorad[letra]."

# game/beyond the bet/day7dlc.rpy:2482
translate Spanish call1_day7dlc_dffe7682:

    # GRC "You're looking a little flushed."
    GRC "Te ves un poco sonrojad[letra]."

# game/beyond the bet/day7dlc.rpy:2487
translate Spanish call1_day7dlc_22dc3fa5:

    # GRC "I can't help my sickness."
    GRC "No puedo evitar mi enfermedad."

# game/beyond the bet/day7dlc.rpy:2489
translate Spanish call1_day7dlc_61841791:

    # GRC "Just as you cannot help but be drawn to me."
    GRC "Así como no puedes evitar sentirte atraíd[letra] por mí."

# game/beyond the bet/day7dlc.rpy:2493
translate Spanish call1_day7dlc_22ab8a60:

    # GRC "Make me."
    GRC "Oblígame."

# game/beyond the bet/day7dlc.rpy:2501
translate Spanish call1_day7dlc_191c16cf:

    # GRC "What are you doing now?"
    GRC "¿Qué estás haciendo ahora?"

# game/beyond the bet/day7dlc.rpy:2502
translate Spanish call1_day7dlc_dafc9cd7:

    # GRC "Hiding behind a magazine?"
    GRC "¿Escondiéndote detrás de una revista?"

# game/beyond the bet/day7dlc.rpy:2503
translate Spanish call1_day7dlc_dc31bf35:

    # GRC "Sunshine, that doesn't make me disappear."
    GRC "Solecito, eso no me hace desaparecer."

# game/beyond the bet/day7dlc.rpy:2508
translate Spanish call1_day7dlc_6302fa71:

    # GRC "That is completely false."
    GRC "Eso es completamente falso."

# game/beyond the bet/day7dlc.rpy:2510
translate Spanish call1_day7dlc_e57a8bb8:

    # GRC "You should not spread lies so easily."
    GRC "No deberías andar diciendo mentiras tan a la ligera."

# game/beyond the bet/day7dlc.rpy:2518
translate Spanish call1_day7dlc_9ce7a2f4:

    # GRC "More falsehoods."
    GRC "Más falsedades."

# game/beyond the bet/day7dlc.rpy:2533
translate Spanish call1_day7dlc_5ebdd030:

    # GRC "Sunshine?"
    GRC "¿Solecito?"

# game/beyond the bet/day7dlc.rpy:2534
translate Spanish call1_day7dlc_537e3be7:

    # GRC "Are you okay?"
    GRC "¿Estás bien?"

# game/beyond the bet/day7dlc.rpy:2543
translate Spanish call1_day7dlc_115a9594:

    # GRC "You should be more careful, papercuts are—"
    GRC "Deberías tener más cuidado, los cortes con papel son—"

# game/beyond the bet/day7dlc.rpy:2545
translate Spanish call1_day7dlc_bd286ab7:

    # GRC "Ah!"
    GRC "¡Ah!"

# game/beyond the bet/day7dlc.rpy:2549
translate Spanish call1_day7dlc_a80e5a31:

    # GRC "...Sunshine, which finger did you cut?"
    GRC "...Solecito, ¿qué dedo te cortaste?"

# game/beyond the bet/day7dlc.rpy:2557
translate Spanish call1_day7dlc_008afe10_6:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day7dlc.rpy:2559
translate Spanish call1_day7dlc_5c6a7edc:

    # GRC "To think a tiny incision could cause that amount of pain."
    GRC "Pensar que una pequeña incisión pudiera causar tanto dolor."

# game/beyond the bet/day7dlc.rpy:2563
translate Spanish call1_day7dlc_cf29f407:

    # GRC "There's a cut on my finger."
    GRC "Tengo un corte en el dedo."

# game/beyond the bet/day7dlc.rpy:2564
translate Spanish call1_day7dlc_56b2e942:

    # GRC "Suddenly, abruptly, without warning."
    GRC "De repente, abruptamente, sin aviso."

# game/beyond the bet/day7dlc.rpy:2572
translate Spanish call1_day7dlc_2e564b71:

    # GRC "This is... something I have experienced, occasionally, but not spontaneously..."
    GRC "Esto es... algo que he experimentado, ocasionalmente, pero no de forma espontánea..."

# game/beyond the bet/day7dlc.rpy:2577
translate Spanish call1_day7dlc_43634d4f:

    # GRC "The exact same place."
    GRC "En el mismo lugar exacto."

# game/beyond the bet/day7dlc.rpy:2583
translate Spanish call1_day7dlc_008afe10_7:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day7dlc.rpy:2584
translate Spanish call1_day7dlc_9bd19d6f:

    # GRC "Wait, I think... wait here for a second."
    GRC "Espera, creo que... espera aquí un segundo."

# game/beyond the bet/day7dlc.rpy:2596
translate Spanish call1_day7dlc_260306e1:

    # GRC "I know it's here somewhere!"
    GRC "¡Sé que está por aquí en alguna parte!"

# game/beyond the bet/day7dlc.rpy:2603
translate Spanish call1_day7dlc_4e57370c:

    # GRC "I'm trying to find a particular tome."
    GRC "Estoy intentando encontrar un tomo en particular."

# game/beyond the bet/day7dlc.rpy:2609
translate Spanish call1_day7dlc_ad052efe:

    # GRC "I'm having little success."
    GRC "Estoy teniendo poco éxito."

# game/beyond the bet/day7dlc.rpy:2611
translate Spanish call1_day7dlc_c36fab2e:

    # GRC "I'll message you when I find it, okay?"
    GRC "Te escribiré cuando lo encuentre, ¿okey?"

# game/beyond the bet/day7dlc.rpy:2618
translate Spanish call1_day7dlc_c02c407d:

    # GRC "I'm fine, Sunshine."
    GRC "Estoy bien, Solecito."

# game/beyond the bet/day7dlc.rpy:2619
translate Spanish call1_day7dlc_134684d9:

    # GRC "Wait for me, okay?"
    GRC "Espérame, ¿okey?"

# game/beyond the bet/day7dlc.rpy:2643
translate Spanish chat2_day7dlc_1b98eb03:

    # player "Well..."
    player "Bueno..."

# game/beyond the bet/day7dlc.rpy:2646
translate Spanish chat2_day7dlc_274c63c7:

    # player "I said I'd wait, but I don't actually have much to do."
    player "Dije que esperaría, pero en realidad no tengo mucho que hacer."

# game/beyond the bet/day7dlc.rpy:2649
translate Spanish chat2_day7dlc_02642e60:

    # player "Let's see how high I can count before you get back."
    player "Veamos hasta cuánto puedo contar antes de que vuelvas."

# game/beyond the bet/day7dlc.rpy:2652
translate Spanish chat2_day7dlc_cba8e1ad:

    # player "1"
    player "1"

# game/beyond the bet/day7dlc.rpy:2655
translate Spanish chat2_day7dlc_3c01f24c:

    # player "2"
    player "2"

# game/beyond the bet/day7dlc.rpy:2658
translate Spanish chat2_day7dlc_55d8ab87:

    # player "3"
    player "3"

# game/beyond the bet/day7dlc.rpy:2661
translate Spanish chat2_day7dlc_ad51cb1e:

    # player "4"
    player "4"

# game/beyond the bet/day7dlc.rpy:2664
translate Spanish chat2_day7dlc_c542e075:

    # player "5"
    player "5"

# game/beyond the bet/day7dlc.rpy:2667
translate Spanish chat2_day7dlc_975281a3:

    # player "Okay I'm bored now."
    player "Okey, ya me aburrí."

# game/beyond the bet/day7dlc.rpy:2670
translate Spanish chat2_day7dlc_ae8f74ca:

    # player "Counting isn't as fun as I thought it might be."
    player "Contar no es tan divertido como pensé que sería."

# game/beyond the bet/day7dlc.rpy:2673
translate Spanish chat2_day7dlc_b1fc356d:

    # player "I'm doing a little dance to pass the time."
    player "Estoy haciendo un bailecito para pasar el rato."

# game/beyond the bet/day7dlc.rpy:2676
translate Spanish chat2_day7dlc_aef7c90f:

    # player "You can't see it but it's very cool."
    player "No puedes verlo, pero es buenísimo."

# game/beyond the bet/day7dlc.rpy:2679
translate Spanish chat2_day7dlc_1930292f:

    # player "I look awesome."
    player "Me veo increíble."

# game/beyond the bet/day7dlc.rpy:2682
translate Spanish chat2_day7dlc_a0180c8b:

    # player "You're missing out."
    player "Te lo estás perdiendo."

# game/beyond the bet/day7dlc.rpy:2685
translate Spanish chat2_day7dlc_5078180e:

    # player "Okay I'm tired of dancing now."
    player "Okey, ya me cansé de bailar."

# game/beyond the bet/day7dlc.rpy:2688
translate Spanish chat2_day7dlc_8da150c3:

    # player "I started doodling something just now."
    player "Acabo de empezar a hacer un garabato."

# game/beyond the bet/day7dlc.rpy:2691
translate Spanish chat2_day7dlc_da05597a:

    # player "It's a picture of the most handsome man I know."
    player "Es un dibujo del hombre más guapo que conozco."

# game/beyond the bet/day7dlc.rpy:2694
translate Spanish chat2_day7dlc_eabc5df4:

    # player "Azrael."
    player "Azrael."

# game/beyond the bet/day7dlc.rpy:2697
translate Spanish chat2_day7dlc_3b54eb93:

    # player "He's all muscly, though."
    player "Aunque es todo musculoso."

# game/beyond the bet/day7dlc.rpy:2700
translate Spanish chat2_day7dlc_4a226fd6:

    # player "Muscly Azrael."
    player "Azrael musculoso."

# game/beyond the bet/day7dlc.rpy:2703
translate Spanish chat2_day7dlc_87cf4748:

    # player "Alright that's done, now what..."
    player "Listo, eso ya está, ¿y ahora qué...?"

# game/beyond the bet/day7dlc.rpy:2706
translate Spanish chat2_day7dlc_c5fc9925:

    # player "I thought about eavesdropping on my neighbors..."
    player "Pensé en espiar a mis vecinos..."

# game/beyond the bet/day7dlc.rpy:2709
translate Spanish chat2_day7dlc_fc57c907:

    # player "But I think whoever lived next door actually MOVED OUT."
    player "Pero creo que quien vivía al lado en realidad SE MUDÓ."

# game/beyond the bet/day7dlc.rpy:2712
translate Spanish chat2_day7dlc_8889d015:

    # player "Out of nowhere."
    player "De la nada."

# game/beyond the bet/day7dlc.rpy:2715
translate Spanish chat2_day7dlc_3491a28d:

    # player "Isn't that strange?"
    player "¿No es raro?"

# game/beyond the bet/day7dlc.rpy:2718
translate Spanish chat2_day7dlc_bb2210c9:

    # player "I think they have some huge secret they're hiding..."
    player "Creo que esconde algún secreto enorme..."

# game/beyond the bet/day7dlc.rpy:2721
translate Spanish chat2_day7dlc_25f4bd45:

    # player "But I guess I'll never find out now."
    player "Pero supongo que ahora nunca lo sabré."

# game/beyond the bet/day7dlc.rpy:2725
translate Spanish chat2_day7dlc_e7002d63:

    # player "You know..."
    player "Sabes..."

# game/beyond the bet/day7dlc.rpy:2728
translate Spanish chat2_day7dlc_55bd5255:

    # player "I thought I was gonna die today."
    player "Pensé que hoy me iba a morir."

# game/beyond the bet/day7dlc.rpy:2730
translate Spanish chat2_day7dlc_2908400d:

    # player "Today is day seven."
    player "Hoy es el día siete."

# game/beyond the bet/day7dlc.rpy:2733
translate Spanish chat2_day7dlc_b4ccc959:

    # player "But I've still got my soul."
    player "Pero todavía tengo mi alma."

# game/beyond the bet/day7dlc.rpy:2736
translate Spanish chat2_day7dlc_41b4543f:

    # player "I think we've kinda danced around the issue all day..."
    player "Creo que hemos estado dándole vueltas al asunto todo el día..."

# game/beyond the bet/day7dlc.rpy:2738
translate Spanish chat2_day7dlc_ab441ab5:

    # player "It's the elephant in the room, huh?"
    player "Es el elefante en la habitación, ¿eh?"

# game/beyond the bet/day7dlc.rpy:2741
translate Spanish chat2_day7dlc_6d499425:

    # player "But..."
    player "Pero..."

# game/beyond the bet/day7dlc.rpy:2744
translate Spanish chat2_day7dlc_32680125:

    # player "There was this flyer put under my door, about some outdoor twilight festival that's being held tomorrow."
    player "Pasaron un folleto por debajo de mi puerta sobre un festival al aire libre del crepúsculo que se celebra mañana."

# game/beyond the bet/day7dlc.rpy:2748
translate Spanish chat2_day7dlc_61643463:

    # player "Not Twilight like vampires."
    player "No Crepúsculo como los vampiros."

# game/beyond the bet/day7dlc.rpy:2752
translate Spanish chat2_day7dlc_86a3ff22:

    # player "Twilight like, uh, the time of day."
    player "Crepúsculo como, eh, la hora del día."

# game/beyond the bet/day7dlc.rpy:2756
translate Spanish chat2_day7dlc_0f618d2e:

    # player "You know what my first thought was?"
    player "¿Sabes cuál fue mi primer pensamiento?"

# game/beyond the bet/day7dlc.rpy:2759
translate Spanish chat2_day7dlc_a6b0a991:

    # player "Wouldn't it be fun to go with Casper?"
    player "¿No sería divertido ir con Casper?"

# game/beyond the bet/day7dlc.rpy:2761
translate Spanish chat2_day7dlc_c77158c1:

    # player "Wouldn't it be fun to go alone?"
    player "¿No sería divertido ir sol[letra]?"

# game/beyond the bet/day7dlc.rpy:2764
translate Spanish chat2_day7dlc_19b3cb61:

    # player "...Okay, that's a lie."
    player "...Okey, eso es mentira."

# game/beyond the bet/day7dlc.rpy:2767
translate Spanish chat2_day7dlc_3bf8cac7:

    # player "I thought about going with you."
    player "Pensé en ir contigo."

# game/beyond the bet/day7dlc.rpy:2770
translate Spanish chat2_day7dlc_aa0274f1:

    # player "And then I remembered that one of the two of us would likely be dead by tomorrow, so..."
    player "Y entonces recordé que uno de los dos probablemente estaría muerto para mañana, así que..."

# game/beyond the bet/day7dlc.rpy:2773
translate Spanish chat2_day7dlc_b70dd3e8:

    # player "It made me kinda sad."
    player "Me dio medio tristeza."

# game/beyond the bet/day7dlc.rpy:2776
translate Spanish chat2_day7dlc_6f2c0b5e:

    # player "Not the thought of being dead."
    player "No la idea de estar muert[letra]."

# game/beyond the bet/day7dlc.rpy:2779
translate Spanish chat2_day7dlc_37186af1:

    # player "I mean, that sucks."
    player "O sea, eso es una porquería."

# game/beyond the bet/day7dlc.rpy:2782
translate Spanish chat2_day7dlc_3761fd46:

    # player "But, the thought that we'd already run out of time."
    player "Sino la idea de que ya se nos acabó el tiempo."

# game/beyond the bet/day7dlc.rpy:2785
translate Spanish chat2_day7dlc_c443b145:

    # player "Even going to watch some fireworks together wouldn't be possible..."
    player "Ni siquiera podríamos ir a ver fuegos artificiales juntos..."

# game/beyond the bet/day7dlc.rpy:2788
translate Spanish chat2_day7dlc_66193e97:

    # player "I've enjoyed our time together."
    player "He disfrutado nuestro tiempo juntos."

# game/beyond the bet/day7dlc.rpy:2791
translate Spanish chat2_day7dlc_7ae72fe3:

    # player "Really enjoyed it."
    player "De verdad lo he disfrutado."

# game/beyond the bet/day7dlc.rpy:2794
translate Spanish chat2_day7dlc_34a893d1:

    # player "Which is silly, because I only responded to you in the first place because..."
    player "Lo cual es tonto, porque en primer lugar solo te respondí porque..."

# game/beyond the bet/day7dlc.rpy:2797
translate Spanish chat2_day7dlc_56c6903f:

    # player "Well, I thought it'd be funny."
    player "Bueno, pensé que sería gracioso."

# game/beyond the bet/day7dlc.rpy:2800
translate Spanish chat2_day7dlc_9ee86862:

    # player "I really like you, Casper."
    player "Me gustas mucho, Casper."

# game/beyond the bet/day7dlc.rpy:2803
translate Spanish chat2_day7dlc_f422d1e4:

    # player "You are so dumb."
    player "Eres tan tonto."

# game/beyond the bet/day7dlc.rpy:2805
translate Spanish chat2_day7dlc_b05ebf98:

    # player "You are the most arrogant person I know."
    player "Eres la persona más arrogante que conozco."

# game/beyond the bet/day7dlc.rpy:2808
translate Spanish chat2_day7dlc_265154e6:

    # player "And for some reason I'm into that."
    player "Y por alguna razón eso me gusta."

# game/beyond the bet/day7dlc.rpy:2810
translate Spanish chat2_day7dlc_44b32e3c:

    # GR "are you just talking to yourself?"
    GR "¿estás hablando contigo mism[letra]?"

# game/beyond the bet/day7dlc.rpy:2813
translate Spanish chat2_day7dlc_335f658e:

    # player "AH!"
    player "¡AH!"

# game/beyond the bet/day7dlc.rpy:2815
translate Spanish chat2_day7dlc_add89494:

    # player "FUCK!"
    player "¡MIERDA!"

# game/beyond the bet/day7dlc.rpy:2818
translate Spanish chat2_day7dlc_12d68497:

    # player "A ghost!"
    player "¡Un fantasma!"

# game/beyond the bet/day7dlc.rpy:2819
translate Spanish chat2_day7dlc_4e779fc1:

    # GR "i am not a ghost."
    GR "no soy un fantasma."

# game/beyond the bet/day7dlc.rpy:2820
translate Spanish chat2_day7dlc_db6341d9:

    # GR "i doubt reapers even become ghosts."
    GR "dudo que las parcas siquiera se conviertan en fantasmas."

# game/beyond the bet/day7dlc.rpy:2823
translate Spanish chat2_day7dlc_837c18e7:

    # player "A demon!"
    player "¡Un demonio!"

# game/beyond the bet/day7dlc.rpy:2824
translate Spanish chat2_day7dlc_8ece9b28:

    # GR "not a demon."
    GR "no soy un demonio."

# game/beyond the bet/day7dlc.rpy:2825
translate Spanish chat2_day7dlc_a73c602c:

    # GR "i am missing the wings, the horns, the tail..."
    GR "me faltan las alas, los cuernos, la cola..."

# game/beyond the bet/day7dlc.rpy:2826
translate Spanish chat2_day7dlc_3cd4a018:

    # GR "though, i will say, i'd look rather fetching with those features."
    GR "aunque debo decir que me vería bastante atractivo con esas características."

# game/beyond the bet/day7dlc.rpy:2829
translate Spanish chat2_day7dlc_77da04b6:

    # player "A Grim Reaper!"
    player "¡Una Parca!"

# game/beyond the bet/day7dlc.rpy:2830
translate Spanish chat2_day7dlc_c800fd54:

    # GR "i'm not..."
    GR "no soy..."

# game/beyond the bet/day7dlc.rpy:2831
translate Spanish chat2_day7dlc_989a6a22:

    # GR "wait."
    GR "espera."

# game/beyond the bet/day7dlc.rpy:2832
translate Spanish chat2_day7dlc_380b52e4:

    # GR "i am a grim reaper."
    GR "soy una parca."

# game/beyond the bet/day7dlc.rpy:2833
translate Spanish chat2_day7dlc_eb2d2e99:

    # GR "i thought you were going to say something absurd and, frankly, incorrect."
    GR "pensé que ibas a decir algo absurdo y, francamente, incorrecto."

# game/beyond the bet/day7dlc.rpy:2836
translate Spanish chat2_day7dlc_2dfcf07f:

    # player "The father to my soulbabies!"
    player "¡El padre de mis bebés alma!"

# game/beyond the bet/day7dlc.rpy:2837
translate Spanish chat2_day7dlc_d3af5b59:

    # GR "???????"
    GR "???????"

# game/beyond the bet/day7dlc.rpy:2838
translate Spanish chat2_day7dlc_41677525:

    # GR "???????????????"
    GR "???????????????"

# game/beyond the bet/day7dlc.rpy:2839
translate Spanish chat2_day7dlc_6099970e:

    # GR "i am not a father!!!!!"
    GR "¡¡¡¡¡no soy padre!!!!!"

# game/beyond the bet/day7dlc.rpy:2842
translate Spanish chat2_day7dlc_c3b087f0:

    # player "Oh, my bad."
    player "Ay, mi error."

# game/beyond the bet/day7dlc.rpy:2845
translate Spanish chat2_day7dlc_3ed8771a:

    # player "Future* father."
    player "Futuro* padre."

# game/beyond the bet/day7dlc.rpy:2846
translate Spanish chat2_day7dlc_949f2162:

    # GR "......."
    GR "......."

# game/beyond the bet/day7dlc.rpy:2847
translate Spanish chat2_day7dlc_f41f11b7:

    # GR "MOVING ON."
    GR "SIGAMOS ADELANTE."

# game/beyond the bet/day7dlc.rpy:2849
translate Spanish chat2_day7dlc_9341f14d:

    # GR "ugh..."
    GR "ugh..."

# game/beyond the bet/day7dlc.rpy:2850
translate Spanish chat2_day7dlc_480a7ef6:

    # GR "sunshine, i found it."
    GR "solecito, lo encontré."

# game/beyond the bet/day7dlc.rpy:2853
translate Spanish chat2_day7dlc_b4cc0c38:

    # player "What is it?"
    player "¿Qué es?"

# game/beyond the bet/day7dlc.rpy:2854
translate Spanish chat2_day7dlc_ddcc570b:

    # GR "'the beginner's guide to soul bridges'."
    GR "'la guía para principiantes sobre puentes de almas'."

# game/beyond the bet/day7dlc.rpy:2857
translate Spanish chat2_day7dlc_491ff588:

    # player "That is NOT a real book."
    player "Ese NO es un libro de verdad."

# game/beyond the bet/day7dlc.rpy:2859
translate Spanish chat2_day7dlc_d7e2edce:

    # player "I thought you couldn't lie."
    player "Pensé que no podías mentir."

# game/beyond the bet/day7dlc.rpy:2860
translate Spanish chat2_day7dlc_932c9473:

    # GR "it's real!"
    GR "¡es real!"

# game/beyond the bet/day7dlc.rpy:2861
translate Spanish chat2_day7dlc_962d4dc2:

    # GR "i have not read this for many years... there was no need..."
    GR "no he leído esto en muchos años... no había necesidad..."

# game/beyond the bet/day7dlc.rpy:2862
translate Spanish chat2_day7dlc_5e399cd9:

    # GR "let's see... yes... uh huh..."
    GR "veamos... sí... ajá..."

# game/beyond the bet/day7dlc.rpy:2863
translate Spanish chat2_day7dlc_7772a27d:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:2864
translate Spanish chat2_day7dlc_2367e502:

    # GR "the... effects of linking two souls together... can be stronger if the souls are inherently compatible..."
    GR "los... efectos de vincular dos almas... pueden ser más fuertes si las almas son inherentemente compatibles..."

# game/beyond the bet/day7dlc.rpy:2865
translate Spanish chat2_day7dlc_7bda7d88:

    # GR "or..."
    GR "o..."

# game/beyond the bet/day7dlc.rpy:2866
translate Spanish chat2_day7dlc_b06fea7b:

    # GR "two parts of one whole..."
    GR "dos partes de un todo..."

# game/beyond the bet/day7dlc.rpy:2867
translate Spanish chat2_day7dlc_44825e34:

    # GR "hm..."
    GR "hm..."

# game/beyond the bet/day7dlc.rpy:2868
translate Spanish chat2_day7dlc_454ccd80:

    # GR "{image=huh}"
    GR "{image=huh}"

# game/beyond the bet/day7dlc.rpy:2871
translate Spanish chat2_day7dlc_e78f5f97:

    # player "Wait, that's why you're sick? And the cut?"
    player "Espera, ¿por eso estás enfermo? ¿Y el corte?"

# game/beyond the bet/day7dlc.rpy:2872
translate Spanish chat2_day7dlc_24db00ac:

    # GR "i... believe it to be so."
    GR "yo... creo que sí."

# game/beyond the bet/day7dlc.rpy:2873
translate Spanish chat2_day7dlc_c8879a53:

    # GR "linking souls usually only has minor effects..."
    GR "vincular almas por lo general solo tiene efectos menores..."

# game/beyond the bet/day7dlc.rpy:2874
translate Spanish chat2_day7dlc_186c22e3:

    # GR "i can travel our 'bridge' to inspect your soul..."
    GR "puedo recorrer nuestro 'puente' para inspeccionar tu alma..."

# game/beyond the bet/day7dlc.rpy:2875
translate Spanish chat2_day7dlc_fa9aadb8:

    # GR "we can hear each other's voices in our heads..."
    GR "podemos oír las voces del otro en nuestras cabezas..."

# game/beyond the bet/day7dlc.rpy:2876
translate Spanish chat2_day7dlc_b6e57272:

    # GR "but it's temporary."
    GR "pero es temporal."

# game/beyond the bet/day7dlc.rpy:2877
translate Spanish chat2_day7dlc_dbc29341:

    # GR "it's supposed to be, at least. it should have worn off by now."
    GR "se supone que lo es, al menos. ya debería haberse desvanecido."

# game/beyond the bet/day7dlc.rpy:2878
translate Spanish chat2_day7dlc_a35b7d9e:

    # GR "i only left the tiniest bit of my soul with you, after all."
    GR "después de todo, solo dejé contigo la más mínima parte de mi alma."

# game/beyond the bet/day7dlc.rpy:2881
translate Spanish chat2_day7dlc_b68628e6:

    # player "So... we're compatible or something?"
    player "Entonces... ¿somos compatibles o algo así?"

# game/beyond the bet/day7dlc.rpy:2883
translate Spanish chat2_day7dlc_1513cd78:

    # player "We complete each other :D ?"
    player "¿Nos complementamos :D ?"

# game/beyond the bet/day7dlc.rpy:2884
translate Spanish chat2_day7dlc_421748ba:

    # GR "let's not jump to conclusions here."
    GR "no saltemos a conclusiones."

# game/beyond the bet/day7dlc.rpy:2885
translate Spanish chat2_day7dlc_d339f7ed:

    # GR "what would cause our connection to suddenly deepen like this?"
    GR "¿qué causaría que nuestra conexión se profundizara de repente así?"

# game/beyond the bet/day7dlc.rpy:2888
translate Spanish chat2_day7dlc_55a0df4c:

    # player "Hmm..."
    player "Hmm..."

# game/beyond the bet/day7dlc.rpy:2891
translate Spanish chat2_day7dlc_0609f689:

    # player "Oh!"
    player "¡Oh!"

# game/beyond the bet/day7dlc.rpy:2894
translate Spanish chat2_day7dlc_05dc3217:

    # player "Last night!"
    player "¡Anoche!"

# game/beyond the bet/day7dlc.rpy:2896
translate Spanish chat2_day7dlc_2aa570c1:

    # player "You came over...!"
    player "¡Viniste...!"

# game/beyond the bet/day7dlc.rpy:2897
translate Spanish chat2_day7dlc_49d8ba9e:

    # GR "why would that make a..."
    GR "¿por qué eso causaría un...?"

# game/beyond the bet/day7dlc.rpy:2898
translate Spanish chat2_day7dlc_ff8bba44:

    # GR "a..."
    GR "un..."

# game/beyond the bet/day7dlc.rpy:2899
translate Spanish chat2_day7dlc_a6de612c:

    # GR "ah."
    GR "ah."

# game/beyond the bet/day7dlc.rpy:2902
translate Spanish chat2_day7dlc_4fc5ff92:

    # player "We touched!"
    player "¡Nos tocamos!"

# game/beyond the bet/day7dlc.rpy:2905
translate Spanish chat2_day7dlc_95bc26f4:

    # player "You took off your gloves and touched my forehead."
    player "Te quitaste los guantes y me tocaste la frente."

# game/beyond the bet/day7dlc.rpy:2908
translate Spanish chat2_day7dlc_2422eb1f:

    # player "Remember that weird zap?"
    player "¿Recuerdas esa extraña descarga?"

# game/beyond the bet/day7dlc.rpy:2909
translate Spanish chat2_day7dlc_52b72d6e:

    # GR "...this will not do."
    GR "...esto no puede ser."

# game/beyond the bet/day7dlc.rpy:2910
translate Spanish chat2_day7dlc_17aff9e0:

    # GR "gods, this is the worst thing to ever happen to me."
    GR "dioses, esto es lo peor que me ha pasado jamás."

# game/beyond the bet/day7dlc.rpy:2911
translate Spanish chat2_day7dlc_e8998d96:

    # GR "a soul of shadow and a soul of sunshine... gods, why did i do this to myself..."
    GR "un alma de sombra y un alma de sol... dioses, ¿por qué me hice esto a mí mismo...?"

# game/beyond the bet/day7dlc.rpy:2914
translate Spanish chat2_day7dlc_0c83378f:

    # player "Hey, you could be a little less upset here."
    player "Oye, podrías estar un poco menos molesto."

# game/beyond the bet/day7dlc.rpy:2917
translate Spanish chat2_day7dlc_ab8426ff:

    # player "I'm not that bad."
    player "No soy tan mal[letra]."

# game/beyond the bet/day7dlc.rpy:2920
translate Spanish chat2_day7dlc_bff2b92c:

    # player "It's not like I stink."
    player "No es que huela mal."

# game/beyond the bet/day7dlc.rpy:2923
translate Spanish chat2_day7dlc_9f30ab35:

    # player "Wait."
    player "Espera."

# game/beyond the bet/day7dlc.rpy:2926
translate Spanish chat2_day7dlc_2c896f40:

    # player "I don't stink, do I?"
    player "No huelo mal, ¿verdad?"

# game/beyond the bet/day7dlc.rpy:2927
translate Spanish chat2_day7dlc_7ac2a355:

    # GR "stop rambling."
    GR "deja de divagar."

# game/beyond the bet/day7dlc.rpy:2928
translate Spanish chat2_day7dlc_99aee770:

    # GR "no, you do not smell."
    GR "no, no hueles mal."

# game/beyond the bet/day7dlc.rpy:2929
translate Spanish chat2_day7dlc_69816ccc:

    # GR "you smell very nice, in fact."
    GR "de hecho, hueles muy bien."

# game/beyond the bet/day7dlc.rpy:2930
translate Spanish chat2_day7dlc_2e30bd0d:

    # GR "i found that out last night."
    GR "lo descubrí anoche."

# game/beyond the bet/day7dlc.rpy:2931
translate Spanish chat2_day7dlc_0b16bee0:

    # GR "ahem."
    GR "ejem."

# game/beyond the bet/day7dlc.rpy:2934
translate Spanish chat2_day7dlc_214e632b:

    # player "C'mon, it's not that bad."
    player "Vamos, no es tan grave."

# game/beyond the bet/day7dlc.rpy:2935
translate Spanish chat2_day7dlc_4851ccc1:

    # GR "you and i are explicitly linked."
    GR "tú y yo estamos explícitamente vinculados."

# game/beyond the bet/day7dlc.rpy:2936
translate Spanish chat2_day7dlc_ccb285b9:

    # GR "for... who knows how long?"
    GR "por... ¿quién sabe cuánto tiempo?"

# game/beyond the bet/day7dlc.rpy:2937
translate Spanish chat2_day7dlc_8a80fe2f:

    # GR "for another week? a month? a year? forever?"
    GR "¿otra semana? ¿un mes? ¿un año? ¿para siempre?"

# game/beyond the bet/day7dlc.rpy:2938
translate Spanish chat2_day7dlc_7d6133f4:

    # GR "that is not a safe thing for either of us."
    GR "eso no es seguro para ninguno de los dos."

# game/beyond the bet/day7dlc.rpy:2940
translate Spanish chat2_day7dlc_4529478c:

    # GR "if either of us are hurt, the other will feel it."
    GR "si uno de los dos resulta herido, el otro lo sentirá."

# game/beyond the bet/day7dlc.rpy:2941
translate Spanish chat2_day7dlc_3c8b9a42:

    # GR "i am overcome with the soulsickness?"
    GR "si la enfermedad del alma me domina..."

# game/beyond the bet/day7dlc.rpy:2942
translate Spanish chat2_day7dlc_3db171d4:

    # GR "you, a human, will be touched by it."
    GR "tú, [arti_2] human[letra], te verás afectad[letra] por ella."

# game/beyond the bet/day7dlc.rpy:2943
translate Spanish chat2_day7dlc_15408951:

    # GR "i have never heard of a human being affected by it."
    GR "nunca he oído que un humano se vea afectado por eso."

# game/beyond the bet/day7dlc.rpy:2944
translate Spanish chat2_day7dlc_c1c4da2d:

    # GR "i do not know if you would survive it."
    GR "no sé si sobrevivirías."

# game/beyond the bet/day7dlc.rpy:2945
translate Spanish chat2_day7dlc_497e0d69:

    # GR "you get sick? i get it, too."
    GR "¿te enfermas tú? yo también."

# game/beyond the bet/day7dlc.rpy:2946
translate Spanish chat2_day7dlc_6019993f:

    # GR "i... take your soul..."
    GR "yo... tomo tu alma..."

# game/beyond the bet/day7dlc.rpy:2947
translate Spanish chat2_day7dlc_57d44d95:

    # GR "likely, my soul will go, too."
    GR "probablemente, la mía también se irá."

# game/beyond the bet/day7dlc.rpy:2948
translate Spanish chat2_day7dlc_d25cc021:

    # GR "you win the bet and now you take my soul?"
    GR "¿ganas la apuesta y ahora tomas mi alma?"

# game/beyond the bet/day7dlc.rpy:2949
translate Spanish chat2_day7dlc_80ddc6d3:

    # GR "you die too."
    GR "tú también mueres."

# game/beyond the bet/day7dlc.rpy:2952
translate Spanish chat2_day7dlc_9f1b6413:

    # player "Ah."
    player "Ah."

# game/beyond the bet/day7dlc.rpy:2955
translate Spanish chat2_day7dlc_7f32d3a5:

    # player "That could be a problem."
    player "Eso podría ser un problema."

# game/beyond the bet/day7dlc.rpy:2956
translate Spanish chat2_day7dlc_5946f553:

    # GR "it IS a problem."
    GR "ES un problema."

# game/beyond the bet/day7dlc.rpy:2957
translate Spanish chat2_day7dlc_a1d706d2:

    # GR "a huge one."
    GR "uno enorme."

# game/beyond the bet/day7dlc.rpy:2958
translate Spanish chat2_day7dlc_7f780581:

    # GR "one i do not know how to fix."
    GR "uno que no sé cómo solucionar."

# game/beyond the bet/day7dlc.rpy:2961
translate Spanish chat2_day7dlc_34ca0067:

    # player "That's less than ideal."
    player "No es precisamente lo ideal."

# game/beyond the bet/day7dlc.rpy:2962
translate Spanish chat2_day7dlc_d9146cb4:

    # GR "the understatement of the century."
    GR "el eufemismo del siglo."

# game/beyond the bet/day7dlc.rpy:2965
translate Spanish chat2_day7dlc_0a08b6e4:

    # player "Worse things happen at sea."
    player "Cosas peores pasan en el mar."

# game/beyond the bet/day7dlc.rpy:2966
translate Spanish chat2_day7dlc_8ede3c01:

    # GR "what?"
    GR "¿qué?"

# game/beyond the bet/day7dlc.rpy:2969
translate Spanish chat2_day7dlc_524ede16:

    # player "I read that once on the internet."
    player "Lo leí una vez en internet."

# game/beyond the bet/day7dlc.rpy:2972
translate Spanish chat2_day7dlc_ba77a0d1:

    # player "It makes me feel better when bad things happen."
    player "Me hace sentir mejor cuando pasan cosas malas."

# game/beyond the bet/day7dlc.rpy:2973
translate Spanish chat2_day7dlc_5ba88828:

    # GR "it is stupid."
    GR "es estúpido."

# game/beyond the bet/day7dlc.rpy:2974
translate Spanish chat2_day7dlc_176e7d6f:

    # GR "this is the worst possible thing that could be happening right now."
    GR "esto es lo peor que podría estar pasando ahora mismo."

# game/beyond the bet/day7dlc.rpy:2978
translate Spanish chat2_day7dlc_9f7c349c:

    # player "So, we just cancel the bet."
    player "Entonces, simplemente cancelamos la apuesta."

# game/beyond the bet/day7dlc.rpy:2979
translate Spanish chat2_day7dlc_8c693087:

    # GR "i cannot."
    GR "no puedo."

# game/beyond the bet/day7dlc.rpy:2980
translate Spanish chat2_day7dlc_8f05ab68:

    # GR "i must take your soul, or die trying."
    GR "debo tomar tu alma, o morir en el intento."

# game/beyond the bet/day7dlc.rpy:2981
translate Spanish chat2_day7dlc_c16207a1:

    # GR "if... if i do not move you on soon, someone else will just step in to take my place."
    GR "si... si no te llevo pronto, alguien más simplemente intervendrá para ocupar mi lugar."

# game/beyond the bet/day7dlc.rpy:2984
translate Spanish chat2_day7dlc_0d3a3f38:

    # player "Then..."
    player "Entonces..."

# game/beyond the bet/day7dlc.rpy:2987
translate Spanish chat2_day7dlc_73325cc9:

    # player "How about..."
    player "¿Qué tal..."

# game/beyond the bet/day7dlc.rpy:2990
translate Spanish chat2_day7dlc_e8698287:

    # player "Extending it?"
    player "extenderla?"

# game/beyond the bet/day7dlc.rpy:2993
translate Spanish chat2_day7dlc_f5d8e581:

    # player "Just for a few days."
    player "Solo por unos días."

# game/beyond the bet/day7dlc.rpy:2996
translate Spanish chat2_day7dlc_1426d6b5:

    # player "You've been after me for years. Surely a few more days is fine."
    player "Llevas años detrás de mí. Seguro que unos días más no son problema."

# game/beyond the bet/day7dlc.rpy:2997
translate Spanish chat2_day7dlc_44825e34_1:

    # GR "hm..."
    GR "hm..."

# game/beyond the bet/day7dlc.rpy:2998
translate Spanish chat2_day7dlc_2cfbaea0:

    # GR "well..."
    GR "bueno..."

# game/beyond the bet/day7dlc.rpy:2999
translate Spanish chat2_day7dlc_9039a0c7:

    # GR "just while i..."
    GR "solo mientras yo..."

# game/beyond the bet/day7dlc.rpy:3000
translate Spanish chat2_day7dlc_01ce05b5:

    # GR "try to reverse our connection..."
    GR "intento revertir nuestra conexión..."

# game/beyond the bet/day7dlc.rpy:3001
translate Spanish chat2_day7dlc_0cc70068:

    # GR "if my head will just stop hurting..."
    GR "si mi cabeza dejara de dolerme..."

# game/beyond the bet/day7dlc.rpy:3004
translate Spanish chat2_day7dlc_3d88cfa5:

    # player "Awww, poor Casper."
    player "Awww, pobre Casper."

# game/beyond the bet/day7dlc.rpy:3005
translate Spanish chat2_day7dlc_40f66124:

    # GR "are you pitying me?"
    GR "¿me estás compadeciendo?"

# game/beyond the bet/day7dlc.rpy:3008
translate Spanish chat2_day7dlc_b58385b3:

    # player "A little."
    player "Un poco."

# game/beyond the bet/day7dlc.rpy:3010
translate Spanish chat2_day7dlc_e843712c:

    # player "I might be."
    player "Podría ser."

# game/beyond the bet/day7dlc.rpy:3012
translate Spanish chat2_day7dlc_7e3f17ab:

    # player "I would never!"
    player "¡Jamás!"

# game/beyond the bet/day7dlc.rpy:3015
translate Spanish chat2_day7dlc_d95617f4:

    # player "Who's my sad little sick boy?"
    player "¿Quién es mi pobre chiquito enfermo?"

# game/beyond the bet/day7dlc.rpy:3016
translate Spanish chat2_day7dlc_7772a27d_1:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:3017
translate Spanish chat2_day7dlc_2ffe69f3:

    # GR "me..."
    GR "yo..."

# game/beyond the bet/day7dlc.rpy:3020
translate Spanish chat2_day7dlc_327cfb56:

    # player "It'll be alright. I'm here for you."
    player "Todo va a estar bien. Estoy aquí contigo."

# game/beyond the bet/day7dlc.rpy:3021
translate Spanish chat2_day7dlc_7f8271e6:

    # GR "your presence is making it worse."
    GR "tu presencia lo empeora."

# game/beyond the bet/day7dlc.rpy:3024
translate Spanish chat2_day7dlc_eaba0a47:

    # player "Oh."
    player "Oh."

# game/beyond the bet/day7dlc.rpy:3027
translate Spanish chat2_day7dlc_39572cc6:

    # player "Welp."
    player "En fin."

# game/beyond the bet/day7dlc.rpy:3030
translate Spanish chat2_day7dlc_3defc36e:

    # player "You're still stuck with me."
    player "Sigues atrapado conmigo."

# game/beyond the bet/day7dlc.rpy:3032
translate Spanish chat2_day7dlc_94b0ab46:

    # GR "it... seems we have a few more days together."
    GR "parece que tenemos algunos días más juntos."

# game/beyond the bet/day7dlc.rpy:3033
translate Spanish chat2_day7dlc_921424cd:

    # GR "no more than 3, okay?"
    GR "no más de 3, ¿okey?"

# game/beyond the bet/day7dlc.rpy:3034
translate Spanish chat2_day7dlc_1b0a4f4a:

    # GR "it will be too dangerous otherwise."
    GR "de lo contrario será demasiado peligroso."

# game/beyond the bet/day7dlc.rpy:3037
translate Spanish chat2_day7dlc_33c32add:

    # player "So if we get to day 10, and don't have a plan..."
    player "Entonces, si llegamos al día 10 y no tenemos un plan..."

# game/beyond the bet/day7dlc.rpy:3038
translate Spanish chat2_day7dlc_39b0ee6d:

    # GR "we're both dead."
    GR "ambos moriremos."

# game/beyond the bet/day7dlc.rpy:3041
translate Spanish chat2_day7dlc_42c69b46:

    # player "Doesn't sound so bad."
    player "No suena tan mal."

# game/beyond the bet/day7dlc.rpy:3042
translate Spanish chat2_day7dlc_c30211c0:

    # GR "i..."
    GR "yo..."

# game/beyond the bet/day7dlc.rpy:3043
translate Spanish chat2_day7dlc_ac526374:

    # GR "suppose there are worse people to die with."
    GR "supongo que hay peores personas con quienes morir."

# game/beyond the bet/day7dlc.rpy:3046
translate Spanish chat2_day7dlc_e781eb80:

    # player "We could go to the afterlife together!"
    player "¡Podríamos ir juntos al más allá!"

# game/beyond the bet/day7dlc.rpy:3047
translate Spanish chat2_day7dlc_6687fd41:

    # GR "unlikely."
    GR "poco probable."

# game/beyond the bet/day7dlc.rpy:3048
translate Spanish chat2_day7dlc_100f3870:

    # GR "or, rather, that's not possible."
    GR "o, mejor dicho, eso no es posible."

# game/beyond the bet/day7dlc.rpy:3051
translate Spanish chat2_day7dlc_888ecc42:

    # player "Why not?"
    player "¿Por qué no?"

# game/beyond the bet/day7dlc.rpy:3052
translate Spanish chat2_day7dlc_80f2fe34:

    # GR "there is no afterlife for a grim reaper."
    GR "no hay más allá para una parca."

# game/beyond the bet/day7dlc.rpy:3053
translate Spanish chat2_day7dlc_ec08cabb:

    # GR "Never once, in my entire existence, have i guided a reaper to their afterlife."
    GR "Nunca, en toda mi existencia, he guiado a una parca a su más allá."

# game/beyond the bet/day7dlc.rpy:3056
translate Spanish chat2_day7dlc_eaba0a47_1:

    # player "Oh."
    player "Oh."

# game/beyond the bet/day7dlc.rpy:3059
translate Spanish chat2_day7dlc_6fe84dca:

    # player "That's sad."
    player "Qué triste."

# game/beyond the bet/day7dlc.rpy:3063
translate Spanish chat2_day7dlc_edb6db89:

    # player "Doomed by the narrative..."
    player "Condenados por la narrativa..."

# game/beyond the bet/day7dlc.rpy:3064
translate Spanish chat2_day7dlc_88c1e4fc:

    # GR "what narrative?"
    GR "¿qué narrativa?"

# game/beyond the bet/day7dlc.rpy:3067
translate Spanish chat2_day7dlc_eff53bab:

    # player "Like."
    player "O sea."

# game/beyond the bet/day7dlc.rpy:3070
translate Spanish chat2_day7dlc_65cf3d5f:

    # player "If this was a book, or a game, or something."
    player "Si esto fuera un libro, o un juego, o algo así."

# game/beyond the bet/day7dlc.rpy:3073
translate Spanish chat2_day7dlc_3afc16d9:

    # player "People would say we're doomed by the narrative."
    player "La gente diría que estamos condenados por la narrativa."

# game/beyond the bet/day7dlc.rpy:3076
translate Spanish chat2_day7dlc_6d499425_1:

    # player "But..."
    player "Pero..."

# game/beyond the bet/day7dlc.rpy:3079
translate Spanish chat2_day7dlc_d27d54a8:

    # player "I bet people would cheer for us, anyway."
    player "Apuesto a que la gente nos animaría de todos modos."

# game/beyond the bet/day7dlc.rpy:3080
translate Spanish chat2_day7dlc_0604e0de:

    # GR "an... interesting concept."
    GR "un... concepto interesante."

# game/beyond the bet/day7dlc.rpy:3083
translate Spanish chat2_day7dlc_b4a56940:

    # player "We're like a pair of tragic lovers."
    player "Somos como una pareja de amantes trágicos."

# game/beyond the bet/day7dlc.rpy:3084
translate Spanish chat2_day7dlc_e6eda00e:

    # GR "a modern day romeo and juliet."
    GR "un romeo y julieta de la era moderna."

# game/beyond the bet/day7dlc.rpy:3087
translate Spanish chat2_day7dlc_2e2bc7b4:

    # player "Practically."
    player "Prácticamente."

# game/beyond the bet/day7dlc.rpy:3090
translate Spanish chat2_day7dlc_48fcb308:

    # player "I don't know about you, but I'm basically written by Shakespeare."
    player "No sé tú, pero parece que mi vida la escribió Shakespeare."

# game/beyond the bet/day7dlc.rpy:3091
translate Spanish chat2_day7dlc_cfd8a172:

    # GR "that is so untrue it almost hurts."
    GR "eso es tan falso que casi duele."

# game/beyond the bet/day7dlc.rpy:3092
translate Spanish chat2_day7dlc_99e1e1d2:

    # GR "you are an absolute moron."
    GR "eres [arti_2] complet[letra] imbécil."

# game/beyond the bet/day7dlc.rpy:3095
translate Spanish chat2_day7dlc_e9e44d8e:

    # player "That makes the two of us."
    player "Somos dos."

# game/beyond the bet/day7dlc.rpy:3098
translate Spanish chat2_day7dlc_c387275c:

    # player "I don't have any plans to die."
    player "No tengo ningún plan de morir."

# game/beyond the bet/day7dlc.rpy:3099
translate Spanish chat2_day7dlc_55cb3b9d:

    # GR "good. we agree on something."
    GR "bien. coincidimos en algo."

# game/beyond the bet/day7dlc.rpy:3100
translate Spanish chat2_day7dlc_44bb438d:

    # GR "i don't see a way for us both to live, but..."
    GR "no veo cómo podemos vivir los dos, pero..."

# game/beyond the bet/day7dlc.rpy:3101
translate Spanish chat2_day7dlc_f53c0ecd:

    # GR "well, i'm good at making the impossible possible."
    GR "bueno, soy bueno haciendo posible lo imposible."

# game/beyond the bet/day7dlc.rpy:3104
translate Spanish chat2_day7dlc_c47bc418:

    # player "What impossible things have you made possible?"
    player "¿Qué cosas imposibles has hecho posibles?"

# game/beyond the bet/day7dlc.rpy:3105
translate Spanish chat2_day7dlc_8152e312:

    # GR "uh..."
    GR "eh..."

# game/beyond the bet/day7dlc.rpy:3106
translate Spanish chat2_day7dlc_0ed4fdb0:

    # GR "things... you would not... know about or understand."
    GR "cosas... que no... sabrías ni entenderías."

# game/beyond the bet/day7dlc.rpy:3107
translate Spanish chat2_day7dlc_aced07d8:

    # GR "of course."
    GR "por supuesto."

# game/beyond the bet/day7dlc.rpy:3108
translate Spanish chat2_day7dlc_35216498:

    # GR "there are many things."
    GR "hay muchas cosas."

# game/beyond the bet/day7dlc.rpy:3109
translate Spanish chat2_day7dlc_f61181db:

    # GR "more things than i can describe here."
    GR "más cosas de las que puedo describir aquí."

# game/beyond the bet/day7dlc.rpy:3112
translate Spanish chat2_day7dlc_f52bd6ab:

    # player "Uh huh. Of course. Totally."
    player "Ajá. Claro. Totalmente."

# game/beyond the bet/day7dlc.rpy:3114
translate Spanish chat2_day7dlc_7772a27d_2:

    # GR "..."
    GR "..."

# game/beyond the bet/day7dlc.rpy:3115
translate Spanish chat2_day7dlc_fc76a364:

    # GR "there's a festival tomorrow?"
    GR "¿mañana hay un festival?"

# game/beyond the bet/day7dlc.rpy:3118
translate Spanish chat2_day7dlc_c3181146:

    # player "Some kind of one."
    player "Algo así."

# game/beyond the bet/day7dlc.rpy:3121
translate Spanish chat2_day7dlc_87459f86:

    # player "I've never been before."
    player "Nunca he ido."

# game/beyond the bet/day7dlc.rpy:3123
translate Spanish chat2_day7dlc_ac841e7f:

    # player "I only just heard about it."
    player "Apenas me enteré."

# game/beyond the bet/day7dlc.rpy:3124
translate Spanish chat2_day7dlc_ef8119f3:

    # GR "very well."
    GR "muy bien."

# game/beyond the bet/day7dlc.rpy:3125
translate Spanish chat2_day7dlc_849298db:

    # GR "i shall keep it in mind."
    GR "lo tendré en cuenta."

# game/beyond the bet/day7dlc.rpy:3126
translate Spanish chat2_day7dlc_c21ab773:

    # GR "for now, i am going to collapse on my bed, scream a little in frustration..."
    GR "por ahora, voy a desplomarme en mi cama, gritar con un poco de frustración..."

# game/beyond the bet/day7dlc.rpy:3127
translate Spanish chat2_day7dlc_0c05e500:

    # GR "roll around in anger, then hug azrael."
    GR "revolcarme de rabia y luego abrazar a azrael."

# game/beyond the bet/day7dlc.rpy:3128
translate Spanish chat2_day7dlc_8b8e1f81:

    # GR "good day."
    GR "buen día."

translate Spanish strings:

    # game/beyond the bet/day7dlc.rpy:42
    old "is this the end?"
    new "¿es este el final?"

    # game/beyond the bet/day7dlc.rpy:77
    old "1. <I'm awake!>"
    new "1. <¡Ya desperté!>"

    # game/beyond the bet/day7dlc.rpy:79
    old "2. <Did you miss me?>"
    new "2. <¿Me extrañaste?>"

    # game/beyond the bet/day7dlc.rpy:82
    old "1. <Thanks for making me breakfast.>"
    new "1. <Gracias por prepararme el desayuno.>"

    # game/beyond the bet/day7dlc.rpy:87
    old "1. <The remains of my kitchen say otherwise.>"
    new "1. <Las ruinas de mi cocina dicen lo contrario.>"

    # game/beyond the bet/day7dlc.rpy:95
    old "1. <To my kitchen?>"
    new "1. <¿A mi cocina?>"

    # game/beyond the bet/day7dlc.rpy:99
    old "1. <I dunno.>"
    new "1. <No sé.>"

    # game/beyond the bet/day7dlc.rpy:102
    old "1. <My kitchen can throw some hands when it wants to.>"
    new "1. <Mi cocina sabe repartir golpes cuando quiere.>"

    # game/beyond the bet/day7dlc.rpy:107
    old "1. <Congrats.>"
    new "1. <Felicidades.>"

    # game/beyond the bet/day7dlc.rpy:110
    old "1. <Casper, conqueror of kitchens.>"
    new "1. <Casper, conquistador de cocinas.>"

    # game/beyond the bet/day7dlc.rpy:116
    old "1. <Oh, oh. Put me as a reference!>"
    new "1. <Oh, oh. ¡Ponme de referencia!>"

    # game/beyond the bet/day7dlc.rpy:122
    old "1. <I'm scared of phone calls. I wouldn't pick up.>"
    new "1. <Me dan miedo las llamadas. No contestaría.>"

    # game/beyond the bet/day7dlc.rpy:125
    old "2. <I'd say your track record work-wise is a little iffy.>"
    new "2. <Diría que tu historial laboral es un poco dudoso.>"

    # game/beyond the bet/day7dlc.rpy:129
    old "1. <I mean, you're not doing a very good job with me, are you?>"
    new "1. <O sea, no estás haciendo un muy buen trabajo conmigo, ¿verdad?>"

    # game/beyond the bet/day7dlc.rpy:132
    old "3. <I'd put on a funny voice and pretend \nthey called the wrong number.>"
    new "3. <Pondría una voz graciosa y fingiría que se equivocaron de número.>"

    # game/beyond the bet/day7dlc.rpy:141
    old "2. <I still want to thank you.>"
    new "2. <Aun así quiero agradecerte.>"

    # game/beyond the bet/day7dlc.rpy:144
    old "1. <I haven't had someone cook for me in years.>"
    new "1. <Hace años que nadie cocina para mí.>"

    # game/beyond the bet/day7dlc.rpy:148
    old "1. <In what way?>"
    new "1. <¿En qué sentido?>"

    # game/beyond the bet/day7dlc.rpy:153
    old "1. <A couple of days ago you thought I was an idiot.>"
    new "1. <Hace un par de días pensabas que yo era [arti_2] idiota.>"

    # game/beyond the bet/day7dlc.rpy:157
    old "1. <Wow.>"
    new "1. <Wow.>"

    # game/beyond the bet/day7dlc.rpy:160
    old "1. <You're a bigger idiot.>"
    new "1. <Tú eres más idiota.>"

    # game/beyond the bet/day7dlc.rpy:165
    old "1. <...Oh.>"
    new "1. <...Oh.>"

    # game/beyond the bet/day7dlc.rpy:168
    old "1. <Well, thanks Casper.>"
    new "1. <Bueno, gracias, Casper.>"

    # game/beyond the bet/day7dlc.rpy:171
    old "1. <That's nice of you to say.>"
    new "1. <Qué amable que lo digas.>"

    # game/beyond the bet/day7dlc.rpy:174
    old "1. <I'd like to try cooking for you, sometime.>"
    new "1. <Me gustaría intentar cocinar para ti, algún día.>"

    # game/beyond the bet/day7dlc.rpy:178
    old "1. <I'd make something super spicy.>"
    new "1. <Haría algo súper picante.>"

    # game/beyond the bet/day7dlc.rpy:182
    old "1. <How spicy are we talking?>"
    new "1. <¿De qué nivel de picante estamos hablando?>"

    # game/beyond the bet/day7dlc.rpy:187
    old "1. <Not bad, not bad.>"
    new "1. <Nada mal, nada mal.>"

    # game/beyond the bet/day7dlc.rpy:190
    old "1. <Alright, I'll cook you something that'll make your tongue fall off :D>"
    new "1. <Muy bien, te cocinaré algo que hará que se te caiga la lengua :D>"

    # game/beyond the bet/day7dlc.rpy:195
    old "1. <For?>"
    new "1. <¿Para qué?>"

    # game/beyond the bet/day7dlc.rpy:202
    old "1. <Fine.>"
    new "1. <Está bien.>"

    # game/beyond the bet/day7dlc.rpy:205
    old "1. <I'll spare your tongue... this time.>"
    new "1. <Perdonaré tu lengua... esta vez.>"

    # game/beyond the bet/day7dlc.rpy:208
    old "1. <But you better watch it, pretty boy.>"
    new "1. <Pero más te vale tener cuidado, chico bonito.>"

    # game/beyond the bet/day7dlc.rpy:211
    old "1. <I'll get you with my cooking one day.>"
    new "1. <Algún día te voy a vencer con mi cocina.>"

    # game/beyond the bet/day7dlc.rpy:216
    old "2. <I want to bake you something sweet!>"
    new "2. <¡Quiero hornearte algo dulce!>"

    # game/beyond the bet/day7dlc.rpy:219
    old "1. <Cake, or muffins, or cookies, maybe?>"
    new "1. <¿Pastel, muffins o galletas, quizás?>"

    # game/beyond the bet/day7dlc.rpy:223
    old "1. <WHAT?>"
    new "1. <¡¿QUÉ?!>"

    # game/beyond the bet/day7dlc.rpy:226
    old "1. <HOW?>"
    new "1. <¿CÓMO?>"

    # game/beyond the bet/day7dlc.rpy:230
    old "1. <I'm sure you could find SOME baked goods!>"
    new "1. <¡Seguro que podrías encontrar ALGO de pan o pasteles!>"

    # game/beyond the bet/day7dlc.rpy:235
    old "1. <What exactly do you EAT?>"
    new "1. <¿Qué COMES exactamente?>"

    # game/beyond the bet/day7dlc.rpy:241
    old "1. <How can the Grim Reaper be such a mess of a man?>"
    new "1. <¿Cómo puede la Parca ser un hombre tan desastroso?>"

    # game/beyond the bet/day7dlc.rpy:245
    old "1. <It's not exactly a balanced diet, is it?>"
    new "1. <No es precisamente una dieta balanceada, ¿o sí?>"

    # game/beyond the bet/day7dlc.rpy:249
    old "1. <Okay, I can't lie, you definitely have a good body.>"
    new "1. <Okey, no te voy a mentir, tienes muy buen cuerpo.>"

    # game/beyond the bet/day7dlc.rpy:252
    old "1. <But you should still eat a vegetable or something every now and then.>"
    new "1. <Pero igual deberías comer una verdura o algo de vez en cuando.>"

    # game/beyond the bet/day7dlc.rpy:256
    old "1. <That's not enough!>"
    new "1. <¡Eso no es suficiente!>"

    # game/beyond the bet/day7dlc.rpy:262
    old "1. <I'm gonna make you eat vegetables, one way or another.>"
    new "1. <Voy a hacer que comas verduras, de una forma u otra.>"

    # game/beyond the bet/day7dlc.rpy:268
    old "2. <Well, I wouldn't mind taking a bite of your eggplant 🍆>"
    new "2. <Pues no me importaría darle un mordisco a tu berenjena 🍆>"

    # game/beyond the bet/day7dlc.rpy:275
    old "1. <Yes. I definitely mean the vegetable. Nothing else. No sir.>"
    new "1. <Sí. Me refiero definitivamente a la verdura. Nada más. No, señor.>"

    # game/beyond the bet/day7dlc.rpy:281
    old "1. <I just said I DID mean the vegetable!>"
    new "1. <¡Acabo de decir que SÍ me refería a la verdura!>"

    # game/beyond the bet/day7dlc.rpy:287
    old "1. <Okay, you caught me, Detective Casper.>"
    new "1. <Okey, me atrapaste, Detective Casper.>"

    # game/beyond the bet/day7dlc.rpy:291
    old "1. <You're so perceptive.>"
    new "1. <Eres muy perspicaz.>"

    # game/beyond the bet/day7dlc.rpy:299
    old "1. <Your eggplant?>"
    new "1. <¿Tu berenjena?>"

    # game/beyond the bet/day7dlc.rpy:305
    old "1. <Are we really having a conversation about your eggplant right now?>"
    new "1. <¿De verdad estamos hablando de tu berenjena ahora mismo?>"

    # game/beyond the bet/day7dlc.rpy:313
    old "1. <That sounds unhealthy.>"
    new "1. <Eso suena poco saludable.>"

    # game/beyond the bet/day7dlc.rpy:319
    old "2. <I want to give you flowers, too.>"
    new "2. <También quiero regalarte flores.>"

    # game/beyond the bet/day7dlc.rpy:324
    old "1. <Did you invent giving flowers as a gift?>"
    new "1. <¿Inventaste tú lo de regalar flores?>"

    # game/beyond the bet/day7dlc.rpy:328
    old "1. <I don't think you did.>"
    new "1. <No creo que lo hayas hecho.>"

    # game/beyond the bet/day7dlc.rpy:332
    old "1. <Okay, that I can agree with.>"
    new "1. <Okey, en eso estoy de acuerdo.>"

    # game/beyond the bet/day7dlc.rpy:335
    old "1. <I doubt anyone will ever be outside my window FLYING with flowers again.>"
    new "1. <Dudo que alguien vuelva a estar frente a mi ventana VOLANDO con flores.>"

    # game/beyond the bet/day7dlc.rpy:340
    old "1. <Trendsetter over here.>"
    new "1. <Aquí tenemos a un creador de tendencias.>"

    # game/beyond the bet/day7dlc.rpy:343
    old "1. <I could get used to this kind of treatment.>"
    new "1. <Podría acostumbrarme a este tipo de trato.>"

    # game/beyond the bet/day7dlc.rpy:346
    old "2. <I'm gonna give you a run for your money.>"
    new "2. <Te voy a dar pelea.>"

    # game/beyond the bet/day7dlc.rpy:349
    old "1. <Keep an eye out your window, Grimmy boy.>"
    new "1. <Vigila tu ventana, Parquita.>"

    # game/beyond the bet/day7dlc.rpy:352
    old "1. <I'm gonna be there any second.>"
    new "1. <Voy a estar ahí en cualquier segundo.>"

    # game/beyond the bet/day7dlc.rpy:356
    old "1. <What?>{#day7dlc_what}"
    new "1. <¿Qué?>{#day7dlc_what}"

    # game/beyond the bet/day7dlc.rpy:359
    old "1. <No windows?>"
    new "1. <¿No tienes ventanas?>"

    # game/beyond the bet/day7dlc.rpy:363
    old "1. <Don't you feel kinda boxed in?>"
    new "1. <¿No te sientes un poco encerrado?>"

    # game/beyond the bet/day7dlc.rpy:370
    old "1. <Surprisingly, I feel as fit as a fiddle.>"
    new "1. <Sorprendentemente, me siento san[letra] como una manzana.>"

    # game/beyond the bet/day7dlc.rpy:377
    old "1. <I'm sure someone smarter than me knows the answer.>"
    new "1. <Seguro que alguien más listo que yo sabe la respuesta.>"

    # game/beyond the bet/day7dlc.rpy:380
    old "1. <But, yeah, I feel... good, actually.>"
    new "1. <Pero sí, me siento... bien, la verdad.>"

    # game/beyond the bet/day7dlc.rpy:385
    old "1. <So, I guess this is it then, right?>"
    new "1. <Entonces, supongo que este es el momento, ¿no?>"

    # game/beyond the bet/day7dlc.rpy:388
    old "1. <Day 7.>"
    new "1. <Día 7.>"

    # game/beyond the bet/day7dlc.rpy:391
    old "1. <You coming to take my soul?>"
    new "1. <¿Vienes a llevarte mi alma?>"

    # game/beyond the bet/day7dlc.rpy:395
    old "1. <Or will I get yours instead :D ?>"
    new "1. <¿O me quedaré yo con la tuya :D ?>"

    # game/beyond the bet/day7dlc.rpy:403
    old "1. <Are you trying to weasel out of our bet?>"
    new "1. <¿Estás intentando escaparte de nuestra apuesta?>"

    # game/beyond the bet/day7dlc.rpy:412
    old "1. <Is it that soulsickness thing? Did you spend too much time here?>"
    new "1. <¿Es lo de la enfermedad del alma? ¿Pasaste demasiado tiempo aquí?>"

    # game/beyond the bet/day7dlc.rpy:415
    old "1. <Now I feel bad for asking you to stay...>"
    new "1. <Ahora me siento mal por haberte pedido que te quedaras...>"

    # game/beyond the bet/day7dlc.rpy:419
    old "1. <What?????>"
    new "1. <¿¿¿Qué???>"

    # game/beyond the bet/day7dlc.rpy:423
    old "1. <Oh.>{#oh_day7}"
    new "1. <Oh.>{#oh_day7}"

    # game/beyond the bet/day7dlc.rpy:428
    old "1. <Casper, you made me worry it was something serious!>"
    new "1. <¡Casper, me hiciste pensar que era algo grave!>"

    # game/beyond the bet/day7dlc.rpy:432
    old "1. <It's a cold!>"
    new "1. <¡Es un resfriado!>"

    # game/beyond the bet/day7dlc.rpy:443
    old "1. <How could you have caught it then???>"
    new "1. <¿¿¿Entonces cómo pudiste contagiarte???>"

    # game/beyond the bet/day7dlc.rpy:446
    old "1. <From sleeping next to me?>"
    new "1. <¿Por dormir a mi lado?>"

    # game/beyond the bet/day7dlc.rpy:451
    old "1. <That seems a little dramatic.>"
    new "1. <Eso suena un poco dramático.>"

    # game/beyond the bet/day7dlc.rpy:456
    old "1. <I know you are.>"
    new "1. <Ya lo sé.>"

    # game/beyond the bet/day7dlc.rpy:459
    old "1. <Trust me, it'll pass.>"
    new "1. <Confía en mí, se te pasará.>"

    # game/beyond the bet/day7dlc.rpy:463
    old "1. <Then I guess I win the bet ;)>"
    new "1. <Entonces supongo que gano la apuesta ;)>"

    # game/beyond the bet/day7dlc.rpy:469
    old "2. <Come here, I'll kiss it better.>"
    new "2. <Ven acá, te lo curo con un beso.>"

    # game/beyond the bet/day7dlc.rpy:474
    old "1. <Have you ever tried it?>"
    new "1. <¿Alguna vez lo has intentado?>"

    # game/beyond the bet/day7dlc.rpy:478
    old "1. <Then it might work!>"
    new "1. <¡Entonces podría funcionar!>"

    # game/beyond the bet/day7dlc.rpy:481
    old "1. <Come on over ;)>"
    new "1. <Ven acá ;)>"

    # game/beyond the bet/day7dlc.rpy:491
    old "1. <That means...>"
    new "1. <Eso significa...>"

    # game/beyond the bet/day7dlc.rpy:495
    old "1. <Your soul is all mine!>"
    new "1. <¡Tu alma es toda mía!>"

    # game/beyond the bet/day7dlc.rpy:506
    old "2. <It's finally soul baby time!>"
    new "2. <¡Por fin es hora del bebé alma!>"

    # game/beyond the bet/day7dlc.rpy:512
    old "1. <Not yet.>"
    new "1. <Todavía no.>"

    # game/beyond the bet/day7dlc.rpy:516
    old "1. <I regularly do the impossible, Grim.>"
    new "1. <Hago lo imposible con regularidad, Parca.>"

    # game/beyond the bet/day7dlc.rpy:521
    old "1. <I don't think you're certain about that.>"
    new "1. <No creo que estés tan seguro de eso.>"

    # game/beyond the bet/day7dlc.rpy:528
    old "1. <What do you mean...?>"
    new "1. <¿A qué te refieres...?>"

    # game/beyond the bet/day7dlc.rpy:531
    old "1. <Won't you stick around if I win...? :(>"
    new "1. <¿No te quedarás si gano...? :(>"

    # game/beyond the bet/day7dlc.rpy:536
    old "1. <HUH?>"
    new "1. <¿EH?>"

    # game/beyond the bet/day7dlc.rpy:538
    old "2. <Wait a second!>"
    new "2. <¡Espera un segundo!>"

    # game/beyond the bet/day7dlc.rpy:541
    old "1. <That's not what I want!>"
    new "1. <¡Eso no es lo que quiero!>"

    # game/beyond the bet/day7dlc.rpy:544
    old "1. <When I said I wanted your soul, I was mostly joking.>"
    new "1. <Cuando dije que quería tu alma, casi todo era broma.>"

    # game/beyond the bet/day7dlc.rpy:547
    old "1. <I don't want you to DIE for me.>"
    new "1. <No quiero que MUERAS por mí.>"

    # game/beyond the bet/day7dlc.rpy:552
    old "1. <Well.>"
    new "1. <Bueno.>"

    # game/beyond the bet/day7dlc.rpy:555
    old "1. <I've decided I don't like our agreement anymore.>"
    new "1. <He decidido que ya no me gusta nuestro acuerdo.>"

    # game/beyond the bet/day7dlc.rpy:559
    old "1. <It matters a lot!>"
    new "1. <¡Importa mucho!>"

    # game/beyond the bet/day7dlc.rpy:563
    old "1. <Come on, I'm giving us both an out!>"
    new "1. <¡Vamos, estoy buscando una salida para los dos!>"

    # game/beyond the bet/day7dlc.rpy:566
    old "1. <I don't want you to die, and I also don't want to die.>"
    new "1. <No quiero que mueras, y tampoco quiero morir yo.>"

    # game/beyond the bet/day7dlc.rpy:569
    old "1. <Let's call it off.>"
    new "1. <Cancelémoslo.>"

    # game/beyond the bet/day7dlc.rpy:577
    old "1. <:(>"
    new "1. <:(>"

    # game/beyond the bet/day7dlc.rpy:580
    old "1. <I don't like this.>"
    new "1. <No me gusta esto.>"

    # game/beyond the bet/day7dlc.rpy:582
    old "2. <But there could be! You don't know for certain.>"
    new "2. <¡Pero podría haberlo! No lo sabes con certeza.>"

    # game/beyond the bet/day7dlc.rpy:588
    old "1. <Stop saying you're gonna die.>"
    new "1. <Deja de decir que te vas a morir.>"

    # game/beyond the bet/day7dlc.rpy:591
    old "1. <I seriously won't let that happen.>"
    new "1. <En serio, no voy a dejar que eso pase.>"

    # game/beyond the bet/day7dlc.rpy:597
    old "1. <How long is that?>"
    new "1. <¿Cuánto tiempo es eso?>"

    # game/beyond the bet/day7dlc.rpy:599
    old "2. <You did say you picked my nickname a long time ago...>"
    new "2. <Sí dijiste que escogiste mi apodo hace mucho tiempo...>"

    # game/beyond the bet/day7dlc.rpy:612
    old "1. <Hmm...>"
    new "1. <Hmm...>"

    # game/beyond the bet/day7dlc.rpy:615
    old "1. <Oh, there was one time, in school...>"
    new "1. <Oh, una vez, en la escuela...>"

    # game/beyond the bet/day7dlc.rpy:618
    old "1. <A friend of mine fell over and scuffed her knee, so I took her to the school nurse.>"
    new "1. <Una amiga mía se cayó y se raspó la rodilla, así que la llevé a la enfermería de la escuela.>"

    # game/beyond the bet/day7dlc.rpy:621
    old "1. <I swear there was so much blood, but by the time we got there it was a scratch.>"
    new "1. <Juro que había muchísima sangre, pero cuando llegamos era solo un rasguño.>"

    # game/beyond the bet/day7dlc.rpy:624
    old "1. <My friend said it must just have been my healing aura :D>"
    new "1. <Mi amiga dijo que seguro era mi aura sanadora :D>"

    # game/beyond the bet/day7dlc.rpy:627
    old "2. <I had a cousin like that!>"
    new "2. <¡Tenía un primo así!>"

    # game/beyond the bet/day7dlc.rpy:630
    old "1. <I went over to hang out with him but when I got there, he had a fever.>"
    new "1. <Fui a pasar el rato con él, pero cuando llegué tenía fiebre.>"

    # game/beyond the bet/day7dlc.rpy:633
    old "1. <So I went to say hi before I left, and then we just kept chatting, \nand he felt totally better by the end of it.>"
    new "1. <Así que fui a saludarlo antes de irme, y terminamos charlando, y para el final ya se sentía totalmente mejor.>"

    # game/beyond the bet/day7dlc.rpy:636
    old "1. <We got to hang out after all!>"
    new "1. <¡Al final sí pudimos pasar el rato!>"

    # game/beyond the bet/day7dlc.rpy:639
    old "3. <There was a stranger on the subway...>"
    new "3. <Había una desconocida en el metro...>"

    # game/beyond the bet/day7dlc.rpy:642
    old "1. <I didn't even get her name.>"
    new "1. <Ni siquiera supe su nombre.>"

    # game/beyond the bet/day7dlc.rpy:645
    old "1. <She was sitting across from me, and she didn't look very well.>"
    new "1. <Estaba sentada frente a mí y no se veía muy bien.>"

    # game/beyond the bet/day7dlc.rpy:648
    old "1. <Actually, she kept looking at me and it was giving me the creeps a little.>"
    new "1. <En realidad, no dejaba de mirarme y me daba un poco de mala espina.>"

    # game/beyond the bet/day7dlc.rpy:651
    old "1. <But when she got off, she thanked me and said that just sitting \nnear me made her feel better.>"
    new "1. <Pero cuando se bajó, me dio las gracias y dijo que con solo sentarse cerca de mí se sintió mejor.>"

    # game/beyond the bet/day7dlc.rpy:654
    old "1. <Still kinda weird but I guess it's... also kinda nice?>"
    new "1. <Sigue siendo medio raro, pero supongo que es... ¿también medio lindo?>"

    # game/beyond the bet/day7dlc.rpy:660
    old "1. <Correct about what?>"
    new "1. <¿Tenías razón en qué?>"

    # game/beyond the bet/day7dlc.rpy:669
    old "1. <I... what?>"
    new "1. <Yo... ¿qué?>"

    # game/beyond the bet/day7dlc.rpy:672
    old "1. <I don't think I have anything amazing like that...>"
    new "1. <No creo tener nada así de increíble...>"

    # game/beyond the bet/day7dlc.rpy:682
    old "1. <So... what does that all mean?>"
    new "1. <Entonces... ¿qué significa todo eso?>"

    # game/beyond the bet/day7dlc.rpy:685
    old "2. <I HAVE SUPERPOWERS?>"
    new "2. <¿¿TENGO SUPERPODERES??>"

    # game/beyond the bet/day7dlc.rpy:689
    old "1. <You have superpowers! That must mean I do, too!>"
    new "1. <¡Tienes superpoderes! ¡Eso debe significar que yo también!>"

    # game/beyond the bet/day7dlc.rpy:695
    old "1. <Can I fly?>"
    new "1. <¿Puedo volar?>"

    # game/beyond the bet/day7dlc.rpy:699
    old "1. <Can I go invisible?>"
    new "1. <¿Puedo volverme invisible?>"

    # game/beyond the bet/day7dlc.rpy:703
    old "1. <Can I run suuuuuper fast?>"
    new "1. <¿Puedo correr súúúper rápido?>"

    # game/beyond the bet/day7dlc.rpy:707
    old "1. <Okay.>"
    new "1. <Okey.>"

    # game/beyond the bet/day7dlc.rpy:710
    old "1. <I just ran around my room.>"
    new "1. <Acabo de correr por mi cuarto.>"

    # game/beyond the bet/day7dlc.rpy:713
    old "1. <It was at a normal to less than normal speed.>"
    new "1. <Fue a una velocidad normal o menos que normal.>"

    # game/beyond the bet/day7dlc.rpy:717
    old "1. <That's a lame superpower!>"
    new "1. <¡Qué superpoder tan malo!>"

    # game/beyond the bet/day7dlc.rpy:722
    old "1. <I think that power only works on you, Grim.>"
    new "1. <Creo que ese poder solo funciona contigo, Parca.>"

    # game/beyond the bet/day7dlc.rpy:732
    old "1. <This is insane.>"
    new "1. <Esto es una locura.>"

    # game/beyond the bet/day7dlc.rpy:737
    old "1. <I dunno if that's the only reason.>"
    new "1. <No sé si esa sea la única razón.>"

    # game/beyond the bet/day7dlc.rpy:740
    old "1. <I think you just like me too much to kill me.>"
    new "1. <Creo que simplemente te gusto demasiado como para matarme.>"

    # game/beyond the bet/day7dlc.rpy:746
    old "2. <Like, really?>"
    new "2. <¿Pero en serio?>"

    # game/beyond the bet/day7dlc.rpy:750
    old "1. <Really really?>"
    new "1. <¿En serio en serio?>"

    # game/beyond the bet/day7dlc.rpy:755
    old "1. <Are you sure, though?>"
    new "1. <¿Pero seguro?>"

    # game/beyond the bet/day7dlc.rpy:758
    old "1. <Like...>"
    new "1. <Como...>"

    # game/beyond the bet/day7dlc.rpy:761
    old "1. <I know I'm hard to kill, but maybe this whole healing thing's just luck.>"
    new "1. <Sé que soy difícil de matar, pero quizá esto de la sanación es pura suerte.>"

    # game/beyond the bet/day7dlc.rpy:771
    old "1. <Here I thought you just liked me a lot :(>"
    new "1. <Yo que pensaba que solo te gustaba mucho :(>"

    # game/beyond the bet/day7dlc.rpy:783
    old "1. <I could always give you some.>"
    new "1. <Yo te puedo dar un poco.>"

    # game/beyond the bet/day7dlc.rpy:786
    old "1. <I'll nurse you back to health.>"
    new "1. <Te cuidaré hasta que te recuperes.>"

    # game/beyond the bet/day7dlc.rpy:791
    old "1. <Are we that different, deep down?>"
    new "1. <¿Somos tan distintos en el fondo?>"

    # game/beyond the bet/day7dlc.rpy:793
    old "2. <We have all the same parts, don't we?>"
    new "2. <Tenemos las mismas partes, ¿no?>"

    # game/beyond the bet/day7dlc.rpy:797
    old "1. <Oh? That's certainly one way of putting it...>"
    new "1. <¿Ah, sí? Esa es una forma de decirlo, sí...>"

    # game/beyond the bet/day7dlc.rpy:800
    old "1. <Seriously, you should work on your phrasing.>"
    new "1. <En serio, deberías trabajar tu forma de expresarte.>"

    # game/beyond the bet/day7dlc.rpy:809
    old "1. <We both know you like it.>"
    new "1. <Ambos sabemos que te gusta.>"

    # game/beyond the bet/day7dlc.rpy:817
    old "1. <Wait, what if normal medicine made you, like, mortal?>"
    new "1. <Espera, ¿y si la medicina normal te volviera, no sé, mortal?>"

    # game/beyond the bet/day7dlc.rpy:822
    old "1. <It came to me in a dream.>"
    new "1. <Se me ocurrió en un sueño.>"

    # game/beyond the bet/day7dlc.rpy:825
    old "1. <A vision, pretty much.>"
    new "1. <Una visión, básicamente.>"

    # game/beyond the bet/day7dlc.rpy:832
    old "2. <I have a really good source.>"
    new "2. <Tengo una fuente muy buena.>"

    # game/beyond the bet/day7dlc.rpy:836
    old "1. <This brain of mine.>"
    new "1. <Este cerebro mío.>"

    # game/beyond the bet/day7dlc.rpy:839
    old "1. <Wonderful thing.>"
    new "1. <Maravilloso.>"

    # game/beyond the bet/day7dlc.rpy:842
    old "1. <Huge.>"
    new "1. <Enorme.>"

    # game/beyond the bet/day7dlc.rpy:845
    old "1. <Wrinkly.>"
    new "1. <Arrugado.>"

    # game/beyond the bet/day7dlc.rpy:848
    old "1. <Pulsing.>"
    new "1. <Palpitante.>"

    # game/beyond the bet/day7dlc.rpy:854
    old "1. <But what if it DID work, huh?>"
    new "1. <Pero ¿y si SÍ funcionara, eh?>"

    # game/beyond the bet/day7dlc.rpy:857
    old "1. <No more 'Mr Grim Reaper'.>"
    new "1. <Se acabó el 'Señor Parca'.>"

    # game/beyond the bet/day7dlc.rpy:860
    old "1. <You'd just be Casper.>"
    new "1. <Serías simplemente Casper.>"

    # game/beyond the bet/day7dlc.rpy:865
    old "1. <Would you even survive in the human world?>"
    new "1. <¿Sobrevivirías siquiera en el mundo humano?>"

    # game/beyond the bet/day7dlc.rpy:868
    old "1. <Do you have any practical skills?>"
    new "1. <¿Tienes alguna habilidad práctica?>"

    # game/beyond the bet/day7dlc.rpy:872
    old "1. <Uhh... you know...>"
    new "1. <Eeeh... ya sabes...>"

    # game/beyond the bet/day7dlc.rpy:875
    old "1. <You're good at taking souls...>"
    new "1. <Eres bueno quitando almas...>"

    # game/beyond the bet/day7dlc.rpy:878
    old "1. <Wait, are you even good at that?>"
    new "1. <Espera, ¿acaso eres bueno en eso?>"

    # game/beyond the bet/day7dlc.rpy:881
    old "1. <Day 7 over here and I still have my soul.>"
    new "1. <Llegamos al día 7 y todavía tengo mi alma.>"

    # game/beyond the bet/day7dlc.rpy:886
    old "1. <Let's just pretend that's true for a second.>"
    new "1. <Pretendamos que eso es verdad por un segundo.>"

    # game/beyond the bet/day7dlc.rpy:888
    old "2. <Sure, sure...>"
    new "2. <Claro, claro...>"

    # game/beyond the bet/day7dlc.rpy:892
    old "1. <What else are you good at?>"
    new "1. <¿En qué más eres bueno?>"

    # game/beyond the bet/day7dlc.rpy:895
    old "1. <Hacking computers with virus-filled apps, I guess.>"
    new "1. <Hackear computadoras con aplicaciones llenas de virus, supongo.>"

    # game/beyond the bet/day7dlc.rpy:900
    old "1. <Right...>"
    new "1. <Claro...>"

    # game/beyond the bet/day7dlc.rpy:902
    old "2. <Definitely.>"
    new "2. <Definitivamente.>"

    # game/beyond the bet/day7dlc.rpy:906
    old "1. <Well, that's true.>"
    new "1. <Bueno, eso es cierto.>"

    # game/beyond the bet/day7dlc.rpy:908
    old "2. <Questionable, but go off King.>"
    new "2. <Cuestionable, pero adelante, rey.>"

    # game/beyond the bet/day7dlc.rpy:915
    old "1. <Who tells you that?>"
    new "1. <¿Quién te dice eso?>"

    # game/beyond the bet/day7dlc.rpy:920
    old "1. <Okay but that's not a skill.>"
    new "1. <Okey, pero eso no es una habilidad.>"

    # game/beyond the bet/day7dlc.rpy:923
    old "1. <What would you even do as a job?>"
    new "1. <¿Qué harías siquiera como trabajo?>"

    # game/beyond the bet/day7dlc.rpy:927
    old "1. <Could you even get a job? There's no proof you even exist, right?>"
    new "1. <¿Podrías siquiera conseguir un trabajo? No hay pruebas de que existas, ¿verdad?>"

    # game/beyond the bet/day7dlc.rpy:933
    old "1. <That's mega illegal, but I respect it.>"
    new "1. <Eso es mega ilegal, pero lo respeto.>"

    # game/beyond the bet/day7dlc.rpy:935
    old "2. <Right, it's that easy.>"
    new "2. <Claro, así de fácil.>"

    # game/beyond the bet/day7dlc.rpy:944
    old "1. <You'd start out flipping burgers somewhere greasy.>"
    new "1. <Empezarías volteando hamburguesas en algún local grasiento.>"

    # game/beyond the bet/day7dlc.rpy:947
    old "1. <You can't just walk in and get a job as a CEO.>"
    new "1. <No puedes simplemente entrar y conseguir un trabajo de director ejecutivo.>"

    # game/beyond the bet/day7dlc.rpy:952
    old "1. <Maybe fifty years ago.>"
    new "1. <Quizá hace cincuenta años.>"

    # game/beyond the bet/day7dlc.rpy:954
    old "2. <Uh huh, of course.>"
    new "2. <Ajá, claro.>"

    # game/beyond the bet/day7dlc.rpy:957
    old "1. <I guess you could be a model or something.>"
    new "1. <Supongo que podrías ser modelo o algo así.>"

    # game/beyond the bet/day7dlc.rpy:963
    old "1. <Find what unfair?>"
    new "1. <¿Qué cosa es injusta?>"

    # game/beyond the bet/day7dlc.rpy:968
    old "1. <You're such a piece of work, you know that?>"
    new "1. <Eres todo un personaje, ¿lo sabías?>"

    # game/beyond the bet/day7dlc.rpy:973
    old "2. <Maybe stick with being a Grim Reaper.>"
    new "2. <Quizá mejor quédate de Parca.>"

    # game/beyond the bet/day7dlc.rpy:978
    old "2. <I wouldn't mind fiddling around inside you >:D>"
    new "2. <A mí no me importaría hurgar dentro de ti >:D>"

    # game/beyond the bet/day7dlc.rpy:982
    old "1. <You know. For science.>"
    new "1. <Ya sabes. Por la ciencia.>"

    # game/beyond the bet/day7dlc.rpy:985
    old "1. <I do consider myself something of a scientist.>"
    new "1. <Yo me considero algo así como [arti_2] científic[letra].>"

    # game/beyond the bet/day7dlc.rpy:989
    old "1. <Not to toot my own horn or anything...>"
    new "1. <Sin ánimo de presumir...>"

    # game/beyond the bet/day7dlc.rpy:992
    old "1. <But I'm certain that you'd forget about feeling sick once I'm done with you.>"
    new "1. <Pero estoy segur[letra] de que olvidarías que estás enfermo una vez que termine contigo.>"

    # game/beyond the bet/day7dlc.rpy:996
    old "1. <I always know I'm hitting the right notes when you bring out the caps.>"
    new "1. <Siempre sé que estoy dando en el blanco cuando sacas las mayúsculas.>"

    # game/beyond the bet/day7dlc.rpy:999
    old "1. <Maybe I am ;)>"
    new "1. <Quizá sí ;)>"

    # game/beyond the bet/day7dlc.rpy:1002
    old "1. <Would you like that?>"
    new "1. <¿Te gustaría?>"

    # game/beyond the bet/day7dlc.rpy:1007
    old "1. <Well, yeah.>"
    new "1. <Bueno, sí.>"

    # game/beyond the bet/day7dlc.rpy:1010
    old "1. <That's the perfect time to bend over the Grim Reaper, right? 😇 >"
    new "1. <Ese es el momento perfecto para doblegar a la Parca, ¿no? 😇>"

    # game/beyond the bet/day7dlc.rpy:1023
    old "1. <Who's to say I'm not already addicted?>"
    new "1. <¿Y si ya lo estoy?>"

    # game/beyond the bet/day7dlc.rpy:1028
    old "1. <Me consuming your body?>"
    new "1. <¿Yo consumiendo tu cuerpo?>"

    # game/beyond the bet/day7dlc.rpy:1034
    old "1. <Then I guess we'll just have to throw the bet to the side, and I'll keep you.>"
    new "1. <Entonces supongo que tendremos que dejar la apuesta de lado, y me quedaré contigo.>"

    # game/beyond the bet/day7dlc.rpy:1047
    old "1. <:)>"
    new "1. <:)>"

    # game/beyond the bet/day7dlc.rpy:1050
    old "3. <I can be your learning experience ;)>"
    new "3. <Puedo ser tu experiencia de aprendizaje ;)>"

    # game/beyond the bet/day7dlc.rpy:1053
    old "1. <We can come compare notes... and I'll let you explore whatever you want.>"
    new "1. <Podemos venir a comparar notas... y te dejaré explorar lo que quieras.>"

    # game/beyond the bet/day7dlc.rpy:1057
    old "1. <Maybe.>"
    new "1. <Quizá.>"

    # game/beyond the bet/day7dlc.rpy:1060
    old "1. <I might be.>"
    new "1. <Podría ser.>"

    # game/beyond the bet/day7dlc.rpy:1064
    old "1. <Checking my calendar... ah, yes, the rest of my life was SUPPOSED to end today.>"
    new "1. <Déjame revisar mi calendario... ah, sí, se SUPONÍA que el resto de mi vida terminaba hoy.>"

    # game/beyond the bet/day7dlc.rpy:1067
    old "1. <So I think I could deal with that.>"
    new "1. <Así que creo que podría lidiar con eso.>"

    # game/beyond the bet/day7dlc.rpy:1071
    old "1. <Maaaaaybe.>"
    new "1. <Quizááás.>"

    # game/beyond the bet/day7dlc.rpy:1074
    old "1. <Just saying, if you were curious about how we're different and how we're the same...>"
    new "1. <Solo digo, si tenías curiosidad por cómo somos diferentes y cómo somos iguales...>"

    # game/beyond the bet/day7dlc.rpy:1077
    old "1. <I wouldn't mind showing you.>"
    new "1. <No me importaría mostrarte.>"

    # game/beyond the bet/day7dlc.rpy:1080
    old "1. <We can find a lot to explore together, I'm sure ;)>"
    new "1. <Seguro que podemos encontrar mucho que explorar juntos ;)>"

    # game/beyond the bet/day7dlc.rpy:1085
    old "1. <Anything and everything you'd like.>"
    new "1. <Todo lo que quieras.>"

    # game/beyond the bet/day7dlc.rpy:1088
    old "1. <Why don't YOU tell me what you want to do, lover boy?>"
    new "1. <¿Por qué no me dices TÚ qué quieres hacer, galán?>"

    # game/beyond the bet/day7dlc.rpy:1095
    old "1. <Let's roleplay a little here.>"
    new "1. <Hagamos un poco de roleplay.>"

    # game/beyond the bet/day7dlc.rpy:1098
    old "1. <What if I was a reaper, too? Or you were human?>"
    new "1. <¿Y si yo también fuera una parca? ¿O si tú fueras humano?>"

    # game/beyond the bet/day7dlc.rpy:1101
    old "1. <Then what would you want?>"
    new "1. <Entonces, ¿qué te gustaría?>"

    # game/beyond the bet/day7dlc.rpy:1112
    old "1. <Right, right.>"
    new "1. <Claro, claro.>"

    # game/beyond the bet/day7dlc.rpy:1115
    old "1. <My Little Reaper doesn't REALLY want to join me in bed, of course.>"
    new "1. <Mi Parquita no quiere DE VERDAD meterse en la cama conmigo, claro.>"

    # game/beyond the bet/day7dlc.rpy:1119
    old "1. <Oh?>"
    new "1. <¿Ah, sí?>"

    # game/beyond the bet/day7dlc.rpy:1122
    old "1. <So you disagree?>"
    new "1. <¿Entonces no estás de acuerdo?>"

    # game/beyond the bet/day7dlc.rpy:1129
    old "1. <I know what I'd LIKE to do to you, though.>"
    new "1. <Yo sí sé lo que me GUSTARÍA hacerte a ti.>"

    # game/beyond the bet/day7dlc.rpy:1135
    old "2. <Well, maybe you should fiddle some more.>"
    new "2. <Bueno, quizá deberías hurgar un poco más.>"

    # game/beyond the bet/day7dlc.rpy:1140
    old "1. <I bet you've seen a lot of that stuff...>"
    new "1. <Apuesto a que has visto mucho de eso...>"

    # game/beyond the bet/day7dlc.rpy:1144
    old "1. <Does it get easier?>"
    new "1. <¿Se vuelve más fácil?>"

    # game/beyond the bet/day7dlc.rpy:1152
    old "1. <I'm not sure I could do it.>"
    new "1. <No sé si podría hacerlo.>"

    # game/beyond the bet/day7dlc.rpy:1155
    old "1. <Blood and stuff grosses me outttt.>"
    new "1. <La sangre y esas cosas me dan muuucho asco.>"

    # game/beyond the bet/day7dlc.rpy:1159
    old "1. <I thought you'd laugh at me for that.>"
    new "1. <Pensé que te reirías de mí por eso.>"

    # game/beyond the bet/day7dlc.rpy:1165
    old "1. <Sometimes you're very reasonable.>"
    new "1. <A veces eres muy razonable.>"

    # game/beyond the bet/day7dlc.rpy:1169
    old "1. <And other times you say things like that.>"
    new "1. <Y otras veces dices cosas como esa.>"

    # game/beyond the bet/day7dlc.rpy:1172
    old "1. <Well, I guess it's true.>"
    new "1. <Bueno, supongo que es cierto.>"

    # game/beyond the bet/day7dlc.rpy:1176
    old "2. <I'm pretty numb to that kind of stuff myself.>"
    new "2. <A mí ese tipo de cosas ya casi no me afectan.>"

    # game/beyond the bet/day7dlc.rpy:1179
    old "1. <Seen a few too many horror movies in my days.>"
    new "1. <He visto unas cuantas películas de terror de más en mi vida.>"

    # game/beyond the bet/day7dlc.rpy:1184
    old "1. <Some of them are pretty realistic.>"
    new "1. <Algunas son bastante realistas.>"

    # game/beyond the bet/day7dlc.rpy:1187
    old "1. <You might like them.>"
    new "1. <Quizá te gusten.>"

    # game/beyond the bet/day7dlc.rpy:1193
    old "1. <Oh man.>"
    new "1. <Ay, hombre.>"

    # game/beyond the bet/day7dlc.rpy:1196
    old "1. <Horror movie night?>"
    new "1. <¿Noche de películas de terror?>"

    # game/beyond the bet/day7dlc.rpy:1199
    old "1. <Horror movie night.>"
    new "1. <Noche de películas de terror.>"

    # game/beyond the bet/day7dlc.rpy:1202
    old "1. <I'm gonna find something that'll make you cling to me in fear.>"
    new "1. <Voy a encontrar algo que te haga aferrarte a mí del miedo.>"

    # game/beyond the bet/day7dlc.rpy:1207
    old "1. <Would you like that, Grimmy :D ?>"
    new "1. <¿Te gustaría, Parquita :D ?>"

    # game/beyond the bet/day7dlc.rpy:1212
    old "1. <But I like this topic!>"
    new "1. <¡Pero me gusta este tema!>"

    # game/beyond the bet/day7dlc.rpy:1219
    old "1. <You just said you've never had it!>"
    new "1. <¡Acabas de decir que nunca la has probado!>"

    # game/beyond the bet/day7dlc.rpy:1223
    old "1. <It's really not.>"
    new "1. <La verdad es que no.>"

    # game/beyond the bet/day7dlc.rpy:1226
    old "1. <Most of it tastes pretty terrible.>"
    new "1. <La mayoría sabe bastante mal.>"

    # game/beyond the bet/day7dlc.rpy:1234
    old "2. <I'm practically a doctor.>"
    new "2. <Soy casi [arti_2] [doctor].>"

    # game/beyond the bet/day7dlc.rpy:1238
    old "1. <I just think I'd make a pretty good doctor.>"
    new "1. <Solo creo que sería [arti_2] [doctor] bastante [buen].>"

    # game/beyond the bet/day7dlc.rpy:1242
    old "1. <Well, no.>"
    new "1. <Bueno, no.>"

    # game/beyond the bet/day7dlc.rpy:1245
    old "1. <Not literally.>"
    new "1. <No literalmente.>"

    # game/beyond the bet/day7dlc.rpy:1248
    old "1. <But I do still feel like I'd do a good job of doctoring you.>"
    new "1. <Pero igual siento que haría un buen trabajo curándote.>"

    # game/beyond the bet/day7dlc.rpy:1252
    old "1. <If you're feeling too weak to take the medicine, I can help you take it.>"
    new "1. <Si te sientes demasiado débil para tomar la medicina, puedo ayudarte a tomarla.>"

    # game/beyond the bet/day7dlc.rpy:1255
    old "1. <Just let me guide your mouth open, okay?>"
    new "1. <Solo déjame guiar tu boca para que la abras, ¿okey?>"

    # game/beyond the bet/day7dlc.rpy:1259
    old "1. <I'll be gentle with you, okay?>"
    new "1. <Seré delicad[letra] contigo, ¿okey?>"

    # game/beyond the bet/day7dlc.rpy:1263
    old "1. <Malpractice? No, no, no...>"
    new "1. <¿Negligencia? No, no, no...>"

    # game/beyond the bet/day7dlc.rpy:1266
    old "1. <I'll be totally professional, ethical and totally nothing bad will happen.>"
    new "1. <Seré totalmente profesional, étic[letra], y no pasará absolutamente nada malo.>"

    # game/beyond the bet/day7dlc.rpy:1269
    old "1. <Wait, do you have hospitals in the Underworld, anyway?>"
    new "1. <Espera, ¿tienen hospitales en el Inframundo, por cierto?>"

    # game/beyond the bet/day7dlc.rpy:1274
    old "1. <What about injured?>"
    new "1. <¿Y qué pasa con los heridos?>"

    # game/beyond the bet/day7dlc.rpy:1278
    old "1. <That doesn't seem fair.>"
    new "1. <Eso no parece justo.>"

    # game/beyond the bet/day7dlc.rpy:1283
    old "1. <Did you ever get hit by a plane while flying?>"
    new "1. <¿Alguna vez te golpeó un avión mientras volabas?>"

    # game/beyond the bet/day7dlc.rpy:1287
    old "1. <You fly, right?>"
    new "1. <Tú vuelas, ¿no?>"

    # game/beyond the bet/day7dlc.rpy:1290
    old "1. <And you make people think you're a bird. Did you ever accidentally fly into a plane?>"
    new "1. <Y haces que la gente piense que eres un pájaro. ¿Alguna vez chocaste sin querer con un avión?>"

    # game/beyond the bet/day7dlc.rpy:1294
    old "1. <Is it a bird? Is it a plane???>"
    new "1. <¿Es un pájaro? ¿¿¿Es un avión???>"

    # game/beyond the bet/day7dlc.rpy:1297
    old "1. <Nope, just Casper flying around again.>"
    new "1. <Nop, es solo Casper volando otra vez.>"

    # game/beyond the bet/day7dlc.rpy:1301
    old "1. <I dunno, but you gotta watch out for those planes, man.>"
    new "1. <No sé, pero hay que tener cuidado con los aviones, hombre.>"

    # game/beyond the bet/day7dlc.rpy:1304
    old "1. <They're killer.>"
    new "1. <Son letales.>"

    # game/beyond the bet/day7dlc.rpy:1309
    old "1. <Good. Always best to be ready.>"
    new "1. <Bien. Siempre es mejor tomar precauciones.>"

    # game/beyond the bet/day7dlc.rpy:1313
    old "2. <Wait, who else lives in the Underworld for the hospitals to be for?>"
    new "2. <Espera, ¿quién más vive en el Inframundo para que haya hospitales?>"

    # game/beyond the bet/day7dlc.rpy:1324
    old "1. <You do realize that humans don't even know if the Underworld exists, right?>"
    new "1. <¿Te das cuenta de que los humanos ni siquiera saben si el Inframundo existe, verdad?>"

    # game/beyond the bet/day7dlc.rpy:1327
    old "1. <Like that's a hot debate.>"
    new "1. <O sea, es un debate candente.>"

    # game/beyond the bet/day7dlc.rpy:1330
    old "1. <You're out here acting like it's obvious, and that OF COURSE there's gods there!>"
    new "1. <¡Tú actúas como si fuera obvio, y como si POR SUPUESTO hubiera dioses allí!>"

    # game/beyond the bet/day7dlc.rpy:1335
    old "1. <Dude.>"
    new "1. <Amigo.>"

    # game/beyond the bet/day7dlc.rpy:1338
    old "1. <I'm getting all the behind the scenes info on how the world works.>"
    new "1. <Me estoy enterando de todo lo que pasa tras bambalinas sobre cómo funciona el mundo.>"

    # game/beyond the bet/day7dlc.rpy:1341
    old "1. <That's awesome.>"
    new "1. <Eso es genial.>"

    # game/beyond the bet/day7dlc.rpy:1348
    old "2. <Practically yes.>"
    new "2. <Prácticamente sí.>"

    # game/beyond the bet/day7dlc.rpy:1353
    old "1. <No.>"
    new "1. <No.>"

    # game/beyond the bet/day7dlc.rpy:1357
    old "1. <I just feel it in my bones.>"
    new "1. <Simplemente lo siento en los huesos.>"

    # game/beyond the bet/day7dlc.rpy:1360
    old "1. <In my soul.>"
    new "1. <En mi alma.>"

    # game/beyond the bet/day7dlc.rpy:1363
    old "1. <I'd make a good doctor.>"
    new "1. <Sería [arti_2] [buen] [doctor].>"

    # game/beyond the bet/day7dlc.rpy:1367
    old "1. <Man, I really have such a good list of talents.>"
    new "1. <Hombre, de verdad tengo una lista de talentos buenísima.>"

    # game/beyond the bet/day7dlc.rpy:1370
    old "1. <Good doctor? Check.>"
    new "1. <¿[buen!c] [doctor]? Listo.>"

    # game/beyond the bet/day7dlc.rpy:1373
    old "1. <Good bullshitter? Correct.>"
    new "1. <¿Talento para soltar tonterías? Correcto.>"

    # game/beyond the bet/day7dlc.rpy:1376
    old "1. <Good looking? Absolutely.>"
    new "1. <¿Buen aspecto? Absolutamente.>"

    # game/beyond the bet/day7dlc.rpy:1383
    old "1. <Fantastic? Amazing? Gorgeous? Smart?>"
    new "1. <¿Fantástic[letra]? ¿Increíble? ¿Guap[letra]? ¿Inteligente?>"

    # game/beyond the bet/day7dlc.rpy:1387
    old "1. <Absurd for you <3>"
    new "1. <Absurd[letra] por ti <3>"

    # game/beyond the bet/day7dlc.rpy:1391
    old "1. <Does anything I say make sense?>"
    new "1. <¿Algo de lo que digo tiene sentido?>"

    # game/beyond the bet/day7dlc.rpy:1396
    old "1. <I do.>"
    new "1. <Yo sí.>"

    # game/beyond the bet/day7dlc.rpy:1399
    old "1. <Let me lay it out for you.>"
    new "1. <Te lo explico.>"

    # game/beyond the bet/day7dlc.rpy:1403
    old "1. <In the beginning, there was a little reaper...>"
    new "1. <Al principio, había una parquita...>"

    # game/beyond the bet/day7dlc.rpy:1406
    old "1. <He was so lonely, sitting by himself in his windowless home deep in the underworld...>"
    new "1. <Estaba tan solo, sentado a solas en su casa sin ventanas en lo profundo del inframundo...>"

    # game/beyond the bet/day7dlc.rpy:1409
    old "1. <He wondered if this was all life was - sitting, waiting...>"
    new "1. <Se preguntaba si la vida era solo eso: sentarse y esperar...>"

    # game/beyond the bet/day7dlc.rpy:1412
    old "1. <Until he was given a job. A very important job...>"
    new "1. <Hasta que le dieron un trabajo. Un trabajo muy importante...>"

    # game/beyond the bet/day7dlc.rpy:1415
    old "1. <To take the soul of a very important mortal...>"
    new "1. <Tomar el alma de un mortal muy importante...>"

    # game/beyond the bet/day7dlc.rpy:1418
    old "1. <He accepted, because he must, and went off to take the soul. Just another job...>"
    new "1. <Aceptó, porque debía, y se fue a tomar el alma. Un trabajo más...>"

    # game/beyond the bet/day7dlc.rpy:1421
    old "1. <Until he laid eyes on the most wonderful mortal he'd ever seen.>"
    new "1. <Hasta que posó los ojos en [arti] mortal más maravillos[letra] que había visto jamás.>"

    # game/beyond the bet/day7dlc.rpy:1425
    old "1. <The most wonderful person, full stop...>"
    new "1. <La persona más maravillosa, punto final...>"

    # game/beyond the bet/day7dlc.rpy:1429
    old "1. <And he instantly fell in love!>"
    new "1. <¡Y se enamoró al instante!>"

    # game/beyond the bet/day7dlc.rpy:1432
    old "1. <He could not keep away, and grew desperate to talk to [her]...>"
    new "1. <No podía mantenerse alejado, y se desesperó por hablarle...>"

    # game/beyond the bet/day7dlc.rpy:1435
    old "1. <And so, created an app where he could do just that...>"
    new "1. <Y así, creó una aplicación donde podría hacer justamente eso...>"

    # game/beyond the bet/day7dlc.rpy:1438
    old "1. <It was already over for him. He'd never be able to go back to that darkness.>"
    new "1. <Ya estaba perdido. Nunca podría volver a esa oscuridad.>"

    # game/beyond the bet/day7dlc.rpy:1441
    old "1. <He craved the sunlight much too badly.>"
    new "1. <Anhelaba demasiado la luz del sol.>"

    # game/beyond the bet/day7dlc.rpy:1444
    old "1. <The end!>"
    new "1. <¡Fin!>"

    # game/beyond the bet/day7dlc.rpy:1450
    old "1. <It's your story! What do you think?>"
    new "1. <¡Es tu historia! ¿Qué te parece?>"

    # game/beyond the bet/day7dlc.rpy:1453
    old "1. <I took some creative liberties, but I kinda like it.>"
    new "1. <Me tomé algunas libertades creativas, pero me gusta bastante.>"

    # game/beyond the bet/day7dlc.rpy:1458
    old "1. <I might clean this up and make a book out of it.>"
    new "1. <Quizá la pula un poco y haga un libro con ella.>"

    # game/beyond the bet/day7dlc.rpy:1461
    old "1. <What do you think?>"
    new "1. <¿Qué piensas?>"

    # game/beyond the bet/day7dlc.rpy:1469
    old "1. <Uh huh. That's why you were here last night.>"
    new "1. <Ajá. Por eso estuviste aquí anoche.>"

    # game/beyond the bet/day7dlc.rpy:1474
    old "1. <Should I quit my day job and become an author?>"
    new "1. <¿Debería dejar mi trabajo y dedicarme a escribir libros?>"

    # game/beyond the bet/day7dlc.rpy:1478
    old "1. <Okay, but like...>"
    new "1. <Okey, pero o sea...>"

    # game/beyond the bet/day7dlc.rpy:1481
    old "1. <I think 100 percent of people would take it as a work of fiction.>"
    new "1. <Creo que el 100 por ciento de la gente lo tomaría como una obra de ficción.>"

    # game/beyond the bet/day7dlc.rpy:1488
    old "1. <Hey, answer this, okay?>"
    new "1. <Oye, contesta, ¿okey?>"

    # game/beyond the bet/day7dlc.rpy:1491
    old "1. <{i}Call Casper.{/i}>"
    new "1. <{i}Llamar a Casper.{/i}>"

    # game/beyond the bet/day7dlc.rpy:1537
    old "1. <Are... you in your pajamas?>"
    new "1. <¿Estás... en pijama?>"

    # game/beyond the bet/day7dlc.rpy:1544
    old "1. <Oh my god.>"
    new "1. <Dios mío.>"

    # game/beyond the bet/day7dlc.rpy:1547
    old "1. <You are so cute.>"
    new "1. <Eres tan lindo.>"

    # game/beyond the bet/day7dlc.rpy:1561
    old "1. <To be fair, you saw me sick.>"
    new "1. <Para ser just[letra], tú me viste enferm[letra].>"

    # game/beyond the bet/day7dlc.rpy:1564
    old "1. <You should've stayed at my place!>"
    new "1. <¡Deberías haberte quedado en mi casa!>"

    # game/beyond the bet/day7dlc.rpy:1570
    old "1. <You can still be capable and {i}let{/i} people help you.>"
    new "1. <Puedes ser capaz y {i}dejar{/i} que la gente te ayude.>"

    # game/beyond the bet/day7dlc.rpy:1573
    old "1. <If you want, you can depend on me a little, Casper.>"
    new "1. <Si quieres, puedes depender un poco de mí, Casper.>"

    # game/beyond the bet/day7dlc.rpy:1595
    old "1. <Sucks, huh?>"
    new "1. <Qué fastidio, ¿eh?>"

    # game/beyond the bet/day7dlc.rpy:1599
    old "1. <Well, not much choice.>"
    new "1. <Bueno, no hay mucha opción.>"

    # game/beyond the bet/day7dlc.rpy:1603
    old "1. <Alright, I'm on it.>"
    new "1. <Muy bien, me pongo en ello.>"

    # game/beyond the bet/day7dlc.rpy:1608
    old "1. <Oh, they'll be bowing down to you any second now.>"
    new "1. <Oh, se postrarán ante ti en cualquier momento.>"

    # game/beyond the bet/day7dlc.rpy:1613
    old "2. <Now you can understand why I was in bed \nall day long yesterday.>"
    new "2. <Ahora entiendes por qué estuve en cama todo el día de ayer.>"

    # game/beyond the bet/day7dlc.rpy:1615
    old "1. <Why aren't you in bed, anyway?>"
    new "1. <¿Por qué no estás en la cama, por cierto?>"

    # game/beyond the bet/day7dlc.rpy:1618
    old "1. <Go lay down, I can see the bed from here.>"
    new "1. <Ve a acostarte, puedo ver la cama desde aquí.>"

    # game/beyond the bet/day7dlc.rpy:1624
    old "1. <So?>"
    new "1. <¿Tan?>"

    # game/beyond the bet/day7dlc.rpy:1636
    old "1. <You call me suddenly all the time!>"
    new "1. <¡Tú me llamas de repente todo el tiempo!>"

    # game/beyond the bet/day7dlc.rpy:1639
    old "1. <Can I not just call you because I want to?>"
    new "1. <¿No puedo llamarte simplemente porque quiero?>"

    # game/beyond the bet/day7dlc.rpy:1645
    old "1. <Hey, don't do that!>"
    new "1. <¡Oye, no hagas eso!>"

    # game/beyond the bet/day7dlc.rpy:1647
    old "2. <You spoilsport!>"
    new "2. <¡Aguafiestas!>"

    # game/beyond the bet/day7dlc.rpy:1662
    old "1. <Ah yes, the mighty power of the 'call button'.>"
    new "1. <Ah, sí, el temible poder del 'botón de llamada'.>"

    # game/beyond the bet/day7dlc.rpy:1664
    old "1. <I'm really collecting magical abilities left right \nand center today.>"
    new "1. <Hoy sí que estoy acumulando habilidades mágicas a lo loco.>"

    # game/beyond the bet/day7dlc.rpy:1667
    old "1. <Wait, is that why you can't take my soul?>"
    new "1. <Espera, ¿por eso no puedes tomar mi alma?>"

    # game/beyond the bet/day7dlc.rpy:1670
    old "1. <I'm just that powerful.>"
    new "1. <Soy así de poderos[letra].>"

    # game/beyond the bet/day7dlc.rpy:1676
    old "1. <Or {i}maybe{/i} I'm just that powerful.>"
    new "1. <O {i}quizá{/i} soy así de poderos[letra].>"

    # game/beyond the bet/day7dlc.rpy:1685
    old "1. <Pot meet kettle.>"
    new "1. <Mira quién habla.>"

    # game/beyond the bet/day7dlc.rpy:1687
    old "2. <Funny, coming from you.>"
    new "2. <Qué gracioso, viniendo de ti.>"

    # game/beyond the bet/day7dlc.rpy:1690
    old "2. <I'd always be on call with you.>"
    new "2. <Siempre estaría en llamada contigo.>"

    # game/beyond the bet/day7dlc.rpy:1700
    old "1. <Just because we shouldn't doesn't mean we can't.>"
    new "1. <Que no debamos no significa que no podamos.>"

    # game/beyond the bet/day7dlc.rpy:1703
    old "1. <It's a good idea. Why don't I start now?>"
    new "1. <Es una buena idea. ¿Por qué no empiezo ahora?>"

    # game/beyond the bet/day7dlc.rpy:1708
    old "1. <I wouldn't mind.>"
    new "1. <No me importaría.>"

    # game/beyond the bet/day7dlc.rpy:1710
    old "2. <What if I want that?>"
    new "2. <¿Y si eso es lo que quiero?>"

    # game/beyond the bet/day7dlc.rpy:1713
    old "1. <And you'd be getting lost in me, as well.>"
    new "1. <Y tú también te perderías en mí.>"

    # game/beyond the bet/day7dlc.rpy:1716
    old "1. <I can tell by how you look at me.>"
    new "1. <Lo noto por cómo me miras.>"

    # game/beyond the bet/day7dlc.rpy:1721
    old "1. <Like you've just seen color for the first time.>"
    new "1. <Como si acabaras de ver el color por primera vez.>"

    # game/beyond the bet/day7dlc.rpy:1723
    old "1. <And you aren't quite sure how you could live \nwithout it now.>"
    new "1. <Y no estás muy seguro de cómo podrías vivir sin él ahora.>"

    # game/beyond the bet/day7dlc.rpy:1726
    old "2. <Like you want to devour me.>"
    new "2. <Como si quisieras devorarme.>"

    # game/beyond the bet/day7dlc.rpy:1728
    old "1. <Sometimes it feels like you're undressing \nme with your eyes.>"
    new "1. <A veces siento que me desvistes con la mirada.>"

    # game/beyond the bet/day7dlc.rpy:1731
    old "2. <Like you want to crush me, but also hold me so \ngently at the same time.>"
    new "2. <Como si quisieras aplastarme, pero también abrazarme con tanta delicadeza al mismo tiempo.>"

    # game/beyond the bet/day7dlc.rpy:1733
    old "1. <I frustrate you but you're learning to love it.>"
    new "1. <Te frustro, pero estás aprendiendo a amarlo.>"

    # game/beyond the bet/day7dlc.rpy:1741
    old "3. <I have {i}some{/i} self restraint, Casper.>"
    new "3. <Tengo {i}algo{/i} de autocontrol, Casper.>"

    # game/beyond the bet/day7dlc.rpy:1745
    old "1. <Man, I'm so glad you can't lie. That would be terrifying.>"
    new "1. <Hombre, qué alegría que no puedas mentir. Eso sería aterrador.>"

    # game/beyond the bet/day7dlc.rpy:1752
    old "1. <So, you think I'm scary?>"
    new "1. <Entonces, ¿piensas que doy miedo?>"

    # game/beyond the bet/day7dlc.rpy:1759
    old "1. <As you should.>"
    new "1. <Y con razón.>"

    # game/beyond the bet/day7dlc.rpy:1763
    old "1. <If you could lie, I guess you'd be a little \nless predictable.>"
    new "1. <Si pudieras mentir, supongo que serías un poco menos predecible.>"

    # game/beyond the bet/day7dlc.rpy:1769
    old "1. <You just kinda are.>"
    new "1. <Es que simplemente lo eres.>"

    # game/beyond the bet/day7dlc.rpy:1773
    old "1. <I can make you react however I want.>"
    new "1. <Puedo hacerte reaccionar como quiera.>"

    # game/beyond the bet/day7dlc.rpy:1779
    old "1. <Casper, I seriously love you.>"
    new "1. <Casper, te amo en serio.>"

    # game/beyond the bet/day7dlc.rpy:1781
    old "2. <Who's the cutest guy in the world? You!>"
    new "2. <¿Quién es el chico más lindo del mundo? ¡Tú!>"

    # game/beyond the bet/day7dlc.rpy:1783
    old "3. <I want to do unspeakable things to you.>"
    new "3. <Quiero hacerte cosas que no se pueden decir.>"

    # game/beyond the bet/day7dlc.rpy:1794
    old "1. <See?>"
    new "1. <¿Ves?>"

    # game/beyond the bet/day7dlc.rpy:1799
    old "2. <I would only call... occasionally.>"
    new "2. <Solo llamaría... de vez en cuando.>"

    # game/beyond the bet/day7dlc.rpy:1801
    old "1. <Maybe every...>"
    new "1. <Quizá cada...>"

    # game/beyond the bet/day7dlc.rpy:1804
    old "1. <Ten minutes.>"
    new "1. <Diez minutos.>"

    # game/beyond the bet/day7dlc.rpy:1809
    old "1. <Something tells me you wouldn't mind too much.>"
    new "1. <Algo me dice que no te molestaría tanto.>"

    # game/beyond the bet/day7dlc.rpy:1817
    old "2. <Few hours?>"
    new "2. <¿Unas pocas horas?>"

    # game/beyond the bet/day7dlc.rpy:1822
    old "1. <Hehe. Maybe I'm lying.>"
    new "1. <Jeje. Quizá estoy mintiendo.>"

    # game/beyond the bet/day7dlc.rpy:1825
    old "1. <You know me, such a troublemaker for my little reaper.>"
    new "1. <Ya me conoces, siempre dándole problemas a mi Parquita.>"

    # game/beyond the bet/day7dlc.rpy:1831
    old "3. <Week. Or maybe monthly.>"
    new "3. <¿Cada semana? O quizá cada mes.>"

    # game/beyond the bet/day7dlc.rpy:1835
    old "1. <Awww, Caspy Waspy, don't make that face. \nI'm just kidding!>"
    new "1. <Awww, Caspy Waspy, no pongas esa cara. ¡Es broma!>"

    # game/beyond the bet/day7dlc.rpy:1839
    old "1. <I'd call you like every half an hour, I promise.>"
    new "1. <Te llamaría como cada media hora, lo prometo.>"

    # game/beyond the bet/day7dlc.rpy:1843
    old "1. <You have free time right now.>"
    new "1. <Ahora tienes tiempo libre.>"

    # game/beyond the bet/day7dlc.rpy:1848
    old "2. <I just called you! Don't pout like that, you'll \nmake me feel bad.>"
    new "2. <¡Acabo de llamarte! No hagas pucheros así, me harás sentir mal.>"

    # game/beyond the bet/day7dlc.rpy:1851
    old "1. <Leave the feature on and I'll never stop calling you.>"
    new "1. <Deja la función activada y nunca dejaré de llamarte.>"

    # game/beyond the bet/day7dlc.rpy:1854
    old "1. <Don't you worry your cute little head.>"
    new "1. <No te rompas esa linda cabecita.>"

    # game/beyond the bet/day7dlc.rpy:1858
    old "1. <Also, by the way~>"
    new "1. <Además, por cierto~>"

    # game/beyond the bet/day7dlc.rpy:1861
    old "1. <Hello Azrael!>"
    new "1. <¡Hola, Azrael!>"

    # game/beyond the bet/day7dlc.rpy:1864
    old "1. <Might I say, you are looking rather handsome today!>"
    new "1. <¡Si me permites decirlo, te ves bastante apuesto hoy!>"

    # game/beyond the bet/day7dlc.rpy:1870
    old "2. <I just have to tell you how cute you are!>"
    new "2. <¡Tengo que decirte lo lindo que eres!>"

    # game/beyond the bet/day7dlc.rpy:1876
    old "3. <You are looking nice and cozy there!>"
    new "3. <¡Te ves calentito y cómodo ahí!>"

    # game/beyond the bet/day7dlc.rpy:1881
    old "1. <I wish he was always around when we chat.>"
    new "1. <Ojalá estuviera siempre cerca cuando chateamos.>"

    # game/beyond the bet/day7dlc.rpy:1884
    old "2. <You should cuddle him more often.>"
    new "2. <Deberías abrazarlo más seguido.>"

    # game/beyond the bet/day7dlc.rpy:1897
    old "1. <I think dire might be an overstatement.>"
    new "1. <Creo que 'aciagos' podría ser una exageración.>"

    # game/beyond the bet/day7dlc.rpy:1900
    old "2. <Dire? Grim, it seems pretty mild.>"
    new "2. <¿Aciagos? Parca, no parece para tanto.>"

    # game/beyond the bet/day7dlc.rpy:1907
    old "1. <How long have you had him?>"
    new "1. <¿Hace cuánto lo tienes?>"

    # game/beyond the bet/day7dlc.rpy:1912
    old "1. <That is hardly an answer.>"
    new "1. <Eso no es ni una respuesta.>"

    # game/beyond the bet/day7dlc.rpy:1927
    old "1. <He's still in such good condition!>"
    new "1. <¡Aún está en tan buen estado!>"

    # game/beyond the bet/day7dlc.rpy:1940
    old "1. <Awww, you love him just as much as I love \n[pet_name].>"
    new "1. <Awww, lo quieres tanto como yo quiero a [pet_name].>"

    # game/beyond the bet/day7dlc.rpy:1955
    old "1. <It's nice to know the Grim Reaper can be sentimental.>"
    new "1. <Es lindo saber que la Parca puede ser sentimental.>"

    # game/beyond the bet/day7dlc.rpy:1958
    old "1. <You're not that far from a human, after all.>"
    new "1. <No estás tan lejos de un humano, después de todo.>"

    # game/beyond the bet/day7dlc.rpy:1963
    old "1. <So, did you buy him from a store deep in the pits \nof the Underworld?>"
    new "1. <Entonces, ¿lo compraste en una tienda en lo más profundo del Inframundo?>"

    # game/beyond the bet/day7dlc.rpy:1969
    old "1. <Oh, you bought him here?>"
    new "1. <Oh, ¿lo compraste aquí?>"

    # game/beyond the bet/day7dlc.rpy:1972
    old "1. <I guess that makes sense. He doesn't look very 'hell'-y.>"
    new "1. <Supongo que tiene sentido. No parece muy 'infernal'.>"

    # game/beyond the bet/day7dlc.rpy:1975
    old "2. <Did you get him here? On the... 'mortal plane'?>"
    new "2. <¿Lo conseguiste aquí? ¿En el... 'plano mortal'?>"

    # game/beyond the bet/day7dlc.rpy:1979
    old "1. <Where did you buy him from?>"
    new "1. <¿Dónde lo compraste?>"

    # game/beyond the bet/day7dlc.rpy:1982
    old "1. <Wait, do you even have 'mortal money'?>"
    new "1. <Espera, ¿siquiera tienes 'dinero mortal'?>"

    # game/beyond the bet/day7dlc.rpy:1995
    old "1. <...Did you steal him?>"
    new "1. <...¿Lo robaste?>"

    # game/beyond the bet/day7dlc.rpy:2000
    old "1. <Okay, I'm confused then.>"
    new "1. <Okey, entonces estoy confundid[letra].>"

    # game/beyond the bet/day7dlc.rpy:2009
    old "1. <Gifted to you? From... someone like me?>"
    new "1. <¿Te lo regalaron? ¿Alguien como yo... te lo regaló?>"

    # game/beyond the bet/day7dlc.rpy:2012
    old "1. <Wow. Suddenly feeling less special here.>"
    new "1. <Wow. De repente me siento menos especial.>"

    # game/beyond the bet/day7dlc.rpy:2014
    old "2. <Okay, I wanna know more about that.>"
    new "2. <Okey, quiero saber más sobre eso.>"

    # game/beyond the bet/day7dlc.rpy:2016
    old "3. <Here I thought I was your first...>"
    new "3. <Y yo que pensaba que era [arti] primer[letra]...>"

    # game/beyond the bet/day7dlc.rpy:2021
    old "1. <A child just gave you their toy?>"
    new "1. <¿Un niño simplemente te dio su juguete?>"

    # game/beyond the bet/day7dlc.rpy:2029
    old "1. <Of course I'll listen.>"
    new "1. <Por supuesto que te escucharé.>"

    # game/beyond the bet/day7dlc.rpy:2046
    old "2. <He knew you were coming?>"
    new "2. <¿Sabía que venías?>"

    # game/beyond the bet/day7dlc.rpy:2056
    old "1. <And you did?>"
    new "1. <¿Y lo hiciste?>"

    # game/beyond the bet/day7dlc.rpy:2059
    old "2. <Oh, Casper...>"
    new "2. <Oh, Casper...>"

    # game/beyond the bet/day7dlc.rpy:2068
    old "1. <And did he get safe passage?>"
    new "1. <¿Y tuvo un paso seguro?>"

    # game/beyond the bet/day7dlc.rpy:2078
    old "1. <It's good to remember things like that.>"
    new "1. <Es bueno recordar cosas así.>"

    # game/beyond the bet/day7dlc.rpy:2081
    old "1. <He left you a kind gift.>"
    new "1. <Te dejó un regalo muy considerado.>"

    # game/beyond the bet/day7dlc.rpy:2086
    old "1. <No, I mean...>"
    new "1. <No, quiero decir...>"

    # game/beyond the bet/day7dlc.rpy:2089
    old "1. <He left you a piece of humanity.>"
    new "1. <Te dejó un pedacito de humanidad.>"

    # game/beyond the bet/day7dlc.rpy:2094
    old "1. <It was very kind of you to do that.>"
    new "1. <Fue muy amable de tu parte hacer eso.>"

    # game/beyond the bet/day7dlc.rpy:2099
    old "2. <I'm not sure I'm up for a sad story right now.>"
    new "2. <No sé si tengo ganas de escuchar una historia triste ahora mismo.>"

    # game/beyond the bet/day7dlc.rpy:2102
    old "1. <But... I do have one question.>"
    new "1. <Pero... sí tengo una pregunta.>"

    # game/beyond the bet/day7dlc.rpy:2106
    old "1. <Did you name him Azrael?>"
    new "1. <¿Le pusiste Azrael?>"

    # game/beyond the bet/day7dlc.rpy:2113
    old "1. <It's nice you kept it.>"
    new "1. <Qué bueno que lo conservaras.>"

    # game/beyond the bet/day7dlc.rpy:2121
    old "1. <???>"
    new "1. <???>"

    # game/beyond the bet/day7dlc.rpy:2127
    old "2. <You did what?>"
    new "2. <¿Tú hiciste qué?>"

    # game/beyond the bet/day7dlc.rpy:2133
    old "1. <That's... adorable.>"
    new "1. <Eso es... adorable.>"

    # game/beyond the bet/day7dlc.rpy:2135
    old "1. <You're going to kill me from sweetness, Casper.>"
    new "1. <Vas a matarme de dulzura, Casper.>"

    # game/beyond the bet/day7dlc.rpy:2141
    old "1. <Doesn't matter, anyway.>"
    new "1. <Igual no importa.>"

    # game/beyond the bet/day7dlc.rpy:2144
    old "1. <You and I both know I'm much too stubborn to actually die that easily.>"
    new "1. <Tú y yo sabemos que soy demasiado terc[letra] como para morir tan fácilmente.>"

    # game/beyond the bet/day7dlc.rpy:2150
    old "2. <You absolute dork.>"
    new "2. <Eres un tontito de lo más adorable.>"

    # game/beyond the bet/day7dlc.rpy:2152
    old "1. <That's so precious.>"
    new "1. <Qué precioso.>"

    # game/beyond the bet/day7dlc.rpy:2160
    old "1. <Yes, yes, sexy, smug, attractive, gorgeous, etc. etc.>"
    new "1. <Sí, sí, sexy, engreído, atractivo, espectacular, etc. etc.>"

    # game/beyond the bet/day7dlc.rpy:2165
    old "3. <Wait, can you do my name as well?>"
    new "3. <Espera, ¿puedes hacer mi nombre también?>"

    # game/beyond the bet/day7dlc.rpy:2170
    old "1. <Hmm... how about you stitch it into your clothes, then.>"
    new "1. <Mmm... ¿por qué no lo coses en tu ropa, entonces?>"

    # game/beyond the bet/day7dlc.rpy:2172
    old "1. <Then it's like I'm always with you! Awww.>"
    new "1. <¡Así sería como si siempre estuviera contigo! ¡Awww!>"

    # game/beyond the bet/day7dlc.rpy:2175
    old "1. <Okay, it sounds creepy when I say it aloud.>"
    new "1. <Okey, suena espeluznante cuando lo digo en voz alta.>"

    # game/beyond the bet/day7dlc.rpy:2180
    old "2. <Stitch it into your pillowcase!>"
    new "2. <¡Cóselo en la funda de tu almohada!>"

    # game/beyond the bet/day7dlc.rpy:2182
    old "1. <Then, when you sleep, you have a little reminder of me.>"
    new "1. <Así, cuando duermas, tendrás un pequeño recordatorio de mí.>"

    # game/beyond the bet/day7dlc.rpy:2191
    old "1. <Can you show me your beautiful stitching work?>"
    new "1. <¿Puedes mostrarme tu hermoso trabajo de costura?>"

    # game/beyond the bet/day7dlc.rpy:2197
    old "1. <Cute.>"
    new "1. <Lindo.>"

    # game/beyond the bet/day7dlc.rpy:2200
    old "1. <Who would've thought that the Grim Reaper takes up knitting in his spare time.>"
    new "1. <Quién iba a pensar que la Parca se dedica a tejer en su tiempo libre.>"

    # game/beyond the bet/day7dlc.rpy:2206
    old "1. <Well, do you like knitting?>"
    new "1. <Bueno, ¿te gusta tejer?>"

    # game/beyond the bet/day7dlc.rpy:2211
    old "1. <Damn. I was hoping you could knit me a \nblanket or something.>"
    new "1. <Qué lástima. Esperaba que pudieras tejerme una manta o algo.>"

    # game/beyond the bet/day7dlc.rpy:2215
    old "1. <Why? You gonna pick up knitting, after all?>"
    new "1. <¿Por qué? ¿Vas a ponerte a tejer, después de todo?>"

    # game/beyond the bet/day7dlc.rpy:2225
    old "2. <I guess I'll have to do the knitting.>"
    new "2. <Supongo que tendré que tejer yo.>"

    # game/beyond the bet/day7dlc.rpy:2227
    old "1. <I'm already pretty good.>"
    new "1. <Ya soy bastante [buen].>"

    # game/beyond the bet/day7dlc.rpy:2229
    old "1. <Huh. I like being better at something than you, hehe.>"
    new "1. <Eh. Me gusta ser mejor que tú en algo, jeje.>"

    # game/beyond the bet/day7dlc.rpy:2231
    old "2. <It's never too late to learn, I suppose.>"
    new "2. <Nunca es tarde para aprender, supongo.>"

    # game/beyond the bet/day7dlc.rpy:2235
    old "1. <Hey, Grim.>"
    new "1. <Oye, Parca.>"

    # game/beyond the bet/day7dlc.rpy:2240
    old "1. <I can't keep it to myself anymore or I think I'll explode.>"
    new "1. <No puedo seguir guardándomelo o creo que voy a explotar.>"

    # game/beyond the bet/day7dlc.rpy:2243
    old "1. <ARE YOU WEARING HAIR CLIPS?!>"
    new "1. <¡¿LLEVAS PINZAS EN EL CABELLO?!>"

    # game/beyond the bet/day7dlc.rpy:2245
    old "2. <The... the hair clips... aaaaa?>"
    new "2. <¿Las... las pinzas del cabello... aaaaa?>"

    # game/beyond the bet/day7dlc.rpy:2260
    old "1. <One of them is a sunflower!>"
    new "1. <¡Una de ellas es un girasol!>"

    # game/beyond the bet/day7dlc.rpy:2267
    old "1. <Why'd you pick that one, huh?>"
    new "1. <¿Por qué elegiste esa, eh?>"

    # game/beyond the bet/day7dlc.rpy:2270
    old "1. <Did it remind you of little old me?>"
    new "1. <¿Te recordó a mí?>"

    # game/beyond the bet/day7dlc.rpy:2273
    old "1. <Your forever Sunshine.>"
    new "1. <Tu Solecito de siempre.>"

    # game/beyond the bet/day7dlc.rpy:2278
    old "2. <One of them is a little skull!>"
    new "2. <¡Una es una calaverita!>"

    # game/beyond the bet/day7dlc.rpy:2280
    old "1. <You are so predictable. And cute. Mostly cute.>"
    new "1. <Eres tan predecible. Y lindo. Más que nada lindo.>"

    # game/beyond the bet/day7dlc.rpy:2285
    old "1. <And a sunflower, too.>"
    new "1. <Y un girasol también.>"

    # game/beyond the bet/day7dlc.rpy:2288
    old "1. <Aaaaaah. You are too much sometimes.>"
    new "1. <Aaaaaah. A veces eres demasiado tierno.>"

    # game/beyond the bet/day7dlc.rpy:2294
    old "1. <But it's hair clips on {i}you{/i}!>"
    new "1. <¡Pero son pinzas en {i}tu cabello{/i}!>"

    # game/beyond the bet/day7dlc.rpy:2297
    old "1. <I literally never thought I'd see this.>"
    new "1. <Jamás pensé que llegaría a ver esto.>"

    # game/beyond the bet/day7dlc.rpy:2300
    old "1. <I can die happy now.>"
    new "1. <Ya puedo morir feliz.>"

    # game/beyond the bet/day7dlc.rpy:2307
    old "1. <How often do you wear them?>"
    new "1. <¿Con qué frecuencia las usas?>"

    # game/beyond the bet/day7dlc.rpy:2311
    old "1. <I feel like I've been missing out...>"
    new "1. <Siento que me lo he estado perdiendo...>"

    # game/beyond the bet/day7dlc.rpy:2314
    old "1. <Wait, do you ever put your hair in a ponytail? \nI wanna see that too...>"
    new "1. <Espera, ¿alguna vez te recoges el cabello en una cola de caballo? Quiero ver eso también...>"

    # game/beyond the bet/day7dlc.rpy:2317
    old "1. <You know, since you get hot.>"
    new "1. <Sabes, ya que te da calor.>"

    # game/beyond the bet/day7dlc.rpy:2322
    old "1. <To the hair clips or the ponytail?>"
    new "1. <¿Las pinzas o la cola de caballo?>"

    # game/beyond the bet/day7dlc.rpy:2327
    old "1. <Grimmmmm.>"
    new "1. <Parcaaaa.>"

    # game/beyond the bet/day7dlc.rpy:2336
    old "1. <How adorable.>"
    new "1. <Qué adorable.>"

    # game/beyond the bet/day7dlc.rpy:2339
    old "1. <Is that a common style in the Underworld, then?>"
    new "1. <¿Es un estilo común en el Inframundo, entonces?>"

    # game/beyond the bet/day7dlc.rpy:2344
    old "1. <'All this stuff'?>"
    new "1. <¿'A todo esto'?>"

    # game/beyond the bet/day7dlc.rpy:2352
    old "1. <One day you'll let me run my fingers through it.>"
    new "1. <Un día me dejarás pasar los dedos por él.>"

    # game/beyond the bet/day7dlc.rpy:2356
    old "1. <I think you'd get addicted to it. It's a nice feeling.>"
    new "1. <Creo que te volverías adicto. Es una sensación agradable.>"

    # game/beyond the bet/day7dlc.rpy:2359
    old "1. <Even better, coming from me. Go on, say pretty please.>"
    new "1. <Aún mejor, viniendo de mí. Anda, di porfis.>"

    # game/beyond the bet/day7dlc.rpy:2367
    old "1. <Are we still talking about hair?>"
    new "1. <¿Seguimos hablando del cabello?>"

    # game/beyond the bet/day7dlc.rpy:2371
    old "1. <I thought you were being dirty.>"
    new "1. <Pensé que te estabas poniendo atrevido.>"

    # game/beyond the bet/day7dlc.rpy:2373
    old "2. <All this talk of begging...>"
    new "2. <Con todo esto de suplicar...>"

    # game/beyond the bet/day7dlc.rpy:2376
    old "1. <But, really, I think you'd enjoy it.>"
    new "1. <Pero, en serio, creo que lo disfrutarías.>"

    # game/beyond the bet/day7dlc.rpy:2379
    old "1. <Me running my hands through your hair.>"
    new "1. <Yo pasando mis manos por tu cabello.>"

    # game/beyond the bet/day7dlc.rpy:2382
    old "1. <Has anyone ever done that for you?>"
    new "1. <¿Alguien te lo ha hecho alguna vez?>"

    # game/beyond the bet/day7dlc.rpy:2387
    old "1. <It's nice.>"
    new "1. <Es agradable.>"

    # game/beyond the bet/day7dlc.rpy:2390
    old "2. <...I...>"
    new "2. <...Yo...>"

    # game/beyond the bet/day7dlc.rpy:2392
    old "1. <Shit, Casper...>"
    new "1. <Mierda, Casper...>"

    # game/beyond the bet/day7dlc.rpy:2401
    old "3. <Who said I want you to go easy on me?>"
    new "3. <¿Quién dijo que quiero que seas suave conmigo?>"

    # game/beyond the bet/day7dlc.rpy:2403
    old "1. <You can give me everything, Casper.>"
    new "1. <Puedes darme todo, Casper.>"

    # game/beyond the bet/day7dlc.rpy:2406
    old "1. <Trust me. I can take it.>"
    new "1. <Confía en mí. Puedo soportarlo.>"

    # game/beyond the bet/day7dlc.rpy:2412
    old "1. <Same for you.>"
    new "1. <Lo mismo digo de ti.>"

    # game/beyond the bet/day7dlc.rpy:2416
    old "1. <God, is it hot in here or something?>"
    new "1. <Dios, ¿hace calor aquí o qué?>"

    # game/beyond the bet/day7dlc.rpy:2419
    old "4. <I'm... into it.>"
    new "4. <Me... gusta la idea.>"

    # game/beyond the bet/day7dlc.rpy:2423
    old "1. <Well, I'd make you work for it a bit.>"
    new "1. <Bueno, haría que te costara un poco conseguirlo.>"

    # game/beyond the bet/day7dlc.rpy:2425
    old "1. <But... well, ultimately... yes.>"
    new "1. <Pero... bueno, al final... sí.>"

    # game/beyond the bet/day7dlc.rpy:2427
    old "2. <Not gonna lie, I'd likely drop to my knees if \nyou asked me to.>"
    new "2. <No te voy a mentir, probablemente me arrodillaría si me lo pidieras.>"

    # game/beyond the bet/day7dlc.rpy:2434
    old "1. <Well, I can't really speak for all mortals.>"
    new "1. <Bueno, no puedo hablar por todos los mortales.>"

    # game/beyond the bet/day7dlc.rpy:2437
    old "1. <Man. I think it's getting a little hot in here or \nsomething...>"
    new "1. <Hombre. Creo que está haciendo un poco de calor aquí o algo...>"

    # game/beyond the bet/day7dlc.rpy:2442
    old "2. <Tie it up now! I want to see it.>"
    new "2. <¡Átatelo ya! Quiero verlo.>"

    # game/beyond the bet/day7dlc.rpy:2448
    old "1. <You know what, how about we do that in person.>"
    new "1. <Sabes qué, ¿y si lo hacemos en persona?>"

    # game/beyond the bet/day7dlc.rpy:2451
    old "1. <I'm sure you and I can work out something \nto do with your exposed neck.>"
    new "1. <Seguro que tú y yo podemos idear algo que tenga que ver con tu cuello expuesto.>"

    # game/beyond the bet/day7dlc.rpy:2457
    old "1. <Or maybe I am very much bite.>"
    new "1. <O quizá yo sí muerdo muchísimo.>"

    # game/beyond the bet/day7dlc.rpy:2467
    old "1. <.............>"
    new "1. <.............>"

    # game/beyond the bet/day7dlc.rpy:2470
    old "2. <And you?>"
    new "2. <¿Y tú?>"

    # game/beyond the bet/day7dlc.rpy:2475
    old "1. <I'm not saying no.>"
    new "1. <No estoy diciendo que no.>"

    # game/beyond the bet/day7dlc.rpy:2477
    old "2. <You can try.>"
    new "2. <Puedes intentarlo.>"

    # game/beyond the bet/day7dlc.rpy:2484
    old "1. <Not as flushed as you!>"
    new "1. <¡No tan sonrojad[letra] como tú!>"

    # game/beyond the bet/day7dlc.rpy:2491
    old "1. <Shut up already.>"
    new "1. <Cállate ya.>"

    # game/beyond the bet/day7dlc.rpy:2495
    old "1. <Ugh!>"
    new "1. <¡Ugh!>"

    # game/beyond the bet/day7dlc.rpy:2498
    old "1. <{i}Hide your face with whatever is nearby.{/i}>"
    new "1. <{i}Escondes la cara con lo que tengas cerca.{/i}>"

    # game/beyond the bet/day7dlc.rpy:2505
    old "1. <Lalala. If I can't see you, you don't exist.>"
    new "1. <Lalala. Si no puedo verte, no existes.>"

    # game/beyond the bet/day7dlc.rpy:2512
    old "1. <Who said that?>"
    new "1. <¿Quién dijo eso?>"

    # game/beyond the bet/day7dlc.rpy:2515
    old "1. <Casper? Never heard of him.>"
    new "1. <¿Casper? Nunca he oído hablar de él.>"

    # game/beyond the bet/day7dlc.rpy:2520
    old "1. <I—>"
    new "1. <Yo—>"

    # game/beyond the bet/day7dlc.rpy:2528
    old "1. <Ouch!>"
    new "1. <¡Ay!>"

    # game/beyond the bet/day7dlc.rpy:2530
    old "2. <Ah!>"
    new "2. <¡Ah!>"

    # game/beyond the bet/day7dlc.rpy:2536
    old "1. <I'm fine.>"
    new "1. <Estoy bien.>"

    # game/beyond the bet/day7dlc.rpy:2539
    old "1. <I just caught my finger on the paper.>"
    new "1. <Solo me corté el dedo con el papel.>"

    # game/beyond the bet/day7dlc.rpy:2541
    old "2. <It's just a papercut.>"
    new "2. <Es solo un corte con el papel.>"

    # game/beyond the bet/day7dlc.rpy:2551
    old "1. <The pinky finger on my left hand.>"
    new "1. <El dedo meñique de mi mano izquierda.>"

    # game/beyond the bet/day7dlc.rpy:2553
    old "2. <My ring finger.>"
    new "2. <Mi dedo anular.>"

    # game/beyond the bet/day7dlc.rpy:2555
    old "3. <My thumb on my right hand.>"
    new "3. <Mi pulgar de la mano derecha.>"

    # game/beyond the bet/day7dlc.rpy:2561
    old "1. <What are you saying?>"
    new "1. <¿Qué estás diciendo?>"

    # game/beyond the bet/day7dlc.rpy:2574
    old "1. <In the... same place?>"
    new "1. <¿En el... mismo lugar?>"

    # game/beyond the bet/day7dlc.rpy:2579
    old "1. <What the...>"
    new "1. <¿Qué demo...?>"

    # game/beyond the bet/day7dlc.rpy:2581
    old "2. <How could that happen?>"
    new "2. <¿Cómo puede pasar eso?>"

    # game/beyond the bet/day7dlc.rpy:2592
    old "1. <Helloooo.....?>"
    new "1. <¿Hoooola.....?>"

    # game/beyond the bet/day7dlc.rpy:2594
    old "2. <Where'd you go?>"
    new "2. <¿Adónde fuiste?>"

    # game/beyond the bet/day7dlc.rpy:2598
    old "1. <What are you looking for...?>"
    new "1. <¿Qué estás buscando...?>"

    # game/beyond the bet/day7dlc.rpy:2613
    old "1. <Don't strain yourself too hard...>"
    new "1. <No te esfuerces demasiado...>"

    # game/beyond the bet/day7dlc.rpy:2615
    old "2. <You're sick, Casper. Rest up.>"
    new "2. <Estás enfermo, Casper. Descansa.>"

    # game/beyond the bet/day7dlc.rpy:2621
    old "1. <Always.>"
    new "1. <Siempre.>"

    # game/beyond the bet/day7dlc.rpy:2642
    old "1. <Well...>"
    new "1. <Bueno...>"

    # game/beyond the bet/day7dlc.rpy:2645
    old "1. <I said I'd wait, but I don't actually have much to do.>"
    new "1. <Dije que esperaría, pero en realidad no tengo mucho que hacer.>"

    # game/beyond the bet/day7dlc.rpy:2648
    old "1. <Let's see how high I can count before you get back.>"
    new "1. <Veamos hasta cuánto puedo contar antes de que vuelvas.>"

    # game/beyond the bet/day7dlc.rpy:2651
    old "1. <1>"
    new "1. <1>"

    # game/beyond the bet/day7dlc.rpy:2654
    old "1. <2>"
    new "1. <2>"

    # game/beyond the bet/day7dlc.rpy:2657
    old "1. <3>"
    new "1. <3>"

    # game/beyond the bet/day7dlc.rpy:2660
    old "1. <4>"
    new "1. <4>"

    # game/beyond the bet/day7dlc.rpy:2663
    old "1. <5>"
    new "1. <5>"

    # game/beyond the bet/day7dlc.rpy:2666
    old "1. <Okay I'm bored now.>"
    new "1. <Okey, ya me aburrí.>"

    # game/beyond the bet/day7dlc.rpy:2669
    old "1. <Counting isn't as fun as I thought it might be.>"
    new "1. <Contar no es tan divertido como pensé que sería.>"

    # game/beyond the bet/day7dlc.rpy:2672
    old "2. <I'm doing a little dance to pass the time.>"
    new "2. <Estoy haciendo un bailecito para pasar el rato.>"

    # game/beyond the bet/day7dlc.rpy:2675
    old "1. <You can't see it but it's very cool.>"
    new "1. <No puedes verlo, pero es buenísimo.>"

    # game/beyond the bet/day7dlc.rpy:2678
    old "1. <I look awesome.>"
    new "1. <Me veo increíble.>"

    # game/beyond the bet/day7dlc.rpy:2681
    old "1. <You're missing out.>"
    new "1. <Te lo estás perdiendo.>"

    # game/beyond the bet/day7dlc.rpy:2684
    old "1. <Okay I'm tired of dancing now.>"
    new "1. <Okey, ya me cansé de bailar.>"

    # game/beyond the bet/day7dlc.rpy:2687
    old "3. <I started doodling something just now.>"
    new "3. <Acabo de empezar a hacer un garabato.>"

    # game/beyond the bet/day7dlc.rpy:2690
    old "1. <It's a picture of the most handsome man I know.>"
    new "1. <Es un dibujo del hombre más guapo que conozco.>"

    # game/beyond the bet/day7dlc.rpy:2693
    old "1. <Azrael.>"
    new "1. <Azrael.>"

    # game/beyond the bet/day7dlc.rpy:2696
    old "1. <He's all muscly, though.>"
    new "1. <Aunque es todo musculoso.>"

    # game/beyond the bet/day7dlc.rpy:2699
    old "1. <Muscly Azrael.>"
    new "1. <Azrael musculoso.>"

    # game/beyond the bet/day7dlc.rpy:2702
    old "1. <Alright that's done, now what...>"
    new "1. <Listo, eso ya está, ¿y ahora qué...?>"

    # game/beyond the bet/day7dlc.rpy:2705
    old "4. <I thought about eavesdropping on my neighbors...>"
    new "4. <Pensé en espiar a mis vecinos...>"

    # game/beyond the bet/day7dlc.rpy:2708
    old "1. <But I think whoever lived next door actually MOVED OUT.>"
    new "1. <Pero creo que quien vivía al lado en realidad SE MUDÓ.>"

    # game/beyond the bet/day7dlc.rpy:2711
    old "1. <Out of nowhere.>"
    new "1. <De la nada.>"

    # game/beyond the bet/day7dlc.rpy:2714
    old "1. <Isn't that strange?>"
    new "1. <¿No es raro?>"

    # game/beyond the bet/day7dlc.rpy:2717
    old "1. <I think they have some huge secret they're hiding...>"
    new "1. <Creo que esconde algún secreto enorme...>"

    # game/beyond the bet/day7dlc.rpy:2720
    old "1. <But I guess I'll never find out now.>"
    new "1. <Pero supongo que ahora nunca lo sabré.>"

    # game/beyond the bet/day7dlc.rpy:2724
    old "1. <You know...>"
    new "1. <Sabes...>"

    # game/beyond the bet/day7dlc.rpy:2727
    old "1. <I thought I was gonna die today.>"
    new "1. <Pensé que hoy me iba a morir.>"

    # game/beyond the bet/day7dlc.rpy:2729
    old "2. <Today is day seven.>"
    new "2. <Hoy es el día siete.>"

    # game/beyond the bet/day7dlc.rpy:2732
    old "1. <But I've still got my soul.>"
    new "1. <Pero todavía tengo mi alma.>"

    # game/beyond the bet/day7dlc.rpy:2735
    old "1. <I think we've kinda danced around the issue all day...>"
    new "1. <Creo que hemos estado dándole vueltas al asunto todo el día...>"

    # game/beyond the bet/day7dlc.rpy:2737
    old "2. <It's the elephant in the room, huh?>"
    new "2. <Es el elefante en la habitación, ¿eh?>"

    # game/beyond the bet/day7dlc.rpy:2740
    old "1. <But...>"
    new "1. <Pero...>"

    # game/beyond the bet/day7dlc.rpy:2743
    old "1. <There was this flyer put under my door, about some outdoor twilight \nfestival that's being held tomorrow.>"
    new "1. <Pasaron un folleto por debajo de mi puerta sobre un festival al aire libre del crepúsculo que se celebra mañana.>"

    # game/beyond the bet/day7dlc.rpy:2747
    old "1. <Not Twilight like vampires.>"
    new "1. <No Crepúsculo como los vampiros.>"

    # game/beyond the bet/day7dlc.rpy:2751
    old "1. <Twilight like, uh, the time of day.>"
    new "1. <Crepúsculo como, eh, la hora del día.>"

    # game/beyond the bet/day7dlc.rpy:2755
    old "1. <You know what my first thought was?>"
    new "1. <¿Sabes cuál fue mi primer pensamiento?>"

    # game/beyond the bet/day7dlc.rpy:2758
    old "1. <Wouldn't it be fun to go with Casper?>"
    new "1. <¿No sería divertido ir con Casper?>"

    # game/beyond the bet/day7dlc.rpy:2760
    old "2. <Wouldn't it be fun to go alone?>"
    new "2. <¿No sería divertido ir sol[letra]?>"

    # game/beyond the bet/day7dlc.rpy:2763
    old "1. <...Okay, that's a lie.>"
    new "1. <...Okey, eso es mentira.>"

    # game/beyond the bet/day7dlc.rpy:2766
    old "1. <I thought about going with you.>"
    new "1. <Pensé en ir contigo.>"

    # game/beyond the bet/day7dlc.rpy:2769
    old "1. <And then I remembered that one of the two of us would likely be \ndead by tomorrow, so...>"
    new "1. <Y entonces recordé que uno de los dos probablemente estaría muerto para mañana, así que...>"

    # game/beyond the bet/day7dlc.rpy:2772
    old "1. <It made me kinda sad.>"
    new "1. <Me dio medio tristeza.>"

    # game/beyond the bet/day7dlc.rpy:2775
    old "1. <Not the thought of being dead.>"
    new "1. <No la idea de estar muert[letra].>"

    # game/beyond the bet/day7dlc.rpy:2778
    old "1. <I mean, that sucks.>"
    new "1. <O sea, eso es una porquería.>"

    # game/beyond the bet/day7dlc.rpy:2781
    old "1. <But, the thought that we'd already run out of time.>"
    new "1. <Sino la idea de que ya se nos acabó el tiempo.>"

    # game/beyond the bet/day7dlc.rpy:2784
    old "1. <Even going to watch some fireworks together wouldn't be possible...>"
    new "1. <Ni siquiera podríamos ir a ver fuegos artificiales juntos...>"

    # game/beyond the bet/day7dlc.rpy:2787
    old "1. <I've enjoyed our time together.>"
    new "1. <He disfrutado nuestro tiempo juntos.>"

    # game/beyond the bet/day7dlc.rpy:2790
    old "1. <Really enjoyed it.>"
    new "1. <De verdad lo he disfrutado.>"

    # game/beyond the bet/day7dlc.rpy:2793
    old "1. <Which is silly, because I only responded to you in the first place because...>"
    new "1. <Lo cual es tonto, porque en primer lugar solo te respondí porque...>"

    # game/beyond the bet/day7dlc.rpy:2796
    old "1. <Well, I thought it'd be funny.>"
    new "1. <Bueno, pensé que sería gracioso.>"

    # game/beyond the bet/day7dlc.rpy:2799
    old "2. <I really like you, Casper.>"
    new "2. <Me gustas mucho, Casper.>"

    # game/beyond the bet/day7dlc.rpy:2802
    old "1. <You are so dumb.>"
    new "1. <Eres tan tonto.>"

    # game/beyond the bet/day7dlc.rpy:2804
    old "2. <You are the most arrogant person I know.>"
    new "2. <Eres la persona más arrogante que conozco.>"

    # game/beyond the bet/day7dlc.rpy:2807
    old "1. <And for some reason I'm into that.>"
    new "1. <Y por alguna razón eso me gusta.>"

    # game/beyond the bet/day7dlc.rpy:2812
    old "1. <AH!>"
    new "1. <¡AH!>"

    # game/beyond the bet/day7dlc.rpy:2814
    old "2. <FUCK!>"
    new "2. <¡MIERDA!>"

    # game/beyond the bet/day7dlc.rpy:2817
    old "1. <A ghost!>"
    new "1. <¡Un fantasma!>"

    # game/beyond the bet/day7dlc.rpy:2822
    old "2. <A demon!>"
    new "2. <¡Un demonio!>"

    # game/beyond the bet/day7dlc.rpy:2828
    old "3. <A Grim Reaper!>"
    new "3. <¡Una Parca!>"

    # game/beyond the bet/day7dlc.rpy:2835
    old "4. <The father to my soulbabies!>"
    new "4. <¡El padre de mis bebés alma!>"

    # game/beyond the bet/day7dlc.rpy:2841
    old "1. <Oh, my bad.>"
    new "1. <Ay, mi error.>"

    # game/beyond the bet/day7dlc.rpy:2844
    old "1. <Future* father.>"
    new "1. <Futuro* padre.>"

    # game/beyond the bet/day7dlc.rpy:2852
    old "1. <What is it?>"
    new "1. <¿Qué es?>"

    # game/beyond the bet/day7dlc.rpy:2856
    old "1. <That is NOT a real book.>"
    new "1. <Ese NO es un libro de verdad.>"

    # game/beyond the bet/day7dlc.rpy:2858
    old "2. <I thought you couldn't lie.>"
    new "2. <Pensé que no podías mentir.>"

    # game/beyond the bet/day7dlc.rpy:2870
    old "1. <Wait, that's why you're sick? And the cut?>"
    new "1. <Espera, ¿por eso estás enfermo? ¿Y el corte?>"

    # game/beyond the bet/day7dlc.rpy:2880
    old "1. <So... we're compatible or something?>"
    new "1. <Entonces... ¿somos compatibles o algo así?>"

    # game/beyond the bet/day7dlc.rpy:2882
    old "2. <We complete each other :D ?>"
    new "2. <¿Nos complementamos :D ?>"

    # game/beyond the bet/day7dlc.rpy:2893
    old "1. <Last night!>"
    new "1. <¡Anoche!>"

    # game/beyond the bet/day7dlc.rpy:2895
    old "2. <You came over...!>"
    new "2. <¡Viniste...!>"

    # game/beyond the bet/day7dlc.rpy:2901
    old "1. <We touched!>"
    new "1. <¡Nos tocamos!>"

    # game/beyond the bet/day7dlc.rpy:2904
    old "1. <You took off your gloves and touched my forehead.>"
    new "1. <Te quitaste los guantes y me tocaste la frente.>"

    # game/beyond the bet/day7dlc.rpy:2907
    old "1. <Remember that weird zap?>"
    new "1. <¿Recuerdas esa extraña descarga?>"

    # game/beyond the bet/day7dlc.rpy:2913
    old "1. <Hey, you could be a little less upset here.>"
    new "1. <Oye, podrías estar un poco menos molesto.>"

    # game/beyond the bet/day7dlc.rpy:2916
    old "1. <I'm not that bad.>"
    new "1. <No soy tan mal[letra].>"

    # game/beyond the bet/day7dlc.rpy:2919
    old "1. <It's not like I stink.>"
    new "1. <No es que huela mal.>"

    # game/beyond the bet/day7dlc.rpy:2925
    old "1. <I don't stink, do I?>"
    new "1. <No huelo mal, ¿verdad?>"

    # game/beyond the bet/day7dlc.rpy:2933
    old "2. <C'mon, it's not that bad.>"
    new "2. <Vamos, no es tan grave.>"

    # game/beyond the bet/day7dlc.rpy:2951
    old "1. <Ah.>"
    new "1. <Ah.>"

    # game/beyond the bet/day7dlc.rpy:2954
    old "1. <That could be a problem.>"
    new "1. <Eso podría ser un problema.>"

    # game/beyond the bet/day7dlc.rpy:2960
    old "2. <That's less than ideal.>"
    new "2. <No es precisamente lo ideal.>"

    # game/beyond the bet/day7dlc.rpy:2964
    old "3. <Worse things happen at sea.>"
    new "3. <Cosas peores pasan en el mar.>"

    # game/beyond the bet/day7dlc.rpy:2968
    old "1. <I read that once on the internet.>"
    new "1. <Lo leí una vez en internet.>"

    # game/beyond the bet/day7dlc.rpy:2971
    old "1. <It makes me feel better when bad things happen.>"
    new "1. <Me hace sentir mejor cuando pasan cosas malas.>"

    # game/beyond the bet/day7dlc.rpy:2977
    old "1. <So, we just cancel the bet.>"
    new "1. <Entonces, simplemente cancelamos la apuesta.>"

    # game/beyond the bet/day7dlc.rpy:2983
    old "1. <Then...>"
    new "1. <Entonces...>"

    # game/beyond the bet/day7dlc.rpy:2986
    old "1. <How about...>"
    new "1. <¿Qué tal...>"

    # game/beyond the bet/day7dlc.rpy:2989
    old "1. <Extending it?>"
    new "1. <extenderla?>"

    # game/beyond the bet/day7dlc.rpy:2992
    old "1. <Just for a few days.>"
    new "1. <Solo por unos días.>"

    # game/beyond the bet/day7dlc.rpy:2995
    old "1. <You've been after me for years. Surely a few more days is fine.>"
    new "1. <Llevas años detrás de mí. Seguro que unos días más no son problema.>"

    # game/beyond the bet/day7dlc.rpy:3003
    old "1. <Awww, poor Casper.>"
    new "1. <Awww, pobre Casper.>"

    # game/beyond the bet/day7dlc.rpy:3009
    old "2. <I might be.>"
    new "2. <Podría ser.>"

    # game/beyond the bet/day7dlc.rpy:3011
    old "3. <I would never!>"
    new "3. <¡Jamás!>"

    # game/beyond the bet/day7dlc.rpy:3014
    old "1. <Who's my sad little sick boy?>"
    new "1. <¿Quién es mi pobre chiquito enfermo?>"

    # game/beyond the bet/day7dlc.rpy:3019
    old "2. <It'll be alright. I'm here for you.>"
    new "2. <Todo va a estar bien. Estoy aquí contigo.>"

    # game/beyond the bet/day7dlc.rpy:3026
    old "1. <Welp.>"
    new "1. <En fin.>"

    # game/beyond the bet/day7dlc.rpy:3029
    old "1. <You're still stuck with me.>"
    new "1. <Sigues atrapado conmigo.>"

    # game/beyond the bet/day7dlc.rpy:3036
    old "1. <So if we get to day 10, and don't have a plan...>"
    new "1. <Entonces, si llegamos al día 10 y no tenemos un plan...>"

    # game/beyond the bet/day7dlc.rpy:3040
    old "1. <Doesn't sound so bad.>"
    new "1. <No suena tan mal.>"

    # game/beyond the bet/day7dlc.rpy:3045
    old "1. <We could go to the afterlife together!>"
    new "1. <¡Podríamos ir juntos al más allá!>"

    # game/beyond the bet/day7dlc.rpy:3058
    old "1. <That's sad.>"
    new "1. <Qué triste.>"

    # game/beyond the bet/day7dlc.rpy:3062
    old "2. <Doomed by the narrative...>"
    new "2. <Condenados por la narrativa...>"

    # game/beyond the bet/day7dlc.rpy:3066
    old "1. <Like.>"
    new "1. <O sea.>"

    # game/beyond the bet/day7dlc.rpy:3069
    old "1. <If this was a book, or a game, or something.>"
    new "1. <Si esto fuera un libro, o un juego, o algo así.>"

    # game/beyond the bet/day7dlc.rpy:3072
    old "1. <People would say we're doomed by the narrative.>"
    new "1. <La gente diría que estamos condenados por la narrativa.>"

    # game/beyond the bet/day7dlc.rpy:3078
    old "1. <I bet people would cheer for us, anyway.>"
    new "1. <Apuesto a que la gente nos animaría de todos modos.>"

    # game/beyond the bet/day7dlc.rpy:3082
    old "3. <We're like a pair of tragic lovers.>"
    new "3. <Somos como una pareja de amantes trágicos.>"

    # game/beyond the bet/day7dlc.rpy:3086
    old "1. <Practically.>"
    new "1. <Prácticamente.>"

    # game/beyond the bet/day7dlc.rpy:3089
    old "1. <I don't know about you, but I'm basically written by Shakespeare.>"
    new "1. <No sé tú, pero parece que mi vida la escribió Shakespeare.>"

    # game/beyond the bet/day7dlc.rpy:3094
    old "1. <That makes the two of us.>"
    new "1. <Somos dos.>"

    # game/beyond the bet/day7dlc.rpy:3097
    old "4. <I don't have any plans to die.>"
    new "4. <No tengo ningún plan de morir.>"

    # game/beyond the bet/day7dlc.rpy:3103
    old "1. <What impossible things have you made possible?>"
    new "1. <¿Qué cosas imposibles has hecho posibles?>"

    # game/beyond the bet/day7dlc.rpy:3111
    old "1. <Uh huh. Of course. Totally.>"
    new "1. <Ajá. Claro. Totalmente.>"

    # game/beyond the bet/day7dlc.rpy:3117
    old "1. <Some kind of one.>"
    new "1. <Algo así.>"

    # game/beyond the bet/day7dlc.rpy:3120
    old "1. <I've never been before.>"
    new "1. <Nunca he ido.>"

    # game/beyond the bet/day7dlc.rpy:3122
    old "2. <I only just heard about it.>"
    new "2. <Apenas me enteré.>"

