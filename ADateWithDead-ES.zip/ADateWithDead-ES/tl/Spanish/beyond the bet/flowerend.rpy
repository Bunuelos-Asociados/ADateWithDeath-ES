# TODO: Translation updated at 2026-10-15 18:36

# game/beyond the bet/flowerend.rpy:4
translate Spanish dlc_flowerend_start_308625b1:

    # center_text "You dream of flowers."
    center_text "Sueñas con flores."

# game/beyond the bet/flowerend.rpy:7
translate Spanish dlc_flowerend_start_534d8411:

    # center_text "Fields and fields of them, as far as the eye can see."
    center_text "Campos y campos de ellas, hasta donde alcanza la vista."

# game/beyond the bet/flowerend.rpy:8
translate Spanish dlc_flowerend_start_c25b5bd1:

    # center_text "Red, orange, yellow, pink, purple... the colors are endless."
    center_text "Rojas, naranjas, amarillas, rosas, moradas... los colores son infinitos."

# game/beyond the bet/flowerend.rpy:9
translate Spanish dlc_flowerend_start_53f740c6:

    # center_text "And in between them all is him."
    center_text "Y entre todas ellas está él."

# game/beyond the bet/flowerend.rpy:10
translate Spanish dlc_flowerend_start_483a3123:

    # center_text "Casper."
    center_text "Casper."

# game/beyond the bet/flowerend.rpy:11
translate Spanish dlc_flowerend_start_9c98c304:

    # center_text "You smile, then run towards him."
    center_text "Sonríes y corres hacia él."

# game/beyond the bet/flowerend.rpy:12
translate Spanish dlc_flowerend_start_c9ef8983:

    # center_text "The flowers part like the sea, clearing your path towards the one you love."
    center_text "Las flores se abren como el mar, despejando tu camino hacia aquel a quien amas."

# game/beyond the bet/flowerend.rpy:13
translate Spanish dlc_flowerend_start_08f6e709:

    # center_text "And you embrace him."
    center_text "Y lo abrazas."

# game/beyond the bet/flowerend.rpy:14
translate Spanish dlc_flowerend_start_b90b06b6:

    # center_text "All is right with the world."
    center_text "Todo está bien en el mundo."

# game/beyond the bet/flowerend.rpy:45
translate Spanish dlc_flowerend_start_21638ba4:

    # "You wake up, eyes fluttering open."
    "Despiertas, abriendo los ojos con un parpadeo."

# game/beyond the bet/flowerend.rpy:46
translate Spanish dlc_flowerend_start_2ce0c40c:

    # "For a moment, the room around you is unfamiliar, and your heart begins to race."
    "Por un momento, la habitación que te rodea te resulta desconocida y tu corazón empieza a acelerarse."

# game/beyond the bet/flowerend.rpy:50
translate Spanish dlc_flowerend_start_eefb31bc:

    # "Then you remember."
    "Entonces recuerdas."

# game/beyond the bet/flowerend.rpy:51
translate Spanish dlc_flowerend_start_b68f4d6d:

    # "This is Casper's house... in the Underworld."
    "Esta es la casa de Casper... en el Inframundo."

# game/beyond the bet/flowerend.rpy:52
translate Spanish dlc_flowerend_start_ff5f4bbc:

    # "Right."
    "Cierto."

# game/beyond the bet/flowerend.rpy:53
translate Spanish dlc_flowerend_start_d6b3f6ea:

    # "You feel a weight against your chest, and for a second you expect to see Casper... but he doesn't seem to be back yet."
    "Sientes un peso contra el pecho y por un segundo esperas ver a Casper... pero parece que aún no ha vuelto."

# game/beyond the bet/flowerend.rpy:54
translate Spanish dlc_flowerend_start_4d180fff:

    # "Instead, you see a fluffy orange cat with round green eyes."
    "En su lugar, ves a un gato naranja y esponjoso de ojos verdes y redondos."

# game/beyond the bet/flowerend.rpy:93
translate Spanish dlc_flowerend_start_21c0740b:

    # "The cat stares back at you, eyes wide..."
    "El gato te devuelve la mirada, con los ojos muy abiertos..."

# game/beyond the bet/flowerend.rpy:95
translate Spanish dlc_flowerend_start_ccd0f942:

    # "Then, in a sudden puff of smoke, goes up in flames!"
    "Y entonces, en una repentina nube de humo, ¡estalla en llamas!"

# game/beyond the bet/flowerend.rpy:96
translate Spanish dlc_flowerend_start_77ea6331:

    # "You jump away and out of bed as it runs off, ducking under a shelf and finding its way out of the house."
    "Te apartas de un salto y sales de la cama mientras el gato huye corriendo, se cuela bajo una estantería y encuentra la forma de salir de la casa."

# game/beyond the bet/flowerend.rpy:108
translate Spanish dlc_flowerend_start_b83e0f85:

    # "You stretch out your shoulders, yawning as you look around the room."
    "Estiras los hombros, bostezando mientras miras alrededor de la habitación."

# game/beyond the bet/flowerend.rpy:109
translate Spanish dlc_flowerend_start_e9b0f36f:

    # "It's strange to be standing here after seeing it over video call so much."
    "Es raro estar aquí de pie después de haberla visto tantas veces por videollamada."

# game/beyond the bet/flowerend.rpy:110
translate Spanish dlc_flowerend_start_df53bb13:

    # "You glance towards Casper's computer."
    "Echas un vistazo a la computadora de Casper."

# game/beyond the bet/flowerend.rpy:111
translate Spanish dlc_flowerend_start_6251a6fc:

    # "You're not sure why, but a sense of... nostalgia wells in your chest."
    "No sabes por qué, pero una sensación de... nostalgia te llena el pecho."

# game/beyond the bet/flowerend.rpy:112
translate Spanish dlc_flowerend_start_a3eb80a0:

    # "How amazing it is to know that man sits right there and spends his free time chatting to you."
    "Qué increíble saber que ese hombre se sienta justo ahí y pasa su tiempo libre chateando contigo."

# game/beyond the bet/flowerend.rpy:113
translate Spanish dlc_flowerend_start_557583b4:

    # "There's a deep fondness for Casper that wells within your chest, but for now you force it away."
    "Un profundo cariño por Casper te brota en el pecho, pero por ahora lo apartas."

# game/beyond the bet/flowerend.rpy:114
translate Spanish dlc_flowerend_start_cee45b96:

    # "Where is Casper?"
    "¿Dónde está Casper?"

# game/beyond the bet/flowerend.rpy:115
translate Spanish dlc_flowerend_start_ddb8a3f0:

    # "You can't keep that question from your mind."
    "No puedes sacarte esa pregunta de la cabeza."

# game/beyond the bet/flowerend.rpy:116
translate Spanish dlc_flowerend_start_90206dde:

    # "He said he'd be back, but judging from the lack of babygirl energy in the room, he hasn't returned at all yet."
    "Dijo que volvería, pero a juzgar por la falta de energía de babygirl en la habitación, todavía no ha regresado."

# game/beyond the bet/flowerend.rpy:117
translate Spanish dlc_flowerend_start_6978d389:

    # "You sit down on the edge of Casper's bed and pull out the letter that the mysterious reaper sent to you."
    "Te sientas en el borde de la cama de Casper y sacas la carta que te envió la misteriosa parca."

# game/beyond the bet/flowerend.rpy:118
translate Spanish dlc_flowerend_start_79abbae2:

    # "The letter is short and sweet - come alone and learn the truth."
    "La carta es breve y al grano: ven a solas y descubre la verdad."

# game/beyond the bet/flowerend.rpy:119
translate Spanish dlc_flowerend_start_6605d3da:

    # "You flip over the keycard, looking for any clues you missed yesterday."
    "Das la vuelta a la tarjeta de acceso, buscando cualquier pista que se te escapara ayer."

# game/beyond the bet/flowerend.rpy:120
translate Spanish dlc_flowerend_start_b706a3dc:

    # "There's a number of some kind, and a name: 'Library of the Lost'."
    "Hay una especie de número y un nombre: 'Biblioteca de los Perdidos'."

# game/beyond the bet/flowerend.rpy:126
translate Spanish dlc_flowerend_start_46f8fd54:

    # "Sitting there, alone in a place - no, a world - where you don't belong, you wonder if you can truly do anything that will help Casper."
    "Ahí sentad[letra], sin nadie más en un lugar —no, en un mundo— al que no perteneces, te preguntas si de verdad puedes hacer algo que ayude a Casper."

# game/beyond the bet/flowerend.rpy:127
translate Spanish dlc_flowerend_start_dcfc6b3f:

    # "Can a 'mere mortal' really save an immortal reaper?"
    "¿Puede un 'simple mortal' salvar de verdad a una parca inmortal?"

# game/beyond the bet/flowerend.rpy:128
translate Spanish dlc_flowerend_start_0dfe8c7d:

    # "But in the end, you decide on one thing."
    "Pero al final, decides una cosa."

# game/beyond the bet/flowerend.rpy:129
translate Spanish dlc_flowerend_start_eae0ad61:

    # "Dangerous or not, Casper is worth taking risks for."
    "Peligroso o no, Casper merece que corras riesgos."

# game/beyond the bet/flowerend.rpy:130
translate Spanish dlc_flowerend_start_722b058c:

    # "If he can break the rules, so can you."
    "Si él puede romper las reglas, tú también."

# game/beyond the bet/flowerend.rpy:131
translate Spanish dlc_flowerend_start_dd21ca70:

    # "You dress, finding your discarded clothes, before pausing next to a dresser. You open it to find..."
    "Te vistes, encontrando tu ropa tirada, y luego te detienes junto a una cómoda. La abres y encuentras..."

# game/beyond the bet/flowerend.rpy:132
translate Spanish dlc_flowerend_start_3c9a5ffd:

    # "Casper's clothes."
    "La ropa de Casper."

# game/beyond the bet/flowerend.rpy:133
translate Spanish dlc_flowerend_start_693c66aa:

    # "Cloaks, gloves, hats... there's all kinds of things in here."
    "Capas, guantes, sombreros... aquí hay de todo."

# game/beyond the bet/flowerend.rpy:134
translate Spanish dlc_flowerend_start_e7077e09:

    # "But overall, you can't help but notice..."
    "Pero en general, no puedes evitar notar..."

# game/beyond the bet/flowerend.rpy:135
translate Spanish dlc_flowerend_start_126dc13c:

    # "Everything has..."
    "Todo tiene..."

# game/beyond the bet/flowerend.rpy:136
translate Spanish dlc_flowerend_start_fed469ef:

    # "So. Many. Belts."
    "Tantos. Cinturones."

# game/beyond the bet/flowerend.rpy:137
translate Spanish dlc_flowerend_start_06b97564:

    # "You pull out one of the cloaks - it seems to match the one Casper usually wears - and pull it over your shoulders and head."
    "Sacas una de las capas —parece igual a la que Casper suele llevar— y te la echas sobre los hombros y la cabeza."

# game/beyond the bet/flowerend.rpy:138
translate Spanish dlc_flowerend_start_fe0ea869:

    # "Maybe this will make navigating the Underworld a little easier."
    "Quizá esto haga un poco más fácil moverte por el Inframundo."

# game/beyond the bet/flowerend.rpy:139
translate Spanish dlc_flowerend_start_a8a4bb5a:

    # "You grab your bag, emptying most of the contents out and just taking the essentials - the letter, the keycard, and your laptop."
    "Agarras tu bolso, vacías la mayor parte de lo que hay dentro y te llevas solo lo esencial: la carta, la tarjeta de acceso y tu laptop."

# game/beyond the bet/flowerend.rpy:140
translate Spanish dlc_flowerend_start_11a62a93:

    # "Just in case."
    "Por si acaso."

# game/beyond the bet/flowerend.rpy:141
translate Spanish dlc_flowerend_start_f4d3a2e9:

    # "Your bag in hand, you go towards the door, then stop."
    "Con el bolso en la mano, vas hacia la puerta y te detienes."

# game/beyond the bet/flowerend.rpy:142
translate Spanish dlc_flowerend_start_b327e428:

    # "You turn to where Azrael is sitting, then go back over and..."
    "Te giras hacia donde está sentado Azrael, vuelves a acercarte y..."

# game/beyond the bet/flowerend.rpy:162
translate Spanish dlc_flowerend_start_672ce820:

    # "You turn back towards the door, then finally head outside."
    "Te vuelves hacia la puerta y por fin sales."

# game/beyond the bet/flowerend.rpy:176
translate Spanish dlc_flowerend_start_a53e16c9:

    # "Your journey through the city that encompasses all of the Underworld is both overwhelming and a little confusing."
    "Tu recorrido por la ciudad que abarca todo el Inframundo es abrumador y un poco confuso."

# game/beyond the bet/flowerend.rpy:178
translate Spanish dlc_flowerend_start_ebd4d4dd:

    # "There's far more people than you first thought - people who don't look so different to any normal 'mortal'."
    "Hay mucha más gente de la que pensabas: gente que no se ve tan distinta de cualquier 'mortal' normal."

# game/beyond the bet/flowerend.rpy:179
translate Spanish dlc_flowerend_start_3e1226e0:

    # "But there's also people who look far different to what you've seen before - people with wings and tails and horns, or skin in shades of pinks and blues and purples."
    "Pero también hay gente muy distinta a todo lo que habías visto antes: gente con alas, colas y cuernos, o con piel en tonos de rosa, azul y morado."

# game/beyond the bet/flowerend.rpy:180
translate Spanish dlc_flowerend_start_adc40a9a:

    # "You walk along, your head down, trying to ignore the eyes that watch you."
    "Caminas con la cabeza agachada, intentando ignorar los ojos que te observan."

# game/beyond the bet/flowerend.rpy:181
translate Spanish dlc_flowerend_start_237940a8:

    # "Are they watching you? You're not sure, but it certainly feels like it."
    "¿Te están mirando? No lo sabes con certeza, pero desde luego lo parece."

# game/beyond the bet/flowerend.rpy:182
translate Spanish dlc_flowerend_start_788beee8:

    # "Despite being morning time, there's no sun in the sky. Above you is just blackness, without a single star."
    "Aunque es de mañana, no hay sol en el cielo. Sobre ti solo hay negrura, sin una sola estrella."

# game/beyond the bet/flowerend.rpy:183
translate Spanish dlc_flowerend_start_3c4bb6ac:

    # "You find it a little sad, honestly."
    "Te parece un poco triste, la verdad."

# game/beyond the bet/flowerend.rpy:184
translate Spanish dlc_flowerend_start_544c7977:

    # "Eventually, you find your way to the place you're searching for - the library. Thankfully, whoever is in charge of the signage in the Underworld is earning their keep."
    "Al final llegas al lugar que buscas: la biblioteca. Por suerte, quien se encargue de la señalización del Inframundo se gana bien el sueldo."

# game/beyond the bet/flowerend.rpy:185
translate Spanish dlc_flowerend_start_44866125:

    # "From the outside, the library is a large and imposing building, with wide steps and tall columns."
    "Desde fuera, la biblioteca es un edificio grande e imponente, con amplios escalones y altas columnas."

# game/beyond the bet/flowerend.rpy:186
translate Spanish dlc_flowerend_start_7d9781d8:

    # "It's also... strangely empty."
    "Además está... extrañamente vacía."

# game/beyond the bet/flowerend.rpy:187
translate Spanish dlc_flowerend_start_b051d6ce:

    # "There are no people here at all."
    "No hay nadie aquí."

# game/beyond the bet/flowerend.rpy:188
translate Spanish dlc_flowerend_start_89c01865:

    # "Just... silence."
    "Solo... silencio."

# game/beyond the bet/flowerend.rpy:189
translate Spanish dlc_flowerend_start_ba5c9d50:

    # "Slowly, you walk up the steps."
    "Subes los escalones lentamente."

# game/beyond the bet/flowerend.rpy:190
translate Spanish dlc_flowerend_start_4e0c8127:

    # "At the front door, you scan your keycard, waiting for it to alert security that you're there."
    "En la puerta principal, pasas tu tarjeta de acceso, esperando que avise a seguridad de que estás ahí."

# game/beyond the bet/flowerend.rpy:191
translate Spanish dlc_flowerend_start_a20cefa7:

    # "..."
    "..."

# game/beyond the bet/flowerend.rpy:192
translate Spanish dlc_flowerend_start_733f21a5:

    # "Nothing happens."
    "No pasa nada."

# game/beyond the bet/flowerend.rpy:193
translate Spanish dlc_flowerend_start_ea8372d9:

    # "You try the door."
    "Pruebas la puerta."

# game/beyond the bet/flowerend.rpy:194
translate Spanish dlc_flowerend_start_5859f575:

    # "It swings open easily, and you step inside."
    "Se abre con facilidad y entras."

# game/beyond the bet/flowerend.rpy:201
translate Spanish dlc_flowerend_start_a69963b6:

    # "This inside is... vast."
    "El interior es... inmenso."

# game/beyond the bet/flowerend.rpy:202
translate Spanish dlc_flowerend_start_58fd4884:

    # "The ceiling is impossibly high, and alcoves lead to shelves that are full to bursting with books."
    "El techo es imposiblemente alto, y unos recovecos conducen a estanterías repletas hasta reventar de libros."

# game/beyond the bet/flowerend.rpy:203
translate Spanish dlc_flowerend_start_e4fb43e1:

    # "You feel as if a single person could spend their whole life in here and still not find everything they were looking for."
    "Sientes que una sola persona podría pasar aquí toda su vida y aun así no encontrar todo lo que buscaba."

# game/beyond the bet/flowerend.rpy:204
translate Spanish dlc_flowerend_start_301a6752:

    # "But still, you'll try."
    "Pero aun así, lo intentarás."

# game/beyond the bet/flowerend.rpy:207
translate Spanish dlc_flowerend_start_86315756:

    # "You do a quick search around for the mysterious reaper, but don't find them."
    "Echas un vistazo rápido en busca de la misteriosa parca, pero no encuentras ni rastro."

# game/beyond the bet/flowerend.rpy:208
translate Spanish dlc_flowerend_start_8395fe16:

    # "In fact, you don't find anyone."
    "De hecho, no encuentras a nadie."

# game/beyond the bet/flowerend.rpy:209
translate Spanish dlc_flowerend_start_f407d215:

    # "The silence is almost loud."
    "El silencio casi resulta ensordecedor."

# game/beyond the bet/flowerend.rpy:210
translate Spanish dlc_flowerend_start_95a8ec96:

    # "Slightly creeped out, you instead head towards the bookshelves."
    "Con un escalofrío de inquietud, te diriges mejor hacia las estanterías."

# game/beyond the bet/flowerend.rpy:212
translate Spanish dlc_flowerend_start_8b1aeeaa:

    # "You head over to the shelves on the left of the room and start perusing."
    "Te acercas a las estanterías de la izquierda de la sala y empiezas a ojearlas."

# game/beyond the bet/flowerend.rpy:213
translate Spanish dlc_flowerend_start_9cdbf175:

    # "There's books here in more languages than you knew existed, but luckily there are also some you can read."
    "Hay libros en más idiomas de los que sabías que existían, pero por suerte también hay algunos que puedes leer."

# game/beyond the bet/flowerend.rpy:215
translate Spanish dlc_flowerend_start_94a31d3b:

    # "You head over to the shelves on the right of the room and start perusing."
    "Te acercas a las estanterías de la derecha de la sala y empiezas a ojearlas."

# game/beyond the bet/flowerend.rpy:216
translate Spanish dlc_flowerend_start_34d7fd0a:

    # "A lot of the books here are handwritten journals, rather than printed books."
    "Muchos de los libros de aquí son diarios escritos a mano, en lugar de libros impresos."

# game/beyond the bet/flowerend.rpy:219
translate Spanish dlc_flowerend_start_b3923747:

    # "It opens when you test it."
    "Se abre cuando la pruebas."

# game/beyond the bet/flowerend.rpy:220
translate Spanish dlc_flowerend_start_cdfc5e1d:

    # "Phew."
    "Uf."

# game/beyond the bet/flowerend.rpy:221
translate Spanish dlc_flowerend_start_3272a9ad:

    # "Feeling a little more relaxed, you turn towards the books."
    "Con algo más de calma, te vuelves hacia los libros."

# game/beyond the bet/flowerend.rpy:231
translate Spanish dlc_flowerend_start_33cc9f5e:

    # "Seconds become minutes, minutes become hours as you search through the vast collection of the Library of the Lost."
    "Los segundos se vuelven minutos y los minutos, horas mientras rebuscas en la vasta colección de la Biblioteca de los Perdidos."

# game/beyond the bet/flowerend.rpy:237
translate Spanish dlc_flowerend_start_fd82642f:

    # "You find books and journals about all kinds of things related to being a Grim Reaper or one of the other inhabitants of the Underworld - history, culture, politics..."
    "Encuentras libros y diarios sobre todo tipo de temas relacionados con ser una Parca o uno de los otros habitantes del Inframundo: historia, cultura, política..."

# game/beyond the bet/flowerend.rpy:238
translate Spanish dlc_flowerend_start_aab90191:

    # "A lot of it is above your head."
    "Mucho de ello se te escapa."

# game/beyond the bet/flowerend.rpy:252
translate Spanish dlc_flowerend_start_1b822c86:

    # "You keep looking, pensively."
    "Sigues buscando, con aire pensativo."

# game/beyond the bet/flowerend.rpy:259
translate Spanish dlc_flowerend_start_27c35e89:

    # "As the hours tick by, you begin to lose hope."
    "A medida que pasan las horas, empiezas a perder la esperanza."

# game/beyond the bet/flowerend.rpy:260
translate Spanish dlc_flowerend_start_54f558af:

    # "But, in a small section towards the back of the library, you find a book."
    "Pero, en una pequeña sección al fondo de la biblioteca, encuentras un libro."

# game/beyond the bet/flowerend.rpy:261
translate Spanish dlc_flowerend_start_d1ef4415:

    # "It's dusty and faded, and the pages are brittle and yellowed."
    "Está cubierto de polvo y descolorido, y sus páginas son quebradizas y amarillentas."

# game/beyond the bet/flowerend.rpy:262
translate Spanish dlc_flowerend_start_1d28f01a:

    # "You open it, then cough a little. Very musty."
    "Lo abres y toses un poco. Huele muchísimo a humedad."

# game/beyond the bet/flowerend.rpy:263
translate Spanish dlc_flowerend_start_f3bbbf63:

    # "In washed out ink, you read the title - The Laws of Life and Death."
    "En tinta desvaída, lees el título: Las Leyes de la Vida y la Muerte."

# game/beyond the bet/flowerend.rpy:264
translate Spanish dlc_flowerend_start_51569bb4:

    # "Inside is pages upon pages of laws, rules, and regulations that all reapers are required to follow."
    "Dentro hay páginas y páginas de leyes, reglas y normas que todas las parcas deben cumplir."

# game/beyond the bet/flowerend.rpy:265
translate Spanish dlc_flowerend_start_db04217e:

    # "Some of them are easy enough to understand - do not tell humans the secrets of the afterlife, for example."
    "Algunas son bastante fáciles de entender: no revelar a los humanos los secretos del más allá, por ejemplo."

# game/beyond the bet/flowerend.rpy:266
translate Spanish dlc_flowerend_start_d94fe231:

    # "But others are a little vague."
    "Pero otras son un poco vagas."

# game/beyond the bet/flowerend.rpy:267
translate Spanish dlc_flowerend_start_bec55537:

    # "'The Grim Reaper shall not fall in love.'"
    "'La Parca no se enamorará.'"

# game/beyond the bet/flowerend.rpy:268
translate Spanish dlc_flowerend_start_0492379c:

    # "'The Grim Reaper does not age. They will live as long as the world does, and will cease only when the world ceases.'"
    "'La Parca no envejece. Vivirá tanto como el mundo, y solo cesará cuando el mundo cese.'"

# game/beyond the bet/flowerend.rpy:269
translate Spanish dlc_flowerend_start_19fe994a:

    # "'The Grim Reaper is not a god. They have no power to judge those who die, nor do they have any power over life and death. They can only take the souls of those who are set to die, and are bound by the rules of their masters.'"
    "'La Parca no es un dios. No tiene poder para juzgar a quienes mueren, ni poder alguno sobre la vida y la muerte. Solo puede tomar las almas de quienes están destinados a morir, y está sujeta a las reglas de sus amos.'"

# game/beyond the bet/flowerend.rpy:270
translate Spanish dlc_flowerend_start_1e6d61d3:

    # "'The Grim Reaper may not interfere with the lives of mortals.'"
    "'La Parca no puede interferir en la vida de los mortales.'"

# game/beyond the bet/flowerend.rpy:271
translate Spanish dlc_flowerend_start_7799d739:

    # "On, and on, and on, the rules are neverending."
    "Y así, una y otra vez, las reglas no se acaban nunca."

# game/beyond the bet/flowerend.rpy:272
translate Spanish dlc_flowerend_start_ccf25cab:

    # "And you're certain you and Casper have broke a lot of these. Whoops."
    "Y seguro que Casper y tú han roto un montón de ellas. Ups."

# game/beyond the bet/flowerend.rpy:273
translate Spanish dlc_flowerend_start_86bae9ec:

    # "Anyway. You're sure there's something in here you could use, but there's only so much time."
    "En fin. Seguro que aquí hay algo que podrías usar, pero el tiempo es limitado."

# game/beyond the bet/flowerend.rpy:274
translate Spanish dlc_flowerend_start_ea1103f0:

    # "Eventually, you flip to the back section of the book, and you find something..."
    "Al final, pasas a la sección del final del libro y encuentras algo..."

# game/beyond the bet/flowerend.rpy:275
translate Spanish dlc_flowerend_start_5109a36f:

    # "'The Law of Equal Souls'."
    "'La Ley de las Almas Iguales'."

# game/beyond the bet/flowerend.rpy:276
translate Spanish dlc_flowerend_start_2c7abd85:

    # "'The Grim Reaper may not become mortal. However, should they be willingly gifted the entirety of a soul's life essence by one of equal but opposite nature, the reaper will become afflicted with what is known as soulsickness.'"
    "'La Parca no puede volverse mortal. Sin embargo, si alguien de naturaleza igual pero opuesta le regala voluntariamente la totalidad de la esencia vital de su alma, la Parca se verá afectada por lo que se conoce como enfermedad del alma.'"

# game/beyond the bet/flowerend.rpy:277
translate Spanish dlc_flowerend_start_a51ec8f6:

    # "'This condition erodes their immortal existence and causes them to gradually regain mortality. The process is irreversible.'"
    "'Esta afección erosiona su existencia inmortal y hace que recupere gradualmente la mortalidad. El proceso es irreversible.'"

# game/beyond the bet/flowerend.rpy:278
translate Spanish dlc_flowerend_start_7871181e:

    # "'The exchange, once completed, leaves both souls mortal, severing their connection to the forces of life and death. If one with such a soul sacrifices for the Grim Reaper, they will be allowed a mortal life once again.'"
    "'Una vez completado el intercambio, ambas almas quedan mortales, cortando su conexión con las fuerzas de la vida y la muerte. Si alguien con un alma así se sacrifica por la Parca, a esta se le permitirá una vida mortal de nuevo.'"

# game/beyond the bet/flowerend.rpy:287
translate Spanish dlc_flowerend_start_9a5317b6:

    # "You turn and rush towards the door, book in hand, but stop dead."
    "Te giras y corres hacia la puerta, con el libro en la mano, pero te detienes en seco."

# game/beyond the bet/flowerend.rpy:288
translate Spanish dlc_flowerend_start_3682f1d9:

    # "The door is sealed tight, and no matter how much you pull and push, you can't get it to open."
    "La puerta está sellada a cal y canto, y por mucho que tires y empujes, no consigues abrirla."

# game/beyond the bet/flowerend.rpy:296
translate Spanish dlc_flowerend_start_ec6786c7:

    # "All around you is silence."
    "A tu alrededor solo hay silencio."

# game/beyond the bet/flowerend.rpy:300
translate Spanish dlc_flowerend_start_c844e4ab:

    # "Fine, you think."
    "Bien, piensas."

# game/beyond the bet/flowerend.rpy:301
translate Spanish dlc_flowerend_start_36cf4989:

    # "You don't need to leave the building to talk to Casper."
    "No necesitas salir del edificio para hablar con Casper."

# game/beyond the bet/flowerend.rpy:303
translate Spanish dlc_flowerend_start_6e531c4b:

    # "You can leave him a message, so he knows where to find you!"
    "¡Puedes dejarle un mensaje para que sepa dónde encontrarte!"

# game/beyond the bet/flowerend.rpy:338
translate Spanish flowerendchat1_84025b55:

    # player "Casper!"
    player "¡Casper!"

# game/beyond the bet/flowerend.rpy:340
translate Spanish flowerendchat1_d12a01c0:

    # player "Caspy-Waspy!"
    player "¡Caspy-Waspy!"

# game/beyond the bet/flowerend.rpy:342
translate Spanish flowerendchat1_b013eb86:

    # player "Grimmy!"
    player "¡Parquita!"

# game/beyond the bet/flowerend.rpy:345
translate Spanish flowerendchat1_73e72e96:

    # player "It's me."
    player "Soy yo."

# game/beyond the bet/flowerend.rpy:348
translate Spanish flowerendchat1_125d6559:

    # player "[playerfirstname] [playerlastname], in case you somehow forgot."
    player "[playerfirstname] [playerlastname], por si acaso se te olvidó."

# game/beyond the bet/flowerend.rpy:351
translate Spanish flowerendchat1_45416a27:

    # player "TBH I think that would be impossible..."
    player "La verdad, creo que eso sería imposible..."

# game/beyond the bet/flowerend.rpy:353
translate Spanish flowerendchat1_7ef2b29b:

    # player "Maybe you're getting memory issues with your old age? idk."
    player "¿Quizá tienes problemas de memoria por la vejez? ni idea."

# game/beyond the bet/flowerend.rpy:356
translate Spanish flowerendchat1_426a43ac:

    # player "Anyway..."
    player "En fin..."

# game/beyond the bet/flowerend.rpy:357
translate Spanish flowerendchat1_b0d70e95:

    # GR "SUNSHINE!"
    GR "¡SOLECITO!"

# game/beyond the bet/flowerend.rpy:360
translate Spanish flowerendchat1_2e327660:

    # player "Woah, no need to yell."
    player "Uy, no hace falta gritar."

# game/beyond the bet/flowerend.rpy:363
translate Spanish flowerendchat1_b927c0f5:

    # player "Go back to all lowercase, please."
    player "Vuelve a escribir todo en minúsculas, por favor."

# game/beyond the bet/flowerend.rpy:365
translate Spanish flowerendchat1_76fbd30e:

    # player "This feels like when your parents or grandparents use your full name..."
    player "Esto se siente como cuando tus padres o abuelos usan tu nombre completo..."

# game/beyond the bet/flowerend.rpy:368
translate Spanish flowerendchat1_0b8cf938:

    # player "Except Sunshine isn't my name."
    player "Solo que Solecito no es mi nombre."

# game/beyond the bet/flowerend.rpy:371
translate Spanish flowerendchat1_7e3487a7:

    # player "At least, I don't think it is."
    player "Al menos, no creo que lo sea."

# game/beyond the bet/flowerend.rpy:373
translate Spanish flowerendchat1_bcc4759a:

    # player "I'd get that all the time..."
    player "Eso me pasaba siempre..."

# game/beyond the bet/flowerend.rpy:374
translate Spanish flowerendchat1_7772a27d:

    # GR "..."
    GR "..."

# game/beyond the bet/flowerend.rpy:375
translate Spanish flowerendchat1_7d0b0c9f:

    # GR "where are you? "
    GR "¿dónde estás? "

# game/beyond the bet/flowerend.rpy:378
translate Spanish flowerendchat1_8ba9d1bc:

    # player "Well, where are you?"
    player "Bueno, ¿y tú dónde estás?"

# game/beyond the bet/flowerend.rpy:379
translate Spanish flowerendchat1_ad77407d:

    # GR "you are answering a question with a question."
    GR "estás respondiendo una pregunta con otra pregunta."

# game/beyond the bet/flowerend.rpy:382
translate Spanish flowerendchat1_c45997d0:

    # player "Am I?"
    player "¿Ah, sí?"

# game/beyond the bet/flowerend.rpy:383
translate Spanish flowerendchat1_7772a27d_1:

    # GR "..."
    GR "..."

# game/beyond the bet/flowerend.rpy:386
translate Spanish flowerendchat1_310dbe54:

    # player "I'm in that library."
    player "Estoy en esa biblioteca."

# game/beyond the bet/flowerend.rpy:388
translate Spanish flowerendchat1_536736f1:

    # player "Is that illegal?"
    player "¿Eso es ilegal?"

# game/beyond the bet/flowerend.rpy:389
translate Spanish flowerendchat1_ab5aadfb:

    # GR "i truly believe it should be."
    GR "sinceramente creo que debería serlo."

# game/beyond the bet/flowerend.rpy:392
translate Spanish flowerendchat1_f648c408:

    # player "You do it all the time."
    player "Tú lo haces todo el tiempo."

# game/beyond the bet/flowerend.rpy:393
translate Spanish flowerendchat1_d10fbac0:

    # GR "i, of course, am above the law."
    GR "yo, por supuesto, estoy por encima de la ley."

# game/beyond the bet/flowerend.rpy:396
translate Spanish flowerendchat1_681a04e2:

    # player "Uh huh. Sure."
    player "Ajá. Claro."

# game/beyond the bet/flowerend.rpy:399
translate Spanish flowerendchat1_d1e1deeb:

    # player "But anyways!"
    player "¡Pero bueno!"

# game/beyond the bet/flowerend.rpy:402
translate Spanish flowerendchat1_16f6e32f:

    # player "I'm in a very musty library."
    player "Estoy en una biblioteca que huele muchísimo a humedad."

# game/beyond the bet/flowerend.rpy:405
translate Spanish flowerendchat1_e5bc3bd8:

    # player "I'm not telling."
    player "No te lo diré."

# game/beyond the bet/flowerend.rpy:406
translate Spanish flowerendchat1_7def630c:

    # GR "why?!"
    GR "¡¿por qué?!"

# game/beyond the bet/flowerend.rpy:409
translate Spanish flowerendchat1_f12e67a0:

    # player "I want to be fun and mysterious."
    player "Quiero ser divertid[letra] y misterios[letra]."

# game/beyond the bet/flowerend.rpy:410
translate Spanish flowerendchat1_7ba774fd:

    # GR "how is this fun or mysterious?!?!?!"
    GR "¡¿¡¿¡¿cómo es esto divertido o misterioso?!?!?!"

# game/beyond the bet/flowerend.rpy:411
translate Spanish flowerendchat1_078bc02c:

    # GR "i thought you were dead!"
    GR "¡pensé que estabas muert[letra]!"

# game/beyond the bet/flowerend.rpy:414
translate Spanish flowerendchat1_be0b1348:

    # player "Still kicking, dw."
    player "Aquí sigo, tranqui."

# game/beyond the bet/flowerend.rpy:417
translate Spanish flowerendchat1_b1521468:

    # player "I'm in a big ol' library."
    player "Estoy en una biblioteca enorme."

# game/beyond the bet/flowerend.rpy:420
translate Spanish flowerendchat1_40111962:

    # player "I like to make you beg just a little."
    player "Me gusta hacerte suplicar un poquito."

# game/beyond the bet/flowerend.rpy:421
translate Spanish flowerendchat1_a9fb3ef7:

    # GR "is now really the time???"
    GR "¿¿¿de verdad es el momento???"

# game/beyond the bet/flowerend.rpy:424
translate Spanish flowerendchat1_f8202829:

    # player "It's always the time for begging, Casper."
    player "Siempre es momento de suplicar, Casper."

# game/beyond the bet/flowerend.rpy:427
translate Spanish flowerendchat1_21d2bd04:

    # player "Please, take this seriously."
    player "Por favor, tómate esto en serio."

# game/beyond the bet/flowerend.rpy:428
translate Spanish flowerendchat1_7772a27d_2:

    # GR "..."
    GR "..."

# game/beyond the bet/flowerend.rpy:429
translate Spanish flowerendchat1_e296e9c6:

    # GR "you are the worst."
    GR "eres lo peor."

# game/beyond the bet/flowerend.rpy:430
translate Spanish flowerendchat1_0f4655c4:

    # GR "please?"
    GR "¿por favor?"

# game/beyond the bet/flowerend.rpy:433
translate Spanish flowerendchat1_867d58d2:

    # player "Awww, good boy."
    player "Awww, buen chico."

# game/beyond the bet/flowerend.rpy:436
translate Spanish flowerendchat1_744149d0:

    # player "I'm in that library you told me about."
    player "Estoy en esa biblioteca de la que me hablaste."

# game/beyond the bet/flowerend.rpy:440
translate Spanish flowerendchat1_7712308c:

    # player "Uhh... big library?"
    player "Eh... ¿biblioteca grande?"

# game/beyond the bet/flowerend.rpy:442
translate Spanish flowerendchat1_90248968:

    # GR "you're WHAT?"
    GR "¿QUÉ?"

# game/beyond the bet/flowerend.rpy:445
translate Spanish flowerendchat1_812566c5:

    # player "Sorry, did it glitch out?"
    player "Perdona, ¿se cortó la conexión?"

# game/beyond the bet/flowerend.rpy:448
translate Spanish flowerendchat1_14e710be:

    # player "I'm in the library."
    player "Estoy en la biblioteca."

# game/beyond the bet/flowerend.rpy:451
translate Spanish flowerendchat1_8bdba931:

    # player "L.I.B.R.A.R.Y."
    player "B.I.B.L.I.O.T.E.C.A."

# game/beyond the bet/flowerend.rpy:454
translate Spanish flowerendchat1_4f959767:

    # player "Yeah, I know..."
    player "Sí, ya lo sé..."

# game/beyond the bet/flowerend.rpy:457
translate Spanish flowerendchat1_f4092ffa:

    # player "Sorry, Grimmy. I know I shouldn't have left."
    player "Perdón, Parquita. Sé que no debí irme."

# game/beyond the bet/flowerend.rpy:459
translate Spanish flowerendchat1_8bb7ce81:

    # GR "what are you doing there???"
    GR "¿¿¿qué haces ahí???"

# game/beyond the bet/flowerend.rpy:462
translate Spanish flowerendchat1_bdbfe8e0:

    # player "I wanted to help you."
    player "Quería ayudarte."

# game/beyond the bet/flowerend.rpy:464
translate Spanish flowerendchat1_c2c20e6f:

    # player "I knew there had to be something here."
    player "Sabía que tenía que haber algo aquí."

# game/beyond the bet/flowerend.rpy:467
translate Spanish flowerendchat1_6a8f2a1e:

    # player "Something to help the both of us."
    player "Algo que nos ayudara a los dos."

# game/beyond the bet/flowerend.rpy:469
translate Spanish flowerendchat1_2ae12f88:

    # GR "and so, you went... all by yourself...?"
    GR "¿y entonces fuiste... tú sol[letra]...?"

# game/beyond the bet/flowerend.rpy:470
translate Spanish flowerendchat1_45a53da9:

    # GR "stay right there, i'm coming."
    GR "quédate ahí, voy para allá."

# game/beyond the bet/flowerend.rpy:473
translate Spanish flowerendchat1_b3edb214:

    # player "Wait!"
    player "¡Espera!"

# game/beyond the bet/flowerend.rpy:476
translate Spanish flowerendchat1_6cba71ac:

    # player "I found something."
    player "Encontré algo."

# game/beyond the bet/flowerend.rpy:477
translate Spanish flowerendchat1_e531c1b6:

    # GR "then tell me about it in person!"
    GR "¡entonces cuéntamelo en persona!"

# game/beyond the bet/flowerend.rpy:480
translate Spanish flowerendchat1_80fe4f58:

    # player "I might do something stupid."
    player "Puede que haga una tontería."

# game/beyond the bet/flowerend.rpy:481
translate Spanish flowerendchat1_da3ebee4:

    # GR "you are always doing something stupid!"
    GR "¡siempre estás haciendo alguna tontería!"

# game/beyond the bet/flowerend.rpy:482
translate Spanish flowerendchat1_4554e00d:

    # GR "it is a problem of yours!"
    GR "¡es un problema tuyo!"

# game/beyond the bet/flowerend.rpy:483
translate Spanish flowerendchat1_5d3faab1:

    # GR "you have no regard for your own life."
    GR "no tienes ningún aprecio por tu propia vida."

# game/beyond the bet/flowerend.rpy:486
translate Spanish flowerendchat1_380c66e8:

    # player "You're worth risking it for."
    player "Mereces que lo arriesgue."

# game/beyond the bet/flowerend.rpy:488
translate Spanish flowerendchat1_e73dc57e:

    # player "I would happily give it up for you."
    player "Con gusto la daría por ti."

# game/beyond the bet/flowerend.rpy:489
translate Spanish flowerendchat1_703264c4:

    # GR "ah..."
    GR "ah..."

# game/beyond the bet/flowerend.rpy:490
translate Spanish flowerendchat1_702b75c5:

    # GR "sunshine, i..."
    GR "solecito, yo..."

# game/beyond the bet/flowerend.rpy:491
translate Spanish flowerendchat1_926a29d4:

    # GR "i could not handle it if something happened to you because of me."
    GR "no podría soportar que te pasara algo por mi culpa."

# game/beyond the bet/flowerend.rpy:492
translate Spanish flowerendchat1_39c17e58:

    # GR "no matter what, i need you to be safe."
    GR "pase lo que pase, necesito que estés a salvo."

# game/beyond the bet/flowerend.rpy:493
translate Spanish flowerendchat1_0819d5a5:

    # GR "what comes of me is secondary."
    GR "lo que sea de mí es secundario."

# game/beyond the bet/flowerend.rpy:496
translate Spanish flowerendchat1_b843d9c8:

    # player "Sorry Casper, no can do."
    player "Lo siento, Casper, no puedo."

# game/beyond the bet/flowerend.rpy:498
translate Spanish flowerendchat1_d5fc368a:

    # player "Hmm... no."
    player "Mmm... no."

# game/beyond the bet/flowerend.rpy:501
translate Spanish flowerendchat1_e4de43bb:

    # player "Are you back at your house now?"
    player "¿Ya estás de vuelta en tu casa?"

# game/beyond the bet/flowerend.rpy:502
translate Spanish flowerendchat1_1f7df39c:

    # GR "yes. i just arrived back to find you gone."
    GR "sí. acabo de volver y me encontré con que no estabas."

# game/beyond the bet/flowerend.rpy:503
translate Spanish flowerendchat1_1f249f31:

    # GR "i thought..."
    GR "pensé..."

# game/beyond the bet/flowerend.rpy:506
translate Spanish flowerendchat1_f8606af5:

    # player "That's my bad."
    player "Es culpa mía."

# game/beyond the bet/flowerend.rpy:509
translate Spanish flowerendchat1_13a0a3a4:

    # player "I know I shouldn't be wandering about here, but..."
    player "Sé que no debería andar vagando por aquí, pero..."

# game/beyond the bet/flowerend.rpy:512
translate Spanish flowerendchat1_83615345:

    # player "Look, accept this, okay?"
    player "Mira, acéptalo, ¿okey?"

# game/beyond the bet/flowerend.rpy:549
translate Spanish call1_dayflowerend_b4671a15:

    # GRC "Sunshine, there's no time for this."
    GRC "Solecito, no hay tiempo para esto."

# game/beyond the bet/flowerend.rpy:550
translate Spanish call1_dayflowerend_f7961d9b:

    # GRC "I must come and get you."
    GRC "Debo ir a buscarte."

# game/beyond the bet/flowerend.rpy:554
translate Spanish call1_dayflowerend_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/flowerend.rpy:556
translate Spanish call1_dayflowerend_4258105b:

    # GRC "...Why do you ask?"
    GRC "...¿Por qué lo preguntas?"

# game/beyond the bet/flowerend.rpy:566
translate Spanish call1_dayflowerend_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/flowerend.rpy:568
translate Spanish call1_dayflowerend_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/beyond the bet/flowerend.rpy:569
translate Spanish call1_dayflowerend_f90d4d6d:

    # GRC "If you had asked me six months ago, I would have said no."
    GRC "Si me lo hubieras preguntado hace seis meses, habría dicho que no."

# game/beyond the bet/flowerend.rpy:570
translate Spanish call1_dayflowerend_c92bdfd4:

    # GRC "I have always been this job. It was always enough."
    GRC "Siempre he sido este trabajo. Siempre fue suficiente."

# game/beyond the bet/flowerend.rpy:572
translate Spanish call1_dayflowerend_05e093f2:

    # GRC "But now..."
    GRC "Pero ahora..."

# game/beyond the bet/flowerend.rpy:573
translate Spanish call1_dayflowerend_b8766cd5:

    # GRC "...I would give anything for that."
    GRC "...Daría cualquier cosa por eso."

# game/beyond the bet/flowerend.rpy:575
translate Spanish call1_dayflowerend_7b802933:

    # GRC "To be able to be by your side, without putting you in danger..."
    GRC "Poder estar a tu lado, sin ponerte en peligro..."

# game/beyond the bet/flowerend.rpy:576
translate Spanish call1_dayflowerend_1f5931d9:

    # GRC "To experience the fleeting beauty of life..."
    GRC "Experimentar la fugaz belleza de la vida..."

# game/beyond the bet/flowerend.rpy:577
translate Spanish call1_dayflowerend_fe7c7805:

    # GRC "...But that is not possible."
    GRC "...Pero eso no es posible."

# game/beyond the bet/flowerend.rpy:584
translate Spanish call1_dayflowerend_a24a639d:

    # GRC "What do you mean?"
    GRC "¿Qué quieres decir?"

# game/beyond the bet/flowerend.rpy:591
translate Spanish call1_dayflowerend_f92353b0:

    # GRC "I demand you tell me now."
    GRC "Exijo que me lo digas ahora."

# game/beyond the bet/flowerend.rpy:628
translate Spanish call1_dayflowerend_4fd2622a:

    # GRC "You are an idiot, you know that?"
    GRC "Eres [arti_2] idiota, ¿lo sabías?"

# game/beyond the bet/flowerend.rpy:640
translate Spanish call1_dayflowerend_b47c53b0:

    # GRC "You'll be a dead idiot if you keep this up."
    GRC "Serás [arti_2] idiota muert[letra] si sigues así."

# game/beyond the bet/flowerend.rpy:647
translate Spanish call1_dayflowerend_c1ce1efe:

    # GRC "I do not want that in the slightest anymore."
    GRC "Ya no quiero eso en lo más mínimo."

# game/beyond the bet/flowerend.rpy:649
translate Spanish call1_dayflowerend_7014af40:

    # GRC "Do not depart that building. I'm leaving now."
    GRC "No salgas de ese edificio. Salgo ahora mismo."

# game/beyond the bet/flowerend.rpy:661
translate Spanish call1_dayflowerend_008afe10_2:

    # GRC "..."
    GRC "..."

# game/beyond the bet/flowerend.rpy:663
translate Spanish call1_dayflowerend_f97736f7:

    # GRC "Gods, I am an idiot for getting involved with you."
    GRC "Dioses, qué idiota soy por haberme involucrado contigo."

# game/beyond the bet/flowerend.rpy:688
translate Spanish chat2_dayflowerend_78259047:

    # "You smile towards your laptop."
    "Le sonríes a tu laptop."

# game/beyond the bet/flowerend.rpy:689
translate Spanish chat2_dayflowerend_75a38e78:

    # "You really are just a pair of idiots."
    "De verdad son un par de idiotas."

# game/beyond the bet/flowerend.rpy:691
translate Spanish chat2_dayflowerend_6b4e74ab:

    # "With a shake of your head, you close the lid, and almost jump out of your skin as you see someone standing on the other side."
    "Con un movimiento de cabeza, cierras la tapa y casi te da un infarto al ver a alguien de pie al otro lado."

# game/beyond the bet/flowerend.rpy:714
translate Spanish chat2_dayflowerend_960994b4:

    # O_ip "And so, the little stray piece of Sunshine finally decides to pay attention to their surroundings."
    O_ip "Y así, el pequeño pedacito extraviado de Solecito por fin decide prestar atención a su entorno."

# game/beyond the bet/flowerend.rpy:721
translate Spanish chat2_dayflowerend_73aee28f:

    # O_ip "That's not a very polite way to talk to someone you've just met."
    O_ip "Esa no es una manera muy cortés de hablarle a alguien que acabas de conocer."

# game/beyond the bet/flowerend.rpy:728
translate Spanish chat2_dayflowerend_b77d2a3d:

    # O_ip "Names aren't important for my kind."
    O_ip "Los nombres no son importantes para los de mi clase."

# game/beyond the bet/flowerend.rpy:729
translate Spanish chat2_dayflowerend_8aa1d0b6:

    # O_ip "Except to those that stray."
    O_ip "Excepto para quienes se desvían."

# game/beyond the bet/flowerend.rpy:730
translate Spanish chat2_dayflowerend_2708ec65:

    # O_ip "I believe you know someone like that, don't you?"
    O_ip "Creo que conoces a alguien así, ¿verdad?"

# game/beyond the bet/flowerend.rpy:734
translate Spanish chat2_dayflowerend_e44b4fae:

    # O_ip "Who am I?"
    O_ip "¿Quién soy?"

# game/beyond the bet/flowerend.rpy:735
translate Spanish chat2_dayflowerend_4e441e8f:

    # O_ip "No one important."
    O_ip "Nadie importante."

# game/beyond the bet/flowerend.rpy:736
translate Spanish chat2_dayflowerend_4af83251:

    # O_ip "I'm more interested in you."
    O_ip "Me interesas más tú."

# game/beyond the bet/flowerend.rpy:742
translate Spanish chat2_dayflowerend_e163f841:

    # O_ip "A Grim Reaper, really?"
    O_ip "¿Una Parca, en serio?"

# game/beyond the bet/flowerend.rpy:746
translate Spanish chat2_dayflowerend_25e96da9:

    # O_ip "You are funny, I'll give you that."
    O_ip "Tienes gracia, eso te lo concedo."

# game/beyond the bet/flowerend.rpy:747
translate Spanish chat2_dayflowerend_80dd7a2c:

    # O_ip "Funny in a pathetic kind of way."
    O_ip "Una gracia patética, eso sí."

# game/beyond the bet/flowerend.rpy:759
translate Spanish chat2_dayflowerend_6f26abde:

    # O_ip "Oh, yes, mortals are so very interesting."
    O_ip "Oh, sí, los mortales son muy interesantes."

# game/beyond the bet/flowerend.rpy:760
translate Spanish chat2_dayflowerend_c055ff4b:

    # O_ip "I'm sure you'll have plenty to tell me, then."
    O_ip "Seguro que entonces tendrás mucho que contarme."

# game/beyond the bet/flowerend.rpy:765
translate Spanish chat2_dayflowerend_d3c02811:

    # O_ip "Let's cut to the chase, shall we?"
    O_ip "Vayamos al grano, ¿te parece?"

# game/beyond the bet/flowerend.rpy:767
translate Spanish chat2_dayflowerend_ed17dca4:

    # O_ip "You're supposed to be dead."
    O_ip "Se supone que deberías estar muert[letra]."

# game/beyond the bet/flowerend.rpy:768
translate Spanish chat2_dayflowerend_5d79864b:

    # O_ip "Reaper 8394 of the 13th Station—the one you call 'Casper'—has gone against the natural order of the world in order to keep you alive."
    O_ip "La Parca 8394 de la 13.ª Estación —a quien tú llamas 'Casper'— ha ido contra el orden natural del mundo para mantenerte con vida."

# game/beyond the bet/flowerend.rpy:780
translate Spanish chat2_dayflowerend_6b439440:

    # O_ip "That's not possible."
    O_ip "Eso no es posible."

# game/beyond the bet/flowerend.rpy:781
translate Spanish chat2_dayflowerend_1b3562b8:

    # O_ip "But I believe you know why you're still here already."
    O_ip "Pero creo que ya sabes por qué sigues aquí."

# game/beyond the bet/flowerend.rpy:782
translate Spanish chat2_dayflowerend_3028259a:

    # O_ip "You have a very special soul."
    O_ip "Tienes un alma muy especial."

# game/beyond the bet/flowerend.rpy:783
translate Spanish chat2_dayflowerend_bea91bd9:

    # O_ip "A soul that belongs to our organization."
    O_ip "Un alma que pertenece a nuestra organización."

# game/beyond the bet/flowerend.rpy:786
translate Spanish chat2_dayflowerend_5a160ffd:

    # O_ip "You have... borrowed it, you could say."
    O_ip "La has... tomado prestada, podría decirse."

# game/beyond the bet/flowerend.rpy:787
translate Spanish chat2_dayflowerend_ad645d89:

    # O_ip "But it does not belong to you."
    O_ip "Pero no te pertenece."

# game/beyond the bet/flowerend.rpy:789
translate Spanish chat2_dayflowerend_847393bb:

    # O_ip "Did I say you had a choice?"
    O_ip "¿Acaso dije que tuvieras opción?"

# game/beyond the bet/flowerend.rpy:791
translate Spanish chat2_dayflowerend_429f36df:

    # O_ip "I do."
    O_ip "Yo lo digo."

# game/beyond the bet/flowerend.rpy:794
translate Spanish chat2_dayflowerend_703a1fca:

    # O_ip "As much as I would love to stand here and chat to you, I really don't."
    O_ip "Por mucho que me encantaría quedarme aquí charlando contigo, la verdad es que no."

# game/beyond the bet/flowerend.rpy:795
translate Spanish chat2_dayflowerend_8a5f2e7a:

    # O_ip "You will hand over your soul as instructed."
    O_ip "Entregarás tu alma según lo indicado."

# game/beyond the bet/flowerend.rpy:796
translate Spanish chat2_dayflowerend_bcc998b0:

    # O_ip "If you do so quickly, then perhaps we will show some leniency to your 'Casper'."
    O_ip "Si lo haces rápido, quizá seamos indulgentes con tu 'Casper'."

# game/beyond the bet/flowerend.rpy:802
translate Spanish chat2_dayflowerend_381d226f:

    # O_ip "You do not."
    O_ip "No lo sabes."

# game/beyond the bet/flowerend.rpy:803
translate Spanish chat2_dayflowerend_50040294:

    # O_ip "Only a fool would trust someone they have just met."
    O_ip "Solo un necio confiaría en alguien que acaba de conocer."

# game/beyond the bet/flowerend.rpy:806
translate Spanish chat2_dayflowerend_1eeeb98f:

    # O_ip "I believe you know my kind to be incapable of lies."
    O_ip "Creo que sabes que los de mi clase son incapaces de mentir."

# game/beyond the bet/flowerend.rpy:810
translate Spanish chat2_dayflowerend_1a252c36:

    # O_ip "That is true, yes."
    O_ip "Eso es cierto, sí."

# game/beyond the bet/flowerend.rpy:816
translate Spanish chat2_dayflowerend_62ad2581:

    # "You look around the room - it's empty, save for the two of you."
    "Miras alrededor de la habitación: está vacía, salvo por ustedes dos."

# game/beyond the bet/flowerend.rpy:817
translate Spanish chat2_dayflowerend_cfa42358:

    # "Casper hasn't arrived yet."
    "Casper aún no ha llegado."

# game/beyond the bet/flowerend.rpy:818
translate Spanish chat2_dayflowerend_0e92b9b8:

    # "You need time."
    "Necesitas tiempo."

# game/beyond the bet/flowerend.rpy:819
translate Spanish chat2_dayflowerend_801a6739:

    # "Fortunately, if you're good at anything, it's stalling for time with bullshit."
    "Por suerte, si algo se te da bien, es ganar tiempo soltando puras tonterías."

# game/beyond the bet/flowerend.rpy:823
translate Spanish chat2_dayflowerend_11197e13:

    # O_ip "Good. Then-"
    O_ip "Bien. Entonces..."

# game/beyond the bet/flowerend.rpy:835
translate Spanish chat2_dayflowerend_fcc47655:

    # O_ip "Hm..."
    O_ip "Hm…"

# game/beyond the bet/flowerend.rpy:836
translate Spanish chat2_dayflowerend_cf927ade:

    # O_ip "What is there you could possibly want to know?"
    O_ip "¿Qué podrías querer saber?"

# game/beyond the bet/flowerend.rpy:840
translate Spanish chat2_dayflowerend_cc761909:

    # O_ip "I do not have one."
    O_ip "No tengo uno."

# game/beyond the bet/flowerend.rpy:844
translate Spanish chat2_dayflowerend_96c6e745:

    # O_ip "None."
    O_ip "Ninguno."

# game/beyond the bet/flowerend.rpy:848
translate Spanish chat2_dayflowerend_bb2ea68b:

    # O_ip "Six hundred and sixty six."
    O_ip "Seiscientos sesenta y seis."

# game/beyond the bet/flowerend.rpy:855
translate Spanish chat2_dayflowerend_0bc5c76c:

    # O_ip "Who has a favorite vowel?"
    O_ip "¿Quién tiene una vocal favorita?"

# game/beyond the bet/flowerend.rpy:869
translate Spanish chat2_dayflowerend_7558553d:

    # O_ip "I do not feel any special connections to any vowel in particular."
    O_ip "No siento ninguna conexión especial con ninguna vocal en particular."

# game/beyond the bet/flowerend.rpy:881
translate Spanish chat2_dayflowerend_83872d29:

    # O_ip "Enough."
    O_ip "Basta."

# game/beyond the bet/flowerend.rpy:882
translate Spanish chat2_dayflowerend_b93ab0a4:

    # O_ip "I grow tired of your silly little games."
    O_ip "Me estoy cansando de tus tontos jueguitos."

# game/beyond the bet/flowerend.rpy:883
translate Spanish chat2_dayflowerend_dfc69ce1:

    # O_ip "Vowels and colors and numbers and names do not matter."
    O_ip "Las vocales, los colores, los números y los nombres no importan."

# game/beyond the bet/flowerend.rpy:884
translate Spanish chat2_dayflowerend_bf7dfe9e:

    # O_ip "All that matters is your soul."
    O_ip "Lo único que importa es tu alma."

# game/beyond the bet/flowerend.rpy:889
translate Spanish chat2_dayflowerend_416fb09a:

    # O_ip "Your... riddle?"
    O_ip "¿Tu... adivinanza?"

# game/beyond the bet/flowerend.rpy:897
translate Spanish chat2_dayflowerend_dca6be38:

    # O_ip "You stand here, on the day of your demise, and you ask me a philosophical question?"
    O_ip "¿Estás aquí, en el día de tu muerte, y me haces una pregunta filosófica?"

# game/beyond the bet/flowerend.rpy:898
translate Spanish chat2_dayflowerend_0fe85370:

    # O_ip "I don't see how the end of everything is a riddle, but fine."
    O_ip "No veo cómo el final de todo es una adivinanza, pero bien."

# game/beyond the bet/flowerend.rpy:899
translate Spanish chat2_dayflowerend_a5c1950f:

    # O_ip "At the end of everything, there will be nothing."
    O_ip "Al final de todo, no habrá nada."

# game/beyond the bet/flowerend.rpy:900
translate Spanish chat2_dayflowerend_b9c0409e:

    # O_ip "Space and time will likely cease to exist. Perhaps a new universe will be born, perhaps not."
    O_ip "El espacio y el tiempo probablemente dejarán de existir. Quizá nazca un nuevo universo, quizá no."

# game/beyond the bet/flowerend.rpy:901
translate Spanish chat2_dayflowerend_134f9499:

    # O_ip "But that does not matter for you."
    O_ip "Pero eso no te importa a ti."

# game/beyond the bet/flowerend.rpy:909
translate Spanish chat2_dayflowerend_c1f5cd69:

    # O_ip "...What?"
    O_ip "...¿Qué?"

# game/beyond the bet/flowerend.rpy:929
translate Spanish chat2_dayflowerend_14ed0a0f:

    # O_ip "...Your riddle is for fools and I care not for it."
    O_ip "...Tu adivinanza es para necios y no me interesa."

# game/beyond the bet/flowerend.rpy:930
translate Spanish chat2_dayflowerend_fd3f18ae:

    # O_ip "You will hand over your soul now, and we will be done with this charade."
    O_ip "Entregarás tu alma ahora, y pondremos fin a esta farsa."

# game/beyond the bet/flowerend.rpy:946
translate Spanish chat2_dayflowerend_fe547dbd:

    # GRC "Sunshine!"
    GRC "¡Solecito!"

# game/beyond the bet/flowerend.rpy:950
translate Spanish chat2_dayflowerend_f40a1522:

    # "{i}The door slams open, and there, standing in the doorway, is none other than Casper.{/i}"
    "{i}La puerta se abre de golpe y ahí, de pie en el umbral, no está nadie más que Casper.{/i}"

# game/beyond the bet/flowerend.rpy:952
translate Spanish chat2_dayflowerend_d94df07d:

    # "{i}He looks to you with relief, before his eyes find the mysterious reaper standing in front of you.{/i}"
    "{i}Te mira con alivio, antes de que sus ojos encuentren a la misteriosa parca que está de pie frente a ti.{/i}"

# game/beyond the bet/flowerend.rpy:954
translate Spanish chat2_dayflowerend_b0e22e97:

    # GRC "...5012?"
    GRC "...¿5012?"

# game/beyond the bet/flowerend.rpy:970
translate Spanish chat2_dayflowerend_d27af9ca:

    # O_ip "Hello, 'Casper'."
    O_ip "Hola, 'Casper'."

# game/beyond the bet/flowerend.rpy:983
translate Spanish chat2_dayflowerend_1893b34b:

    # O_ip "Indeed. I would say we know each other quite well. Wouldn't you agree?"
    O_ip "En efecto. Diría que nos conocemos bastante bien. ¿No te parece?"

# game/beyond the bet/flowerend.rpy:994
translate Spanish chat2_dayflowerend_563ec63e:

    # GRC "Unfortunately."
    GRC "Por desgracia."

# game/beyond the bet/flowerend.rpy:1007
translate Spanish chat2_dayflowerend_a5181c5b:

    # O_ip "I hadn't realized our relationship was so terrible that it would be unfortunate to know me."
    O_ip "No me había dado cuenta de que nuestra relación fuera tan terrible como para que conocerme resulte una desgracia."

# game/beyond the bet/flowerend.rpy:1009
translate Spanish chat2_dayflowerend_424cec92:

    # GRC "Yeah, well, things change."
    GRC "Sí, bueno, las cosas cambian."

# game/beyond the bet/flowerend.rpy:1011
translate Spanish chat2_dayflowerend_8f202ce7:

    # O_ip "Mortals change. It is their way. You do not change, Casper."
    O_ip "Los mortales cambian. Es su naturaleza. Tú no cambias, Casper."

# game/beyond the bet/flowerend.rpy:1017
translate Spanish chat2_dayflowerend_cdeb3f75:

    # O_ip "I trained 'Casper' for some time."
    O_ip "Entrené a 'Casper' durante un tiempo."

# game/beyond the bet/flowerend.rpy:1019
translate Spanish chat2_dayflowerend_8899df28:

    # O_ip "If you cannot even do your role correctly after being trained by me, then you have no hope."
    O_ip "Si ni siquiera puedes desempeñar bien tu papel después de que yo te entrenara, entonces no tienes remedio."

# game/beyond the bet/flowerend.rpy:1021
translate Spanish chat2_dayflowerend_26393213:

    # GRC "...There's more to life than just death. That's something I've learned recently."
    GRC "...La vida es más que solo muerte. Es algo que he aprendido hace poco."

# game/beyond the bet/flowerend.rpy:1023
translate Spanish chat2_dayflowerend_4a8650b2:

    # O_ip "Not for people like us."
    O_ip "No para gente como nosotros."

# game/beyond the bet/flowerend.rpy:1025
translate Spanish chat2_dayflowerend_f0ab05b9:

    # GRC "You're wrong."
    GRC "Te equivocas."

# game/beyond the bet/flowerend.rpy:1026
translate Spanish chat2_dayflowerend_a4027922:

    # GRC "It's almost hilarious that you can't tell how wrong you are."
    GRC "Es casi hilarante que no te des cuenta de lo equivocado que estás."

# game/beyond the bet/flowerend.rpy:1027
translate Spanish chat2_dayflowerend_210fdf18:

    # GRC "You've become so wrapped up in what you are, you cannot see who you are."
    GRC "Te has envuelto tanto en lo que eres que no puedes ver quién eres."

# game/beyond the bet/flowerend.rpy:1028
translate Spanish chat2_dayflowerend_8e174a8d:

    # O_ip "The individual is hardly important."
    O_ip "El individuo apenas importa."

# game/beyond the bet/flowerend.rpy:1029
translate Spanish chat2_dayflowerend_2ef874cc:

    # GRC "Wrong again. You really are good at being wrong, you know that?"
    GRC "Otra vez te equivocas. Se te da muy bien equivocarte, ¿lo sabías?"

# game/beyond the bet/flowerend.rpy:1032
translate Spanish chat2_dayflowerend_36bb549f:

    # O_ip "I tire of this nonsense, 8394."
    O_ip "Me canso de estas tonterías, 8394."

# game/beyond the bet/flowerend.rpy:1033
translate Spanish chat2_dayflowerend_00d7a0d3:

    # O_ip "I had hoped to be able to make you understand, but it seems I was mistaken."
    O_ip "Esperaba poder hacerte entender, pero parece que me equivoqué."

# game/beyond the bet/flowerend.rpy:1034
translate Spanish chat2_dayflowerend_ddee5591:

    # O_ip "Perhaps after you see your 'Sunshine' finally go to their resting place, you will see the error of your ways."
    O_ip "Quizá cuando veas a tu 'Solecito' ir por fin a su lugar de descanso, veas el error de tu camino."

# game/beyond the bet/flowerend.rpy:1035
translate Spanish chat2_dayflowerend_81e45f5f:

    # O_ip "Death is such a beautiful thing."
    O_ip "La muerte es algo tan hermoso."

# game/beyond the bet/flowerend.rpy:1037
translate Spanish chat2_dayflowerend_22175056:

    # GRC "...Through my dead body. No one else can touch my mortal but me."
    GRC "...Por encima de mi cadáver. Nadie más puede tocar a mi mortal salvo yo."

# game/beyond the bet/flowerend.rpy:1038
translate Spanish chat2_dayflowerend_9dd5c0ad:

    # O_ip "They are not your mortal. Not any longer. You have abandoned your station."
    O_ip "Ya no es tu mortal. Has abandonado tu estación."

# game/beyond the bet/flowerend.rpy:1040
translate Spanish chat2_dayflowerend_f3858115:

    # GRC "Sunshine, get behind me."
    GRC "Solecito, ponte detrás de mí."

# game/beyond the bet/flowerend.rpy:1050
translate Spanish chat2_dayflowerend_8892a693:

    # GRC "5012, you'll stay away from them, or you'll answer to me."
    GRC "5012, te mantendrás alejado de Solecito o responderás ante mí."

# game/beyond the bet/flowerend.rpy:1059
translate Spanish chat2_dayflowerend_a9a51ed4:

    # O_ip "Threatening another reaper breaks protocol 3027, but I see that no longer matters to you."
    O_ip "Amenazar a otra parca infringe el protocolo 3027, pero veo que ya no te importa."

# game/beyond the bet/flowerend.rpy:1060
translate Spanish chat2_dayflowerend_919e5567:

    # O_ip "Unfortunately for you, 'Casper', you have become soft. Your threats carry no weight."
    O_ip "Por desgracia para ti, 'Casper', te has vuelto blando. Tus amenazas no tienen peso."

# game/beyond the bet/flowerend.rpy:1068
translate Spanish chat2_dayflowerend_2586baee:

    # GRC "Better soft than an unfeeling bastard like you."
    GRC "Mejor blando que un bastardo insensible como tú."

# game/beyond the bet/flowerend.rpy:1076
translate Spanish chat2_dayflowerend_6c1a9667:

    # O_ip "Better alive than gone, as you'll soon be."
    O_ip "Mejor vivo que desaparecido, como pronto estarás."

# game/beyond the bet/flowerend.rpy:1082
translate Spanish chat2_dayflowerend_9dd600f7:

    # O_ip "What you want does not matter, mortal."
    O_ip "Lo que quieras no importa, mortal."

# game/beyond the bet/flowerend.rpy:1083
translate Spanish chat2_dayflowerend_25c0a720:

    # O_ip "You could do nothing to stop me, even if you tried."
    O_ip "No podrías hacer nada para detenerme, aunque lo intentaras."

# game/beyond the bet/flowerend.rpy:1089
translate Spanish chat2_dayflowerend_014382d2:

    # O_ip "I believe this has gone on far too long."
    O_ip "Creo que esto ya se ha alargado demasiado."

# game/beyond the bet/flowerend.rpy:1090
translate Spanish chat2_dayflowerend_3c6a4609:

    # O_ip "This mortal will hand over their soul immediately, and you will be dealt with after."
    O_ip "Este mortal entregará su alma de inmediato, y después nos ocuparemos de ti."

# game/beyond the bet/flowerend.rpy:1095
translate Spanish chat2_dayflowerend_aea96ea5:

    # GRC "Your... your..."
    GRC "Tu... tu..."

# game/beyond the bet/flowerend.rpy:1100
translate Spanish chat2_dayflowerend_3d134883:

    # GRC "We... we are not married!"
    GRC "¡No... no estamos casados!"

# game/beyond the bet/flowerend.rpy:1106
translate Spanish chat2_dayflowerend_97556da2:

    # O_ip "Your opinion matters little."
    O_ip "Tu opinión importa poco."

# game/beyond the bet/flowerend.rpy:1111
translate Spanish chat2_dayflowerend_a63eb012:

    # "{i}You close your eyes and concentrate.{/i}"
    "{i}Cierras los ojos y te concentras.{/i}"

# game/beyond the bet/flowerend.rpy:1113
translate Spanish chat2_dayflowerend_72a803fc:

    # "{i}You can feel your connection to Casper.{/i}"
    "{i}Puedes sentir tu conexión con Casper.{/i}"

# game/beyond the bet/flowerend.rpy:1114
translate Spanish chat2_dayflowerend_5ed30ff8:

    # "{i}Like a long string that winds and turns, but connects you directly to him.{/i}"
    "{i}Como un largo hilo que serpentea y gira, pero que te conecta directamente con él.{/i}"

# game/beyond the bet/flowerend.rpy:1115
translate Spanish chat2_dayflowerend_6cd84f28:

    # "{i}With a furrowed brow, you picture that bridge again, and you start walking.{/i}"
    "{i}Con el ceño fruncido, vuelves a imaginar ese puente y empiezas a caminar.{/i}"

# game/beyond the bet/flowerend.rpy:1116
translate Spanish chat2_dayflowerend_e0994d6c:

    # "{i}You feel a great weight on your shoulders. The weight of your entire soul.{/i}"
    "{i}Sientes un gran peso sobre los hombros. El peso de toda tu alma.{/i}"

# game/beyond the bet/flowerend.rpy:1117
translate Spanish chat2_dayflowerend_db69aec5:

    # "{i}Despite your eyes being closed, it's almost... light.{/i}"
    "{i}Aunque tienes los ojos cerrados, es casi... ligero.{/i}"

# game/beyond the bet/flowerend.rpy:1118
translate Spanish chat2_dayflowerend_3cdfd4da:

    # "{i}Casper was right. Your soul is incredibly bright.{/i}"
    "{i}Casper tenía razón. Tu alma es increíblemente brillante.{/i}"

# game/beyond the bet/flowerend.rpy:1119
translate Spanish chat2_dayflowerend_5b441695:

    # "{i}You cross, one foot in front of the other. On the other side is pitch darkness.{/i}"
    "{i}Cruzas, un pie delante del otro. Al otro lado hay una oscuridad total.{/i}"

# game/beyond the bet/flowerend.rpy:1120
translate Spanish chat2_dayflowerend_31174ae5:

    # "{i}A pitch darkness your light begins to envelop.{/i}" id chat2_dayflowerend_31174ae5
    "{i}Una oscuridad total que tu luz comienza a envolver.{/i}" id chat2_dayflowerend_31174ae5

# game/beyond the bet/flowerend.rpy:1121
translate Spanish chat2_dayflowerend_9bbc0efa:

    # "{i}You stare into the darkness for just a moment, and then...{/i}"
    "{i}Contemplas la oscuridad solo un instante, y entonces...{/i}"

# game/beyond the bet/flowerend.rpy:1122
translate Spanish chat2_dayflowerend_49be38e6:

    # "{i}You run.{/i}"
    "{i}Corres.{/i}"

# game/beyond the bet/flowerend.rpy:1123
translate Spanish chat2_dayflowerend_c5571c08:

    # "{i}With all of your energy, all of your love, all of your strength, you fling the light of your soul into Casper's darkness, and then you open your eyes.{/i}"
    "{i}Con toda tu energía, todo tu amor, toda tu fuerza, lanzas la luz de tu alma hacia la oscuridad de Casper, y entonces abres los ojos.{/i}"

# game/beyond the bet/flowerend.rpy:1131
translate Spanish chat2_dayflowerend_3931d73e:

    # "{i}And there you see Casper, half kneeling on the ground, enveloped by a bright, white light.{/i}"
    "{i}Y ahí ves a Casper, medio arrodillado en el suelo, envuelto en una luz blanca y brillante.{/i}"

# game/beyond the bet/flowerend.rpy:1132
translate Spanish chat2_dayflowerend_4c1b3b99:

    # "{i}You put your hand to your chest - you feel a little strange.{/i}"
    "{i}Te llevas la mano al pecho: algo se siente un poco extraño.{/i}"

# game/beyond the bet/flowerend.rpy:1137
translate Spanish chat2_dayflowerend_9216c1a7:

    # "{i}Lighter, maybe?{/i}"
    "{i}¿Más ligero, quizá?{/i}"

# game/beyond the bet/flowerend.rpy:1138
translate Spanish chat2_dayflowerend_4adb7a7d:

    # "{i}Like a part of you is missing...{/i}"
    "{i}Como si te faltara una parte...{/i}"

# game/beyond the bet/flowerend.rpy:1139
translate Spanish chat2_dayflowerend_d684cdc1:

    # "{i}But, then again, when you look at Casper, that feeling seems to subside.{/i}"
    "{i}Pero, por otro lado, cuando miras a Casper, esa sensación parece desvanecerse.{/i}"

# game/beyond the bet/flowerend.rpy:1160
translate Spanish chat2_dayflowerend_64b1cf1d:

    # O_ip "What... what have you done...?"
    O_ip "¿Qué... qué has hecho...?"

# game/beyond the bet/flowerend.rpy:1166
translate Spanish chat2_dayflowerend_e56c7961:

    # O_ip "..."
    O_ip "..."

# game/beyond the bet/flowerend.rpy:1168
translate Spanish chat2_dayflowerend_226ecb06:

    # GRC "S... Sunshine...?"
    GRC "S... ¿Solecito...?"

# game/beyond the bet/flowerend.rpy:1185
translate Spanish chat2_dayflowerend_b4dc5e5a:

    # GRC "The... soulsickess makes us human?"
    GRC "¿La... enfermedad del alma nos vuelve humanos?"

# game/beyond the bet/flowerend.rpy:1202
translate Spanish chat2_dayflowerend_e1b95f83:

    # GRC "You..."
    GRC "Tú..."

# game/beyond the bet/flowerend.rpy:1203
translate Spanish chat2_dayflowerend_a234f92f:

    # GRC "You would give that up... for me?"
    GRC "¿Renunciarías a eso... por mí?"

# game/beyond the bet/flowerend.rpy:1209
translate Spanish chat2_dayflowerend_8d2c875e:

    # O_ip "You... you can't just..."
    O_ip "Tú... tú no puedes simplemente..."

# game/beyond the bet/flowerend.rpy:1213
translate Spanish chat2_dayflowerend_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/beyond the bet/flowerend.rpy:1215
translate Spanish chat2_dayflowerend_b575f4ee:

    # GRC "...Tired, I think."
    GRC "...Cansado, creo."

# game/beyond the bet/flowerend.rpy:1231
translate Spanish chat2_dayflowerend_b4371c0d:

    # GRC "Wait, what?"
    GRC "Espera, ¿qué?"

# game/beyond the bet/flowerend.rpy:1233
translate Spanish chat2_dayflowerend_165b74e3:

    # GRC "I'm not going anywhere without you."
    GRC "No voy a ninguna parte sin ti."

# game/beyond the bet/flowerend.rpy:1234
translate Spanish chat2_dayflowerend_6d9eab47:

    # O_ip "...You two have messed up everything."
    O_ip "...Ustedes dos lo han arruinado todo."

# game/beyond the bet/flowerend.rpy:1240
translate Spanish chat2_dayflowerend_1bf7e9ce:

    # O_ip "YOUR soul?"
    O_ip "¿TU alma?"

# game/beyond the bet/flowerend.rpy:1241
translate Spanish chat2_dayflowerend_1b4f5b3d:

    # O_ip "The part of your soul we want is gone!"
    O_ip "¡La parte de tu alma que queremos ya no está!"

# game/beyond the bet/flowerend.rpy:1242
translate Spanish chat2_dayflowerend_84d8e1d5:

    # O_ip "Now you're just a regular human, like everyone else."
    O_ip "Ahora eres una persona normal y corriente, como todos los demás."

# game/beyond the bet/flowerend.rpy:1243
translate Spanish chat2_dayflowerend_ad39ce8b:

    # O_ip "Look."
    O_ip "Mira."

# game/beyond the bet/flowerend.rpy:1244
translate Spanish chat2_dayflowerend_e549d412:

    # "He holds up a piece of paper. At the bottom, you see your name... and then it vanishes!"
    "Sostiene en alto un papel. Al final, ves tu nombre... ¡y entonces desaparece!"

# game/beyond the bet/flowerend.rpy:1245
translate Spanish chat2_dayflowerend_320eb069:

    # O_ip "...You are no longer marked for death."
    O_ip "...Ya no estás marcad[letra] para la muerte."

# game/beyond the bet/flowerend.rpy:1247
translate Spanish chat2_dayflowerend_1656e893:

    # O_ip "I am no judge. As much as I would like to see the two of you punished for this, that is not for me to decide."
    O_ip "No soy juez. Por mucho que me gustaría ver a los dos castigados por esto, no me corresponde decidirlo."

# game/beyond the bet/flowerend.rpy:1248
translate Spanish chat2_dayflowerend_145b2322:

    # O_ip "Unlike someone else here, I take my role seriously."
    O_ip "A diferencia de cierta persona presente, yo me tomo mi papel en serio."

# game/beyond the bet/flowerend.rpy:1249
translate Spanish chat2_dayflowerend_d18d87ff:

    # O_ip "Fine."
    O_ip "Bueno."

# game/beyond the bet/flowerend.rpy:1250
translate Spanish chat2_dayflowerend_b6652479:

    # O_ip "I shall send you back to the mortal world."
    O_ip "Los enviaré de vuelta al mundo mortal."

# game/beyond the bet/flowerend.rpy:1251
translate Spanish chat2_dayflowerend_b5a4a505:

    # O_ip "And one day, when your time comes, I will be there to take your souls."
    O_ip "Y algún día, cuando llegue su hora, estaré allí para llevarme sus almas."

# game/beyond the bet/flowerend.rpy:1257
translate Spanish chat2_dayflowerend_0175cae0:

    # O_ip "Goodbye, mortals."
    O_ip "Adiós, mortales."

# game/beyond the bet/flowerend.rpy:1260
translate Spanish chat2_dayflowerend_8505e97f:

    # "{i}Darkness surrounds you, and then you feel as if you're falling - your stomach almost jumps up into your mouth.{/i}"
    "{i}La oscuridad te rodea y entonces sientes que caes: el estómago casi se te sube a la garganta.{/i}"

# game/beyond the bet/flowerend.rpy:1261
translate Spanish chat2_dayflowerend_867ccf0c:

    # "{i}You flip and tumble through the air for what feels like an eternity before—{/i}"
    "{i}Giras y das vueltas por el aire durante lo que parece una eternidad antes de que—{/i}"

# game/beyond the bet/flowerend.rpy:1262
translate Spanish chat2_dayflowerend_e6a42223:

    # "{i}It all fades away, and you're back in your apartment.{/i}"
    "{i}Todo se desvanece y estás de vuelta en tu apartamento.{/i}"

# game/beyond the bet/flowerend.rpy:1266
translate Spanish chat2_dayflowerend_af28bfee:

    # "{i}[pet_name] is sitting on your bed.{/i}"
    "{i}[pet_name] está sentad[letra_pet] en tu cama.{/i}"

# game/beyond the bet/flowerend.rpy:1267
translate Spanish chat2_dayflowerend_3526d091:

    # "{i}Your laptop is on your desk.{/i}"
    "{i}Tu laptop está sobre tu escritorio.{/i}"

# game/beyond the bet/flowerend.rpy:1268
translate Spanish chat2_dayflowerend_9c0f6492:

    # "{i}Your bag is sitting on the floor.{/i}"
    "{i}Tu bolso está en el suelo.{/i}"

# game/beyond the bet/flowerend.rpy:1269
translate Spanish chat2_dayflowerend_741b4c29:

    # "{i}Azrael's head sticks out from the top of it, somehow.{/i}"
    "{i}La cabeza de Azrael asoma por la parte de arriba, de alguna manera.{/i}"

# game/beyond the bet/flowerend.rpy:1270
translate Spanish chat2_dayflowerend_4a5a947c:

    # "{i}And standing across from you is the kindest, stupidest, most lovely man in the entire world.{/i}"
    "{i}Y frente a ti está el hombre más amable, más tonto y más encantador de todo el mundo.{/i}"

# game/beyond the bet/flowerend.rpy:1272
translate Spanish chat2_dayflowerend_e1b95f83_1:

    # GRC "You..."
    GRC "Tú..."

# game/beyond the bet/flowerend.rpy:1282
translate Spanish chat2_dayflowerend_8fff8664:

    # "{i}He rushes forward and hugs you, holding your body close to his.{/i}"
    "{i}Se lanza hacia ti y te abraza, estrechando tu cuerpo contra el suyo.{/i}"

# game/beyond the bet/flowerend.rpy:1283
translate Spanish chat2_dayflowerend_49ca0d19:

    # "{i}You hold onto him tight and finally notice your hands shaking, ever so slightly.{/i}"
    "{i}Te aferras a él con fuerza y por fin notas que te tiemblan las manos, apenas un poco.{/i}"

# game/beyond the bet/flowerend.rpy:1284
translate Spanish chat2_dayflowerend_de0be9fe:

    # "{i}You actually pulled that off.{/i}"
    "{i}De verdad lo lograste.{/i}"

# game/beyond the bet/flowerend.rpy:1285
translate Spanish chat2_dayflowerend_051b9910:

    # "{i}It really worked.{/i}"
    "{i}Funcionó de verdad.{/i}"

# game/beyond the bet/flowerend.rpy:1286
translate Spanish chat2_dayflowerend_24c98380:

    # "{i}And now you're holding your most important person so tight he might pop.{/i}"
    "{i}Y ahora estás abrazando a tu persona más importante tan fuerte que podría reventar.{/i}"

# game/beyond the bet/flowerend.rpy:1287
translate Spanish chat2_dayflowerend_3a4142d5:

    # GRC "Sunshine, you..."
    GRC "Solecito, tú..."

# game/beyond the bet/flowerend.rpy:1289
translate Spanish chat2_dayflowerend_70c324ab:

    # GRC "You gave up too much for me..."
    GRC "Renunciaste a demasiado por mí..."

# game/beyond the bet/flowerend.rpy:1295
translate Spanish chat2_dayflowerend_f69bf1b2:

    # GRC "...Thank you."
    GRC "...Gracias."

# game/beyond the bet/flowerend.rpy:1296
translate Spanish chat2_dayflowerend_0eed454d:

    # GRC "I don't know how I could ever thank you enough."
    GRC "No sé cómo podré agradecértelo lo suficiente."

# game/beyond the bet/flowerend.rpy:1300
translate Spanish chat2_dayflowerend_4464c887:

    # "{i}He pulls back from you, then looks you in the eyes.{/i}"
    "{i}Se separa de ti y te mira a los ojos.{/i}"

# game/beyond the bet/flowerend.rpy:1302
translate Spanish chat2_dayflowerend_ccabf7ab:

    # GRC "I don't know. Do you still like me without the sexy Grim Reaper thing going on?"
    GRC "No sé. ¿Todavía te gusto sin lo de la sexy Parca?"

# game/beyond the bet/flowerend.rpy:1310
translate Spanish chat2_dayflowerend_004e665a:

    # "{i}He cracks a smile at that.{/i}"
    "{i}Esboza una sonrisa ante eso.{/i}"

# game/beyond the bet/flowerend.rpy:1311
translate Spanish chat2_dayflowerend_9a861aeb:

    # GRC "God, what a foolish mortal I've become intertwined with."
    GRC "Dios, con qué mortal tan tont[letra] me he entrelazado."

# game/beyond the bet/flowerend.rpy:1318
translate Spanish chat2_dayflowerend_f4ebb735:

    # GRC "Damn. I hadn't considered that."
    GRC "Maldición. No lo había considerado."

# game/beyond the bet/flowerend.rpy:1319
translate Spanish chat2_dayflowerend_87aae560:

    # GRC "I'll need to come up with some new insults..."
    GRC "Tendré que inventar nuevos insultos..."

# game/beyond the bet/flowerend.rpy:1321
translate Spanish chat2_dayflowerend_c50dd1e2:

    # GRC "But... what now?"
    GRC "Pero... ¿y ahora qué?"

# game/beyond the bet/flowerend.rpy:1329
translate Spanish chat2_dayflowerend_17c4d01b:

    # GRC "...The rest of our lives sounds good. "
    GRC "...El resto de nuestras vidas suena bien. "

# game/beyond the bet/flowerend.rpy:1332
translate Spanish chat2_dayflowerend_a348d464:

    # "{i}He kisses you, gently.{/i}"
    "{i}Te besa con suavidad.{/i}"

# game/beyond the bet/flowerend.rpy:1333
translate Spanish chat2_dayflowerend_196d8122:

    # "{i}Your souls no longer vibrate when you touch, but there's something else there now.{/i}"
    "{i}Sus almas ya no vibran cuando se tocan, pero ahora hay algo más.{/i}"

# game/beyond the bet/flowerend.rpy:1334
translate Spanish chat2_dayflowerend_b1a29e82:

    # "{i}Something you find hard to describe.{/i}"
    "{i}Algo que te cuesta describir.{/i}"

# game/beyond the bet/flowerend.rpy:1335
translate Spanish chat2_dayflowerend_bf0fb896:

    # "{i}It feels a little like fireworks, you think.{/i}"
    "{i}Se siente un poco como fuegos artificiales, piensas.{/i}"

# game/beyond the bet/flowerend.rpy:1336
translate Spanish chat2_dayflowerend_c45fe593:

    # "{i}A special kind of firework, just for you and Casper.{/i}"
    "{i}Un tipo especial de fuegos artificiales, solo para ti y Casper.{/i}"

# game/beyond the bet/flowerend.rpy:1364
translate Spanish bloom_end_after_ae8d9e37:

    # "{i}Everywhere you look, you see bright flowers in bloom.{/i}"
    "{i}Dondequiera que miras, ves flores vistosas en plena floración.{/i}"

# game/beyond the bet/flowerend.rpy:1369
translate Spanish bloom_end_after_a89b8ce3:

    # "{i}A brilliant blue sky greets you from just outside the window, beyond the green outstretched arms of the many potted plants that are displayed there.{/i}"
    "{i}Un cielo azul brillante te saluda justo al otro lado de la ventana, más allá de los brazos verdes y extendidos de las muchas plantas en maceta que se exhiben allí.{/i}"

# game/beyond the bet/flowerend.rpy:1370
translate Spanish bloom_end_after_d3bc25c7:

    # "{i}The scent of freshly cut flowers and dirt is strong, but not overwhelming.{/i}"
    "{i}El aroma de flores recién cortadas y de tierra es intenso, pero no abrumador.{/i}"

# game/beyond the bet/flowerend.rpy:1371
translate Spanish bloom_end_after_8b23f90f:

    # "{i}Your shoes tap against the smooth hardwood floors as you make your way behind the counter.{/i}"
    "{i}Tus zapatos resuenan contra el liso suelo de madera mientras te diriges detrás del mostrador.{/i}"

# game/beyond the bet/flowerend.rpy:1372
translate Spanish bloom_end_after_74e4085b:

    # "{i}Here it is. Your little slice of heaven, on the bottom floor of your apartment building.{/i}"
    "{i}Aquí está. Tu pedacito de cielo, en la planta baja de tu edificio de apartamentos.{/i}"

# game/beyond the bet/flowerend.rpy:1373
translate Spanish bloom_end_after_b4d53486:

    # "{i}And there he is.{/i}"
    "{i}Y ahí está él.{/i}"

# game/beyond the bet/flowerend.rpy:1375
translate Spanish bloom_end_after_8b2b09ca:

    # "{i}Your other little slice of heaven, wearing his silly little apron.{/i}"
    "{i}Tu otro pedacito de cielo, con su tonto delantalcito.{/i}"

# game/beyond the bet/flowerend.rpy:1376
translate Spanish bloom_end_after_3eb3d3ac:

    # "{i}You love that silly little apron.{/i}"
    "{i}Adoras ese tonto delantalcito.{/i}"

# game/beyond the bet/flowerend.rpy:1381
translate Spanish bloom_end_after_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/flowerend.rpy:1382
translate Spanish bloom_end_after_5104bedc:

    # GRC "No, I suppose they will not."
    GRC "No, supongo que no lo harán."

# game/beyond the bet/flowerend.rpy:1383
translate Spanish bloom_end_after_183e567b:

    # GRC "I also suppose someone will have to do something about that."
    GRC "También supongo que alguien tendrá que hacer algo al respecto."

# game/beyond the bet/flowerend.rpy:1390
translate Spanish bloom_end_after_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/flowerend.rpy:1391
translate Spanish bloom_end_after_bad26a23:

    # GRC "It would be a lot easier if I could float up to it..."
    GRC "Sería mucho más fácil si pudiera flotar hasta allí arriba..."

# game/beyond the bet/flowerend.rpy:1396
translate Spanish bloom_end_after_cd324459:

    # GRC "Well, I think the mortal way of doing things is inferior."
    GRC "Bueno, creo que la manera mortal de hacer las cosas es inferior."

# game/beyond the bet/flowerend.rpy:1401
translate Spanish bloom_end_after_52f3b5b1:

    # GRC "When I woke up this morning, I was thinking I'd like to break my neck today, so that sounds wonderful."
    GRC "Cuando desperté esta mañana, pensaba que hoy me gustaría romperme el cuello, así que suena maravilloso."

# game/beyond the bet/flowerend.rpy:1408
translate Spanish bloom_end_after_9091719e:

    # GRC "That's your fault. You're a bad influence on me."
    GRC "Es culpa tuya. Eres una mala influencia para mí."

# game/beyond the bet/flowerend.rpy:1413
translate Spanish bloom_end_after_008afe10_2:

    # GRC "..."
    GRC "..."

# game/beyond the bet/flowerend.rpy:1415
translate Spanish bloom_end_after_c2d69061:

    # GRC "Very much."
    GRC "Muchísimo."

# game/beyond the bet/flowerend.rpy:1416
translate Spanish bloom_end_after_aa45b979:

    # "{i}You quit your job not long after coming back to your apartment with Casper.{/i}"
    "{i}Renunciaste a tu trabajo poco después de volver a tu apartamento con Casper.{/i}"

# game/beyond the bet/flowerend.rpy:1417
translate Spanish bloom_end_after_c3fdb91a:

    # "{i}He had nothing - no birth certificate, no identification, nothing.{/i}"
    "{i}Él no tenía nada: ni acta de nacimiento, ni identificación, nada.{/i}"

# game/beyond the bet/flowerend.rpy:1418
translate Spanish bloom_end_after_889815b2:

    # "{i}Starting over for him would be tough.{/i}"
    "{i}Empezar de cero sería duro para él.{/i}"

# game/beyond the bet/flowerend.rpy:1419
translate Spanish bloom_end_after_ef768f51:

    # "{i}Tough, but not impossible.{/i}"
    "{i}Duro, pero no imposible.{/i}"

# game/beyond the bet/flowerend.rpy:1420
translate Spanish bloom_end_after_f500d351:

    # "{i}You ended up here - with your savings spent on a small store below your apartment.{/i}"
    "{i}Acabaste aquí, con tus ahorros gastados en una pequeña tienda bajo tu apartamento.{/i}"

# game/beyond the bet/flowerend.rpy:1421
translate Spanish bloom_end_after_0828f45a:

    # "{i}It's something both you and Casper loved. Something that connected you.{/i}"
    "{i}Es algo que tanto tú como Casper amaban. Algo que los conectaba.{/i}"

# game/beyond the bet/flowerend.rpy:1422
translate Spanish bloom_end_after_112c6c06:

    # "{i}Flowers.{/i}"
    "{i}Flores.{/i}"

# game/beyond the bet/flowerend.rpy:1423
translate Spanish bloom_end_after_f42ba331:

    # "{i}Almost every day you get to see Casper experiencing something new.{/i}"
    "{i}Casi todos los días ves a Casper experimentar algo nuevo.{/i}"

# game/beyond the bet/flowerend.rpy:1424
translate Spanish bloom_end_after_696cd362:

    # "{i}Sometimes it's nice things, like the first snowfall, or the spicy noodles from the noodle place around the corner.{/i}"
    "{i}A veces son cosas bonitas, como la primera nevada o los fideos picantes del local de fideos de la esquina.{/i}"

# game/beyond the bet/flowerend.rpy:1425
translate Spanish bloom_end_after_08b84738:

    # "{i}Other times, it's the more annoying parts of mortality - like paying bills, or not being able to float up to the top shelf.{/i}"
    "{i}Otras veces son las partes más molestas de ser mortal, como pagar facturas o no poder flotar hasta el estante de arriba.{/i}"

# game/beyond the bet/flowerend.rpy:1426
translate Spanish bloom_end_after_0cf55c2d:

    # "{i}But no matter what he's experiencing, you're there too.{/i}"
    "{i}Pero sea lo que sea que experimente, tú también estás ahí.{/i}"

# game/beyond the bet/flowerend.rpy:1427
translate Spanish bloom_end_after_b3bc2b4b:

    # "{i}You get to see it all.{/i}"
    "{i}Llegas a verlo todo.{/i}"

# game/beyond the bet/flowerend.rpy:1428
translate Spanish bloom_end_after_34758eb6:

    # "{i}And you couldn't be happier.{/i}"
    "{i}Y no podrías ser más feliz.{/i}"

# game/beyond the bet/flowerend.rpy:1429
translate Spanish bloom_end_after_89aa7068:

    # "{i}You sit on the edge of the counter and smile towards Casper.{/i}"
    "{i}Te sientas en el borde del mostrador y le sonríes a Casper.{/i}"

# game/beyond the bet/flowerend.rpy:1430
translate Spanish bloom_end_after_421450c3:

    # "{i}The sunlight hits him just right, making his red eyes sparkle like gems.{/i}"
    "{i}La luz del sol lo ilumina en el ángulo perfecto, haciendo que sus ojos rojos brillen como gemas.{/i}"

# game/beyond the bet/flowerend.rpy:1431
translate Spanish bloom_end_after_77256ca8:

    # "{i}Life really is good.{/i}"
    "{i}La vida de verdad es buena.{/i}"

# game/beyond the bet/flowerend.rpy:1435
translate Spanish bloom_end_after_8a20aaca:

    # GRC "Yeah?"
    GRC "¿Sí?"

# game/beyond the bet/flowerend.rpy:1442
translate Spanish bloom_end_after_4b38c118:

    # GRC "...That's your fault, you know."
    GRC "...Es culpa tuya, ¿sabes?"

# game/beyond the bet/flowerend.rpy:1444
translate Spanish bloom_end_after_2bc6dad4:

    # GRC "You went and ruined a perfectly good Grim Reaper soul with your terrible, terrible light."
    GRC "Fuiste y arruinaste un alma de Parca perfectamente buena con tu terrible, terrible luz."

# game/beyond the bet/flowerend.rpy:1449
translate Spanish bloom_end_after_8ae5be6c:

    # GRC "No one calls you that."
    GRC "Nadie te llama así."

# game/beyond the bet/flowerend.rpy:1454
translate Spanish bloom_end_after_d46ef20a:

    # GRC "You're insufferable."
    GRC "Eres insufrible."

# game/beyond the bet/flowerend.rpy:1455
translate Spanish bloom_end_after_2680bbe3:

    # GRC "...But I'm glad to be stuck suffering you."
    GRC "...Pero me alegra estar atrapado soportándote."

# game/beyond the bet/flowerend.rpy:1459
translate Spanish bloom_end_after_5f541c59:

    # GRC "...I love you, Sunshine."
    GRC "...Te amo, Solecito."

# game/beyond the bet/flowerend.rpy:1460
translate Spanish bloom_end_after_0c449cf6:

    # GRC "More than anything."
    GRC "Más que a nada."

# game/beyond the bet/flowerend.rpy:1464
translate Spanish bloom_end_after_c218bfb1:

    # GRC "...Now get off the counter, and come help me."
    GRC "...Ahora bájate del mostrador y ven a ayudarme."

# game/beyond the bet/flowerend.rpy:1468
translate Spanish bloom_end_after_dedd9ed3:

    # "{i}You hop off the counter and step towards Casper, every step one more towards your shared future.{/i}"
    "{i}Bajas de un salto del mostrador y caminas hacia Casper, cada paso uno más hacia su futuro compartido.{/i}"

# game/beyond the bet/flowerend.rpy:1469
translate Spanish bloom_end_after_db35398e:

    # "{i}Life really is just perfect.{/i}"
    "{i}La vida de verdad es simplemente perfecta.{/i}"

translate Spanish strings:

    # game/beyond the bet/flowerend.rpy:60
    old "1. <Oh my gosh, hello kitty!>"
    new "1. <¡Dios mío, hola, gatito!>"

    # game/beyond the bet/flowerend.rpy:62
    old "1. <Who's a cute kitty?>"
    new "1. <¿Quién es un gatito lindo?>"

    # game/beyond the bet/flowerend.rpy:65
    old "1. <You are!>"
    new "1. <¡Tú!>"

    # game/beyond the bet/flowerend.rpy:68
    old "1. <Probably.>"
    new "1. <Probablemente.>"

    # game/beyond the bet/flowerend.rpy:71
    old "1. <I mean, I don't know you, but all kitties are good kitties.>"
    new "1. <O sea, no te conozco, pero todos los gatitos son buenos gatitos.>"

    # game/beyond the bet/flowerend.rpy:74
    old "2. <Eugh, I'm allergic...>"
    new "2. <Puaj, soy alérgic[letra]...>"

    # game/beyond the bet/flowerend.rpy:76
    old "1. <Ah... ah... ah->"
    new "1. <Ah... ah... ah->"

    # game/beyond the bet/flowerend.rpy:82
    old "1. <You're not setting off my allergies?>"
    new "1. <¿No me estás provocando alergia?>"

    # game/beyond the bet/flowerend.rpy:85
    old "3. <Aren't you the cutest little thing in the world?>"
    new "3. <¿No eres la cosita más linda del mundo?>"

    # game/beyond the bet/flowerend.rpy:87
    old "1. <Except for [pet_name], of course.>"
    new "1. <Excepto [pet_name], claro.>"

    # game/beyond the bet/flowerend.rpy:90
    old "1. <But you're a close second.>"
    new "1. <Pero te quedas muy cerca, en segundo lugar.>"

    # game/beyond the bet/flowerend.rpy:101
    old "1. <His cat really did burst into flames...>"
    new "1. <Su gato de verdad estalló en llamas...>"

    # game/beyond the bet/flowerend.rpy:103
    old "2. <I... what just happened?>"
    new "2. <Yo... ¿qué acaba de pasar?>"

    # game/beyond the bet/flowerend.rpy:106
    old "1. <This place is wild...>"
    new "1. <Este lugar es una locura...>"

    # game/beyond the bet/flowerend.rpy:122
    old "1. <I'd thought as much.>"
    new "1. <Ya me lo imaginaba.>"

    # game/beyond the bet/flowerend.rpy:124
    old "2. <What a surprise...>"
    new "2. <Qué sorpresa...>"

    # game/beyond the bet/flowerend.rpy:144
    old "1. <{i}Give him a kiss on the head.{/i}>"
    new "1. <{i}Darle un beso en la cabeza.{/i}>"

    # game/beyond the bet/flowerend.rpy:146
    old "1. <Mwah.>"
    new "1. <Muac.>"

    # game/beyond the bet/flowerend.rpy:148
    old "2. <{i}Pat him.{/i}>"
    new "2. <{i}Acariciarlo.{/i}>"

    # game/beyond the bet/flowerend.rpy:152
    old "3. <{i}Tuck him into bed.{/i}>"
    new "3. <{i}Arroparlo en la cama.{/i}>"

    # game/beyond the bet/flowerend.rpy:154
    old "1. <There we go. Nice and cozy.>"
    new "1. <Listo. Cómodo y calentito.>"

    # game/beyond the bet/flowerend.rpy:158
    old "1. <You're in charge while Casper's out, Azrael!>"
    new "1. <¡Tú estás a cargo mientras Casper no está, Azrael!>"

    # game/beyond the bet/flowerend.rpy:160
    old "2. <Hold down the fort, alright?>"
    new "2. <Cuida el fuerte, ¿okey?>"

    # game/beyond the bet/flowerend.rpy:206
    old "1. <{i}Look around for the mysterious reaper.{/i}>"
    new "1. <{i}Buscar la misteriosa parca.{/i}>"

    # game/beyond the bet/flowerend.rpy:211
    old "2. <{i}Start on the shelves on the left.{/i}>"
    new "2. <{i}Empezar por las estanterías de la izquierda.{/i}>"

    # game/beyond the bet/flowerend.rpy:214
    old "3. <{i}Start on the shelves on the right.{/i}>"
    new "3. <{i}Empezar por las estanterías de la derecha.{/i}>"

    # game/beyond the bet/flowerend.rpy:217
    old "4. <{i}Double check the door.{/i}>"
    new "4. <{i}Comprobar la puerta otra vez.{/i}>"

    # game/beyond the bet/flowerend.rpy:233
    old "1. <You've never been into reading, so it's incredibly painful.>"
    new "1. <Nunca te ha gustado leer, así que resulta muy doloroso.>"

    # game/beyond the bet/flowerend.rpy:235
    old "2. <Despite liking reading, it's slow going.>"
    new "2. <Aunque te gusta leer, el avance es lento.>"

    # game/beyond the bet/flowerend.rpy:240
    old "1. <There must be something here...>"
    new "1. <Tiene que haber algo aquí...>"

    # game/beyond the bet/flowerend.rpy:242
    old "1. <A way to help Casper...>"
    new "1. <Una forma de ayudar a Casper...>"

    # game/beyond the bet/flowerend.rpy:245
    old "1. <And myself, of course.>"
    new "1. <Y a mí mism[letra], claro.>"

    # game/beyond the bet/flowerend.rpy:247
    old "2. <There's way too many books...>"
    new "2. <Hay demasiados libros...>"

    # game/beyond the bet/flowerend.rpy:249
    old "1. <By the time I'm done, I'll probably be dead from old age...>"
    new "1. <Para cuando termine, probablemente habré muerto de vejez...>"

    # game/beyond the bet/flowerend.rpy:282
    old "2. <This is it!>"
    new "2. <¡Esto es!>"

    # game/beyond the bet/flowerend.rpy:285
    old "1. <I gotta talk to Casper...>"
    new "1. <Tengo que hablar con Casper...>"

    # game/beyond the bet/flowerend.rpy:292
    old "2. <Hello, is anyone out there?>"
    new "2. <¿Hola? ¿Hay alguien ahí fuera?>"

    # game/beyond the bet/flowerend.rpy:294
    old "3. <What...?! It opened before...?>"
    new "3. <¿Qué...? ¿Antes se abría...?>"

    # game/beyond the bet/flowerend.rpy:298
    old "1. <{i}Pull out your laptop.{/i}>"
    new "1. <{i}Sacar tu laptop.{/i}>"

    # game/beyond the bet/flowerend.rpy:309
    old "my greatest treasure"
    new "mi mayor tesoro"

    # game/beyond the bet/flowerend.rpy:339
    old "2. <Caspy-Waspy!>"
    new "2. <¡Caspy-Waspy!>"

    # game/beyond the bet/flowerend.rpy:341
    old "3. <Grimmy!>"
    new "3. <¡Parquita!>"

    # game/beyond the bet/flowerend.rpy:344
    old "1. <It's me.>"
    new "1. <Soy yo.>"

    # game/beyond the bet/flowerend.rpy:347
    old "1. <[playerfirstname] [playerlastname], in case you somehow forgot.>"
    new "1. <[playerfirstname] [playerlastname], por si acaso se te olvidó.>"

    # game/beyond the bet/flowerend.rpy:350
    old "1. <TBH I think that would be impossible...>"
    new "1. <La verdad, creo que eso sería imposible...>"

    # game/beyond the bet/flowerend.rpy:352
    old "2. <Maybe you're getting memory issues with your old age? idk.>"
    new "2. <¿Quizá tienes problemas de memoria por la vejez? ni idea.>"

    # game/beyond the bet/flowerend.rpy:359
    old "1. <Woah, no need to yell.>"
    new "1. <Uy, no hace falta gritar.>"

    # game/beyond the bet/flowerend.rpy:362
    old "1. <Go back to all lowercase, please.>"
    new "1. <Vuelve a escribir todo en minúsculas, por favor.>"

    # game/beyond the bet/flowerend.rpy:364
    old "2. <This feels like when your parents or grandparents use your full name...>"
    new "2. <Esto se siente como cuando tus padres o abuelos usan tu nombre completo...>"

    # game/beyond the bet/flowerend.rpy:367
    old "1. <Except Sunshine isn't my name.>"
    new "1. <Solo que Solecito no es mi nombre.>"

    # game/beyond the bet/flowerend.rpy:370
    old "1. <At least, I don't think it is.>"
    new "1. <Al menos, no creo que lo sea.>"

    # game/beyond the bet/flowerend.rpy:372
    old "2. <I'd get that all the time...>"
    new "2. <Eso me pasaba siempre...>"

    # game/beyond the bet/flowerend.rpy:377
    old "1. <Well, where are you?>"
    new "1. <Bueno, ¿y tú dónde estás?>"

    # game/beyond the bet/flowerend.rpy:381
    old "1. <Am I?>"
    new "1. <¿Ah, sí?>"

    # game/beyond the bet/flowerend.rpy:385
    old "1. <I'm in that library.>"
    new "1. <Estoy en esa biblioteca.>"

    # game/beyond the bet/flowerend.rpy:387
    old "2. <Is that illegal?>"
    new "2. <¿Eso es ilegal?>"

    # game/beyond the bet/flowerend.rpy:391
    old "1. <You do it all the time.>"
    new "1. <Tú lo haces todo el tiempo.>"

    # game/beyond the bet/flowerend.rpy:395
    old "1. <Uh huh. Sure.>"
    new "1. <Ajá. Claro.>"

    # game/beyond the bet/flowerend.rpy:398
    old "1. <But anyways!>"
    new "1. <¡Pero bueno!>"

    # game/beyond the bet/flowerend.rpy:401
    old "1. <I'm in a very musty library.>"
    new "1. <Estoy en una biblioteca que huele muchísimo a humedad.>"

    # game/beyond the bet/flowerend.rpy:404
    old "2. <I'm not telling.>"
    new "2. <No te lo diré.>"

    # game/beyond the bet/flowerend.rpy:408
    old "1. <I want to be fun and mysterious.>"
    new "1. <Quiero ser divertid[letra] y misterios[letra].>"

    # game/beyond the bet/flowerend.rpy:413
    old "1. <Still kicking, dw.>"
    new "1. <Aquí sigo, tranqui.>"

    # game/beyond the bet/flowerend.rpy:416
    old "1. <I'm in a big ol' library.>"
    new "1. <Estoy en una biblioteca enorme.>"

    # game/beyond the bet/flowerend.rpy:419
    old "2. <I like to make you beg just a little.>"
    new "2. <Me gusta hacerte suplicar un poquito.>"

    # game/beyond the bet/flowerend.rpy:423
    old "1. <It's always the time for begging, Casper.>"
    new "1. <Siempre es momento de suplicar, Casper.>"

    # game/beyond the bet/flowerend.rpy:426
    old "1. <Please, take this seriously.>"
    new "1. <Por favor, tómate esto en serio.>"

    # game/beyond the bet/flowerend.rpy:432
    old "1. <Awww, good boy.>"
    new "1. <Awww, buen chico.>"

    # game/beyond the bet/flowerend.rpy:435
    old "1. <I'm in that library you told me about.>"
    new "1. <Estoy en esa biblioteca de la que me hablaste.>"

    # game/beyond the bet/flowerend.rpy:439
    old "3. <Uhh... big library?>"
    new "3. <Eh... ¿biblioteca grande?>"

    # game/beyond the bet/flowerend.rpy:444
    old "1. <Sorry, did it glitch out?>"
    new "1. <Perdona, ¿se cortó la conexión?>"

    # game/beyond the bet/flowerend.rpy:447
    old "1. <I'm in the library.>"
    new "1. <Estoy en la biblioteca.>"

    # game/beyond the bet/flowerend.rpy:450
    old "1. <L.I.B.R.A.R.Y.>"
    new "1. <B.I.B.L.I.O.T.E.C.A.>"

    # game/beyond the bet/flowerend.rpy:453
    old "2. <Yeah, I know...>"
    new "2. <Sí, ya lo sé...>"

    # game/beyond the bet/flowerend.rpy:456
    old "1. <Sorry, Grimmy. I know I shouldn't have left.>"
    new "1. <Perdón, Parquita. Sé que no debí irme.>"

    # game/beyond the bet/flowerend.rpy:461
    old "1. <I wanted to help you.>"
    new "1. <Quería ayudarte.>"

    # game/beyond the bet/flowerend.rpy:463
    old "2. <I knew there had to be something here.>"
    new "2. <Sabía que tenía que haber algo aquí.>"

    # game/beyond the bet/flowerend.rpy:466
    old "1. <Something to help the both of us.>"
    new "1. <Algo que nos ayudara a los dos.>"

    # game/beyond the bet/flowerend.rpy:472
    old "1. <Wait!>"
    new "1. <¡Espera!>"

    # game/beyond the bet/flowerend.rpy:475
    old "1. <I found something.>"
    new "1. <Encontré algo.>"

    # game/beyond the bet/flowerend.rpy:479
    old "1. <I might do something stupid.>"
    new "1. <Puede que haga una tontería.>"

    # game/beyond the bet/flowerend.rpy:485
    old "1. <You're worth risking it for.>"
    new "1. <Mereces que lo arriesgue.>"

    # game/beyond the bet/flowerend.rpy:487
    old "2. <I would happily give it up for you.>"
    new "2. <Con gusto la daría por ti.>"

    # game/beyond the bet/flowerend.rpy:495
    old "1. <Sorry Casper, no can do.>"
    new "1. <Lo siento, Casper, no puedo.>"

    # game/beyond the bet/flowerend.rpy:497
    old "2. <Hmm... no.>"
    new "2. <Mmm... no.>"

    # game/beyond the bet/flowerend.rpy:500
    old "1. <Are you back at your house now?>"
    new "1. <¿Ya estás de vuelta en tu casa?>"

    # game/beyond the bet/flowerend.rpy:505
    old "1. <That's my bad.>"
    new "1. <Es culpa mía.>"

    # game/beyond the bet/flowerend.rpy:508
    old "1. <I know I shouldn't be wandering about here, but...>"
    new "1. <Sé que no debería andar vagando por aquí, pero...>"

    # game/beyond the bet/flowerend.rpy:511
    old "1. <Look, accept this, okay?>"
    new "1. <Mira, acéptalo, ¿okey?>"

    # game/beyond the bet/flowerend.rpy:552
    old "1. <Grim, do you want to be mortal?>"
    new "1. <Grim, ¿quieres ser mortal?>"

    # game/beyond the bet/flowerend.rpy:558
    old "1. <That doesn't matter.>"
    new "1. <Eso no importa.>"

    # game/beyond the bet/flowerend.rpy:561
    old "1. <Just say you have a way to become mortal\n in front of you right now.>"
    new "1. <Digamos que tienes ahora mismo una forma de volverte mortal.>"

    # game/beyond the bet/flowerend.rpy:564
    old "1. <Would you take it?>"
    new "1. <¿La tomarías?>"

    # game/beyond the bet/flowerend.rpy:579
    old "1. <What if I said it is?>"
    new "1. <¿Y si te dijera que lo es?>"

    # game/beyond the bet/flowerend.rpy:581
    old "2. <Maybe it's not so impossible.>"
    new "2. <Quizá no sea tan imposible.>"

    # game/beyond the bet/flowerend.rpy:586
    old "1. <That's my secret.>"
    new "1. <Es mi secreto.>"

    # game/beyond the bet/flowerend.rpy:588
    old "2. <I'll tell you when I can.>"
    new "2. <Te lo diré cuando pueda.>"

    # game/beyond the bet/flowerend.rpy:593
    old "1. <Demand all you like.>"
    new "1. <Exige todo lo que quieras.>"

    # game/beyond the bet/flowerend.rpy:595
    old "1. <I'll tell you soon, okay? >"
    new "1. <Te lo diré pronto, ¿okey? >"

    # game/beyond the bet/flowerend.rpy:597
    old "2. <I AM taking it seriously, I promise.>"
    new "2. <Me lo estoy tomando en serio, lo prometo.>"

    # game/beyond the bet/flowerend.rpy:600
    old "1. <I just want to see if I can find out anything else.>"
    new "1. <Solo quiero ver si puedo averiguar algo más.>"

    # game/beyond the bet/flowerend.rpy:604
    old "1. <This is how serious I am about you.>"
    new "1. <Así de en serio voy contigo.>"

    # game/beyond the bet/flowerend.rpy:607
    old "1. <About us, and our future.>"
    new "1. <Con nosotros y con nuestro futuro.>"

    # game/beyond the bet/flowerend.rpy:610
    old "1. <Casper, I'd rather both of us burn than watch \nyou go up in flames alone.>"
    new "1. <Casper, prefiero que ardamos los dos antes que verte arder solo.>"

    # game/beyond the bet/flowerend.rpy:612
    old "1. <If you're taking risks, then so am I.>"
    new "1. <Si tú corres riesgos, yo también.>"

    # game/beyond the bet/flowerend.rpy:614
    old "2. <I'm not letting you get hurt while I sit in \nyour apartment hiding.>"
    new "2. <No dejaré que te hagan daño mientras me quedo escondid[letra] en tu apartamento.>"

    # game/beyond the bet/flowerend.rpy:616
    old "1. <You can depend on me, too.>"
    new "1. <Tú también puedes contar conmigo.>"

    # game/beyond the bet/flowerend.rpy:619
    old "2. <Oooh, now he's getting bossy!>"
    new "2. <¡Uuuh, ahora se pone mandón!>"

    # game/beyond the bet/flowerend.rpy:621
    old "1. <What else are you going to demand of me, huh?>"
    new "1. <¿Qué más vas a exigirme, eh?>"

    # game/beyond the bet/flowerend.rpy:623
    old "2. <My bossy little reaper.>"
    new "2. <Mi parquita mandona.>"

    # game/beyond the bet/flowerend.rpy:630
    old "1. <Thank you.>"
    new "1. <Gracias.>"

    # game/beyond the bet/flowerend.rpy:632
    old "2. <Yeah, I'm very aware.>"
    new "2. <Sí, soy muy consciente.>"

    # game/beyond the bet/flowerend.rpy:634
    old "3. <You've said that once or twice, I think.>"
    new "3. <Creo que lo has dicho una o dos veces.>"

    # game/beyond the bet/flowerend.rpy:637
    old "1. <I'm an idiot who looooves you.>"
    new "1. <Soy [arti_2] idiota que te quiiiiere.>"

    # game/beyond the bet/flowerend.rpy:642
    old "1. <Hey, then you'd win our bet, at least!>"
    new "1. <¡Oye, al menos así ganarías nuestra apuesta!>"

    # game/beyond the bet/flowerend.rpy:644
    old "2. <Isn't that kinda what you wanted anyway?>"
    new "2. <¿No es más o menos lo que querías de todos modos?>"

    # game/beyond the bet/flowerend.rpy:651
    old "1. <Fiiiine.>"
    new "1. <Bueeeno.>"

    # game/beyond the bet/flowerend.rpy:654
    old "1. <See ya soon, Grimmy.>"
    new "1. <Nos vemos pronto, Parquita.>"

    # game/beyond the bet/flowerend.rpy:656
    old "2. <I'll be a good [girl] and wait right here.>"
    new "2. <Me portaré bien y esperaré justo aquí.>"

    # game/beyond the bet/flowerend.rpy:665
    old "1. <My special little idiot.>"
    new "1. <Mi idiota especial.>"

    # game/beyond the bet/flowerend.rpy:708
    old "2. <Why the hell are you just standing there?!>"
    new "2. <¡¿Por qué diablos te quedas ahí parado?!>"

    # game/beyond the bet/flowerend.rpy:710
    old "3. <Who the...?!>"
    new "3. <¡¿Quién diablos...?!>"

    # game/beyond the bet/flowerend.rpy:716
    old "1. <You...>"
    new "1. <Tú...>"

    # game/beyond the bet/flowerend.rpy:719
    old "1. <You're that asshole, aren't you!>"
    new "1. <¡Eres ese imbécil, ¿verdad?!>"

    # game/beyond the bet/flowerend.rpy:723
    old "1. <Well, if you gave me your name, I could use that.>"
    new "1. <Bueno, si me dijeras tu nombre, podría usarlo.>"

    # game/beyond the bet/flowerend.rpy:726
    old "1. <You didn't, so you're 'that asshole'.>"
    new "1. <No lo hiciste, así que eres 'ese imbécil'.>"

    # game/beyond the bet/flowerend.rpy:732
    old "2. <Who are you?>"
    new "2. <¿Quién eres?>"

    # game/beyond the bet/flowerend.rpy:738
    old "1. <I'm pretty boring, actually.>"
    new "1. <En realidad soy bastante aburrid[letra].>"

    # game/beyond the bet/flowerend.rpy:740
    old "1. <Yup. Just another boring ol' Grim Reaper.>"
    new "1. <Sip. Otra aburrida Parca más.>"

    # game/beyond the bet/flowerend.rpy:744
    old "1. <Can't you see my cloak? It screams Grim Reaper.>"
    new "1. <¿No ves mi capa? Grita Parca por todas partes.>"

    # game/beyond the bet/flowerend.rpy:749
    old "2. <Yeah, well, I'm more interesting than you.>"
    new "2. <Sí, bueno, yo soy más interesante que tú.>"

    # game/beyond the bet/flowerend.rpy:751
    old "1. <Easily.>"
    new "1. <Con facilidad.>"

    # game/beyond the bet/flowerend.rpy:754
    old "1. <A hundred times as interesting.>"
    new "1. <Cien veces más interesante.>"

    # game/beyond the bet/flowerend.rpy:757
    old "1. <Maybe even a thousand.>"
    new "1. <Quizá hasta mil.>"

    # game/beyond the bet/flowerend.rpy:770
    old "1. <It's not like I'm TRYING to stay alive here!>"
    new "1. <¡No es que esté INTENTANDO seguir con vida aquí!>"

    # game/beyond the bet/flowerend.rpy:773
    old "1. <And Casper - bless his heart - did actually try his best to kill me.>"
    new "1. <Y Casper, bendito sea, de verdad hizo todo lo posible por matarme.>"

    # game/beyond the bet/flowerend.rpy:775
    old "2. <He even tried to drop a piano on me one time!>"
    new "2. <¡Incluso intentó dejarme caer un piano encima una vez!>"

    # game/beyond the bet/flowerend.rpy:778
    old "1. <Maybe if I'm not dying like I'm supposed to, then I'm not meant to be dead.>"
    new "1. <Quizá si no me estoy muriendo como se supone, es que no estoy destinad[letra] a estar muert[letra].>"

    # game/beyond the bet/flowerend.rpy:785
    old "1. <Pretty sure it's mine.>"
    new "1. <Estoy bastante segur[letra] de que es mía.>"

    # game/beyond the bet/flowerend.rpy:788
    old "2. <I'm not handing it over.>"
    new "2. <No voy a entregarla.>"

    # game/beyond the bet/flowerend.rpy:790
    old "3. <Who says it's yours?>"
    new "3. <¿Quién dice que es tuya?>"

    # game/beyond the bet/flowerend.rpy:800
    old "1. <How do I know I can trust you?>"
    new "1. <¿Cómo sé que puedo confiar en ti?>"

    # game/beyond the bet/flowerend.rpy:805
    old "2. <Would you really?>"
    new "2. <¿De verdad lo harías?>"

    # game/beyond the bet/flowerend.rpy:808
    old "1. <You are perfectly capable of bending the truth, though.>"
    new "1. <Aunque eres perfectamente capaz de torcer la verdad.>"

    # game/beyond the bet/flowerend.rpy:813
    old "1. <{i}Look around the room.{/i}>"
    new "1. <{i}Mirar alrededor de la habitación.{/i}>"

    # game/beyond the bet/flowerend.rpy:821
    old "1. <Okay, let's hypothetically say we have a deal...>"
    new "1. <Okey, digamos hipotéticamente que tenemos un trato...>"

    # game/beyond the bet/flowerend.rpy:825
    old "1. <Woah there, cowboy.>"
    new "1. <Uy, tranquilo, vaquero.>"

    # game/beyond the bet/flowerend.rpy:827
    old "2. <Don't get ahead of yourself.>"
    new "2. <No te adelantes.>"

    # game/beyond the bet/flowerend.rpy:830
    old "1. <I said hypothetically.>"
    new "1. <Dije hipotéticamente.>"

    # game/beyond the bet/flowerend.rpy:833
    old "1. <I wanna know some more about you before I agree.>"
    new "1. <Quiero saber algo más de ti antes de aceptar.>"

    # game/beyond the bet/flowerend.rpy:838
    old "1. <Your name.>"
    new "1. <Tu nombre.>"

    # game/beyond the bet/flowerend.rpy:842
    old "1. <Favorite color?>"
    new "1. <¿Color favorito?>"

    # game/beyond the bet/flowerend.rpy:846
    old "1. <...Lucky number?>"
    new "1. <...¿Número de la suerte?>"

    # game/beyond the bet/flowerend.rpy:850
    old "1. <I feel like I should've guessed that one.>"
    new "1. <Siento que debí adivinar ese.>"

    # game/beyond the bet/flowerend.rpy:853
    old "1. <Favorite vowel?>"
    new "1. <¿Vocal favorita?>"

    # game/beyond the bet/flowerend.rpy:857
    old "1. <Me. It's u.>"
    new "1. <Yo. Es la u.>"

    # game/beyond the bet/flowerend.rpy:859
    old "1. <Because 'u' are my favorite.>"
    new "1. <Porque la 'u' está en 'tú', y tú eres mi favorito.>"

    # game/beyond the bet/flowerend.rpy:862
    old "1. <Now it's your turn.>"
    new "1. <Ahora es tu turno.>"

    # game/beyond the bet/flowerend.rpy:864
    old "2. <I don't know. You, maybe?>"
    new "2. <No sé. ¿Tú, quizá?>"

    # game/beyond the bet/flowerend.rpy:866
    old "1. <You seem like a vowel kind of guy.>"
    new "1. <Tienes pinta de ser de los de vocal.>"

    # game/beyond the bet/flowerend.rpy:874
    old "1. <Really think about it.>"
    new "1. <Piénsalo bien.>"

    # game/beyond the bet/flowerend.rpy:877
    old "1. <No rush. This is an important question.>"
    new "1. <Sin prisa. Es una pregunta importante.>"

    # game/beyond the bet/flowerend.rpy:888
    old "2. <IF... you answer my riddle.>"
    new "2. <SI... respondes a mi adivinanza.>"

    # game/beyond the bet/flowerend.rpy:891
    old "1. <Yes. My riddle.>"
    new "1. <Sí. Mi adivinanza.>"

    # game/beyond the bet/flowerend.rpy:894
    old "1. <What's the end of everything?>"
    new "1. <¿Cuál es el final de todo?>"

    # game/beyond the bet/flowerend.rpy:903
    old "1. <Bzzzz. Wrong.>"
    new "1. <Bzzzz. Incorrecto.>"

    # game/beyond the bet/flowerend.rpy:906
    old "1. <The answer is 'G'!>"
    new "1. <¡La respuesta es 'O'!>"

    # game/beyond the bet/flowerend.rpy:911
    old "1. <The end of everything.>"
    new "1. <El final de todo.>"

    # game/beyond the bet/flowerend.rpy:914
    old "1. <G is the last letter.>"
    new "1. <La 'o' es la última letra.>"

    # game/beyond the bet/flowerend.rpy:917
    old "1. <Man, I thought you seemed kinda smart. I guess not.>"
    new "1. <Vaya, pensé que parecías bastante listo. Supongo que no.>"

    # game/beyond the bet/flowerend.rpy:919
    old "1. <I guess we can't all be super smart and cool and awesome like me.>"
    new "1. <Supongo que no todos podemos ser superlistos, geniales y fabulosos como yo.>"

    # game/beyond the bet/flowerend.rpy:921
    old "2. <There there. Everyone's wrong sometimes.>"
    new "2. <Ya, ya. Todos nos equivocamos a veces.>"

    # game/beyond the bet/flowerend.rpy:923
    old "1. <I mean, not me.>"
    new "1. <O sea, yo no.>"

    # game/beyond the bet/flowerend.rpy:926
    old "1. <But definitely you.>"
    new "1. <Pero tú sin duda.>"

    # game/beyond the bet/flowerend.rpy:972
    old "1. <You two know each other?>"
    new "1. <¿Ustedes se conocen?>"

    # game/beyond the bet/flowerend.rpy:1014
    old "1. <So you're... friends?>"
    new "1. <¿Entonces son... amigos?>"

    # game/beyond the bet/flowerend.rpy:1045
    old "2. <I'm fine where I am.>"
    new "2. <Estoy bien donde estoy.>"

    # game/beyond the bet/flowerend.rpy:1047
    old "3. <I'm not scared of this loser.>"
    new "3. <No le tengo miedo a este perdedor.>"

    # game/beyond the bet/flowerend.rpy:1079
    old "1. <I won't let you hurt him.>"
    new "1. <No dejaré que le hagas daño.>"

    # game/beyond the bet/flowerend.rpy:1093
    old "1. <Sorry, but I'd much rather just go home with my boyfriend.>"
    new "1. <Lo siento, pero prefiero irme a casa con mi novio.>"

    # game/beyond the bet/flowerend.rpy:1097
    old "1. <Husband?>"
    new "1. <¿Esposo?>"

    # game/beyond the bet/flowerend.rpy:1102
    old "1. <Then boyfriend will have to do.>"
    new "1. <Entonces tendrá que bastar con novio.>"

    # game/beyond the bet/flowerend.rpy:1105
    old "2. <Heh. I don't think so.>"
    new "2. <Je. No lo creo.>"

    # game/beyond the bet/flowerend.rpy:1141
    old "1. <{i}Run towards Casper.{/i}>"
    new "1. <{i}Correr hacia Casper.{/i}>"

    # game/beyond the bet/flowerend.rpy:1162
    old "1. <The law of equal souls... maybe you've heard of it?>"
    new "1. <La ley de las almas iguales... ¿quizá has oído hablar de ella?>"

    # game/beyond the bet/flowerend.rpy:1170
    old "1. <I found out about it here.>"
    new "1. <Me enteré de ella aquí.>"

    # game/beyond the bet/flowerend.rpy:1173
    old "1. <That's what the soulsickness is, Casper.>"
    new "1. <Eso es la enfermedad del alma, Casper.>"

    # game/beyond the bet/flowerend.rpy:1176
    old "1. <That's why you can't stay in the mortal world for too long.>"
    new "1. <Por eso no puedes quedarte demasiado tiempo en el mundo mortal.>"

    # game/beyond the bet/flowerend.rpy:1179
    old "1. <It makes you human.>"
    new "1. <Te vuelve humano.>"

    # game/beyond the bet/flowerend.rpy:1182
    old "1. <Slowly, though.>"
    new "1. <Aunque poco a poco.>"

    # game/beyond the bet/flowerend.rpy:1187
    old "1. <Yes!>"
    new "1. <¡Sí!>"

    # game/beyond the bet/flowerend.rpy:1189
    old "2. <It's not a sickness at all.>"
    new "2. <No es una enfermedad en absoluto.>"

    # game/beyond the bet/flowerend.rpy:1192
    old "1. <The law of equal souls says that...>"
    new "1. <La ley de las almas iguales dice que...>"

    # game/beyond the bet/flowerend.rpy:1195
    old "1. <If a Grim Reaper is gifted a soul of light, they'll become mortal, and get to live as one.>"
    new "1. <Si a una Parca le regalan un alma de luz, se volverá mortal y podrá vivir como tal.>"

    # game/beyond the bet/flowerend.rpy:1199
    old "1. <It's a more concentrated soulsickness.>"
    new "1. <Es una enfermedad del alma más concentrada.>"

    # game/beyond the bet/flowerend.rpy:1205
    old "1. <Casper, there's plenty more I'd give up for you, too.>"
    new "1. <Casper, hay mucho más a lo que renunciaría por ti.>"

    # game/beyond the bet/flowerend.rpy:1207
    old "2. <Yes. No matter what, I'd always choose this.>"
    new "2. <Sí. Pase lo que pase, siempre elegiría esto.>"

    # game/beyond the bet/flowerend.rpy:1211
    old "1. <Do you feel any different?>"
    new "1. <¿Te sientes diferente?>"

    # game/beyond the bet/flowerend.rpy:1217
    old "1. <Hah. Get used to sleeping 8+ hours a night, buddy.>"
    new "1. <Jah. Acostúmbrate a dormir más de 8 horas por noche, amigo.>"

    # game/beyond the bet/flowerend.rpy:1219
    old "2. <Then we better get you tucked up in bed.>"
    new "2. <Entonces será mejor que te arropemos en la cama.>"

    # game/beyond the bet/flowerend.rpy:1222
    old "1. <{i}Turn towards the mysterious reaper.{/i}>"
    new "1. <{i}Volverte hacia la misteriosa parca.{/i}>"

    # game/beyond the bet/flowerend.rpy:1225
    old "1. <He's human now. You have to follow your rules.>"
    new "1. <Ahora es humano. Tienes que seguir tus reglas.>"

    # game/beyond the bet/flowerend.rpy:1228
    old "1. <Send him back.>"
    new "1. <Envíalo de vuelta.>"

    # game/beyond the bet/flowerend.rpy:1236
    old "1. <It's my soul you want. Let me go.>"
    new "1. <Es mi alma lo que quieres. Déjame ir.>"

    # game/beyond the bet/flowerend.rpy:1253
    old "1. <Sounds fair to me.>"
    new "1. <Me parece justo.>"

    # game/beyond the bet/flowerend.rpy:1255
    old "2. <Awww, you like me so much you want to see me again?>"
    new "2. <Awww, ¿tanto te gusto que quieres volver a verme?>"

    # game/beyond the bet/flowerend.rpy:1291
    old "1. <A 'thank you' will suffice.>"
    new "1. <Un 'gracias' bastará.>"

    # game/beyond the bet/flowerend.rpy:1293
    old "2. <It was my pleasure.>"
    new "2. <Fue un placer.>"

    # game/beyond the bet/flowerend.rpy:1298
    old "1. <Do you still like me without the whole soul connection thing?>"
    new "1. <¿Todavía te gusto sin lo de la conexión de almas?>"

    # game/beyond the bet/flowerend.rpy:1304
    old "1. <Yeah, probably.>"
    new "1. <Sí, probablemente.>"

    # game/beyond the bet/flowerend.rpy:1306
    old "2. <Hmmm... let me think.>"
    new "2. <Mmm... déjame pensar.>"

    # game/beyond the bet/flowerend.rpy:1313
    old "1. <Hey, hold on a second.>"
    new "1. <Oye, espera un segundo.>"

    # game/beyond the bet/flowerend.rpy:1316
    old "1. <You're a foolish mortal now, too!>"
    new "1. <¡Ahora tú también eres un mortal tonto!>"

    # game/beyond the bet/flowerend.rpy:1323
    old "1. <Well....>"
    new "1. <Bueno....>"

    # game/beyond the bet/flowerend.rpy:1326
    old "1. <The rest of our lives?>"
    new "1. <¿El resto de nuestras vidas?>"

    # game/beyond the bet/flowerend.rpy:1379
    old "1. <You know, those top shelves in the back room aren't going to restock themselves.>"
    new "1. <Sabes, esos estantes de arriba del almacén no se van a reponer solos.>"

    # game/beyond the bet/flowerend.rpy:1388
    old "1. <You.>"
    new "1. <Tú.>"

    # game/beyond the bet/flowerend.rpy:1393
    old "1. <Gotta do things the mortal way now, Casper.>"
    new "1. <Ahora toca hacer las cosas a la manera mortal, Casper.>"

    # game/beyond the bet/flowerend.rpy:1398
    old "1. <If you want, you can stand on my shoulders.>"
    new "1. <Si quieres, puedes subirte a mis hombros.>"

    # game/beyond the bet/flowerend.rpy:1406
    old "1. <You're getting good at lying now, Casper.>"
    new "1. <Te estás volviendo bueno mintiendo, Casper.>"

    # game/beyond the bet/flowerend.rpy:1410
    old "1. <A bad influence you love.>"
    new "1. <Una mala influencia a la que amas.>"

    # game/beyond the bet/flowerend.rpy:1437
    old "1. <You always said that sunflowers suited me.>"
    new "1. <Siempre dijiste que los girasoles me quedaban bien.>"

    # game/beyond the bet/flowerend.rpy:1440
    old "1. <I think they suit you just fine, too.>"
    new "1. <Creo que a ti también te quedan muy bien.>"

    # game/beyond the bet/flowerend.rpy:1446
    old "1. <Mwhahaha. That's why they call me the 'Corrupter of Souls'!>"
    new "1. <Mwajajaja. ¡Por eso me llaman 'Corrompealmas'!>"

    # game/beyond the bet/flowerend.rpy:1451
    old "1. <They should!>"
    new "1. <¡Deberían!>"

    # game/beyond the bet/flowerend.rpy:1457
    old "1. <A simple 'I love you' would suffice.>"
    new "1. <Un simple 'te amo' bastaría.>"

    # game/beyond the bet/flowerend.rpy:1462
    old "1. <I love you, too, Casper.>"
    new "1. <Yo también te amo, Casper.>"

    # game/beyond the bet/flowerend.rpy:1466
    old "1. <Yes, sir!>"
    new "1. <¡Sí, señor!>"

