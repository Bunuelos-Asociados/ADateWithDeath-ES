# TODO: Translation updated at 2026-10-15 18:36

# game/beyond the bet/9dlc_roomexplore.rpy:223
translate Spanish bed_hub9_36f8ed72:

    # "You sit on the edge of your bed, then look down at your pillows."
    "Te sientas al borde de tu cama y luego miras tus almohadas."

# game/beyond the bet/9dlc_roomexplore.rpy:224
translate Spanish bed_hub9_fc48d988:

    # "They're the same as always, but they seem..."
    "Son las mismas de siempre, pero parecen..."

# game/beyond the bet/9dlc_roomexplore.rpy:225
translate Spanish bed_hub9_f02f7cd8:

    # "Different, too?"
    "¿Diferentes también?"

# game/beyond the bet/9dlc_roomexplore.rpy:226
translate Spanish bed_hub9_1a6828c5:

    # "Just this morning, Casper was laying there, right beside you."
    "Esta misma mañana, Casper estaba tumbado ahí, justo a tu lado."

# game/beyond the bet/9dlc_roomexplore.rpy:227
translate Spanish bed_hub9_7ef41a62:

    # "A Grim Reaper."
    "Una Parca."

# game/beyond the bet/9dlc_roomexplore.rpy:228
translate Spanish bed_hub9_66ac9760:

    # "But more than that, a man you have come to feel for deeply."
    "Pero, más que eso, un hombre por quien has llegado a sentir un cariño muy profundo."

# game/beyond the bet/9dlc_roomexplore.rpy:234
translate Spanish bed_hub9_575b8f69:

    # "You want to sleep beside him every night."
    "Quieres dormir a su lado todas las noches."

# game/beyond the bet/9dlc_roomexplore.rpy:237
translate Spanish bed_hub9_d8fb00a8:

    # "Or maybe a pillow fort each, and then you can wage a war."
    "O tal vez un fuerte de almohadas para cada uno, y así podrían librar una guerra."

# game/beyond the bet/9dlc_roomexplore.rpy:238
translate Spanish bed_hub9_562e7c95:

    # "You will win, of course."
    "Tú ganarás, por supuesto."

# game/beyond the bet/9dlc_roomexplore.rpy:241
translate Spanish bed_hub9_adb5a43d:

    # "Isn't that strange? You went your whole life without him, and now it feels like a part of yourself is missing."
    "¿No es extraño? Viviste toda tu vida sin él, y ahora sientes como si te faltara una parte de ti."

# game/beyond the bet/9dlc_roomexplore.rpy:244
translate Spanish bed_hub9_813e70ea:

    # "It'll just add to his ego, but he really is a good-looking man."
    "Solo le subirá más el ego, pero de verdad es un hombre muy guapo."

# game/beyond the bet/9dlc_roomexplore.rpy:245
translate Spanish bed_hub9_dd5d7cd5:

    # "Curse him."
    "Maldito sea."

# game/beyond the bet/9dlc_roomexplore.rpy:247
translate Spanish bed_hub9_135b97d1:

    # "You stand up, smiling down at your bed once more."
    "Te levantas, sonriendo una vez más a tu cama."

# game/beyond the bet/9dlc_roomexplore.rpy:248
translate Spanish bed_hub9_9e6851f1:

    # "Hopefully you'll spend another night with him soon."
    "Ojalá pronto pases otra noche con él."

# game/beyond the bet/9dlc_roomexplore.rpy:258
translate Spanish door_hub9_65762a7e:

    # "You put your ear to the door, but find it... quiet."
    "Pegas la oreja a la puerta, pero todo está... en silencio."

# game/beyond the bet/9dlc_roomexplore.rpy:259
translate Spanish door_hub9_a5d8cf05:

    # "With your mysterious neighbors moving out a couple of days ago, eavesdropping has become a lot more boring."
    "Desde que tus misteriosos vecinos se mudaron hace un par de días, espiar se ha vuelto mucho más aburrido."

# game/beyond the bet/9dlc_roomexplore.rpy:260
translate Spanish door_hub9_23d197e0:

    # "Maybe it's a sign you should actually go out there and meet some of your neighbors, instead of just eavesdropping all the time."
    "Quizá sea una señal de que deberías salir a conocer a algunos de tus vecinos, en lugar de limitarte a espiar todo el tiempo."

# game/beyond the bet/9dlc_roomexplore.rpy:261
translate Spanish door_hub9_a4929f9c:

    # "You're just thinking of doing that when you hear footsteps approach your door, then stop."
    "Justo estás pensando en hacerlo cuando oyes unos pasos que se acercan a tu puerta y luego se detienen."

# game/beyond the bet/9dlc_roomexplore.rpy:267
translate Spanish door_hub9_66792387:

    # "Before you have the chance to open your door, a letter slips in your mail slot."
    "Antes de que puedas abrir la puerta, una carta se desliza por la ranura del correo."

# game/beyond the bet/9dlc_roomexplore.rpy:268
translate Spanish door_hub9_d0b65dc8:

    # "The footsteps retreat."
    "Los pasos se alejan."

# game/beyond the bet/9dlc_roomexplore.rpy:269
translate Spanish door_hub9_9d354e84:

    # "Curious, you pick up the letter."
    "Con curiosidad, recoges la carta."

# game/beyond the bet/9dlc_roomexplore.rpy:270
translate Spanish door_hub9_45265821:

    # "'Dear Neighbor,'"
    "'Estimad[letra] vecin[letra]:'"

# game/beyond the bet/9dlc_roomexplore.rpy:271
translate Spanish door_hub9_1cfccaac:

    # "'Sorry if this letter comes as a surprise, but I promise I'm not a scammer, or a con artist, or a thief...'" id door_hub9_1cfccaac
    "'Perdona si esta carta te sorprende, pero te prometo que no vengo a estafarte, ni a engañarte, ni a robarte...'" id door_hub9_1cfccaac

# game/beyond the bet/9dlc_roomexplore.rpy:272
translate Spanish door_hub9_16f3ff6c:

    # "'My intentions are pure!'"
    "'¡Mis intenciones son puras!'"

# game/beyond the bet/9dlc_roomexplore.rpy:273
translate Spanish door_hub9_75c1dfa1:

    # "'Anyway.'"
    "'En fin.'"

# game/beyond the bet/9dlc_roomexplore.rpy:274
translate Spanish door_hub9_b8bbd50c:

    # "'This is your neighbor, kinda. Room 4, on the 9th floor.'"
    "'Te escribe alguien que vive cerca de ti, más o menos. Habitación 4, piso 9.'"

# game/beyond the bet/9dlc_roomexplore.rpy:275
translate Spanish door_hub9_31a24609:

    # "'You probably don't know me, but I've passed you in the halls a few times.'"
    "'Probablemente no me conozcas, pero me he cruzado contigo en los pasillos varias veces.'"

# game/beyond the bet/9dlc_roomexplore.rpy:276
translate Spanish door_hub9_3dab5a6f:

    # "'I should probably have clarified, this isn't a confession of my love, either...'"
    "'Debería haber aclarado que esto tampoco es una declaración de amor...'"

# game/beyond the bet/9dlc_roomexplore.rpy:277
translate Spanish door_hub9_67d76273:

    # "'God, should I start this letter again...?'"
    "'Dios, ¿debería empezar esta carta de nuevo...?'"

# game/beyond the bet/9dlc_roomexplore.rpy:278
translate Spanish door_hub9_730c9bc3:

    # "'Ahem.'"
    "'Ejem.'"

# game/beyond the bet/9dlc_roomexplore.rpy:279
translate Spanish door_hub9_8d4e8d16:

    # "'I'm moving to a small town called Willowmist soon, just for a few months. You probably haven't heard of it... it's in the complete middle of nowhere (lol).'"
    "'Pronto me mudaré a un pueblito llamado Willowmist, solo por unos meses. Seguramente nunca has oído hablar de él... está en medio de la nada, literalmente (jaja).'"

# game/beyond the bet/9dlc_roomexplore.rpy:280
translate Spanish door_hub9_50bd12a3:

    # "'I just wanted to tell you that you've seemed very bright lately.'"
    "'Solo quería decirte que últimamente te ves muy radiante.'"

# game/beyond the bet/9dlc_roomexplore.rpy:281
translate Spanish door_hub9_e355b50c:

    # "'We don't know each other, but I think I felt inspired to do this move because of you.'"
    "'No nos conocemos, pero creo que tú me inspiraste a dar este paso.'"

# game/beyond the bet/9dlc_roomexplore.rpy:282
translate Spanish door_hub9_be8307f4:

    # "'Which is, again, kinda crazy, seeing as we don't know each other. Isn't is strange how someone you only pass sometimes can make such a difference?'"
    "'Lo cual es, una vez más, un poco absurdo, considerando que ni siquiera nos conocemos. ¿No es extraño que alguien con quien apenas te cruzas de vez en cuando pueda marcar tanta diferencia?'"

# game/beyond the bet/9dlc_roomexplore.rpy:283
translate Spanish door_hub9_f6e538d4:

    # "'Whatever it is that's changed for you, I hope it continues. Happiness can be so sparse these days, but you seem to radiate with it.'"
    "'Sea lo que sea lo que ha cambiado para ti, espero que continúe. La felicidad escasea tanto en estos días, pero tú pareces irradiarla.'"

# game/beyond the bet/9dlc_roomexplore.rpy:284
translate Spanish door_hub9_11a71454:

    # "'Wherever life takes you, I hope you can enjoy it, even when something challenges your brightness.'"
    "'Adonde sea que te lleve la vida, espero que puedas disfrutarla, incluso cuando algo ponga a prueba tu luz.'"

# game/beyond the bet/9dlc_roomexplore.rpy:285
translate Spanish door_hub9_04553173:

    # "'This ended up kinda poetic. My bad.'"
    "'Esto quedó medio poético. Mi error.'"

# game/beyond the bet/9dlc_roomexplore.rpy:286
translate Spanish door_hub9_8e633b0e:

    # "'See ya around!'"
    "'¡Nos vemos por ahí!'"

# game/beyond the bet/9dlc_roomexplore.rpy:287
translate Spanish door_hub9_be302ab2:

    # "'The weirdo from the 9th floor.'"
    "'La persona rara del piso 9.'"

# game/beyond the bet/9dlc_roomexplore.rpy:288
translate Spanish door_hub9_6090f164:

    # "You put the letter down, and spend some time thinking over the contents."
    "Dejas la carta y te quedas un rato pensando en lo que dice."

# game/beyond the bet/9dlc_roomexplore.rpy:294
translate Spanish door_hub9_f2887003:

    # "The hallway is silent."
    "El pasillo está en silencio."

# game/beyond the bet/9dlc_roomexplore.rpy:308
translate Spanish pet_hub9_631638bc:

    # "You look down at [pet_name], a mix of pride, happiness and love in your heart."
    "Miras a [pet_name] con una mezcla de orgullo, alegría y amor en el corazón."

# game/beyond the bet/9dlc_roomexplore.rpy:309
translate Spanish pet_hub9_d9d5fccb:

    # "Really, it's quite amazing."
    "De verdad, es asombroso."

# game/beyond the bet/9dlc_roomexplore.rpy:310
translate Spanish pet_hub9_5bac2faf:

    # "In all the years of the universe, you and [pet_name] happened to be born close enough to know each other."
    "En todos los años del universo, tú y [pet_name] coincidieron en nacer lo bastante cerca como para conocerse."

# game/beyond the bet/9dlc_roomexplore.rpy:311
translate Spanish pet_hub9_3e3df970:

    # "It's a special feeling."
    "Es una sensación especial."

# game/beyond the bet/9dlc_roomexplore.rpy:312
translate Spanish pet_hub9_c73f92ce:

    # "You hope this very special feeling will continue for a long time into the future."
    "Esperas que esta sensación tan especial perdure durante muchos años."

# game/beyond the bet/9dlc_roomexplore.rpy:317
translate Spanish pet_hub9_18a8ee0d:

    # "You sit down beside [pet_name] and pull out your diary."
    "Te sientas junto a [pet_name] y sacas tu diario."

# game/beyond the bet/9dlc_roomexplore.rpy:322
translate Spanish pet_hub9_027304d6:

    # "But today, you think it might be nice to do a little writing."
    "Pero hoy piensas que sería agradable escribir un poco."

# game/beyond the bet/9dlc_roomexplore.rpy:325
translate Spanish pet_hub9_7aaed316:

    # "It's full of your thoughts, your secrets, your musings..."
    "Está lleno de tus pensamientos, tus secretos, tus reflexiones..."

# game/beyond the bet/9dlc_roomexplore.rpy:327
translate Spanish pet_hub9_36758de6:

    # "Pen in hand, [pet_name] rests against your legs as you write."
    "Con el bolígrafo en la mano, [pet_name] se acurruca junto a tus piernas mientras escribes."

# game/beyond the bet/9dlc_roomexplore.rpy:328
translate Spanish pet_hub9_709c1029:

    # "You write about Casper. You write about [pet_name]. You write about your little corner of the world."
    "Escribes sobre Casper. Escribes sobre [pet_name]. Escribes sobre tu pequeño rincón del mundo."

# game/beyond the bet/9dlc_roomexplore.rpy:329
translate Spanish pet_hub9_af145abf:

    # "It's freeing."
    "Es liberador."

# game/beyond the bet/9dlc_roomexplore.rpy:354
translate Spanish plant_hub9_c1229c6a:

    # "You give your little sprout a big drink of water."
    "Le das a tu pequeño retoño un buen trago de agua."

# game/beyond the bet/9dlc_roomexplore.rpy:355
translate Spanish plant_hub9_c5de961c:

    # "Though you don't speak sprout, it seems to say thank you."
    "Aunque no hablas el idioma retoño, parece que te está dando las gracias."

# game/beyond the bet/9dlc_roomexplore.rpy:357
translate Spanish plant_hub9_518e64fd:

    # "Your little sprout has grown some leaves!"
    "¡A tu pequeño retoño le han salido hojas!"

# game/beyond the bet/9dlc_roomexplore.rpy:358
translate Spanish plant_hub9_8036dce1:

    # "You can't help but feel proud as you give it a big drink of water."
    "No puedes evitar sentir orgullo mientras le das un gran trago de agua."

# game/beyond the bet/9dlc_roomexplore.rpy:360
translate Spanish plant_hub9_adaac543:

    # "Even more leaves have appeared now!"
    "¡Aún más hojas han aparecido ahora!"

# game/beyond the bet/9dlc_roomexplore.rpy:361
translate Spanish plant_hub9_a4970463:

    # "You water it generously and feel excited that, this time, you didn't kill your plant instantly."
    "La riegas abundantemente y te emociona comprobar que esta vez no has matado tu planta nada más empezar."

# game/beyond the bet/9dlc_roomexplore.rpy:363
translate Spanish plant_hub9_2087a70f:

    # "Your little plant is growing healthily!"
    "¡Tu pequeña planta está creciendo sana y fuerte!"

# game/beyond the bet/9dlc_roomexplore.rpy:364
translate Spanish plant_hub9_80d209cf:

    # "You give it a big drink of water, excited about its growth."
    "Le das un buen trago de agua, con entusiasmo por su crecimiento."

# game/beyond the bet/9dlc_roomexplore.rpy:366
translate Spanish plant_hub9_41affa3b:

    # "Your little plant has sprouted some buds!"
    "¡A tu pequeña planta le han salido algunos botones florales!"

# game/beyond the bet/9dlc_roomexplore.rpy:367
translate Spanish plant_hub9_75fbf720:

    # "You almost tear up when you notice them. They're so cute - you can't wait to see what the flowers will look like."
    "Casi se te saltan las lágrimas al verlos. ¡Son tan adorables! No puedes esperar a ver cómo serán las flores."

# game/beyond the bet/9dlc_roomexplore.rpy:369
translate Spanish plant_hub9_33ab5804:

    # "The buds on your little plant seem to be doing well!"
    "¡Los capullos de tu pequeña planta parecen estar muy bien!"

# game/beyond the bet/9dlc_roomexplore.rpy:370
translate Spanish plant_hub9_8b2d7914:

    # "You can't believe how healthy it is... though after what Casper told you, you're starting to understand why..."
    "No puedes creer lo bien que está creciendo... aunque, después de lo que te contó Casper, empiezas a entender por qué..."

# game/beyond the bet/9dlc_roomexplore.rpy:372
translate Spanish plant_hub9_3a8cf5f3:

    # "Your little sprout has grown up happily and healthily all because of you, and today..."
    "Tu pequeño retoño ha crecido feliz y saludable gracias a ti, y hoy..."

# game/beyond the bet/9dlc_roomexplore.rpy:379
translate Spanish plant_hub9_3542ab9b:

    # "It rewards you with four beautiful flowers!"
    "¡Te recompensa con cuatro hermosas flores!"

# game/beyond the bet/9dlc_roomexplore.rpy:380
translate Spanish plant_hub9_c9e73e13:

    # "You water your plant and feel a sense of accomplishment."
    "Riegas tu planta y sientes una gran satisfacción."

# game/beyond the bet/9dlc_roomexplore.rpy:383
translate Spanish plant_hub9_8a980ec9:

    # "You give your beautiful flower a healthy dose of water."
    "Le das a tu hermosa flor una buena dosis de agua."

# game/beyond the bet/9dlc_roomexplore.rpy:384
translate Spanish plant_hub9_51a7614d:

    # "It seems to lean towards you in thanks, as if bowing, but you're probably just imagining that."
    "Parece inclinarse hacia ti en señal de agradecimiento, como si hiciera una reverencia, pero seguramente solo lo estás imaginando."

# game/beyond the bet/9dlc_roomexplore.rpy:387
translate Spanish plant_hub9_011c9313:

    # "You give your beautiful plant a big drink of water."
    "Le das a tu hermosa planta un buen trago de agua."

# game/beyond the bet/9dlc_roomexplore.rpy:388
translate Spanish plant_hub9_8e5200a5:

    # "You've come to think of this plant as your child."
    "Has llegado a pensar en esta planta como en tu hijo."

# game/beyond the bet/9dlc_roomexplore.rpy:389
translate Spanish plant_hub9_b8d1a59a:

    # "A green, leafy child. You think it might have your eyes."
    "Un hijo verde y frondoso. Crees que podría tener tus ojos."

# game/beyond the bet/9dlc_roomexplore.rpy:402
translate Spanish plant_hub9_860a7116:

    # "You pour another cup full of water into the soil around your plant."
    "Viertes otra taza llena de agua en la tierra alrededor de tu planta."

# game/beyond the bet/9dlc_roomexplore.rpy:403
translate Spanish plant_hub9_5dd3a1a4:

    # "You're sure it'll enjoy that."
    "Seguro que le encantará."

# game/beyond the bet/9dlc_roomexplore.rpy:417
translate Spanish plant_hub9_d69a29e1:

    # "All plants will bow beneath your power."
    "Todas las plantas se doblegarán ante tu poder."

# game/beyond the bet/9dlc_roomexplore.rpy:418
translate Spanish plant_hub9_4b2b66f6:

    # "You, the God of Water, shall grant your boon readily."
    "Tú, la Deidad del Agua, concederás tu don sin dudar."

# game/beyond the bet/9dlc_roomexplore.rpy:419
translate Spanish plant_hub9_c68e6990:

    # "No matter who shall drown in the process."
    "No importa quién termine ahogándose en el proceso."

translate Spanish strings:

    # game/beyond the bet/9dlc_roomexplore.rpy:233
    old "1. You hope you'll get plenty of nights like that."
    new "1. Esperas tener muchas noches así."

    # game/beyond the bet/9dlc_roomexplore.rpy:236
    old "2. Next time, you want to build a pillow fort with him."
    new "2. La próxima vez, quieres construir un fuerte de almohadas con él."

    # game/beyond the bet/9dlc_roomexplore.rpy:240
    old "3. It's hard to imagine him NOT being there, now."
    new "3. Ahora es difícil imaginar que NO esté ahí."

    # game/beyond the bet/9dlc_roomexplore.rpy:243
    old "4. Sleeping next to him was VERY distracting."
    new "4. Dormir a su lado fue una distracción ENORME."

    # game/beyond the bet/9dlc_roomexplore.rpy:265
    old "1. ...?"
    new "1. ...?"

    # game/beyond the bet/9dlc_roomexplore.rpy:306
    old "Contemplate your time with [pet_name]."
    new "Reflexionar sobre tu tiempo con [pet_name]."

    # game/beyond the bet/9dlc_roomexplore.rpy:315
    old "Sit with [pet_name]."
    new "Sentarte con [pet_name]."

    # game/beyond the bet/9dlc_roomexplore.rpy:321
    old "1. You don't usually use a diary."
    new "1. Normalmente no usas un diario."

    # game/beyond the bet/9dlc_roomexplore.rpy:324
    old "2. You LIVE in your diary."
    new "2. VIVES en tu diario."

