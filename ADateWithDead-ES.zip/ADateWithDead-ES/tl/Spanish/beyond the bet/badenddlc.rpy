# TODO: Translation updated at 2026-10-15 18:36

# game/beyond the bet/badenddlc.rpy:14
translate Spanish dlc_badend_start_b987b26b:

    # center_text "A nightmare takes your dreams."
    center_text "Una pesadilla se apodera de tus sueños."

# game/beyond the bet/badenddlc.rpy:16
translate Spanish dlc_badend_start_159fd4a3:

    # center_text "Darkness writhes, twisting and churning in a maelstrom of terror."
    center_text "La oscuridad se retuerce, gira y se agita en una vorágine de terror."

# game/beyond the bet/badenddlc.rpy:17
translate Spanish dlc_badend_start_cb202db0:

    # center_text "It swallows you, dragging you down into its depths."
    center_text "Te engulle y te arrastra hacia sus profundidades."

# game/beyond the bet/badenddlc.rpy:18
translate Spanish dlc_badend_start_e12a3661:

    # center_text "And in these depths... you're alone."
    center_text "Y en estas profundidades... estás sol[letra]."

# game/beyond the bet/badenddlc.rpy:19
translate Spanish dlc_badend_start_a6af8c9f:

    # center_text "There's no Casper, no sunshine, no hope. There's just you, and the dark."
    center_text "No hay Casper, no hay Solecito, no hay esperanza. Solo estás tú y la oscuridad."

# game/beyond the bet/badenddlc.rpy:20
translate Spanish dlc_badend_start_4ac2cdfb:

    # center_text "So, you call out."
    center_text "Así que llamas a voces."

# game/beyond the bet/badenddlc.rpy:21
translate Spanish dlc_badend_start_113dbfe5:

    # center_text "You scream, hoping against hope that someone will hear your cries."
    center_text "Gritas, con la esperanza casi perdida de que alguien oiga tus llamados."

# game/beyond the bet/badenddlc.rpy:22
translate Spanish dlc_badend_start_bf2cd2d4:

    # center_text "But no one replies."
    center_text "Pero nadie responde."

# game/beyond the bet/badenddlc.rpy:23
translate Spanish dlc_badend_start_bc8dfe27:

    # center_text "Just as you feel like your sanity will finally slip, you awaken."
    center_text "Justo cuando sientes que tu cordura está a punto de quebrarse, despiertas."

# game/beyond the bet/badenddlc.rpy:32
translate Spanish dlc_badend_start_abeae1eb:

    # "You wake up to what your body feels like is morning, though you have no actual way to confirm that."
    "Despiertas en lo que tu cuerpo siente como la mañana, aunque no tienes forma real de confirmarlo."

# game/beyond the bet/badenddlc.rpy:33
translate Spanish dlc_badend_start_d0dad112:

    # "The spot next to you is empty."
    "El lugar a tu lado está vacío."

# game/beyond the bet/badenddlc.rpy:34
translate Spanish dlc_badend_start_b7741dd1:

    # "Quickly scanning around the room, you find Casper nowhere in sight."
    "Recorres la habitación con la mirada, pero no hay rastro de Casper por ningún lado."

# game/beyond the bet/badenddlc.rpy:35
translate Spanish dlc_badend_start_43d35ab8:

    # "Panic wells in your chest."
    "El pánico crece en tu pecho."

# game/beyond the bet/badenddlc.rpy:36
translate Spanish dlc_badend_start_507a50c3:

    # "You had thought, for certain, that Casper would have returned by now."
    "Estabas segur[letra] de que Casper ya habría regresado."

# game/beyond the bet/badenddlc.rpy:37
translate Spanish dlc_badend_start_48c84ce5:

    # "And yet, he has not."
    "Y, sin embargo, no lo ha hecho."

# game/beyond the bet/badenddlc.rpy:38
translate Spanish dlc_badend_start_b2a43939:

    # "You look towards your bag, where the letter from the mysterious reaper still lies."
    "Miras hacia tu bolso, donde aún está la carta de la misteriosa parca."

# game/beyond the bet/badenddlc.rpy:39
translate Spanish dlc_badend_start_c391f941:

    # "You could go out and find them."
    "Podrías salir a buscar a esa persona."

# game/beyond the bet/badenddlc.rpy:40
translate Spanish dlc_badend_start_da78fda5:

    # "And yet..."
    "Y, sin embargo..."

# game/beyond the bet/badenddlc.rpy:41
translate Spanish dlc_badend_start_62528854:

    # "There's a nagging feeling in the back of your brain that if you leave this room, it could lead to terrible things."
    "Una sensación inquietante te ronda el fondo de la mente: si sales de esta habitación, podrían pasar cosas terribles."

# game/beyond the bet/badenddlc.rpy:42
translate Spanish dlc_badend_start_f31aa437:

    # "So, instead you sit up slowly and look around the room, taking in the little bits of Casper that fill the space."
    "Así que, en lugar de eso, te incorporas despacio y recorres la habitación con la mirada, fijándote en los pequeños rastros de Casper que llenan el espacio."

# game/beyond the bet/badenddlc.rpy:51
translate Spanish dlc_badend_start_5426ce6e:

    # "Surprisingly, Casper has two shelves packed with books."
    "Sorprendentemente, Casper tiene dos estantes repletos de libros."

# game/beyond the bet/badenddlc.rpy:52
translate Spanish dlc_badend_start_21d0318c:

    # "Your eyes scan the spines, reading the titles."
    "Tus ojos recorren los lomos, leyendo los títulos."

# game/beyond the bet/badenddlc.rpy:53
translate Spanish dlc_badend_start_93d0b01a:

    # "There's some fiction books, which you find amusing. Apparently, the Grim Reaper isn't against reading sappy romance novels."
    "Hay algunos libros de ficción, lo cual te divierte. Al parecer, a la Parca no le molesta leer novelas románticas empalagosas."

# game/beyond the bet/badenddlc.rpy:54
translate Spanish dlc_badend_start_7123e4c4:

    # "But the majority seem to be nonfiction."
    "Pero la mayoría parecen ser de no ficción."

# game/beyond the bet/badenddlc.rpy:55
translate Spanish dlc_badend_start_faaeb865:

    # "And perhaps more surprising is that most of them are... photography collections?"
    "Y lo que quizá sorprende más es que casi todos son... ¿colecciones de fotografía?"

# game/beyond the bet/badenddlc.rpy:56
translate Spanish dlc_badend_start_0ad7e325:

    # "You thumb through a few of them. Pictures of nature, sunsets, architecture, animals. There's all kinds of photographs."
    "Hojeas algunos. Fotos de naturaleza, atardeceres, arquitectura, animales. Hay fotografías de todo tipo."

# game/beyond the bet/badenddlc.rpy:57
translate Spanish dlc_badend_start_fda36c08:

    # "A small smile appears on your lips as you look through the pages."
    "Una pequeña sonrisa aparece en tus labios mientras miras las páginas."

# game/beyond the bet/badenddlc.rpy:58
translate Spanish dlc_badend_start_70b546ab:

    # "He'd argue fiercely against it, but he really does love the world, and all the colors within it."
    "Lo negaría con vehemencia, pero de verdad ama el mundo y todos los colores que hay en él."

# game/beyond the bet/badenddlc.rpy:59
translate Spanish dlc_badend_start_12918a70:

    # "Seeing the Underworld, you can see how he'd come to feel that way."
    "Después de ver el Inframundo, entiendes cómo pudo llegar a sentirse así."

# game/beyond the bet/badenddlc.rpy:66
translate Spanish dlc_badend_start_db889b12:

    # "His monitor is huge, but currently turned off."
    "Su monitor es enorme, pero ahora mismo está apagado."

# game/beyond the bet/badenddlc.rpy:67
translate Spanish dlc_badend_start_14b82e03:

    # "You nosy around the rest of his desk, but it's relatively clean."
    "Curioseas el resto de su escritorio, pero está bastante ordenado."

# game/beyond the bet/badenddlc.rpy:68
translate Spanish dlc_badend_start_7f11f72b:

    # "You do find a scrappy piece of paper, though."
    "Eso sí, encuentras un trozo de papel viejo y maltratado."

# game/beyond the bet/badenddlc.rpy:69
translate Spanish dlc_badend_start_2fd96510:

    # "On it is a list of... something. Whatever was written here was crossed out, one line at a time."
    "Tiene una lista de... algo. Lo que estaba escrito ahí fue tachado, línea por línea."

# game/beyond the bet/badenddlc.rpy:70
translate Spanish dlc_badend_start_0ad00a92:

    # "But at the very bottom, you notice something: [playerfirstname] [playerlastname]."
    "Pero justo al final ves algo: [playerfirstname] [playerlastname]."

# game/beyond the bet/badenddlc.rpy:71
translate Spanish dlc_badend_start_cb888b6e:

    # "Ah, you think. This is the fabled list. He really did circle your name."
    "Ah, piensas. Esta es la famosa lista. De verdad encerró tu nombre en un círculo."

# game/beyond the bet/badenddlc.rpy:72
translate Spanish dlc_badend_start_7a7c12b4:

    # "...And put little love hearts around it."
    "...Y le dibujó corazoncitos alrededor."

# game/beyond the bet/badenddlc.rpy:73
translate Spanish dlc_badend_start_6708c289:

    # "The corners of the paper have little sunflowers drawn in pen, too."
    "En las esquinas del papel también hay pequeños girasoles dibujados con bolígrafo."

# game/beyond the bet/badenddlc.rpy:74
translate Spanish dlc_badend_start_cf5e9acf:

    # "A goofy smile crosses your face as you set it back down on the desk."
    "Una sonrisa boba te cruza el rostro mientras lo dejas de nuevo sobre el escritorio."

# game/beyond the bet/badenddlc.rpy:83
translate Spanish dlc_badend_start_f03d1890:

    # "This shelf is, in fact, dedicated solely to skin care."
    "Este estante, de hecho, está dedicado únicamente al cuidado de la piel."

# game/beyond the bet/badenddlc.rpy:84
translate Spanish dlc_badend_start_f09a8593:

    # "There's a load of stuff."
    "Hay un montón de cosas."

# game/beyond the bet/badenddlc.rpy:85
translate Spanish dlc_badend_start_c81027d9:

    # "There's bottles and jars and tubes of every kind. Some are full, others are empty, and the rest are unopened."
    "Hay botellas, frascos y tubos de todo tipo. Algunos están llenos, otros vacíos y el resto sin abrir."

# game/beyond the bet/badenddlc.rpy:86
translate Spanish dlc_badend_start_35c1d31a:

    # "There's also a variety of masks, scrubs, and moisturizers."
    "También hay una variedad de mascarillas, exfoliantes e hidratantes."

# game/beyond the bet/badenddlc.rpy:87
translate Spanish dlc_badend_start_9ddb47a4:

    # "This is a man who takes his skin care very seriously."
    "Este es un hombre que se toma muy en serio el cuidado de su piel."

# game/beyond the bet/badenddlc.rpy:88
translate Spanish dlc_badend_start_d91b511e:

    # "You push aside a few of the jars and bottles when you notice something sitting behind them - stuck to the wall is a piece of paper."
    "Apartas algunos frascos y botellas cuando notas algo detrás de ellos: pegado a la pared hay un papel."

# game/beyond the bet/badenddlc.rpy:89
translate Spanish dlc_badend_start_951bc8f9:

    # "On it, a small doodle of Azrael giving a thumbs up, with a speechbubble that says 'looking handsome, Casper!'"
    "En él, un pequeño garabato de Azrael con el pulgar en alto y un globo de diálogo que dice '¡qué guapo estás, Casper!'"

# game/beyond the bet/badenddlc.rpy:90
translate Spanish dlc_badend_start_57ec9994:

    # "You giggle to yourself."
    "Te ríes por lo bajo."

# game/beyond the bet/badenddlc.rpy:98
translate Spanish dlc_badend_start_f9fd6af2:

    # "You flop down on Casper's bed, back hitting the soft mattress."
    "Te dejas caer sobre la cama de Casper y tu espalda aterriza en el suave colchón."

# game/beyond the bet/badenddlc.rpy:99
translate Spanish dlc_badend_start_ad2183f0:

    # "You were surprised last night how comfortable it really was."
    "Anoche te sorprendió lo cómoda que era en realidad."

# game/beyond the bet/badenddlc.rpy:100
translate Spanish dlc_badend_start_3b97807c:

    # "It was so soft, and you'd sunk into the mattress - it was like being wrapped in a warm hug."
    "Era tan suave que te hundías en el colchón; era como si te envolviera un cálido abrazo."

# game/beyond the bet/badenddlc.rpy:101
translate Spanish dlc_badend_start_3fc8207b:

    # "But now, without Casper, the bed feels lonely."
    "Pero ahora, sin Casper, la cama se siente solitaria."

# game/beyond the bet/badenddlc.rpy:102
translate Spanish dlc_badend_start_384cb8e9:

    # "Here, surrounded by his things, his smell, and the memories of him..."
    "Aquí, entre sus cosas, su olor y los recuerdos de él..."

# game/beyond the bet/badenddlc.rpy:103
translate Spanish dlc_badend_start_1d4d906a:

    # "You miss him."
    "Lo extrañas."

# game/beyond the bet/badenddlc.rpy:104
translate Spanish dlc_badend_start_ca3c5d2b:

    # "You pull your laptop out of your bag and set it on Casper's desk, then carefully sit down on his chair."
    "Sacas tu laptop del bolso, la dejas sobre el escritorio de Casper y te sientas con cuidado en su silla."

# game/beyond the bet/badenddlc.rpy:105
translate Spanish dlc_badend_start_dd828216:

    # "Comfortable. You smile, imagining Casper sitting here every day, messaging you."
    "Qué comodidad. Sonríes, imaginando a Casper sentado aquí cada día, escribiéndote."

# game/beyond the bet/badenddlc.rpy:106
translate Spanish dlc_badend_start_91852ca6:

    # "You boot up your computer."
    "Enciendes tu computadora."

# game/beyond the bet/badenddlc.rpy:107
translate Spanish dlc_badend_start_0167e8ec:

    # "And then you notice a message."
    "Y entonces notas un mensaje."

# game/beyond the bet/badenddlc.rpy:137
translate Spanish dlcbadchatstart_343129d6:

    # GR "sunshine... are you there?"
    GR "solecito... ¿estás ahí?"

# game/beyond the bet/badenddlc.rpy:140
translate Spanish dlcbadchatstart_560e757d:

    # player "Grim?"
    player "¿Parca?"

# game/beyond the bet/badenddlc.rpy:142
translate Spanish dlcbadchatstart_ecf16999:

    # player "Casper?"
    player "¿Casper?"

# game/beyond the bet/badenddlc.rpy:143
translate Spanish dlcbadchatstart_ab5175a2:

    # GR "good, good... i thought my app was playing up. aren't i clever? it works on my phone now."
    GR "bien, bien... pensé que mi aplicación estaba fallando. ¿acaso no soy ingenioso? ahora funciona en mi teléfono."

# game/beyond the bet/badenddlc.rpy:144
translate Spanish dlcbadchatstart_0c88be34:

    # GR "i could... keep in contact with you, regardless of where i am."
    GR "podría... mantenerme en contacto contigo, sin importar dónde me encuentre."

# game/beyond the bet/badenddlc.rpy:147
translate Spanish dlcbadchatstart_201c76b3:

    # player "Where are you?"
    player "¿Dónde estás?"

# game/beyond the bet/badenddlc.rpy:149
translate Spanish dlcbadchatstart_d99b4aed:

    # player "Is everything alright?"
    player "¿Está todo bien?"

# game/beyond the bet/badenddlc.rpy:150
translate Spanish dlcbadchatstart_7772a27d:

    # GR "..."
    GR "..."

# game/beyond the bet/badenddlc.rpy:151
translate Spanish dlcbadchatstart_031ae819:

    # GR "i am... on my way back, but..."
    GR "estoy... de camino de regreso, pero..."

# game/beyond the bet/badenddlc.rpy:152
translate Spanish dlcbadchatstart_f7dc5895:

    # GR "please promise me something."
    GR "por favor, prométeme algo."

# game/beyond the bet/badenddlc.rpy:155
translate Spanish dlcbadchatstart_1a79462e:

    # player "Casper, you're acting strange..."
    player "Casper, estás actuando raro..."

# game/beyond the bet/badenddlc.rpy:157
translate Spanish dlcbadchatstart_d86a3843:

    # player "Please just tell me what's going on."
    player "Por favor, dime qué está pasando."

# game/beyond the bet/badenddlc.rpy:158
translate Spanish dlcbadchatstart_b9bcafcf:

    # GR "do not overreact."
    GR "no reacciones de forma exagerada."

# game/beyond the bet/badenddlc.rpy:161
translate Spanish dlcbadchatstart_e9010c15:

    # player "About what?????"
    player "¿¿De qué?????"

# game/beyond the bet/badenddlc.rpy:162
translate Spanish dlcbadchatstart_1f42fb30:

    # GR "just promise me."
    GR "solo prométemelo."

# game/beyond the bet/badenddlc.rpy:165
translate Spanish dlcbadchatstart_3dfc8a01:

    # player "I can't make a promise I don't understand."
    player "No puedo hacer una promesa que no entiendo."

# game/beyond the bet/badenddlc.rpy:167
translate Spanish dlcbadchatstart_2920d744:

    # player "Why?"
    player "¿Por qué?"

# game/beyond the bet/badenddlc.rpy:168
translate Spanish dlcbadchatstart_7772a27d_1:

    # GR "..."
    GR "..."

# game/beyond the bet/badenddlc.rpy:169
translate Spanish dlcbadchatstart_790a7c2f:

    # GR "i have always loved you, you know."
    GR "siempre te he amado, ¿sabes?"

# game/beyond the bet/badenddlc.rpy:172
translate Spanish dlcbadchatstart_6a200d7b:

    # player "Stop talking like that."
    player "Deja de hablar así."

# game/beyond the bet/badenddlc.rpy:174
translate Spanish dlcbadchatstart_44437210:

    # player "You're scaring me."
    player "Me estás asustando."

# game/beyond the bet/badenddlc.rpy:175
translate Spanish dlcbadchatstart_d10bbd5b:

    # GR "you were annoying. terribly, awfully annoying."
    GR "eras irritante. terrible, espantosamente irritante."

# game/beyond the bet/badenddlc.rpy:176
translate Spanish dlcbadchatstart_b0cc8e8b:

    # GR "the most annoying person in the entire world."
    GR "la persona más irritante de todo el mundo."

# game/beyond the bet/badenddlc.rpy:177
translate Spanish dlcbadchatstart_5d45caee:

    # GR "but, nine hells, i've always loved you."
    GR "pero, por los nueve infiernos, siempre te he amado."

# game/beyond the bet/badenddlc.rpy:178
translate Spanish dlcbadchatstart_6b8c253e:

    # GR "who knew one person could be so bright, so lovely."
    GR "quién habría pensado que una persona podía ser tan luminosa, tan encantadora."

# game/beyond the bet/badenddlc.rpy:179
translate Spanish dlcbadchatstart_ee8ed841:

    # GR "perhaps i am... waxing poetic, but..."
    GR "quizá me estoy... poniendo poético, pero..."

# game/beyond the bet/badenddlc.rpy:180
translate Spanish dlcbadchatstart_26efd094:

    # GR "you brought so much light to my otherwise dull life."
    GR "le trajiste tanta luz a mi vida, que de otro modo era tan opaca."

# game/beyond the bet/badenddlc.rpy:181
translate Spanish dlcbadchatstart_848783f4:

    # GR "thank you, sunshine."
    GR "gracias, solecito."

# game/beyond the bet/badenddlc.rpy:184
translate Spanish dlcbadchatstart_1ca78a5c:

    # player "Casper, where are you?"
    player "Casper, ¿dónde estás?"

# game/beyond the bet/badenddlc.rpy:185
translate Spanish dlcbadchatstart_03c30333:

    # GR "i will be there soon."
    GR "pronto estaré ahí."

# game/beyond the bet/badenddlc.rpy:188
translate Spanish dlcbadchatstart_e618d4f0:

    # player "I'll come out and find you."
    player "Saldré a buscarte."

# game/beyond the bet/badenddlc.rpy:189
translate Spanish dlcbadchatstart_6de0b388:

    # GR "do not."
    GR "no lo hagas."

# game/beyond the bet/badenddlc.rpy:190
translate Spanish dlcbadchatstart_a25b573d:

    # GR "this place is dangerous."
    GR "este lugar es peligroso."

# game/beyond the bet/badenddlc.rpy:191
translate Spanish dlcbadchatstart_a29715b3:

    # GR "please, just wait there."
    GR "por favor, solo espera ahí."

# game/beyond the bet/badenddlc.rpy:192
translate Spanish dlcbadchatstart_07271454:

    # GR "when i return, i will... make sure you have safe passage home."
    GR "cuando regrese, me... aseguraré de que tengas un paso seguro de vuelta a casa."

# game/beyond the bet/badenddlc.rpy:193
translate Spanish dlcbadchatstart_75f597f4:

    # GR "i must."
    GR "debo hacerlo."

# game/beyond the bet/badenddlc.rpy:196
translate Spanish dlcbadchatstart_9d41e314:

    # player "I'm not going anywhere without you."
    player "No me iré sin ti."

# game/beyond the bet/badenddlc.rpy:198
translate Spanish dlcbadchatstart_06a9b07a:

    # player "Why do I have to leave?"
    player "¿Por qué tengo que irme?"

# game/beyond the bet/badenddlc.rpy:199
translate Spanish dlcbadchatstart_38f361dc:

    # GR "you must."
    GR "debes hacerlo."

# game/beyond the bet/badenddlc.rpy:200
translate Spanish dlcbadchatstart_ed7574a1:

    # GR "how i wish you could stay, or i could go, but..."
    GR "cuánto desearía que pudieras quedarte, o poder irme yo, pero..."

# game/beyond the bet/badenddlc.rpy:203
translate Spanish dlcbadchatstart_2627ae80:

    # player "Then come."
    player "Entonces ven."

# game/beyond the bet/badenddlc.rpy:204
translate Spanish dlcbadchatstart_dc1701e1:

    # GR "i'm sorry..."
    GR "lo siento..."

# game/beyond the bet/badenddlc.rpy:205
translate Spanish dlcbadchatstart_e2cbb5e8:

    # GR "if i could, i would."
    GR "si pudiera, lo haría."

# game/beyond the bet/badenddlc.rpy:206
translate Spanish dlcbadchatstart_2afe6bca:

    # GR "if it weren't for this damned job, then i... no, i can not blame this on everything but myself."
    GR "si no fuera por este maldito trabajo, entonces yo... no, no puedo culpar a todo menos a mí mismo."

# game/beyond the bet/badenddlc.rpy:207
translate Spanish dlcbadchatstart_424b0205:

    # GR "if it weren't for me, you would be safe."
    GR "si no fuera por mí, estarías a salvo."

# game/beyond the bet/badenddlc.rpy:208
translate Spanish dlcbadchatstart_b3ef8040:

    # GR "but i am a fool. the biggest fool in the world."
    GR "pero soy un necio. el mayor necio del mundo."

# game/beyond the bet/badenddlc.rpy:209
translate Spanish dlcbadchatstart_159b532e:

    # GR "thank you for loving this fool."
    GR "gracias por amar a este necio."

# game/beyond the bet/badenddlc.rpy:213
translate Spanish dlcbadchatstart_82a4499c:

    # player "Stop talking like you're dying."
    player "Deja de hablar como si te estuvieras muriendo."

# game/beyond the bet/badenddlc.rpy:241
translate Spanish dlcbadroom2_5983c441:

    # "You jump to your feet, then storm towards the door. "
    "Te pones de pie de un salto y te lanzas hacia la puerta. "

# game/beyond the bet/badenddlc.rpy:242
translate Spanish dlcbadroom2_684ace04:

    # "Throwing it open, you see darkness, lit occassionally by the odd streetlight." id dlcbadroom2_684ace04
    "Al abrirla de golpe, solo ves oscuridad, iluminada de vez en cuando por alguna farola." id dlcbadroom2_684ace04

# game/beyond the bet/badenddlc.rpy:243
translate Spanish dlcbadroom2_19912e45:

    # "But you only make it two steps out when you see it."
    "Pero apenas das dos pasos fuera cuando lo ves."

# game/beyond the bet/badenddlc.rpy:245
translate Spanish dlcbadroom2_2e41f687:

    # "Him."
    "A él."

# game/beyond the bet/badenddlc.rpy:246
translate Spanish dlcbadroom2_a1fee71a:

    # "Leaning against the wall beside your door, darkness seeping from his stomach, is Casper."
    "Apoyado contra la pared junto a tu puerta, con oscuridad filtrándose de su estómago, está Casper."

# game/beyond the bet/badenddlc.rpy:247
translate Spanish dlcbadroom2_1d91e54f:

    # "He looks up at you in surprise, but that switches to a gentle smile when he meets your eyes."
    "Alza la vista hacia ti con sorpresa, pero esta da paso a una sonrisa suave cuando sus ojos se encuentran con los tuyos."

# game/beyond the bet/badenddlc.rpy:264
translate Spanish badend_CG_750acbe6:

    # GRC "You found me."
    GRC "Me encontraste."

# game/beyond the bet/badenddlc.rpy:268
translate Spanish badend_CG_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/badenddlc.rpy:269
translate Spanish badend_CG_99d3d0a8:

    # GRC "I told you not to overreact."
    GRC "Te dije que no reaccionaras de forma exagerada."

# game/beyond the bet/badenddlc.rpy:279
translate Spanish badend_CG_7687498c:

    # GRC "Just stay with me."
    GRC "Solo quédate conmigo."

# game/beyond the bet/badenddlc.rpy:283
translate Spanish badend_CG_9998a22f:

    # GRC "Bandages won't be enough, and I've been marked a traitor. No one will help me here." id badend_CG_9998a22f
    GRC "Las vendas no serán suficientes, y me han marcado como traidor. Nadie me ayudará aquí." id badend_CG_9998a22f

# game/beyond the bet/badenddlc.rpy:290
translate Spanish badend_CG_1b61e29f:

    # GRC "I lack the strength. I... there's nothing we can do."
    GRC "No tengo fuerzas. Yo... no hay nada que podamos hacer."

# game/beyond the bet/badenddlc.rpy:291
translate Spanish badend_CG_7a224043:

    # GRC "But you can stay with me."
    GRC "Pero puedes quedarte conmigo."

# game/beyond the bet/badenddlc.rpy:292
translate Spanish badend_CG_47431b6d:

    # "{i}Tears well up in your eyes as you kneel down.{/i}"
    "{i}Las lágrimas te inundan los ojos mientras te arrodillas.{/i}"

# game/beyond the bet/badenddlc.rpy:293
translate Spanish badend_CG_609f08c9:

    # "{i}The smell of... something is strong.{/i}"
    "{i}El olor a... algo es intenso.{/i}"

# game/beyond the bet/badenddlc.rpy:294
translate Spanish badend_CG_36184fbb:

    # "{i}What is that smell?{/i}"
    "{i}¿Qué es ese olor?{/i}"

# game/beyond the bet/badenddlc.rpy:295
translate Spanish badend_CG_b80dc045:

    # "{i}It's almost like... ash, or smoke.{/i}"
    "{i}Es casi como... ceniza, o humo.{/i}"

# game/beyond the bet/badenddlc.rpy:296
translate Spanish badend_CG_aceea87b:

    # "{i}You don't know what it is, exactly, but you do recognize that it smells like... death, somehow.{/i}"
    "{i}No sabes qué es exactamente, pero reconoces que huele a... muerte, de algún modo.{/i}"

# game/beyond the bet/badenddlc.rpy:297
translate Spanish badend_CG_aa38a57b:

    # GRC "You know, Sunshine..."
    GRC "Sabes, Solecito..."

# game/beyond the bet/badenddlc.rpy:302
translate Spanish badend_CG_11a24a66:

    # GRC "The first time I touched you, I thanked whoever my creators were."
    GRC "La primera vez que te toqué, di gracias a quienes sea que me hayan creado."

# game/beyond the bet/badenddlc.rpy:303
translate Spanish badend_CG_d30b2f18:

    # GRC "Whoever my 'god' is."
    GRC "A quienquiera que sea mi 'dios'."

# game/beyond the bet/badenddlc.rpy:304
translate Spanish badend_CG_18d0f405:

    # GRC "Because they made me alive. They gave me touch, and feeling."
    GRC "Porque me dieron vida. Me dieron el tacto y la capacidad de sentir."

# game/beyond the bet/badenddlc.rpy:305
translate Spanish badend_CG_7cef01df:

    # GRC "I could reach out and touch you. I could feel your warmth beneath my fingers."
    GRC "Podía extender la mano y tocarte. Podía sentir tu calidez bajo mis dedos."

# game/beyond the bet/badenddlc.rpy:306
translate Spanish badend_CG_6f7af002:

    # GRC "What a blessing that was."
    GRC "Qué bendición fue aquello."

# game/beyond the bet/badenddlc.rpy:316
translate Spanish badend_CG_1f94a665:

    # GRC "That sounds nice..."
    GRC "Eso suena agradable..."

# game/beyond the bet/badenddlc.rpy:323
translate Spanish badend_CG_02d7dbb7:

    # GRC "I went looking for a way to break our connection."
    GRC "Salí en busca de una forma de romper nuestra conexión."

# game/beyond the bet/badenddlc.rpy:324
translate Spanish badend_CG_f686b8c5:

    # GRC "I found it. It worked. "
    GRC "La encontré. Funcionó. "

# game/beyond the bet/badenddlc.rpy:328
translate Spanish badend_CG_7f616772:

    # GRC "I... am hurt. You are not."
    GRC "Yo... estoy herido. Tú no."

# game/beyond the bet/badenddlc.rpy:329
translate Spanish badend_CG_ede430be:

    # GRC "Thank the gods you are not." id badend_CG_ede430be
    GRC "Gracias a los dioses que no." id badend_CG_ede430be

# game/beyond the bet/badenddlc.rpy:330
translate Spanish badend_CG_05da2a32:

    # GRC "Someone... someone I used to know found me. Tried to take me away, told me he'd have your soul once he'd dealt with me..."
    GRC "Alguien... alguien a quien conocí me encontró. Intentó llevarme, me dijo que se quedaría con tu alma cuando terminara conmigo..."

# game/beyond the bet/badenddlc.rpy:331
translate Spanish badend_CG_acf3c0f0:

    # GRC "But I couldn't.... I couldn't let him touch you, Sunshine."
    GRC "Pero no pude... no pude permitir que te tocara, Solecito."

# game/beyond the bet/badenddlc.rpy:332
translate Spanish badend_CG_ca318894:

    # GRC "I would give anything for you."
    GRC "Daría lo que fuera por ti."

# game/beyond the bet/badenddlc.rpy:333
translate Spanish badend_CG_87d29815:

    # GRC "I tried to fight him, but... well, maybe I'm not as good at everything as I assumed I was."
    GRC "Intenté luchar contra él, pero... bueno, quizá no soy tan bueno en todo como creía."

# game/beyond the bet/badenddlc.rpy:334
translate Spanish badend_CG_5d5bdee4:

    # GRC "I... I left part of my soul with you, Sunshine, before I cut away our connection. A much bigger part than before."
    GRC "Yo... dejé parte de mi alma contigo, Solecito, antes de cortar nuestra conexión. Una parte mucho más grande que la de antes."

# game/beyond the bet/badenddlc.rpy:335
translate Spanish badend_CG_c7a6cf00:

    # GRC "Part of me will always be with you."
    GRC "Una parte de mí siempre estará contigo."

# game/beyond the bet/badenddlc.rpy:336
translate Spanish badend_CG_9ce9d487:

    # GRC "If you ever feel lonely, put a hand to your chest and know that I will always be cheering you on."
    GRC "Si alguna vez sientes soledad, pon una mano sobre tu pecho y recuerda que siempre estaré animándote."

# game/beyond the bet/badenddlc.rpy:343
translate Spanish badend_CG_40bc7b37:

    # GRC "You'll be okay."
    GRC "Estarás bien."

# game/beyond the bet/badenddlc.rpy:344
translate Spanish badend_CG_af5e4a44:

    # GRC "You're a strong person."
    GRC "Eres una persona fuerte."

# game/beyond the bet/badenddlc.rpy:359
translate Spanish badend_CG_6b392c02:

    # GRC "I love you, too."
    GRC "Yo también te amo."

# game/beyond the bet/badenddlc.rpy:360
translate Spanish badend_CG_950b2bd5:

    # GRC "Gods, I love you so much."
    GRC "Dioses, te amo tanto."

# game/beyond the bet/badenddlc.rpy:361
translate Spanish badend_CG_2afc476a:

    # GRC "I've always thought the only fairness in life was death."
    GRC "Siempre pensé que lo único justo en la vida era la muerte."

# game/beyond the bet/badenddlc.rpy:362
translate Spanish badend_CG_410a7fe2:

    # GRC "But right now, it feels... unbelieveably unfair. I want to live."
    GRC "Pero ahora mismo se siente... increíblemente injusta. Quiero vivir."

# game/beyond the bet/badenddlc.rpy:363
translate Spanish badend_CG_3bddb278:

    # GRC "To stay with you."
    GRC "Quedarme contigo."

# game/beyond the bet/badenddlc.rpy:364
translate Spanish badend_CG_a92b6a24:

    # GRC "I was made for a singular purpose, and yet, here I am, failing it."
    GRC "Fui creado con un único propósito, y aun así, aquí estoy, fracasando en él."

# game/beyond the bet/badenddlc.rpy:365
translate Spanish badend_CG_99b255b3:

    # GRC "But I also feel... happy."
    GRC "Pero también me siento... feliz."

# game/beyond the bet/badenddlc.rpy:366
translate Spanish badend_CG_7225c77a:

    # GRC "Because I had you."
    GRC "Porque te tuve a ti."

# game/beyond the bet/badenddlc.rpy:367
translate Spanish badend_CG_755f811d:

    # GRC "If I had never met you, I wouldn't be feeling any of this."
    GRC "Si nunca te hubiera conocido, no estaría sintiendo nada de esto."

# game/beyond the bet/badenddlc.rpy:368
translate Spanish badend_CG_2e8a18f7:

    # GRC "I would never have felt love, or sorrow, or loss."
    GRC "Nunca habría sentido amor, ni pena, ni pérdida."

# game/beyond the bet/badenddlc.rpy:369
translate Spanish badend_CG_67605b06:

    # GRC "Never laughed, never cried."
    GRC "Nunca habría reído, nunca habría llorado."

# game/beyond the bet/badenddlc.rpy:370
translate Spanish badend_CG_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/badenddlc.rpy:371
translate Spanish badend_CG_92093b09:

    # GRC "Be happy."
    GRC "Sé feliz."

# game/beyond the bet/badenddlc.rpy:372
translate Spanish badend_CG_96103962:

    # GRC "You deserve to be happy."
    GRC "Mereces ser feliz."

# game/beyond the bet/badenddlc.rpy:379
translate Spanish badend_CG_09d5e37a:

    # GRC "I don't know, Sunshine."
    GRC "No lo sé, Solecito."

# game/beyond the bet/badenddlc.rpy:380
translate Spanish badend_CG_b66116ea:

    # GRC "I don't know."
    GRC "No lo sé."

# game/beyond the bet/badenddlc.rpy:381
translate Spanish badend_CG_6ef58d2c:

    # GRC "Ugh, khh..."
    GRC "Ugh, khh..."

# game/beyond the bet/badenddlc.rpy:382
translate Spanish badend_CG_4e7e77f7:

    # GRC "So, this is what it feels like, to die beside someone you love more than anything..."
    GRC "Así que esto es lo que se siente al morir junto a alguien a quien amas más que a nada..."

# game/beyond the bet/badenddlc.rpy:383
translate Spanish badend_CG_387885f4:

    # GRC "It is warmer... than I... imagined..."
    GRC "Es más cálido... de lo que... imaginaba..."

# game/beyond the bet/badenddlc.rpy:395
translate Spanish badend_CG_1127bb33:

    # "{i}His eyes fall closed, and his breathing begins to slow.{/i}"
    "{i}Sus ojos se cierran y su respiración empieza a hacerse más lenta.{/i}"

# game/beyond the bet/badenddlc.rpy:396
translate Spanish badend_CG_b735312b:

    # "{i}Your body trembles as tears spill down your cheeks.{/i}"
    "{i}Tu cuerpo tiembla mientras las lágrimas te ruedan por las mejillas.{/i}"

# game/beyond the bet/badenddlc.rpy:397
translate Spanish badend_CG_105bc5c9:

    # "{i}You reach for him and feel his heat - what little of it he has.{/i}"
    "{i}Lo buscas con la mano y sientes su calor, lo poco que le queda.{/i}"

# game/beyond the bet/badenddlc.rpy:398
translate Spanish badend_CG_3e226b78:

    # "{i}It is already fading.{/i}"
    "{i}Ya se está desvaneciendo.{/i}"

# game/beyond the bet/badenddlc.rpy:428
translate Spanish badend_CG_8b81c7ef:

    # "{i}You half lift, half drag Casper inside, away from prying eyes.{/i}"
    "{i}Medio levantas, medio arrastras a Casper hacia adentro, lejos de miradas indiscretas.{/i}"

# game/beyond the bet/badenddlc.rpy:430
translate Spanish badend_CG_2e348a03:

    # O_ip "How sad."
    O_ip "Qué triste."

# game/beyond the bet/badenddlc.rpy:440
translate Spanish badend_CG_d84812cc:

    # "{i}You don't even turn to look. You hear a voice - his voice. The voice of the person who sent you that letter.{/i}"
    "{i}Ni siquiera te giras a mirar. Oyes una voz: su voz. La voz de quien te envió aquella carta.{/i}"

# game/beyond the bet/badenddlc.rpy:441
translate Spanish badend_CG_2cb141ee:

    # "{i}You don't know how you know it, but you know it.{/i}"
    "{i}No sabes cómo lo sabes, pero lo sabes.{/i}"

# game/beyond the bet/badenddlc.rpy:442
translate Spanish badend_CG_42ddf447:

    # O_ip "This is what happens to those who break the rules, 'Sunshine'. Look and know that this was your fault."
    O_ip "Esto es lo que les ocurre a quienes rompen las reglas, 'Solecito'. Mira y entiende que esto fue culpa tuya."

# game/beyond the bet/badenddlc.rpy:443
translate Spanish badend_CG_b491fc40:

    # O_ip "And now..."
    O_ip "Y ahora..."

# game/beyond the bet/badenddlc.rpy:445
translate Spanish badend_CG_3445ce82:

    # O_ip "Your... soul...?"
    O_ip "¿Tu... alma...?"

# game/beyond the bet/badenddlc.rpy:447
translate Spanish badend_CG_8678a84c:

    # O_ip "Hah. So he has corrupted your soul with his own."
    O_ip "Ja. Así que ha corrompido tu alma con la suya."

# game/beyond the bet/badenddlc.rpy:448
translate Spanish badend_CG_e14e2785:

    # O_ip "A final effort to save that which he once loved."
    O_ip "Un último esfuerzo por salvar lo que alguna vez amó."

# game/beyond the bet/badenddlc.rpy:450
translate Spanish badend_CG_adfd3ef4:

    # O_ip "Your soul is no longer suitable for taking. Very well, it seems your 'Casper' has won, this time."
    O_ip "Tu alma ya no es apta para ser tomada. Muy bien, parece que tu 'Casper' ha ganado, esta vez."

# game/beyond the bet/badenddlc.rpy:457
translate Spanish badend_CG_2f4c2b31:

    # O_ip "He is gone."
    O_ip "Se ha ido."

# game/beyond the bet/badenddlc.rpy:458
translate Spanish badend_CG_b7b68fe7:

    # O_ip "You will be sent back to your home, and all memory of the Underworld, Casper, and anything he told you will be wiped from your mind."
    O_ip "Te enviarán de vuelta a tu hogar, y todo recuerdo del Inframundo, de Casper y de cualquier cosa que él te dijera será borrado de tu mente."

# game/beyond the bet/badenddlc.rpy:465
translate Spanish badend_CG_cf845f43:

    # O_ip "That matters little to me."
    O_ip "Eso me importa poco."

# game/beyond the bet/badenddlc.rpy:473
translate Spanish badend_CG_d4ea70a7:

    # center_text "You feel a hand on your shoulder, then everything goes white."
    center_text "Sientes una mano en tu hombro y luego todo se vuelve blanco."

# game/beyond the bet/badenddlc.rpy:474
translate Spanish badend_CG_11573e85:

    # center_text "The pain is brief, but sharp."
    center_text "El dolor es breve, pero agudo."

# game/beyond the bet/badenddlc.rpy:475
translate Spanish badend_CG_52b656d1:

    # center_text "But it's not the pain that matters."
    center_text "Pero no es el dolor lo que importa."

# game/beyond the bet/badenddlc.rpy:476
translate Spanish badend_CG_c302f2ab:

    # center_text "You feel it."
    center_text "Lo sientes."

# game/beyond the bet/badenddlc.rpy:477
translate Spanish badend_CG_e94b6c2b:

    # center_text "Every memory being ripped away from you."
    center_text "Cada recuerdo siendo arrancado de ti."

# game/beyond the bet/badenddlc.rpy:478
translate Spanish badend_CG_11d4f0ce:

    # center_text "Every call. Every joke. Every message."
    center_text "Cada llamada. Cada broma. Cada mensaje."

# game/beyond the bet/badenddlc.rpy:479
translate Spanish badend_CG_9b77a4a4:

    # center_text "Every time Casper called you 'Sunshine'."
    center_text "Cada vez que Casper te llamó 'Solecito'."

# game/beyond the bet/badenddlc.rpy:480
translate Spanish badend_CG_5550023d:

    # center_text "Every time he said he loved you."
    center_text "Cada vez que dijo que te amaba."

# game/beyond the bet/badenddlc.rpy:481
translate Spanish badend_CG_727b3d96:

    # center_text "The hours and hours spent talking."
    center_text "Las horas y horas que pasaron hablando."

# game/beyond the bet/badenddlc.rpy:482
translate Spanish badend_CG_59e4e32e:

    # center_text "Every memory burns away."
    center_text "Cada recuerdo se consume."

# game/beyond the bet/badenddlc.rpy:483
translate Spanish badend_CG_d5326f8c:

    # center_text "The last thing left is his name."
    center_text "Lo último que queda es su nombre."

# game/beyond the bet/badenddlc.rpy:484
translate Spanish badend_CG_483a3123:

    # center_text "Casper."
    center_text "Casper."

# game/beyond the bet/badenddlc.rpy:485
translate Spanish badend_CG_88a57915:

    # center_text "....Casper?"
    center_text "....¿Casper?"

# game/beyond the bet/badenddlc.rpy:486
translate Spanish badend_CG_58c5b926:

    # center_text "Who was that, anyway?"
    center_text "¿Quién era, de todos modos?"

# game/beyond the bet/badenddlc.rpy:487
translate Spanish badend_CG_7df2bad1:

    # center_text "This must all be a dream. Just a dream."
    center_text "Todo esto debe de ser un sueño. Solo un sueño."

# game/beyond the bet/badenddlc.rpy:488
translate Spanish badend_CG_764d1dbf:

    # center_text "With that in mind, you close your eyes against the blinding white light, then go to sleep."
    center_text "Con eso en mente, cierras los ojos ante la cegadora luz blanca y luego te duermes."

# game/beyond the bet/badenddlc.rpy:505
translate Spanish badenddlc_after_891562b8:

    # "Moonlight shines in through your open window. Your laptop sits in front of you, but you're too occupied with the window to pay much attention."
    "La luz de la luna entra por tu ventana abierta. Tu laptop está frente a ti, pero la ventana acapara tanto tu atención que apenas la notas."

# game/beyond the bet/badenddlc.rpy:510
translate Spanish badenddlc_after_b89cfdc5:

    # "You wait.... nothing."
    "Esperas... nada."

# game/beyond the bet/badenddlc.rpy:511
translate Spanish badenddlc_after_b7344455:

    # "So you wait a little longer, and then..."
    "Así que esperas un poco más, y entonces..."

# game/beyond the bet/badenddlc.rpy:512
translate Spanish badenddlc_after_3c12fb9c:

    # "Kaboom!"
    "¡Pum!"

# game/beyond the bet/badenddlc.rpy:513
translate Spanish badenddlc_after_7bbe5323:

    # "The sky is lit up by colorful fireworks. You watch the trails in wonder as the noise echoes out across the city."
    "El cielo se ilumina con fuegos artificiales de colores. Observas las estelas con asombro mientras el estruendo resuena por toda la ciudad."

# game/beyond the bet/badenddlc.rpy:514
translate Spanish badenddlc_after_daca7460:

    # "You've always enjoyed fireworks."
    "Siempre te han gustado los fuegos artificiales."

# game/beyond the bet/badenddlc.rpy:515
translate Spanish badenddlc_after_5b82f538:

    # "There's something... human and fleeting about them."
    "Tienen algo... humano y fugaz."

# game/beyond the bet/badenddlc.rpy:516
translate Spanish badenddlc_after_f4571ac1:

    # "As you continue watching, you can't help but notice that they almost form the shape of a flower."
    "Mientras sigues mirando, no puedes evitar notar que casi forman la silueta de una flor."

# game/beyond the bet/badenddlc.rpy:517
translate Spanish badenddlc_after_e8d0e49d:

    # "A sunflower, perhaps."
    "Un girasol, quizá."

# game/beyond the bet/badenddlc.rpy:518
translate Spanish badenddlc_after_627a33d4:

    # "You blink, your head hurting slightly."
    "Parpadeas, con un ligero dolor de cabeza."

# game/beyond the bet/badenddlc.rpy:519
translate Spanish badenddlc_after_ffc9045f:

    # "Something feels... missing."
    "Algo se siente... ausente."

# game/beyond the bet/badenddlc.rpy:520
translate Spanish badenddlc_after_a141ec15:

    # "You can't remember what, but it feels like you've forgotten the most important thing in the world."
    "No recuerdas qué, pero sientes que has olvidado lo más importante del mundo."

# game/beyond the bet/badenddlc.rpy:521
translate Spanish badenddlc_after_ac85cb33:

    # "The thing you cherished most."
    "Lo que más apreciabas."

# game/beyond the bet/badenddlc.rpy:522
translate Spanish badenddlc_after_7ec9dad6:

    # "It was..."
    "Era..."

# game/beyond the bet/badenddlc.rpy:523
translate Spanish badenddlc_after_fc254a88:

    # "What was it?"
    "¿Qué era?"

# game/beyond the bet/badenddlc.rpy:524
translate Spanish badenddlc_after_a20cefa7:

    # "..."
    "..."

# game/beyond the bet/badenddlc.rpy:525
translate Spanish badenddlc_after_2521d867:

    # "Oh well."
    "En fin."

# game/beyond the bet/badenddlc.rpy:527
translate Spanish badenddlc_after_b8de1180:

    # "Maybe you'll remember it tomorrow."
    "Quizá lo recuerdes mañana."

translate Spanish strings:

    # game/beyond the bet/badenddlc.rpy:45
    old "1. <{i}Look at his bookshelves.{/i}>"
    new "1. <{i}Mirar sus estanterías.{/i}>"

    # game/beyond the bet/badenddlc.rpy:62
    old "2. <{i}Look at his desk.{/i}>"
    new "2. <{i}Mirar su escritorio.{/i}>"

    # game/beyond the bet/badenddlc.rpy:77
    old "3. <{i}Look at his skincare product shelf.{/i}>"
    new "3. <{i}Mirar su estante de productos para el cuidado de la piel.{/i}>"

    # game/beyond the bet/badenddlc.rpy:114
    old "goodbye"
    new "adiós"

    # game/beyond the bet/badenddlc.rpy:139
    old "1. <Grim?>"
    new "1. <¿Parca?>"

    # game/beyond the bet/badenddlc.rpy:141
    old "2. <Casper?>"
    new "2. <¿Casper?>"

    # game/beyond the bet/badenddlc.rpy:146
    old "1. <Where are you?>"
    new "1. <¿Dónde estás?>"

    # game/beyond the bet/badenddlc.rpy:148
    old "2. <Is everything alright?>"
    new "2. <¿Está todo bien?>"

    # game/beyond the bet/badenddlc.rpy:154
    old "1. <Casper, you're acting strange...>"
    new "1. <Casper, estás actuando raro...>"

    # game/beyond the bet/badenddlc.rpy:156
    old "2. <Please just tell me what's going on.>"
    new "2. <Por favor, dime qué está pasando.>"

    # game/beyond the bet/badenddlc.rpy:160
    old "1. <About what?????>"
    new "1. <¿¿De qué?????>"

    # game/beyond the bet/badenddlc.rpy:164
    old "1. <I can't make a promise I don't understand.>"
    new "1. <No puedo hacer una promesa que no entiendo.>"

    # game/beyond the bet/badenddlc.rpy:166
    old "2. <Why?>"
    new "2. <¿Por qué?>"

    # game/beyond the bet/badenddlc.rpy:171
    old "1. <Stop talking like that.>"
    new "1. <Deja de hablar así.>"

    # game/beyond the bet/badenddlc.rpy:173
    old "2. <You're scaring me.>"
    new "2. <Me estás asustando.>"

    # game/beyond the bet/badenddlc.rpy:183
    old "1. <Casper, where are you?>"
    new "1. <Casper, ¿dónde estás?>"

    # game/beyond the bet/badenddlc.rpy:187
    old "1. <I'll come out and find you.>"
    new "1. <Saldré a buscarte.>"

    # game/beyond the bet/badenddlc.rpy:195
    old "1. <I'm not going anywhere without you.>"
    new "1. <No me iré sin ti.>"

    # game/beyond the bet/badenddlc.rpy:197
    old "2. <Why do I have to leave?>"
    new "2. <¿Por qué tengo que irme?>"

    # game/beyond the bet/badenddlc.rpy:202
    old "1. <Then come.>"
    new "1. <Entonces ven.>"

    # game/beyond the bet/badenddlc.rpy:212
    old "1. <Stop talking like you're dying.>"
    new "1. <Deja de hablar como si te estuvieras muriendo.>"

    # game/beyond the bet/badenddlc.rpy:266
    old "1. <Casper, what happened?!>"
    new "1. <¡Casper, ¿qué ha pasado?!>"

    # game/beyond the bet/badenddlc.rpy:271
    old "1. <And I didn't promise you anything!>"
    new "1. <¡Y yo no te prometí nada!>"

    # game/beyond the bet/badenddlc.rpy:274
    old "1. <Casper, we need to get you something!>"
    new "1. <¡Casper, tenemos que conseguirte algo!>"

    # game/beyond the bet/badenddlc.rpy:277
    old "1. <Bandages, or...>"
    new "1. <Vendas, o...>"

    # game/beyond the bet/badenddlc.rpy:281
    old "1. <No, I can't leave you like this. We need to get some help!>"
    new "1. <No, no puedo dejarte así. ¡Tenemos que conseguir ayuda!>"

    # game/beyond the bet/badenddlc.rpy:285
    old "1. <Then let's go back!>"
    new "1. <¡Entonces volvamos!>"

    # game/beyond the bet/badenddlc.rpy:288
    old "1. <We can go to a hospital!>"
    new "1. <¡Podemos ir a un hospital!>"

    # game/beyond the bet/badenddlc.rpy:308
    old "1. <Then don't stop now. Touch me. Feel my warmth.>"
    new "1. <Entonces no pares ahora. Tócame. Siente mi calidez.>"

    # game/beyond the bet/badenddlc.rpy:311
    old "1. <I'm not going anywhere.>"
    new "1. <No me voy a ninguna parte.>"

    # game/beyond the bet/badenddlc.rpy:314
    old "1. <Everything's going to be okay.>"
    new "1. <Todo va a salir bien.>"

    # game/beyond the bet/badenddlc.rpy:318
    old "1. <Casper, what happened?>"
    new "1. <Casper, ¿qué ha pasado?>"

    # game/beyond the bet/badenddlc.rpy:321
    old "1. <Please, tell me.>"
    new "1. <Por favor, dímelo.>"

    # game/beyond the bet/badenddlc.rpy:326
    old "1. <How do you know?>"
    new "1. <¿Cómo lo sabes?>"

    # game/beyond the bet/badenddlc.rpy:338
    old "1. <I can't go on without you, Casper...>"
    new "1. <No puedo seguir sin ti, Casper...>"

    # game/beyond the bet/badenddlc.rpy:341
    old "1. <Please don't go.>"
    new "1. <Por favor, no te vayas.>"

    # game/beyond the bet/badenddlc.rpy:346
    old "1. <Not without you.>"
    new "1. <No sin ti.>"

    # game/beyond the bet/badenddlc.rpy:348
    old "2. <I don't care about being strong, I just want you to stay.>"
    new "2. <No me importa ser fuerte, solo quiero que te quedes.>"

    # game/beyond the bet/badenddlc.rpy:354
    old "1. <Please.>"
    new "1. <Por favor.>"

    # game/beyond the bet/badenddlc.rpy:357
    old "1. <Don't leave.>"
    new "1. <No me dejes.>"

    # game/beyond the bet/badenddlc.rpy:374
    old "1. <How can I be happy without you now?>"
    new "1. <¿Cómo voy a ser feliz sin ti ahora?>"

    # game/beyond the bet/badenddlc.rpy:377
    old "1. <How can I go on after having you?>"
    new "1. <¿Cómo voy a seguir adelante después de haberte tenido?>"

    # game/beyond the bet/badenddlc.rpy:400
    old "1. <No, please...>"
    new "1. <No, por favor...>"

    # game/beyond the bet/badenddlc.rpy:402
    old "2. <Please, open your eyes.>"
    new "2. <Por favor, abre los ojos.>"

    # game/beyond the bet/badenddlc.rpy:405
    old "1. <Please, Casper!>"
    new "1. <¡Por favor, Casper!>"

    # game/beyond the bet/badenddlc.rpy:408
    old "1. <You said my soul was special, didn't you? That I could heal people?>"
    new "1. <Dijiste que mi alma era especial, ¿verdad? ¿Que podía curar a la gente?>"

    # game/beyond the bet/badenddlc.rpy:411
    old "1. <Then take my soul! Take it all!>"
    new "1. <¡Entonces toma mi alma! ¡Tómala toda!>"

    # game/beyond the bet/badenddlc.rpy:414
    old "1. <I'd give it away in a heartbeat just to talk to you for a moment longer.>"
    new "1. <La entregaría sin pensarlo con tal de hablar contigo un momento más.>"

    # game/beyond the bet/badenddlc.rpy:417
    old "1. <Why... why isn't it working...>"
    new "1. <¿Por qué... por qué no funciona...?>"

    # game/beyond the bet/badenddlc.rpy:419
    old "2. <Just... just take it... please...>"
    new "2. <Solo... solo tómala... por favor...>"

    # game/beyond the bet/badenddlc.rpy:452
    old "1. <Please, help him. Please.>"
    new "1. <Por favor, ayúdalo. Por favor.>"

    # game/beyond the bet/badenddlc.rpy:454
    old "2. <Can you... can you fix this...?>"
    new "2. <¿Puedes... puedes arreglar esto...?>"

    # game/beyond the bet/badenddlc.rpy:460
    old "1. <What...? No, I don't want that!>"
    new "1. <¿Qué...? ¡No, no quiero eso!>"

    # game/beyond the bet/badenddlc.rpy:462
    old "2. <I refuse to leave him!>"
    new "2. <¡Me niego a dejarlo!>"
