# TODO: Translation updated at 2026-10-15 18:36

# game/beyond the bet/day6dlc.rpy:10
translate Spanish day6dlc_start_d41d8cd9:

    # nvl clear
    nvl clear

# game/beyond the bet/day6dlc.rpy:21
translate Spanish day6dlc_start_0490abe4:

    # center_text "You'd already planned to take the day off work today, which was lucky, really."
    center_text "Ya habías planeado tomarte el día libre hoy, lo cual fue una suerte, la verdad."

# game/beyond the bet/day6dlc.rpy:22
translate Spanish day6dlc_start_9f590ec9:

    # center_text "Because you woke up this morning with something terrible..."
    center_text "Porque esta mañana te despertaste con algo terrible..."

# game/beyond the bet/day6dlc.rpy:23
translate Spanish day6dlc_start_059a6c39:

    # center_text "A cold."
    center_text "Un resfriado."

# game/beyond the bet/day6dlc.rpy:24
translate Spanish day6dlc_start_e02b5d33:

    # center_text "Your head hurt, your nose was stuffed, and your throat felt like you'd been swallowing gravel."
    center_text "Te dolía la cabeza, tenías la nariz tapada y sentías la garganta como si hubieras estado tragando grava."

# game/beyond the bet/day6dlc.rpy:25
translate Spanish day6dlc_start_e380de56:

    # center_text "Which you hadn't, of course. That would be stupid."
    center_text "Cosa que, claro, no habías hecho. Eso sería una estupidez."

# game/beyond the bet/day6dlc.rpy:26
translate Spanish day6dlc_start_5ac16afc:

    # center_text "You'd never eat gravel."
    center_text "Tú nunca te pondrías a comer grava."

# game/beyond the bet/day6dlc.rpy:27
translate Spanish day6dlc_start_2f7be77e:

    # center_text "You decided to stay in bed for the day and rest up, and it's midday when you wake up again feeling bored and lonely."
    center_text "Decidiste quedarte en la cama todo el día para descansar, y es mediodía cuando vuelves a despertar sintiéndote aburrid[letra] y sol[letra]."

# game/beyond the bet/day6dlc.rpy:28
translate Spanish day6dlc_start_edcd476d:

    # center_text "And what better to do when you're bored and lonely than chat with the guy who wants you dead?"
    center_text "¿Y qué mejor para cuando estás aburrid[letra] y sol[letra] que charlar con el tipo que te quiere muert[letra]?"

# game/beyond the bet/day6dlc.rpy:63
translate Spanish day6dlc_start2_ecf16999:

    # player "Casper?"
    player "¿Casper?"

# game/beyond the bet/day6dlc.rpy:66
translate Spanish day6dlc_start2_8d7325c3:

    # player "I..."
    player "Yo..."

# game/beyond the bet/day6dlc.rpy:69
translate Spanish day6dlc_start2_6e580bcf:

    # player "I just wanted to say thanks."
    player "Solo quería darte las gracias."

# game/beyond the bet/day6dlc.rpy:72
translate Spanish day6dlc_start2_87dc943f:

    # player "It's kinda embarrassing just to type this out, but..."
    player "Da un poco de vergüenza escribirlo, pero..."

# game/beyond the bet/day6dlc.rpy:75
translate Spanish day6dlc_start2_6820ebfe:

    # player "Where's my little reaper?"
    player "¿Dónde está mi parquita?"

# game/beyond the bet/day6dlc.rpy:78
translate Spanish day6dlc_start2_96d24b1c:

    # player "Well, now that we've met properly..."
    player "Bueno, ahora que nos hemos conocido bien..."

# game/beyond the bet/day6dlc.rpy:81
translate Spanish day6dlc_start2_36926941:

    # player "I don't know if 'little' is correct."
    player "No sé si 'parquita' sea la palabra correcta."

# game/beyond the bet/day6dlc.rpy:84
translate Spanish day6dlc_start2_42d03f53:

    # player "I mean, you seem normal sized."
    player "O sea, pareces de tamaño normal."

# game/beyond the bet/day6dlc.rpy:87
translate Spanish day6dlc_start2_acda0ac1:

    # player "A normal sized man."
    player "Un hombre de tamaño normal."

# game/beyond the bet/day6dlc.rpy:90
translate Spanish day6dlc_start2_3ee9706c:

    # player "Or something."
    player "O algo así."

# game/beyond the bet/day6dlc.rpy:93
translate Spanish day6dlc_start2_426a43ac:

    # player "Anyway..."
    player "En fin..."

# game/beyond the bet/day6dlc.rpy:97
translate Spanish day6dlc_start2_db01b372:

    # player "I really am grateful for the flowers."
    player "De verdad te agradezco las flores."

# game/beyond the bet/day6dlc.rpy:100
translate Spanish day6dlc_start2_90a28a21:

    # player "I felt a little stunned yesterday, so... just wanted to make sure you knew."
    player "Ayer me quedé un poco aturdid[letra], así que... quería asegurarme de que lo supieras."

# game/beyond the bet/day6dlc.rpy:101
translate Spanish day6dlc_start2_7772a27d:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:102
translate Spanish day6dlc_start2_4e590fec:

    # GR "it was... quite obvious."
    GR "fue... bastante obvio."

# game/beyond the bet/day6dlc.rpy:103
translate Spanish day6dlc_start2_ffe7caba:

    # GR "i saw your face when i handed them to you. "
    GR "vi tu cara cuando te las entregué."

# game/beyond the bet/day6dlc.rpy:104
translate Spanish day6dlc_start2_0bcfff99:

    # GR "perhaps you've already forgotten."
    GR "quizá ya lo has olvidado."

# game/beyond the bet/day6dlc.rpy:107
translate Spanish day6dlc_start2_e46082e7:

    # player "My memory isn't that bad!"
    player "¡Mi memoria no es tan mala!"

# game/beyond the bet/day6dlc.rpy:110
translate Spanish day6dlc_start2_b7dc1218:

    # player "I might be a bit of an airhead, but I remember that much at least!"
    player "Puede que sea un poco cabeza hueca, ¡pero eso al menos lo recuerdo!"

# game/beyond the bet/day6dlc.rpy:113
translate Spanish day6dlc_start2_abd91b35:

    # player "And I remember your cute face, too."
    player "Y también recuerdo tu linda carita."

# game/beyond the bet/day6dlc.rpy:116
translate Spanish day6dlc_start2_c1d1d4c4:

    # player "Were you feeling shy? "
    player "¿Te dio vergüenza?"

# game/beyond the bet/day6dlc.rpy:119
translate Spanish day6dlc_start2_0fce9ea4:

    # player "Your ears were red!"
    player "¡Tenías las orejas rojas!"

# game/beyond the bet/day6dlc.rpy:120
translate Spanish day6dlc_start2_7772a27d_1:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:121
translate Spanish day6dlc_start2_12e8be67:

    # GR "why do you remember my ears, of all things?"
    GR "¿por qué recuerdas mis orejas, de todas las cosas?"

# game/beyond the bet/day6dlc.rpy:122
translate Spanish day6dlc_start2_ba83ac5b:

    # GR "i have a perfectly good face you can admire."
    GR "tengo un rostro perfectamente bueno para que lo admires."

# game/beyond the bet/day6dlc.rpy:125
translate Spanish day6dlc_start2_4e662c0e:

    # player "Is the rest of you not worth admiring?"
    player "¿El resto de ti no merece ser admirado?"

# game/beyond the bet/day6dlc.rpy:126
translate Spanish day6dlc_start2_9ed63a1e:

    # GR "...it is."
    GR "...sí lo merece."

# game/beyond the bet/day6dlc.rpy:127
translate Spanish day6dlc_start2_77f5864f:

    # GR "right. of course it is."
    GR "claro. por supuesto que sí."

# game/beyond the bet/day6dlc.rpy:128
translate Spanish day6dlc_start2_10aca0c9:

    # GR "hah! mortal, you fall into my trap once again. i am that alluring, hm?"
    GR "¡ja! mortal, caes en mi trampa una vez más. ¿tan cautivador soy, eh?"

# game/beyond the bet/day6dlc.rpy:131
translate Spanish day6dlc_start2_431976c4:

    # player "Yeah, you're pretty alluring."
    player "Sí, eres bastante cautivador."

# game/beyond the bet/day6dlc.rpy:133
translate Spanish day6dlc_start2_89571a5a:

    # player "To be honest, I can't keep my eyes off you."
    player "Para ser sincer[letra], no puedo apartar los ojos de ti."

# game/beyond the bet/day6dlc.rpy:137
translate Spanish day6dlc_start2_210224c9:

    # player "I think even your shoulders were blushing."
    player "Creo que hasta tus hombros se sonrojaron."

# game/beyond the bet/day6dlc.rpy:140
translate Spanish day6dlc_start2_bd0aa18c:

    # player "Is that possible? Does my charm make your full body blush?"
    player "¿Es eso posible? ¿Mi encanto te hace sonrojar de pies a cabeza?"

# game/beyond the bet/day6dlc.rpy:141
translate Spanish day6dlc_start2_e5a6f156:

    # GR "what?!"
    GR "¡¿qué?!"

# game/beyond the bet/day6dlc.rpy:142
translate Spanish day6dlc_start2_9f092b50:

    # GR "it is unlikely that such a thing happened."
    GR "es poco probable que tal cosa haya ocurrido."

# game/beyond the bet/day6dlc.rpy:143
translate Spanish day6dlc_start2_684a9a53:

    # GR "i am the grim reaper, damn it, and grim reapers do not spend their time blushing."
    GR "soy la parca, maldición, y las parcas no se pasan el tiempo sonrojándose."

# game/beyond the bet/day6dlc.rpy:146
translate Spanish day6dlc_start2_229035b7:

    # player "Maybe you're not like other reapers."
    player "Quizá no eres como las otras parcas."

# game/beyond the bet/day6dlc.rpy:147
translate Spanish day6dlc_start2_b30dc515:

    # GR "i am perfectly normal."
    GR "soy perfectamente normal."

# game/beyond the bet/day6dlc.rpy:150
translate Spanish day6dlc_start2_47ea49a8:

    # player "Blushing is your normal, I'm afraid."
    player "Me temo que sonrojarte es lo normal en ti."

# game/beyond the bet/day6dlc.rpy:152
translate Spanish day6dlc_start2_eeab0a39:

    # GR "...perhaps the flowers were a bad idea."
    GR "...quizá las flores fueron una mala idea."

# game/beyond the bet/day6dlc.rpy:155
translate Spanish day6dlc_start2_885500ed:

    # player "How so?"
    player "¿Por qué lo dices?"

# game/beyond the bet/day6dlc.rpy:156
translate Spanish day6dlc_start2_9483e4fc:

    # GR "now you're being so... so..."
    GR "ahora estás siendo tan... tan..."

# game/beyond the bet/day6dlc.rpy:159
translate Spanish day6dlc_start2_ae804b0a:

    # player "Teasing? Perfect? Fantastic? Gorgeous?"
    player "¿Bromista? ¿Perfect[letra]? ¿Fantástic[letra]? ¿Guapísim[letra]?"

# game/beyond the bet/day6dlc.rpy:161
translate Spanish day6dlc_start2_131d435a:

    # player "Sarcastic? Hilarious? Inspiring? Considerate?"
    player "¿Sarcástic[letra]? ¿Gracios[letra]? ¿Admirable? ¿Considerad[letra]?"

# game/beyond the bet/day6dlc.rpy:162
translate Spanish day6dlc_start2_63c7d3a5:

    # GR "the first word, sure, the rest... i will leave that up to you."
    GR "la primera palabra, claro, el resto... lo dejo a tu criterio."

# game/beyond the bet/day6dlc.rpy:165
translate Spanish day6dlc_start2_d1a103a5:

    # player "You're not disagreeing!"
    player "¡No lo niegas!"

# game/beyond the bet/day6dlc.rpy:166
translate Spanish day6dlc_start2_c0ff4e42:

    # GR "neither am i agreeing!"
    GR "¡tampoco te estoy dando la razón!"

# game/beyond the bet/day6dlc.rpy:169
translate Spanish day6dlc_start2_bb841265:

    # player "I'll take it."
    player "Con eso me basta."

# game/beyond the bet/day6dlc.rpy:172
translate Spanish day6dlc_start2_489e431f:

    # player "That's one point to me."
    player "Un punto para mí."

# game/beyond the bet/day6dlc.rpy:175
translate Spanish day6dlc_start2_ea3932fe:

    # player "Maybe they were."
    player "Quizás lo fueron."

# game/beyond the bet/day6dlc.rpy:176
translate Spanish day6dlc_start2_094b8906:

    # GR "i... oh."
    GR "yo... oh."

# game/beyond the bet/day6dlc.rpy:177
translate Spanish day6dlc_start2_03700a5f:

    # GR "i mean... of course they were. i am the grim reaper."
    GR "quiero decir... claro que lo fueron. soy la parca."

# game/beyond the bet/day6dlc.rpy:178
translate Spanish day6dlc_start2_b1e5311b:

    # GR "i should not give a mortal flowers simply because they have never received them before."
    GR "no debería regalarle flores a [arti_2] mortal solo porque nunca las ha recibido."

# game/beyond the bet/day6dlc.rpy:179
translate Spanish day6dlc_start2_e7d30f37:

    # GR "and they deserve to receive them."
    GR "y merece recibirlas."

# game/beyond the bet/day6dlc.rpy:180
translate Spanish day6dlc_start2_c43fdb75:

    # GR "and every mortal who has failed to give them flowers in the past deserves to burn in the fiery pits of hell."
    GR "y todo mortal que no le haya regalado flores en el pasado merece arder en las fosas ardientes del infierno."

# game/beyond the bet/day6dlc.rpy:181
translate Spanish day6dlc_start2_715f17c7:

    # GR "because they are the brightest person i have ever met..."
    GR "porque es la persona más brillante que he conocido..."

# game/beyond the bet/day6dlc.rpy:182
translate Spanish day6dlc_start2_e0ed24b4:

    # GR "and why should the brightest person i've ever met not receive flowers?"
    GR "¿y por qué la persona más brillante que he conocido no habría de recibir flores?"

# game/beyond the bet/day6dlc.rpy:183
translate Spanish day6dlc_start2_ab08dda8:

    # GR "it would be stupidity beyond what i thought possible of mortals."
    GR "sería una estupidez más allá de lo que creía posible en los mortales."

# game/beyond the bet/day6dlc.rpy:184
translate Spanish day6dlc_start2_0b16bee0:

    # GR "ahem."
    GR "ejem."

# game/beyond the bet/day6dlc.rpy:185
translate Spanish day6dlc_start2_3c9faaf8:

    # GR "yes. those would be silly reasons to give someone flowers. of course."
    GR "sí. esas serían razones tontas para regalarle flores a alguien. claro."

# game/beyond the bet/day6dlc.rpy:188
translate Spanish day6dlc_start2_286d2c21:

    # player "...Is that all true?"
    player "...¿Todo eso es verdad?"

# game/beyond the bet/day6dlc.rpy:189
translate Spanish day6dlc_start2_3ff335df:

    # GR "i... was just being hypothetical."
    GR "yo... solo estaba siendo hipotético."

# game/beyond the bet/day6dlc.rpy:192
translate Spanish day6dlc_start2_0ecbf91f:

    # player "You can't lie!"
    player "¡No puedes mentir!"

# game/beyond the bet/day6dlc.rpy:195
translate Spanish day6dlc_start2_28959b4d:

    # player "Well, I love them!"
    player "¡Pues a mí me encantan!"

# game/beyond the bet/day6dlc.rpy:196
translate Spanish day6dlc_start2_52fa73b1:

    # GR "...you do?"
    GR "...¿en serio?"

# game/beyond the bet/day6dlc.rpy:199
translate Spanish day6dlc_start2_02a87ee6:

    # player "I told you that already, silly man."
    player "Ya te lo dije, tontito."

# game/beyond the bet/day6dlc.rpy:200
translate Spanish day6dlc_start2_dd8f3333:

    # GR "silly man?"
    GR "¿tontito?"

# game/beyond the bet/day6dlc.rpy:201
translate Spanish day6dlc_start2_516377b3:

    # GR "i do not particularly like this nickname."
    GR "no me gusta particularmente ese apodo."

# game/beyond the bet/day6dlc.rpy:204
translate Spanish day6dlc_start2_5558c868:

    # player "Then you should listen properly, mister."
    player "Entonces deberías escuchar bien, señor."

# game/beyond the bet/day6dlc.rpy:207
translate Spanish day6dlc_start2_fe72fdfa:

    # player "I love these flowers."
    player "Me encantan estas flores."

# game/beyond the bet/day6dlc.rpy:210
translate Spanish day6dlc_start2_9b5d4956:

    # player "I'm thinking of pressing them in a few days."
    player "Estoy pensando en prensarlas dentro de unos días."

# game/beyond the bet/day6dlc.rpy:211
translate Spanish day6dlc_start2_e87d68b4:

    # GR "pressing them into what?"
    GR "¿prensarlas para convertirlas en qué?"

# game/beyond the bet/day6dlc.rpy:214
translate Spanish day6dlc_start2_3ce3511f:

    # player "Like, drying them flat in a book or something."
    player "O sea, secarlas bien planas dentro de un libro o algo así."

# game/beyond the bet/day6dlc.rpy:217
translate Spanish day6dlc_start2_933d2ea5:

    # player "Then maybe I can use the petals for a bookmark or something."
    player "Así quizá pueda usar los pétalos como marcapáginas o algo así."

# game/beyond the bet/day6dlc.rpy:219
translate Spanish day6dlc_start2_b2d6ddb8:

    # player "You know, like some people do with their wedding bouquets."
    player "Ya sabes, como hacen algunas personas con sus ramos de boda."

# game/beyond the bet/day6dlc.rpy:222
translate Spanish day6dlc_start2_accaa33e:

    # player "I dunno yet. I just wanna keep them forever."
    player "Todavía no lo sé. Solo quiero conservarlas para siempre."

# game/beyond the bet/day6dlc.rpy:224
translate Spanish day6dlc_start2_41250153:

    # player "Don't you think that would be nice?"
    player "¿No crees que sería bonito?"

# game/beyond the bet/day6dlc.rpy:228
translate Spanish day6dlc_start2_2cc7063b:

    # player "Then they'll be with me forever."
    player "Así estarán conmigo para siempre."

# game/beyond the bet/day6dlc.rpy:230
translate Spanish day6dlc_start2_73ec2a71:

    # GR "might i remind you that your forever extends to today and tomorrow."
    GR "permíteme recordarte que tu 'para siempre' se extiende hasta hoy y mañana."

# game/beyond the bet/day6dlc.rpy:233
translate Spanish day6dlc_start2_321e8799:

    # player "Right!"
    player "¡Cierto!"

# game/beyond the bet/day6dlc.rpy:236
translate Spanish day6dlc_start2_4c00f7fa:

    # player "Soul taking, and all that."
    player "Lo de llevarte el alma y todo eso."

# game/beyond the bet/day6dlc.rpy:237
translate Spanish day6dlc_start2_686bf10e:

    # GR "you could sound a little more frightened..."
    GR "podrías parecer un poco más asustad[letra]..."

# game/beyond the bet/day6dlc.rpy:240
translate Spanish day6dlc_start2_c7621be6:

    # player "It's hard to be scared of you, Grim."
    player "Es difícil tenerte miedo, Parca."

# game/beyond the bet/day6dlc.rpy:242
translate Spanish day6dlc_start2_0c2e438d:

    # player "You're too sweet to be afraid of."
    player "Eres demasiado dulce para temerte."

# game/beyond the bet/day6dlc.rpy:243
translate Spanish day6dlc_start2_768f45ef:

    # GR "many have feared me."
    GR "muchos me han temido."

# game/beyond the bet/day6dlc.rpy:246
translate Spanish day6dlc_start2_c2317982:

    # player "Mister Big Bad Scary Grim Reaper."
    player "Señor Parca Grande, Malo y Aterrador."

# game/beyond the bet/day6dlc.rpy:247
translate Spanish day6dlc_start2_98627bf5:

    # GR "exactly. you are beginning to understand."
    GR "exacto. empiezas a entenderlo."

# game/beyond the bet/day6dlc.rpy:251
translate Spanish day6dlc_start2_60442cad:

    # player "I didn't know I could enjoy flowers so much."
    player "No sabía que podía disfrutar tanto de las flores."

# game/beyond the bet/day6dlc.rpy:254
translate Spanish day6dlc_start2_51024655:

    # player "They're... refreshing to have around. I'll be sad when they die."
    player "Son... refrescantes. Da gusto tenerlas cerca. Me pondré triste cuando se marchiten."

# game/beyond the bet/day6dlc.rpy:255
translate Spanish day6dlc_start2_7772a27d_2:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:256
translate Spanish day6dlc_start2_d957e871:

    # GR "well."
    GR "bueno."

# game/beyond the bet/day6dlc.rpy:257
translate Spanish day6dlc_start2_f093948e:

    # GR "perhaps someone will need to bring you more."
    GR "quizá alguien tendrá que traerte más."

# game/beyond the bet/day6dlc.rpy:260
translate Spanish day6dlc_start2_5839b4d2:

    # player "Someone like...?"
    player "¿Alguien como...?"

# game/beyond the bet/day6dlc.rpy:261
translate Spanish day6dlc_start2_7772a27d_3:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:262
translate Spanish day6dlc_start2_08eca73d:

    # GR "obviously someone immaculately handsome, charming, and perfect."
    GR "obviamente alguien inmaculadamente apuesto, encantador y perfecto."

# game/beyond the bet/day6dlc.rpy:265
translate Spanish day6dlc_start2_c13a45eb:

    # player "Can't say I know anyone like that."
    player "No creo conocer a nadie así."

# game/beyond the bet/day6dlc.rpy:267
translate Spanish day6dlc_start2_f2304224:

    # player "Hmmm... who could that be?"
    player "Mmm... ¿quién podrá ser?"

# game/beyond the bet/day6dlc.rpy:268
translate Spanish day6dlc_start2_4ee17326:

    # GR "ahah! it seems your memory is that bad, after all!"
    GR "¡ajá! ¡parece que tu memoria sí es así de mala, después de todo!"

# game/beyond the bet/day6dlc.rpy:271
translate Spanish day6dlc_start2_5f0a2c18:

    # player "Hmm... still thinking, but there really is no one like that."
    player "Mmm... sigo pensando, pero de verdad no hay nadie así."

# game/beyond the bet/day6dlc.rpy:272
translate Spanish day6dlc_start2_7772a27d_4:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:275
translate Spanish day6dlc_start2_486ddb6d:

    # player "Just kidding ;)"
    player "Era broma ;)"

# game/beyond the bet/day6dlc.rpy:277
translate Spanish day6dlc_start2_e2b8a586:

    # GR "i am starting to think you have a kink for bullying people, you know."
    GR "empiezo a pensar que tienes un fetiche con molestar a la gente, ¿sabes?"

# game/beyond the bet/day6dlc.rpy:280
translate Spanish day6dlc_start2_800eda5b:

    # player "What if I do?"
    player "¿Y si es así?"

# game/beyond the bet/day6dlc.rpy:281
translate Spanish day6dlc_start2_7abc4556:

    # GR "you admit it so freely!"
    GR "¡lo admites con tanta libertad!"

# game/beyond the bet/day6dlc.rpy:284
translate Spanish day6dlc_start2_ea12909d:

    # player "There's something freeing about making a handsome man blush."
    player "Hay algo liberador en hacer sonrojar a un hombre guapo."

# game/beyond the bet/day6dlc.rpy:287
translate Spanish day6dlc_start2_4f0b5909:

    # player "I fear I'm going crazy with the power I hold."
    player "Me temo que me estoy volviendo loc[letra] con el poder que tengo."

# game/beyond the bet/day6dlc.rpy:290
translate Spanish day6dlc_start2_18f71441:

    # player "This is my supervillain origin story."
    player "Este es mi origen como supervillan[letra]."

# game/beyond the bet/day6dlc.rpy:291
translate Spanish day6dlc_start2_8ede3c01:

    # GR "what?"
    GR "¿qué?"

# game/beyond the bet/day6dlc.rpy:294
translate Spanish day6dlc_start2_ecb53a25:

    # player "Don't you think I'd make a good supervillain?"
    player "¿No crees que se me daría bien ser [arti_2] supervillan[letra]?"

# game/beyond the bet/day6dlc.rpy:295
translate Spanish day6dlc_start2_d5f97507:

    # GR "er... not really."
    GR "mm... la verdad es que no."

# game/beyond the bet/day6dlc.rpy:298
translate Spanish day6dlc_start2_1fc0adac:

    # player "WHAT!"
    player "¡¿QUÉ?!"

# game/beyond the bet/day6dlc.rpy:300
translate Spanish day6dlc_start2_05cf1b99:

    # player "???"
    player "???"

# game/beyond the bet/day6dlc.rpy:304
translate Spanish day6dlc_start2_3eaf8f39:

    # player "Why not?!"
    player "¡¿Por qué no?!"

# game/beyond the bet/day6dlc.rpy:305
translate Spanish day6dlc_start2_7772a27d_5:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:306
translate Spanish day6dlc_start2_b9c44846:

    # GR "your heart is... kind."
    GR "tu corazón es... bondadoso."

# game/beyond the bet/day6dlc.rpy:307
translate Spanish day6dlc_start2_ca72c375:

    # GR "i doubt you could commit even one crime."
    GR "dudo que pudieras cometer siquiera un crimen."

# game/beyond the bet/day6dlc.rpy:310
translate Spanish day6dlc_start2_108bcff9:

    # player "Yeah, probably not."
    player "Sí, probablemente no."

# game/beyond the bet/day6dlc.rpy:313
translate Spanish day6dlc_start2_d8e2fd06:

    # player "I think you'd make a good supervillain, though."
    player "Aunque creo que tú sí serías un buen supervillano."

# game/beyond the bet/day6dlc.rpy:314
translate Spanish day6dlc_start2_3fe25d6e:

    # GR "what makes you think that?"
    GR "¿qué te hace pensar eso?"

# game/beyond the bet/day6dlc.rpy:317
translate Spanish day6dlc_start2_c89feed8:

    # player "Well, you kinda have the aesthetic down already."
    player "Bueno, ya tienes la estética."

# game/beyond the bet/day6dlc.rpy:318
translate Spanish day6dlc_start2_d8954a14:

    # GR "what's that supposed to mean?"
    GR "¿qué se supone que significa eso?"

# game/beyond the bet/day6dlc.rpy:321
translate Spanish day6dlc_start2_3e8668bf:

    # player "Like, you look kinda broody and evil until you open your mouth."
    player "O sea, tienes pinta de sombrío y malvado hasta que abres la boca."

# game/beyond the bet/day6dlc.rpy:324
translate Spanish day6dlc_start2_92529016:

    # player "And you can fly! And make yourself look like a bird!"
    player "¡Y puedes volar! ¡Y hacerte pasar por un pájaro!"

# game/beyond the bet/day6dlc.rpy:327
translate Spanish day6dlc_start2_49bed719:

    # player "You literally already have superpowers." id day6dlc_start2_49bed719
    player "Literalmente ya tienes superpoderes." id day6dlc_start2_49bed719

# game/beyond the bet/day6dlc.rpy:328
translate Spanish day6dlc_start2_67527862:

    # GR "it is not just a bird."
    GR "no es solo un pájaro."

# game/beyond the bet/day6dlc.rpy:329
translate Spanish day6dlc_start2_32bafe9a:

    # GR "i can make myself look like many things to other people."
    GR "puedo hacerme pasar por muchas cosas ante los demás."

# game/beyond the bet/day6dlc.rpy:330
translate Spanish day6dlc_start2_6e5624c3:

    # GR "it is useful for blending into the world when out on jobs."
    GR "es útil para camuflarme en el mundo cuando salgo a trabajar."

# game/beyond the bet/day6dlc.rpy:333
translate Spanish day6dlc_start2_e83f2f70:

    # player "I'm literally going to look at animals differently, now..."
    player "Literalmente, ahora voy a mirar a los animales de otra forma..."

# game/beyond the bet/day6dlc.rpy:336
translate Spanish day6dlc_start2_5679aa7c:

    # player "They're all incognito reapers..."
    player "Todos son parcas de incógnito..."

# game/beyond the bet/day6dlc.rpy:337
translate Spanish day6dlc_start2_7be85885:

    # GR "you would be surprised how many of them are."
    GR "te sorprendería saber cuántos de ellos lo son."

# game/beyond the bet/day6dlc.rpy:340
translate Spanish day6dlc_start2_b5f3f9b4:

    # player "Wait, do you have any other superpowers?"
    player "Espera, ¿tienes otros superpoderes?"

# game/beyond the bet/day6dlc.rpy:341
translate Spanish day6dlc_start2_ea8386c6:

    # GR "i would not describe any of my abilities as 'superpowers' to begin with."
    GR "para empezar, no describiría ninguna de mis habilidades como 'superpoderes'."

# game/beyond the bet/day6dlc.rpy:344
translate Spanish day6dlc_start2_e9af7707:

    # player "Okay, do you have any other {i}'abilities'{/i}?"
    player "Okey, ¿tienes otras {i}'habilidades'{/i}?"

# game/beyond the bet/day6dlc.rpy:345
translate Spanish day6dlc_start2_e52850cc:

    # GR "i can travel between the planes of reality. i can pull a soul from a mortal shell. i have plenty of abilities."
    GR "puedo viajar entre los planos de la realidad. puedo arrancar un alma de un cuerpo mortal. tengo muchísimas habilidades."

# game/beyond the bet/day6dlc.rpy:348
translate Spanish day6dlc_start2_e3260bda:

    # player "Super strength?"
    player "¿Superfuerza?"

# game/beyond the bet/day6dlc.rpy:349
translate Spanish day6dlc_start2_9313039a:

    # GR "my strength is ordinary."
    GR "mi fuerza es común y corriente."

# game/beyond the bet/day6dlc.rpy:352
translate Spanish day6dlc_start2_c72f4074:

    # player "Invisibility?"
    player "¿Invisibilidad?"

# game/beyond the bet/day6dlc.rpy:353
translate Spanish day6dlc_start2_6d34b495:

    # GR "i... could make myself look incredibly small. does that count?"
    GR "yo... podría hacerme ver increíblemente pequeño. ¿eso cuenta?"

# game/beyond the bet/day6dlc.rpy:356
translate Spanish day6dlc_start2_93666768:

    # player "Nope."
    player "Nop."

# game/beyond the bet/day6dlc.rpy:358
translate Spanish day6dlc_start2_879be65e:

    # player "Close, but no cigar."
    player "Casi, pero no hay premio."

# game/beyond the bet/day6dlc.rpy:359
translate Spanish day6dlc_start2_54850fcc:

    # GR "what's a cigar got to do with it?"
    GR "¿qué tiene que ver un premio con esto?"

# game/beyond the bet/day6dlc.rpy:362
translate Spanish day6dlc_start2_94dc49af:

    # player "Wait, can you see through clothes?"
    player "Espera, ¿puedes ver a través de la ropa?"

# game/beyond the bet/day6dlc.rpy:363
translate Spanish day6dlc_start2_3aa3e606:

    # GR "what??????"
    GR "¿¿¿¿¿¿qué??????"

# game/beyond the bet/day6dlc.rpy:364
translate Spanish day6dlc_start2_3cf688c5:

    # GR "what kind of superpower is that?"
    GR "¿qué clase de superpoder es ese?"

# game/beyond the bet/day6dlc.rpy:367
translate Spanish day6dlc_start2_ef653d29:

    # player "Definitely the super power of a super villain..."
    player "Definitivamente, el superpoder de un supervillano..."

# game/beyond the bet/day6dlc.rpy:370
translate Spanish day6dlc_start2_5c83d2d8:

    # player "I'm onto you, Grimmy."
    player "Ya te descubrí, Parquita."

# game/beyond the bet/day6dlc.rpy:371
translate Spanish day6dlc_start2_170c037a:

    # GR "i... would never just look at you naked!"
    GR "yo... ¡jamás te miraría desnud[letra] así como así!"

# game/beyond the bet/day6dlc.rpy:374
translate Spanish day6dlc_start2_15c3db15:

    # player "Oh? :("
    player "¿Ah, no? :("

# game/beyond the bet/day6dlc.rpy:375
translate Spanish day6dlc_start2_c245b22d:

    # GR "i...!"
    GR "¡yo...!"

# game/beyond the bet/day6dlc.rpy:376
translate Spanish day6dlc_start2_7fbe646e:

    # GR "gods, why are you doing this to me..."
    GR "dioses, ¿por qué me haces esto...?"

# game/beyond the bet/day6dlc.rpy:377
translate Spanish day6dlc_start2_6f9eb130:

    # GR "i mean... i... i wouldn't ever do it without permission, whether i could see through clothes or not!"
    GR "quiero decir... yo... ¡nunca lo haría sin permiso, pudiera ver a través de la ropa o no!"

# game/beyond the bet/day6dlc.rpy:380
translate Spanish day6dlc_start2_b456fd18:

    # player "So... you DO want to look through them?"
    player "Entonces... ¿SÍ quieres ver a través de la ropa?"

# game/beyond the bet/day6dlc.rpy:381
translate Spanish day6dlc_start2_5ace3137:

    # GR "i am not playing this game anymore."
    GR "ya no voy a seguir jugando a esto."

# game/beyond the bet/day6dlc.rpy:384
translate Spanish day6dlc_start2_ae5dfd2b:

    # player "Refusal is an answer itself."
    player "Negarse ya es una respuesta."

# game/beyond the bet/day6dlc.rpy:385
translate Spanish day6dlc_start2_10ad7da1:

    # GR "lalala. not listening."
    GR "lalala. no escucho."

# game/beyond the bet/day6dlc.rpy:388
translate Spanish day6dlc_start2_f9920e1d:

    # player "Fortunately, you don't have to listen, only see."
    player "Por suerte, no tienes que escuchar, solo ver."

# game/beyond the bet/day6dlc.rpy:389
translate Spanish day6dlc_start2_51883853:

    # GR "ah. suddenly, i can no longer see my screen. what a shame."
    GR "ah. de repente ya no puedo ver mi pantalla. qué lástima."

# game/beyond the bet/day6dlc.rpy:392
translate Spanish day6dlc_start2_e85ae26e:

    # player "I thought you couldn't lie!"
    player "¡Creía que no podías mentir!"

# game/beyond the bet/day6dlc.rpy:393
translate Spanish day6dlc_start2_ce325610:

    # GR "i closed my eyes for a moment. it was not a lie."
    GR "cerré los ojos un momento. no fue mentira."

# game/beyond the bet/day6dlc.rpy:396
translate Spanish day6dlc_start2_c59cb492:

    # player "Then you can see it again!"
    player "¡Entonces ya puedes volver a verla!"

# game/beyond the bet/day6dlc.rpy:400
translate Spanish day6dlc_start2_3ec897bd:

    # player "I know, I trust you wouldn't."
    player "Lo sé, confío en que no lo harías."

# game/beyond the bet/day6dlc.rpy:401
translate Spanish day6dlc_start2_5ec7bbed:

    # GR "i may be a reaper but i am also a man with morals."
    GR "puede que sea una parca, pero también soy un hombre con moral."

# game/beyond the bet/day6dlc.rpy:402
translate Spanish day6dlc_start2_672772a9:

    # GR "and there are lines i will not cross."
    GR "y hay límites que no cruzaré."

# game/beyond the bet/day6dlc.rpy:405
translate Spanish day6dlc_start2_9015419d:

    # player "Thanks Grimmy."
    player "Gracias, Parquita."

# game/beyond the bet/day6dlc.rpy:407
translate Spanish day6dlc_start2_cab53c1f:

    # player "We love a well mannered reaper."
    player "Nos encanta una parca con buenos modales."

# game/beyond the bet/day6dlc.rpy:408
translate Spanish day6dlc_start2_fb167be5:

    # GR "it is the kind of thing i would do only with permission."
    GR "es el tipo de cosa que solo haría con permiso."

# game/beyond the bet/day6dlc.rpy:411
translate Spanish day6dlc_start2_9f12ba97:

    # player "I'll keep it in mind."
    player "Lo tendré en cuenta."

# game/beyond the bet/day6dlc.rpy:412
translate Spanish day6dlc_start2_7772a27d_6:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:413
translate Spanish day6dlc_start2_4ee98cd4:

    # GR "okay."
    GR "okey."

# game/beyond the bet/day6dlc.rpy:417
translate Spanish day6dlc_start2_d36a66f7:

    # player "You can't even imagine the heinous acts I would commit for my child."
    player "No te imaginas los actos atroces que cometería por mi hij[letra_pet]."

# game/beyond the bet/day6dlc.rpy:420
translate Spanish day6dlc_start2_49544e23:

    # player "If someone hurt [pet_her2], I would burn the world down."
    player "Si alguien le hiciera daño a [pet_name], quemaría el mundo entero."

# game/beyond the bet/day6dlc.rpy:421
translate Spanish day6dlc_start2_9b033812:

    # GR "your... child?"
    GR "¿tu... hij[letra_pet]?"

# game/beyond the bet/day6dlc.rpy:426
translate Spanish day6dlc_start2_5503a072:

    # player "[pet_name], of course."
    player "[pet_name], por supuesto."

# game/beyond the bet/day6dlc.rpy:430
translate Spanish day6dlc_start2_e51b837f:

    # player "My pet, of course."
    player "Mi mascota, por supuesto."

# game/beyond the bet/day6dlc.rpy:432
translate Spanish day6dlc_start2_f38df6bb:

    # GR "you know what."
    GR "sabes qué."

# game/beyond the bet/day6dlc.rpy:433
translate Spanish day6dlc_start2_4ec0dfdb:

    # GR "for some reason i actually believe that."
    GR "por alguna razón, lo creo de verdad."

# game/beyond the bet/day6dlc.rpy:434
translate Spanish day6dlc_start2_47824ee3:

    # GR "you would be like that little 'meme' child."
    GR "serías como esa niña del 'meme'."

# game/beyond the bet/day6dlc.rpy:437
translate Spanish day6dlc_start2_12939665:

    # player "That what?"
    player "¿Esa qué?"

# game/beyond the bet/day6dlc.rpy:438
translate Spanish day6dlc_start2_ca941130:

    # GR "perhaps it is too recent a 'meme' for you to know it."
    GR "quizá es un 'meme' demasiado reciente para que lo conozcas."

# game/beyond the bet/day6dlc.rpy:439
translate Spanish day6dlc_start2_ad35e25f:

    # GR "it features a small child standing in front of a burning building, smiling."
    GR "muestra a una niña pequeña frente a un edificio en llamas, sonriendo."

# game/beyond the bet/day6dlc.rpy:442
translate Spanish day6dlc_start2_03775ec8:

    # player "..."
    player "..."

# game/beyond the bet/day6dlc.rpy:445
translate Spanish day6dlc_start2_c97035c9:

    # player "Casper, that's YEARS old!"
    player "¡Casper, eso es de hace AÑOS!"

# game/beyond the bet/day6dlc.rpy:448
translate Spanish day6dlc_start2_e6850d7c:

    # player "That child is an adult now."
    player "Esa niña ya es adulta."

# game/beyond the bet/day6dlc.rpy:449
translate Spanish day6dlc_start2_3261b4f0:

    # GR "really?"
    GR "¿en serio?"

# game/beyond the bet/day6dlc.rpy:450
translate Spanish day6dlc_start2_03e3a992:

    # GR "mortals age at such fascinating rates."
    GR "los mortales envejecen a ritmos fascinantes."

# game/beyond the bet/day6dlc.rpy:453
translate Spanish day6dlc_start2_3ef568a1:

    # player "Don't we just age at normal rates?"
    player "¿No envejecemos a un ritmo normal?"

# game/beyond the bet/day6dlc.rpy:454
translate Spanish day6dlc_start2_41524b92:

    # GR "what is normal?"
    GR "¿qué es lo normal?"

# game/beyond the bet/day6dlc.rpy:455
translate Spanish day6dlc_start2_f8cac46f:

    # GR "turtles live much longer than humans - is that rate not normal?"
    GR "las tortugas viven mucho más que los humanos, ¿ese ritmo no es normal?"

# game/beyond the bet/day6dlc.rpy:458
translate Spanish day6dlc_start2_08503dbe:

    # player "Touche."
    player "Touché."

# game/beyond the bet/day6dlc.rpy:461
translate Spanish day6dlc_start2_4968d89f:

    # player "Memes don't really age very well, anyway."
    player "Además, los memes no envejecen muy bien que digamos."

# game/beyond the bet/day6dlc.rpy:464
translate Spanish day6dlc_start2_629fa55d:

    # player "You gotta keep up to date with those things, Caspy-waspy."
    player "Tienes que mantenerte al día con esas cosas, Caspy-waspy."

# game/beyond the bet/day6dlc.rpy:465
translate Spanish day6dlc_start2_3aa852d4:

    # GR "c... caspy.... waspy...?"
    GR "c... caspy.... waspy...?"

# game/beyond the bet/day6dlc.rpy:468
translate Spanish day6dlc_start2_2ebab400:

    # player "No? You don't like that one?"
    player "¿No? ¿No te gusta ese?"

# game/beyond the bet/day6dlc.rpy:469
translate Spanish day6dlc_start2_205e26cc:

    # GR "i... never in my lifetime has anyone called me something so..."
    GR "yo... jamás en mi vida alguien me había llamado de forma tan..."

# game/beyond the bet/day6dlc.rpy:472
translate Spanish day6dlc_start2_fedb5997:

    # player "Amazing?"
    player "¿Increíble?"

# game/beyond the bet/day6dlc.rpy:474
translate Spanish day6dlc_start2_8e42bc2e:

    # player "Creative?"
    player "¿Creativa?"

# game/beyond the bet/day6dlc.rpy:476
translate Spanish day6dlc_start2_8935ab30:

    # player "Cute?"
    player "¿Tierna?"

# game/beyond the bet/day6dlc.rpy:478
translate Spanish day6dlc_start2_5ef8303c:

    # player "Fitting?"
    player "¿Apropiada?"

# game/beyond the bet/day6dlc.rpy:479
translate Spanish day6dlc_start2_7c5446ea:

    # GR "stupid!"
    GR "¡tonta!"

# game/beyond the bet/day6dlc.rpy:482
translate Spanish day6dlc_start2_e11487ee:

    # player "Soooo... do you like it or not?"
    player "Entoooonces... ¿te gusta o no?"

# game/beyond the bet/day6dlc.rpy:483
translate Spanish day6dlc_start2_588be31d:

    # GR "i refuse to elaborate."
    GR "no pienso dar explicaciones."

# game/beyond the bet/day6dlc.rpy:486
translate Spanish day6dlc_start2_5b8790d7:

    # player "Awww. You like it!"
    player "¡Aww! ¡Te gusta!"

# game/beyond the bet/day6dlc.rpy:489
translate Spanish day6dlc_start2_ef3a023a:

    # player "Sunshine and Caspy-waspy :)"
    player "Solecito y Caspy-waspy :)"

# game/beyond the bet/day6dlc.rpy:490
translate Spanish day6dlc_start2_7772a27d_7:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:495
translate Spanish day6dlc_start2_0852b82d:

    # player "I have a kink for blushing Grim Reapers."
    player "Tengo un fetiche con las Parcas sonrojadas."

# game/beyond the bet/day6dlc.rpy:496
translate Spanish day6dlc_start2_75f399fe:

    # GR "HUH?"
    GR "¿¿EH??"

# game/beyond the bet/day6dlc.rpy:499
translate Spanish day6dlc_start2_6669f036:

    # player "Oh, all capitals. Things are getting serious."
    player "Oh, todo en mayúsculas. Las cosas se ponen serias."

# game/beyond the bet/day6dlc.rpy:500
translate Spanish day6dlc_start2_8102d0dd:

    # GR "how many grim reapers do you know?!"
    GR "¡¿a cuántas parcas conoces?!"

# game/beyond the bet/day6dlc.rpy:503
translate Spanish day6dlc_start2_4273cc5a:

    # player "Just the one, actually."
    player "Solo una, en realidad."

# game/beyond the bet/day6dlc.rpy:504
translate Spanish day6dlc_start2_d369fc6b:

    # GR "then how could it possibly be a kink!"
    GR "¡entonces cómo podría ser un fetiche!"

# game/beyond the bet/day6dlc.rpy:507
translate Spanish day6dlc_start2_2068ac9d:

    # player "It's a new discovery of mine."
    player "Es un nuevo descubrimiento."

# game/beyond the bet/day6dlc.rpy:510
translate Spanish day6dlc_start2_81bfe6d1:

    # player "You should be proud, Grimmy. You've inspired this in me <3"
    player "Deberías estar orgulloso, Parquita. Tú me inspiraste esto <3"

# game/beyond the bet/day6dlc.rpy:511
translate Spanish day6dlc_start2_7772a27d_8:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:512
translate Spanish day6dlc_start2_20e41447:

    # GR "i... i..."
    GR "yo... yo..."

# game/beyond the bet/day6dlc.rpy:513
translate Spanish day6dlc_start2_c8709be8:

    # GR "i don't believe i blush as much as you insist!"
    GR "¡no creo que me sonroje tanto como insistes!"

# game/beyond the bet/day6dlc.rpy:516
translate Spanish day6dlc_start2_2a994e37:

    # player "Probably more."
    player "Probablemente más."

# game/beyond the bet/day6dlc.rpy:519
translate Spanish day6dlc_start2_ef4d8743:

    # player "Luckily I think it's adorable."
    player "Por suerte, me parece adorable."

# game/beyond the bet/day6dlc.rpy:520
translate Spanish day6dlc_start2_75a6e3d8:

    # GR "adorable... you make me sound like a domesticated pet."
    GR "adorable... me haces sonar como una mascota domesticada."

# game/beyond the bet/day6dlc.rpy:523
translate Spanish day6dlc_start2_5c40587a:

    # player "Hey, if that's what you want."
    player "Oye, si eso es lo que quieres."

# game/beyond the bet/day6dlc.rpy:526
translate Spanish day6dlc_start2_124d3855:

    # player "I'll let you come sit on my lap. Come here, boy."
    player "Te dejaré sentarte en mi regazo. Ven aquí, chico."

# game/beyond the bet/day6dlc.rpy:527
translate Spanish day6dlc_start2_7772a27d_9:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:530
translate Spanish day6dlc_start2_036e165b:

    # player "Go on, roll over. There's a good boy! Who wants a treat?"
    player "Vamos, date la vuelta. ¡Así, buen chico! ¿Quién quiere un premio?"

# game/beyond the bet/day6dlc.rpy:531
translate Spanish day6dlc_start2_4329b728:

    # GR "m... me..."
    GR "y... yo..."

# game/beyond the bet/day6dlc.rpy:534
translate Spanish day6dlc_start2_dd2d4b1d:

    # player "You can come over and sleep on my lap, then <3"
    player "Entonces puedes venir a dormir en mi regazo <3"

# game/beyond the bet/day6dlc.rpy:535
translate Spanish day6dlc_start2_7772a27d_10:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:536
translate Spanish day6dlc_start2_1ca1078c:

    # GR "you should not offer such a thing so freely, [playerfirstname!l]."
    GR "no deberías ofrecer algo así con tanta ligereza, [playerfirstname!l]."

# game/beyond the bet/day6dlc.rpy:537
translate Spanish day6dlc_start2_6e691f33:

    # GR "it... someone could easily misunderstand your intentions..."
    GR "alguien podría malinterpretar fácilmente tus intenciones..."

# game/beyond the bet/day6dlc.rpy:540
translate Spanish day6dlc_start2_7ceb3e6f:

    # player "I think I'm being pretty transparent about my intentions, Grimmy."
    player "Creo que estoy siendo bastante transparente con mis intenciones, Parquita."

# game/beyond the bet/day6dlc.rpy:543
translate Spanish day6dlc_start2_ee721d60:

    # player "I like doing things that make you blush."
    player "Me gusta hacer cosas que te hagan sonrojar."

# game/beyond the bet/day6dlc.rpy:544
translate Spanish day6dlc_start2_7772a27d_11:

    # GR "..."
    GR "…"

# game/beyond the bet/day6dlc.rpy:545
translate Spanish day6dlc_start2_6125c213:

    # GR "well, perhaps for a change i would like to make YOU blush."
    GR "bueno, quizá para variar me gustaría hacerte sonrojar a TI."

# game/beyond the bet/day6dlc.rpy:548
translate Spanish day6dlc_start2_e073bc32:

    # player "Give it a go, then."
    player "Inténtalo, entonces."

# game/beyond the bet/day6dlc.rpy:549
translate Spanish day6dlc_start2_0062f744:

    # GR "ah... ahem..."
    GR "ah... ejem..."

# game/beyond the bet/day6dlc.rpy:550
translate Spanish day6dlc_start2_6c9e3aa9:

    # GR "you... you are very..."
    GR "tú... tú eres muy..."

# game/beyond the bet/day6dlc.rpy:551
translate Spanish day6dlc_start2_bf642f9d:

    # GR "no, that's not right."
    GR "no, eso no está bien."

# game/beyond the bet/day6dlc.rpy:552
translate Spanish day6dlc_start2_41187a30:

    # GR "um."
    GR "eh."

# game/beyond the bet/day6dlc.rpy:553
translate Spanish day6dlc_start2_702b75c5:

    # GR "sunshine, i..."
    GR "solecito, yo..."

# game/beyond the bet/day6dlc.rpy:554
translate Spanish day6dlc_start2_a38c707f:

    # GR "i think you... are the one who would look good lying in my lap..."
    GR "creo que tú... serías quien se vería bien recostad[letra] en mi regazo..."

# game/beyond the bet/day6dlc.rpy:555
translate Spanish day6dlc_start2_dc8e2caf:

    # GR "i can imagine the sunlight drifting in lazily from the window in the mid-afternoon..."
    GR "puedo imaginar la luz del sol entrando perezosa por la ventana a media tarde..."

# game/beyond the bet/day6dlc.rpy:556
translate Spanish day6dlc_start2_bed115d8:

    # GR "and you there, in those rays, looking at home..."
    GR "y a ti ahí, bajo esos rayos, como en casa..."

# game/beyond the bet/day6dlc.rpy:557
translate Spanish day6dlc_start2_9326fb35:

    # GR "if that were the case, then i believe life would be perfect."
    GR "si así fuera, creo que la vida sería perfecta."

# game/beyond the bet/day6dlc.rpy:560
translate Spanish day6dlc_start2_03775ec8_1:

    # player "..."
    player "…"

# game/beyond the bet/day6dlc.rpy:563
translate Spanish day6dlc_start2_6d3e25ff:

    # player "Is that true?"
    player "¿Es verdad?"

# game/beyond the bet/day6dlc.rpy:564
translate Spanish day6dlc_start2_4809dbc2:

    # GR "you know i cannot lie."
    GR "sabes que no puedo mentir."

# game/beyond the bet/day6dlc.rpy:565
translate Spanish day6dlc_start2_94bd39ad:

    # GR "even if i could, i would not lie about this."
    GR "aunque pudiera, no mentiría sobre esto."

# game/beyond the bet/day6dlc.rpy:568
translate Spanish day6dlc_start2_076f61db:

    # player "Well... maybe I think that sounds perfect too."
    player "Bueno... quizá a mí también me parece perfecto."

# game/beyond the bet/day6dlc.rpy:569
translate Spanish day6dlc_start2_1dfc4c6e:

    # GR "did you blush?"
    GR "¿te sonrojaste?"

# game/beyond the bet/day6dlc.rpy:572
translate Spanish day6dlc_start2_b58385b3:

    # player "A little."
    player "Un poco."

# game/beyond the bet/day6dlc.rpy:573
translate Spanish day6dlc_start2_b0f3e060:

    # GR "i will take a little."
    GR "me conformo con un poco."

# game/beyond the bet/day6dlc.rpy:576
translate Spanish day6dlc_start2_a6262ee6:

    # player "...Quite a bit, yes."
    player "...Bastante, sí."

# game/beyond the bet/day6dlc.rpy:577
translate Spanish day6dlc_start2_a7ce6f05:

    # GR "good, do try to remember it then."
    GR "bien, procura recordarlo entonces."

# game/beyond the bet/day6dlc.rpy:580
translate Spanish day6dlc_start2_c64283ef:

    # player "There was one other reaper, actually."
    player "En realidad, conocí a otra parca."

# game/beyond the bet/day6dlc.rpy:581
translate Spanish day6dlc_start2_eba278ab:

    # GR "who??? who would dare try to steal my quarry out from under me?"
    GR "¿¿¿quién??? ¿quién se atrevería a quitarme mi presa delante de mis narices?"

# game/beyond the bet/day6dlc.rpy:584
translate Spanish day6dlc_start2_9e1cfaf6:

    # player "I think his name was... Jeremy?"
    player "Creo que se llamaba... ¿Jeremy?"

# game/beyond the bet/day6dlc.rpy:585
translate Spanish day6dlc_start2_deac16bc:

    # GR "JEREMY!"
    GR "¡JEREMY!"

# game/beyond the bet/day6dlc.rpy:586
translate Spanish day6dlc_start2_e7ffc4c4:

    # GR "i may not have heard of you, jeremy, but today you are my mortal enemy."
    GR "puede que no haya oído hablar de ti, jeremy, pero hoy eres mi enemigo mortal."

# game/beyond the bet/day6dlc.rpy:587
translate Spanish day6dlc_start2_237c9046:

    # GR "sunshine, i will not let jeremy lay a single finger on you."
    GR "solecito, no permitiré que jeremy te ponga un solo dedo encima."

# game/beyond the bet/day6dlc.rpy:588
translate Spanish day6dlc_start2_175bd154:

    # GR "the fact he does not hold to the reaper's code disgusts me."
    GR "me repugna que no respete el código de las parcas."

# game/beyond the bet/day6dlc.rpy:589
translate Spanish day6dlc_start2_a86d5d47:

    # GR "you are my mortal. no one else's."
    GR "eres mi mortal. de nadie más."

# game/beyond the bet/day6dlc.rpy:590
translate Spanish day6dlc_start2_fed7a570:

    # GR "jeremy the grim reaper, your time is short."
    GR "jeremy la parca, tu tiempo es corto."

# game/beyond the bet/day6dlc.rpy:594
translate Spanish day6dlc_start2_7fa63d5d:

    # player "Poor, poor Jeremy..."
    player "Pobre, pobre Jeremy..."

# game/beyond the bet/day6dlc.rpy:595
translate Spanish day6dlc_start2_d8f6050a:

    # GR "what do you mean poor jeremy?!"
    GR "¡¿a qué te refieres con pobre jeremy?!"

# game/beyond the bet/day6dlc.rpy:596
translate Spanish day6dlc_start2_2688b0d9:

    # GR "jeremy can only be after your soul! you should not feel sorry for him, nor pity him!"
    GR "¡jeremy solo puede ir tras tu alma! ¡no deberías sentir lástima por él, ni compasión!"

# game/beyond the bet/day6dlc.rpy:599
translate Spanish day6dlc_start2_a156ee05:

    # player "But Jeremy and I are friends :("
    player "Pero Jeremy y yo somos amigos :("

# game/beyond the bet/day6dlc.rpy:600
translate Spanish day6dlc_start2_cff50c54:

    # GR "that cannot be true."
    GR "eso no puede ser cierto."

# game/beyond the bet/day6dlc.rpy:601
translate Spanish day6dlc_start2_749ac3f4:

    # GR "he is tricking you."
    GR "te está engañando."

# game/beyond the bet/day6dlc.rpy:604
translate Spanish day6dlc_start2_2c627f23:

    # player "What about you, then?"
    player "¿Y tú, entonces?"

# game/beyond the bet/day6dlc.rpy:607
translate Spanish day6dlc_start2_4e82133e:

    # player "You want me to die, but you bring me flowers?"
    player "¿Quieres que me muera, pero me traes flores?"

# game/beyond the bet/day6dlc.rpy:610
translate Spanish day6dlc_start2_d28d3a48:

    # player "Are you tricking me?"
    player "¿Me estás engañando?"

# game/beyond the bet/day6dlc.rpy:611
translate Spanish day6dlc_start2_c30211c0:

    # GR "i..."
    GR "yo..."

# game/beyond the bet/day6dlc.rpy:612
translate Spanish day6dlc_start2_6b414af0:

    # GR "do not try to change the subject. jeremy and i are completely different."
    GR "no intentes cambiar de tema. jeremy y yo somos completamente distintos."

# game/beyond the bet/day6dlc.rpy:615
translate Spanish day6dlc_start2_1c83f6fd:

    # player "Actually, you're both pretty similar."
    player "En realidad, son bastante parecidos."

# game/beyond the bet/day6dlc.rpy:618
translate Spanish day6dlc_start2_68046ec1:

    # player "Do all of you reapers have white hair and red eyes?"
    player "¿Todas las parcas tienen el pelo blanco y los ojos rojos?"

# game/beyond the bet/day6dlc.rpy:619
translate Spanish day6dlc_start2_b500f9c0:

    # GR "YOU HAVE MET HIM???"
    GR "¡¿YA LO HAS CONOCIDO?!"

# game/beyond the bet/day6dlc.rpy:622
translate Spanish day6dlc_start2_c9a748b7:

    # player "Once or twice."
    player "Una o dos veces."

# game/beyond the bet/day6dlc.rpy:624
translate Spanish day6dlc_start2_6893cee7:

    # player "Maaaybe."
    player "Quizááá."

# game/beyond the bet/day6dlc.rpy:625
translate Spanish day6dlc_start2_09097f34:

    # GR "jeremy, you will rue the day you crossed me."
    GR "jeremy, lamentarás el día en que te cruzaste conmigo."

# game/beyond the bet/day6dlc.rpy:626
translate Spanish day6dlc_start2_99d32833:

    # GR "and, no. we don't all have matching features."
    GR "y no. no todos tenemos los mismos rasgos."

# game/beyond the bet/day6dlc.rpy:627
translate Spanish day6dlc_start2_4430c6eb:

    # GR "my white hair and red eyes are supposed to be my original charm points........."
    GR "se supone que mi cabello blanco y mis ojos rojos son mis encantos distintivos........."

# game/beyond the bet/day6dlc.rpy:628
translate Spanish day6dlc_start2_429fe4f7:

    # GR "to know that another is out there, copying me.... i will not allow this."
    GR "saber que hay otro por ahí, copiándome.... no lo permitiré."

# game/beyond the bet/day6dlc.rpy:631
translate Spanish day6dlc_start2_c51c1ebd:

    # player "Wait, forget Jeremy. You really don't all look alike?"
    player "Espera, olvida a Jeremy. ¿De verdad no se parecen todos?"

# game/beyond the bet/day6dlc.rpy:632
translate Spanish day6dlc_start2_e4e3c06c:

    # GR "is that so surprising?"
    GR "¿tan sorprendente es?"

# game/beyond the bet/day6dlc.rpy:633
translate Spanish day6dlc_start2_dffd3fba:

    # GR "you mortals do not all look alike."
    GR "ustedes los mortales tampoco se parecen todos."

# game/beyond the bet/day6dlc.rpy:636
translate Spanish day6dlc_start2_776bbbc7:

    # player "I guess that makes sense."
    player "Supongo que tiene sentido."

# game/beyond the bet/day6dlc.rpy:639
translate Spanish day6dlc_start2_9ad59d1c:

    # player "I just thought, maybe you were all created in a lab or something to look the same"
    player "Solo pensé que quizá los habían creado a todos en un laboratorio o algo así para que se vieran iguales."

# game/beyond the bet/day6dlc.rpy:640
translate Spanish day6dlc_start2_f5df585b:

    # GR "this is not a video game, [playerfirstname!l]."
    GR "esto no es un videojuego, [playerfirstname!l]."

# game/beyond the bet/day6dlc.rpy:643
translate Spanish day6dlc_start2_adf4cae0:

    # player "Imagine if it was."
    player "Imagínate que lo fuera."

# game/beyond the bet/day6dlc.rpy:646
translate Spanish day6dlc_start2_a7092644:

    # player "Right now your love bar would be full."
    player "Ahora mismo tendrías la barra de amor llena."

# game/beyond the bet/day6dlc.rpy:647
translate Spanish day6dlc_start2_7419275a:

    # GR "it would be empty."
    GR "estaría vacía."

# game/beyond the bet/day6dlc.rpy:650
translate Spanish day6dlc_start2_775e22d2:

    # player "I just had your ten star heart event, Grimmy. It's definitely full."
    player "Acabo de desbloquear tu evento romántico de diez estrellas, Parquita. Esa barra está llenísima."

# game/beyond the bet/day6dlc.rpy:651
translate Spanish day6dlc_start2_7772a27d_12:

    # GR "..."
    GR "…"

# game/beyond the bet/day6dlc.rpy:652
translate Spanish day6dlc_start2_d957e871_1:

    # GR "well."
    GR "bueno."

# game/beyond the bet/day6dlc.rpy:653
translate Spanish day6dlc_start2_8b4db409:

    # GR "personally, i believe it's the other way around."
    GR "personalmente, creo que es al revés."

# game/beyond the bet/day6dlc.rpy:654
translate Spanish day6dlc_start2_824714e5:

    # GR "i would be the 'main character', so to speak."
    GR "yo sería el 'personaje principal', por así decirlo."

# game/beyond the bet/day6dlc.rpy:655
translate Spanish day6dlc_start2_a76b23b7:

    # GR "you would be the love interest who cannot help but fall for me."
    GR "tú serías el interés amoroso que no puede evitar enamorarse de mí."

# game/beyond the bet/day6dlc.rpy:658
translate Spanish day6dlc_start2_74798303:

    # player "Well, you've got that last part right, at least."
    player "Bueno, al menos en eso último tienes razón."

# game/beyond the bet/day6dlc.rpy:659
translate Spanish day6dlc_start2_2053f178:

    # GR "h... hey..."
    GR "o... oye..."

# game/beyond the bet/day6dlc.rpy:660
translate Spanish day6dlc_start2_7169bcdf:

    # GR "you should not tease me so."
    GR "no deberías molestarme así."

# game/beyond the bet/day6dlc.rpy:661
translate Spanish day6dlc_start2_a7225ebe:

    # GR "lest i take your soul ahead of time."
    GR "no sea que te quite el alma antes de tiempo."

# game/beyond the bet/day6dlc.rpy:664
translate Spanish day6dlc_start2_bc142f37:

    # player "Honestly, I'm starting to think you can't take it."
    player "Sinceramente, empiezo a pensar que no aguantas mis provocaciones."

# game/beyond the bet/day6dlc.rpy:667
translate Spanish day6dlc_start2_b00d7ef0:

    # player "You like me too much."
    player "Te gusto demasiado."

# game/beyond the bet/day6dlc.rpy:668
translate Spanish day6dlc_start2_7772a27d_13:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:671
translate Spanish day6dlc_start2_00d24de5:

    # player "I dunno, I feel like Jeremy could be the MC..."
    player "No sé, siento que Jeremy podría ser el personaje principal..."

# game/beyond the bet/day6dlc.rpy:672
translate Spanish day6dlc_start2_3f316003:

    # GR "enough about jeremy!"
    GR "¡basta de jeremy!"

# game/beyond the bet/day6dlc.rpy:673
translate Spanish day6dlc_start2_458b6098:

    # GR "i will deal with him on my own time."
    GR "me ocuparé de él a su debido tiempo."

# game/beyond the bet/day6dlc.rpy:674
translate Spanish day6dlc_start2_1d04b331:

    # GR "you should forget him immediately."
    GR "deberías olvidarlo de inmediato."

# game/beyond the bet/day6dlc.rpy:677
translate Spanish day6dlc_start2_04a533c5:

    # player "Yessir."
    player "Sí, señor."

# game/beyond the bet/day6dlc.rpy:680
translate Spanish day6dlc_start2_0121fb11:

    # player "Don't worry, Grimmy, you're the only one for me <3"
    player "No te preocupes, Parquita, eres el único para mí <3"

# game/beyond the bet/day6dlc.rpy:681
translate Spanish day6dlc_start2_7772a27d_14:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:685
translate Spanish day6dlc_start2_33b629ad:

    # player "Jeremy pulls it off better than you, tbh."
    player "Jeremy lo hace mejor que tú, la verdad."

# game/beyond the bet/day6dlc.rpy:686
translate Spanish day6dlc_start2_00d403c1:

    # GR "that is not true."
    GR "eso no es cierto."

# game/beyond the bet/day6dlc.rpy:687
translate Spanish day6dlc_start2_860eec0c:

    # GR "you take that back."
    GR "retráctate."

# game/beyond the bet/day6dlc.rpy:690
translate Spanish day6dlc_start2_3994d0cd:

    # player "Hmmm..."
    player "Mmm..."

# game/beyond the bet/day6dlc.rpy:693
translate Spanish day6dlc_start2_82b1c2ac:

    # player "Make me :D"
    player "Oblígame :D"

# game/beyond the bet/day6dlc.rpy:694
translate Spanish day6dlc_start2_e9551854:

    # GR "and how am I supposed to do that..."
    GR "¿y cómo se supone que haga eso...?"

# game/beyond the bet/day6dlc.rpy:697
translate Spanish day6dlc_start2_83c4cd46:

    # player "Promise to bring me flowers again."
    player "Prométeme que volverás a traerme flores."

# game/beyond the bet/day6dlc.rpy:698
translate Spanish day6dlc_start2_52a07a64:

    # GR "...well."
    GR "...bueno."

# game/beyond the bet/day6dlc.rpy:699
translate Spanish day6dlc_start2_59c96791:

    # GR "that is a given, sunshine. i will happily bring you flowers again."
    GR "eso ni se discute, solecito. con gusto te traeré flores otra vez."

# game/beyond the bet/day6dlc.rpy:702
translate Spanish day6dlc_start2_01dfecf1:

    # player "Yippeeee!"
    player "¡Yupiii!"

# game/beyond the bet/day6dlc.rpy:704
translate Spanish day6dlc_start2_a5f08fc7:

    # player "Score."
    player "Genial."

# game/beyond the bet/day6dlc.rpy:709
translate Spanish day6dlc_start2_a04a5246:

    # player "Jeremy isn't real, by the way."
    player "Por cierto, Jeremy no existe."

# game/beyond the bet/day6dlc.rpy:710
translate Spanish day6dlc_start2_8ede3c01_1:

    # GR "what?"
    GR "¿qué?"

# game/beyond the bet/day6dlc.rpy:713
translate Spanish day6dlc_start2_ec63d7e3:

    # player "I tricked you. My bad."
    player "Te engañé. Mi error."

# game/beyond the bet/day6dlc.rpy:716
translate Spanish day6dlc_start2_6b4c3a46:

    # player "You just make it so easy."
    player "Es que me lo pones tan fácil."

# game/beyond the bet/day6dlc.rpy:719
translate Spanish day6dlc_start2_471c67a1:

    # player "You get so jealous!"
    player "¡Te pones tan celoso!"

# game/beyond the bet/day6dlc.rpy:720
translate Spanish day6dlc_start2_2d70b5dc:

    # GR "i... i do not get that jealous!"
    GR "yo... ¡no me pongo tan celoso!"

# game/beyond the bet/day6dlc.rpy:723
translate Spanish day6dlc_start2_fed82fa6:

    # player "You do."
    player "Claro que sí."

# game/beyond the bet/day6dlc.rpy:726
translate Spanish day6dlc_start2_4ed964db:

    # player "Maybe you really like me?"
    player "¿Quizá de verdad te gusto?"

# game/beyond the bet/day6dlc.rpy:727
translate Spanish day6dlc_start2_cc21bd84:

    # GR "!!!"
    GR "!!!"

# game/beyond the bet/day6dlc.rpy:728
translate Spanish day6dlc_start2_3d61a1da:

    # GR "do not be absurd!"
    GR "¡no seas absurd[letra]!"

# game/beyond the bet/day6dlc.rpy:729
translate Spanish day6dlc_start2_463ad3ec:

    # GR "a grim reaper and a mortal? that would be beyond sinful!"
    GR "¿una parca y un mortal? ¡eso sería más que pecaminoso!"

# game/beyond the bet/day6dlc.rpy:732
translate Spanish day6dlc_start2_5f597bf5:

    # player "Then call me a sinner, baby."
    player "Entonces llámame [pecador], cariño."

# game/beyond the bet/day6dlc.rpy:733
translate Spanish day6dlc_start2_dd45d39a:

    # GR "...you are ridiculous."
    GR "...eres ridícul[letra]."

# game/beyond the bet/day6dlc.rpy:736
translate Spanish day6dlc_start2_b4f2a3a0:

    # player "That I am, Grimmy. That I am."
    player "Así es, Parquita. Así es."

# game/beyond the bet/day6dlc.rpy:741
translate Spanish day6dlc_start2_49bdba19:

    # player "Maybe it's YOU with the 'being bullied' kink."
    player "Quizá el del fetiche de 'que se metan contigo' eres TÚ."

# game/beyond the bet/day6dlc.rpy:744
translate Spanish day6dlc_start2_346d92a9:

    # player "I'm not judging. If anything, it shows we're super compatible ;)"
    player "No te juzgo. Al contrario, demuestra que somos súper compatibles ;)"

# game/beyond the bet/day6dlc.rpy:745
translate Spanish day6dlc_start2_c30211c0_1:

    # GR "i..."
    GR "yo..."

# game/beyond the bet/day6dlc.rpy:746
translate Spanish day6dlc_start2_8feec8d5:

    # GR "to be totally honest, i feel as if you have uncovered a new part of me."
    GR "para ser totalmente sincero, siento que has descubierto una parte nueva de mí."

# game/beyond the bet/day6dlc.rpy:749
translate Spanish day6dlc_start2_8ae5d473:

    # player "Wait, you agree?"
    player "Espera, ¿estás de acuerdo?"

# game/beyond the bet/day6dlc.rpy:752
translate Spanish day6dlc_start2_124da5c1:

    # player "I was joking!"
    player "¡Estaba bromeando!"

# game/beyond the bet/day6dlc.rpy:753
translate Spanish day6dlc_start2_ce8fbf1e:

    # GR "per... perhaps i enjoy it somewhat..."
    GR "qui... quizá lo disfrute un poco..."

# game/beyond the bet/day6dlc.rpy:754
translate Spanish day6dlc_start2_919473a4:

    # GR "you are the only one in the history of my existence to treat me like... this."
    GR "eres la única persona en toda la historia de mi existencia que me trata así..."

# game/beyond the bet/day6dlc.rpy:755
translate Spanish day6dlc_start2_73bec301:

    # GR "or like anything but someone to be feared."
    GR "o que me ha tratado como algo más que alguien a quien temer."

# game/beyond the bet/day6dlc.rpy:756
translate Spanish day6dlc_start2_bb63e087:

    # GR "i mean, i am someone to be feared!"
    GR "¡quiero decir, soy alguien a quien temer!"

# game/beyond the bet/day6dlc.rpy:757
translate Spanish day6dlc_start2_9f5c15b5:

    # GR "but.... mayhaps this is not too bad, either..."
    GR "pero.... quizá esto tampoco esté tan mal..."

# game/beyond the bet/day6dlc.rpy:758
translate Spanish day6dlc_start2_3ac10be8:

    # GR "so... no! i will not agree that i have a mortal 'kink' for it, sunshine."
    GR "así que... ¡no! no admitiré que tengo un 'fetiche' mortal por eso, solecito."

# game/beyond the bet/day6dlc.rpy:759
translate Spanish day6dlc_start2_4f8af1aa:

    # GR "but it is refreshing."
    GR "pero es refrescante."

# game/beyond the bet/day6dlc.rpy:762
translate Spanish day6dlc_start2_db0f7b2e:

    # player "This was way more honesty than I was expecting."
    player "No esperaba tanta sinceridad."

# game/beyond the bet/day6dlc.rpy:765
translate Spanish day6dlc_start2_beaf2f7d:

    # player "I am astounded rn."
    player "Estoy atónit[letra] ahora mismo."

# game/beyond the bet/day6dlc.rpy:768
translate Spanish day6dlc_start2_af3f6c3b:

    # player "I guess that's permission to keep on teasin', then."
    player "Supongo que entonces tengo permiso para seguir molestándote."

# game/beyond the bet/day6dlc.rpy:770
translate Spanish day6dlc_start2_780432f2:

    # player "Well, I don't plan to stop anytime soon :D"
    player "Bueno, no pienso parar pronto :D"

# game/beyond the bet/day6dlc.rpy:773
translate Spanish day6dlc_start2_b68b7e49:

    # player "This arrangement works for me B)"
    player "Este trato me parece perfecto B)"

# game/beyond the bet/day6dlc.rpy:774
translate Spanish day6dlc_start2_2c5c3421:

    # GR "sigh..."
    GR "*suspiro*..."

# game/beyond the bet/day6dlc.rpy:777
translate Spanish day6dlc_start2_f48c8516:

    # player "It's cute, and honestly it's teaching me something new about myself."
    player "Es tierno, y sinceramente me está enseñando algo nuevo sobre mí."

# game/beyond the bet/day6dlc.rpy:780
translate Spanish day6dlc_start2_3177a040:

    # player "Turns out I like flustered babygirls."
    player "Resulta que me gustan las babygirls que se sonrojan fácilmente."

# game/beyond the bet/day6dlc.rpy:781
translate Spanish day6dlc_start2_39bbb782:

    # GR "i am not a 'flustered babygirl'. i am the grim reaper."
    GR "no soy una 'babygirl que se sonroja'. soy la parca."

# game/beyond the bet/day6dlc.rpy:782
translate Spanish day6dlc_start2_b63e5391:

    # GR "do i have to repeat that every single day?"
    GR "¿tengo que repetirlo todos los días?"

# game/beyond the bet/day6dlc.rpy:784
translate Spanish day6dlc_start2_f780e9ad:

    # player "Turns out I have a thing for sexy men that are easily flustered."
    player "Resulta que tengo debilidad por los hombres sexis que se sonrojan fácilmente."

# game/beyond the bet/day6dlc.rpy:785
translate Spanish day6dlc_start2_ee043665:

    # GR "while the sexy part is extremely truthful..."
    GR "aunque lo de sexy es extremadamente cierto..."

# game/beyond the bet/day6dlc.rpy:786
translate Spanish day6dlc_start2_4f468f9b:

    # GR "once again, i am the grim reaper. the grim reaper. a personification of death. evil, bad guy."
    GR "una vez más, soy la parca. la parca. la personificación de la muerte. el malvado, el villano."

# game/beyond the bet/day6dlc.rpy:790
translate Spanish day6dlc_start2_e84cf7ae:

    # player "*A* Grim Reaper."
    player "'Una' Parca."

# game/beyond the bet/day6dlc.rpy:791
translate Spanish day6dlc_start2_23639830:

    # GR "that is beside the point."
    GR "eso es irrelevante."

# game/beyond the bet/day6dlc.rpy:794
translate Spanish day6dlc_start2_bf0cb49c:

    # player "Okay, but you're a grim reaper who, usually, is blushing from ear to ear."
    player "Okey, pero eres una parca que, normalmente, se sonroja hasta las orejas."

# game/beyond the bet/day6dlc.rpy:797
translate Spanish day6dlc_start2_9b0ae81d:

    # player "Are other reapers like that?"
    player "¿Las otras parcas son así?"

# game/beyond the bet/day6dlc.rpy:800
translate Spanish day6dlc_start2_da381636:

    # player "Or are they actually scary?"
    player "¿O en realidad dan miedo?"

# game/beyond the bet/day6dlc.rpy:801
translate Spanish day6dlc_start2_4484e282:

    # GR "i am scary."
    GR "yo doy miedo."

# game/beyond the bet/day6dlc.rpy:802
translate Spanish day6dlc_start2_4484d550:

    # GR "but... well, the other reapers are varied, i suppose."
    GR "pero... bueno, las otras parcas son variadas, supongo."

# game/beyond the bet/day6dlc.rpy:803
translate Spanish day6dlc_start2_30cb5e0f:

    # GR "i do not spend much time with them."
    GR "no paso mucho tiempo con ellas."

# game/beyond the bet/day6dlc.rpy:804
translate Spanish day6dlc_start2_c576043a:

    # GR "but they are similar to mortals in ways. all with their own quirks and annoyances."
    GR "pero se parecen a los mortales en algunos aspectos. todas con sus manías y fastidios."

# game/beyond the bet/day6dlc.rpy:807
translate Spanish day6dlc_start2_33be17d2:

    # player "Are there more hot guys?"
    player "¿Hay más tipos guapos?"

# game/beyond the bet/day6dlc.rpy:808
translate Spanish day6dlc_start2_960e1c1a:

    # GR "more?"
    GR "¿más?"

# game/beyond the bet/day6dlc.rpy:811
translate Spanish day6dlc_start2_1907ab81:

    # player "Well, let's be honest, you are very good looking."
    player "Bueno, seamos sinceros, eres muy guapo."

# game/beyond the bet/day6dlc.rpy:812
translate Spanish day6dlc_start2_c6545757:

    # GR "well, at least you notice that much."
    GR "bueno, al menos eso lo notas."

# game/beyond the bet/day6dlc.rpy:815
translate Spanish day6dlc_start2_5e5137bd:

    # player "So, are there more?"
    player "Entonces, ¿hay más?"

# game/beyond the bet/day6dlc.rpy:817
translate Spanish day6dlc_start2_80b5031e:

    # player "Putting you aside, there must be others too."
    player "Aparte de ti, seguro que hay otros."

# game/beyond the bet/day6dlc.rpy:818
translate Spanish day6dlc_start2_7772a27d_15:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:819
translate Spanish day6dlc_start2_a2abc575:

    # GR "none as good looking as me."
    GR "ninguno tan guapo como yo."

# game/beyond the bet/day6dlc.rpy:822
translate Spanish day6dlc_start2_2fb4d59d:

    # player "Well, of course."
    player "Claro, por supuesto."

# game/beyond the bet/day6dlc.rpy:824
translate Spanish day6dlc_start2_0f6112a8:

    # player "You're cocky, but not wrong."
    player "Eres engreído, pero no te equivocas."

# game/beyond the bet/day6dlc.rpy:827
translate Spanish day6dlc_start2_f26c8cb6:

    # player "But even someone a tiny less hot than you would be pretty hot."
    player "Pero incluso alguien un poquito menos guapo que tú sería bastante guapo."

# game/beyond the bet/day6dlc.rpy:828
translate Spanish day6dlc_start2_ce9f1dd5:

    # GR "they are average."
    GR "son del montón."

# game/beyond the bet/day6dlc.rpy:831
translate Spanish day6dlc_start2_67c5693e:

    # player "So, no other reapers ever caught your eye?"
    player "Entonces, ¿ninguna otra parca te llamó la atención?"

# game/beyond the bet/day6dlc.rpy:832
translate Spanish day6dlc_start2_5d364529:

    # GR "no."
    GR "no."

# game/beyond the bet/day6dlc.rpy:833
translate Spanish day6dlc_start2_28bc9a1c:

    # GR "i have no interest in any of them."
    GR "no me interesa ninguna."

# game/beyond the bet/day6dlc.rpy:834
translate Spanish day6dlc_start2_f5868cc4:

    # GR "perhaps they look fine, but we all have an aura of death."
    GR "quizá se vean bien, pero todos tenemos un aura de muerte."

# game/beyond the bet/day6dlc.rpy:835
translate Spanish day6dlc_start2_91669fee:

    # GR "i find great solace in death, you know."
    GR "encuentro gran consuelo en la muerte, ¿sabes?"

# game/beyond the bet/day6dlc.rpy:836
translate Spanish day6dlc_start2_ff4af82f:

    # GR "but, well, it is sometimes depressing."
    GR "pero, bueno, a veces resulta deprimente."

# game/beyond the bet/day6dlc.rpy:839
translate Spanish day6dlc_start2_42e87e41:

    # player "Is that why you like me so much?"
    player "¿Por eso te gusto tanto?"

# game/beyond the bet/day6dlc.rpy:840
translate Spanish day6dlc_start2_7772a27d_16:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:841
translate Spanish day6dlc_start2_19ca6c42:

    # GR "maybe."
    GR "quizá."

# game/beyond the bet/day6dlc.rpy:842
translate Spanish day6dlc_start2_18cebd1e:

    # GR "maybe one would think that you are very likeable because of your cheery personality and kind heart."
    GR "quizá uno pensaría que eres muy agradable por tu personalidad alegre y tu buen corazón."

# game/beyond the bet/day6dlc.rpy:843
translate Spanish day6dlc_start2_9dfb3c27:

    # GR "but maybe that's not true. who knows."
    GR "pero quizá eso no sea cierto. quién sabe."

# game/beyond the bet/day6dlc.rpy:846
translate Spanish day6dlc_start2_388d6ed4:

    # player "Something tells me the guy who can't lie thinks I have a kind heart <3"
    player "Algo me dice que el tipo que no puede mentir cree que tengo buen corazón <3"

# game/beyond the bet/day6dlc.rpy:847
translate Spanish day6dlc_start2_fd966e13:

    # GR "yeah yeah..."
    GR "sí, sí..."

# game/beyond the bet/day6dlc.rpy:850
translate Spanish day6dlc_start2_0db6e885:

    # player "Any pretty ladies?"
    player "¿Alguna chica bonita?"

# game/beyond the bet/day6dlc.rpy:851
translate Spanish day6dlc_start2_8ede3c01_2:

    # GR "what?"
    GR "¿qué?"

# game/beyond the bet/day6dlc.rpy:854
translate Spanish day6dlc_start2_d2d8487d:

    # player "I'm just wondering..."
    player "Solo tenía curiosidad..."

# game/beyond the bet/day6dlc.rpy:855
translate Spanish day6dlc_start2_c30211c0_2:

    # GR "i..."
    GR "yo..."

# game/beyond the bet/day6dlc.rpy:856
translate Spanish day6dlc_start2_f689f85e:

    # GR "i suppose?"
    GR "¿supongo?"

# game/beyond the bet/day6dlc.rpy:857
translate Spanish day6dlc_start2_49c3ac13:

    # GR "i do not pay them much mind. i keep to myself."
    GR "no les presto mucha atención. me mantengo aparte."

# game/beyond the bet/day6dlc.rpy:858
translate Spanish day6dlc_start2_32e498cd:

    # GR "you are far more pleasing to the eye."
    GR "tú eres mucho más agradable a la vista."

# game/beyond the bet/day6dlc.rpy:861
translate Spanish day6dlc_start2_0ff2f063:

    # player ":O"
    player ":O"

# game/beyond the bet/day6dlc.rpy:864
translate Spanish day6dlc_start2_b26999c7:

    # player "I am???"
    player "¿¿¿YO???"

# game/beyond the bet/day6dlc.rpy:865
translate Spanish day6dlc_start2_77abb79b:

    # GR "...forget it."
    GR "...olvídalo."

# game/beyond the bet/day6dlc.rpy:868
translate Spanish day6dlc_start2_2fab8f5f:

    # player "Grim thinks I'm pleasing to the eye :D "
    player "A Parca le parezco agradable a la vista :D"

# game/beyond the bet/day6dlc.rpy:869
translate Spanish day6dlc_start2_d89d0c4f:

    # GR "forget it!"
    GR "¡olvídalo!"

# game/beyond the bet/day6dlc.rpy:872
translate Spanish day6dlc_start2_f4eef4b9:

    # player "I will definitely remember this forever."
    player "Definitivamente lo recordaré para siempre."

# game/beyond the bet/day6dlc.rpy:875
translate Spanish day6dlc_start2_80ae27d7:

    # player "Forget what? What are we talking about?"
    player "¿Olvidar qué? ¿De qué estamos hablando?"

# game/beyond the bet/day6dlc.rpy:876
translate Spanish day6dlc_start2_7772a27d_17:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:877
translate Spanish day6dlc_start2_50327172:

    # GR "well, i am glad you have forgotten so quickly."
    GR "bueno, me alegra que lo hayas olvidado tan rápido."

# game/beyond the bet/day6dlc.rpy:880
translate Spanish day6dlc_start2_e82c701c:

    # player "Definitely, totally, completely forgotten. Yup."
    player "Definitivamente, totalmente, completamente olvidado. Sip."

# game/beyond the bet/day6dlc.rpy:883
translate Spanish day6dlc_start2_4bbda1bb:

    # player "How flippin' weird, huh?"
    player "Qué raro, ¿no?"

# game/beyond the bet/day6dlc.rpy:886
translate Spanish day6dlc_start2_fbc0c488:

    # player "Big ol' blank space in my brain."
    player "Un gran espacio en blanco en mi cerebro."

# game/beyond the bet/day6dlc.rpy:887
translate Spanish day6dlc_start2_0d84c375:

    # GR "...i shall just pretend that you are not lying through your teeth right now."
    GR "...fingiré que no me estás mintiendo descaradamente en la cara ahora mismo."

# game/beyond the bet/day6dlc.rpy:890
translate Spanish day6dlc_start2_38437647:

    # player "My keyboard, but yes!"
    player "¡En la cara no, por teclado, pero sí!"

# game/beyond the bet/day6dlc.rpy:891
translate Spanish day6dlc_start2_7772a27d_18:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:892
translate Spanish day6dlc_start2_d39a3696:

    # GR "...i feel as if i will not live this down."
    GR "...siento que no lo superaré."

# game/beyond the bet/day6dlc.rpy:893
translate Spanish day6dlc_start2_afc5f4a4:

    # GR "you will keep bringing this up to me for as long as you exist."
    GR "me lo seguirás sacando en cara mientras tú existas."

# game/beyond the bet/day6dlc.rpy:896
translate Spanish day6dlc_start2_2b9eca44:

    # player "How could I not?"
    player "¿Cómo no iba a hacerlo?"

# game/beyond the bet/day6dlc.rpy:899
translate Spanish day6dlc_start2_76cb3cdc:

    # player "It's now one of my greatest achievements."
    player "Ahora es uno de mis mayores logros."

# game/beyond the bet/day6dlc.rpy:902
translate Spanish day6dlc_start2_0609f689:

    # player "Oh!"
    player "¡Oh!"

# game/beyond the bet/day6dlc.rpy:905
translate Spanish day6dlc_start2_9355f0c0:

    # player "Hey, Grim!"
    player "¡Oye, Parca!"

# game/beyond the bet/day6dlc.rpy:908
translate Spanish day6dlc_start2_baae82fb:

    # player "When you take my soul, can you get me one of those little ads in the newspaper?"
    player "Cuando me quites el alma, ¿puedes conseguirme uno de esos avisos fúnebres en el periódico?"

# game/beyond the bet/day6dlc.rpy:912
translate Spanish day6dlc_start2_c152a01a:

    # player "Like, '[playerfirstname], gone but not forgotten'?"
    player "¿Algo como '[playerfirstname], se fue, pero no será olvidad[letra]'?"

# game/beyond the bet/day6dlc.rpy:915
translate Spanish day6dlc_start2_206e2e51:

    # player "But instead, write 'the Grim Reaper found [her] too pleasing to the eye'."
    player "Pero en vez de eso, escribe 'La Parca encontró a [playerfirstname] demasiado agradable a la vista'."

# game/beyond the bet/day6dlc.rpy:918
translate Spanish day6dlc_start2_6b340211:

    # player "That'll sound metal AF."
    player "Eso sonará súper metalero."

# game/beyond the bet/day6dlc.rpy:919
translate Spanish day6dlc_start2_88c033e9:

    # GR "'[playerfirstname!l], taken to be the Grim Reaper's eternal spouse'."
    GR "'[playerfirstname!l], convertid[letra] en [arti] [wife] etern[letra] de la Parca'."

# game/beyond the bet/day6dlc.rpy:922
translate Spanish day6dlc_start2_c87c129a:

    # player "WOAH!"
    player "¡UY!"

# game/beyond the bet/day6dlc.rpy:925
translate Spanish day6dlc_start2_6c642e57:

    # player "That sounds even cooler!"
    player "¡Eso suena todavía mejor!"

# game/beyond the bet/day6dlc.rpy:928
translate Spanish day6dlc_start2_aaab5a66:

    # player "Wait, is that why you're after my soul?"
    player "Espera, ¿por eso vas tras mi alma?"

# game/beyond the bet/day6dlc.rpy:929
translate Spanish day6dlc_start2_fe5ce676:

    # GR "no!"
    GR "¡no!"

# game/beyond the bet/day6dlc.rpy:930
translate Spanish day6dlc_start2_0012c708:

    # GR "you would not end up here, in the underworld, anyway."
    GR "de todas formas, no terminarías aquí, en el inframundo."

# game/beyond the bet/day6dlc.rpy:933
translate Spanish day6dlc_start2_d114a803:

    # player "Where would I end up?"
    player "¿Dónde terminaría?"

# game/beyond the bet/day6dlc.rpy:934
translate Spanish day6dlc_start2_fc8fc1bb:

    # GR "that is not for me to judge."
    GR "eso no me corresponde juzgarlo."

# game/beyond the bet/day6dlc.rpy:937
translate Spanish day6dlc_start2_6428dcfc:

    # player "Come on, give me some examples."
    player "Anda, dame algunos ejemplos."

# game/beyond the bet/day6dlc.rpy:938
translate Spanish day6dlc_start2_ce3869bd:

    # GR "there are more afterlives than i would be able to count."
    GR "hay más tipos de vida después de la muerte de los que podría contar."

# game/beyond the bet/day6dlc.rpy:939
translate Spanish day6dlc_start2_16f6a0b8:

    # GR "that is a problem for someone paid much more than me to work out."
    GR "ese es un problema para que lo resuelva alguien a quien le pagan mucho más que a mí."

# game/beyond the bet/day6dlc.rpy:942
translate Spanish day6dlc_start2_e505c5f5:

    # player "You get paid for your work?"
    player "¿Te pagan por tu trabajo?"

# game/beyond the bet/day6dlc.rpy:943
translate Spanish day6dlc_start2_ebc9eb7a:

    # GR "yes."
    GR "sí."

# game/beyond the bet/day6dlc.rpy:944
translate Spanish day6dlc_start2_be1df9f6:

    # GR "it would be illegal otherwise."
    GR "de lo contrario sería ilegal."

# game/beyond the bet/day6dlc.rpy:947
translate Spanish day6dlc_start2_7f151097:

    # player "So, the underworld has its own set of laws?"
    player "¿Entonces el inframundo tiene sus propias leyes?"

# game/beyond the bet/day6dlc.rpy:948
translate Spanish day6dlc_start2_aced07d8:

    # GR "of course."
    GR "por supuesto."

# game/beyond the bet/day6dlc.rpy:951
translate Spanish day6dlc_start2_a048c159:

    # player "So you get paid, but you can't quit?"
    player "¿Entonces te pagan, pero no puedes renunciar?"

# game/beyond the bet/day6dlc.rpy:952
translate Spanish day6dlc_start2_feec4b51:

    # GR "correct."
    GR "correcto."

# game/beyond the bet/day6dlc.rpy:953
translate Spanish day6dlc_start2_3220dcfb:

    # GR "if i were to attempt to quit, i would likely just be disposed of."
    GR "si intentara renunciar, probablemente me desecharían."

# game/beyond the bet/day6dlc.rpy:954
translate Spanish day6dlc_start2_9e62ec07:

    # GR "reapers exist solely for harvesting souls. there is no quitting."
    GR "las parcas existen únicamente para cosechar almas. no se puede renunciar."

# game/beyond the bet/day6dlc.rpy:957
translate Spanish day6dlc_start2_dc728ed8:

    # player "That's really sad."
    player "Qué triste."

# game/beyond the bet/day6dlc.rpy:959
translate Spanish day6dlc_start2_a240aa80:

    # player "It kinda sounds messed up."
    player "Suena un poco retorcido."

# game/beyond the bet/day6dlc.rpy:962
translate Spanish day6dlc_start2_db609903:

    # player "I think you should complain to your manager."
    player "Creo que deberías quejarte con tu jefe."

# game/beyond the bet/day6dlc.rpy:963
translate Spanish day6dlc_start2_9fd9a76d:

    # GR "why?"
    GR "¿por qué?"

# game/beyond the bet/day6dlc.rpy:964
translate Spanish day6dlc_start2_f6709729:

    # GR "there is little point. in the thousands upon thousands of years of our organization, little has changed." id day6dlc_start2_f6709729
    GR "tiene poco sentido. en los miles y miles de años de nuestra organización, poco ha cambiado." id day6dlc_start2_f6709729

# game/beyond the bet/day6dlc.rpy:965
translate Spanish day6dlc_start2_1f5ff4fc:

    # GR "nothing will change simply because i complain a little."
    GR "nada cambiará solo porque me queje un poco."

# game/beyond the bet/day6dlc.rpy:968
translate Spanish day6dlc_start2_8833e6de:

    # player "But isn't there more you want to do with your life?"
    player "Pero ¿no hay algo más que quieras hacer con tu vida?"

# game/beyond the bet/day6dlc.rpy:969
translate Spanish day6dlc_start2_460c4fb2:

    # GR "like?"
    GR "¿como qué?"

# game/beyond the bet/day6dlc.rpy:972
translate Spanish day6dlc_start2_76b1950a:

    # player "Me?"
    player "¿Yo?"

# game/beyond the bet/day6dlc.rpy:973
translate Spanish day6dlc_start2_c4742559:

    # GR "you???"
    GR "¿¿¿tú???"

# game/beyond the bet/day6dlc.rpy:976
translate Spanish day6dlc_start2_274d53a7:

    # player "That's what I said."
    player "Eso es lo que dije."

# game/beyond the bet/day6dlc.rpy:977
translate Spanish day6dlc_start2_14774a80:

    # GR "........"
    GR "........"

# game/beyond the bet/day6dlc.rpy:978
translate Spanish day6dlc_start2_aa962dbe:

    # GR "your mind is wandering again into fantasy, mortal."
    GR "tu mente vuelve a divagar hacia la fantasía, mortal."

# game/beyond the bet/day6dlc.rpy:981
translate Spanish day6dlc_start2_cf11310f:

    # player "Come on, wander a bit with me!"
    player "¡Vamos, divaga un poco conmigo!"

# game/beyond the bet/day6dlc.rpy:982
translate Spanish day6dlc_start2_14774a80_1:

    # GR "........"
    GR "........"

# game/beyond the bet/day6dlc.rpy:983
translate Spanish day6dlc_start2_ca667329:

    # GR "that... i would like very much... ahem..."
    GR "eso... me gustaría mucho... ejem..."

# game/beyond the bet/day6dlc.rpy:984
translate Spanish day6dlc_start2_3107290c:

    # GR "what i mean to say is... is that's not a discussion for now...."
    GR "lo que quiero decir es... es que esa no es una conversación para ahora...."

# game/beyond the bet/day6dlc.rpy:987
translate Spanish day6dlc_start2_65f14387:

    # player "Well, hey, it's not a no."
    player "Bueno, oye, no es un no."

# game/beyond the bet/day6dlc.rpy:988
translate Spanish day6dlc_start2_3eeb2614:

    # GR "sunshine, you... you're killing me here."
    GR "solecito, tú... tú me estás matando."

# game/beyond the bet/day6dlc.rpy:991
translate Spanish day6dlc_start2_13a78bc4:

    # player "That's only fair, seeing as you're trying to kill me, too."
    player "Es justo, ya que tú también estás intentando matarme."

# game/beyond the bet/day6dlc.rpy:994
translate Spanish day6dlc_start2_e1e7650c:

    # player "Might as well go out with a 'bang'."
    player "Más vale irme con broche de oro."

# game/beyond the bet/day6dlc.rpy:995
translate Spanish day6dlc_start2_58e78576:

    # GR "................."
    GR "................."

# game/beyond the bet/day6dlc.rpy:998
translate Spanish day6dlc_start2_add9c150:

    # player "You blushing again?"
    player "¿Te sonrojaste otra vez?"

# game/beyond the bet/day6dlc.rpy:999
translate Spanish day6dlc_start2_0ffba3be:

    # GR "MAYBE. MAYBE NOT."
    GR "QUIZÁ. QUIZÁ NO."

# game/beyond the bet/day6dlc.rpy:1002
translate Spanish day6dlc_start2_649fd383:

    # player "You really are so cute."
    player "De verdad eres tan lindo."

# game/beyond the bet/day6dlc.rpy:1004
translate Spanish day6dlc_start2_1ec687d1:

    # player "God I love you."
    player "Dios, te amo."

# game/beyond the bet/day6dlc.rpy:1005
translate Spanish day6dlc_start2_771282ed:

    # GR "WHAT?"
    GR "¿¡QUÉ!?"

# game/beyond the bet/day6dlc.rpy:1009
translate Spanish day6dlc_start2_d74dc9a6:

    # player "You're hilariously stupid. I love that about you."
    player "Eres ridículamente tonto. Eso me encanta de ti."

# game/beyond the bet/day6dlc.rpy:1011
translate Spanish day6dlc_start2_68c56f4e:

    # GR "oh... that is what you meant........"
    GR "oh... eso era a lo que te referías........"

# game/beyond the bet/day6dlc.rpy:1012
translate Spanish day6dlc_start2_a3948957:

    # GR "right."
    GR "claro."

# game/beyond the bet/day6dlc.rpy:1013
translate Spanish day6dlc_start2_a484d1f8:

    # GR "i understood that immediately."
    GR "lo entendí de inmediato."

# game/beyond the bet/day6dlc.rpy:1014
translate Spanish day6dlc_start2_0b16bee0_1:

    # GR "ahem."
    GR "ejem."

# game/beyond the bet/day6dlc.rpy:1019
translate Spanish day6dlc_start2_945fba02:

    # player "See the world?"
    player "¿Ver el mundo?"

# game/beyond the bet/day6dlc.rpy:1020
translate Spanish day6dlc_start2_0883a50b:

    # GR "i see plenty of the world in this job, mortal."
    GR "veo bastante del mundo en este trabajo, mortal."

# game/beyond the bet/day6dlc.rpy:1021
translate Spanish day6dlc_start2_a3c6ef40:

    # GR "more than you see, i imagine."
    GR "más de lo que tú ves, imagino."

# game/beyond the bet/day6dlc.rpy:1024
translate Spanish day6dlc_start2_a0a86a50:

    # player "It's not a competition."
    player "No es una competencia."

# game/beyond the bet/day6dlc.rpy:1025
translate Spanish day6dlc_start2_6400dc10:

    # GR "that's fortunate for you, then."
    GR "qué suerte para ti, entonces."

# game/beyond the bet/day6dlc.rpy:1026
translate Spanish day6dlc_start2_e0d31755:

    # GR "if it were a competition, then i would be winning."
    GR "si lo fuera, yo estaría ganando."

# game/beyond the bet/day6dlc.rpy:1027
translate Spanish day6dlc_start2_6cbe8b45:

    # GR "i do not lose, after all."
    GR "yo no pierdo, después de todo."

# game/beyond the bet/day6dlc.rpy:1030
translate Spanish day6dlc_start2_c49b092c:

    # player "Except when it comes to bets against a certain [pretty] [girl] over [her2] soul."
    player "Excepto cuando se trata de las apuestas contra [arti_2] [girl!t] [pretty!t] por su alma."

# game/beyond the bet/day6dlc.rpy:1033
translate Spanish day6dlc_start2_f3567f50:

    # player "You're not too good at winning those."
    player "No se te da muy bien ganarlas."

# game/beyond the bet/day6dlc.rpy:1034
translate Spanish day6dlc_start2_d81bba2f:

    # GR "that is false."
    GR "eso es falso."

# game/beyond the bet/day6dlc.rpy:1035
translate Spanish day6dlc_start2_64213775:

    # GR "i still have today and tomorrow."
    GR "todavía tengo hoy y mañana."

# game/beyond the bet/day6dlc.rpy:1038
translate Spanish day6dlc_start2_e182e967:

    # player "Let's be real with each other, Grimmy."
    player "Seamos realistas, Parquita."

# game/beyond the bet/day6dlc.rpy:1041
translate Spanish day6dlc_start2_72a35be9:

    # player "You're struggling."
    player "Estás teniendo problemas."

# game/beyond the bet/day6dlc.rpy:1042
translate Spanish day6dlc_start2_8269ed67:

    # GR "i could take it at any time."
    GR "podría tomarla en cualquier momento."

# game/beyond the bet/day6dlc.rpy:1045
translate Spanish day6dlc_start2_bfc0009a:

    # player "Come do it now."
    player "Hazlo ahora."

# game/beyond the bet/day6dlc.rpy:1046
translate Spanish day6dlc_start2_7772a27d_19:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:1047
translate Spanish day6dlc_start2_5d364529_1:

    # GR "no."
    GR "no."

# game/beyond the bet/day6dlc.rpy:1050
translate Spanish day6dlc_start2_888ecc42:

    # player "Why not?"
    player "¿Por qué no?"

# game/beyond the bet/day6dlc.rpy:1051
translate Spanish day6dlc_start2_f84084b9:

    # GR "i am busy."
    GR "estoy ocupado."

# game/beyond the bet/day6dlc.rpy:1054
translate Spanish day6dlc_start2_90afb255:

    # player "With?"
    player "¿Con qué?"

# game/beyond the bet/day6dlc.rpy:1055
translate Spanish day6dlc_start2_80d2b4f8:

    # GR "things that do not concern you."
    GR "cosas que no te incumben."

# game/beyond the bet/day6dlc.rpy:1058
translate Spanish day6dlc_start2_ca7fccea:

    # player "If those things are delaying my death, I'd say they concern me."
    player "Si esas cosas retrasan mi muerte, diría que sí me incumben."

# game/beyond the bet/day6dlc.rpy:1059
translate Spanish day6dlc_start2_82794a5e:

    # GR "do you miss me so badly?"
    GR "¿tanto me extrañas?"

# game/beyond the bet/day6dlc.rpy:1062
translate Spanish day6dlc_start2_d91603ea:

    # player "Maybe a little."
    player "Quizá un poco."

# game/beyond the bet/day6dlc.rpy:1064
translate Spanish day6dlc_start2_b7c27874:

    # player "Yeah, a lot."
    player "Sí, mucho."

# game/beyond the bet/day6dlc.rpy:1067
translate Spanish day6dlc_start2_8c3ac9e9:

    # player "I enjoyed seeing you yesterday, Mister Big Scary Grim Reaper."
    player "Disfruté verte ayer, Señor Parca Grande y Aterrador."

# game/beyond the bet/day6dlc.rpy:1070
translate Spanish day6dlc_start2_4070cb75:

    # player "TBH I even surprise myself admitting that."
    player "La verdad es que hasta me sorprende admitirlo."

# game/beyond the bet/day6dlc.rpy:1073
translate Spanish day6dlc_start2_35c22d1c:

    # player "A few days ago I thought you were a scammer."
    player "Hace unos días pensaba que eras un estafador."

# game/beyond the bet/day6dlc.rpy:1076
translate Spanish day6dlc_start2_a5aeb6f3:

    # player "And then you go ahead and sweep me off my feet with a bouquet of sunflowers."
    player "Y luego vas y me haces perder la cabeza con un ramo de girasoles."

# game/beyond the bet/day6dlc.rpy:1077
translate Spanish day6dlc_start2_6c7b4fc1:

    # GR "...it wasn't about sweeping you off your feet."
    GR "...no se trataba de hacerte perder la cabeza."

# game/beyond the bet/day6dlc.rpy:1078
translate Spanish day6dlc_start2_7e7fbd55:

    # GR "you just deserve flowers."
    GR "solo mereces flores."

# game/beyond the bet/day6dlc.rpy:1079
translate Spanish day6dlc_start2_6a714639:

    # GR "truly, you deserve much more, but..."
    GR "en verdad mereces mucho más, pero..."

# game/beyond the bet/day6dlc.rpy:1080
translate Spanish day6dlc_start2_22c4cd8f:

    # GR "i am not the one who should give you more."
    GR "yo no soy quien debería darte más."

# game/beyond the bet/day6dlc.rpy:1081
translate Spanish day6dlc_start2_30cc41a2:

    # GR "even if that angers me to admit. "
    GR "aunque me enfade admitirlo."

# game/beyond the bet/day6dlc.rpy:1082
translate Spanish day6dlc_start2_7c2efcf9:

    # GR "no one else deserves to hold your gaze. no one else deserves to 'sweep you off your feet'."
    GR "nadie más merece sostenerte la mirada. nadie más merece 'hacerte perder la cabeza'."

# game/beyond the bet/day6dlc.rpy:1085
translate Spanish day6dlc_start2_888ecc42_1:

    # player "Why not?"
    player "¿Por qué no?"

# game/beyond the bet/day6dlc.rpy:1086
translate Spanish day6dlc_start2_4045fa9f:

    # GR "because it should be me."
    GR "porque debería ser yo."

# game/beyond the bet/day6dlc.rpy:1090
translate Spanish day6dlc_start2_bf8d194d:

    # player "That is oddly honest of you."
    player "Eso es curiosamente sincero de tu parte."

# game/beyond the bet/day6dlc.rpy:1093
translate Spanish day6dlc_start2_03775ec8_2:

    # player "..."
    player "..."

# game/beyond the bet/day6dlc.rpy:1095
translate Spanish day6dlc_start2_ea347b40:

    # GR "but it cannot be."
    GR "pero no puede ser."

# game/beyond the bet/day6dlc.rpy:1096
translate Spanish day6dlc_start2_4b902a8c:

    # GR "for we are too different."
    GR "pues somos demasiado distintos."

# game/beyond the bet/day6dlc.rpy:1099
translate Spanish day6dlc_start2_732df6e2:

    # player "I think we're similar in plenty of ways, too."
    player "Creo que también nos parecemos en muchas cosas."

# game/beyond the bet/day6dlc.rpy:1100
translate Spanish day6dlc_start2_460c4fb2_1:

    # GR "like?"
    GR "¿como qué?"

# game/beyond the bet/day6dlc.rpy:1103
translate Spanish day6dlc_start2_c5fd2a95:

    # player "We're both animal lovers."
    player "Los dos amamos a los animales."

# game/beyond the bet/day6dlc.rpy:1107
translate Spanish day6dlc_start2_b7672343:

    # player "I love [pet_name], you love Azrael :D"
    player "Yo amo a [pet_name], tú amas a Azrael :D"

# game/beyond the bet/day6dlc.rpy:1111
translate Spanish day6dlc_start2_93b31ac0:

    # player "I love my pet, you love Azrael :D"
    player "Yo amo a mi mascota, tú amas a Azrael :D"

# game/beyond the bet/day6dlc.rpy:1114
translate Spanish day6dlc_start2_90320c1e:

    # player "I know Azrael is just a plushie, but he's still an axolotl!"
    player "Sé que Azrael es solo un peluche, ¡pero sigue siendo un ajolote!"

# game/beyond the bet/day6dlc.rpy:1115
translate Spanish day6dlc_start2_e49900d3:

    # GR "he is not *just* a plushie."
    GR "no es 'solo' un peluche."

# game/beyond the bet/day6dlc.rpy:1116
translate Spanish day6dlc_start2_56a2e955:

    # GR "he is lord of the shadows himself. he stalks the night for souls. he is a better grim reaper than i."
    GR "es el señor de las sombras en persona. acecha la noche en busca de almas. es mejor parca que yo."

# game/beyond the bet/day6dlc.rpy:1119
translate Spanish day6dlc_start2_6dfccd72:

    # player "I don't doubt that for a second."
    player "No lo dudo ni por un segundo."

# game/beyond the bet/day6dlc.rpy:1124
translate Spanish day6dlc_start2_b595d573:

    # player "[pet_name] would make a good reaper, too."
    player "[pet_name] también tendría talento para ser una parca."

# game/beyond the bet/day6dlc.rpy:1128
translate Spanish day6dlc_start2_5d4177c0:

    # player "My pet would make a good reaper, too."
    player "Mi mascota también tendría talento para ser una parca."

# game/beyond the bet/day6dlc.rpy:1131
translate Spanish day6dlc_start2_a19e8b5f:

    # GR "doubtful."
    GR "lo dudo."

# game/beyond the bet/day6dlc.rpy:1133
translate Spanish day6dlc_start2_d76a3631:

    # GR "your animal does not possess the grace that azrael does." id day6dlc_start2_d76a3631
    GR "tu animal no posee la gracia que posee azrael." id day6dlc_start2_d76a3631

# game/beyond the bet/day6dlc.rpy:1135
translate Spanish day6dlc_start2_2952941a:

    # GR "but, fine, i will admit that we are similar in that regard."
    GR "pero, bien, admitiré que en eso nos parecemos."

# game/beyond the bet/day6dlc.rpy:1139
translate Spanish day6dlc_start2_772f2299:

    # player "We're both workaholics."
    player "Los dos somos adictos al trabajo."

# game/beyond the bet/day6dlc.rpy:1142
translate Spanish day6dlc_start2_ca8a5694:

    # player "I mean, is there any hour in the day where you're not working?"
    player "O sea, ¿hay alguna hora del día en que no trabajes?"

# game/beyond the bet/day6dlc.rpy:1145
translate Spanish day6dlc_start2_b8f34687:

    # player "Wait, do you even sleep?"
    player "Espera, ¿acaso duermes?"

# game/beyond the bet/day6dlc.rpy:1146
translate Spanish day6dlc_start2_5dc9ef0e:

    # GR "yes, in a way."
    GR "sí, a mi manera."

# game/beyond the bet/day6dlc.rpy:1147
translate Spanish day6dlc_start2_912f2fe1:

    # GR "i need less sleep than a human like yourself, but i still need some."
    GR "necesito dormir menos que un humano como tú, pero igual necesito dormir algo."

# game/beyond the bet/day6dlc.rpy:1148
translate Spanish day6dlc_start2_5d60464e:

    # GR "usually i sleep for one or two hours at a time, then work calls."
    GR "normalmente duermo una o dos horas seguidas, y luego el trabajo llama."

# game/beyond the bet/day6dlc.rpy:1151
translate Spanish day6dlc_start2_65c3cfa0:

    # player "That sounds MEGA unhealthy."
    player "Eso suena SÚPER poco saludable."

# game/beyond the bet/day6dlc.rpy:1152
translate Spanish day6dlc_start2_3ff7fcc6:

    # GR "we are simply built different."
    GR "simplemente estamos hechos de forma distinta."

# game/beyond the bet/day6dlc.rpy:1155
translate Spanish day6dlc_start2_889745ab:

    # player "You need to come over and get a full eight hours sleep."
    player "Tienes que venir y dormir ocho horas completas."

# game/beyond the bet/day6dlc.rpy:1156
translate Spanish day6dlc_start2_d5c9faa8:

    # GR "i cannot imagine sleeping for so long."
    GR "no me imagino durmiendo tanto tiempo."

# game/beyond the bet/day6dlc.rpy:1159
translate Spanish day6dlc_start2_c8478f6d:

    # player "Don't worry, I'll show you how."
    player "Tranquilo, te enseñaré cómo."

# game/beyond the bet/day6dlc.rpy:1162
translate Spanish day6dlc_start2_0a146afb:

    # player "You can lay your head down beside mine..."
    player "Puedes recostar tu cabeza junto a la mía..."

# game/beyond the bet/day6dlc.rpy:1165
translate Spanish day6dlc_start2_ec66dc56:

    # player "I'm sure you'll get plenty of sleep ;)"
    player "Seguro que dormirás un montón ;)"

# game/beyond the bet/day6dlc.rpy:1166
translate Spanish day6dlc_start2_7772a27d_20:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:1167
translate Spanish day6dlc_start2_c30211c0_3:

    # GR "i..."
    GR "yo..."

# game/beyond the bet/day6dlc.rpy:1168
translate Spanish day6dlc_start2_59ed026f:

    # GR "would likely be in trouble for being away from work for so long."
    GR "probablemente tendría problemas por estar tanto tiempo lejos del trabajo."

# game/beyond the bet/day6dlc.rpy:1171
translate Spanish day6dlc_start2_25a732ad:

    # player "I'll write you a note, dw."
    player "Te escribiré una nota, tranqui."

# game/beyond the bet/day6dlc.rpy:1174
translate Spanish day6dlc_start2_2f928fac:

    # player "{i}'Grimmy was busy being my cuddle buddy, he'll be back tomorrow'{/i}."
    player "{i}'Parquita estaba ocupado siendo mi compañero de abrazos, volverá mañana'{/i}."

# game/beyond the bet/day6dlc.rpy:1175
translate Spanish day6dlc_start2_6dd07ea1:

    # GR ".........."
    GR ".........."

# game/beyond the bet/day6dlc.rpy:1182
translate Spanish day6dlc_start2_f2bec8a6:

    # player "Just to simply... live."
    player "Simplemente... vivir."

# game/beyond the bet/day6dlc.rpy:1185
translate Spanish day6dlc_start2_f60316bd:

    # player "There's so much to do in life."
    player "Hay tanto por hacer en la vida."

# game/beyond the bet/day6dlc.rpy:1188
translate Spanish day6dlc_start2_7c2131d4:

    # player "There's a lot of ugly things, sure, but there's a lot of beautiful things, too."
    player "Hay muchas cosas feas, sí, pero también hay muchas cosas hermosas."

# game/beyond the bet/day6dlc.rpy:1191
translate Spanish day6dlc_start2_3fa9f47c:

    # player "We could experience them together."
    player "Podríamos vivirlas juntos."

# game/beyond the bet/day6dlc.rpy:1192
translate Spanish day6dlc_start2_7772a27d_21:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:1193
translate Spanish day6dlc_start2_a50cc61c:

    # GR "that is a kind offer, [playerfirstname!l]."
    GR "es una oferta amable, [playerfirstname!l]."

# game/beyond the bet/day6dlc.rpy:1194
translate Spanish day6dlc_start2_6b254f59:

    # GR "in another life, perhaps, you and i would experience it all."
    GR "en otra vida, quizá, tú y yo lo viviríamos todo."

# game/beyond the bet/day6dlc.rpy:1195
translate Spanish day6dlc_start2_5dd9dfbf:

    # GR "we would wake up early to see the sunrise, and then later watch that same sun set."
    GR "nos levantaríamos temprano para ver el amanecer, y más tarde veríamos ese mismo sol ponerse."

# game/beyond the bet/day6dlc.rpy:1196
translate Spanish day6dlc_start2_203e3e3b:

    # GR "i would deliver you flowers every day, so that you would never run out."
    GR "te traería flores todos los días, para que nunca se te acabaran."

# game/beyond the bet/day6dlc.rpy:1197
translate Spanish day6dlc_start2_4182c00c:

    # GR "we would cook new foods together every day."
    GR "cocinaríamos recetas nuevas juntos todos los días."

# game/beyond the bet/day6dlc.rpy:1198
translate Spanish day6dlc_start2_953d94b5:

    # GR "some days it would be terrible..."
    GR "algunos días nos saldría terrible..."

# game/beyond the bet/day6dlc.rpy:1199
translate Spanish day6dlc_start2_ccb8f96e:

    # GR "and others we would fall in love with whatever recipe we dug up on the internet..."
    GR "y otros días nos enamoraríamos de cualquier receta que encontráramos en internet..."

# game/beyond the bet/day6dlc.rpy:1200
translate Spanish day6dlc_start2_a48da2ad:

    # GR "but either way we would enjoy it."
    GR "pero de cualquier modo lo disfrutaríamos."

# game/beyond the bet/day6dlc.rpy:1201
translate Spanish day6dlc_start2_2123f764:

    # GR "alas."
    GR "por desgracia."

# game/beyond the bet/day6dlc.rpy:1202
translate Spanish day6dlc_start2_4d39748b:

    # GR "i am a reaper shrouded in darkness, and you are a mortal surrounded by light."
    GR "soy una parca envuelta en oscuridad, y tú eres [arti_2] mortal rodead[letra] de luz."

# game/beyond the bet/day6dlc.rpy:1203
translate Spanish day6dlc_start2_42ed9b7d:

    # GR "not in this lifetime, sunshine."
    GR "no en esta vida, solecito."

# game/beyond the bet/day6dlc.rpy:1206
translate Spanish day6dlc_start2_4b021b7b:

    # player "What if I said pretty please?"
    player "¿Y si dijera porfis?"

# game/beyond the bet/day6dlc.rpy:1207
translate Spanish day6dlc_start2_7e73b054:

    # GR "that would not change reality."
    GR "eso no cambiaría la realidad."

# game/beyond the bet/day6dlc.rpy:1210
translate Spanish day6dlc_start2_126c0670:

    # player "You don't know that."
    player "Eso no lo sabes."

# game/beyond the bet/day6dlc.rpy:1213
translate Spanish day6dlc_start2_8b646420:

    # player "Maybe if I wish hard enough?"
    player "¿Quizá si lo deseo con todas mis fuerzas?"

# game/beyond the bet/day6dlc.rpy:1214
translate Spanish day6dlc_start2_175a587b:

    # GR "then i will pray to whoever is listening that it works."
    GR "entonces rezaré a quien sea que escuche para que funcione."

# game/beyond the bet/day6dlc.rpy:1217
translate Spanish day6dlc_start2_edbd28cc:

    # player "I'll try my best, for the both of us!"
    player "¡Daré lo mejor de mí, por los dos!"

# game/beyond the bet/day6dlc.rpy:1220
translate Spanish day6dlc_start2_54160e6c:

    # player "Well, that makes me feel a little sad."
    player "Bueno, eso me pone un poco triste."

# game/beyond the bet/day6dlc.rpy:1221
translate Spanish day6dlc_start2_836fe2f7:

    # GR "such is life, sunshine."
    GR "así es la vida, solecito."

# game/beyond the bet/day6dlc.rpy:1222
translate Spanish day6dlc_start2_c6021d5d:

    # GR "the only fairness is in death."
    GR "la única justicia está en la muerte."

# game/beyond the bet/day6dlc.rpy:1225
translate Spanish day6dlc_start2_7324f6de:

    # player "Well, I think the system is bullshit."
    player "Pues yo creo que el sistema es una mierda."

# game/beyond the bet/day6dlc.rpy:1228
translate Spanish day6dlc_start2_9a5784dc:

    # player "And I'm gonna do something about it."
    player "Y voy a hacer algo al respecto."

# game/beyond the bet/day6dlc.rpy:1229
translate Spanish day6dlc_start2_408acb70:

    # GR "ah, yes. a lone mortal charging into the underworld, demanding rights for the grim reapers."
    GR "ah, sí. [arti_2] mortal sol[letra] irrumpiendo en el inframundo, exigiendo derechos para las parcas."

# game/beyond the bet/day6dlc.rpy:1230
translate Spanish day6dlc_start2_5c1584aa:

    # GR "that will go swimmingly."
    GR "eso saldrá a las mil maravillas."

# game/beyond the bet/day6dlc.rpy:1233
translate Spanish day6dlc_start2_5a8ddd43:

    # player "You're being sarcastic, but it could work."
    player "Estás siendo sarcástico, pero podría funcionar."

# game/beyond the bet/day6dlc.rpy:1234
translate Spanish day6dlc_start2_b5244b4f:

    # GR "i doubt it."
    GR "lo dudo."

# game/beyond the bet/day6dlc.rpy:1235
translate Spanish day6dlc_start2_7e7b4372:

    # GR "but..."
    GR "pero..."

# game/beyond the bet/day6dlc.rpy:1236
translate Spanish day6dlc_start2_e3e45bf5:

    # GR "perhaps i will pretend it could work, too."
    GR "quizá yo también finja que podría funcionar."

# game/beyond the bet/day6dlc.rpy:1237
translate Spanish day6dlc_start2_fccab77c:

    # GR "it gives one a reason to keep existing, i suppose."
    GR "da una razón para seguir existiendo, supongo."

# game/beyond the bet/day6dlc.rpy:1240
translate Spanish day6dlc_start2_edbd28cc_1:

    # player "I'll try my best, for the both of us!"
    player "¡Daré lo mejor de mí, por los dos!"

# game/beyond the bet/day6dlc.rpy:1251
translate Spanish day6dlc_start2_c55d191d:

    # player "Who is the weirdest one?"
    player "¿Quién es el más raro?"

# game/beyond the bet/day6dlc.rpy:1252
translate Spanish day6dlc_start2_5dcf937a:

    # GR "hmm."
    GR "mmm."

# game/beyond the bet/day6dlc.rpy:1253
translate Spanish day6dlc_start2_c1ce8341:

    # GR "a curious question."
    GR "una pregunta curiosa."

# game/beyond the bet/day6dlc.rpy:1254
translate Spanish day6dlc_start2_fd63fe7a:

    # GR "but, also an easy one."
    GR "pero también fácil."

# game/beyond the bet/day6dlc.rpy:1255
translate Spanish day6dlc_start2_53eaf861:

    # GR "there is another reaper named douglas the second."
    GR "hay otra parca llamada douglas el segundo."

# game/beyond the bet/day6dlc.rpy:1256
translate Spanish day6dlc_start2_639add83:

    # GR "we are not sure why he calls himself that."
    GR "no sabemos por qué se hace llamar así."

# game/beyond the bet/day6dlc.rpy:1257
translate Spanish day6dlc_start2_c74b7f00:

    # GR "there was never a douglas the first."
    GR "nunca hubo un douglas el primero."

# game/beyond the bet/day6dlc.rpy:1260
translate Spanish day6dlc_start2_0fa79698:

    # player "How do you know?"
    player "¿Cómo lo sabes?"

# game/beyond the bet/day6dlc.rpy:1261
translate Spanish day6dlc_start2_a368670c:

    # GR "there was an official investigation into the matter."
    GR "hubo una investigación oficial sobre el asunto."

# game/beyond the bet/day6dlc.rpy:1262
translate Spanish day6dlc_start2_f1f53d73:

    # GR "the upper management were extremely distraught, actually."
    GR "la alta dirección estaba muy angustiada, en realidad."

# game/beyond the bet/day6dlc.rpy:1263
translate Spanish day6dlc_start2_acb70c1b:

    # GR "thinking they had forgotten whoever douglas the first was."
    GR "pensando que habían olvidado a quienquiera que fuera douglas el primero."

# game/beyond the bet/day6dlc.rpy:1264
translate Spanish day6dlc_start2_73e94350:

    # GR "but, no, he never existed."
    GR "pero no, nunca existió."

# game/beyond the bet/day6dlc.rpy:1267
translate Spanish day6dlc_start2_2142f10a:

    # player "You should ask him why he calls himself that."
    player "Deberías preguntarle por qué se hace llamar así."

# game/beyond the bet/day6dlc.rpy:1268
translate Spanish day6dlc_start2_590bc2f2:

    # GR "i did once."
    GR "una vez lo hice."

# game/beyond the bet/day6dlc.rpy:1269
translate Spanish day6dlc_start2_24f76521:

    # GR "it was some years back."
    GR "fue hace algunos años."

# game/beyond the bet/day6dlc.rpy:1270
translate Spanish day6dlc_start2_ee26a87f:

    # GR "his answer was that he felt like a second."
    GR "su respuesta fue que se sentía como un segundo."

# game/beyond the bet/day6dlc.rpy:1271
translate Spanish day6dlc_start2_9faf12d0:

    # GR "he also collects used tissues, so i fear that's not his only oddity."
    GR "también colecciona pañuelos desechables usados, así que me temo que esa no es su única rareza."

# game/beyond the bet/day6dlc.rpy:1274
translate Spanish day6dlc_start2_ae2bc1f3:

    # player "That IS kinda weird."
    player "Eso SÍ es medio raro."

# game/beyond the bet/day6dlc.rpy:1277
translate Spanish day6dlc_start2_e6b18282:

    # player "But, hey, who am I to judge."
    player "Pero, oye, quién soy yo para juzgar."

# game/beyond the bet/day6dlc.rpy:1280
translate Spanish day6dlc_start2_47b15281:

    # player "I collected some weird stuff when I was a kid."
    player "Yo coleccionaba cosas raras cuando era niñ[letra]."

# game/beyond the bet/day6dlc.rpy:1281
translate Spanish day6dlc_start2_460c4fb2_2:

    # GR "like?"
    GR "¿como qué?"

# game/beyond the bet/day6dlc.rpy:1284
translate Spanish day6dlc_start2_b38dad3f:

    # player "Stamps."
    player "Estampillas."

# game/beyond the bet/day6dlc.rpy:1285
translate Spanish day6dlc_start2_e8678b8f:

    # GR "stamps?"
    GR "¿estampillas?"

# game/beyond the bet/day6dlc.rpy:1286
translate Spanish day6dlc_start2_32d653cf:

    # GR "that seems rather normal."
    GR "eso parece bastante normal."

# game/beyond the bet/day6dlc.rpy:1289
translate Spanish day6dlc_start2_912e6ee1:

    # player "I had like 4000 of them, last I checked."
    player "Tenía como 4000, la última vez que revisé."

# game/beyond the bet/day6dlc.rpy:1290
translate Spanish day6dlc_start2_d2817595:

    # GR "what."
    GR "qué."

# game/beyond the bet/day6dlc.rpy:1291
translate Spanish day6dlc_start2_50d70e04:

    # GR "that is far too many stamps."
    GR "son demasiadas estampillas, y por mucho."

# game/beyond the bet/day6dlc.rpy:1294
translate Spanish day6dlc_start2_bbeed5b0:

    # player "You can never have too many stamps, Grim."
    player "Nunca hay demasiadas estampillas, Parca."

# game/beyond the bet/day6dlc.rpy:1297
translate Spanish day6dlc_start2_242d09ae:

    # player "Rocks."
    player "Piedras."

# game/beyond the bet/day6dlc.rpy:1298
translate Spanish day6dlc_start2_4610b0e1:

    # GR "like. the kind you find everywhere?"
    GR "como. ¿de las que se encuentran en todas partes?"

# game/beyond the bet/day6dlc.rpy:1301
translate Spanish day6dlc_start2_98bb3370:

    # player "All kinds."
    player "De todo tipo."

# game/beyond the bet/day6dlc.rpy:1304
translate Spanish day6dlc_start2_4dcd685e:

    # player "Pretty rocks, ugly rocks, rocks that are pretty on the inside but ugly on the outside."
    player "Piedras bonitas, piedras feas, piedras que son bonitas por dentro pero feas por fuera."

# game/beyond the bet/day6dlc.rpy:1307
translate Spanish day6dlc_start2_45819b66:

    # player "I just liked rocks."
    player "Simplemente me gustaban las piedras."

# game/beyond the bet/day6dlc.rpy:1308
translate Spanish day6dlc_start2_2cfbaea0:

    # GR "well..."
    GR "bueno..."

# game/beyond the bet/day6dlc.rpy:1309
translate Spanish day6dlc_start2_c02991a6:

    # GR "i suppose there are worse things to collect than rocks."
    GR "supongo que hay cosas peores para coleccionar que piedras."

# game/beyond the bet/day6dlc.rpy:1313
translate Spanish day6dlc_start2_33efb8a7:

    # player "Teeth."
    player "Dientes."

# game/beyond the bet/day6dlc.rpy:1314
translate Spanish day6dlc_start2_889206ba:

    # GR "TEETH?"
    GR "¿¿¿DIENTES???"

# game/beyond the bet/day6dlc.rpy:1315
translate Spanish day6dlc_start2_c02ca8ab:

    # GR "aha! this could begin to explain some of your strange abilities."
    GR "¡ajá! esto podría empezar a explicar algunas de tus extrañas habilidades."

# game/beyond the bet/day6dlc.rpy:1318
translate Spanish day6dlc_start2_3bf2e05a:

    # player "My what?!"
    player "¡¿Mis qué?!"

# game/beyond the bet/day6dlc.rpy:1320
translate Spanish day6dlc_start2_bb3f4936:

    # player "...Abilities? Casper, what are you talking about?"
    player "...¿Habilidades? Casper, ¿de qué hablas?"

# game/beyond the bet/day6dlc.rpy:1321
translate Spanish day6dlc_start2_7772a27d_22:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:1322
translate Spanish day6dlc_start2_40798eba:

    # GR "don't worry about that yet."
    GR "no te preocupes por eso todavía."

# game/beyond the bet/day6dlc.rpy:1323
translate Spanish day6dlc_start2_3ca2a647:

    # GR "right now i have another matter on my mind."
    GR "ahora mismo tengo otro asunto en mente."

# game/beyond the bet/day6dlc.rpy:1324
translate Spanish day6dlc_start2_730f4931:

    # GR "perhaps you are half tooth fairy."
    GR "quizá seas mitad hada de los dientes."

# game/beyond the bet/day6dlc.rpy:1327
translate Spanish day6dlc_start2_e6fb0b05:

    # player "You can't just spring on me that the tooth fairy is real, Grim."
    player "No puedes soltarme así como así que el hada de los dientes es real, Parca."

# game/beyond the bet/day6dlc.rpy:1328
translate Spanish day6dlc_start2_e6f0cc3f:

    # GR "well, they are. there's plenty of them."
    GR "pues lo son. hay muchísimas."

# game/beyond the bet/day6dlc.rpy:1329
translate Spanish day6dlc_start2_b29d851b:

    # GR "creepy little creatures."
    GR "criaturitas espeluznantes."

# game/beyond the bet/day6dlc.rpy:1330
translate Spanish day6dlc_start2_ab963254:

    # GR "i don't understand their obsession with teeth. they're very secretive."
    GR "no entiendo su obsesión con los dientes. son muy reservadas."

# game/beyond the bet/day6dlc.rpy:1333
translate Spanish day6dlc_start2_6ff7fe93:

    # player "Grim. Come on."
    player "Parca. Vamos."

# game/beyond the bet/day6dlc.rpy:1334
translate Spanish day6dlc_start2_9833c835:

    # GR "it is true."
    GR "es cierto."

# game/beyond the bet/day6dlc.rpy:1335
translate Spanish day6dlc_start2_ab61ab80:

    # GR "i have heard that if a child's teeth do not fall out quickly enough..."
    GR "he oído que si a un niño no se le caen los dientes lo bastante rápido..."

# game/beyond the bet/day6dlc.rpy:1336
translate Spanish day6dlc_start2_86558945:

    # GR "they pull them straight from their mouths while they sleep."
    GR "se los arrancan de la boca mientras duerme."

# game/beyond the bet/day6dlc.rpy:1337
translate Spanish day6dlc_start2_15787564:

    # GR "i would never trust a tooth fairy."
    GR "jamás confiaría en un hada de los dientes."

# game/beyond the bet/day6dlc.rpy:1340
translate Spanish day6dlc_start2_a0d8e0db:

    # player "You literally keep saying things that completely change my outlook on life."
    player "Literalmente no paras de decir cosas que cambian por completo mi visión de la vida."

# game/beyond the bet/day6dlc.rpy:1343
translate Spanish day6dlc_start2_7b52b417:

    # player "Do parents not wonder where the teeth go???"
    player "¿¿¿Los padres no se preguntan adónde van los dientes???"

# game/beyond the bet/day6dlc.rpy:1344
translate Spanish day6dlc_start2_c391e96c:

    # GR "i believe those fairies use their dust to change the memories of anyone that gets in their way."
    GR "creo que esas hadas usan su polvo para cambiar los recuerdos de cualquiera que se les cruce en el camino."

# game/beyond the bet/day6dlc.rpy:1347
translate Spanish day6dlc_start2_c7d69dad:

    # player "What the fuck."
    player "Qué carajo."

# game/beyond the bet/day6dlc.rpy:1349
translate Spanish day6dlc_start2_cad4e2fa:

    # player "This is insane."
    player "Esto es una locura."

# game/beyond the bet/day6dlc.rpy:1350
translate Spanish day6dlc_start2_46198311:

    # GR "are you half tooth fairy?"
    GR "¿eres mitad hada de los dientes?"

# game/beyond the bet/day6dlc.rpy:1353
translate Spanish day6dlc_start2_e70a0812:

    # player "Um."
    player "Eh."

# game/beyond the bet/day6dlc.rpy:1356
translate Spanish day6dlc_start2_4c6fded1:

    # player "I think not."
    player "Creo que no."

# game/beyond the bet/day6dlc.rpy:1359
translate Spanish day6dlc_start2_07a646b9:

    # player "I just thought collecting teeth was fun."
    player "Solo pensé que coleccionar dientes era divertido."

# game/beyond the bet/day6dlc.rpy:1362
translate Spanish day6dlc_start2_bf42f661:

    # player "My own teeth, that is. Not anyone else's."
    player "Mis propios dientes, claro. No los de nadie más."

# game/beyond the bet/day6dlc.rpy:1365
translate Spanish day6dlc_start2_5e1d80aa:

    # player "THAT would be weird."
    player "ESO sí sería raro."

# game/beyond the bet/day6dlc.rpy:1368
translate Spanish day6dlc_start2_f8e7b488:

    # player "But now that you mention it, they all mysteriously went missing one day..."
    player "Pero ahora que lo mencionas, todos desaparecieron misteriosamente un día..."

# game/beyond the bet/day6dlc.rpy:1369
translate Spanish day6dlc_start2_db1e44b0:

    # GR "the tooth fairies strike once again."
    GR "las hadas de los dientes atacan de nuevo."

# game/beyond the bet/day6dlc.rpy:1370
translate Spanish day6dlc_start2_db6ee9c4:

    # GR "be careful around them, mortal."
    GR "ten cuidado con ellas, mortal."

# game/beyond the bet/day6dlc.rpy:1375
translate Spanish day6dlc_start2_bc71d074:

    # player "Spoons."
    player "Cucharas."

# game/beyond the bet/day6dlc.rpy:1376
translate Spanish day6dlc_start2_f3238ca1:

    # GR "spoons?"
    GR "¿cucharas?"

# game/beyond the bet/day6dlc.rpy:1379
translate Spanish day6dlc_start2_7cf9aa10:

    # player "Like, those little collectable spoons you get when you travel."
    player "O sea, esas cucharitas de colección que uno se trae cuando viaja."

# game/beyond the bet/day6dlc.rpy:1382
translate Spanish day6dlc_start2_069a45e8:

    # player "They're kind of pointless but they look pretty."
    player "Son medio inútiles, pero se ven bonitas."

# game/beyond the bet/day6dlc.rpy:1383
translate Spanish day6dlc_start2_0fd21ff0:

    # GR "why not just use them?"
    GR "¿por qué no usarlas y ya?"

# game/beyond the bet/day6dlc.rpy:1386
translate Spanish day6dlc_start2_71e5e245:

    # player "They're too pretty to use!"
    player "¡Son demasiado bonitas para usarlas!"

# game/beyond the bet/day6dlc.rpy:1387
translate Spanish day6dlc_start2_471de712:

    # GR "that makes no sense."
    GR "eso no tiene sentido."

# game/beyond the bet/day6dlc.rpy:1388
translate Spanish day6dlc_start2_863f2037:

    # GR "life is too short for a mortal to just stare at something they like and decide its too pretty to use..."
    GR "la vida es demasiado corta para que un mortal se quede mirando algo que le gusta y decida que es demasiado bonito para usarlo..."

# game/beyond the bet/day6dlc.rpy:1389
translate Spanish day6dlc_start2_16f066a7:

    # GR "then relegate it to some shelf to collect dust."
    GR "y luego lo relegue a algún estante a acumular polvo."

# game/beyond the bet/day6dlc.rpy:1390
translate Spanish day6dlc_start2_705ea26a:

    # GR "it is best to use the things you love, because to love is to be changed."
    GR "lo mejor es usar las cosas que amas, porque amar es ser transformado."

# game/beyond the bet/day6dlc.rpy:1391
translate Spanish day6dlc_start2_acf88531:

    # GR "it does not ruin something to use it as intended, even if it becomes worn in the process."
    GR "no se arruina algo por usarlo como fue pensado, aunque se desgaste en el proceso."

# game/beyond the bet/day6dlc.rpy:1394
translate Spanish day6dlc_start2_6befdc9d:

    # player "That was... surprisingly deep."
    player "Eso fue... sorprendentemente profundo."

# game/beyond the bet/day6dlc.rpy:1397
translate Spanish day6dlc_start2_2b91dae7:

    # player "I think you have a point, Grim."
    player "Creo que tienes razón, Parca."

# game/beyond the bet/day6dlc.rpy:1400
translate Spanish day6dlc_start2_337d827f:

    # player "I have a whole stack of stickers in a drawer I'm too afraid to use, but better to use them, huh?"
    player "Tengo un montón de pegatinas en un cajón que me da miedo usar, pero es mejor usarlas, ¿no?"

# game/beyond the bet/day6dlc.rpy:1401
translate Spanish day6dlc_start2_ad537e59:

    # GR "yes, well, i am full of wisdom, naturally."
    GR "sí, bueno, estoy lleno de sabiduría, naturalmente."

# game/beyond the bet/day6dlc.rpy:1404
translate Spanish day6dlc_start2_9f12ba97_1:

    # player "I'll keep it in mind."
    player "Lo tendré en cuenta."

# game/beyond the bet/day6dlc.rpy:1405
translate Spanish day6dlc_start2_ad537e59_1:

    # GR "yes, well, i am full of wisdom, naturally."
    GR "sí, bueno, estoy lleno de sabiduría, naturalmente."

# game/beyond the bet/day6dlc.rpy:1410
translate Spanish day6dlc_start2_4cf8a4cc:

    # player "Not to backtrack, but..."
    player "No quiero volver atrás, pero..."

# game/beyond the bet/day6dlc.rpy:1414
translate Spanish day6dlc_start2_d78dd431:

    # player "What did you say? I have a kink for bullying people?"
    player "¿Qué dijiste? ¿Que tengo un fetiche con molestar a la gente?"

# game/beyond the bet/day6dlc.rpy:1417
translate Spanish day6dlc_start2_5e3007f6:

    # player "Honestly, Grimmy, you just make it too easy. It's fun."
    player "Sinceramente, Parquita, me lo pones demasiado fácil. Es divertido."

# game/beyond the bet/day6dlc.rpy:1420
translate Spanish day6dlc_start2_9bfded30:

    # player "I like teasing you."
    player "Me gusta molestarte."

# game/beyond the bet/day6dlc.rpy:1424
translate Spanish day6dlc_start2_0bdebdb5:

    # player "You're filling a hunger I didn't even know I had."
    player "Estás saciando un hambre que ni sabía que tenía."

# game/beyond the bet/day6dlc.rpy:1427
translate Spanish day6dlc_start2_10607968:

    # player "And I've been absolutely starved, apparently."
    player "Y por lo visto estaba muriéndome de hambre."

# game/beyond the bet/day6dlc.rpy:1428
translate Spanish day6dlc_start2_c4293a77:

    # GR "well, fortunately you are a capable mortal who can feed yourself."
    GR "bueno, por suerte eres [arti_2] mortal capaz de alimentarte por tu cuenta."

# game/beyond the bet/day6dlc.rpy:1431
translate Spanish day6dlc_start2_22fff884:

    # player "Awwww..."
    player "Awwww..."

# game/beyond the bet/day6dlc.rpy:1434
translate Spanish day6dlc_start2_e41f93b4:

    # player "That's no fun, Grim."
    player "Qué aburrido, Parca."

# game/beyond the bet/day6dlc.rpy:1437
translate Spanish day6dlc_start2_393dcbe2:

    # player "Come feed me!"
    player "¡Ven a darme de comer!"

# game/beyond the bet/day6dlc.rpy:1438
translate Spanish day6dlc_start2_916606c6:

    # GR "feed you? what, like a child?"
    GR "¿darte de comer? ¿qué, como a [arti_2] niñ[letra]?"

# game/beyond the bet/day6dlc.rpy:1441
translate Spanish day6dlc_start2_b8dfefab:

    # player "Aaaaaaaaah."
    player "Aaaaaaaaah."

# game/beyond the bet/day6dlc.rpy:1444
translate Spanish day6dlc_start2_bd1e454d:

    # player "(I'm waiting for the airplane)"
    player "(Estoy esperando al avioncito)"

# game/beyond the bet/day6dlc.rpy:1446
translate Spanish day6dlc_start2_ae4a164e:

    # GR "you will be waiting for some time."
    GR "esperarás un buen rato."

# game/beyond the bet/day6dlc.rpy:1451
translate Spanish day6dlc_start2_031dd23f:

    # player "I was starving before I met you, and now you've completely filled me up."
    player "Me moría de hambre antes de conocerte, y ahora me has llenado por completo."

# game/beyond the bet/day6dlc.rpy:1452
translate Spanish day6dlc_start2_1dd771ba:

    # GR "filled you up? sunshine, that's a little..."
    GR "¿llenarte? solecito, eso es un poco..."

# game/beyond the bet/day6dlc.rpy:1455
translate Spanish day6dlc_start2_a3dee18b:

    # player "Hey, I didn't mean it like that!"
    player "¡Oye, no lo dije en ese sentido!"

# game/beyond the bet/day6dlc.rpy:1458
translate Spanish day6dlc_start2_0b19827c:

    # player "I'm not saying no, though..."
    player "Aunque no digo que no..."

# game/beyond the bet/day6dlc.rpy:1461
translate Spanish day6dlc_start2_c279c7b7:

    # player "You can come 'fill me up' any day ;)"
    player "Puedes venir a 'llenarme' cuando quieras ;)"

# game/beyond the bet/day6dlc.rpy:1463
translate Spanish day6dlc_start2_7772a27d_23:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:1464
translate Spanish day6dlc_start2_7d5fd4bd:

    # GR "i suppose we are no longer talking about me feeding you food."
    GR "supongo que ya no hablamos de que te dé comida."

# game/beyond the bet/day6dlc.rpy:1465
translate Spanish day6dlc_start2_c47e533c:

    # GR "were we, i would let you know that you are fully capable of feeding yourself."
    GR "si lo hiciéramos, te haría saber que eres perfectamente capaz de alimentarte por tu cuenta."

# game/beyond the bet/day6dlc.rpy:1466
translate Spanish day6dlc_start2_f8f7d0d1:

    # GR "i doubt you could handle what you insinuate, mortal."
    GR "dudo que pudieras con lo que insinúas, mortal."

# game/beyond the bet/day6dlc.rpy:1467
translate Spanish day6dlc_start2_7e7b4372_1:

    # GR "but..."
    GR "pero..."

# game/beyond the bet/day6dlc.rpy:1468
translate Spanish day6dlc_start2_8584a84d:

    # GR "perhaps i would like to see you try."
    GR "quizá me gustaría verte intentarlo."

# game/beyond the bet/day6dlc.rpy:1471
translate Spanish day6dlc_start2_2bf35b58:

    # player "I'll note it down in my calendar, then."
    player "Lo anotaré en mi calendario, entonces."

# game/beyond the bet/day6dlc.rpy:1474
translate Spanish day6dlc_start2_a68a4723:

    # player "Wednesday, the Grim Reaper comes over to show me how he works that scythe ;)"
    player "El miércoles, la Parca viene a mostrarme cómo maneja esa guadaña ;)"

# game/beyond the bet/day6dlc.rpy:1475
translate Spanish day6dlc_start2_c012197e:

    # GR "i have a pretty busy schedule. perhaps i'll be there, perhaps i won't."
    GR "tengo una agenda bastante apretada. quizá vaya, quizá no."

# game/beyond the bet/day6dlc.rpy:1479
translate Spanish day6dlc_start2_d9de4745:

    # player "What if I flutter my eyelashes at you? Would that change your mind?"
    player "¿Y si te bato las pestañas? ¿Te haría cambiar de opinión?"

# game/beyond the bet/day6dlc.rpy:1481
translate Spanish day6dlc_start2_1e1f7372:

    # player "I'll get down on my knees and beg. Pretty please?"
    player "Me pondré de rodillas y te suplicaré. ¿Porfis?"

# game/beyond the bet/day6dlc.rpy:1482
translate Spanish day6dlc_start2_7772a27d_24:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:1485
translate Spanish day6dlc_start2_da3394f6:

    # player "See! I told you. You make it too easy."
    player "¡Ves! Te lo dije. Me lo pones demasiado fácil."

# game/beyond the bet/day6dlc.rpy:1486
translate Spanish day6dlc_start2_c003a17a:

    # GR "it is not my intention."
    GR "no es mi intención."

# game/beyond the bet/day6dlc.rpy:1487
translate Spanish day6dlc_start2_d7ae7dc9:

    # GR "you just..."
    GR "es que tú..."

# game/beyond the bet/day6dlc.rpy:1488
translate Spanish day6dlc_start2_4505efa6:

    # GR "overwhelm me, sometimes."
    GR "me abrumas, a veces."

# game/beyond the bet/day6dlc.rpy:1489
translate Spanish day6dlc_start2_5ea21e4a:

    # GR "it is a strange, foreign feeling. no one else has ever... pulled at my heartstrings so."
    GR "es un sentimiento extraño, ajeno. nadie más ha... tocado así las fibras de mi corazón."

# game/beyond the bet/day6dlc.rpy:1492
translate Spanish day6dlc_start2_03775ec8_3:

    # player "..."
    player "..."

# game/beyond the bet/day6dlc.rpy:1495
translate Spanish day6dlc_start2_0de03d4a:

    # player "You should be careful there, Grimmy."
    player "Deberías tener cuidado, Parquita."

# game/beyond the bet/day6dlc.rpy:1498
translate Spanish day6dlc_start2_0c5b28c3:

    # player "A [girl] could misunderstand what you mean."
    player "[arti_2!c] [girl!t] podría malinterpretar lo que quieres decir."

# game/beyond the bet/day6dlc.rpy:1501
translate Spanish day6dlc_start2_7747921f:

    # player "You're just trying to trick me for my soul again, aren't you?"
    player "Solo intentas engañarme otra vez para quedarte con mi alma, ¿verdad?"

# game/beyond the bet/day6dlc.rpy:1502
translate Spanish day6dlc_start2_f305bd7c:

    # GR "...right."
    GR "...claro."

# game/beyond the bet/day6dlc.rpy:1503
translate Spanish day6dlc_start2_82579c9a:

    # GR "yes, i am of course being... "
    GR "sí, por supuesto estoy siendo..."

# game/beyond the bet/day6dlc.rpy:1504
translate Spanish day6dlc_start2_b7ea2ae7:

    # GR "a crafty grim reaper. because i want your soul. because that is my job."
    GR "una parca astuta. porque quiero tu alma. porque ese es mi trabajo."

# game/beyond the bet/day6dlc.rpy:1505
translate Spanish day6dlc_start2_aced07d8_1:

    # GR "of course."
    GR "por supuesto."

# game/beyond the bet/day6dlc.rpy:1508
translate Spanish day6dlc_start2_8c2f188a:

    # player "Feeling conflicted, Casper?"
    player "¿Con sentimientos encontrados, Casper?"

# game/beyond the bet/day6dlc.rpy:1509
translate Spanish day6dlc_start2_5a31f33c:

    # GR "confliction is beneath me. i am always sure of myself."
    GR "sentirme dividido está por debajo de mí. siempre estoy seguro de mí mismo."

# game/beyond the bet/day6dlc.rpy:1512
translate Spanish day6dlc_start2_9e92f37b:

    # player "Even when it comes to me?"
    player "¿Incluso cuando se trata de mí?"

# game/beyond the bet/day6dlc.rpy:1515
translate Spanish day6dlc_start2_9068fccb:

    # player "Do I make you feel things you didn't know possible, Grim?"
    player "¿Te hago sentir cosas que no sabías que eran posibles, Parca?"

# game/beyond the bet/day6dlc.rpy:1516
translate Spanish day6dlc_start2_4c535754:

    # GR "i have plenty of abilities, [playerfirstname!l]. amazing abilities."
    GR "tengo muchas habilidades, [playerfirstname!l]. habilidades asombrosas."

# game/beyond the bet/day6dlc.rpy:1517
translate Spanish day6dlc_start2_0bd066f9:

    # GR "to lie is not one of them."
    GR "mentir no es una de ellas."

# game/beyond the bet/day6dlc.rpy:1518
translate Spanish day6dlc_start2_ebc9eb7a_1:

    # GR "yes."
    GR "sí."

# game/beyond the bet/day6dlc.rpy:1519
translate Spanish day6dlc_start2_a55c6370:

    # GR "you make me.... conflicted, confused, angry, happy, sad, all at once."
    GR "me haces sentir.... dividido, confundido, enojado, feliz, triste, todo a la vez."

# game/beyond the bet/day6dlc.rpy:1520
translate Spanish day6dlc_start2_1df90f41:

    # GR "but that is my own problem."
    GR "pero ese es mi problema."

# game/beyond the bet/day6dlc.rpy:1521
translate Spanish day6dlc_start2_e1fda95a:

    # GR "perhaps there was a fault in my creation."
    GR "quizá hubo un fallo en mi creación."

# game/beyond the bet/day6dlc.rpy:1524
translate Spanish day6dlc_start2_1a59e58c:

    # player "I think you're perfect."
    player "Creo que eres perfecto."

# game/beyond the bet/day6dlc.rpy:1525
translate Spanish day6dlc_start2_27038761:

    # GR "any other time, i would agree with you."
    GR "en cualquier otro momento estaría de acuerdo contigo."

# game/beyond the bet/day6dlc.rpy:1526
translate Spanish day6dlc_start2_8a368074:

    # GR "i have always known i am perfect."
    GR "siempre he sabido que soy perfecto."

# game/beyond the bet/day6dlc.rpy:1527
translate Spanish day6dlc_start2_f79a0510:

    # GR "and yet today i am not certain of that fact."
    GR "y sin embargo hoy no estoy seguro de ese hecho."

# game/beyond the bet/day6dlc.rpy:1528
translate Spanish day6dlc_start2_1fd99e1a:

    # GR "ugh."
    GR "uf."

# game/beyond the bet/day6dlc.rpy:1529
translate Spanish day6dlc_start2_10853d26:

    # GR "i will deal with it myself."
    GR "lo resolveré yo solo."

# game/beyond the bet/day6dlc.rpy:1532
translate Spanish day6dlc_start2_6c693492:

    # player "Wait, maybe you {i}really{/i} like the idea of feeding me?"
    player "Espera, ¿quizá {i}de verdad{/i} te gusta la idea de darme de comer?"

# game/beyond the bet/day6dlc.rpy:1533
translate Spanish day6dlc_start2_cc21bd84_1:

    # GR "!!!"
    GR "!!!"

# game/beyond the bet/day6dlc.rpy:1536
translate Spanish day6dlc_start2_7440fbcf:

    # GR "i... i told you! you are capable of feeding yourself!"
    GR "yo... ¡te lo dije! ¡eres capaz de alimentarte por tu cuenta!"

# game/beyond the bet/day6dlc.rpy:1537
translate Spanish day6dlc_start2_6c862e92:

    # GR "i never said i wanted to!"
    GR "¡nunca dije que quisiera!"

# game/beyond the bet/day6dlc.rpy:1540
translate Spanish day6dlc_start2_2ef5defa:

    # player "I know what you said and didn't say."
    player "Sé lo que dijiste y lo que no dijiste."

# game/beyond the bet/day6dlc.rpy:1542
translate Spanish day6dlc_start2_6a8f275d:

    # GR "putting aside the thought of feeding you desserts at a picnic..."
    GR "dejando de lado la idea de darte de comer postres en un picnic..."

# game/beyond the bet/day6dlc.rpy:1543
translate Spanish day6dlc_start2_b6603ba5:

    # GR "you are an adult who can feed yourself..."
    GR "eres una persona adulta capaz de alimentarte por tu cuenta..."

# game/beyond the bet/day6dlc.rpy:1548
translate Spanish day6dlc_start2_3f72a0ad:

    # player "But I think if I asked really nicely, you might?"
    player "Pero creo que si te lo pidiera muy amablemente, quizá lo harías, ¿no?"

# game/beyond the bet/day6dlc.rpy:1549
translate Spanish day6dlc_start2_77e1853c:

    # GR "er... uh..."
    GR "eh... este..."

# game/beyond the bet/day6dlc.rpy:1552
translate Spanish day6dlc_start2_9b01166a:

    # player "If I suddenly had a bowl full of strawberries, would you feed them to me?"
    player "Si de repente tuviera un tazón lleno de fresas, ¿me las darías de comer?"

# game/beyond the bet/day6dlc.rpy:1553
translate Spanish day6dlc_start2_3df8952a:

    # GR "i... if... if you really wanted me to, perhaps..."
    GR "yo... si... si de verdad quisieras, quizá..."

# game/beyond the bet/day6dlc.rpy:1556
translate Spanish day6dlc_start2_7cb7b1ab:

    # player "With your mouth, of course. You take one end, I'll take the other."
    player "Con la boca. Tú tomas un extremo, yo el otro."

# game/beyond the bet/day6dlc.rpy:1557
translate Spanish day6dlc_start2_75f399fe_1:

    # GR "HUH?"
    GR "¿¿EH??"

# game/beyond the bet/day6dlc.rpy:1558
translate Spanish day6dlc_start2_35944814:

    # GR "that! is...! that's just kissing with a strawberry in the middle!"
    GR "¡eso! ¡es...! ¡eso es solo un beso con una fresa en medio!"

# game/beyond the bet/day6dlc.rpy:1561
translate Spanish day6dlc_start2_edf4b62d:

    # player "Yeah. That sounds like a good way to eat strawberries, to me."
    player "Sí. Me parece una buena forma de comer fresas."

# game/beyond the bet/day6dlc.rpy:1564
translate Spanish day6dlc_start2_e8a4590d:

    # player "No? Too intimate?"
    player "¿No? ¿Demasiado íntimo?"

# game/beyond the bet/day6dlc.rpy:1565
translate Spanish day6dlc_start2_7772a27d_25:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:1566
translate Spanish day6dlc_start2_37d12912:

    # GR "i fear... if i did that, you would become addicted to the taste."
    GR "temo que... si hiciera eso, te volverías adict[letra] al sabor."

# game/beyond the bet/day6dlc.rpy:1567
translate Spanish day6dlc_start2_df5b72fb:

    # GR "not of the strawberries. of me."
    GR "no de las fresas. de mí."

# game/beyond the bet/day6dlc.rpy:1568
translate Spanish day6dlc_start2_3927ca75:

    # GR "that would be too cruel. to give you a taste of perfection, then to take it away."
    GR "sería demasiado cruel. darte a probar la perfección y luego quitártela."

# game/beyond the bet/day6dlc.rpy:1571
translate Spanish day6dlc_start2_03775ec8_4:

    # player "..."
    player "..."

# game/beyond the bet/day6dlc.rpy:1574
translate Spanish day6dlc_start2_174c5527:

    # player "Wow. Way to turn that around on me."
    player "Wow. Qué forma de darle la vuelta a esto."

# game/beyond the bet/day6dlc.rpy:1577
translate Spanish day6dlc_start2_5c5224fd:

    # player "AHEM."
    player "EJEM."

# game/beyond the bet/day6dlc.rpy:1580
translate Spanish day6dlc_start2_6c0985d2:

    # player "I'll say 'aaaah' and then you'll pop it in my mouth" id day6dlc_start2_6c0985d2
    player "Diré 'aaaah' y tú me la pones en la boca." id day6dlc_start2_6c0985d2

# game/beyond the bet/day6dlc.rpy:1581
translate Spanish day6dlc_start2_77321bfc:

    # GR "and what if i get hungry?"
    GR "¿y si me da hambre a mí?"

# game/beyond the bet/day6dlc.rpy:1584
translate Spanish day6dlc_start2_f5d192c3:

    # player "Well, it would be only right for me to return the favor."
    player "Bueno, sería justo que te devolviera el favor."

# game/beyond the bet/day6dlc.rpy:1587
translate Spanish day6dlc_start2_bc4812e2:

    # player "Open wide, Grimmy, and I'll give it to you <3"
    player "Abre bien la boca, Parquita, y te la pondré <3"

# game/beyond the bet/day6dlc.rpy:1588
translate Spanish day6dlc_start2_7772a27d_26:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:1591
translate Spanish day6dlc_start2_518cc3e6:

    # player "The strawberry! I mean the strawberry."
    player "¡La fresa! Me refiero a la fresa."

# game/beyond the bet/day6dlc.rpy:1592
translate Spanish day6dlc_start2_31333d91:

    # GR "of course! the strawberry."
    GR "¡por supuesto! la fresa."

# game/beyond the bet/day6dlc.rpy:1595
translate Spanish day6dlc_start2_03775ec8_5:

    # player "..."
    player "..."

# game/beyond the bet/day6dlc.rpy:1596
translate Spanish day6dlc_start2_7772a27d_27:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:1599
translate Spanish day6dlc_start2_c4e2067b:

    # player "There's a secret third option here. Eat them off of each other's bodies ;)"
    player "La tercera opción secreta. Comérnoslas del cuerpo del otro ;)"

# game/beyond the bet/day6dlc.rpy:1602
translate Spanish day6dlc_start2_38ef3953:

    # player "If you're not afraid of a little mess, that is."
    player "Si no te asusta ensuciarte un poco, claro."

# game/beyond the bet/day6dlc.rpy:1603
translate Spanish day6dlc_start2_e279d46c:

    # GR "that seems like a wildly inefficient way to consume food."
    GR "eso parece una forma tremendamente ineficiente de consumir alimentos."

# game/beyond the bet/day6dlc.rpy:1606
translate Spanish day6dlc_start2_77b88ef2:

    # player "The point isn't really the food. It's the rest of what's going on."
    player "La idea no es realmente la comida. Es todo lo demás que pasa."

# game/beyond the bet/day6dlc.rpy:1607
translate Spanish day6dlc_start2_467fac03:

    # GR "and you want to do this? you want to eat food off of my body?"
    GR "¿y quieres hacer esto? ¿quieres comer comida de mi cuerpo?"

# game/beyond the bet/day6dlc.rpy:1610
translate Spanish day6dlc_start2_9f2386f3:

    # player "Hey, if you want to undress, I am CERTAINLY not going to stop you."
    player "Oye, si quieres desvestirte, DESDE LUEGO que no te lo voy a impedir."

# game/beyond the bet/day6dlc.rpy:1613
translate Spanish day6dlc_start2_ca2e3b9b:

    # player "Strip away, Mister Reaper, Sir."
    player "Adelante, quítese la ropa, Señor Parca, señor."

# game/beyond the bet/day6dlc.rpy:1616
translate Spanish day6dlc_start2_2f421038:

    # player "I'll be waiting for you ;)"
    player "Te estaré esperando ;)"

# game/beyond the bet/day6dlc.rpy:1619
translate Spanish day6dlc_start2_c6b3df22:

    # player "Alternatively, we skip the food and just do the stripping?"
    player "¿O nos saltamos la comida y hacemos solo lo de desvestirnos?"

# game/beyond the bet/day6dlc.rpy:1620
translate Spanish day6dlc_start2_7772a27d_28:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:1621
translate Spanish day6dlc_start2_6b287fa6:

    # GR "you act awfully tough now..."
    GR "ahora te las das de muy valiente..."

# game/beyond the bet/day6dlc.rpy:1622
translate Spanish day6dlc_start2_06511501:

    # GR "but if i turned up there now with strawberries i know you wouldn't be so sure of yourself."
    GR "pero si apareciera ahí ahora mismo con fresas sé que no estarías tan segur[letra] de ti mism[letra]."

# game/beyond the bet/day6dlc.rpy:1623
translate Spanish day6dlc_start2_6a4c9a6b:

    # GR "just you wait, [playerfirstname!l]. perhaps i will take you up on this some day."
    GR "ya verás, [playerfirstname!l]. quizá algún día te tome la palabra."

# game/beyond the bet/day6dlc.rpy:1624
translate Spanish day6dlc_start2_2134aa7a:

    # GR "but, that can wait. i wanted to ask..."
    GR "pero eso puede esperar. quería preguntarte..."

# game/beyond the bet/day6dlc.rpy:1627
translate Spanish day6dlc_start2_94938837:

    # player "Bring strawberries next time instead of flowers ;)"
    player "Trae fresas la próxima vez en lugar de flores ;)"

# game/beyond the bet/day6dlc.rpy:1630
translate Spanish day6dlc_start2_9f30ab35:

    # player "Wait."
    player "Espera."

# game/beyond the bet/day6dlc.rpy:1633
translate Spanish day6dlc_start2_1d588b4c:

    # player "Bring both."
    player "Trae ambas."

# game/beyond the bet/day6dlc.rpy:1635
translate Spanish day6dlc_start2_90099224:

    # GR "if you're lucky."
    GR "si tienes suerte."

# game/beyond the bet/day6dlc.rpy:1636
translate Spanish day6dlc_start2_2134aa7a_1:

    # GR "but, that can wait. i wanted to ask..."
    GR "pero eso puede esperar. quería preguntarte..."

# game/beyond the bet/day6dlc.rpy:1638
translate Spanish day6dlc_start2_aac671d3:

    # GR "don't you have something better to do on your days off, mortal?"
    GR "¿no tienes algo mejor que hacer en tus días libres, mortal?"

# game/beyond the bet/day6dlc.rpy:1639
translate Spanish day6dlc_start2_1cfa36e4:

    # GR "you have so few days left, and you use them to torment me."
    GR "te quedan tan pocos días, y los usas para atormentarme."

# game/beyond the bet/day6dlc.rpy:1640
translate Spanish day6dlc_start2_b76d816a:

    # GR "it seems a waste."
    GR "me parece un desperdicio."

# game/beyond the bet/day6dlc.rpy:1643
translate Spanish day6dlc_start2_1a6cd4d0:

    # player "Well, actually..."
    player "Bueno, en realidad..."

# game/beyond the bet/day6dlc.rpy:1646
translate Spanish day6dlc_start2_c43a38f3:

    # player "I'm in bed still."
    player "Sigo en la cama."

# game/beyond the bet/day6dlc.rpy:1647
translate Spanish day6dlc_start2_63faf53c:

    # GR "in bed? sunshine, it's nearly evening. you should be having dinner, not lounging."
    GR "¿en la cama? solecito, casi es de noche. deberías estar cenando, no holgazaneando."

# game/beyond the bet/day6dlc.rpy:1650
translate Spanish day6dlc_start2_07009214:

    # player "Give a [girl] a break, Grimmy boy."
    player "Dame un respiro, Parquita."

# game/beyond the bet/day6dlc.rpy:1653
translate Spanish day6dlc_start2_c62c7316:

    # player "I'm feeling off today."
    player "Hoy me siento mal."

# game/beyond the bet/day6dlc.rpy:1656
translate Spanish day6dlc_start2_fb23b18e:

    # player "I think I've caught a cold."
    player "Creo que me resfrié."

# game/beyond the bet/day6dlc.rpy:1659
translate Spanish day6dlc_start2_21f3aa1f:

    # player "Pretty sure I'm dying, actually."
    player "La verdad es que creo que me estoy muriendo."

# game/beyond the bet/day6dlc.rpy:1660
translate Spanish day6dlc_start2_e5a6f156_1:

    # GR "what?!"
    GR "¡¿qué?!"

# game/beyond the bet/day6dlc.rpy:1663
translate Spanish day6dlc_start2_bfad3633:

    # player "Heh."
    player "Je."

# game/beyond the bet/day6dlc.rpy:1666
translate Spanish day6dlc_start2_fbb25fc2:

    # player "It's just a cold."
    player "Solo es un resfriado."

# game/beyond the bet/day6dlc.rpy:1671
translate Spanish day6dlc_start2_8dc01fce:

    # player "I figured I'd just stay in bed with [pet_name] and chat with you."
    player "Pensé en quedarme en la cama con [pet_name] y charlar contigo."

# game/beyond the bet/day6dlc.rpy:1675
translate Spanish day6dlc_start2_254f7240:

    # player "I figured I'd just stay in bed with my pet and chat to you."
    player "Pensé en quedarme en la cama con mi mascota y charlar contigo."

# game/beyond the bet/day6dlc.rpy:1677
translate Spanish day6dlc_start2_7772a27d_29:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:1678
translate Spanish day6dlc_start2_d3da2fb0:

    # GR "how have you let a common cold take you, mortal? did you go to sleep with wet hair?"
    GR "¿cómo has permitido que un simple resfriado te venza, mortal? ¿te dormiste con el pelo mojado?"

# game/beyond the bet/day6dlc.rpy:1681
translate Spanish day6dlc_start2_b02977e8:

    # player "Um... no?"
    player "Eh... ¿no?"

# game/beyond the bet/day6dlc.rpy:1684
translate Spanish day6dlc_start2_a99721e6:

    # player "I mean, I don't think so, at least."
    player "O sea, creo que no, al menos."

# game/beyond the bet/day6dlc.rpy:1688
translate Spanish day6dlc_start2_64c2f4f2:

    # player "Yes, always."
    player "Sí, siempre."

# game/beyond the bet/day6dlc.rpy:1689
translate Spanish day6dlc_start2_c6d077d9:

    # GR "lords above, humans are so frail."
    GR "por todos los dioses, qué frágiles son los humanos."

# game/beyond the bet/day6dlc.rpy:1692
translate Spanish day6dlc_start2_e0cdb1c8:

    # player "But I always do it, so I doubt it's that."
    player "Pero siempre lo hago, así que dudo que sea eso."

# game/beyond the bet/day6dlc.rpy:1694
translate Spanish day6dlc_start2_d7bf4490:

    # GR "did you leave your window open all night?"
    GR "¿dejaste la ventana abierta toda la noche?"

# game/beyond the bet/day6dlc.rpy:1697
translate Spanish day6dlc_start2_93666768_1:

    # player "Nope."
    player "Nop."

# game/beyond the bet/day6dlc.rpy:1700
translate Spanish day6dlc_start2_df5f558b:

    # player "I close it every night before I go to bed."
    player "La cierro todas las noches antes de acostarme."

# game/beyond the bet/day6dlc.rpy:1703
translate Spanish day6dlc_start2_68f9edfd:

    # player "And if its cold, I don't even open it to begin with."
    player "Y si hace frío, ni siquiera la abro desde un principio."

# game/beyond the bet/day6dlc.rpy:1704
translate Spanish day6dlc_start2_809cafae:

    # GR "well, that is very sensible of you, at least."
    GR "bueno, eso es muy sensato de tu parte, al menos."

# game/beyond the bet/day6dlc.rpy:1707
translate Spanish day6dlc_start2_ad541557:

    # player "That's why they call me sensible [playerfirstname]."
    player "Por eso me llaman [playerfirstname] [arti] Sensat[letra]."

# game/beyond the bet/day6dlc.rpy:1708
translate Spanish day6dlc_start2_dfbed174:

    # GR "no one calls you that."
    GR "nadie te llama así."

# game/beyond the bet/day6dlc.rpy:1711
translate Spanish day6dlc_start2_72c56eb4:

    # player "How would you know?"
    player "¿Cómo lo sabrías?"

# game/beyond the bet/day6dlc.rpy:1714
translate Spanish day6dlc_start2_ef463e7e:

    # player "Maybe everyone calls me that."
    player "Quizá todos me llaman así."

# game/beyond the bet/day6dlc.rpy:1715
translate Spanish day6dlc_start2_6b542f1e:

    # GR "tell me who exactly calls you that."
    GR "dime quién exactamente te llama así."

# game/beyond the bet/day6dlc.rpy:1718
translate Spanish day6dlc_start2_3704a528:

    # player "Um..."
    player "Eh..."

# game/beyond the bet/day6dlc.rpy:1721
translate Spanish day6dlc_start2_839cd846:

    # player "My next door neighbors."
    player "Mis vecinos de al lado."

# game/beyond the bet/day6dlc.rpy:1722
translate Spanish day6dlc_start2_36d63958:

    # GR "Who are named?"
    GR "¿Y cómo se llaman?"

# game/beyond the bet/day6dlc.rpy:1725
translate Spanish day6dlc_start2_f90be0db:

    # player "Great question."
    player "Excelente pregunta."

# game/beyond the bet/day6dlc.rpy:1728
translate Spanish day6dlc_start2_7e6168b3:

    # player "Uh..."
    player "Eh..."

# game/beyond the bet/day6dlc.rpy:1731
translate Spanish day6dlc_start2_78258f23:

    # player "Greg...."
    player "Greg...."

# game/beyond the bet/day6dlc.rpy:1734
translate Spanish day6dlc_start2_667c6655:

    # player "Timmothy..."
    player "Timmothy..."

# game/beyond the bet/day6dlc.rpy:1735
translate Spanish day6dlc_start2_12afd4bc:

    # GR "you are bullshitting me."
    GR "me estás tomando el pelo."

# game/beyond the bet/day6dlc.rpy:1738
translate Spanish day6dlc_start2_d9aaee16:

    # player "Yeah, just a little."
    player "Sí, un poquito."

# game/beyond the bet/day6dlc.rpy:1741
translate Spanish day6dlc_start2_fbaa82c3:

    # player "I am very sensible, though."
    player "Soy muy sensat[letra], eso sí."

# game/beyond the bet/day6dlc.rpy:1744
translate Spanish day6dlc_start2_f0c13cf5:

    # player "My window is completely closed right now, so my cold didn't come from that."
    player "Mi ventana está completamente cerrada ahora mismo, así que mi resfriado no vino de ahí."

# game/beyond the bet/day6dlc.rpy:1747
translate Spanish day6dlc_start2_e3c543cf:

    # player "That's classified."
    player "Eso es confidencial."

# game/beyond the bet/day6dlc.rpy:1748
translate Spanish day6dlc_start2_85fc7430:

    # GR "no it is not."
    GR "no, no lo es."

# game/beyond the bet/day6dlc.rpy:1751
translate Spanish day6dlc_start2_4faf0e7c:

    # player "Highly classified on all levels."
    player "Altamente confidencial a todos los niveles."

# game/beyond the bet/day6dlc.rpy:1754
translate Spanish day6dlc_start2_2b9da715:

    # player "Their files have big red warning labels on them and all."
    player "Sus expedientes tienen grandes etiquetas rojas de advertencia y todo."

# game/beyond the bet/day6dlc.rpy:1755
translate Spanish day6dlc_start2_696d2d83:

    # GR "you don't know their names, do you?"
    GR "no sabes sus nombres, ¿verdad?"

# game/beyond the bet/day6dlc.rpy:1758
translate Spanish day6dlc_start2_6bd97f64:

    # player "Of course I do."
    player "Claro que sí."

# game/beyond the bet/day6dlc.rpy:1759
translate Spanish day6dlc_start2_b5c8e54c:

    # GR "well?"
    GR "¿entonces?"

# game/beyond the bet/day6dlc.rpy:1762
translate Spanish day6dlc_start2_87b41c77:

    # player "Nuh uh mister!"
    player "¡Ni hablar, señor!"

# game/beyond the bet/day6dlc.rpy:1765
translate Spanish day6dlc_start2_ab346de9:

    # player "Access denied!"
    player "¡Acceso denegado!"

# game/beyond the bet/day6dlc.rpy:1766
translate Spanish day6dlc_start2_b6cc8755:

    # GR "fine, i will have to find it out myself."
    GR "bien, tendré que averiguarlo yo mismo."

# game/beyond the bet/day6dlc.rpy:1767
translate Spanish day6dlc_start2_b896c066:

    # GR "these neighbours must be suspicious people."
    GR "estos vecinos deben de ser gente sospechosa."

# game/beyond the bet/day6dlc.rpy:1768
translate Spanish day6dlc_start2_b44120e3:

    # GR "i will return to that on a later date. for now, your illness."
    GR "retomaré ese tema más adelante. por ahora, tu enfermedad."

# game/beyond the bet/day6dlc.rpy:1771
translate Spanish day6dlc_start2_153c26e9:

    # player "...No, I don't..."
    player "...No, no los sé..."

# game/beyond the bet/day6dlc.rpy:1772
translate Spanish day6dlc_start2_8a87fc6c:

    # GR "and how long have you lived there?"
    GR "¿y cuánto tiempo llevas viviendo ahí?"

# game/beyond the bet/day6dlc.rpy:1775
translate Spanish day6dlc_start2_3704a528_1:

    # player "Um..."
    player "Eh..."

# game/beyond the bet/day6dlc.rpy:1778
translate Spanish day6dlc_start2_f0eafb90:

    # player "A little while..."
    player "Un tiempito..."

# game/beyond the bet/day6dlc.rpy:1780
translate Spanish day6dlc_start2_767c562a:

    # GR "i am judging you right now."
    GR "te estoy juzgando ahora mismo."

# game/beyond the bet/day6dlc.rpy:1784
translate Spanish day6dlc_start2_0abf0831:

    # player "Come on, you don't know all your neighbors."
    player "Anda, tú tampoco conoces a todos tus vecinos."

# game/beyond the bet/day6dlc.rpy:1786
translate Spanish day6dlc_start2_45eb49b1:

    # GR "i, at least, learned their names."
    GR "yo, al menos, aprendí sus nombres."

# game/beyond the bet/day6dlc.rpy:1787
translate Spanish day6dlc_start2_a53c3fc7:

    # GR "then i knew who i was avoiding."
    GR "así sabía a quién estaba evitando."

# game/beyond the bet/day6dlc.rpy:1791
translate Spanish day6dlc_start2_a2dd5f34:

    # player "I like your style."
    player "Me gusta tu estilo."

# game/beyond the bet/day6dlc.rpy:1792
translate Spanish day6dlc_start2_a798a742:

    # GR "yes, my style is impeccable."
    GR "sí, mi estilo es impecable."

# game/beyond the bet/day6dlc.rpy:1793
translate Spanish day6dlc_start2_b53312bf:

    # GR "speaking of style..."
    GR "hablando de estilo..."

# game/beyond the bet/day6dlc.rpy:1795
translate Spanish day6dlc_start2_0f82e6df:

    # player "Now you're speaking my language."
    player "Ahora sí hablas mi idioma."

# game/beyond the bet/day6dlc.rpy:1796
translate Spanish day6dlc_start2_d645503e:

    # GR "i already did that."
    GR "ya lo hacía."

# game/beyond the bet/day6dlc.rpy:1800
translate Spanish day6dlc_start2_752bfc39:

    # player "It's a figure of speech."
    player "Es una figura retórica."

# game/beyond the bet/day6dlc.rpy:1803
translate Spanish day6dlc_start2_fa66afda:

    # player "Wait a second."
    player "Espera un segundo."

# game/beyond the bet/day6dlc.rpy:1807
translate Spanish day6dlc_start2_612ad57b:

    # player "What language do they speak in the Underworld, anyway?"
    player "¿Qué idioma hablan en el Inframundo, por cierto?"

# game/beyond the bet/day6dlc.rpy:1810
translate Spanish day6dlc_start2_6434a3b1:

    # player "It must be a miracle we both speak the same language."
    player "Debe de ser un milagro que hablemos el mismo idioma."

# game/beyond the bet/day6dlc.rpy:1812
translate Spanish day6dlc_start2_b8ba11a9:

    # GR "it is no miracle."
    GR "no es ningún milagro."

# game/beyond the bet/day6dlc.rpy:1813
translate Spanish day6dlc_start2_a676cc34:

    # GR "i could speak every language from the moment of my creation."
    GR "podía hablar todos los idiomas desde el momento de mi creación."

# game/beyond the bet/day6dlc.rpy:1816
translate Spanish day6dlc_start2_f4fbcb49:

    # player "What the hell."
    player "Qué demonios."

# game/beyond the bet/day6dlc.rpy:1819
translate Spanish day6dlc_start2_a00f0a7e:

    # player "How's that fair?"
    player "¿Y eso cómo es justo?"

# game/beyond the bet/day6dlc.rpy:1821
translate Spanish day6dlc_start2_a3fa7bd5:

    # GR "it is not."
    GR "no lo es."

# game/beyond the bet/day6dlc.rpy:1825
translate Spanish day6dlc_start2_fed8430c:

    # player "No shit."
    player "Ni que lo digas."

# game/beyond the bet/day6dlc.rpy:1828
translate Spanish day6dlc_start2_34a888dd:

    # player "Where do I sign up?"
    player "¿Dónde me apunto?"

# game/beyond the bet/day6dlc.rpy:1830
translate Spanish day6dlc_start2_b98f2673:

    # GR "you're a little too mortal for their tastes, my apologies."
    GR "eres demasiado mortal para su gusto, mis disculpas."

# game/beyond the bet/day6dlc.rpy:1831
translate Spanish day6dlc_start2_b2edb2f5:

    # GR "especially considering you are sick."
    GR "sobre todo considerando que estás enferm[letra]."

# game/beyond the bet/day6dlc.rpy:1832
translate Spanish day6dlc_start2_1a474520:

    # GR "speaking of..."
    GR "hablando de eso..."

# game/beyond the bet/day6dlc.rpy:1837
translate Spanish day6dlc_start2_8823b7d8:

    # player "Left it wide open for you."
    player "La dejé abierta de par en par para ti."

# game/beyond the bet/day6dlc.rpy:1838
translate Spanish day6dlc_start2_2854b65d:

    # GR "what a foolish decision."
    GR "qué decisión tan necia."

# game/beyond the bet/day6dlc.rpy:1839
translate Spanish day6dlc_start2_77684131:

    # GR "anyone could've slipped in."
    GR "cualquiera podría haberse colado."

# game/beyond the bet/day6dlc.rpy:1842
translate Spanish day6dlc_start2_7712cc66:

    # player "I live on the fifth floor Grim, you know that."
    player "Vivo en el quinto piso, Parca, lo sabes."

# game/beyond the bet/day6dlc.rpy:1843
translate Spanish day6dlc_start2_dc555203:

    # GR "there are others like me."
    GR "hay otros como yo."

# game/beyond the bet/day6dlc.rpy:1844
translate Spanish day6dlc_start2_1104ac3d:

    # GR "and beside that, what if a wild animal climbed the outer walls and jumped in your window?"
    GR "y además, ¿y si un animal salvaje trepara por los muros exteriores y saltara por tu ventana?"

# game/beyond the bet/day6dlc.rpy:1847
translate Spanish day6dlc_start2_d8e445ea:

    # player "Ah, yes, all those midcity wild animals."
    player "Ah, sí, todos esos animales salvajes del centro de la ciudad."

# game/beyond the bet/day6dlc.rpy:1850
translate Spanish day6dlc_start2_acb8653d:

    # player "I feel like the chances of that are PRETTY slim."
    player "Siento que las probabilidades de eso son BASTANTE escasas."

# game/beyond the bet/day6dlc.rpy:1851
translate Spanish day6dlc_start2_1271a944:

    # GR "but a chance nonetheless."
    GR "pero hay una probabilidad, aun así."

# game/beyond the bet/day6dlc.rpy:1852
translate Spanish day6dlc_start2_d49153f2:

    # GR "you have little care for your own well-being."
    GR "te importa poco tu propio bienestar."

# game/beyond the bet/day6dlc.rpy:1855
translate Spanish day6dlc_start2_9fc00178:

    # player "I mean this in the kindest way possible, but that is SO ironic coming from you."
    player "Lo digo con la mejor intención, pero eso es TAN irónico viniendo de ti."

# game/beyond the bet/day6dlc.rpy:1856
translate Spanish day6dlc_start2_a0396c30:

    # GR "death is not the end."
    GR "la muerte no es el final."

# game/beyond the bet/day6dlc.rpy:1857
translate Spanish day6dlc_start2_1394a97b:

    # GR "wanting to move your soul to the afterlife is not necessarily a bad thing for your well-being."
    GR "querer llevar tu alma al más allá no es necesariamente malo para tu bienestar."

# game/beyond the bet/day6dlc.rpy:1858
translate Spanish day6dlc_start2_e5fee42c:

    # GR "for some people, it is a blessing."
    GR "para algunas personas, es una bendición."

# game/beyond the bet/day6dlc.rpy:1859
translate Spanish day6dlc_start2_904683c2:

    # GR "life can be painful and lonely. what comes after is not so."
    GR "la vida puede ser dolorosa y solitaria. lo que viene después no lo es."

# game/beyond the bet/day6dlc.rpy:1862
translate Spanish day6dlc_start2_ffa4436c:

    # player "I guess I never thought about it like that."
    player "Supongo que nunca lo había pensado así."

# game/beyond the bet/day6dlc.rpy:1865
translate Spanish day6dlc_start2_031b7007:

    # player "Still, I'm perfectly healthy (usually) and way too young to die."
    player "Aun así, estoy perfectamente san[letra] (normalmente) y soy demasiado joven para morir."

# game/beyond the bet/day6dlc.rpy:1868
translate Spanish day6dlc_start2_5a4d5828:

    # player "I'd say in this case..."
    player "Diría que en este caso..."

# game/beyond the bet/day6dlc.rpy:1871
translate Spanish day6dlc_start2_2d81719a:

    # player "Causing accidents trying to take my soul is probably not good for my well-being."
    player "Causar accidentes para intentar llevarte mi alma probablemente no sea bueno para mi bienestar."

# game/beyond the bet/day6dlc.rpy:1873
translate Spanish day6dlc_start2_355d3770:

    # GR "that is beside the point, anyway. we are not talking about me."
    GR "eso es irrelevante, de todos modos. no estamos hablando de mí."

# game/beyond the bet/day6dlc.rpy:1874
translate Spanish day6dlc_start2_33ec56ea:

    # GR "we are talking about the countless wild animals that could be razing your apartment as we speak."
    GR "estamos hablando de los innumerables animales salvajes que podrían estar arrasando tu apartamento en este mismo momento."

# game/beyond the bet/day6dlc.rpy:1877
translate Spanish day6dlc_start2_64b3b411:

    # player "I think I'd notice that."
    player "Creo que lo notaría."

# game/beyond the bet/day6dlc.rpy:1878
translate Spanish day6dlc_start2_231e29b5:

    # GR "they could be tiny."
    GR "podrían ser diminutos."

# game/beyond the bet/day6dlc.rpy:1881
translate Spanish day6dlc_start2_011cf8a7:

    # player "What, you think a colony of ants is going to destroy my room?"
    player "¿Qué, crees que una colonia de hormigas va a destruir mi cuarto?"

# game/beyond the bet/day6dlc.rpy:1882
translate Spanish day6dlc_start2_53b531c0:

    # GR "crazier things have happened."
    GR "han pasado cosas más locas."

# game/beyond the bet/day6dlc.rpy:1885
translate Spanish day6dlc_start2_3060aa1e:

    # player "Okay, well, I think the invisible colony of ants hasn't caused my flu, Grim."
    player "Okey, bueno, creo que la colonia invisible de hormigas no me causó la gripe, Parca."

# game/beyond the bet/day6dlc.rpy:1886
translate Spanish day6dlc_start2_1b35770b:

    # GR "likely not."
    GR "probablemente no."

# game/beyond the bet/day6dlc.rpy:1887
translate Spanish day6dlc_start2_a20d7a17:

    # GR "but it is not impossible."
    GR "pero no es imposible."

# game/beyond the bet/day6dlc.rpy:1888
translate Spanish day6dlc_start2_eeefe827:

    # GR "i suppose i should turn to the more mundane..."
    GR "supongo que debería recurrir a lo más mundano..."

# game/beyond the bet/day6dlc.rpy:1891
translate Spanish day6dlc_start2_c19f189e:

    # player "Maybe they'll be friendly."
    player "Quizá sean amistosos."

# game/beyond the bet/day6dlc.rpy:1892
translate Spanish day6dlc_start2_39aae0db:

    # GR "ooooor... maybe they plan to eat your pet."
    GR "ooooo... quizá planean comerse a tu mascota."

# game/beyond the bet/day6dlc.rpy:1895
translate Spanish day6dlc_start2_c6abc9f0:

    # player "Nooooo! Don't even joke about that!"
    player "¡¡Nooooo!! ¡Ni bromees con eso!"

# game/beyond the bet/day6dlc.rpy:1897
translate Spanish day6dlc_start2_e46bc822:

    # GR "i'd advise caution, then."
    GR "aconsejaría precaución, entonces."

# game/beyond the bet/day6dlc.rpy:1898
translate Spanish day6dlc_start2_5a9b4762:

    # GR "some beasts can invade even through the smallest of gaps."
    GR "algunas bestias pueden invadir incluso por los resquicios más pequeños."

# game/beyond the bet/day6dlc.rpy:1901
translate Spanish day6dlc_start2_d8d4d361:

    # player "Shut uppppp."
    player "Cállateeeee."

# game/beyond the bet/day6dlc.rpy:1904
translate Spanish day6dlc_start2_87cd300d:

    # player "There's no wild animals invading my apartment through the window!"
    player "¡No hay animales salvajes invadiendo mi apartamento por la ventana!"

# game/beyond the bet/day6dlc.rpy:1905
translate Spanish day6dlc_start2_aa0ebc53:

    # GR "not yet."
    GR "todavía no."

# game/beyond the bet/day6dlc.rpy:1909
translate Spanish day6dlc_start2_b515fa49:

    # player "For someone I like, you're really the worst, you know that?"
    player "Mira que me gustas, pero eres lo peor, ¿sabías?"

# game/beyond the bet/day6dlc.rpy:1910
translate Spanish day6dlc_start2_fb937206:

    # GR "thank you."
    GR "gracias."

# game/beyond the bet/day6dlc.rpy:1914
translate Spanish day6dlc_start2_3a339bef:

    # player "Not a compliment."
    player "No es un cumplido."

# game/beyond the bet/day6dlc.rpy:1916
translate Spanish day6dlc_start2_4556a7c5:

    # GR "i will happily take it as one. it does wonders for my ego, you know, getting compliments."
    GR "lo aceptaré con gusto como un cumplido. le hace maravillas a mi ego, ¿sabes?, recibir cumplidos."

# game/beyond the bet/day6dlc.rpy:1917
translate Spanish day6dlc_start2_6ae9b5b0:

    # GR "but, yes, there are likely no wild animals that have caused your flu, so..."
    GR "pero, sí, probablemente ningún animal salvaje te causó la gripe, así que..."

# game/beyond the bet/day6dlc.rpy:1924
translate Spanish day6dlc_start2_f90bf323:

    # player "Maybe a smiiiidge."
    player "Quizá un poquiiito."

# game/beyond the bet/day6dlc.rpy:1927
translate Spanish day6dlc_start2_1722d067:

    # player "Like a teeny weeny smidge."
    player "Un poquitito chiquitito."

# game/beyond the bet/day6dlc.rpy:1930
translate Spanish day6dlc_start2_daa93a11:

    # player "Just enough that a Grim Reaper could sneak in if he wanted to."
    player "Lo justo para que una Parca pudiera colarse si quisiera."

# game/beyond the bet/day6dlc.rpy:1931
translate Spanish day6dlc_start2_c83d6bce:

    # GR "very irresponsible."
    GR "muy irresponsable."

# game/beyond the bet/day6dlc.rpy:1932
translate Spanish day6dlc_start2_1066f492:

    # GR "but realistically, even if it were closed, that would not stop me. "
    GR "pero siendo realistas, aunque estuviera cerrada, eso no me detendría."

# game/beyond the bet/day6dlc.rpy:1935
translate Spanish day6dlc_start2_1f93dc39:

    # player "That does not surprise me in the slightest."
    player "Eso no me sorprende en lo más mínimo."

# game/beyond the bet/day6dlc.rpy:1938
translate Spanish day6dlc_start2_b6f142c2:

    # player "You throw pianos from twenty stories up at innocent people (me)."
    player "Lanzas pianos desde veinte pisos de altura a gente inocente (yo)."

# game/beyond the bet/day6dlc.rpy:1941
translate Spanish day6dlc_start2_3efd2e34:

    # player "May as well add breaking and entering onto your rap sheet as well."
    player "Bien podrías añadir allanamiento de morada a tus antecedentes."

# game/beyond the bet/day6dlc.rpy:1942
translate Spanish day6dlc_start2_fff41f00:

    # GR "i believe i've told you before that your mortal laws do not apply to me."
    GR "creo que ya te dije antes que tus leyes mortales no se aplican a mí."

# game/beyond the bet/day6dlc.rpy:1943
translate Spanish day6dlc_start2_adf6ca76:

    # GR "and even if they did, they would be unable to catch me."
    GR "y aunque se aplicaran, no podrían atraparme."

# game/beyond the bet/day6dlc.rpy:1944
translate Spanish day6dlc_start2_d0d8f445:

    # GR "i am like an eel. far too slippery."
    GR "soy como una anguila. demasiado escurridizo."

# game/beyond the bet/day6dlc.rpy:1947
translate Spanish day6dlc_start2_a011099a:

    # player "Ah, yes. Slippery eel Casper."
    player "Ah, sí. Casper, la anguila escurridiza."

# game/beyond the bet/day6dlc.rpy:1950
translate Spanish day6dlc_start2_684de666:

    # player "I've always thought you were giving {i}'eel'{/i}."
    player "Siempre pensé que tenías algo de {i}'anguila'{/i}."

# game/beyond the bet/day6dlc.rpy:1951
translate Spanish day6dlc_start2_44d72bbb:

    # GR "i did not mean i was actually like an eel, minus their slipperiness."
    GR "no quise decir que fuera realmente como una anguila, aparte de lo escurridiza."

# game/beyond the bet/day6dlc.rpy:1954
translate Spanish day6dlc_start2_e641d54f:

    # player "No, but there's some similarities, isn't there?"
    player "No, pero hay algunas similitudes, ¿no?"

# game/beyond the bet/day6dlc.rpy:1957
translate Spanish day6dlc_start2_1c4c2212:

    # player "You like axolotls. Those are kinda similar."
    player "Te gustan los ajolotes. Esos son medio parecidos."

# game/beyond the bet/day6dlc.rpy:1958
translate Spanish day6dlc_start2_2e3e21f2:

    # GR "they are not similar at all."
    GR "no se parecen en nada."

# game/beyond the bet/day6dlc.rpy:1959
translate Spanish day6dlc_start2_91beba19:

    # GR "this is what mortals call 'a stretch'."
    GR "esto es lo que los mortales llaman 'una comparación rebuscada'."

# game/beyond the bet/day6dlc.rpy:1962
translate Spanish day6dlc_start2_a256465f:

    # player "You're the one who said you were like an eel."
    player "Tú fuiste quien dijo que eras como una anguila."

# game/beyond the bet/day6dlc.rpy:1963
translate Spanish day6dlc_start2_3f91067b:

    # GR "i take it back, then."
    GR "entonces lo retiro."

# game/beyond the bet/day6dlc.rpy:1966
translate Spanish day6dlc_start2_52b377f8:

    # player "Look, Mister Eel Reaper, it doesn't matter if I left the window open anyway."
    player "Mira, Señor Parca Anguila, no importa si dejé la ventana abierta de todos modos."

# game/beyond the bet/day6dlc.rpy:1969
translate Spanish day6dlc_start2_122e8751:

    # player "I do that all the time. I don't think that's what made me sick."
    player "Lo hago todo el tiempo. No creo que eso me enfermara."

# game/beyond the bet/day6dlc.rpy:1971
translate Spanish day6dlc_start2_76f05611:

    # GR "mister eel reaper..."
    GR "señor parca anguila..."

# game/beyond the bet/day6dlc.rpy:1972
translate Spanish day6dlc_start2_ad6c7f8d:

    # GR "fine."
    GR "bien."

# game/beyond the bet/day6dlc.rpy:1975
translate Spanish day6dlc_start2_898c1d16:

    # player "I think you mean like a slug or a worm."
    player "Creo que te refieres más a una babosa o un gusano."

# game/beyond the bet/day6dlc.rpy:1976
translate Spanish day6dlc_start2_2b14968e:

    # GR "a... slug? you think me similar to a SLUG?"
    GR "una... ¿babosa? ¿piensas que me parezco a una BABOSA?"

# game/beyond the bet/day6dlc.rpy:1977
translate Spanish day6dlc_start2_9a337ace:

    # GR "or a WORM?"
    GR "¿o a un GUSANO?"

# game/beyond the bet/day6dlc.rpy:1978
translate Spanish day6dlc_start2_c560f19c:

    # GR "that is... beyond shameful. i have never been so insulted."
    GR "eso es... más que vergonzoso. jamás me habían insultado tanto."

# game/beyond the bet/day6dlc.rpy:1981
translate Spanish day6dlc_start2_42b22e6a:

    # player "You'd be a cute worm or slug though!"
    player "¡Pero serías un gusano o una babosa muy lindos!"

# game/beyond the bet/day6dlc.rpy:1984
translate Spanish day6dlc_start2_b6fab900:

    # player "Don't worry, I'd still like you if you were a worm, or a slug."
    player "Tranquilo, me seguirías gustando aunque fueras un gusano o una babosa."

# game/beyond the bet/day6dlc.rpy:1985
translate Spanish day6dlc_start2_4ebf9ce9:

    # GR "that would make one of us."
    GR "serías la única persona a la que le gustaría."

# game/beyond the bet/day6dlc.rpy:1988
translate Spanish day6dlc_start2_9218c453:

    # player "Or a snail, you seem like the kinda guy to have a shell."
    player "O un caracol, pareces del tipo que tiene caparazón."

# game/beyond the bet/day6dlc.rpy:1991
translate Spanish day6dlc_start2_a4f21990:

    # player "All those outer walls to keep everyone out."
    player "Todos esos muros exteriores para mantener a todos afuera."

# game/beyond the bet/day6dlc.rpy:1994
translate Spanish day6dlc_start2_f4851359:

    # GR "what is with your obsession with shelled creatures? First it was ninja tortoises, now it is ninja snails?"
    GR "¿qué es esa obsesión tuya con las criaturas con caparazón? primero fueron las tortugas ninja, ¿y ahora caracoles ninja?"

# game/beyond the bet/day6dlc.rpy:1996
translate Spanish day6dlc_start2_1fac1904:

    # GR "i've had plenty of pointless conversations in my long life, but this has got to take the cake."
    GR "he tenido muchas conversaciones inútiles en mi larga vida, pero esta se lleva el premio."

# game/beyond the bet/day6dlc.rpy:2002
translate Spanish day6dlc_start2_65998c22:

    # player "Do you think I had a shell in my past life?"
    player "¿Crees que tuve caparazón en mi vida pasada?"

# game/beyond the bet/day6dlc.rpy:2003
translate Spanish day6dlc_start2_60293287:

    # GR "those are words you chose to type out for me to read. wow."
    GR "esas son palabras que elegiste escribir para que las lea. wow."

# game/beyond the bet/day6dlc.rpy:2006
translate Spanish day6dlc_start2_199a3ef2:

    # player "But do you think I did?"
    player "¿Pero crees que sí?"

# game/beyond the bet/day6dlc.rpy:2007
translate Spanish day6dlc_start2_80e3a45b:

    # GR "who said reincarnation existed, mortal?"
    GR "¿quién dijo que existía la reencarnación, mortal?"

# game/beyond the bet/day6dlc.rpy:2010
translate Spanish day6dlc_start2_90c42201:

    # player "Not you, my cute little reaper slug :( you don't tell me anything!"
    player "Tú no, mi linda parquita babosa :( ¡no me cuentas nada!"

# game/beyond the bet/day6dlc.rpy:2011
translate Spanish day6dlc_start2_0070a333:

    # GR "i shouldn't have mentioned the eel..."
    GR "no debí mencionar la anguila..."

# game/beyond the bet/day6dlc.rpy:2012
translate Spanish day6dlc_start2_69b02e65:

    # GR "i'm choosing to move on from this... this conversation is beyond stupid."
    GR "prefiero dejar esto atrás... esta conversación es el colmo de la estupidez."

# game/beyond the bet/day6dlc.rpy:2013
translate Spanish day6dlc_start2_e76ebe1b:

    # GR "back to the issue at hand. your illness, and your lack of explanation for it."
    GR "volviendo al asunto que nos ocupa. tu enfermedad, y que no me des explicación alguna."

# game/beyond the bet/day6dlc.rpy:2020
translate Spanish day6dlc_start2_edc31972:

    # player "I didn't leave it open for you. Obviously it's open for Jeremy."
    player "No la dejé abierta para ti. Obviamente está abierta para Jeremy."

# game/beyond the bet/day6dlc.rpy:2021
translate Spanish day6dlc_start2_49182c68:

    # GR "that good-for-nothing vermin..."
    GR "esa alimaña inútil..."

# game/beyond the bet/day6dlc.rpy:2022
translate Spanish day6dlc_start2_158183e5:

    # GR "he is a dead man walking."
    GR "es un hombre muerto que aun camina."

# game/beyond the bet/day6dlc.rpy:2025
translate Spanish day6dlc_start2_76e239a5:

    # player "Levitating."
    player "Levita."

# game/beyond the bet/day6dlc.rpy:2026
translate Spanish day6dlc_start2_7772a27d_30:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:2027
translate Spanish day6dlc_start2_c9034363:

    # GR "levitating, walking, that matters not."
    GR "levita, camina, eso no importa."

# game/beyond the bet/day6dlc.rpy:2030
translate Spanish day6dlc_start2_1372ffda:

    # player "Okay, okay, don't get your panties in a twist."
    player "Okey, okey, no te pongas así."

# game/beyond the bet/day6dlc.rpy:2033
translate Spanish day6dlc_start2_1fccf5ce:

    # player "It was opened a crack for you."
    player "La dejé entreabierta para ti."

# game/beyond the bet/day6dlc.rpy:2036
translate Spanish day6dlc_start2_6d69b119:

    # player "Jeremy knows how to knock on the door."
    player "Jeremy sabe tocar la puerta."

# game/beyond the bet/day6dlc.rpy:2039
translate Spanish day6dlc_start2_a101530b:

    # player "Such a gentleman."
    player "Todo un caballero."

# game/beyond the bet/day6dlc.rpy:2042
translate Spanish day6dlc_start2_89c3655a:

    # player "jk ;)"
    player "es broma ;)"

# game/beyond the bet/day6dlc.rpy:2045
translate Spanish day6dlc_start2_54f9bc03:

    # player "Jeremy has a key if he needs one."
    player "Jeremy tiene llave, por si la necesita."

# game/beyond the bet/day6dlc.rpy:2046
translate Spanish day6dlc_start2_39be1efb:

    # GR "WHAT!?"
    GR "¡¿QUÉ?!"

# game/beyond the bet/day6dlc.rpy:2049
translate Spanish day6dlc_start2_d5afb473:

    # player "I'm messing with you, Grimmy."
    player "Te estoy molestando, Parquita."

# game/beyond the bet/day6dlc.rpy:2052
translate Spanish day6dlc_start2_9f41bbc4:

    # player "Just pulling your leg :D"
    player "Solo te estoy tomando el pelo :D"

# game/beyond the bet/day6dlc.rpy:2053
translate Spanish day6dlc_start2_7772a27d_31:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:2056
translate Spanish day6dlc_start2_a9795d98:

    # player "You are the only reaper for me, don't worry Casper."
    player "Tú eres la única parca para mí, tranquilo Casper."

# game/beyond the bet/day6dlc.rpy:2057
translate Spanish day6dlc_start2_d40b8a29:

    # GR "hmph. that much is obvious."
    GR "hmph. eso es obvio."

# game/beyond the bet/day6dlc.rpy:2058
translate Spanish day6dlc_start2_ca44f7b6:

    # GR "you are mine."
    GR "eres mí[letra]."

# game/beyond the bet/day6dlc.rpy:2059
translate Spanish day6dlc_start2_432c5b7e:

    # GR "every aspect of you is destined for me."
    GR "cada aspecto de ti está destinado a mí."

# game/beyond the bet/day6dlc.rpy:2062
translate Spanish day6dlc_start2_7f43650a:

    # player "Wow, I'm swooning Grim."
    player "Wow, me estoy derritiendo, Parca."

# game/beyond the bet/day6dlc.rpy:2065
translate Spanish day6dlc_start2_1677419b:

    # player "Come take every aspect of me ;)"
    player "Ven a llevarte cada aspecto de mí ;)"

# game/beyond the bet/day6dlc.rpy:2066
translate Spanish day6dlc_start2_7772a27d_32:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:2067
translate Spanish day6dlc_start2_49564bf5:

    # GR "you are sick."
    GR "estás enferm[letra]."

# game/beyond the bet/day6dlc.rpy:2068
translate Spanish day6dlc_start2_57bc1df4:

    # GR "nothing will be taken until we work out why."
    GR "no me llevaré nada hasta que averigüemos por qué."

# game/beyond the bet/day6dlc.rpy:2069
translate Spanish day6dlc_start2_3544e65e:

    # GR "speaking of the issue..."
    GR "hablando del asunto..."

# game/beyond the bet/day6dlc.rpy:2072
translate Spanish day6dlc_start2_df39b71a:

    # GR "did you forget to wear a coat when you left your apartment?"
    GR "¿olvidaste ponerte un abrigo al salir de tu apartamento?"

# game/beyond the bet/day6dlc.rpy:2075
translate Spanish day6dlc_start2_05e1dd35:

    # player "It's just a cold, Grim."
    player "Solo es un resfriado, Parca."

# game/beyond the bet/day6dlc.rpy:2078
translate Spanish day6dlc_start2_26e6c2c9:

    # player "It happens to everyone. It's super common."
    player "Le pasa a todo el mundo. Es súper común."

# game/beyond the bet/day6dlc.rpy:2079
translate Spanish day6dlc_start2_1836b526:

    # GR "it does not happen to everyone."
    GR "no le pasa a todo el mundo."

# game/beyond the bet/day6dlc.rpy:2080
translate Spanish day6dlc_start2_83646711:

    # GR "it is an illness purely for mortals."
    GR "es una enfermedad exclusiva de los mortales."

# game/beyond the bet/day6dlc.rpy:2083
translate Spanish day6dlc_start2_1a2ceea1:

    # player "Sure, but it's not a big deal. It's just a bit inconvenient."
    player "Claro, pero no es para tanto. Es solo un poco molesto."

# game/beyond the bet/day6dlc.rpy:2086
translate Spanish day6dlc_start2_505eb958:

    # player "But, hey, it means I can talk to you some more."
    player "Pero, oye, significa que puedo hablar más contigo."

# game/beyond the bet/day6dlc.rpy:2087
translate Spanish day6dlc_start2_573e9a25:

    # GR "how so? i don't see what stops you from talking to me when you're well, too."
    GR "¿cómo así? no veo qué te impide hablar conmigo cuando estás bien también."

# game/beyond the bet/day6dlc.rpy:2090
translate Spanish day6dlc_start2_e7493ea7:

    # player "Well, I'd usually be at work."
    player "Bueno, normalmente estaría en el trabajo."

# game/beyond the bet/day6dlc.rpy:2091
translate Spanish day6dlc_start2_8a1662f6:

    # GR "i speak to you on work hours every day."
    GR "te hablo en horario laboral todos los días."

# game/beyond the bet/day6dlc.rpy:2096
translate Spanish day6dlc_start2_0bca370e:

    # player "If I do that, I'll never get any work done."
    player "Si hago eso, nunca terminaré nada del trabajo."

# game/beyond the bet/day6dlc.rpy:2099
translate Spanish day6dlc_start2_bfe0ee49:

    # player "You're a little distracting, you know." id day6dlc_start2_bfe0ee49
    player "Distraes un poquito, ¿sabes?" id day6dlc_start2_bfe0ee49

# game/beyond the bet/day6dlc.rpy:2100
translate Spanish day6dlc_start2_ad0dd272:

    # GR "in what way?"
    GR "¿en qué sentido?"

# game/beyond the bet/day6dlc.rpy:2103
translate Spanish day6dlc_start2_094b4f8c:

    # player "Well, you talk a lot."
    player "Bueno, hablas mucho."

# game/beyond the bet/day6dlc.rpy:2104
translate Spanish day6dlc_start2_a24a55c7:

    # GR "i talk a normal amount!"
    GR "¡hablo una cantidad normal!"

# game/beyond the bet/day6dlc.rpy:2107
translate Spanish day6dlc_start2_d5b21d25:

    # player "You're kinda a yapper, Grim."
    player "Eres como una cotorra, Parca."

# game/beyond the bet/day6dlc.rpy:2108
translate Spanish day6dlc_start2_7772a27d_33:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:2109
translate Spanish day6dlc_start2_576279ad:

    # GR "Well, this yapper wants to know something."
    GR "Bueno, esta cotorra quiere saber algo."

# game/beyond the bet/day6dlc.rpy:2112
translate Spanish day6dlc_start2_0bf63b2f:

    # player "And that is?"
    player "¿Y eso qué es?"

# game/beyond the bet/day6dlc.rpy:2117
translate Spanish day6dlc_start2_6dbf02dc:

    # player "Okay, well, if I do that I'll probably get fired."
    player "Okey, pero si hago eso probablemente me despidan."

# game/beyond the bet/day6dlc.rpy:2118
translate Spanish day6dlc_start2_9fd9a76d_1:

    # GR "why?"
    GR "¿por qué?"

# game/beyond the bet/day6dlc.rpy:2119
translate Spanish day6dlc_start2_2faa9992:

    # GR "as long as you get your required work done, why should whatever else you do matter?"
    GR "mientras termines el trabajo requerido, ¿por qué debería importar lo demás que hagas?"

# game/beyond the bet/day6dlc.rpy:2122
translate Spanish day6dlc_start2_3459b330:

    # player "To be honest, that's how I feel too."
    player "Para ser sincer[letra], yo también lo siento así."

# game/beyond the bet/day6dlc.rpy:2125
translate Spanish day6dlc_start2_1c43d278:

    # player "Alas, my boss wouldn't agree."
    player "Por desgracia, mi jefe no estaría de acuerdo."

# game/beyond the bet/day6dlc.rpy:2126
translate Spanish day6dlc_start2_fc4cdaa0:

    # GR "well, i think you should let this boss of yours know that you may speak to whoever you wish."
    GR "bien, creo que deberías hacerle saber a ese jefe tuyo que puedes hablar con quien desees."

# game/beyond the bet/day6dlc.rpy:2130
translate Spanish day6dlc_start2_f9d4d148:

    # player "I'll be right on that."
    player "Ahora mismo me pongo a ello."

# game/beyond the bet/day6dlc.rpy:2134
translate Spanish day6dlc_start2_e67f3e2a:

    # player "'Excuse me sir, the Grim Reaper wants to chat, bye'!"
    player "'Disculpe, señor, la Parca quiere charlar, ¡adiós!'"

# game/beyond the bet/day6dlc.rpy:2135
translate Spanish day6dlc_start2_9c80b90d:

    # GR "you are rehearsing it. good."
    GR "lo estás ensayando. bien."

# game/beyond the bet/day6dlc.rpy:2136
translate Spanish day6dlc_start2_bc15a4bd:

    # GR "perhaps say that if he gets in the way, he may find his life cut short."
    GR "quizá dile que, si se interpone, su vida podría acortarse."

# game/beyond the bet/day6dlc.rpy:2140
translate Spanish day6dlc_start2_7ba589f9:

    # player "You wouldn't do that."
    player "Tú no harías eso."

# game/beyond the bet/day6dlc.rpy:2142
translate Spanish day6dlc_start2_e48a4211:

    # GR "he does not know that."
    GR "él no lo sabe."

# game/beyond the bet/day6dlc.rpy:2146
translate Spanish day6dlc_start2_b8a0f60c:

    # player "I don't think he'd believe me."
    player "No creo que me crea."

# game/beyond the bet/day6dlc.rpy:2150
translate Spanish day6dlc_start2_5656386b:

    # player "But what does that matter? I'm meant to die today or tomorrow."
    player "Pero ¿qué importa? Se supone que moriré hoy o mañana."

# game/beyond the bet/day6dlc.rpy:2152
translate Spanish day6dlc_start2_950c63bc:

    # GR "if this illness does not take you first..."
    GR "si esta enfermedad no te lleva antes..."

# game/beyond the bet/day6dlc.rpy:2156
translate Spanish day6dlc_start2_fa41fa85:

    # player "IT'S A COLD."
    player "ES UN RESFRIADO."

# game/beyond the bet/day6dlc.rpy:2158
translate Spanish day6dlc_start2_97df8387:

    # GR "an unexplained illness..."
    GR "una enfermedad inexplicada..."

# game/beyond the bet/day6dlc.rpy:2159
translate Spanish day6dlc_start2_891f4bf1:

    # GR "you must have some idea."
    GR "debes de tener alguna idea."

# game/beyond the bet/day6dlc.rpy:2170
translate Spanish day6dlc_start2_90a8e13a:

    # player "You could try cleaning your glasses."
    player "Podrías intentar limpiarte las gafas."

# game/beyond the bet/day6dlc.rpy:2173
translate Spanish day6dlc_start2_a71f4401:

    # player "You know, if you can't... *see*."
    player "Ya sabes, si no puedes... 'ver'."

# game/beyond the bet/day6dlc.rpy:2174
translate Spanish day6dlc_start2_35ba7107:

    # GR "funny. i do not wear glasses."
    GR "gracioso. no uso gafas."

# game/beyond the bet/day6dlc.rpy:2177
translate Spanish day6dlc_start2_c9d5c769:

    # player "You don't? I could've sworn you had glasses on last night."
    player "¿No? Habría jurado que anoche tenías gafas puestas."

# game/beyond the bet/day6dlc.rpy:2180
translate Spanish day6dlc_start2_585d3f59:

    # player "Huh, weird."
    player "Hmm, qué raro."

# game/beyond the bet/day6dlc.rpy:2181
translate Spanish day6dlc_start2_36fc2ef2:

    # GR "my eyesight is perfect."
    GR "mi vista es perfecta."

# game/beyond the bet/day6dlc.rpy:2182
translate Spanish day6dlc_start2_3931c321:

    # GR "i do not need fancy glass for my eyes."
    GR "no necesito cristales elegantes para mis ojos."

# game/beyond the bet/day6dlc.rpy:2186
translate Spanish day6dlc_start2_719c879c:

    # GR "they suit you, they would not suit me."
    GR "a ti te quedan bien, a mí no me quedarían."

# game/beyond the bet/day6dlc.rpy:2189
translate Spanish day6dlc_start2_a8bc9d69:

    # player "Aww, you like my glasses?"
    player "Aww, ¿te gustan mis gafas?"

# game/beyond the bet/day6dlc.rpy:2190
translate Spanish day6dlc_start2_762bf460:

    # GR "that is what i said."
    GR "eso es lo que dije."

# game/beyond the bet/day6dlc.rpy:2193
translate Spanish day6dlc_start2_3298c816:

    # player "Well, I think they'd suit you plenty."
    player "Pues creo que a ti te quedarían de maravilla."

# game/beyond the bet/day6dlc.rpy:2196
translate Spanish day6dlc_start2_74f34023:

    # player "Next time you come over, you can try them on."
    player "La próxima vez que vengas, puedes probártelas."

# game/beyond the bet/day6dlc.rpy:2199
translate Spanish day6dlc_start2_5d711057:

    # player "Unless you're too scared to come in again."
    player "A menos que te dé demasiado miedo volver a entrar."

# game/beyond the bet/day6dlc.rpy:2200
translate Spanish day6dlc_start2_4f29f8e3:

    # GR "i was not afraid."
    GR "no tenía miedo."

# game/beyond the bet/day6dlc.rpy:2201
translate Spanish day6dlc_start2_cae2de23:

    # GR "i was being polite."
    GR "estaba siendo educado."

# game/beyond the bet/day6dlc.rpy:2202
translate Spanish day6dlc_start2_74c0fd5f:

    # GR "it would not be polite to turn up out of nowhere and expect you to let me in."
    GR "no sería educado aparecer de la nada y esperar que me dejaras entrar."

# game/beyond the bet/day6dlc.rpy:2205
translate Spanish day6dlc_start2_fd65e19a:

    # player "I wouldn't have minded."
    player "A mí no me habría importado."

# game/beyond the bet/day6dlc.rpy:2206
translate Spanish day6dlc_start2_c07bdb81:

    # GR "forget that for the moment."
    GR "olvidemos eso por el momento."

# game/beyond the bet/day6dlc.rpy:2207
translate Spanish day6dlc_start2_3470b90b:

    # GR "as much as i would like to... come to see you again..."
    GR "por mucho que me gustaría... volver a verte..."

# game/beyond the bet/day6dlc.rpy:2208
translate Spanish day6dlc_start2_5bfcc2d4:

    # GR "i need to know something first."
    GR "primero necesito saber algo."

# game/beyond the bet/day6dlc.rpy:2211
translate Spanish day6dlc_start2_1aeabead:

    # GR "however, now that i think on it further, i think you would look.... decent in them."
    GR "sin embargo, ahora que lo pienso más, creo que te verías.... decente con ellas."

# game/beyond the bet/day6dlc.rpy:2214
translate Spanish day6dlc_start2_14366603:

    # player "Just decent?"
    player "¿Solo decente?"

# game/beyond the bet/day6dlc.rpy:2215
translate Spanish day6dlc_start2_11958c3b:

    # GR "perhaps slightly above decent, perhaps not."
    GR "quizá un poco por encima de lo decente, quizá no."

# game/beyond the bet/day6dlc.rpy:2218
translate Spanish day6dlc_start2_be969c62:

    # player "Should I get some, then?"
    player "¿Debería comprarme unas, entonces?"

# game/beyond the bet/day6dlc.rpy:2219
translate Spanish day6dlc_start2_2c903a33:

    # GR "well, do you need them?"
    GR "bueno, ¿las necesitas?"

# game/beyond the bet/day6dlc.rpy:2220
translate Spanish day6dlc_start2_dbe48dd1:

    # GR "i do not believe you are supposed to wear prescription glasses if you do not need them."
    GR "no creo que debas usar gafas graduadas si no las necesitas."

# game/beyond the bet/day6dlc.rpy:2223
translate Spanish day6dlc_start2_d2650962:

    # player "I can just pop out the lenses."
    player "Puedo sacarles los cristales."

# game/beyond the bet/day6dlc.rpy:2227
translate Spanish day6dlc_start2_a7439b74:

    # player "I used to do that when I was a kid with those 3D glasses."
    player "Yo hacía eso de niñ[letra] con esas gafas 3D."

# game/beyond the bet/day6dlc.rpy:2229
translate Spanish day6dlc_start2_ab918d4e:

    # GR "that sounds stupid."
    GR "eso suena tonto."

# game/beyond the bet/day6dlc.rpy:2232
translate Spanish day6dlc_start2_f809a428:

    # player "It was."
    player "Lo era."

# game/beyond the bet/day6dlc.rpy:2235
translate Spanish day6dlc_start2_6d2c64ad:

    # player "But, anyway, no I don't actually need glasses."
    player "Pero, en fin, no, en realidad no necesito gafas."

# game/beyond the bet/day6dlc.rpy:2238
translate Spanish day6dlc_start2_5186ba56:

    # player "I've got, like, 20/10 vision. Maybe even 20/0."
    player "Tengo, como, 20/10 de visión. Quizá hasta 20/0."

# game/beyond the bet/day6dlc.rpy:2239
translate Spanish day6dlc_start2_20194626:

    # GR "right, of course you do."
    GR "claro, por supuesto."

# game/beyond the bet/day6dlc.rpy:2242
translate Spanish day6dlc_start2_3f846d4e:

    # player "I really do."
    player "De verdad."

# game/beyond the bet/day6dlc.rpy:2243
translate Spanish day6dlc_start2_582d4882:

    # GR "i believe less that 1 percent of people in the world have 20/10 vision, mortal."
    GR "creo que menos del 1 por ciento de las personas en el mundo tiene visión 20/10, mortal."

# game/beyond the bet/day6dlc.rpy:2246
translate Spanish day6dlc_start2_30f40b28:

    # player "I'm just that special."
    player "Soy así de especial."

# game/beyond the bet/day6dlc.rpy:2249
translate Spanish day6dlc_start2_26d24eef:

    # player "I'm not some 20/20 normie."
    player "No soy [arti_2] normi 20/20."

# game/beyond the bet/day6dlc.rpy:2250
translate Spanish day6dlc_start2_fc9bf004:

    # GR "what in the hells is a normie?"
    GR "¿qué demonios es un normi?"

# game/beyond the bet/day6dlc.rpy:2251
translate Spanish day6dlc_start2_b64bbce6:

    # GR "is this another of your slang words? i swear, you mortals come up with new, stupid words every single day."
    GR "¿es otra de tus palabras de jerga? juro que los mortales inventan palabras nuevas y estúpidas todos los días."

# game/beyond the bet/day6dlc.rpy:2252
translate Spanish day6dlc_start2_ed70c6c2:

    # GR "i must research this. give me a moment."
    GR "debo investigarla. dame un momento."

# game/beyond the bet/day6dlc.rpy:2255
translate Spanish day6dlc_start2_1a5623f9:

    # player "I think it's cute how you research slang."
    player "Me parece tierno que investigues la jerga."

# game/beyond the bet/day6dlc.rpy:2258
translate Spanish day6dlc_start2_291c66b4:

    # player "It's just terrible when you repeat it back to me."
    player "Lo malo es cuando me la repites."

# game/beyond the bet/day6dlc.rpy:2261
translate Spanish day6dlc_start2_05dbdf2e:

    # player "Ah, yes, the ancient evil Grim Reaper..."
    player "Ah, sí, la antigua y malvada Parca..."

# game/beyond the bet/day6dlc.rpy:2265
translate Spanish day6dlc_start2_6ec68b7f:

    # player "Harvester of souls and keeper of the underworld, telling me my rizz is w."
    player "Cosechador de almas y guardián del inframundo, diciéndome que mi aura es +1000."

# game/beyond the bet/day6dlc.rpy:2267
translate Spanish day6dlc_start2_cf1a5b77:

    # GR "more words for me to search. thank you for furthering my education."
    GR "más palabras que buscar. gracias por ampliar mi educación."

# game/beyond the bet/day6dlc.rpy:2270
translate Spanish day6dlc_start2_7e36a566:

    # player "I feel I've made a mistake."
    player "Siento que cometí un error."

# game/beyond the bet/day6dlc.rpy:2271
translate Spanish day6dlc_start2_43e0b3aa:

    # GR "but i can resume my study later. for now, we must work this out."
    GR "pero puedo retomar mi estudio más tarde. por ahora, debemos resolver esto."

# game/beyond the bet/day6dlc.rpy:2275
translate Spanish day6dlc_start2_18ab2e8b:

    # player "I haven't had my eyes tested in awhile, maybe I should."
    player "Hace un tiempo que no me reviso la vista, quizá debería."

# game/beyond the bet/day6dlc.rpy:2276
translate Spanish day6dlc_start2_e9ad6bd5:

    # GR "i believe making appointments is quite simple in the mortal world, so just do it."
    GR "creo que pedir citas es bastante simple en el mundo mortal, así que hazlo."

# game/beyond the bet/day6dlc.rpy:2279
translate Spanish day6dlc_start2_7f83674c:

    # player "Making phone calls suck, though..."
    player "Hacer llamadas es un asco, eso sí..."

# game/beyond the bet/day6dlc.rpy:2282
translate Spanish day6dlc_start2_80e178a2:

    # player "And, I mean, you're planning to whisk me away to the afterlife soon, right?"
    player "Y, o sea, ¿planeas llevarme pronto al más allá, no?"

# game/beyond the bet/day6dlc.rpy:2285
translate Spanish day6dlc_start2_5aebb945:

    # player "Glasses ain't cheap, or fast."
    player "Las gafas no son baratas, ni rápidas."

# game/beyond the bet/day6dlc.rpy:2289
translate Spanish day6dlc_start2_9b374c96:

    # player "I don't wanna spend my hard earned cash like that."
    player "No quiero gastar así mi dinero ganado con esfuerzo."

# game/beyond the bet/day6dlc.rpy:2293
translate Spanish day6dlc_start2_85d0a75b:

    # player "On something that will arrive just in time to slip into my coffin."
    player "En algo que llegará justo a tiempo para meterlo en mi ataúd."

# game/beyond the bet/day6dlc.rpy:2297
translate Spanish day6dlc_start2_b2afb7fb:

    # GR "why? there is nothing wrong with looking fashionable for your death."
    GR "¿por qué? no hay nada de malo en lucir a la moda para tu muerte."

# game/beyond the bet/day6dlc.rpy:2300
translate Spanish day6dlc_start2_61667f19:

    # player "Eh..."
    player "Eh..."

# game/beyond the bet/day6dlc.rpy:2303
translate Spanish day6dlc_start2_a008aa77:

    # player "OR..."
    player "O..."

# game/beyond the bet/day6dlc.rpy:2306
translate Spanish day6dlc_start2_3557a97e:

    # player "I could buy a pretty vase for my flowers :D"
    player "Podría comprar un jarrón bonito para mis flores :D"

# game/beyond the bet/day6dlc.rpy:2307
translate Spanish day6dlc_start2_f6626447:

    # GR "and then when your vision deteriorates, you can use the vase as glasses, of course."
    GR "y cuando tu visión se deteriore, puedes usar el jarrón como gafas, claro."

# game/beyond the bet/day6dlc.rpy:2310
translate Spanish day6dlc_start2_3d12f41f:

    # player "Sarcasm is the lowest form of wit, you know."
    player "El sarcasmo es la forma más baja de ingenio, ¿sabes?"

# game/beyond the bet/day6dlc.rpy:2311
translate Spanish day6dlc_start2_46cca92f:

    # GR "perhaps look in the mirror and tell that to yourself."
    GR "quizá mírate al espejo y dile eso a tu reflejo."

# game/beyond the bet/day6dlc.rpy:2312
translate Spanish day6dlc_start2_f578c429:

    # GR "you are sarcastic almost every day."
    GR "eres sarcástic[letra] casi todos los días."

# game/beyond the bet/day6dlc.rpy:2315
translate Spanish day6dlc_start2_fc5da844:

    # player "I would, but without glasses I can't even see myself in the mirror :("
    player "Lo haría, pero sin gafas ni siquiera puedo verme en el espejo :("

# game/beyond the bet/day6dlc.rpy:2316
translate Spanish day6dlc_start2_7772a27d_34:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:2317
translate Spanish day6dlc_start2_54624fcb:

    # GR "just so you know, the lead up was bad, and the execution did not make me laugh. terrible joke."
    GR "para que lo sepas, la preparación fue mala, y la ejecución no me hizo reír. chiste terrible."

# game/beyond the bet/day6dlc.rpy:2318
translate Spanish day6dlc_start2_51798248:

    # GR "but for now, let us put that aside."
    GR "pero por ahora, dejemos eso a un lado."

# game/beyond the bet/day6dlc.rpy:2319
translate Spanish day6dlc_start2_df704541:

    # GR "we must work out something more important."
    GR "debemos resolver algo más importante."

# game/beyond the bet/day6dlc.rpy:2324
translate Spanish day6dlc_start2_62a35f06:

    # player "Open your eyes SUPER WIDE and maybe you'll see."
    player "Abre los ojos BIEN GRANDES y quizá veas."

# game/beyond the bet/day6dlc.rpy:2325
translate Spanish day6dlc_start2_4ee98cd4_1:

    # GR "okay."
    GR "okey."

# game/beyond the bet/day6dlc.rpy:2326
translate Spanish day6dlc_start2_1afa8d70:

    # GR "i'm doing it. my eyes are wider than they've ever been before, and..."
    GR "lo estoy haciendo. mis ojos están más abiertos que nunca, y..."

# game/beyond the bet/day6dlc.rpy:2327
translate Spanish day6dlc_start2_1aad3ed2:

    # GR "nope, i still don't see how you being sick means you can talk to me more."
    GR "no, sigo sin ver por qué estar enferm[letra] significa que puedas hablar más conmigo."

# game/beyond the bet/day6dlc.rpy:2328
translate Spanish day6dlc_start2_4752be3f:

    # GR "i am available no matter how you feel, mortal."
    GR "estoy disponible sin importar cómo te sientas, mortal."

# game/beyond the bet/day6dlc.rpy:2331
translate Spanish day6dlc_start2_6a9bd527:

    # player "In actual fact, you're usually too busy to talk to me."
    player "En realidad, normalmente estás demasiado ocupado para hablar conmigo."

# game/beyond the bet/day6dlc.rpy:2332
translate Spanish day6dlc_start2_16d545d3:

    # GR "that..."
    GR "eso..."

# game/beyond the bet/day6dlc.rpy:2333
translate Spanish day6dlc_start2_d2239773:

    # GR "well, i suppose there is some truth to it."
    GR "bueno, supongo que hay algo de verdad en eso."

# game/beyond the bet/day6dlc.rpy:2334
translate Spanish day6dlc_start2_014571be:

    # GR "i cannot help but have an unending amount of work, with the cycle of birth and death as it is."
    GR "no puedo evitar tener una cantidad interminable de trabajo, con el ciclo de nacimiento y muerte como es."

# game/beyond the bet/day6dlc.rpy:2335
translate Spanish day6dlc_start2_c0e56f5d:

    # GR "but i am always just a message away, and i will respond when i am able."
    GR "pero siempre estoy a un mensaje de distancia, y responderé cuando pueda."

# game/beyond the bet/day6dlc.rpy:2338
translate Spanish day6dlc_start2_ae5860c3:

    # player "Okay, well, I think you're super distracting."
    player "Okey, pues creo que me distraes muchísimo."

# game/beyond the bet/day6dlc.rpy:2342
translate Spanish day6dlc_start2_596ea6c9:

    # player "And if I spent all my normal days chatting with you, I'd never get anything done."
    player "Y si pasara todos mis días normales charlando contigo, nunca haría nada."

# game/beyond the bet/day6dlc.rpy:2344
translate Spanish day6dlc_start2_5934465d:

    # GR "am i that alluring?"
    GR "¿tan cautivador soy?"

# game/beyond the bet/day6dlc.rpy:2347
translate Spanish day6dlc_start2_579e132f:

    # player "I mean, your stupid face is alright, I guess."
    player "O sea, tu cara tonta está bien, supongo."

# game/beyond the bet/day6dlc.rpy:2348
translate Spanish day6dlc_start2_9bb89d98:

    # GR "stupid? what is stupid about my face?"
    GR "¿tonta? ¿qué tiene de tonto mi cara?"

# game/beyond the bet/day6dlc.rpy:2349
translate Spanish day6dlc_start2_0dec4389:

    # GR "every piece of it is perfection."
    GR "cada parte de ella es perfección."

# game/beyond the bet/day6dlc.rpy:2350
translate Spanish day6dlc_start2_b8a042d1:

    # GR "from my eyes, to my nose, to my lips... alluring is an understatement."
    GR "desde mis ojos, hasta mi nariz, hasta mis labios... cautivador es quedarse corto."

# game/beyond the bet/day6dlc.rpy:2353
translate Spanish day6dlc_start2_76e5083f:

    # player "You know, I'm coming to love how confident you are."
    player "Sabes, estoy empezando a amar lo seguro que eres."

# game/beyond the bet/day6dlc.rpy:2354
translate Spanish day6dlc_start2_17fc319a:

    # GR "naturally."
    GR "naturalmente."

# game/beyond the bet/day6dlc.rpy:2357
translate Spanish day6dlc_start2_89cbfa8d:

    # player "One moment you're as red as a tomato..."
    player "Un momento estás rojo como un tomate..."

# game/beyond the bet/day6dlc.rpy:2360
translate Spanish day6dlc_start2_a25712f3:

    # player "And the next you're confidently telling me about how perfect your face is."
    player "Y al siguiente me estás diciendo con total seguridad lo perfecta que es tu cara."

# game/beyond the bet/day6dlc.rpy:2363
translate Spanish day6dlc_start2_e4a00848:

    # player "I love me a man who can do both."
    player "Me encanta un hombre que puede hacer ambas."

# game/beyond the bet/day6dlc.rpy:2364
translate Spanish day6dlc_start2_22646023:

    # GR "yes, well... truly, i am fit to every person's fantasy."
    GR "sí, bueno... de verdad, encajo en la fantasía de cualquiera."

# game/beyond the bet/day6dlc.rpy:2367
translate Spanish day6dlc_start2_cda71055:

    # player "Don't get ahead of yourself, buddy."
    player "No te adelantes, amigo."

# game/beyond the bet/day6dlc.rpy:2368
translate Spanish day6dlc_start2_059b3872:

    # GR "you are correct."
    GR "tienes razón."

# game/beyond the bet/day6dlc.rpy:2369
translate Spanish day6dlc_start2_eae42fd1:

    # GR "let us put aside talk of how perfect i am for the moment."
    GR "dejemos de lado por el momento la charla sobre lo perfecto que soy."

# game/beyond the bet/day6dlc.rpy:2370
translate Spanish day6dlc_start2_06a76c36:

    # GR "even if it is a factual discussion."
    GR "aunque sea una discusión basada en hechos."

# game/beyond the bet/day6dlc.rpy:2371
translate Spanish day6dlc_start2_244c8794:

    # GR "we must concentrate on your sickness, instead."
    GR "debemos concentrarnos en tu enfermedad, en cambio."

# game/beyond the bet/day6dlc.rpy:2376
translate Spanish day6dlc_start2_96e7409d:

    # player "Alluringly stupid."
    player "Cautivadoramente tonto."

# game/beyond the bet/day6dlc.rpy:2377
translate Spanish day6dlc_start2_40ff94e5:

    # GR "i'll have you know, i am not stupid in the slightest."
    GR "te haré saber que no soy tonto en lo más mínimo."

# game/beyond the bet/day6dlc.rpy:2380
translate Spanish day6dlc_start2_4ba84248:

    # player "🤓🤓🤓"
    player "🤓🤓🤓"

# game/beyond the bet/day6dlc.rpy:2381
translate Spanish day6dlc_start2_3ba2a44f:

    # GR "what? what are those little faces supposed to mean?"
    GR "¿qué? ¿qué se supone que significan esas caritas?"

# game/beyond the bet/day6dlc.rpy:2384
translate Spanish day6dlc_start2_9f4dc074:

    # player "Those are *actual* emojis, FYI."
    player "Son emojis 'de verdad', por cierto."

# game/beyond the bet/day6dlc.rpy:2387
translate Spanish day6dlc_start2_06a45d92:

    # player "And they don't mean anything. I just felt like putting them there."
    player "Y no significan nada. Solo tuve ganas de ponerlos ahí."

# game/beyond the bet/day6dlc.rpy:2388
translate Spanish day6dlc_start2_b0533c7f:

    # GR "are you trying to say that i am indeed stupid?"
    GR "¿intentas decir que en efecto soy tonto?"

# game/beyond the bet/day6dlc.rpy:2389
translate Spanish day6dlc_start2_1f4354af:

    # GR "i have studied most human topics in great detail."
    GR "he estudiado la mayoría de los temas humanos con gran detalle."

# game/beyond the bet/day6dlc.rpy:2392
translate Spanish day6dlc_start2_4ba84248_1:

    # player "🤓🤓🤓"
    player "🤓🤓🤓"

# game/beyond the bet/day6dlc.rpy:2393
translate Spanish day6dlc_start2_7772a27d_35:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:2396
translate Spanish day6dlc_start2_0c959dac:

    # player "I'm kidding. I know you're smart."
    player "Estoy bromeando. Sé que eres listo."

# game/beyond the bet/day6dlc.rpy:2399
translate Spanish day6dlc_start2_28a62156:

    # player "You're, like, information smart, but not very people smart."
    player "Eres listo en información, pero no muy listo con la gente."

# game/beyond the bet/day6dlc.rpy:2400
translate Spanish day6dlc_start2_2f231539:

    # GR "yes, well, my job doesn't usually put me in direct contact with mortals."
    GR "sí, bueno, mi trabajo no suele ponerme en contacto directo con mortales."

# game/beyond the bet/day6dlc.rpy:2401
translate Spanish day6dlc_start2_4a9ce06b:

    # GR "you are my first, and i am certain you will also be my last."
    GR "eres la primera persona con la que trato, y estoy seguro de que también serás la última."

# game/beyond the bet/day6dlc.rpy:2404
translate Spanish day6dlc_start2_cb8e4b66:

    # player "Well, doesn't that make me feel special?"
    player "Vaya, ¿eso no me hace sentir especial?"

# game/beyond the bet/day6dlc.rpy:2405
translate Spanish day6dlc_start2_4943e68f:

    # GR "special, and yet sick."
    GR "especial, y sin embargo enferm[letra]."

# game/beyond the bet/day6dlc.rpy:2406
translate Spanish day6dlc_start2_a2723fde:

    # GR "we must work out why."
    GR "debemos averiguar por qué."

# game/beyond the bet/day6dlc.rpy:2410
translate Spanish day6dlc_start2_d5475f5e:

    # player "Honestly, yes."
    player "Sinceramente, sí."

# game/beyond the bet/day6dlc.rpy:2413
translate Spanish day6dlc_start2_1112c7cc:

    # player "I do have to admit that over the last few days, I..."
    player "Tengo que admitir que en los últimos días, yo..."

# game/beyond the bet/day6dlc.rpy:2416
translate Spanish day6dlc_start2_8e8dd1c5:

    # player "Have come to like you more than I probably should."
    player "Me gustas más de lo que probablemente debería."

# game/beyond the bet/day6dlc.rpy:2420
translate Spanish day6dlc_start2_8fb01c03:

    # player "You're an alluring guy, Grimmy."
    player "Eres un tipo cautivador, Parquita."

# game/beyond the bet/day6dlc.rpy:2421
translate Spanish day6dlc_start2_302852c8:

    # GR "o... oh. right."
    GR "o... oh. claro."

# game/beyond the bet/day6dlc.rpy:2422
translate Spanish day6dlc_start2_6b1e1d24:

    # GR "you are... very honest today."
    GR "estás... muy sincer[letra] hoy."

# game/beyond the bet/day6dlc.rpy:2425
translate Spanish day6dlc_start2_e8c707b7:

    # player "Honesty is the best policy."
    player "La honestidad es lo mejor en la política."

# game/beyond the bet/day6dlc.rpy:2426
translate Spanish day6dlc_start2_08885e7e:

    # GR "i do not see how policies come into this, but..."
    GR "no veo qué tiene que ver la política, pero..."

# game/beyond the bet/day6dlc.rpy:2427
translate Spanish day6dlc_start2_bdfae487:

    # GR "well, honesty is something i am familiar with, so why does it make me feel so..."
    GR "bueno, la honestidad es algo que conozco bien, así que por qué me hace sentir tan..."

# game/beyond the bet/day6dlc.rpy:2428
translate Spanish day6dlc_start2_0b16bee0_2:

    # GR "ahem."
    GR "ejem."

# game/beyond the bet/day6dlc.rpy:2429
translate Spanish day6dlc_start2_cc1d1f51:

    # GR "i am getting carried away."
    GR "me estoy dejando llevar."

# game/beyond the bet/day6dlc.rpy:2430
translate Spanish day6dlc_start2_49564bf5_1:

    # GR "you are sick."
    GR "estás enferm[letra]."

# game/beyond the bet/day6dlc.rpy:2431
translate Spanish day6dlc_start2_8f10f567:

    # GR "we must get to the bottom of this."
    GR "debemos llegar al fondo de esto."

# game/beyond the bet/day6dlc.rpy:2433
translate Spanish day6dlc_start2_bed53c39:

    # GR "why are you sick? how have you allowed this?"
    GR "¿por qué estás enferm[letra]? ¿cómo lo has permitido?"

# game/beyond the bet/day6dlc.rpy:2436
translate Spanish day6dlc_start2_4b8ad0fd:

    # player "I don't know if there's any specific reason."
    player "No sé si hay alguna razón específica."

# game/beyond the bet/day6dlc.rpy:2439
translate Spanish day6dlc_start2_726543ee:

    # player "It's just going around again, I guess."
    player "Supongo que la gripe está circulando otra vez."

# game/beyond the bet/day6dlc.rpy:2440
translate Spanish day6dlc_start2_26c76fba:

    # GR "that is not sufficient for me."
    GR "eso no me basta."

# game/beyond the bet/day6dlc.rpy:2441
translate Spanish day6dlc_start2_85569dea:

    # GR "how dare something like a cold take root in you."
    GR "cómo se atreve algo como un resfriado a echar raíces en ti."

# game/beyond the bet/day6dlc.rpy:2444
translate Spanish day6dlc_start2_c1e60f93:

    # player "I appreciate the sentiment, but it's really no biggie."
    player "Aprecio el sentimiento, pero de verdad no es nada del otro mundo."

# game/beyond the bet/day6dlc.rpy:2445
translate Spanish day6dlc_start2_9063197f:

    # GR "you are accepting this illness too easily."
    GR "estás aceptando esta enfermedad con demasiada facilidad."

# game/beyond the bet/day6dlc.rpy:2446
translate Spanish day6dlc_start2_082a1b0c:

    # GR "you must be prepared to fight back against that which wrongs you."
    GR "debes estar preparad[letra] para luchar contra lo que te agravia."

# game/beyond the bet/day6dlc.rpy:2447
translate Spanish day6dlc_start2_916060a4:

    # GR "is it your head?"
    GR "¿es la cabeza?"

# game/beyond the bet/day6dlc.rpy:2448
translate Spanish day6dlc_start2_02f22c40:

    # GR "your stomach?"
    GR "¿el estómago?"

# game/beyond the bet/day6dlc.rpy:2451
translate Spanish day6dlc_start2_afe9eaba:

    # player "I'd say both."
    player "Diría que ambos."

# game/beyond the bet/day6dlc.rpy:2454
translate Spanish day6dlc_start2_4892d063:

    # player "I feel so tired for a person that's done nothing but sleep."
    player "Me siento muy cansad[letra] para ser alguien que no ha hecho más que dormir."

# game/beyond the bet/day6dlc.rpy:2457
translate Spanish day6dlc_start2_9cb8cc4e:

    # player "Well, not that I slept very well, but I've just been lounging around all day."
    player "Bueno, no es que haya dormido muy bien, pero llevo todo el día tirad[letra] por ahí."

# game/beyond the bet/day6dlc.rpy:2458
translate Spanish day6dlc_start2_6b868c5f:

    # GR "hmm. you did not look unwell when i visited you last night."
    GR "mmm. no te veías enferm[letra] cuando te visité anoche."

# game/beyond the bet/day6dlc.rpy:2461
translate Spanish day6dlc_start2_4c643028:

    # player "No? How did I look?"
    player "¿No? ¿Cómo me veía?"

# game/beyond the bet/day6dlc.rpy:2462
translate Spanish day6dlc_start2_7da9f868:

    # GR "...[pretty]."
    GR "...[pretty!t]."

# game/beyond the bet/day6dlc.rpy:2463
translate Spanish day6dlc_start2_ad44e21a:

    # GR "flustered."
    GR "sonrojad[letra]."

# game/beyond the bet/day6dlc.rpy:2464
translate Spanish day6dlc_start2_73c41139:

    # GR "as well as absolutely captivated by my good self, of course."
    GR "además de absolutamente cautivad[letra] por mi ilustre persona, claro."

# game/beyond the bet/day6dlc.rpy:2465
translate Spanish day6dlc_start2_04866222:

    # GR "but, how could you not?"
    GR "pero, ¿cómo no estarlo?"

# game/beyond the bet/day6dlc.rpy:2468
translate Spanish day6dlc_start2_6e17d865:

    # player "Me? [pretty!c] and flustered?"
    player "¿Yo? ¿[pretty!c] y sonrojad[letra]?"

# game/beyond the bet/day6dlc.rpy:2471
translate Spanish day6dlc_start2_6111c7ac:

    # player "Hmmm."
    player "Mmm."

# game/beyond the bet/day6dlc.rpy:2474
translate Spanish day6dlc_start2_616431ee:

    # player "Are you sure you're not thinking of yourself?"
    player "¿Seguro que no estás pensando en ti mismo?"

# game/beyond the bet/day6dlc.rpy:2475
translate Spanish day6dlc_start2_1cc8009d:

    # GR "hah! i would take that as a compliment, but your words are dripping with sarcasm once again."
    GR "¡ja! lo tomaría como un cumplido, pero tus palabras vuelven a gotear sarcasmo."

# game/beyond the bet/day6dlc.rpy:2479
translate Spanish day6dlc_start2_a5602458:

    # player "I would NEVER be sarcastic to you, Grim."
    player "JAMÁS sería sarcástic[letra] contigo, Parca."

# game/beyond the bet/day6dlc.rpy:2480
translate Spanish day6dlc_start2_edd2204c:

    # GR "ah!"
    GR "¡ah!"

# game/beyond the bet/day6dlc.rpy:2481
translate Spanish day6dlc_start2_d87ea0a7:

    # GR "i was not aware you were a comedian."
    GR "no sabía que eras comediante."

# game/beyond the bet/day6dlc.rpy:2484
translate Spanish day6dlc_start2_82e4a762:

    # player "I HAVE been practicing my jokes."
    player "SÍ he estado practicando mis chistes."

# game/beyond the bet/day6dlc.rpy:2487
translate Spanish day6dlc_start2_62ee5fd2:

    # player "Knock knock."
    player "Toc toc."

# game/beyond the bet/day6dlc.rpy:2488
translate Spanish day6dlc_start2_8aeade66:

    # GR "i do not like these jokes."
    GR "no me gustan estos chistes."

# game/beyond the bet/day6dlc.rpy:2491
translate Spanish day6dlc_start2_68e8bdd8:

    # player "KNOCK KNOCK."
    player "TOC TOC."

# game/beyond the bet/day6dlc.rpy:2492
translate Spanish day6dlc_start2_d1fbd2fa:

    # GR "...who is at my door?"
    GR "...¿quién está en mi puerta?"

# game/beyond the bet/day6dlc.rpy:2495
translate Spanish day6dlc_start2_7619ed85:

    # player "The Grim Reaper."
    player "La Parca."

# game/beyond the bet/day6dlc.rpy:2496
translate Spanish day6dlc_start2_a6f46652:

    # GR "the grim reaper who..."
    GR "la parca que..."

# game/beyond the bet/day6dlc.rpy:2499
translate Spanish day6dlc_start2_602da368:

    # player "Okay, I actually hadn't thought the joke this far through."
    player "Okey, en realidad no había pensado el chiste hasta aquí."

# game/beyond the bet/day6dlc.rpy:2502
translate Spanish day6dlc_start2_f4240b73:

    # player "I guess we'll never know."
    player "Supongo que nunca lo sabremos."

# game/beyond the bet/day6dlc.rpy:2503
translate Spanish day6dlc_start2_29523095:

    # GR "that is immensely unsatisfying."
    GR "eso es inmensamente insatisfactorio."

# game/beyond the bet/day6dlc.rpy:2506
translate Spanish day6dlc_start2_1bd16f5c:

    # player "You finish the joke, then."
    player "Termina tú el chiste, entonces."

# game/beyond the bet/day6dlc.rpy:2509
translate Spanish day6dlc_start2_85dec2e5:

    # player "Lemme know when you work it out."
    player "Avísame cuando lo resuelvas."

# game/beyond the bet/day6dlc.rpy:2510
translate Spanish day6dlc_start2_1dfdaeaa:

    # GR "you are the comedian here. you finish the joke yourself."
    GR "tú eres [arti] comediante aquí. termina tú el chiste."

# game/beyond the bet/day6dlc.rpy:2514
translate Spanish day6dlc_start2_dcaf4b56:

    # player "I'll be waiting :D"
    player "Estaré esperando :D"

# game/beyond the bet/day6dlc.rpy:2517
translate Spanish day6dlc_start2_3bf50bc6:

    # player "I can show you something dripping."
    player "Puedo mostrarte algo que gotea."

# game/beyond the bet/day6dlc.rpy:2518
translate Spanish day6dlc_start2_fba3a682:

    # GR "do i want to inquire about what exactly you mean by that..."
    GR "¿debería preguntar qué quieres decir exactamente con eso...?"

# game/beyond the bet/day6dlc.rpy:2521
translate Spanish day6dlc_start2_ccd84c71:

    # player "Take a guess."
    player "Adivina."

# game/beyond the bet/day6dlc.rpy:2522
translate Spanish day6dlc_start2_06f22928:

    # GR "likely something dirty."
    GR "probablemente algo sucio."

# game/beyond the bet/day6dlc.rpy:2525
translate Spanish day6dlc_start2_5266903b:

    # player "And if it was?"
    player "¿Y si lo fuera?"

# game/beyond the bet/day6dlc.rpy:2526
translate Spanish day6dlc_start2_7772a27d_36:

    # GR "..."
    GR "..."

# game/beyond the bet/day6dlc.rpy:2529
translate Spanish day6dlc_start2_4a8246ed:

    # player "I think you already know what I mean, so no use in saying it ;D"
    player "Creo que ya sabes a qué me refiero, así que no hace falta decirlo ;D"

# game/beyond the bet/day6dlc.rpy:2531
translate Spanish day6dlc_start2_632658b2:

    # player "I mean my nose, of course."
    player "Me refiero a mi nariz, claro."

# game/beyond the bet/day6dlc.rpy:2534
translate Spanish day6dlc_start2_e0d40be2:

    # player "Aaargh, I hate being sick."
    player "Aaargh, odio estar enferm[letra]."

# game/beyond the bet/day6dlc.rpy:2542
translate Spanish day6dlc_start2_03775ec8_6:

    # player "..."
    player "..."

# game/beyond the bet/day6dlc.rpy:2543
translate Spanish day6dlc_start2_21a3764f:

    # GR "did i make you feel shy, [playerfirstname!l]?"
    GR "¿te puse tímid[letra], [playerfirstname!l]?"

# game/beyond the bet/day6dlc.rpy:2544
translate Spanish day6dlc_start2_9d4ec31f:

    # GR "i have seen you in your entirety."
    GR "te he visto de pies a cabeza."

# game/beyond the bet/day6dlc.rpy:2547
translate Spanish day6dlc_start2_a1833eea:

    # player "You sound so dirty right now."
    player "Suenas muy atrevido ahora mismo."

# game/beyond the bet/day6dlc.rpy:2548
translate Spanish day6dlc_start2_a66ea027:

    # GR "dirty? that is hardly dirty."
    GR "¿atrevido? eso no tiene nada de atrevido."

# game/beyond the bet/day6dlc.rpy:2549
translate Spanish day6dlc_start2_c773b608:

    # GR "it is true. though, it was true before yesterday, too."
    GR "es cierto. aunque ya lo era antes de ayer, también."

# game/beyond the bet/day6dlc.rpy:2550
translate Spanish day6dlc_start2_61860281:

    # GR "i've watched you for some time, [playerfirstname!l], as i've tried to take your soul."
    GR "te he observado durante un tiempo, [playerfirstname!l], mientras intentaba tomar tu alma."

# game/beyond the bet/day6dlc.rpy:2551
translate Spanish day6dlc_start2_726e7ea5:

    # GR "i've spent many a day in the mortal world, seeing you."
    GR "he pasado muchos días en el mundo mortal, viéndote."

# game/beyond the bet/day6dlc.rpy:2552
translate Spanish day6dlc_start2_608c9084:

    # GR "it is frustrating, but i cannot admit that you are not [pretty]."
    GR "es frustrante, pero no puedo negar que eres [pretty!t]."

# game/beyond the bet/day6dlc.rpy:2555
translate Spanish day6dlc_start2_2d146c60:

    # player "I still don't feel like you've {i}'seen me in my entirety'{/i}."
    player "Sigo sin sentir que me hayas {i}'visto por completo'{/i}."

# game/beyond the bet/day6dlc.rpy:2558
translate Spanish day6dlc_start2_a041d485:

    # player "Trust me, there's plenty more to see ;)"
    player "Créeme, hay mucho más que ver ;)"

# game/beyond the bet/day6dlc.rpy:2561
translate Spanish day6dlc_start2_9af8b7ba:

    # player "Pretty sure you couldn't see my whole body through a window, Grimmy."
    player "Seguro que no podrías ver todo mi cuerpo por una ventana, Parquita."

# game/beyond the bet/day6dlc.rpy:2564
translate Spanish day6dlc_start2_c68e5534:

    # player "But I don't mind you looking."
    player "Pero no me importa que mires."

# game/beyond the bet/day6dlc.rpy:2567
translate Spanish day6dlc_start2_26bc92ba:

    # player "Actually, I kinda feel like encouraging it."
    player "De hecho, casi me dan ganas de animarte."

# game/beyond the bet/day6dlc.rpy:2568
translate Spanish day6dlc_start2_1d6c1e68:

    # GR "do you desire my gaze that much?"
    GR "¿tanto deseas mi mirada?"

# game/beyond the bet/day6dlc.rpy:2571
translate Spanish day6dlc_start2_3121aa22:

    # player "It's not too bad, actually."
    player "En realidad, no está tan mal."

# game/beyond the bet/day6dlc.rpy:2574
translate Spanish day6dlc_start2_97ceaf34:

    # player "Being able to steal Death's gaze."
    player "Poder robarle la mirada a la Muerte."

# game/beyond the bet/day6dlc.rpy:2577
translate Spanish day6dlc_start2_7b49d44b:

    # player "I bet not everyone can do that."
    player "Apuesto a que no cualquiera puede hacerlo."

# game/beyond the bet/day6dlc.rpy:2578
translate Spanish day6dlc_start2_1a255d7c:

    # GR "i would think near no one would want that."
    GR "diría que casi nadie desearía eso."

# game/beyond the bet/day6dlc.rpy:2579
translate Spanish day6dlc_start2_a9d2e80d:

    # GR "death's eyes upon them."
    GR "los ojos de la muerte sobre ellos."

# game/beyond the bet/day6dlc.rpy:2582
translate Spanish day6dlc_start2_e3ed6ef5:

    # player "Aren't you lucky that I'm one of the ones who likes it."
    player "¿No tienes suerte de que yo sea de quienes lo disfrutan?"

# game/beyond the bet/day6dlc.rpy:2583
translate Spanish day6dlc_start2_1c41d95a:

    # GR "lucky, unlucky, they are two sides of the same coin."
    GR "suerte, desgracia, son dos caras de la misma moneda."

# game/beyond the bet/day6dlc.rpy:2584
translate Spanish day6dlc_start2_43110cae:

    # GR "perhaps us meeting was fate."
    GR "quizá nuestro encuentro fue cosa del destino."

# game/beyond the bet/day6dlc.rpy:2585
translate Spanish day6dlc_start2_a21ecec9:

    # GR "fate is a cruel mistress, after all."
    GR "el destino es una amante cruel, después de todo."

# game/beyond the bet/day6dlc.rpy:2586
translate Spanish day6dlc_start2_c7a80d4e:

    # GR "anyway..."
    GR "en fin..."

# game/beyond the bet/day6dlc.rpy:2589
translate Spanish day6dlc_start2_647113fb:

    # player "I'm bleeding out of my eyes."
    player "Estoy sangrando por los ojos."

# game/beyond the bet/day6dlc.rpy:2592
translate Spanish day6dlc_start2_dbcf3f2f:

    # player "And my nose."
    player "Y por la nariz."

# game/beyond the bet/day6dlc.rpy:2595
translate Spanish day6dlc_start2_a7f2ebb1:

    # player "Maybe my ears?"
    player "¿Quizá por las orejas?"

# game/beyond the bet/day6dlc.rpy:2596
translate Spanish day6dlc_start2_b95f3147:

    # GR "WHAT???"
    GR "¿¿¿QUÉ???"

# game/beyond the bet/day6dlc.rpy:2597
translate Spanish day6dlc_start2_e22dd61d:

    # GR "call an ambulance, immediately!"
    GR "¡llama a una ambulancia, de inmediato!"

# game/beyond the bet/day6dlc.rpy:2598
translate Spanish day6dlc_start2_ebb60802:

    # GR "if you do not call one right this instant i will travel to your realm just to do it for you!"
    GR "¡si no llamas a una ahora mismo, viajaré a tu reino solo para hacerlo por ti!"

# game/beyond the bet/day6dlc.rpy:2599
translate Spanish day6dlc_start2_ef6aef32:

    # GR "in fact, i will make sure you do it. answer this immediately."
    GR "de hecho, me aseguraré de que lo hagas. responde esto de inmediato."

# game/beyond the bet/day6dlc.rpy:2609
translate Spanish day6dlc_start2_f837b659:

    # GR "glad to know that sickness does not dampen your... personality."
    GR "me alegra saber que la enfermedad no merma tu... personalidad."

# game/beyond the bet/day6dlc.rpy:2612
translate Spanish day6dlc_start2_6718c6a6:

    # player "You love my personality."
    player "Te encanta mi personalidad."

# game/beyond the bet/day6dlc.rpy:2613
translate Spanish day6dlc_start2_fc970276:

    # GR "yes. of course. almost as much as i love Azrael."
    GR "sí. por supuesto. casi tanto como amo a Azrael."

# game/beyond the bet/day6dlc.rpy:2614
translate Spanish day6dlc_start2_5b678613:

    # GR "answer this."
    GR "responde."

# game/beyond the bet/day6dlc.rpy:2646
translate Spanish call1_dayalt6_fe547dbd:

    # GRC "Sunshine!"
    GRC "¡Solecito!"

# game/beyond the bet/day6dlc.rpy:2647
translate Spanish call1_dayalt6_3673a772:

    # GRC "You have no excuse now. Hurry up and call them."
    GRC "Ya no tienes excusa. Date prisa y llámalos."

# game/beyond the bet/day6dlc.rpy:2652
translate Spanish call1_dayalt6_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:2654
translate Spanish call1_dayalt6_6f0e1fd3:

    # GRC "Ah. You were being a trickster. Of course."
    GRC "Ah. Estabas gastándome una broma. Por supuesto."

# game/beyond the bet/day6dlc.rpy:2656
translate Spanish call1_dayalt6_403d04be:

    # GRC "You know what?"
    GRC "¿Sabes qué?"

# game/beyond the bet/day6dlc.rpy:2658
translate Spanish call1_dayalt6_671e1b28:

    # GRC "You will sorely regret tricking me."
    GRC "Lamentarás profundamente haberme engañado."

# game/beyond the bet/day6dlc.rpy:2665
translate Spanish call1_dayalt6_c843dced:

    # GRC "It was not obvious in the slightest."
    GRC "No fue obvio en lo más mínimo."

# game/beyond the bet/day6dlc.rpy:2667
translate Spanish call1_dayalt6_339f44ec:

    # GRC "I was worried..."
    GRC "Estaba preocupado..."

# game/beyond the bet/day6dlc.rpy:2674
translate Spanish call1_dayalt6_997a6b3e:

    # GRC "Hah!"
    GRC "¡Ja!"

# game/beyond the bet/day6dlc.rpy:2675
translate Spanish call1_dayalt6_15e0aa22:

    # GRC "Wipe that smirk from your face, mortal."
    GRC "Borra esa sonrisa burlona de tu rostro, mortal."

# game/beyond the bet/day6dlc.rpy:2676
translate Spanish call1_dayalt6_22544ba2:

    # GRC "You could be a little less excited about the idea of being punished, you know."
    GRC "Podrías emocionarte un poco menos con la idea de ser castigad[letra], ¿sabes?"

# game/beyond the bet/day6dlc.rpy:2678
translate Spanish call1_dayalt6_eb2a3ce3:

    # GRC "That is not what I meant, anyway. It is not a reaper's job to punish mortals."
    GRC "Eso no es lo que quise decir, de todos modos. No es trabajo de una parca castigar a los mortales."

# game/beyond the bet/day6dlc.rpy:2683
translate Spanish call1_dayalt6_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:2690
translate Spanish call1_dayalt6_ad30b8be:

    # GRC "If you keep up your bad behavior, perhaps we will."
    GRC "Si sigues con tu mal comportamiento, quizá lo hagamos."

# game/beyond the bet/day6dlc.rpy:2691
translate Spanish call1_dayalt6_21126b02:

    # GRC "Maybe I have a few ideas."
    GRC "Quizá tenga algunas ideas."

# game/beyond the bet/day6dlc.rpy:2692
translate Spanish call1_dayalt6_cf052219:

    # GRC "That can come later."
    GRC "Eso puede venir después."

# game/beyond the bet/day6dlc.rpy:2693
translate Spanish call1_dayalt6_4c8d501a:

    # GRC "But, firstly..."
    GRC "Pero, primero..."

# game/beyond the bet/day6dlc.rpy:2702
translate Spanish call1_dayalt6_9ffdb76b:

    # GRC "So, you're actually fine...?"
    GRC "Entonces, ¿en realidad estás bien...?"

# game/beyond the bet/day6dlc.rpy:2740
translate Spanish call12_dayalt6_3ddcacd1:

    # GRC "He is resting. His role is tiresome, so he spends much time recuperating."
    GRC "Está descansando. Su rol es agotador, así que pasa mucho tiempo recuperándose."

# game/beyond the bet/day6dlc.rpy:2748
translate Spanish call12_dayalt6_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:2752
translate Spanish call12_dayalt6_65074c4c:

    # GRC "I told you, he is resting."
    GRC "Te dije que está descansando."

# game/beyond the bet/day6dlc.rpy:2759
translate Spanish call12_dayalt6_58210194:

    # GRC "Hah! My arms are much too muscular to be comfortable."
    GRC "¡Ja! Mis brazos son demasiado musculosos para ser cómodos."

# game/beyond the bet/day6dlc.rpy:2773
translate Spanish call12_dayalt6_5bad1070:

    # GRC "I... well... it would be a lie to say that does not sound... cute..."
    GRC "Yo... bueno... mentiría si dijera que eso no suena... tierno..."

# game/beyond the bet/day6dlc.rpy:2775
translate Spanish call12_dayalt6_501f1160:

    # GRC "Ahem! That... well, we are too far apart for that to be possible, of course."
    GRC "¡Ejem! Eso... bueno, estamos demasiado lejos para que eso sea posible, por supuesto."

# game/beyond the bet/day6dlc.rpy:2783
translate Spanish call12_dayalt6_c0ec6b49:

    # GRC "I very much doubt that you will be visiting me here, Sunshine."
    GRC "Dudo mucho que vengas a visitarme aquí, Solecito."

# game/beyond the bet/day6dlc.rpy:2785
translate Spanish call12_dayalt6_32b422b2:

    # GRC "But I'll humor you."
    GRC "Pero te seguiré la corriente."

# game/beyond the bet/day6dlc.rpy:2786
translate Spanish call12_dayalt6_b81a402d:

    # GRC "Haaah. So you are sick. Well..."
    GRC "Haaah. Así que estás enferm[letra]. Bueno..."

# game/beyond the bet/day6dlc.rpy:2795
translate Spanish call12_dayalt6_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:2806
translate Spanish call12_dayalt6_a811aea9:

    # GRC "I am tough and scary."
    GRC "Soy rudo y aterrador."

# game/beyond the bet/day6dlc.rpy:2808
translate Spanish call12_dayalt6_670ce39c:

    # GRC "There is something wrong with your natural fight or flight instincts."
    GRC "Algo anda mal con tus instintos naturales de lucha o huida."

# game/beyond the bet/day6dlc.rpy:2810
translate Spanish call12_dayalt6_43fd708f:

    # GRC "I am death incarnate. That should be something that strikes fear into the heart of any and all mortals."
    GRC "Soy la muerte encarnada. Eso debería infundir miedo en el corazón de todos los mortales."

# game/beyond the bet/day6dlc.rpy:2820
translate Spanish call12_dayalt6_9e7cb13a:

    # GRC "Okay."
    GRC "Okey."

# game/beyond the bet/day6dlc.rpy:2822
translate Spanish call12_dayalt6_71587472:

    # GRC "Fear me, for I am the Grim Reaper, mortal."
    GRC "Témeme, pues soy la Parca, mortal."

# game/beyond the bet/day6dlc.rpy:2825
translate Spanish call12_dayalt6_9690962c:

    # GRC "That is more like it."
    GRC "Así está mejor."

# game/beyond the bet/day6dlc.rpy:2828
translate Spanish call12_dayalt6_82f1c33b:

    # GRC "Well. We can work on it."
    GRC "Bueno. Podemos trabajar en ello."

# game/beyond the bet/day6dlc.rpy:2831
translate Spanish call12_dayalt6_af643866:

    # GRC "That was pathetic."
    GRC "Eso fue patético."

# game/beyond the bet/day6dlc.rpy:2836
translate Spanish call12_dayalt6_28fb04a4:

    # GRC "You are so much trouble, mortal..."
    GRC "Das tanto trabajo, mortal..."

# game/beyond the bet/day6dlc.rpy:2841
translate Spanish call12_dayalt6_1ee67f13:

    # GRC "Me, afraid?"
    GRC "¿Yo, asustado?"

# game/beyond the bet/day6dlc.rpy:2846
translate Spanish call12_dayalt6_7cf54e98:

    # GRC "I was not made to fear others. "
    GRC "No fui creado para temerle a otros."

# game/beyond the bet/day6dlc.rpy:2854
translate Spanish call12_dayalt6_008afe10_2:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:2861
translate Spanish call12_dayalt6_0802e93d:

    # GRC "You are insufferable."
    GRC "Eres insufrible."

# game/beyond the bet/day6dlc.rpy:2881
translate Spanish callalt6merge_27737c51:

    # GRC "At least you look cute snuggled up like that... "
    GRC "Al menos te ves adorable acurrucad[letra] así..."

# game/beyond the bet/day6dlc.rpy:2902
translate Spanish callalt6merge_f2cfd7fa:

    # GRC "I said you look cute snuggled up like that!"
    GRC "¡Dije que te ves adorable acurrucad[letra] así!"

# game/beyond the bet/day6dlc.rpy:2911
translate Spanish callalt6merge_32f44438:

    # GRC "Yes."
    GRC "Sí."

# game/beyond the bet/day6dlc.rpy:2920
translate Spanish callalt6merge_4262f7fd:

    # GRC "It is beyond annoying."
    GRC "Es más que molesto."

# game/beyond the bet/day6dlc.rpy:2924
translate Spanish callalt6merge_cf647d0e:

    # GRC "I should not find a mortal 'cute'."
    GRC "No debería encontrar 'adorable' a un mortal."

# game/beyond the bet/day6dlc.rpy:2926
translate Spanish callalt6merge_a62eb2ba:

    # GRC "I am a being created to hunt, to take, to destroy and to rebuild."
    GRC "Soy un ser creado para cazar, tomar, destruir y reconstruir."

# game/beyond the bet/day6dlc.rpy:2928
translate Spanish callalt6merge_3de8632d:

    # GRC "Not to be doing... whatever it is I'm doing."
    GRC "No para estar haciendo... lo que sea que estoy haciendo."

# game/beyond the bet/day6dlc.rpy:2936
translate Spanish callalt6merge_0ac8f8da:

    # GRC "Most mortals, I imagine, would find it terrifying."
    GRC "La mayoría de los mortales, imagino, lo encontrarían aterrador."

# game/beyond the bet/day6dlc.rpy:2938
translate Spanish callalt6merge_a96e9f38:

    # GRC "You are... unique, Sunshine."
    GRC "Eres... únic[letra], Solecito."

# game/beyond the bet/day6dlc.rpy:2947
translate Spanish callalt6merge_0a1b8f5f:

    # GRC "To say the least."
    GRC "Por decir lo menos."

# game/beyond the bet/day6dlc.rpy:2949
translate Spanish callalt6merge_a2982187:

    # GRC "But this is all far, far beside the point."
    GRC "Pero todo esto está muy, muy fuera de lugar."

# game/beyond the bet/day6dlc.rpy:2951
translate Spanish callalt6merge_e0c3837f:

    # GRC "How could you be sick?"
    GRC "¿Cómo puedes estar enferm[letra]?"

# game/beyond the bet/day6dlc.rpy:2974
translate Spanish callalt6merge_5bc1bd19:

    # GRC "I do not get sick."
    GRC "Yo no me enfermo."

# game/beyond the bet/day6dlc.rpy:2979
translate Spanish callalt6merge_3078ec85:

    # GRC "Yes, like ever."
    GRC "Sí, jamás."

# game/beyond the bet/day6dlc.rpy:2980
translate Spanish callalt6merge_f9921652:

    # GRC "Reapers do not get mortal sicknesses."
    GRC "Las parcas no contraen enfermedades mortales."

# game/beyond the bet/day6dlc.rpy:2984
translate Spanish callalt6merge_14174215:

    # GRC "They do not exist."
    GRC "No existen."

# game/beyond the bet/day6dlc.rpy:2993
translate Spanish callalt6merge_f7877a8e:

    # GRC "Well, except for soul sicknesses, of course."
    GRC "Bueno, salvo las enfermedades del alma, claro."

# game/beyond the bet/day6dlc.rpy:2999
translate Spanish callalt6merge_12c9dd13:

    # GRC "At least its cause can be pinpointed."
    GRC "Al menos su causa puede determinarse."

# game/beyond the bet/day6dlc.rpy:3001
translate Spanish callalt6merge_760fa3dd:

    # GRC "You, however, are much weaker than me in that regard."
    GRC "Tú, en cambio, eres mucho más débil que yo en ese aspecto."

# game/beyond the bet/day6dlc.rpy:3008
translate Spanish callalt6merge_9ac378a3:

    # GRC "Are you or are you not sick for no reason?"
    GRC "¿Estás o no estás enferm[letra] sin razón?"

# game/beyond the bet/day6dlc.rpy:3012
translate Spanish callalt6merge_7567c531:

    # GRC "Which proves my point. It is nothing to be upset about, you and I are simply different."
    GRC "Lo cual demuestra mi punto. No hay de qué molestarse, tú y yo simplemente somos diferentes."

# game/beyond the bet/day6dlc.rpy:3013
translate Spanish callalt6merge_0c712446:

    # GRC "The body of a mortal is much more fragile."
    GRC "El cuerpo de un mortal es mucho más frágil."

# game/beyond the bet/day6dlc.rpy:3015
translate Spanish callalt6merge_57295b4c:

    # GRC "You should take more care of yourself."
    GRC "Deberías cuidarte más."

# game/beyond the bet/day6dlc.rpy:3017
translate Spanish callalt6merge_c0d250e8:

    # GRC "How am I supposed to take your soul if you are unwell?"
    GRC "¿Cómo se supone que tome tu alma si estás indispuest[letra]?"

# game/beyond the bet/day6dlc.rpy:3023
translate Spanish callalt6merge_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3025
translate Spanish callalt6merge_7b553e91:

    # GRC "I suppose I should be agreeing, but taking your soul like this..."
    GRC "Supongo que debería estar de acuerdo, pero tomar tu alma así..."

# game/beyond the bet/day6dlc.rpy:3029
translate Spanish callalt6merge_0e47d2b5:

    # GRC "Which is-"
    GRC "Lo cual es-"

# game/beyond the bet/day6dlc.rpy:3031
translate Spanish callalt6merge_8532a413:

    # GRC "... most of the time."
    GRC "... la mayor parte del tiempo."

# game/beyond the bet/day6dlc.rpy:3042
translate Spanish callalt6merge_b2742a6f:

    # GRC "Shut up."
    GRC "Cállate."

# game/beyond the bet/day6dlc.rpy:3047
translate Spanish callalt6merge_086fc257:

    # GRC "Most of the time. Anyway..."
    GRC "La mayor parte del tiempo. En fin..."

# game/beyond the bet/day6dlc.rpy:3050
translate Spanish callalt6merge_75f511a1:

    # GRC "This simply just does not work for me."
    GRC "Esto simplemente no me sirve."

# game/beyond the bet/day6dlc.rpy:3051
translate Spanish callalt6merge_7b4e3700:

    # GRC "I do not accept it."
    GRC "No lo acepto."

# game/beyond the bet/day6dlc.rpy:3060
translate Spanish callalt6merge_3be9a8ab:

    # GRC "What...?"
    GRC "¿Qué...?"

# game/beyond the bet/day6dlc.rpy:3061
translate Spanish callalt6merge_86d727de:

    # GRC "I am not some vampire who sucks out illnesses."
    GRC "No soy ningún vampiro que succiona enfermedades."

# game/beyond the bet/day6dlc.rpy:3074
translate Spanish callalt6merge_37f98146:

    # GRC "Who knows. I think it's more likely you all kill each other, and then I can retire."
    GRC "Quién sabe. Creo que es más probable que se maten entre ustedes, y entonces pueda jubilarme."

# game/beyond the bet/day6dlc.rpy:3075
translate Spanish callalt6merge_ec4cafea:

    # GRC "Anything is possible."
    GRC "Todo es posible."

# game/beyond the bet/day6dlc.rpy:3077
translate Spanish callalt6merge_9f13b686:

    # GRC "Hmm. Perhaps there was once a time where reapers could become ill, too."
    GRC "Mmm. Quizá hubo un tiempo en que las parcas también podían enfermar."

# game/beyond the bet/day6dlc.rpy:3079
translate Spanish callalt6merge_ea49ed2b:

    # GRC "Or maybe we are as we always have been."
    GRC "O quizá somos como siempre hemos sido."

# game/beyond the bet/day6dlc.rpy:3086
translate Spanish callalt6merge_eb669c14:

    # GRC "I have no answer for you there."
    GRC "No tengo respuesta para eso."

# game/beyond the bet/day6dlc.rpy:3087
translate Spanish callalt6merge_bd578430:

    # GRC "I do not have access to classified information like that. I am just a lowly reaper."
    GRC "No tengo acceso a información confidencial como esa. Solo soy una humilde parca."

# game/beyond the bet/day6dlc.rpy:3089
translate Spanish callalt6merge_d91943d8:

    # GRC "If it is even documented at all."
    GRC "Si es que siquiera está documentado."

# game/beyond the bet/day6dlc.rpy:3096
translate Spanish callalt6merge_d3f69159:

    # GRC "I can't say. I don't know how we came to be."
    GRC "No puedo decirlo. No sé cómo llegamos a existir."

# game/beyond the bet/day6dlc.rpy:3098
translate Spanish callalt6merge_d21d0f5e:

    # GRC "We just simply are."
    GRC "Simplemente existimos."

# game/beyond the bet/day6dlc.rpy:3112
translate Spanish callalt6merge_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3116
translate Spanish callalt6merge_605b141b:

    # GRC "I don't know if there ever was a 'first'."
    GRC "No sé si alguna vez hubo un primero."

# game/beyond the bet/day6dlc.rpy:3118
translate Spanish callalt6merge_14e04921:

    # GRC "As for retiring, I've never known it to happen."
    GRC "En cuanto a jubilarse, nunca he sabido que ocurra."

# game/beyond the bet/day6dlc.rpy:3119
translate Spanish callalt6merge_f3101778:

    # GRC "We are tied to our profession, it is a part of us."
    GRC "Estamos atados a nuestra profesión, es parte de nosotros."

# game/beyond the bet/day6dlc.rpy:3121
translate Spanish callalt6merge_bdfbbb09:

    # GRC "Reapers exist solely to do just that. Otherwise there would be no point in our existence at all."
    GRC "Las parcas existimos únicamente para eso. De lo contrario, nuestra existencia no tendría sentido alguno."

# game/beyond the bet/day6dlc.rpy:3125
translate Spanish callalt6merge_e366e25f:

    # GRC "...I wouldn't have agreed with you a week ago."
    GRC "...Hace una semana no habría estado de acuerdo contigo."

# game/beyond the bet/day6dlc.rpy:3127
translate Spanish callalt6merge_88c6ebba:

    # GRC "But perhaps it is."
    GRC "Pero quizá lo sea."

# game/beyond the bet/day6dlc.rpy:3131
translate Spanish callalt6merge_990cc387:

    # GRC "Heh."
    GRC "Je."

# game/beyond the bet/day6dlc.rpy:3135
translate Spanish callalt6merge_70616d67:

    # GRC "It is adequate."
    GRC "Es aceptable."

# game/beyond the bet/day6dlc.rpy:3139
translate Spanish callalt6merge_732b0188:

    # GRC "That is not possible."
    GRC "Eso no es posible."

# game/beyond the bet/day6dlc.rpy:3145
translate Spanish callalt6merge_9f494079:

    # GRC "It is absolutely not."
    GRC "En absoluto."

# game/beyond the bet/day6dlc.rpy:3150
translate Spanish callalt6merge_6fbe03f4:

    # GRC "No."
    GRC "No."

# game/beyond the bet/day6dlc.rpy:3158
translate Spanish callalt6merge_008afe10_2:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3160
translate Spanish callalt6merge_d5a2000b:

    # GRC "Our souls are linked - that is different to being able to take a stroll down your immune system sightseeing."
    GRC "Nuestras almas están vinculadas; eso es distinto a poder darme un paseo turístico por tu sistema inmunológico."

# game/beyond the bet/day6dlc.rpy:3161
translate Spanish callalt6merge_d7a950f3:

    # GRC "Which is impossible."
    GRC "Lo cual es imposible."

# game/beyond the bet/day6dlc.rpy:3166
translate Spanish callalt6merge_b48a73dd:

    # GRC "I cannot."
    GRC "No puedo."

# game/beyond the bet/day6dlc.rpy:3171
translate Spanish callalt6merge_041ded7f:

    # GRC "Plenty."
    GRC "Un montón."

# game/beyond the bet/day6dlc.rpy:3172
translate Spanish callalt6merge_fde5a62e:

    # GRC "Being a doctor is not one of those things."
    GRC "Ser médico no es una de ellas."

# game/beyond the bet/day6dlc.rpy:3186
translate Spanish callalt6merge_5be41805:

    # GRC "Go ahead."
    GRC "Adelante."

# game/beyond the bet/day6dlc.rpy:3197
translate Spanish callalt6merge_21ca14ba:

    # GRC "I understand it may be difficult for you to recognize, mortal, but that was not a question."
    GRC "Entiendo que quizá te cueste reconocerlo, mortal, pero eso no era una pregunta."

# game/beyond the bet/day6dlc.rpy:3207
translate Spanish callalt6merge_ed2fba50:

    # GRC "How do you think?"
    GRC "¿Tú qué crees?"

# game/beyond the bet/day6dlc.rpy:3212
translate Spanish callalt6merge_f06b6f15:

    # GRC "No, I have no parents."
    GRC "No, no tengo padres."

# game/beyond the bet/day6dlc.rpy:3214
translate Spanish callalt6merge_cd634586:

    # GRC "I have no family at all, technically."
    GRC "No tengo familia alguna, técnicamente."

# game/beyond the bet/day6dlc.rpy:3215
translate Spanish callalt6merge_20e7f7a6:

    # GRC "Though, many think of their fellow reapers as their siblings, I suppose."
    GRC "Aunque supongo que muchos consideran a sus compañeros parcas como hermanos."

# game/beyond the bet/day6dlc.rpy:3217
translate Spanish callalt6merge_ca1c6a41:

    # GRC "A sentiment I do not share, unfortunately."
    GRC "Un sentimiento que, lamentablemente, no comparto."

# game/beyond the bet/day6dlc.rpy:3225
translate Spanish callalt6merge_301b9497:

    # GRC "That is likely the simplest explanation."
    GRC "Esa es probablemente la explicación más sencilla."

# game/beyond the bet/day6dlc.rpy:3230
translate Spanish callalt6merge_d82ee6d9:

    # GRC "No one is sure exactly how we are created."
    GRC "Nadie sabe con exactitud cómo somos creados."

# game/beyond the bet/day6dlc.rpy:3231
translate Spanish callalt6merge_0ac09c10:

    # GRC "But I have always looked as I have now. There was no childhood, or parents, or growing up."
    GRC "Pero siempre me he visto como ahora. No hubo infancia, ni padres, ni un proceso de crecer."

# game/beyond the bet/day6dlc.rpy:3240
translate Spanish callalt6merge_613f7145:

    # GRC "I have always been the reaper you see now."
    GRC "Siempre he sido la parca que ves ahora."

# game/beyond the bet/day6dlc.rpy:3245
translate Spanish callalt6merge_4272d6aa:

    # GRC "Likely, yes."
    GRC "Probablemente, sí."

# game/beyond the bet/day6dlc.rpy:3247
translate Spanish callalt6merge_27bac589:

    # GRC "But I do not remember it."
    GRC "Pero no lo recuerdo."

# game/beyond the bet/day6dlc.rpy:3260
translate Spanish callalt6merge_02677c13:

    # GRC "What if I told you that was classified, too?"
    GRC "¿Y si te dijera que eso también es confidencial?"

# game/beyond the bet/day6dlc.rpy:3271
translate Spanish callalt6merge_008afe10_3:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3273
translate Spanish callalt6merge_41645544:

    # GRC "I chose it for myself."
    GRC "Lo elegí yo mismo."

# game/beyond the bet/day6dlc.rpy:3275
translate Spanish callalt6merge_c6c4a81f:

    # GRC "I do not know why, or where it came from."
    GRC "No sé por qué, ni de dónde salió."

# game/beyond the bet/day6dlc.rpy:3276
translate Spanish callalt6merge_46240ddc:

    # GRC "It just felt right."
    GRC "Simplemente me pareció lo correcto."

# game/beyond the bet/day6dlc.rpy:3281
translate Spanish callalt6merge_62eec4c6:

    # GRC "That... is appreciated."
    GRC "Eso... se agradece."

# game/beyond the bet/day6dlc.rpy:3282
translate Spanish callalt6merge_d76e9b68:

    # GRC "I... also enjoy your name."
    GRC "A mí... también me gusta tu nombre."

# game/beyond the bet/day6dlc.rpy:3285
translate Spanish callalt6merge_008afe10_4:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3290
translate Spanish callalt6merge_9467829c:

    # GRC "....."
    GRC "....."

# game/beyond the bet/day6dlc.rpy:3295
translate Spanish callalt6merge_403d8e74:

    # GRC "............"
    GRC "............"

# game/beyond the bet/day6dlc.rpy:3300
translate Spanish callalt6merge_a2022070:

    # GRC "My name is NOT Steve!"
    GRC "¡Mi nombre NO es Steve!"

# game/beyond the bet/day6dlc.rpy:3302
translate Spanish callalt6merge_c1db745c:

    # GRC "Apologies to every Steve out there, but that is not as good of a name as Casper."
    GRC "Disculpas a todos los Steve del mundo, pero ese no es un nombre tan bueno como Casper."

# game/beyond the bet/day6dlc.rpy:3313
translate Spanish callalt6merge_3be9a8ab_1:

    # GRC "What...?"
    GRC "¿Qué...?"

# game/beyond the bet/day6dlc.rpy:3321
translate Spanish callalt6merge_2648ebba:

    # GRC "There... is no reason for me to take your last name, mortal."
    GRC "No... no hay razón para que tome tu apellido, mortal."

# game/beyond the bet/day6dlc.rpy:3331
translate Spanish callalt6merge_b8d5f407:

    # GRC "...!"
    GRC "...!"

# game/beyond the bet/day6dlc.rpy:3335
translate Spanish callalt6merge_008afe10_5:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3337
translate Spanish callalt6merge_ef6121f4:

    # GRC "I'm sure there is someone else you'd rather marry."
    GRC "Estoy seguro de que hay otra persona con quien preferirías casarte."

# game/beyond the bet/day6dlc.rpy:3363
translate Spanish callalt6merge_3a4142d5:

    # GRC "Sunshine, you..."
    GRC "Solecito, tú..."

# game/beyond the bet/day6dlc.rpy:3364
translate Spanish callalt6merge_eee6cc0e:

    # GRC "You don't know what you're doing to me here..."
    GRC "No sabes lo que me estás haciendo..."

# game/beyond the bet/day6dlc.rpy:3378
translate Spanish callalt6merge_0d954208:

    # GRC "There is no 'out'."
    GRC "No hay 'salida'."

# game/beyond the bet/day6dlc.rpy:3379
translate Spanish callalt6merge_6cd372e4:

    # GRC "I must get your soul."
    GRC "Debo conseguir tu alma."

# game/beyond the bet/day6dlc.rpy:3381
translate Spanish callalt6merge_a1580119:

    # GRC "If I do not, then someone else will."
    GRC "Si no lo hago, otro lo hará."

# game/beyond the bet/day6dlc.rpy:3386
translate Spanish callalt6merge_008afe10_6:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3388
translate Spanish callalt6merge_372e0f21:

    # GRC "Gods, what have I gotten myself into."
    GRC "Dioses, en qué me he metido."

# game/beyond the bet/day6dlc.rpy:3390
translate Spanish callalt6merge_494e5f6c:

    # GRC "What you ask of me is my death."
    GRC "Lo que me pides es mi muerte."

# game/beyond the bet/day6dlc.rpy:3395
translate Spanish callalt6merge_9a6ed07a:

    # GRC "Yes, I suppose I am."
    GRC "Sí, supongo que sí."

# game/beyond the bet/day6dlc.rpy:3396
translate Spanish callalt6merge_3c3c377c:

    # GRC "What a position we've found ourselves in."
    GRC "Mira en qué situación nos hemos metido."

# game/beyond the bet/day6dlc.rpy:3415
translate Spanish callalt6merge_008afe10_7:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3417
translate Spanish callalt6merge_2eff0f67:

    # GRC "I know, Sunshine."
    GRC "Lo sé, Solecito."

# game/beyond the bet/day6dlc.rpy:3418
translate Spanish callalt6merge_f31a9990:

    # GRC "That is the nature of what you are, and what I am."
    GRC "Esa es la naturaleza de lo que eres tú, y de lo que soy yo."

# game/beyond the bet/day6dlc.rpy:3427
translate Spanish callalt6merge_216da5c7:

    # GRC "There are still too many things I am unsure about, for this to be over tomorrow..."
    GRC "Todavía hay demasiadas cosas de las que no estoy seguro, para que esto termine mañana..."

# game/beyond the bet/day6dlc.rpy:3429
translate Spanish callalt6merge_4376696d:

    # GRC "I am still looking into your peculiar soul."
    GRC "Todavía estoy investigando tu peculiar alma."

# game/beyond the bet/day6dlc.rpy:3431
translate Spanish callalt6merge_b66ddb32:

    # GRC "Time is unforgiving."
    GRC "El tiempo es implacable."

# game/beyond the bet/day6dlc.rpy:3432
translate Spanish callalt6merge_08373e21:

    # GRC "I have little choice in the matter, just so you know. I exist for this job - I am this job."
    GRC "Tengo poca elección en el asunto, para que lo sepas. Existo para este trabajo; soy este trabajo."

# game/beyond the bet/day6dlc.rpy:3434
translate Spanish callalt6merge_4c192989:

    # GRC "I am a tool for those more important than myself."
    GRC "Soy una herramienta para quienes son más importantes que yo."

# game/beyond the bet/day6dlc.rpy:3435
translate Spanish callalt6merge_f0e12335:

    # GRC "I do not decide who should die. I am just the one who makes sure it happens."
    GRC "Yo no decido quién debe morir. Solo soy quien se asegura de que ocurra."

# game/beyond the bet/day6dlc.rpy:3446
translate Spanish callalt6merge_6d2de22b:

    # GRC "For what reason? You should feel more sorry for yourself."
    GRC "¿Por qué razón? Deberías sentir más lástima por ti."

# game/beyond the bet/day6dlc.rpy:3463
translate Spanish callalt6merge_008afe10_8:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3464
translate Spanish callalt6merge_7b65d276:

    # GRC "Perhaps that is why I've enjoyed this."
    GRC "Quizá por eso he disfrutado esto."

# game/beyond the bet/day6dlc.rpy:3466
translate Spanish callalt6merge_a70282c3:

    # GRC "Enjoyed you."
    GRC "Disfrutado de ti."

# game/beyond the bet/day6dlc.rpy:3467
translate Spanish callalt6merge_c65a2858:

    # GRC "You were a little bit of change."
    GRC "Fuiste un pequeño cambio."

# game/beyond the bet/day6dlc.rpy:3469
translate Spanish callalt6merge_237a210c:

    # GRC "Sunshine, stay right there. I won't be long."
    GRC "Solecito, quédate ahí. No tardaré."

# game/beyond the bet/day6dlc.rpy:3491
translate Spanish chat2_day6alt_ecf16999:

    # player "Casper?"
    player "¿Casper?"

# game/beyond the bet/day6dlc.rpy:3493
translate Spanish chat2_day6alt_44a4c6a1:

    # player "Grimmy?"
    player "¿Parquita?"

# game/beyond the bet/day6dlc.rpy:3496
translate Spanish chat2_day6alt_d5699e0b:

    # player "Where'd you go?"
    player "¿Adónde fuiste?"

# game/beyond the bet/day6dlc.rpy:3499
translate Spanish chat2_day6alt_a78addee:

    # player "Helloooooooooo?"
    player "¿Holaaaaaaaaaa?"

# game/beyond the bet/day6dlc.rpy:3519
translate Spanish chat2_day6alt_4f673053:

    # "There's no response."
    "No hay respuesta."

# game/beyond the bet/day6dlc.rpy:3524
translate Spanish chat2_day6alt_9f783550:

    # "Confused, and slightly annoyed, you shut your laptop for now."
    "Confundid[letra] y un poco molest[letra], cierras tu portátil por ahora."

# game/beyond the bet/day6dlc.rpy:3525
translate Spanish chat2_day6alt_b4e6542f:

    # "You feel a little lonely all of a sudden."
    "De repente te sientes un poco sol[letra]."

# game/beyond the bet/day6dlc.rpy:3526
translate Spanish chat2_day6alt_fc7d1b66:

    # "It's a bit of a strange feeling to you."
    "Es una sensación algo extraña para ti."

# game/beyond the bet/day6dlc.rpy:3527
translate Spanish chat2_day6alt_ba7ffd6f:

    # "You'd never thought of your apartment as lonely."
    "Nunca habías pensado que tu apartamento fuera solitario."

# game/beyond the bet/day6dlc.rpy:3528
translate Spanish chat2_day6alt_9be06e11:

    # "You've enjoyed living alone, decorating your rooms to your liking..."
    "Has disfrutado de vivir sol[letra], decorando tus habitaciones a tu gusto..."

# game/beyond the bet/day6dlc.rpy:3529
translate Spanish chat2_day6alt_6e94f8aa:

    # "But right now, it feels a little empty."
    "Pero ahora mismo se siente un poco vacío."

# game/beyond the bet/day6dlc.rpy:3535
translate Spanish chat2_day6alt_8b080e78:

    # "You get out of bed, legs wobbly, and put your laptop back on your desk."
    "Sales de la cama, con las piernas temblorosas, y vuelves a poner tu portátil sobre el escritorio."

# game/beyond the bet/day6dlc.rpy:3536
translate Spanish chat2_day6alt_6f2e11c2:

    # "...Just in time to make eye contact with someone outside of your window, eyes wide."
    "...Justo a tiempo para cruzar miradas con alguien fuera de tu ventana, con los ojos muy abiertos."

# game/beyond the bet/day6dlc.rpy:3537
translate Spanish chat2_day6alt_5a5fa165:

    # "You hurriedly open the window and a little shyly, he steps inside."
    "Abres la ventana apresuradamente y, con algo de timidez, él entra."

# game/beyond the bet/day6dlc.rpy:3557
translate Spanish da6altinroom_2ba5529e:

    # GRC "Sunshine."
    GRC "Solecito."

# game/beyond the bet/day6dlc.rpy:3558
translate Spanish da6altinroom_24970499:

    # GRC "Ahem."
    GRC "Ejem."

# game/beyond the bet/day6dlc.rpy:3559
translate Spanish da6altinroom_cc9c65c6:

    # GRC "I told you I'd have no problem coming in."
    GRC "Te dije que no tendría problema en entrar."

# game/beyond the bet/day6dlc.rpy:3573
translate Spanish da6altinroom_034fc9fc:

    # GRC "I can hardly take it with you looking as you do."
    GRC "Apenas puedo llevármela viéndote como estás."

# game/beyond the bet/day6dlc.rpy:3582
translate Spanish da6altinroom_747219b6:

    # GRC "I didn't mean it like that."
    GRC "No lo dije en ese sentido."

# game/beyond the bet/day6dlc.rpy:3584
translate Spanish da6altinroom_b7c35b29:

    # GRC "You look much more ill in person."
    GRC "Te ves mucho más enferm[letra] en persona."

# game/beyond the bet/day6dlc.rpy:3585
translate Spanish da6altinroom_6b167f06:

    # GRC "Come on, let me help you to bed."
    GRC "Vamos, déjame ayudarte a volver a la cama."

# game/beyond the bet/day6dlc.rpy:3595
translate Spanish da6altinroom_0d8908a2:

    # "{i}He takes your hand, his gloved fingers gentle, and leads you to your bed.{/i}"
    "{i}Toma tu mano, con sus dedos enguantados gentiles, y te guía hasta tu cama.{/i}"

# game/beyond the bet/day6dlc.rpy:3596
translate Spanish da6altinroom_67399b8d:

    # "{i}He tucks you in carefully, and that feeling of loneliness is instantly replaced with a strange warmness.{/i}"
    "{i}Te arropa con cuidado, y esa sensación de soledad se reemplaza al instante por una extraña calidez.{/i}"

# game/beyond the bet/day6dlc.rpy:3597
translate Spanish da6altinroom_4962df38:

    # "{i}Being looked after by the Grim Reaper wasn't on your bingo card, but it's not so bad.{/i}"
    "{i}Que te cuide la Parca no estaba en tus planes, pero no está tan mal.{/i}"

# game/beyond the bet/day6dlc.rpy:3599
translate Spanish da6altinroom_09937321:

    # GRC "You shouldn't be walking around."
    GRC "No deberías andar por ahí."

# game/beyond the bet/day6dlc.rpy:3601
translate Spanish da6altinroom_7b4ef5e3:

    # GRC "Where is your water?"
    GRC "¿Dónde está tu agua?"

# game/beyond the bet/day6dlc.rpy:3606
translate Spanish da6altinroom_dfd2044c:

    # GRC "Incorrect."
    GRC "Incorrecto."

# game/beyond the bet/day6dlc.rpy:3608
translate Spanish da6altinroom_060f2781:

    # GRC "Wait here."
    GRC "Espera aquí."

# game/beyond the bet/day6dlc.rpy:3611
translate Spanish da6altinroom_c0f204be:

    # "{i}Casper disappears from view, walking away from your bed and into your kitchen.{/i}"
    "{i}Casper desaparece de tu vista, alejándose de tu cama hacia tu cocina.{/i}"

# game/beyond the bet/day6dlc.rpy:3612
translate Spanish da6altinroom_febeac34:

    # "{i}You're thankful you actually washed your dishes last night.{/i}"
    "{i}Agradeces haber lavado los platos anoche.{/i}"

# game/beyond the bet/day6dlc.rpy:3613
translate Spanish da6altinroom_34e3281e:

    # "{i}He returns, a glass of water in his hand.{/i}"
    "{i}Regresa con un vaso de agua en la mano.{/i}"

# game/beyond the bet/day6dlc.rpy:3617
translate Spanish da6altinroom_52d39713:

    # GRC "Drink."
    GRC "Bebe."

# game/beyond the bet/day6dlc.rpy:3619
translate Spanish da6altinroom_c978bfab:

    # GRC "You are unwell, you must keep yourself hydrated."
    GRC "Estás indispuest[letra], debes mantenerte hidratad[letra]."

# game/beyond the bet/day6dlc.rpy:3628
translate Spanish da6altinroom_b955d862:

    # GRC "Of course you will, because I am here."
    GRC "Por supuesto que lo harás, porque yo estoy aquí."

# game/beyond the bet/day6dlc.rpy:3630
translate Spanish da6altinroom_39fb77c8:

    # GRC "So drink that."
    GRC "Así que bebe eso."

# game/beyond the bet/day6dlc.rpy:3631
translate Spanish da6altinroom_7a72b79e:

    # GRC "Are you hungry?"
    GRC "¿Tienes hambre?"

# game/beyond the bet/day6dlc.rpy:3636
translate Spanish da6altinroom_716e02a8:

    # GRC "I will prepare you a mortal meal."
    GRC "Te prepararé una comida de mortales."

# game/beyond the bet/day6dlc.rpy:3640
translate Spanish da6altinroom_2a5c3e46:

    # GRC "It is food for a mortal, is it not?"
    GRC "Es comida para [arti_2] mortal, ¿no es así?"

# game/beyond the bet/day6dlc.rpy:3645
translate Spanish da6altinroom_008afe10:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3647
translate Spanish da6altinroom_b8df2d79:

    # GRC "That is beside the point."
    GRC "Eso es irrelevante."

# game/beyond the bet/day6dlc.rpy:3648
translate Spanish da6altinroom_214648db:

    # GRC "I will not be long, so stay in bed, okay?"
    GRC "No tardaré, así que quédate en la cama, ¿okey?"

# game/beyond the bet/day6dlc.rpy:3654
translate Spanish da6altinroom_a6621a09:

    # "{i}And then he's gone again, figure disappearing back into the kitchen.{/i}"
    "{i}Y luego se va otra vez, su figura desapareciendo de vuelta en la cocina.{/i}"

# game/beyond the bet/day6dlc.rpy:3655
translate Spanish da6altinroom_81767d8a:

    # "{i}Butterflies rise up in your stomach. That's a strange feeling, too.{/i}"
    "{i}Se te alborotan las mariposas en el estómago. Esa también es una sensación extraña.{/i}"

# game/beyond the bet/day6dlc.rpy:3656
translate Spanish da6altinroom_da220e4f:

    # "{i}Like you're a kid in the schoolyard.{/i}"
    "{i}Como si fueras niñ[letra] en el patio del colegio.{/i}"

# game/beyond the bet/day6dlc.rpy:3657
translate Spanish da6altinroom_11dcc9dc:

    # "{i}You're thinking on this when it starts.{/i}"
    "{i}Estás pensando en eso cuando empieza.{/i}"

# game/beyond the bet/day6dlc.rpy:3658
translate Spanish da6altinroom_39f1501e:

    # "{i}Banging.{/i}"
    "{i}Golpes.{/i}"

# game/beyond the bet/day6dlc.rpy:3659
translate Spanish da6altinroom_999b4d52:

    # "{i}Clattering.{/i}"
    "{i}Traqueteo.{/i}"

# game/beyond the bet/day6dlc.rpy:3660
translate Spanish da6altinroom_6ad03d77:

    # "{i}Something... falling?{/i}"
    "{i}¿Algo... cayendo?{/i}"

# game/beyond the bet/day6dlc.rpy:3661
translate Spanish da6altinroom_57e17bab:

    # "{i}Then silence.{/i}"
    "{i}Luego, silencio.{/i}"

# game/beyond the bet/day6dlc.rpy:3662
translate Spanish da6altinroom_70e39fcb:

    # "{i}You stare towards the kitchen.{/i}"
    "{i}Miras hacia la cocina.{/i}"

# game/beyond the bet/day6dlc.rpy:3663
translate Spanish da6altinroom_9af1b394:

    # "{i}More banging! More clattering!{/i}"
    "{i}¡Más golpes! ¡Más traqueteo!{/i}"

# game/beyond the bet/day6dlc.rpy:3664
translate Spanish da6altinroom_cc68a696:

    # "{i}You want to jump out of bed and go see what exactly is going on, but you do feel a little faint.{/i}"
    "{i}Quieres saltar de la cama e ir a ver qué está pasando exactamente, pero sí te sientes un poco maread[letra].{/i}"

# game/beyond the bet/day6dlc.rpy:3665
translate Spanish da6altinroom_16d2414c:

    # "{i}You instead decide to trust in Casper, for better or for worse, and await whatever he considers a 'mortal meal'.{/i}"
    "{i}En cambio, decides confiar en Casper, para bien o para mal, y esperar lo que él considere una 'comida de mortales'.{/i}"

# game/beyond the bet/day6dlc.rpy:3666
translate Spanish da6altinroom_98a4c939:

    # "{i}It's around twenty-five minutes later when he reappears.{/i}"
    "{i}Unos veinticinco minutos después, reaparece.{/i}"

# game/beyond the bet/day6dlc.rpy:3678
translate Spanish da6altinroom_3e343677:

    # GRC "All of what?"
    GRC "¿Todo qué?"

# game/beyond the bet/day6dlc.rpy:3683
translate Spanish da6altinroom_f6ac086c:

    # GRC "Your kitchen is a tough beast."
    GRC "Tu cocina es una bestia indomable."

# game/beyond the bet/day6dlc.rpy:3684
translate Spanish da6altinroom_e139a3a3:

    # GRC "It required some... reining in. It fought admirably."
    GRC "Hubo que... controlarla un poco. Luchó admirablemente."

# game/beyond the bet/day6dlc.rpy:3692
translate Spanish da6altinroom_3c312e72:

    # GRC "I believe I only started one fire, but I handled the issue myself."
    GRC "Creo que solo provoqué un incendio, pero me encargué yo mismo del asunto."

# game/beyond the bet/day6dlc.rpy:3700
translate Spanish da6altinroom_ff1b3da4:

    # GRC "Fortunately, I was well equipped to deal with the raging inferno."
    GRC "Afortunadamente, estaba bien equipado para lidiar con el infierno desatado."

# game/beyond the bet/day6dlc.rpy:3701
translate Spanish da6altinroom_65f3f5e7:

    # GRC "It chose the wrong opponent."
    GRC "Eligió al oponente equivocado."

# game/beyond the bet/day6dlc.rpy:3708
translate Spanish da6altinroom_008afe10_1:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3709
translate Spanish da6altinroom_934fc6d7:

    # GRC "It does not."
    GRC "No es así."

# game/beyond the bet/day6dlc.rpy:3714
translate Spanish da6altinroom_6124241f:

    # GRC "I pulled it down."
    GRC "La arranqué."

# game/beyond the bet/day6dlc.rpy:3718
translate Spanish da6altinroom_35c4dea0:

    # GRC "It was a precautionary measure."
    GRC "Fue una medida de precaución."

# game/beyond the bet/day6dlc.rpy:3729
translate Spanish da6altinroom_1f1b8d1a:

    # GRC "If it went off, you would've gotten out of bed."
    GRC "Si sonara, te habrías levantado de la cama."

# game/beyond the bet/day6dlc.rpy:3737
translate Spanish da6altinroom_ef5e174c:

    # GRC "You are meant to be resting."
    GRC "Se supone que debes estar descansando."

# game/beyond the bet/day6dlc.rpy:3738
translate Spanish da6altinroom_60499604:

    # GRC "Just leave the fires to me."
    GRC "Déjame los incendios a mí."

# game/beyond the bet/day6dlc.rpy:3740
translate Spanish da6altinroom_735aaa6e:

    # "{i}Casper makes his way to your side, the smell of food reaching your nose.{/i}"
    "{i}Casper se acerca a tu lado y te llega el olor a comida.{/i}"

# game/beyond the bet/day6dlc.rpy:3741
translate Spanish da6altinroom_10c7168d:

    # "{i}It... doesn't smell terrible, but it does smell burnt - whatever it is.{/i}"
    "{i}Eso... no huele mal, pero sí huele a quemado, sea lo que sea.{/i}"

# game/beyond the bet/day6dlc.rpy:3742
translate Spanish da6altinroom_334920e3:

    # "{i}But, looking up at him like this, that doesn't matter much.{/i}"
    "{i}Pero, mirándolo desde abajo así, eso no importa mucho.{/i}"

# game/beyond the bet/day6dlc.rpy:3743
translate Spanish da6altinroom_48c9ab8a:

    # "{i}Over video calls, and even when he was at your window, it was hard to tell how...{/i}"
    "{i}Por videollamada, e incluso cuando estaba en tu ventana, era difícil darse cuenta de lo...{/i}"

# game/beyond the bet/day6dlc.rpy:3744
translate Spanish da6altinroom_816681e9:

    # "{i}Well, handsome he really is.{/i}"
    "{i}Bueno, lo guapo que es en realidad.{/i}"

# game/beyond the bet/day6dlc.rpy:3745
translate Spanish da6altinroom_4fe01576:

    # "{i}Well toned arms, a good-looking face, perfect hair...{/i}"
    "{i}Brazos bien tonificados, un rostro atractivo, cabello perfecto...{/i}"

# game/beyond the bet/day6dlc.rpy:3746
translate Spanish da6altinroom_b39eeb7c:

    # "{i}It hits you then how wild this situation is.{/i}"
    "{i}Entonces te cae encima lo descabellada que es esta situación.{/i}"

# game/beyond the bet/day6dlc.rpy:3747
translate Spanish da6altinroom_4e29c98c:

    # "{i}He looks between you and the bed, cheeks slightly flushed, before he sits down carefully on the edge of it.{/i}"
    "{i}Mira de ti a la cama, con las mejillas ligeramente sonrojadas, antes de sentarse con cuidado en el borde de esta.{/i}"

# game/beyond the bet/day6dlc.rpy:3760
translate Spanish da6altinroom_7b7439fb:

    # GRC "H... here."
    GRC "A... aquí tienes."

# game/beyond the bet/day6dlc.rpy:3761
translate Spanish da6altinroom_b408328c:

    # GRC "This is... the first time I am cooking for someone else, so..."
    GRC "Esta es... la primera vez que cocino para alguien más, así que..."

# game/beyond the bet/day6dlc.rpy:3762
translate Spanish da6altinroom_0710da60:

    # "{i}He hands you the plate.{/i}"
    "{i}Te entrega el plato.{/i}"

# game/beyond the bet/day6dlc.rpy:3763
translate Spanish da6altinroom_5969d574:

    # "{i}On it is...{/i}"
    "{i}Sobre él hay...{/i}"

# game/beyond the bet/day6dlc.rpy:3764
translate Spanish da6altinroom_bb9adbf9:

    # "{i}You're not totally sure at first.{/i}"
    "{i}Al principio no estás del todo segur[letra].{/i}"

# game/beyond the bet/day6dlc.rpy:3766
translate Spanish da6altinroom_71674d14:

    # GRC "It is mortal food, correct?"
    GRC "Es comida mortal, ¿correcto?"

# game/beyond the bet/day6dlc.rpy:3767
translate Spanish da6altinroom_d27e272e:

    # "{i}Looking closer... it almost looks like pancakes?{/i}"
    "{i}Mirando más de cerca... ¿casi parecen panqueques?{/i}"

# game/beyond the bet/day6dlc.rpy:3772
translate Spanish da6altinroom_e0b83443:

    # GRC "Of course not. I have no time for fancy cooking."
    GRC "Por supuesto que no. No tengo tiempo para cocina sofisticada."

# game/beyond the bet/day6dlc.rpy:3774
translate Spanish da6altinroom_e211b83e:

    # GRC "Fortunately, I am good at nearly everything I try my hand at. I simply searched on the internet, and I created them perfectly."
    GRC "Afortunadamente, soy bueno en casi todo lo que intento. Simplemente busqué en internet, y los preparé a la perfección."

# game/beyond the bet/day6dlc.rpy:3777
translate Spanish da6altinroom_d3406aed:

    # GRC "Yes, I know."
    GRC "Sí, lo sé."

# game/beyond the bet/day6dlc.rpy:3778
translate Spanish da6altinroom_6ee1809f:

    # GRC "Eat up, Sunshine. You need to conserve your strength."
    GRC "Come, Solecito. Necesitas conservar tus fuerzas."

# game/beyond the bet/day6dlc.rpy:3782
translate Spanish da6altinroom_a24a639d:

    # GRC "What do you mean?"
    GRC "¿A qué te refieres?"

# game/beyond the bet/day6dlc.rpy:3793
translate Spanish da6altinroom_ae1a1e86:

    # GRC "You're making it sound as if they're less than perfect, though."
    GRC "Aunque lo haces sonar como si fueran menos que perfectos."

# game/beyond the bet/day6dlc.rpy:3802
translate Spanish da6altinroom_008afe10_2:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3804
translate Spanish da6altinroom_16a48c26:

    # GRC "It is the least I could do."
    GRC "Es lo mínimo que podía hacer."

# game/beyond the bet/day6dlc.rpy:3812
translate Spanish da6altinroom_65122790:

    # GRC "I..."
    GRC "Yo..."

# game/beyond the bet/day6dlc.rpy:3814
translate Spanish da6altinroom_15464321:

    # GRC "You're sick. What kind of person would I be if I just left you alone?"
    GRC "Estás enferm[letra]. ¿Qué clase de persona sería si te dejara sol[letra]?"

# game/beyond the bet/day6dlc.rpy:3816
translate Spanish da6altinroom_bcca5209:

    # GRC "Go on, eat."
    GRC "Anda, come."

# game/beyond the bet/day6dlc.rpy:3817
translate Spanish da6altinroom_790e71eb:

    # "{i}You look down at the food.{/i}"
    "{i}Miras la comida.{/i}"

# game/beyond the bet/day6dlc.rpy:3818
translate Spanish da6altinroom_2c1c262a:

    # "{i}You look back at Casper.{/i}"
    "{i}Miras de nuevo a Casper.{/i}"

# game/beyond the bet/day6dlc.rpy:3819
translate Spanish da6altinroom_6e808704:

    # "{i}You look at the food again.{/i}"
    "{i}Miras otra vez la comida.{/i}"

# game/beyond the bet/day6dlc.rpy:3820
translate Spanish da6altinroom_14e72689:

    # "{i}And you decide that, for him, you'd eat it.{/i}"
    "{i}Y decides que, por él, te los comerías.{/i}"

# game/beyond the bet/day6dlc.rpy:3821
translate Spanish da6altinroom_bc6581fc:

    # "{i}Fortunately, it's not burnt all the way through!{/i}"
    "{i}¡Por suerte no están quemados por dentro!{/i}"

# game/beyond the bet/day6dlc.rpy:3822
translate Spanish da6altinroom_1783a9c0:

    # "{i}The middle is raw, somehow.{/i}"
    "{i}El centro está crudo, de alguna manera.{/i}"

# game/beyond the bet/day6dlc.rpy:3823
translate Spanish da6altinroom_b3239ce9:

    # "{i}Lovely.{/i}"
    "{i}Qué maravilla.{/i}"

# game/beyond the bet/day6dlc.rpy:3824
translate Spanish da6altinroom_17cd7ec8:

    # "{i}Still, it's not TERRIBLE terrible, and you manage to get it down.{/i}"
    "{i}Aun así, no están TERRIBLES terribles, y logras tragarlos.{/i}"

# game/beyond the bet/day6dlc.rpy:3826
translate Spanish da6altinroom_c93257ee:

    # GRC "So?"
    GRC "¿Y?"

# game/beyond the bet/day6dlc.rpy:3827
translate Spanish da6altinroom_247cd4c5:

    # GRC "H... how was it?"
    GRC "¿C... cómo estuvo?"

# game/beyond the bet/day6dlc.rpy:3838
translate Spanish da6altinroom_cbcdcb9f:

    # GRC "My calling is being a reaper, though I suppose a sidejob wouldn't be so bad."
    GRC "Mi vocación es ser parca, aunque supongo que un trabajo secundario no estaría mal."

# game/beyond the bet/day6dlc.rpy:3839
translate Spanish da6altinroom_2bdf258d:

    # GRC "Still, doing this for you is enough for me."
    GRC "Aun así, hacer esto por ti es suficiente para mí."

# game/beyond the bet/day6dlc.rpy:3844
translate Spanish da6altinroom_1a42729f:

    # GRC "Hah. I knew you'd say that."
    GRC "Ja. Sabía que dirías eso."

# game/beyond the bet/day6dlc.rpy:3845
translate Spanish da6altinroom_fe576458:

    # GRC "I can do anything I put my mind to."
    GRC "Puedo hacer cualquier cosa que me proponga."

# game/beyond the bet/day6dlc.rpy:3852
translate Spanish da6altinroom_f6e5af7b:

    # GRC "You seem to have brightened up a little... but you must be running a fever."
    GRC "Pareces haberte animado un poco... pero debes de tener fiebre."

# game/beyond the bet/day6dlc.rpy:3863
translate Spanish da6altinroom_b992fe79:

    # "{i}Casper takes the plate from you and sets it aside, before coming back to sit on the edge of your bed.{/i}"
    "{i}Casper te quita el plato y lo deja a un lado, antes de volver a sentarse en el borde de tu cama.{/i}"

# game/beyond the bet/day6dlc.rpy:3864
translate Spanish da6altinroom_bfdb2acb:

    # "{i}He looks down at his gloves, conflicted, before he pulls them off.{/i}"
    "{i}Se mira los guantes, indeciso, antes de quitárselos.{/i}"

# game/beyond the bet/day6dlc.rpy:3865
translate Spanish da6altinroom_68bc354f:

    # "{i}His fingers are long and thin, and his hands are without a single blemish.{/i}"
    "{i}Sus dedos son largos y delgados, y sus manos no tienen ni una sola imperfección.{/i}"

# game/beyond the bet/day6dlc.rpy:3866
translate Spanish da6altinroom_2e6fb791:

    # "{i}Of course, knowing Casper, that was a given.{/i}"
    "{i}Por supuesto, conociendo a Casper, eso era de esperarse.{/i}"

# game/beyond the bet/day6dlc.rpy:3867
translate Spanish da6altinroom_9a704bf6:

    # "{i}Your heart skips a beat as he raises his hand to your forehead.{/i}"
    "{i}Tu corazón da un vuelco cuando él lleva la mano a tu frente.{/i}"

# game/beyond the bet/day6dlc.rpy:3868
translate Spanish da6altinroom_f2d85d68:

    # "{i}His fingers are cool and refreshing. You feel yourself almost lean into his touch.{/i}"
    "{i}Sus dedos son frescos y reconfortantes. Casi te inclinas hacia su tacto.{/i}"

# game/beyond the bet/day6dlc.rpy:3869
translate Spanish da6altinroom_d0d0cf14:

    # "{i}You look up and into his eyes, which look back down towards you.{/i}"
    "{i}Levantas la vista hacia sus ojos, que te devuelven la mirada.{/i}"

# game/beyond the bet/day6dlc.rpy:3871
translate Spanish da6altinroom_4136f301:

    # "{i}You see yourself reflected in those red eyes.{/i}"
    "{i}Te ves reflejad[letra] en esos ojos rojos.{/i}"

# game/beyond the bet/day6dlc.rpy:3872
translate Spanish da6altinroom_ffa5e88d:

    # "{i}He opens his mouth, as if to say something, then closes it again. He does this a few times, and you wonder to yourself what exactly he wants to say to you.{/i}"
    "{i}Abre la boca, como para decir algo, y luego la cierra de nuevo. Lo hace varias veces, y te preguntas qué es exactamente lo que quiere decirte.{/i}"

# game/beyond the bet/day6dlc.rpy:3873
translate Spanish da6altinroom_af332746:

    # "{i}But he never gets the chance.{/i}"
    "{i}Pero nunca tiene la oportunidad.{/i}"

# game/beyond the bet/day6dlc.rpy:3877
translate Spanish da6altinroom_1eebe12d:

    # "{i}There's a zap, as if an electric current had just passed between the two of you. Casper pulls his hand back in a flash.{/i}"
    "{i}Hay una chispa, como si una corriente eléctrica acabara de pasar entre ustedes. Casper aparta la mano en un instante.{/i}"

# game/beyond the bet/day6dlc.rpy:3891
translate Spanish da6altinroom_4aa86442:

    # GRC "What the..."
    GRC "Qué demo..."

# game/beyond the bet/day6dlc.rpy:3900
translate Spanish da6altinroom_008afe10_3:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3905
translate Spanish da6altinroom_96c52ff1:

    # "{i}He stares down towards his hand incredulously.{/i}"
    "{i}Mira su mano con incredulidad.{/i}"

# game/beyond the bet/day6dlc.rpy:3906
translate Spanish da6altinroom_815eddaf:

    # "{i}Unsure, he reaches back out towards you, his hand finding your cheek.{/i}"
    "{i}Inseguro, vuelve a extenderla hacia ti, y su mano encuentra tu mejilla.{/i}"

# game/beyond the bet/day6dlc.rpy:3907
translate Spanish da6altinroom_8b25ab07:

    # "{i}It's not as abrupt this time, but you feel it. Like an electric buzz where your skin meets.{/i}"
    "{i}No es tan brusco esta vez, pero lo sientes. Como un zumbido eléctrico donde se encuentra la piel.{/i}"

# game/beyond the bet/day6dlc.rpy:3909
translate Spanish da6altinroom_008afe10_4:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3910
translate Spanish da6altinroom_5b551642:

    # GRC "It must be because of our... connection."
    GRC "Debe de ser por nuestra... conexión."

# game/beyond the bet/day6dlc.rpy:3912
translate Spanish da6altinroom_7b300b9d:

    # GRC "Our bodies react to our touch."
    GRC "Nuestros cuerpos reaccionan a nuestro tacto."

# game/beyond the bet/day6dlc.rpy:3913
translate Spanish da6altinroom_9519adb7:

    # GRC "How strange. I've never read of anything like it."
    GRC "Qué extraño. Nunca he leído nada parecido."

# game/beyond the bet/day6dlc.rpy:3914
translate Spanish da6altinroom_7faac88e:

    # "{i}You lean into his touch again.{/i}"
    "{i}Te inclinas otra vez hacia su tacto.{/i}"

# game/beyond the bet/day6dlc.rpy:3915
translate Spanish da6altinroom_b116c91a:

    # "{i}It feels... nice.{/i}"
    "{i}Se siente... bien.{/i}"

# game/beyond the bet/day6dlc.rpy:3916
translate Spanish da6altinroom_3b15df29:

    # "{i}There's silence between the two of you. A silence that seems to stretch out for far longer than it's really been.{/i}"
    "{i}Hay silencio entre ustedes. Un silencio que parece alargarse mucho más de lo que realmente ha durado.{/i}"

# game/beyond the bet/day6dlc.rpy:3917
translate Spanish da6altinroom_b5e9ad0d:

    # "{i}It's filled with a common understanding.{/i}"
    "{i}Está lleno de un entendimiento mutuo.{/i}"

# game/beyond the bet/day6dlc.rpy:3918
translate Spanish da6altinroom_68a17cde:

    # "{i}Tomorrow, you must die.{/i}"
    "{i}Mañana debes morir.{/i}"

# game/beyond the bet/day6dlc.rpy:3919
translate Spanish da6altinroom_0e7ffeac:

    # "{i}If you don't, then you win the bet, and his soul is yours for the taking.{/i}"
    "{i}Si no lo haces, ganas la apuesta, y su alma es tuya.{/i}"

# game/beyond the bet/day6dlc.rpy:3920
translate Spanish da6altinroom_d933d7be:

    # "{i}You are two people connected by misfortune, both trying desperately to avoid the inevitable.{/i}"
    "{i}Ustedes son dos personas unidas por la desgracia, ambas intentando desesperadamente evitar lo inevitable.{/i}"

# game/beyond the bet/day6dlc.rpy:3921
translate Spanish da6altinroom_0b409f4b:

    # GRC "Sunshine, I..."
    GRC "Solecito, yo..."

# game/beyond the bet/day6dlc.rpy:3926
translate Spanish da6altinroom_65122790_1:

    # GRC "I..."
    GRC "Yo..."

# game/beyond the bet/day6dlc.rpy:3927
translate Spanish da6altinroom_efb1c8b9:

    # GRC "I... should go."
    GRC "Yo... debería irme."

# game/beyond the bet/day6dlc.rpy:3939
translate Spanish da6altinroom_731da278:

    # GRC "W... what?"
    GRC "¿Q... qué?"

# game/beyond the bet/day6dlc.rpy:3946
translate Spanish da6altinroom_008afe10_5:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3950
translate Spanish da6altinroom_de747f51:

    # GRC "...Okay."
    GRC "...Okey."

# game/beyond the bet/day6dlc.rpy:3951
translate Spanish da6altinroom_68d74d1e:

    # "{i}The room is even darker now. The sun set some time ago, but you barely even noticed it.{/i}"
    "{i}La habitación está aún más oscura ahora. El sol se puso hace rato, pero apenas lo notaste.{/i}"

# game/beyond the bet/day6dlc.rpy:3952
translate Spanish da6altinroom_17ecd5b5:

    # "{i}You were too concerned with the man in front of you.{/i}"
    "{i}Estabas demasiado preocupad[letra] por el hombre frente a ti.{/i}"

# game/beyond the bet/day6dlc.rpy:3953
translate Spanish da6altinroom_aa2b4c4e:

    # "{i}The man you've come to be quite fond of.{/i}"
    "{i}El hombre que has llegado a apreciar bastante.{/i}"

# game/beyond the bet/day6dlc.rpy:3958
translate Spanish da6altinroom_1e17dd6b:

    # GRC "I... hardly need to sleep, anyway."
    GRC "Yo... apenas necesito dormir, la verdad."

# game/beyond the bet/day6dlc.rpy:3963
translate Spanish da6altinroom_9ce88654:

    # GRC "S... sleep? With you?!"
    GRC "¿D... dormir? ¡¿Contigo?!"

# game/beyond the bet/day6dlc.rpy:3983
translate Spanish da6altinroom_8c2662a7:

    # GRC "Ah..."
    GRC "Ah..."

# game/beyond the bet/day6dlc.rpy:3985
translate Spanish da6altinroom_b916a7b8:

    # GRC "Of... of course."
    GRC "Cl... claro."

# game/beyond the bet/day6dlc.rpy:3986
translate Spanish da6altinroom_6676af43:

    # GRC "I knew that. Obviously."
    GRC "Lo sabía. Obviamente."

# game/beyond the bet/day6dlc.rpy:3988
translate Spanish da6altinroom_008afe10_6:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:3989
translate Spanish da6altinroom_76a70683:

    # GRC "You are inviting death into bed with you, Sunshine."
    GRC "Estás invitando a la muerte a tu cama, Solecito."

# game/beyond the bet/day6dlc.rpy:3991
translate Spanish da6altinroom_a14c9807:

    # GRC "It never ends well."
    GRC "Nunca termina bien."

# game/beyond the bet/day6dlc.rpy:3992
translate Spanish da6altinroom_4df4a2ab:

    # GRC "Not for anyone."
    GRC "Para nadie."

# game/beyond the bet/day6dlc.rpy:4001
translate Spanish da6altinroom_6d9a6ec2:

    # GRC "You have no sense of danger."
    GRC "No tienes sentido del peligro."

# game/beyond the bet/day6dlc.rpy:4008
translate Spanish da6altinroom_4d86a658:

    # GRC "I didn't say it was a challenge."
    GRC "No dije que fuera un desafío."

# game/beyond the bet/day6dlc.rpy:4009
translate Spanish da6altinroom_200abd06:

    # GRC "What I'm giving you is a warning."
    GRC "Lo que te estoy dando es una advertencia."

# game/beyond the bet/day6dlc.rpy:4010
translate Spanish da6altinroom_710fbcfe:

    # GRC "A word of advice."
    GRC "Un consejo."

# game/beyond the bet/day6dlc.rpy:4011
translate Spanish da6altinroom_776852e4:

    # GRC "Nothing good can come of this."
    GRC "Nada bueno puede salir de esto."

# game/beyond the bet/day6dlc.rpy:4032
translate Spanish da6altinroom_500c7988:

    # "{i}You take his hand, and pull him down beside you, moving over to give him room.{/i}"
    "{i}Tomas su mano y lo jalas a tu lado, moviéndote para darle espacio.{/i}"

# game/beyond the bet/day6dlc.rpy:4033
translate Spanish da6altinroom_cd072c22:

    # "{i}No one else has ever laid beside you in this bed like this.{/i}"
    "{i}Nadie más se ha acostado nunca así a tu lado en esta cama.{/i}"

# game/beyond the bet/day6dlc.rpy:4034
translate Spanish da6altinroom_44002f3d:

    # "{i}He puts his head down on the pillow, staring at you through the darkness.{/i}"
    "{i}Apoya la cabeza en la almohada, mirándote a través de la oscuridad.{/i}"

# game/beyond the bet/day6dlc.rpy:4044
translate Spanish da6altinroom_e905f2ff:

    # GRC "I wish so many things were different."
    GRC "Desearía que muchas cosas fueran distintas."

# game/beyond the bet/day6dlc.rpy:4048
translate Spanish da6altinroom_008afe10_7:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:4050
translate Spanish da6altinroom_f60c3dc1:

    # GRC "Sometimes I wish I was a human."
    GRC "A veces desearía ser humano."

# game/beyond the bet/day6dlc.rpy:4051
translate Spanish da6altinroom_b27f170e:

    # GRC "Wish I was... capable of change, as you put it."
    GRC "Desearía ser... capaz de cambiar, como dices."

# game/beyond the bet/day6dlc.rpy:4053
translate Spanish da6altinroom_3c5bcd24:

    # GRC "I've always been proud of my work. I still am."
    GRC "Siempre me he sentido orgulloso de mi trabajo. Todavía lo estoy."

# game/beyond the bet/day6dlc.rpy:4055
translate Spanish da6altinroom_82d63a90:

    # GRC "But that doesn't mean I don't wish for... more."
    GRC "Pero eso no significa que no desee... más."

# game/beyond the bet/day6dlc.rpy:4056
translate Spanish da6altinroom_f6567edd:

    # GRC "For something different."
    GRC "Algo diferente."

# game/beyond the bet/day6dlc.rpy:4060
translate Spanish da6altinroom_3d668133:

    # "{i}He smiles now, just slightly. There's sadness behind it.{/i}"
    "{i}Sonríe ahora, apenas. Hay tristeza detrás de esa sonrisa.{/i}"

# game/beyond the bet/day6dlc.rpy:4062
translate Spanish da6altinroom_e8f55aec:

    # GRC "I'm not like you."
    GRC "No soy como tú."

# game/beyond the bet/day6dlc.rpy:4067
translate Spanish da6altinroom_f07a00b8:

    # GRC "I would do what I wish to do now more than anything."
    GRC "Haría lo que deseo hacer ahora más que nada."

# game/beyond the bet/day6dlc.rpy:4069
translate Spanish da6altinroom_7636e29f:

    # GRC "Something completely foolish."
    GRC "Algo completamente insensato."

# game/beyond the bet/day6dlc.rpy:4075
translate Spanish da6altinroom_008afe10_8:

    # GRC "..."
    GRC "..."

# game/beyond the bet/day6dlc.rpy:4077
translate Spanish da6altinroom_d9b61698:

    # GRC "Get some sleep, Sunshine."
    GRC "Duerme un poco, Solecito."

# game/beyond the bet/day6dlc.rpy:4078
translate Spanish da6altinroom_5f6b2d25:

    # GRC "You feeling better is more important than anything else."
    GRC "Que te sientas mejor es más importante que cualquier otra cosa."

# game/beyond the bet/day6dlc.rpy:4080
translate Spanish da6altinroom_e1404ba7:

    # "{i}Your eyelids feel heavy now.{/i}"
    "{i}Los párpados te pesan ahora.{/i}"

# game/beyond the bet/day6dlc.rpy:4081
translate Spanish da6altinroom_98cc63cd:

    # "{i}Your heart races.{/i}"
    "{i}Tu corazón se acelera.{/i}"

# game/beyond the bet/day6dlc.rpy:4082
translate Spanish da6altinroom_e1fc1a63:

    # "{i}And yet you feel calm. Laying beside this man, you think you've never felt so safe in your life.{/i}"
    "{i}Y sin embargo te sientes en calma. Acostad[letra] junto a este hombre, crees que nunca te has sentido tan segur[letra] en tu vida.{/i}"

# game/beyond the bet/day6dlc.rpy:4083
translate Spanish da6altinroom_24e785a0:

    # "{i}Ironic, really, when he happens to be the Grim Reaper.{/i}"
    "{i}Irónico, en realidad, siendo él la Parca.{/i}"

# game/beyond the bet/day6dlc.rpy:4084
translate Spanish da6altinroom_aa4f1d19:

    # "{i}You slip away, drifting into a peaceful sleep as you feel his hand still in yours.{/i}"
    "{i}Te dejas llevar hacia un sueño apacible mientras sientes su mano aún en la tuya.{/i}"

translate Spanish strings:

    # game/beyond the bet/day6dlc.rpy:33
    old "the flowers suit you..."
    new "{size=18}las flores te quedan bien...{/size}"

    # game/beyond the bet/day6dlc.rpy:62
    old "1. <Casper?>"
    new "1. <¿Casper?>"

    # game/beyond the bet/day6dlc.rpy:68
    old "1. <I just wanted to say thanks.>"
    new "1. <Solo quería darte las gracias.>"

    # game/beyond the bet/day6dlc.rpy:71
    old "1. <It's kinda embarrassing just to type this out, but...>"
    new "1. <Da un poco de vergüenza escribirlo, pero...>"

    # game/beyond the bet/day6dlc.rpy:74
    old "2. <Where's my little reaper?>"
    new "2. <¿Dónde está mi parquita?>"

    # game/beyond the bet/day6dlc.rpy:77
    old "1. <Well, now that we've met properly...>"
    new "1. <Bueno, ahora que nos hemos conocido bien...>"

    # game/beyond the bet/day6dlc.rpy:80
    old "1. <I don't know if 'little' is correct.>"
    new "1. <No sé si 'parquita' sea la palabra correcta.>"

    # game/beyond the bet/day6dlc.rpy:83
    old "1. <I mean, you seem normal sized.>"
    new "1. <O sea, pareces de tamaño normal.>"

    # game/beyond the bet/day6dlc.rpy:86
    old "1. <A normal sized man.>"
    new "1. <Un hombre de tamaño normal.>"

    # game/beyond the bet/day6dlc.rpy:89
    old "1. <Or something.>"
    new "1. <O algo así.>"

    # game/beyond the bet/day6dlc.rpy:92
    old "1. <Anyway...>"
    new "1. <En fin...>"

    # game/beyond the bet/day6dlc.rpy:96
    old "1. <I really am grateful for the flowers.>"
    new "1. <De verdad te agradezco las flores.>"

    # game/beyond the bet/day6dlc.rpy:99
    old "1. <I felt a little stunned yesterday, so... just wanted to make sure you knew.>"
    new "1. <Ayer me quedé un poco aturdid[letra], así que... quería asegurarme de que lo supieras.>"

    # game/beyond the bet/day6dlc.rpy:106
    old "1. <My memory isn't that bad!>"
    new "1. <¡Mi memoria no es tan mala!>"

    # game/beyond the bet/day6dlc.rpy:109
    old "2. <I might be a bit of an airhead, but I remember that much at least!>"
    new "2. <Puede que sea un poco cabeza hueca, ¡pero eso al menos lo recuerdo!>"

    # game/beyond the bet/day6dlc.rpy:112
    old "1. <And I remember your cute face, too.>"
    new "1. <Y también recuerdo tu linda carita.>"

    # game/beyond the bet/day6dlc.rpy:115
    old "1. <Were you feeling shy? >"
    new "1. <¿Te dio vergüenza?>"

    # game/beyond the bet/day6dlc.rpy:118
    old "1. <Your ears were red!>"
    new "1. <¡Tenías las orejas rojas!>"

    # game/beyond the bet/day6dlc.rpy:124
    old "1. <Is the rest of you not worth admiring?>"
    new "1. <¿El resto de ti no merece ser admirado?>"

    # game/beyond the bet/day6dlc.rpy:130
    old "1. <Yeah, you're pretty alluring.>"
    new "1. <Sí, eres bastante cautivador.>"

    # game/beyond the bet/day6dlc.rpy:132
    old "2. <To be honest, I can't keep my eyes off you.>"
    new "2. <Para ser sincer[letra], no puedo apartar los ojos de ti.>"

    # game/beyond the bet/day6dlc.rpy:136
    old "2. <I think even your shoulders were blushing.>"
    new "2. <Creo que hasta tus hombros se sonrojaron.>"

    # game/beyond the bet/day6dlc.rpy:139
    old "1. <Is that possible? Does my charm make your full body blush?>"
    new "1. <¿Es eso posible? ¿Mi encanto te hace sonrojar de pies a cabeza?>"

    # game/beyond the bet/day6dlc.rpy:145
    old "1. <Maybe you're not like other reapers.>"
    new "1. <Quizá no eres como las otras parcas.>"

    # game/beyond the bet/day6dlc.rpy:149
    old "1. <Blushing is your normal, I'm afraid.>"
    new "1. <Me temo que sonrojarte es lo normal en ti.>"

    # game/beyond the bet/day6dlc.rpy:154
    old "1. <How so?>"
    new "1. <¿Por qué lo dices?>"

    # game/beyond the bet/day6dlc.rpy:158
    old "1. <Teasing? Perfect? Fantastic? Gorgeous?>"
    new "1. <¿Bromista? ¿Perfect[letra]? ¿Fantástic[letra]? ¿Guapísim[letra]?>"

    # game/beyond the bet/day6dlc.rpy:160
    old "2. <Sarcastic? Hilarious? Inspiring? Considerate?>"
    new "2. <¿Sarcástic[letra]? ¿Gracios[letra]? ¿Admirable? ¿Considerad[letra]?>"

    # game/beyond the bet/day6dlc.rpy:164
    old "1. <You're not disagreeing!>"
    new "1. <¡No lo niegas!>"

    # game/beyond the bet/day6dlc.rpy:168
    old "1. <I'll take it.>"
    new "1. <Con eso me basta.>"

    # game/beyond the bet/day6dlc.rpy:171
    old "2. <That's one point to me.>"
    new "2. <Un punto para mí.>"

    # game/beyond the bet/day6dlc.rpy:174
    old "2. <Maybe they were.>"
    new "2. <Quizás lo fueron.>"

    # game/beyond the bet/day6dlc.rpy:187
    old "1. <...Is that all true?>"
    new "1. <...¿Todo eso es verdad?>"

    # game/beyond the bet/day6dlc.rpy:191
    old "1. <You can't lie!>"
    new "1. <¡No puedes mentir!>"

    # game/beyond the bet/day6dlc.rpy:194
    old "3. <Well, I love them!>"
    new "3. <¡Pues a mí me encantan!>"

    # game/beyond the bet/day6dlc.rpy:198
    old "1. <I told you that already, silly man.>"
    new "1. <Ya te lo dije, tontito.>"

    # game/beyond the bet/day6dlc.rpy:203
    old "1. <Then you should listen properly, mister.>"
    new "1. <Entonces deberías escuchar bien, señor.>"

    # game/beyond the bet/day6dlc.rpy:206
    old "1. <I love these flowers.>"
    new "1. <Me encantan estas flores.>"

    # game/beyond the bet/day6dlc.rpy:209
    old "1. <I'm thinking of pressing them in a few days.>"
    new "1. <Estoy pensando en prensarlas dentro de unos días.>"

    # game/beyond the bet/day6dlc.rpy:213
    old "1. <Like, drying them flat in a book or something.>"
    new "1. <O sea, secarlas bien planas dentro de un libro o algo así.>"

    # game/beyond the bet/day6dlc.rpy:216
    old "1. <Then maybe I can use the petals for a bookmark or something.>"
    new "1. <Así quizá pueda usar los pétalos como marcapáginas o algo así.>"

    # game/beyond the bet/day6dlc.rpy:218
    old "2. <You know, like some people do with their wedding bouquets.>"
    new "2. <Ya sabes, como hacen algunas personas con sus ramos de boda.>"

    # game/beyond the bet/day6dlc.rpy:221
    old "1. <I dunno yet. I just wanna keep them forever.>"
    new "1. <Todavía no lo sé. Solo quiero conservarlas para siempre.>"

    # game/beyond the bet/day6dlc.rpy:223
    old "2. <Don't you think that would be nice?>"
    new "2. <¿No crees que sería bonito?>"

    # game/beyond the bet/day6dlc.rpy:227
    old "1. <Then they'll be with me forever.>"
    new "1. <Así estarán conmigo para siempre.>"

    # game/beyond the bet/day6dlc.rpy:232
    old "1. <Right!>"
    new "1. <¡Cierto!>"

    # game/beyond the bet/day6dlc.rpy:235
    old "1. <Soul taking, and all that.>"
    new "1. <Lo de llevarte el alma y todo eso.>"

    # game/beyond the bet/day6dlc.rpy:239
    old "1. <It's hard to be scared of you, Grim.>"
    new "1. <Es difícil tenerte miedo, Parca.>"

    # game/beyond the bet/day6dlc.rpy:241
    old "2. <You're too sweet to be afraid of.>"
    new "2. <Eres demasiado dulce para temerte.>"

    # game/beyond the bet/day6dlc.rpy:245
    old "1. <Mister Big Bad Scary Grim Reaper.>"
    new "1. <Señor Parca Grande, Malo y Aterrador.>"

    # game/beyond the bet/day6dlc.rpy:250
    old "2. <I didn't know I could enjoy flowers so much.>"
    new "2. <No sabía que podía disfrutar tanto de las flores.>"

    # game/beyond the bet/day6dlc.rpy:253
    old "1. <They're... refreshing to have around. I'll be sad when they die.>"
    new "1. <Son... refrescantes. Da gusto tenerlas cerca. Me pondré triste cuando se marchiten.>"

    # game/beyond the bet/day6dlc.rpy:259
    old "1. <Someone like...?>"
    new "1. <¿Alguien como...?>"

    # game/beyond the bet/day6dlc.rpy:264
    old "1. <Can't say I know anyone like that.>"
    new "1. <No creo conocer a nadie así.>"

    # game/beyond the bet/day6dlc.rpy:266
    old "2. <Hmmm... who could that be?>"
    new "2. <Mmm... ¿quién podrá ser?>"

    # game/beyond the bet/day6dlc.rpy:270
    old "1. <Hmm... still thinking, but there really is no one like that.>"
    new "1. <Mmm... sigo pensando, pero de verdad no hay nadie así.>"

    # game/beyond the bet/day6dlc.rpy:274
    old "1. <Just kidding ;)>"
    new "1. <Era broma ;)>"

    # game/beyond the bet/day6dlc.rpy:279
    old "1. <What if I do?>"
    new "1. <¿Y si es así?>"

    # game/beyond the bet/day6dlc.rpy:283
    old "1. <There's something freeing about making a handsome man blush.>"
    new "1. <Hay algo liberador en hacer sonrojar a un hombre guapo.>"

    # game/beyond the bet/day6dlc.rpy:286
    old "1. <I fear I'm going crazy with the power I hold.>"
    new "1. <Me temo que me estoy volviendo loc[letra] con el poder que tengo.>"

    # game/beyond the bet/day6dlc.rpy:289
    old "1. <This is my supervillain origin story.>"
    new "1. <Este es mi origen como supervillan[letra].>"

    # game/beyond the bet/day6dlc.rpy:293
    old "1. <Don't you think I'd make a good supervillain?>"
    new "1. <¿No crees que se me daría bien ser [arti_2] supervillan[letra]?>"

    # game/beyond the bet/day6dlc.rpy:297
    old "1. <WHAT!>"
    new "1. <¡¿QUÉ?!>"

    # game/beyond the bet/day6dlc.rpy:299
    old "2. <???>"
    new "2. <???>"

    # game/beyond the bet/day6dlc.rpy:303
    old "1. <Why not?!>"
    new "1. <¡¿Por qué no?!>"

    # game/beyond the bet/day6dlc.rpy:309
    old "1. <Yeah, probably not.>"
    new "1. <Sí, probablemente no.>"

    # game/beyond the bet/day6dlc.rpy:312
    old "1. <I think you'd make a good supervillain, though.>"
    new "1. <Aunque creo que tú sí serías un buen supervillano.>"

    # game/beyond the bet/day6dlc.rpy:316
    old "1. <Well, you kinda have the aesthetic down already.>"
    new "1. <Bueno, ya tienes la estética.>"

    # game/beyond the bet/day6dlc.rpy:320
    old "1. <Like, you look kinda broody and evil until you open your mouth.>"
    new "1. <O sea, tienes pinta de sombrío y malvado hasta que abres la boca.>"

    # game/beyond the bet/day6dlc.rpy:323
    old "1. <And you can fly! And make yourself look like a bird!>"
    new "1. <¡Y puedes volar! ¡Y hacerte pasar por un pájaro!>"

    # game/beyond the bet/day6dlc.rpy:326
    old "1. <You literally already have superpowers.>"
    new "1. <Literalmente ya tienes superpoderes.>"

    # game/beyond the bet/day6dlc.rpy:332
    old "1. <I'm literally going to look at animals differently, now...>"
    new "1. <Literalmente, ahora voy a mirar a los animales de otra forma...>"

    # game/beyond the bet/day6dlc.rpy:335
    old "1. <They're all incognito reapers...>"
    new "1. <Todos son parcas de incógnito...>"

    # game/beyond the bet/day6dlc.rpy:339
    old "1. <Wait, do you have any other superpowers?>"
    new "1. <Espera, ¿tienes otros superpoderes?>"

    # game/beyond the bet/day6dlc.rpy:343
    old "1. <Okay, do you have any other {i}'abilities'{/i}?>"
    new "1. <Okey, ¿tienes otras {i}'habilidades'{/i}?>"

    # game/beyond the bet/day6dlc.rpy:347
    old "1. <Super strength?>"
    new "1. <¿Superfuerza?>"

    # game/beyond the bet/day6dlc.rpy:351
    old "1. <Invisibility?>"
    new "1. <¿Invisibilidad?>"

    # game/beyond the bet/day6dlc.rpy:355
    old "1. <Nope.>"
    new "1. <Nop.>"

    # game/beyond the bet/day6dlc.rpy:357
    old "2. <Close, but no cigar.>"
    new "2. <Casi, pero no hay premio.>"

    # game/beyond the bet/day6dlc.rpy:361
    old "1. <Wait, can you see through clothes?>"
    new "1. <Espera, ¿puedes ver a través de la ropa?>"

    # game/beyond the bet/day6dlc.rpy:366
    old "1. <Definitely the super power of a super villain...>"
    new "1. <Definitivamente, el superpoder de un supervillano...>"

    # game/beyond the bet/day6dlc.rpy:369
    old "1. <I'm onto you, Grimmy.>"
    new "1. <Ya te descubrí, Parquita.>"

    # game/beyond the bet/day6dlc.rpy:373
    old "1. <Oh? :(>"
    new "1. <¿Ah, no? :(>"

    # game/beyond the bet/day6dlc.rpy:379
    old "1. <So... you DO want to look through them?>"
    new "1. <Entonces... ¿SÍ quieres ver a través de la ropa?>"

    # game/beyond the bet/day6dlc.rpy:383
    old "1. <Refusal is an answer itself.>"
    new "1. <Negarse ya es una respuesta.>"

    # game/beyond the bet/day6dlc.rpy:387
    old "1. <Fortunately, you don't have to listen, only see.>"
    new "1. <Por suerte, no tienes que escuchar, solo ver.>"

    # game/beyond the bet/day6dlc.rpy:391
    old "1. <I thought you couldn't lie!>"
    new "1. <¡Creía que no podías mentir!>"

    # game/beyond the bet/day6dlc.rpy:395
    old "1. <Then you can see it again!>"
    new "1. <¡Entonces ya puedes volver a verla!>"

    # game/beyond the bet/day6dlc.rpy:399
    old "2. <I know, I trust you wouldn't.>"
    new "2. <Lo sé, confío en que no lo harías.>"

    # game/beyond the bet/day6dlc.rpy:404
    old "1. <Thanks Grimmy.>"
    new "1. <Gracias, Parquita.>"

    # game/beyond the bet/day6dlc.rpy:406
    old "2. <We love a well mannered reaper.>"
    new "2. <Nos encanta una parca con buenos modales.>"

    # game/beyond the bet/day6dlc.rpy:410
    old "1. <I'll keep it in mind.>"
    new "1. <Lo tendré en cuenta.>"

    # game/beyond the bet/day6dlc.rpy:416
    old "2. <You can't even imagine the heinous acts I would commit for my child.>"
    new "2. <No te imaginas los actos atroces que cometería por mi hij[letra_pet].>"

    # game/beyond the bet/day6dlc.rpy:419
    old "1. <If someone hurt [pet_her2], I would burn the world down.>"
    new "1. <Si alguien le hiciera daño a [pet_name], quemaría el mundo entero.>"

    # game/beyond the bet/day6dlc.rpy:425
    old "1. <[pet_name], of course.>"
    new "1. <[pet_name], por supuesto.>"

    # game/beyond the bet/day6dlc.rpy:429
    old "1. <My pet, of course.>"
    new "1. <Mi mascota, por supuesto.>"

    # game/beyond the bet/day6dlc.rpy:436
    old "1. <That what?>"
    new "1. <¿Esa qué?>"

    # game/beyond the bet/day6dlc.rpy:441
    old "1. <...>"
    new "1. <...>"

    # game/beyond the bet/day6dlc.rpy:444
    old "1. <Casper, that's YEARS old!>"
    new "1. <¡Casper, eso es de hace AÑOS!>"

    # game/beyond the bet/day6dlc.rpy:447
    old "1. <That child is an adult now.>"
    new "1. <Esa niña ya es adulta.>"

    # game/beyond the bet/day6dlc.rpy:452
    old "1. <Don't we just age at normal rates?>"
    new "1. <¿No envejecemos a un ritmo normal?>"

    # game/beyond the bet/day6dlc.rpy:457
    old "1. <Touche.>"
    new "1. <Touché.>"

    # game/beyond the bet/day6dlc.rpy:460
    old "1. <Memes don't really age very well, anyway.>"
    new "1. <Además, los memes no envejecen muy bien que digamos.>"

    # game/beyond the bet/day6dlc.rpy:463
    old "1. <You gotta keep up to date with those things, Caspy-waspy.>"
    new "1. <Tienes que mantenerte al día con esas cosas, Caspy-waspy.>"

    # game/beyond the bet/day6dlc.rpy:467
    old "1. <No? You don't like that one?>"
    new "1. <¿No? ¿No te gusta ese?>"

    # game/beyond the bet/day6dlc.rpy:473
    old "2. <Creative?>"
    new "2. <¿Creativa?>"

    # game/beyond the bet/day6dlc.rpy:475
    old "3. <Cute?>"
    new "3. <¿Tierna?>"

    # game/beyond the bet/day6dlc.rpy:477
    old "4. <Fitting?>"
    new "4. <¿Apropiada?>"

    # game/beyond the bet/day6dlc.rpy:481
    old "1. <Soooo... do you like it or not?>"
    new "1. <Entoooonces... ¿te gusta o no?>"

    # game/beyond the bet/day6dlc.rpy:485
    old "1. <Awww. You like it!>"
    new "1. <¡Aww! ¡Te gusta!>"

    # game/beyond the bet/day6dlc.rpy:488
    old "1. <Sunshine and Caspy-waspy :)>"
    new "1. <Solecito y Caspy-waspy :)>"

    # game/beyond the bet/day6dlc.rpy:494
    old "2. <I have a kink for blushing Grim Reapers.>"
    new "2. <Tengo un fetiche con las Parcas sonrojadas.>"

    # game/beyond the bet/day6dlc.rpy:498
    old "1. <Oh, all capitals. Things are getting serious.>"
    new "1. <Oh, todo en mayúsculas. Las cosas se ponen serias.>"

    # game/beyond the bet/day6dlc.rpy:502
    old "1. <Just the one, actually.>"
    new "1. <Solo una, en realidad.>"

    # game/beyond the bet/day6dlc.rpy:506
    old "1. <It's a new discovery of mine.>"
    new "1. <Es un nuevo descubrimiento.>"

    # game/beyond the bet/day6dlc.rpy:509
    old "1. <You should be proud, Grimmy. You've inspired this in me <3>"
    new "1. <Deberías estar orgulloso, Parquita. Tú me inspiraste esto <3>"

    # game/beyond the bet/day6dlc.rpy:515
    old "1. <Probably more.>"
    new "1. <Probablemente más.>"

    # game/beyond the bet/day6dlc.rpy:518
    old "1. <Luckily I think it's adorable.>"
    new "1. <Por suerte, me parece adorable.>"

    # game/beyond the bet/day6dlc.rpy:522
    old "1. <Hey, if that's what you want.>"
    new "1. <Oye, si eso es lo que quieres.>"

    # game/beyond the bet/day6dlc.rpy:525
    old "1. <I'll let you come sit on my lap. Come here, boy.>"
    new "1. <Te dejaré sentarte en mi regazo. Ven aquí, chico.>"

    # game/beyond the bet/day6dlc.rpy:529
    old "1. <Go on, roll over. There's a good boy! Who wants a treat?>"
    new "1. <Vamos, date la vuelta. ¡Así, buen chico! ¿Quién quiere un premio?>"

    # game/beyond the bet/day6dlc.rpy:533
    old "1. <You can come over and sleep on my lap, then <3>"
    new "1. <Entonces puedes venir a dormir en mi regazo <3>"

    # game/beyond the bet/day6dlc.rpy:539
    old "1. <I think I'm being pretty transparent about my intentions, Grimmy.>"
    new "1. <Creo que estoy siendo bastante transparente con mis intenciones, Parquita.>"

    # game/beyond the bet/day6dlc.rpy:542
    old "1. <I like doing things that make you blush.>"
    new "1. <Me gusta hacer cosas que te hagan sonrojar.>"

    # game/beyond the bet/day6dlc.rpy:547
    old "1. <Give it a go, then.>"
    new "1. <Inténtalo, entonces.>"

    # game/beyond the bet/day6dlc.rpy:562
    old "1. <Is that true?>"
    new "1. <¿Es verdad?>"

    # game/beyond the bet/day6dlc.rpy:567
    old "1. <Well... maybe I think that sounds perfect too.>"
    new "1. <Bueno... quizá a mí también me parece perfecto.>"

    # game/beyond the bet/day6dlc.rpy:571
    old "1. <A little.>"
    new "1. <Un poco.>"

    # game/beyond the bet/day6dlc.rpy:575
    old "2. <...Quite a bit, yes.>"
    new "2. <...Bastante, sí.>"

    # game/beyond the bet/day6dlc.rpy:579
    old "2. <There was one other reaper, actually.>"
    new "2. <En realidad, conocí a otra parca.>"

    # game/beyond the bet/day6dlc.rpy:583
    old "1. <I think his name was... Jeremy?>"
    new "1. <Creo que se llamaba... ¿Jeremy?>"

    # game/beyond the bet/day6dlc.rpy:592
    old "1. <Poor, poor Jeremy...>"
    new "1. <Pobre, pobre Jeremy...>"

    # game/beyond the bet/day6dlc.rpy:598
    old "1. <But Jeremy and I are friends :(>"
    new "1. <Pero Jeremy y yo somos amigos :(>"

    # game/beyond the bet/day6dlc.rpy:603
    old "1. <What about you, then?>"
    new "1. <¿Y tú, entonces?>"

    # game/beyond the bet/day6dlc.rpy:606
    old "1. <You want me to die, but you bring me flowers?>"
    new "1. <¿Quieres que me muera, pero me traes flores?>"

    # game/beyond the bet/day6dlc.rpy:609
    old "1. <Are you tricking me?>"
    new "1. <¿Me estás engañando?>"

    # game/beyond the bet/day6dlc.rpy:614
    old "1. <Actually, you're both pretty similar.>"
    new "1. <En realidad, son bastante parecidos.>"

    # game/beyond the bet/day6dlc.rpy:617
    old "1. <Do all of you reapers have white hair and red eyes?>"
    new "1. <¿Todas las parcas tienen el pelo blanco y los ojos rojos?>"

    # game/beyond the bet/day6dlc.rpy:621
    old "1. <Once or twice.>"
    new "1. <Una o dos veces.>"

    # game/beyond the bet/day6dlc.rpy:623
    old "2. <Maaaybe.>"
    new "2. <Quizááá.>"

    # game/beyond the bet/day6dlc.rpy:630
    old "1. <Wait, forget Jeremy. You really don't all look alike?>"
    new "1. <Espera, olvida a Jeremy. ¿De verdad no se parecen todos?>"

    # game/beyond the bet/day6dlc.rpy:635
    old "1. <I guess that makes sense.>"
    new "1. <Supongo que tiene sentido.>"

    # game/beyond the bet/day6dlc.rpy:638
    old "1. <I just thought, maybe you were all created in a lab or something to look the same.>"
    new "1. <Solo pensé que quizá los habían creado a todos en un laboratorio o algo así para que se vieran iguales.>"

    # game/beyond the bet/day6dlc.rpy:642
    old "1. <Imagine if it was.>"
    new "1. <Imagínate que lo fuera.>"

    # game/beyond the bet/day6dlc.rpy:645
    old "1. <Right now your love bar would be full.>"
    new "1. <Ahora mismo tendrías la barra de amor llena.>"

    # game/beyond the bet/day6dlc.rpy:649
    old "1. <I just had your ten star heart event, Grimmy. It's definitely full.>"
    new "1. <Acabo de desbloquear tu evento romántico de diez estrellas, Parquita. Esa barra está llenísima.>"

    # game/beyond the bet/day6dlc.rpy:657
    old "1. <Well, you've got that last part right, at least.>"
    new "1. <Bueno, al menos en eso último tienes razón.>"

    # game/beyond the bet/day6dlc.rpy:663
    old "1. <Honestly, I'm starting to think you can't take it.>"
    new "1. <Sinceramente, empiezo a pensar que no aguantas mis provocaciones.>"

    # game/beyond the bet/day6dlc.rpy:666
    old "1. <You like me too much.>"
    new "1. <Te gusto demasiado.>"

    # game/beyond the bet/day6dlc.rpy:670
    old "2. <I dunno, I feel like Jeremy could be the MC...>"
    new "2. <No sé, siento que Jeremy podría ser el personaje principal...>"

    # game/beyond the bet/day6dlc.rpy:676
    old "1. <Yessir.>"
    new "1. <Sí, señor.>"

    # game/beyond the bet/day6dlc.rpy:679
    old "1. <Don't worry, Grimmy, you're the only one for me <3>"
    new "1. <No te preocupes, Parquita, eres el único para mí <3>"

    # game/beyond the bet/day6dlc.rpy:684
    old "2. <Jeremy pulls it off better than you, tbh.>"
    new "2. <Jeremy lo hace mejor que tú, la verdad.>"

    # game/beyond the bet/day6dlc.rpy:689
    old "1. <Hmmm...>"
    new "1. <Mmm...>"

    # game/beyond the bet/day6dlc.rpy:692
    old "1. <Make me :D>"
    new "1. <Oblígame :D>"

    # game/beyond the bet/day6dlc.rpy:696
    old "1. <Promise to bring me flowers again.>"
    new "1. <Prométeme que volverás a traerme flores.>"

    # game/beyond the bet/day6dlc.rpy:701
    old "1. <Yippeeee!>"
    new "1. <¡Yupiii!>"

    # game/beyond the bet/day6dlc.rpy:703
    old "2. <Score.>"
    new "2. <Genial.>"

    # game/beyond the bet/day6dlc.rpy:708
    old "2. <Jeremy isn't real, by the way.>"
    new "2. <Por cierto, Jeremy no existe.>"

    # game/beyond the bet/day6dlc.rpy:712
    old "1. <I tricked you. My bad.>"
    new "1. <Te engañé. Mi error.>"

    # game/beyond the bet/day6dlc.rpy:715
    old "1. <You just make it so easy.>"
    new "1. <Es que me lo pones tan fácil.>"

    # game/beyond the bet/day6dlc.rpy:718
    old "1. <You get so jealous!>"
    new "1. <¡Te pones tan celoso!>"

    # game/beyond the bet/day6dlc.rpy:722
    old "1. <You do.>"
    new "1. <Claro que sí.>"

    # game/beyond the bet/day6dlc.rpy:725
    old "1. <Maybe you really like me?>"
    new "1. <¿Quizá de verdad te gusto?>"

    # game/beyond the bet/day6dlc.rpy:731
    old "1. <Then call me a sinner, baby.>"
    new "1. <Entonces llámame [pecador], cariño.>"

    # game/beyond the bet/day6dlc.rpy:735
    old "1. <That I am, Grimmy. That I am.>"
    new "1. <Así es, Parquita. Así es.>"

    # game/beyond the bet/day6dlc.rpy:740
    old "3. <Maybe it's YOU with the 'being bullied' kink.>"
    new "3. <Quizá el del fetiche de 'que se metan contigo' eres TÚ.>"

    # game/beyond the bet/day6dlc.rpy:743
    old "1. <I'm not judging. If anything, it shows we're super compatible ;)>"
    new "1. <No te juzgo. Al contrario, demuestra que somos súper compatibles ;)>"

    # game/beyond the bet/day6dlc.rpy:748
    old "1. <Wait, you agree?>"
    new "1. <Espera, ¿estás de acuerdo?>"

    # game/beyond the bet/day6dlc.rpy:751
    old "1. <I was joking!>"
    new "1. <¡Estaba bromeando!>"

    # game/beyond the bet/day6dlc.rpy:761
    old "1. <This was way more honesty than I was expecting.>"
    new "1. <No esperaba tanta sinceridad.>"

    # game/beyond the bet/day6dlc.rpy:764
    old "1. <I am astounded rn.>"
    new "1. <Estoy atónit[letra] ahora mismo.>"

    # game/beyond the bet/day6dlc.rpy:767
    old "1. <I guess that's permission to keep on teasin', then.>"
    new "1. <Supongo que entonces tengo permiso para seguir molestándote.>"

    # game/beyond the bet/day6dlc.rpy:769
    old "2. <Well, I don't plan to stop anytime soon :D>"
    new "2. <Bueno, no pienso parar pronto :D>"

    # game/beyond the bet/day6dlc.rpy:772
    old "1. <This arrangement works for me B)>"
    new "1. <Este trato me parece perfecto B)>"

    # game/beyond the bet/day6dlc.rpy:776
    old "2. <It's cute, and honestly it's teaching me something new about myself.>"
    new "2. <Es tierno, y sinceramente me está enseñando algo nuevo sobre mí.>"

    # game/beyond the bet/day6dlc.rpy:779
    old "1. <Turns out I like flustered babygirls.>"
    new "1. <Resulta que me gustan las babygirls que se sonrojan fácilmente.>"

    # game/beyond the bet/day6dlc.rpy:783
    old "2. <Turns out I have a thing for sexy men that are easily flustered.>"
    new "2. <Resulta que tengo debilidad por los hombres sexis que se sonrojan fácilmente.>"

    # game/beyond the bet/day6dlc.rpy:789
    old "1. <*A* Grim Reaper.>"
    new "1. <'Una' Parca.>"

    # game/beyond the bet/day6dlc.rpy:793
    old "1. <Okay, but you're a grim reaper who, usually, is blushing from ear to ear.>"
    new "1. <Okey, pero eres una parca que, normalmente, se sonroja hasta las orejas.>"

    # game/beyond the bet/day6dlc.rpy:796
    old "1. <Are other reapers like that?>"
    new "1. <¿Las otras parcas son así?>"

    # game/beyond the bet/day6dlc.rpy:799
    old "1. <Or are they actually scary?>"
    new "1. <¿O en realidad dan miedo?>"

    # game/beyond the bet/day6dlc.rpy:806
    old "1. <Are there more hot guys?>"
    new "1. <¿Hay más tipos guapos?>"

    # game/beyond the bet/day6dlc.rpy:810
    old "1. <Well, let's be honest, you are very good looking.>"
    new "1. <Bueno, seamos sinceros, eres muy guapo.>"

    # game/beyond the bet/day6dlc.rpy:814
    old "1. <So, are there more?>"
    new "1. <Entonces, ¿hay más?>"

    # game/beyond the bet/day6dlc.rpy:816
    old "2. <Putting you aside, there must be others too.>"
    new "2. <Aparte de ti, seguro que hay otros.>"

    # game/beyond the bet/day6dlc.rpy:821
    old "1. <Well, of course.>"
    new "1. <Claro, por supuesto.>"

    # game/beyond the bet/day6dlc.rpy:823
    old "2. <You're cocky, but not wrong.>"
    new "2. <Eres engreído, pero no te equivocas.>"

    # game/beyond the bet/day6dlc.rpy:826
    old "1. <But even someone a tiny less hot than you would be pretty hot.>"
    new "1. <Pero incluso alguien un poquito menos guapo que tú sería bastante guapo.>"

    # game/beyond the bet/day6dlc.rpy:830
    old "1. <So, no other reapers ever caught your eye?>"
    new "1. <Entonces, ¿ninguna otra parca te llamó la atención?>"

    # game/beyond the bet/day6dlc.rpy:838
    old "1. <Is that why you like me so much?>"
    new "1. <¿Por eso te gusto tanto?>"

    # game/beyond the bet/day6dlc.rpy:845
    old "1. <Something tells me the guy who can't lie thinks I have a kind heart <3>"
    new "1. <Algo me dice que el tipo que no puede mentir cree que tengo buen corazón <3>"

    # game/beyond the bet/day6dlc.rpy:849
    old "2. <Any pretty ladies?>"
    new "2. <¿Alguna chica bonita?>"

    # game/beyond the bet/day6dlc.rpy:853
    old "1. <I'm just wondering...>"
    new "1. <Solo tenía curiosidad...>"

    # game/beyond the bet/day6dlc.rpy:860
    old "1. <:O>"
    new "1. <:O>"

    # game/beyond the bet/day6dlc.rpy:863
    old "1. <I am???>"
    new "1. <¿¿¿YO???>"

    # game/beyond the bet/day6dlc.rpy:867
    old "1. <Grim thinks I'm pleasing to the eye :D >"
    new "1. <A Parca le parezco agradable a la vista :D>"

    # game/beyond the bet/day6dlc.rpy:871
    old "1. <I will definitely remember this forever.>"
    new "1. <Definitivamente lo recordaré para siempre.>"

    # game/beyond the bet/day6dlc.rpy:874
    old "2. <Forget what? What are we talking about?>"
    new "2. <¿Olvidar qué? ¿De qué estamos hablando?>"

    # game/beyond the bet/day6dlc.rpy:879
    old "1. <Definitely, totally, completely forgotten. Yup.>"
    new "1. <Definitivamente, totalmente, completamente olvidado. Sip.>"

    # game/beyond the bet/day6dlc.rpy:882
    old "1. <How flippin' weird, huh?>"
    new "1. <Qué raro, ¿no?>"

    # game/beyond the bet/day6dlc.rpy:885
    old "1. <Big ol' blank space in my brain.>"
    new "1. <Un gran espacio en blanco en mi cerebro.>"

    # game/beyond the bet/day6dlc.rpy:889
    old "1. <My keyboard, but yes!>"
    new "1. <¡En la cara no, por teclado, pero sí!>"

    # game/beyond the bet/day6dlc.rpy:895
    old "1. <How could I not?>"
    new "1. <¿Cómo no iba a hacerlo?>"

    # game/beyond the bet/day6dlc.rpy:898
    old "1. <It's now one of my greatest achievements.>"
    new "1. <Ahora es uno de mis mayores logros.>"

    # game/beyond the bet/day6dlc.rpy:901
    old "1. <Oh!>"
    new "1. <¡Oh!>"

    # game/beyond the bet/day6dlc.rpy:904
    old "1. <Hey, Grim!>"
    new "1. <¡Oye, Parca!>"

    # game/beyond the bet/day6dlc.rpy:907
    old "1. <When you take my soul, can you get me one of those little ads in the newspaper?>"
    new "1. <Cuando me quites el alma, ¿puedes conseguirme uno de esos avisos fúnebres en el periódico?>"

    # game/beyond the bet/day6dlc.rpy:911
    old "1. <Like, '[playerfirstname], gone but not forgotten'?>"
    new "1. <¿Algo como '[playerfirstname], se fue, pero no será olvidad[letra]'?>"

    # game/beyond the bet/day6dlc.rpy:914
    old "1. <But instead, write 'the Grim Reaper found [her] too pleasing to the eye'.>"
    new "1. <Pero en vez de eso, escribe 'La Parca encontró a [playerfirstname] demasiado agradable a la vista'.>"

    # game/beyond the bet/day6dlc.rpy:917
    old "1. <That'll sound metal AF.>"
    new "1. <Eso sonará súper metalero.>"

    # game/beyond the bet/day6dlc.rpy:921
    old "1. <WOAH!>"
    new "1. <¡UY!>"

    # game/beyond the bet/day6dlc.rpy:924
    old "1. <That sounds even cooler!>"
    new "1. <¡Eso suena todavía mejor!>"

    # game/beyond the bet/day6dlc.rpy:927
    old "1. <Wait, is that why you're after my soul?>"
    new "1. <Espera, ¿por eso vas tras mi alma?>"

    # game/beyond the bet/day6dlc.rpy:932
    old "1. <Where would I end up?>"
    new "1. <¿Dónde terminaría?>"

    # game/beyond the bet/day6dlc.rpy:936
    old "1. <Come on, give me some examples.>"
    new "1. <Anda, dame algunos ejemplos.>"

    # game/beyond the bet/day6dlc.rpy:941
    old "1. <You get paid for your work?>"
    new "1. <¿Te pagan por tu trabajo?>"

    # game/beyond the bet/day6dlc.rpy:946
    old "1. <So, the underworld has its own set of laws?>"
    new "1. <¿Entonces el inframundo tiene sus propias leyes?>"

    # game/beyond the bet/day6dlc.rpy:950
    old "1. <So you get paid, but you can't quit?>"
    new "1. <¿Entonces te pagan, pero no puedes renunciar?>"

    # game/beyond the bet/day6dlc.rpy:956
    old "1. <That's really sad.>"
    new "1. <Qué triste.>"

    # game/beyond the bet/day6dlc.rpy:958
    old "2. <It kinda sounds messed up.>"
    new "2. <Suena un poco retorcido.>"

    # game/beyond the bet/day6dlc.rpy:961
    old "1. <I think you should complain to your manager.>"
    new "1. <Creo que deberías quejarte con tu jefe.>"

    # game/beyond the bet/day6dlc.rpy:967
    old "1. <But isn't there more you want to do with your life?>"
    new "1. <Pero ¿no hay algo más que quieras hacer con tu vida?>"

    # game/beyond the bet/day6dlc.rpy:971
    old "1. <Me?>"
    new "1. <¿Yo?>"

    # game/beyond the bet/day6dlc.rpy:975
    old "1. <That's what I said.>"
    new "1. <Eso es lo que dije.>"

    # game/beyond the bet/day6dlc.rpy:980
    old "1. <Come on, wander a bit with me!>"
    new "1. <¡Vamos, divaga un poco conmigo!>"

    # game/beyond the bet/day6dlc.rpy:986
    old "1. <Well, hey, it's not a no.>"
    new "1. <Bueno, oye, no es un no.>"

    # game/beyond the bet/day6dlc.rpy:990
    old "1. <That's only fair, seeing as you're trying to kill me, too.>"
    new "1. <Es justo, ya que tú también estás intentando matarme.>"

    # game/beyond the bet/day6dlc.rpy:993
    old "1. <Might as well go out with a 'bang'.>"
    new "1. <Más vale irme con broche de oro.>"

    # game/beyond the bet/day6dlc.rpy:997
    old "1. <You blushing again?>"
    new "1. <¿Te sonrojaste otra vez?>"

    # game/beyond the bet/day6dlc.rpy:1001
    old "1. <You really are so cute.>"
    new "1. <De verdad eres tan lindo.>"

    # game/beyond the bet/day6dlc.rpy:1003
    old "2. <God I love you.>"
    new "2. <Dios, te amo.>"

    # game/beyond the bet/day6dlc.rpy:1008
    old "1. <You're hilariously stupid. I love that about you.>"
    new "1. <Eres ridículamente tonto. Eso me encanta de ti.>"

    # game/beyond the bet/day6dlc.rpy:1018
    old "2. <See the world?>"
    new "2. <¿Ver el mundo?>"

    # game/beyond the bet/day6dlc.rpy:1023
    old "1. <It's not a competition.>"
    new "1. <No es una competencia.>"

    # game/beyond the bet/day6dlc.rpy:1029
    old "1. <Except when it comes to bets against a certain [pretty] [girl] over [her2] soul.>"
    new "1. <Excepto cuando se trata de las apuestas contra [arti_2] [girl!t] [pretty!t] por su alma.>"

    # game/beyond the bet/day6dlc.rpy:1032
    old "1. <You're not too good at winning those.>"
    new "1. <No se te da muy bien ganarlas.>"

    # game/beyond the bet/day6dlc.rpy:1037
    old "1. <Let's be real with each other, Grimmy.>"
    new "1. <Seamos realistas, Parquita.>"

    # game/beyond the bet/day6dlc.rpy:1040
    old "1. <You're struggling.>"
    new "1. <Estás teniendo problemas.>"

    # game/beyond the bet/day6dlc.rpy:1044
    old "1. <Come do it now.>"
    new "1. <Hazlo ahora.>"

    # game/beyond the bet/day6dlc.rpy:1049
    old "1. <Why not?>"
    new "1. <¿Por qué no?>"

    # game/beyond the bet/day6dlc.rpy:1053
    old "1. <With?>"
    new "1. <¿Con qué?>"

    # game/beyond the bet/day6dlc.rpy:1057
    old "1. <If those things are delaying my death, I'd say they concern me.>"
    new "1. <Si esas cosas retrasan mi muerte, diría que sí me incumben.>"

    # game/beyond the bet/day6dlc.rpy:1061
    old "1. <Maybe a little.>"
    new "1. <Quizá un poco.>"

    # game/beyond the bet/day6dlc.rpy:1063
    old "2. <Yeah, a lot.>"
    new "2. <Sí, mucho.>"

    # game/beyond the bet/day6dlc.rpy:1066
    old "1. <I enjoyed seeing you yesterday, Mister Big Scary Grim Reaper.>"
    new "1. <Disfruté verte ayer, Señor Parca Grande y Aterrador.>"

    # game/beyond the bet/day6dlc.rpy:1069
    old "1. <TBH I even surprise myself admitting that.>"
    new "1. <La verdad es que hasta me sorprende admitirlo.>"

    # game/beyond the bet/day6dlc.rpy:1072
    old "1. <A few days ago I thought you were a scammer.>"
    new "1. <Hace unos días pensaba que eras un estafador.>"

    # game/beyond the bet/day6dlc.rpy:1075
    old "1. <And then you go ahead and sweep me off my feet with a bouquet of sunflowers.>"
    new "1. <Y luego vas y me haces perder la cabeza con un ramo de girasoles.>"

    # game/beyond the bet/day6dlc.rpy:1089
    old "1. <That is oddly honest of you.>"
    new "1. <Eso es curiosamente sincero de tu parte.>"

    # game/beyond the bet/day6dlc.rpy:1092
    old "2. <...>"
    new "2. <...>"

    # game/beyond the bet/day6dlc.rpy:1098
    old "1. <I think we're similar in plenty of ways, too.>"
    new "1. <Creo que también nos parecemos en muchas cosas.>"

    # game/beyond the bet/day6dlc.rpy:1102
    old "1. <We're both animal lovers.>"
    new "1. <Los dos amamos a los animales.>"

    # game/beyond the bet/day6dlc.rpy:1106
    old "1. <I love [pet_name], you love Azrael :D>"
    new "1. <Yo amo a [pet_name], tú amas a Azrael :D>"

    # game/beyond the bet/day6dlc.rpy:1110
    old "1. <I love my pet, you love Azrael :D>"
    new "1. <Yo amo a mi mascota, tú amas a Azrael :D>"

    # game/beyond the bet/day6dlc.rpy:1113
    old "1. <I know Azrael is just a plushie, but he's still an axolotl!>"
    new "1. <Sé que Azrael es solo un peluche, ¡pero sigue siendo un ajolote!>"

    # game/beyond the bet/day6dlc.rpy:1118
    old "1. <I don't doubt that for a second.>"
    new "1. <No lo dudo ni por un segundo.>"

    # game/beyond the bet/day6dlc.rpy:1123
    old "1. <[pet_name] would make a good reaper, too.>"
    new "1. <[pet_name] también tendría talento para ser una parca.>"

    # game/beyond the bet/day6dlc.rpy:1127
    old "1. <My pet would make a good reaper, too.>"
    new "1. <Mi mascota también tendría talento para ser una parca.>"

    # game/beyond the bet/day6dlc.rpy:1138
    old "2. <We're both workaholics.>"
    new "2. <Los dos somos adictos al trabajo.>"

    # game/beyond the bet/day6dlc.rpy:1141
    old "1. <I mean, is there any hour in the day where you're not working?>"
    new "1. <O sea, ¿hay alguna hora del día en que no trabajes?>"

    # game/beyond the bet/day6dlc.rpy:1144
    old "1. <Wait, do you even sleep?>"
    new "1. <Espera, ¿acaso duermes?>"

    # game/beyond the bet/day6dlc.rpy:1150
    old "1. <That sounds MEGA unhealthy.>"
    new "1. <Eso suena SÚPER poco saludable.>"

    # game/beyond the bet/day6dlc.rpy:1154
    old "1. <You need to come over and get a full eight hours sleep.>"
    new "1. <Tienes que venir y dormir ocho horas completas.>"

    # game/beyond the bet/day6dlc.rpy:1158
    old "1. <Don't worry, I'll show you how.>"
    new "1. <Tranquilo, te enseñaré cómo.>"

    # game/beyond the bet/day6dlc.rpy:1161
    old "1. <You can lay your head down beside mine...>"
    new "1. <Puedes recostar tu cabeza junto a la mía...>"

    # game/beyond the bet/day6dlc.rpy:1164
    old "1. <I'm sure you'll get plenty of sleep ;)>"
    new "1. <Seguro que dormirás un montón ;)>"

    # game/beyond the bet/day6dlc.rpy:1170
    old "1. <I'll write you a note, dw.>"
    new "1. <Te escribiré una nota, tranqui.>"

    # game/beyond the bet/day6dlc.rpy:1173
    old "1. <{i}'Grimmy was busy being my cuddle buddy, he'll be back tomorrow'{/i}.>"
    new "1. <{i}'Parquita estaba ocupado siendo mi compañero de abrazos, volverá mañana'{/i}.>"

    # game/beyond the bet/day6dlc.rpy:1181
    old "3. <Just to simply... live.>"
    new "3. <Simplemente... vivir.>"

    # game/beyond the bet/day6dlc.rpy:1184
    old "1. <There's so much to do in life.>"
    new "1. <Hay tanto por hacer en la vida.>"

    # game/beyond the bet/day6dlc.rpy:1187
    old "1. <There's a lot of ugly things, sure, but there's a lot of beautiful things, too.>"
    new "1. <Hay muchas cosas feas, sí, pero también hay muchas cosas hermosas.>"

    # game/beyond the bet/day6dlc.rpy:1190
    old "1. <We could experience them together.>"
    new "1. <Podríamos vivirlas juntos.>"

    # game/beyond the bet/day6dlc.rpy:1205
    old "1. <What if I said pretty please?>"
    new "1. <¿Y si dijera porfis?>"

    # game/beyond the bet/day6dlc.rpy:1209
    old "1. <You don't know that.>"
    new "1. <Eso no lo sabes.>"

    # game/beyond the bet/day6dlc.rpy:1212
    old "1. <Maybe if I wish hard enough?>"
    new "1. <¿Quizá si lo deseo con todas mis fuerzas?>"

    # game/beyond the bet/day6dlc.rpy:1216
    old "1. <I'll try my best, for the both of us!>"
    new "1. <¡Daré lo mejor de mí, por los dos!>"

    # game/beyond the bet/day6dlc.rpy:1219
    old "2. <Well, that makes me feel a little sad.>"
    new "2. <Bueno, eso me pone un poco triste.>"

    # game/beyond the bet/day6dlc.rpy:1224
    old "1. <Well, I think the system is bullshit.>"
    new "1. <Pues yo creo que el sistema es una mierda.>"

    # game/beyond the bet/day6dlc.rpy:1227
    old "1. <And I'm gonna do something about it.>"
    new "1. <Y voy a hacer algo al respecto.>"

    # game/beyond the bet/day6dlc.rpy:1232
    old "1. <You're being sarcastic, but it could work.>"
    new "1. <Estás siendo sarcástico, pero podría funcionar.>"

    # game/beyond the bet/day6dlc.rpy:1250
    old "3. <Who is the weirdest one?>"
    new "3. <¿Quién es el más raro?>"

    # game/beyond the bet/day6dlc.rpy:1266
    old "1. <You should ask him why he calls himself that.>"
    new "1. <Deberías preguntarle por qué se hace llamar así.>"

    # game/beyond the bet/day6dlc.rpy:1273
    old "1. <That IS kinda weird.>"
    new "1. <Eso SÍ es medio raro.>"

    # game/beyond the bet/day6dlc.rpy:1276
    old "1. <But, hey, who am I to judge.>"
    new "1. <Pero, oye, quién soy yo para juzgar.>"

    # game/beyond the bet/day6dlc.rpy:1279
    old "1. <I collected some weird stuff when I was a kid.>"
    new "1. <Yo coleccionaba cosas raras cuando era niñ[letra].>"

    # game/beyond the bet/day6dlc.rpy:1283
    old "1. <Stamps.>"
    new "1. <Estampillas.>"

    # game/beyond the bet/day6dlc.rpy:1288
    old "1. <I had like 4000 of them, last I checked.>"
    new "1. <Tenía como 4000, la última vez que revisé.>"

    # game/beyond the bet/day6dlc.rpy:1293
    old "1. <You can never have too many stamps, Grim.>"
    new "1. <Nunca hay demasiadas estampillas, Parca.>"

    # game/beyond the bet/day6dlc.rpy:1296
    old "2. <Rocks.>"
    new "2. <Piedras.>"

    # game/beyond the bet/day6dlc.rpy:1300
    old "1. <All kinds.>"
    new "1. <De todo tipo.>"

    # game/beyond the bet/day6dlc.rpy:1303
    old "1. <Pretty rocks, ugly rocks, rocks that are pretty on the inside but ugly on the outside.>"
    new "1. <Piedras bonitas, piedras feas, piedras que son bonitas por dentro pero feas por fuera.>"

    # game/beyond the bet/day6dlc.rpy:1306
    old "1. <I just liked rocks.>"
    new "1. <Simplemente me gustaban las piedras.>"

    # game/beyond the bet/day6dlc.rpy:1311
    old "3. <Teeth.>"
    new "3. <Dientes.>"

    # game/beyond the bet/day6dlc.rpy:1317
    old "1. <My what?!>"
    new "1. <¡¿Mis qué?!>"

    # game/beyond the bet/day6dlc.rpy:1319
    old "2. <...Abilities? Casper, what are you talking about?>"
    new "2. <...¿Habilidades? Casper, ¿de qué hablas?>"

    # game/beyond the bet/day6dlc.rpy:1326
    old "1. <You can't just spring on me that the tooth fairy is real, Grim.>"
    new "1. <No puedes soltarme así como así que el hada de los dientes es real, Parca.>"

    # game/beyond the bet/day6dlc.rpy:1332
    old "1. <Grim. Come on.>"
    new "1. <Parca. Vamos.>"

    # game/beyond the bet/day6dlc.rpy:1339
    old "1. <You literally keep saying things that completely change my outlook on life.>"
    new "1. <Literalmente no paras de decir cosas que cambian por completo mi visión de la vida.>"

    # game/beyond the bet/day6dlc.rpy:1342
    old "1. <Do parents not wonder where the teeth go???>"
    new "1. <¿¿¿Los padres no se preguntan adónde van los dientes???>"

    # game/beyond the bet/day6dlc.rpy:1346
    old "1. <What the fuck.>"
    new "1. <Qué carajo.>"

    # game/beyond the bet/day6dlc.rpy:1348
    old "2. <This is insane.>"
    new "2. <Esto es una locura.>"

    # game/beyond the bet/day6dlc.rpy:1352
    old "1. <Um.>"
    new "1. <Eh.>"

    # game/beyond the bet/day6dlc.rpy:1355
    old "1. <I think not.>"
    new "1. <Creo que no.>"

    # game/beyond the bet/day6dlc.rpy:1358
    old "1. <I just thought collecting teeth was fun.>"
    new "1. <Solo pensé que coleccionar dientes era divertido.>"

    # game/beyond the bet/day6dlc.rpy:1361
    old "1. <My own teeth, that is. Not anyone else's.>"
    new "1. <Mis propios dientes, claro. No los de nadie más.>"

    # game/beyond the bet/day6dlc.rpy:1364
    old "1. <THAT would be weird.>"
    new "1. <ESO sí sería raro.>"

    # game/beyond the bet/day6dlc.rpy:1367
    old "1. <But now that you mention it, they all mysteriously went missing one day...>"
    new "1. <Pero ahora que lo mencionas, todos desaparecieron misteriosamente un día...>"

    # game/beyond the bet/day6dlc.rpy:1374
    old "4. <Spoons.>"
    new "4. <Cucharas.>"

    # game/beyond the bet/day6dlc.rpy:1378
    old "1. <Like, those little collectable spoons you get when you travel.>"
    new "1. <O sea, esas cucharitas de colección que uno se trae cuando viaja.>"

    # game/beyond the bet/day6dlc.rpy:1381
    old "1. <They're kind of pointless but they look pretty.>"
    new "1. <Son medio inútiles, pero se ven bonitas.>"

    # game/beyond the bet/day6dlc.rpy:1385
    old "1. <They're too pretty to use!>"
    new "1. <¡Son demasiado bonitas para usarlas!>"

    # game/beyond the bet/day6dlc.rpy:1393
    old "1. <That was... surprisingly deep.>"
    new "1. <Eso fue... sorprendentemente profundo.>"

    # game/beyond the bet/day6dlc.rpy:1396
    old "1. <I think you have a point, Grim.>"
    new "1. <Creo que tienes razón, Parca.>"

    # game/beyond the bet/day6dlc.rpy:1399
    old "1. <I have a whole stack of stickers in a drawer I'm too afraid to use, but better to use them, huh?>"
    new "1. <Tengo un montón de pegatinas en un cajón que me da miedo usar, pero es mejor usarlas, ¿no?>"

    # game/beyond the bet/day6dlc.rpy:1403
    old "2. <I'll keep it in mind.>"
    new "2. <Lo tendré en cuenta.>"

    # game/beyond the bet/day6dlc.rpy:1409
    old "1. <Not to backtrack, but...>"
    new "1. <No quiero volver atrás, pero...>"

    # game/beyond the bet/day6dlc.rpy:1413
    old "1. <What did you say? I have a kink for bullying people?>"
    new "1. <¿Qué dijiste? ¿Que tengo un fetiche con molestar a la gente?>"

    # game/beyond the bet/day6dlc.rpy:1416
    old "1. <Honestly, Grimmy, you just make it too easy. It's fun.>"
    new "1. <Sinceramente, Parquita, me lo pones demasiado fácil. Es divertido.>"

    # game/beyond the bet/day6dlc.rpy:1419
    old "1. <I like teasing you.>"
    new "1. <Me gusta molestarte.>"

    # game/beyond the bet/day6dlc.rpy:1422
    old "1. <You're filling a hunger I didn't even know I had.>"
    new "1. <Estás saciando un hambre que ni sabía que tenía.>"

    # game/beyond the bet/day6dlc.rpy:1426
    old "1. <And I've been absolutely starved, apparently.>"
    new "1. <Y por lo visto estaba muriéndome de hambre.>"

    # game/beyond the bet/day6dlc.rpy:1430
    old "1. <Awwww...>"
    new "1. <Awwww...>"

    # game/beyond the bet/day6dlc.rpy:1433
    old "1. <That's no fun, Grim.>"
    new "1. <Qué aburrido, Parca.>"

    # game/beyond the bet/day6dlc.rpy:1436
    old "1. <Come feed me!>"
    new "1. <¡Ven a darme de comer!>"

    # game/beyond the bet/day6dlc.rpy:1440
    old "1. <Aaaaaaaaah.>"
    new "1. <Aaaaaaaaah.>"

    # game/beyond the bet/day6dlc.rpy:1443
    old "1. <(I'm waiting for the airplane)>"
    new "1. <(Estoy esperando al avioncito)>"

    # game/beyond the bet/day6dlc.rpy:1450
    old "2. <I was starving before I met you, and now you've completely filled me up.>"
    new "2. <Me moría de hambre antes de conocerte, y ahora me has llenado por completo.>"

    # game/beyond the bet/day6dlc.rpy:1454
    old "1. <Hey, I didn't mean it like that!>"
    new "1. <¡Oye, no lo dije en ese sentido!>"

    # game/beyond the bet/day6dlc.rpy:1457
    old "1. <I'm not saying no, though...>"
    new "1. <Aunque no digo que no...>"

    # game/beyond the bet/day6dlc.rpy:1460
    old "1. <You can come 'fill me up' any day ;)>"
    new "1. <Puedes venir a 'llenarme' cuando quieras ;)>"

    # game/beyond the bet/day6dlc.rpy:1470
    old "1. <I'll note it down in my calendar, then.>"
    new "1. <Lo anotaré en mi calendario, entonces.>"

    # game/beyond the bet/day6dlc.rpy:1473
    old "1. <Wednesday, the Grim Reaper comes over to show me how he works that scythe ;)>"
    new "1. <El miércoles, la Parca viene a mostrarme cómo maneja esa guadaña ;)>"

    # game/beyond the bet/day6dlc.rpy:1478
    old "1. <What if I flutter my eyelashes at you? Would that change your mind?>"
    new "1. <¿Y si te bato las pestañas? ¿Te haría cambiar de opinión?>"

    # game/beyond the bet/day6dlc.rpy:1480
    old "2. <I'll get down on my knees and beg. Pretty please?>"
    new "2. <Me pondré de rodillas y te suplicaré. ¿Porfis?>"

    # game/beyond the bet/day6dlc.rpy:1484
    old "1. <See! I told you. You make it too easy.>"
    new "1. <¡Ves! Te lo dije. Me lo pones demasiado fácil.>"

    # game/beyond the bet/day6dlc.rpy:1494
    old "1. <You should be careful there, Grimmy.>"
    new "1. <Deberías tener cuidado, Parquita.>"

    # game/beyond the bet/day6dlc.rpy:1497
    old "1. <A [girl] could misunderstand what you mean.>"
    new "1. <[arti_2!c] [girl!t] podría malinterpretar lo que quieres decir.>"

    # game/beyond the bet/day6dlc.rpy:1500
    old "1. <You're just trying to trick me for my soul again, aren't you?>"
    new "1. <Solo intentas engañarme otra vez para quedarte con mi alma, ¿verdad?>"

    # game/beyond the bet/day6dlc.rpy:1507
    old "1. <Feeling conflicted, Casper?>"
    new "1. <¿Con sentimientos encontrados, Casper?>"

    # game/beyond the bet/day6dlc.rpy:1511
    old "1. <Even when it comes to me?>"
    new "1. <¿Incluso cuando se trata de mí?>"

    # game/beyond the bet/day6dlc.rpy:1514
    old "1. <Do I make you feel things you didn't know possible, Grim?>"
    new "1. <¿Te hago sentir cosas que no sabías que eran posibles, Parca?>"

    # game/beyond the bet/day6dlc.rpy:1523
    old "1. <I think you're perfect.>"
    new "1. <Creo que eres perfecto.>"

    # game/beyond the bet/day6dlc.rpy:1531
    old "2. <Wait, maybe you {i}really{/i} like the idea of feeding me?>"
    new "2. <Espera, ¿quizá {i}de verdad{/i} te gusta la idea de darme de comer?>"

    # game/beyond the bet/day6dlc.rpy:1539
    old "1. <I know what you said and didn't say.>"
    new "1. <Sé lo que dijiste y lo que no dijiste.>"

    # game/beyond the bet/day6dlc.rpy:1547
    old "1. <But I think if I asked really nicely, you might?>"
    new "1. <Pero creo que si te lo pidiera muy amablemente, quizá lo harías, ¿no?>"

    # game/beyond the bet/day6dlc.rpy:1551
    old "1. <If I suddenly had a bowl full of strawberries, would you feed them to me?>"
    new "1. <Si de repente tuviera un tazón lleno de fresas, ¿me las darías de comer?>"

    # game/beyond the bet/day6dlc.rpy:1555
    old "1. <With your mouth. You take one end, I'll take the other.>"
    new "1. <Con la boca. Tú tomas un extremo, yo el otro.>"

    # game/beyond the bet/day6dlc.rpy:1560
    old "1. <Yeah. That sounds like a good way to eat strawberries, to me.>"
    new "1. <Sí. Me parece una buena forma de comer fresas.>"

    # game/beyond the bet/day6dlc.rpy:1563
    old "1. <No? Too intimate?>"
    new "1. <¿No? ¿Demasiado íntimo?>"

    # game/beyond the bet/day6dlc.rpy:1573
    old "1. <Wow. Way to turn that around on me.>"
    new "1. <Wow. Qué forma de darle la vuelta a esto.>"

    # game/beyond the bet/day6dlc.rpy:1576
    old "1. <AHEM.>"
    new "1. <EJEM.>"

    # game/beyond the bet/day6dlc.rpy:1579
    old "2. <I'll say 'aaaah' and then you'll pop it in my mouth.>"
    new "2. <Diré 'aaaah' y tú me la pones en la boca.>"

    # game/beyond the bet/day6dlc.rpy:1583
    old "1. <Well, it would be only right for me to return the favor.>"
    new "1. <Bueno, sería justo que te devolviera el favor.>"

    # game/beyond the bet/day6dlc.rpy:1586
    old "1. <Open wide, Grimmy, and I'll give it to you <3>"
    new "1. <Abre bien la boca, Parquita, y te la pondré <3>"

    # game/beyond the bet/day6dlc.rpy:1590
    old "1. <The strawberry! I mean the strawberry.>"
    new "1. <¡La fresa! Me refiero a la fresa.>"

    # game/beyond the bet/day6dlc.rpy:1598
    old "3. <The secret third option. \nEat them off each other's bodies ;)>"
    new "3. <La tercera opción secreta. Comérnoslas del cuerpo del otro ;)>"

    # game/beyond the bet/day6dlc.rpy:1601
    old "1. <If you're not afraid of a little mess, that is.>"
    new "1. <Si no te asusta ensuciarte un poco, claro.>"

    # game/beyond the bet/day6dlc.rpy:1605
    old "1. <The point isn't really the food. It's the rest of what's going on.>"
    new "1. <La idea no es realmente la comida. Es todo lo demás que pasa.>"

    # game/beyond the bet/day6dlc.rpy:1609
    old "1. <Hey, if you want to undress, I am CERTAINLY not going to stop you.>"
    new "1. <Oye, si quieres desvestirte, DESDE LUEGO que no te lo voy a impedir.>"

    # game/beyond the bet/day6dlc.rpy:1612
    old "1. <Strip away, Mister Reaper, Sir.>"
    new "1. <Adelante, quítese la ropa, Señor Parca, señor.>"

    # game/beyond the bet/day6dlc.rpy:1615
    old "1. <I'll be waiting for you ;)>"
    new "1. <Te estaré esperando ;)>"

    # game/beyond the bet/day6dlc.rpy:1618
    old "1. <Alternatively, we skip the food and just do the stripping?>"
    new "1. <¿O nos saltamos la comida y hacemos solo lo de desvestirnos?>"

    # game/beyond the bet/day6dlc.rpy:1626
    old "2. <Bring strawberries next time instead of flowers ;)>"
    new "2. <Trae fresas la próxima vez en lugar de flores ;)>"

    # game/beyond the bet/day6dlc.rpy:1629
    old "1. <Wait.>"
    new "1. <Espera.>"

    # game/beyond the bet/day6dlc.rpy:1632
    old "1. <Bring both.>"
    new "1. <Trae ambas.>"

    # game/beyond the bet/day6dlc.rpy:1642
    old "1. <Well, actually...>"
    new "1. <Bueno, en realidad...>"

    # game/beyond the bet/day6dlc.rpy:1645
    old "1. <I'm in bed still.>"
    new "1. <Sigo en la cama.>"

    # game/beyond the bet/day6dlc.rpy:1649
    old "1. <Give a [girl] a break, Grimmy boy.>"
    new "1. <Dame un respiro, Parquita.>"

    # game/beyond the bet/day6dlc.rpy:1652
    old "1. <I'm feeling off today.>"
    new "1. <Hoy me siento mal.>"

    # game/beyond the bet/day6dlc.rpy:1655
    old "1. <I think I've caught a cold.>"
    new "1. <Creo que me resfrié.>"

    # game/beyond the bet/day6dlc.rpy:1658
    old "2. <Pretty sure I'm dying, actually.>"
    new "2. <La verdad es que creo que me estoy muriendo.>"

    # game/beyond the bet/day6dlc.rpy:1662
    old "1. <Heh.>"
    new "1. <Je.>"

    # game/beyond the bet/day6dlc.rpy:1665
    old "1. <It's just a cold.>"
    new "1. <Solo es un resfriado.>"

    # game/beyond the bet/day6dlc.rpy:1670
    old "1. <I figured I'd just stay in bed with [pet_name] and chat with you.>"
    new "1. <Pensé en quedarme en la cama con [pet_name] y charlar contigo.>"

    # game/beyond the bet/day6dlc.rpy:1674
    old "1. <I figured I'd just stay in bed with my pet and chat to you.>"
    new "1. <Pensé en quedarme en la cama con mi mascota y charlar contigo.>"

    # game/beyond the bet/day6dlc.rpy:1680
    old "1. <Um... no?>"
    new "1. <Eh... ¿no?>"

    # game/beyond the bet/day6dlc.rpy:1683
    old "1. <I mean, I don't think so, at least.>"
    new "1. <O sea, creo que no, al menos.>"

    # game/beyond the bet/day6dlc.rpy:1687
    old "2. <Yes, always.>"
    new "2. <Sí, siempre.>"

    # game/beyond the bet/day6dlc.rpy:1691
    old "1. <But I always do it, so I doubt it's that.>"
    new "1. <Pero siempre lo hago, así que dudo que sea eso.>"

    # game/beyond the bet/day6dlc.rpy:1699
    old "1. <I close it every night before I go to bed.>"
    new "1. <La cierro todas las noches antes de acostarme.>"

    # game/beyond the bet/day6dlc.rpy:1702
    old "1. <And if its cold, I don't even open it to begin with.>"
    new "1. <Y si hace frío, ni siquiera la abro desde un principio.>"

    # game/beyond the bet/day6dlc.rpy:1706
    old "1. <That's why they call me sensible [playerfirstname].>"
    new "1. <Por eso me llaman [playerfirstname] [arti] Sensat[letra].>"

    # game/beyond the bet/day6dlc.rpy:1710
    old "1. <How would you know?>"
    new "1. <¿Cómo lo sabrías?>"

    # game/beyond the bet/day6dlc.rpy:1713
    old "1. <Maybe everyone calls me that.>"
    new "1. <Quizá todos me llaman así.>"

    # game/beyond the bet/day6dlc.rpy:1717
    old "1. <Um...>"
    new "1. <Eh...>"

    # game/beyond the bet/day6dlc.rpy:1720
    old "1. <My next door neighbors.>"
    new "1. <Mis vecinos de al lado.>"

    # game/beyond the bet/day6dlc.rpy:1724
    old "1. <Great question.>"
    new "1. <Excelente pregunta.>"

    # game/beyond the bet/day6dlc.rpy:1727
    old "1. <Uh...>"
    new "1. <Eh...>"

    # game/beyond the bet/day6dlc.rpy:1730
    old "1. <Greg....>"
    new "1. <Greg....>"

    # game/beyond the bet/day6dlc.rpy:1733
    old "1. <Timmothy...>"
    new "1. <Timmothy...>"

    # game/beyond the bet/day6dlc.rpy:1737
    old "1. <Yeah, just a little.>"
    new "1. <Sí, un poquito.>"

    # game/beyond the bet/day6dlc.rpy:1740
    old "1. <I am very sensible, though.>"
    new "1. <Soy muy sensat[letra], eso sí.>"

    # game/beyond the bet/day6dlc.rpy:1743
    old "1. <My window is completely closed right now, so my cold didn't come from that.>"
    new "1. <Mi ventana está completamente cerrada ahora mismo, así que mi resfriado no vino de ahí.>"

    # game/beyond the bet/day6dlc.rpy:1746
    old "2. <That's classified.>"
    new "2. <Eso es confidencial.>"

    # game/beyond the bet/day6dlc.rpy:1750
    old "1. <Highly classified on all levels.>"
    new "1. <Altamente confidencial a todos los niveles.>"

    # game/beyond the bet/day6dlc.rpy:1753
    old "1. <Their files have big red warning labels on them and all.>"
    new "1. <Sus expedientes tienen grandes etiquetas rojas de advertencia y todo.>"

    # game/beyond the bet/day6dlc.rpy:1757
    old "1. <Of course I do.>"
    new "1. <Claro que sí.>"

    # game/beyond the bet/day6dlc.rpy:1761
    old "1. <Nuh uh mister!>"
    new "1. <¡Ni hablar, señor!>"

    # game/beyond the bet/day6dlc.rpy:1764
    old "1. <Access denied!>"
    new "1. <¡Acceso denegado!>"

    # game/beyond the bet/day6dlc.rpy:1770
    old "2. <...No, I don't...>"
    new "2. <...No, no los sé...>"

    # game/beyond the bet/day6dlc.rpy:1777
    old "1. <A little while...>"
    new "1. <Un tiempito...>"

    # game/beyond the bet/day6dlc.rpy:1783
    old "1. <Come on, you don't know all your neighbors.>"
    new "1. <Anda, tú tampoco conoces a todos tus vecinos.>"

    # game/beyond the bet/day6dlc.rpy:1790
    old "1. <I like your style.>"
    new "1. <Me gusta tu estilo.>"

    # game/beyond the bet/day6dlc.rpy:1794
    old "2. <Now you're speaking my language.>"
    new "2. <Ahora sí hablas mi idioma.>"

    # game/beyond the bet/day6dlc.rpy:1799
    old "1. <It's a figure of speech.>"
    new "1. <Es una figura retórica.>"

    # game/beyond the bet/day6dlc.rpy:1802
    old "1. <Wait a second.>"
    new "1. <Espera un segundo.>"

    # game/beyond the bet/day6dlc.rpy:1806
    old "1. <What language do they speak in the Underworld, anyway?>"
    new "1. <¿Qué idioma hablan en el Inframundo, por cierto?>"

    # game/beyond the bet/day6dlc.rpy:1809
    old "1. <It must be a miracle we both speak the same language.>"
    new "1. <Debe de ser un milagro que hablemos el mismo idioma.>"

    # game/beyond the bet/day6dlc.rpy:1815
    old "1. <What the hell.>"
    new "1. <Qué demonios.>"

    # game/beyond the bet/day6dlc.rpy:1818
    old "1. <How's that fair?>"
    new "1. <¿Y eso cómo es justo?>"

    # game/beyond the bet/day6dlc.rpy:1824
    old "1. <No shit.>"
    new "1. <Ni que lo digas.>"

    # game/beyond the bet/day6dlc.rpy:1827
    old "1. <Where do I sign up?>"
    new "1. <¿Dónde me apunto?>"

    # game/beyond the bet/day6dlc.rpy:1836
    old "2. <Left it wide open for you.>"
    new "2. <La dejé abierta de par en par para ti.>"

    # game/beyond the bet/day6dlc.rpy:1841
    old "1. <I live on the fifth floor Grim, you know that.>"
    new "1. <Vivo en el quinto piso, Parca, lo sabes.>"

    # game/beyond the bet/day6dlc.rpy:1846
    old "1. <Ah, yes, all those midcity wild animals.>"
    new "1. <Ah, sí, todos esos animales salvajes del centro de la ciudad.>"

    # game/beyond the bet/day6dlc.rpy:1849
    old "1. <I feel like the chances of that are PRETTY slim.>"
    new "1. <Siento que las probabilidades de eso son BASTANTE escasas.>"

    # game/beyond the bet/day6dlc.rpy:1854
    old "1. <I mean this in the kindest way possible, but that is SO ironic coming from you.>"
    new "1. <Lo digo con la mejor intención, pero eso es TAN irónico viniendo de ti.>"

    # game/beyond the bet/day6dlc.rpy:1861
    old "1. <I guess I never thought about it like that.>"
    new "1. <Supongo que nunca lo había pensado así.>"

    # game/beyond the bet/day6dlc.rpy:1864
    old "1. <Still, I'm perfectly healthy (usually) and way too young to die.>"
    new "1. <Aun así, estoy perfectamente san[letra] (normalmente) y soy demasiado joven para morir.>"

    # game/beyond the bet/day6dlc.rpy:1867
    old "1. <I'd say in this case...>"
    new "1. <Diría que en este caso...>"

    # game/beyond the bet/day6dlc.rpy:1870
    old "1. <Causing accidents trying to take my soul is probably not good for my well-being.>"
    new "1. <Causar accidentes para intentar llevarte mi alma probablemente no sea bueno para mi bienestar.>"

    # game/beyond the bet/day6dlc.rpy:1876
    old "1. <I think I'd notice that.>"
    new "1. <Creo que lo notaría.>"

    # game/beyond the bet/day6dlc.rpy:1880
    old "1. <What, you think a colony of ants is going to destroy my room?>"
    new "1. <¿Qué, crees que una colonia de hormigas va a destruir mi cuarto?>"

    # game/beyond the bet/day6dlc.rpy:1884
    old "1. <Okay, well, I think the invisible colony of ants hasn't caused my flu, Grim.>"
    new "1. <Okey, bueno, creo que la colonia invisible de hormigas no me causó la gripe, Parca.>"

    # game/beyond the bet/day6dlc.rpy:1890
    old "2. <Maybe they'll be friendly.>"
    new "2. <Quizá sean amistosos.>"

    # game/beyond the bet/day6dlc.rpy:1894
    old "1. <Nooooo! Don't even joke about that!>"
    new "1. <¡¡Nooooo!! ¡Ni bromees con eso!>"

    # game/beyond the bet/day6dlc.rpy:1900
    old "1. <Shut uppppp.>"
    new "1. <Cállateeeee.>"

    # game/beyond the bet/day6dlc.rpy:1903
    old "1. <There's no wild animals invading my apartment through the window!>"
    new "1. <¡No hay animales salvajes invadiendo mi apartamento por la ventana!>"

    # game/beyond the bet/day6dlc.rpy:1908
    old "1. <For someone I like, you're really the worst, you know that?>"
    new "1. <Mira que me gustas, pero eres lo peor, ¿sabías?>"

    # game/beyond the bet/day6dlc.rpy:1913
    old "1. <Not a compliment.>"
    new "1. <No es un cumplido.>"

    # game/beyond the bet/day6dlc.rpy:1923
    old "3. <Maybe a smiiiidge.>"
    new "3. <Quizá un poquiiito.>"

    # game/beyond the bet/day6dlc.rpy:1926
    old "1. <Like a teeny weeny smidge.>"
    new "1. <Un poquitito chiquitito.>"

    # game/beyond the bet/day6dlc.rpy:1929
    old "1. <Just enough that a Grim Reaper could sneak in if he wanted to.>"
    new "1. <Lo justo para que una Parca pudiera colarse si quisiera.>"

    # game/beyond the bet/day6dlc.rpy:1934
    old "1. <That does not surprise me in the slightest.>"
    new "1. <Eso no me sorprende en lo más mínimo.>"

    # game/beyond the bet/day6dlc.rpy:1937
    old "1. <You throw pianos from twenty stories up at innocent people (me).>"
    new "1. <Lanzas pianos desde veinte pisos de altura a gente inocente (yo).>"

    # game/beyond the bet/day6dlc.rpy:1940
    old "1. <May as well add breaking and entering onto your rap sheet as well.>"
    new "1. <Bien podrías añadir allanamiento de morada a tus antecedentes.>"

    # game/beyond the bet/day6dlc.rpy:1946
    old "1. <Ah, yes. Slippery eel Casper.>"
    new "1. <Ah, sí. Casper, la anguila escurridiza.>"

    # game/beyond the bet/day6dlc.rpy:1949
    old "1. <I've always thought you were giving {i}'eel'{/i}.>"
    new "1. <Siempre pensé que tenías algo de {i}'anguila'{/i}.>"

    # game/beyond the bet/day6dlc.rpy:1953
    old "1. <No, but there's some similarities, isn't there?>"
    new "1. <No, pero hay algunas similitudes, ¿no?>"

    # game/beyond the bet/day6dlc.rpy:1956
    old "1. <You like axolotls. Those are kinda similar.>"
    new "1. <Te gustan los ajolotes. Esos son medio parecidos.>"

    # game/beyond the bet/day6dlc.rpy:1961
    old "1. <You're the one who said you were like an eel.>"
    new "1. <Tú fuiste quien dijo que eras como una anguila.>"

    # game/beyond the bet/day6dlc.rpy:1965
    old "1. <Look, Mister Eel Reaper, it doesn't matter if I left the window open anyway.>"
    new "1. <Mira, Señor Parca Anguila, no importa si dejé la ventana abierta de todos modos.>"

    # game/beyond the bet/day6dlc.rpy:1968
    old "1. <I do that all the time. I don't think that's what made me sick.>"
    new "1. <Lo hago todo el tiempo. No creo que eso me enfermara.>"

    # game/beyond the bet/day6dlc.rpy:1974
    old "2. <I think you mean like a slug or a worm.>"
    new "2. <Creo que te refieres más a una babosa o un gusano.>"

    # game/beyond the bet/day6dlc.rpy:1980
    old "1. <You'd be a cute worm or slug though!>"
    new "1. <¡Pero serías un gusano o una babosa muy lindos!>"

    # game/beyond the bet/day6dlc.rpy:1983
    old "2. <Don't worry, I'd still like you if you were a worm, or a slug.>"
    new "2. <Tranquilo, me seguirías gustando aunque fueras un gusano o una babosa.>"

    # game/beyond the bet/day6dlc.rpy:1987
    old "1. <Or a snail, you seem like the kinda guy to have a shell.>"
    new "1. <O un caracol, pareces del tipo que tiene caparazón.>"

    # game/beyond the bet/day6dlc.rpy:1990
    old "1. <All those outer walls to keep everyone out.>"
    new "1. <Todos esos muros exteriores para mantener a todos afuera.>"

    # game/beyond the bet/day6dlc.rpy:2001
    old "1. <Do you think I had a shell in my past life?>"
    new "1. <¿Crees que tuve caparazón en mi vida pasada?>"

    # game/beyond the bet/day6dlc.rpy:2005
    old "1. <But do you think I did?>"
    new "1. <¿Pero crees que sí?>"

    # game/beyond the bet/day6dlc.rpy:2009
    old "1. <Not you, my cute little reaper slug :( you don't tell me anything!>"
    new "1. <Tú no, mi linda parquita babosa :( ¡no me cuentas nada!>"

    # game/beyond the bet/day6dlc.rpy:2019
    old "2. <I didn't leave it open for you. Obviously it's open for Jeremy.>"
    new "2. <No la dejé abierta para ti. Obviamente está abierta para Jeremy.>"

    # game/beyond the bet/day6dlc.rpy:2024
    old "1. <Levitating.>"
    new "1. <Levita.>"

    # game/beyond the bet/day6dlc.rpy:2029
    old "1. <Okay, okay, don't get your panties in a twist.>"
    new "1. <Okey, okey, no te pongas así.>"

    # game/beyond the bet/day6dlc.rpy:2032
    old "1. <It was opened a crack for you.>"
    new "1. <La dejé entreabierta para ti.>"

    # game/beyond the bet/day6dlc.rpy:2035
    old "1. <Jeremy knows how to knock on the door.>"
    new "1. <Jeremy sabe tocar la puerta.>"

    # game/beyond the bet/day6dlc.rpy:2038
    old "1. <Such a gentleman.>"
    new "1. <Todo un caballero.>"

    # game/beyond the bet/day6dlc.rpy:2041
    old "1. <jk ;)>"
    new "1. <es broma ;)>"

    # game/beyond the bet/day6dlc.rpy:2044
    old "2. <Jeremy has a key if he needs one.>"
    new "2. <Jeremy tiene llave, por si la necesita.>"

    # game/beyond the bet/day6dlc.rpy:2048
    old "1. <I'm messing with you, Grimmy.>"
    new "1. <Te estoy molestando, Parquita.>"

    # game/beyond the bet/day6dlc.rpy:2051
    old "1. <Just pulling your leg :D>"
    new "1. <Solo te estoy tomando el pelo :D>"

    # game/beyond the bet/day6dlc.rpy:2055
    old "1. <You are the only reaper for me, don't worry Casper.>"
    new "1. <Tú eres la única parca para mí, tranquilo Casper.>"

    # game/beyond the bet/day6dlc.rpy:2061
    old "1. <Wow, I'm swooning Grim.>"
    new "1. <Wow, me estoy derritiendo, Parca.>"

    # game/beyond the bet/day6dlc.rpy:2064
    old "1. <Come take every aspect of me ;)>"
    new "1. <Ven a llevarte cada aspecto de mí ;)>"

    # game/beyond the bet/day6dlc.rpy:2074
    old "1. <It's just a cold, Grim.>"
    new "1. <Solo es un resfriado, Parca.>"

    # game/beyond the bet/day6dlc.rpy:2077
    old "1. <It happens to everyone. It's super common.>"
    new "1. <Le pasa a todo el mundo. Es súper común.>"

    # game/beyond the bet/day6dlc.rpy:2082
    old "1. <Sure, but it's not a big deal. It's just a bit inconvenient.>"
    new "1. <Claro, pero no es para tanto. Es solo un poco molesto.>"

    # game/beyond the bet/day6dlc.rpy:2085
    old "1. <But, hey, it means I can talk to you some more.>"
    new "1. <Pero, oye, significa que puedo hablar más contigo.>"

    # game/beyond the bet/day6dlc.rpy:2089
    old "1. <Well, I'd usually be at work.>"
    new "1. <Bueno, normalmente estaría en el trabajo.>"

    # game/beyond the bet/day6dlc.rpy:2095
    old "1. <If I do that, I'll never get any work done.>"
    new "1. <Si hago eso, nunca terminaré nada del trabajo.>"

    # game/beyond the bet/day6dlc.rpy:2098
    old "1. <You're a little distracting, you know.>"
    new "1. <Distraes un poquito, ¿sabes?>"

    # game/beyond the bet/day6dlc.rpy:2102
    old "1. <Well, you talk a lot.>"
    new "1. <Bueno, hablas mucho.>"

    # game/beyond the bet/day6dlc.rpy:2106
    old "1. <You're kinda a yapper, Grim.>"
    new "1. <Eres como una cotorra, Parca.>"

    # game/beyond the bet/day6dlc.rpy:2111
    old "1. <And that is?>"
    new "1. <¿Y eso qué es?>"

    # game/beyond the bet/day6dlc.rpy:2116
    old "1. <Okay, well, if I do that I'll probably get fired.>"
    new "1. <Okey, pero si hago eso probablemente me despidan.>"

    # game/beyond the bet/day6dlc.rpy:2121
    old "1. <To be honest, that's how I feel too.>"
    new "1. <Para ser sincer[letra], yo también lo siento así.>"

    # game/beyond the bet/day6dlc.rpy:2124
    old "1. <Alas, my boss wouldn't agree.>"
    new "1. <Por desgracia, mi jefe no estaría de acuerdo.>"

    # game/beyond the bet/day6dlc.rpy:2129
    old "1. <I'll be right on that.>"
    new "1. <Ahora mismo me pongo a ello.>"

    # game/beyond the bet/day6dlc.rpy:2133
    old "1. <'Excuse me sir, the Grim Reaper wants to chat, bye'!>"
    new "1. <'Disculpe, señor, la Parca quiere charlar, ¡adiós!'>"

    # game/beyond the bet/day6dlc.rpy:2139
    old "1. <You wouldn't do that.>"
    new "1. <Tú no harías eso.>"

    # game/beyond the bet/day6dlc.rpy:2145
    old "1. <I don't think he'd believe me.>"
    new "1. <No creo que me crea.>"

    # game/beyond the bet/day6dlc.rpy:2149
    old "1. <But what does that matter? I'm meant to die today or tomorrow.>"
    new "1. <Pero ¿qué importa? Se supone que moriré hoy o mañana.>"

    # game/beyond the bet/day6dlc.rpy:2155
    old "1. <IT'S A COLD.>"
    new "1. <ES UN RESFRIADO.>"

    # game/beyond the bet/day6dlc.rpy:2169
    old "2. <You could try cleaning your glasses.>"
    new "2. <Podrías intentar limpiarte las gafas.>"

    # game/beyond the bet/day6dlc.rpy:2172
    old "1. <You know, if you can't... *see*.>"
    new "1. <Ya sabes, si no puedes... 'ver'.>"

    # game/beyond the bet/day6dlc.rpy:2176
    old "1. <You don't? I could've sworn you had glasses on last night.>"
    new "1. <¿No? Habría jurado que anoche tenías gafas puestas.>"

    # game/beyond the bet/day6dlc.rpy:2179
    old "1. <Huh, weird.>"
    new "1. <Hmm, qué raro.>"

    # game/beyond the bet/day6dlc.rpy:2188
    old "1. <Aww, you like my glasses?>"
    new "1. <Aww, ¿te gustan mis gafas?>"

    # game/beyond the bet/day6dlc.rpy:2192
    old "1. <Well, I think they'd suit you plenty.>"
    new "1. <Pues creo que a ti te quedarían de maravilla.>"

    # game/beyond the bet/day6dlc.rpy:2195
    old "1. <Next time you come over, you can try them on.>"
    new "1. <La próxima vez que vengas, puedes probártelas.>"

    # game/beyond the bet/day6dlc.rpy:2198
    old "1. <Unless you're too scared to come in again.>"
    new "1. <A menos que te dé demasiado miedo volver a entrar.>"

    # game/beyond the bet/day6dlc.rpy:2204
    old "1. <I wouldn't have minded.>"
    new "1. <A mí no me habría importado.>"

    # game/beyond the bet/day6dlc.rpy:2213
    old "1. <Just decent?>"
    new "1. <¿Solo decente?>"

    # game/beyond the bet/day6dlc.rpy:2217
    old "1. <Should I get some, then?>"
    new "1. <¿Debería comprarme unas, entonces?>"

    # game/beyond the bet/day6dlc.rpy:2222
    old "1. <I can just pop out the lenses.>"
    new "1. <Puedo sacarles los cristales.>"

    # game/beyond the bet/day6dlc.rpy:2226
    old "1. <I used to do that when I was a kid with those 3D glasses.>"
    new "1. <Yo hacía eso de niñ[letra] con esas gafas 3D.>"

    # game/beyond the bet/day6dlc.rpy:2231
    old "1. <It was.>"
    new "1. <Lo era.>"

    # game/beyond the bet/day6dlc.rpy:2234
    old "1. <But, anyway, no I don't actually need glasses.>"
    new "1. <Pero, en fin, no, en realidad no necesito gafas.>"

    # game/beyond the bet/day6dlc.rpy:2237
    old "1. <I've got, like, 20/10 vision. Maybe even 20/0.>"
    new "1. <Tengo, como, 20/10 de visión. Quizá hasta 20/0.>"

    # game/beyond the bet/day6dlc.rpy:2241
    old "1. <I really do.>"
    new "1. <De verdad.>"

    # game/beyond the bet/day6dlc.rpy:2245
    old "1. <I'm just that special.>"
    new "1. <Soy así de especial.>"

    # game/beyond the bet/day6dlc.rpy:2248
    old "1. <I'm not some 20/20 normie.>"
    new "1. <No soy [arti_2] normi 20/20.>"

    # game/beyond the bet/day6dlc.rpy:2254
    old "1. <I think it's cute how you research slang.>"
    new "1. <Me parece tierno que investigues la jerga.>"

    # game/beyond the bet/day6dlc.rpy:2257
    old "1. <It's just terrible when you repeat it back to me.>"
    new "1. <Lo malo es cuando me la repites.>"

    # game/beyond the bet/day6dlc.rpy:2260
    old "1. <Ah, yes, the ancient evil Grim Reaper...>"
    new "1. <Ah, sí, la antigua y malvada Parca...>"

    # game/beyond the bet/day6dlc.rpy:2264
    old "1. <Harvester of souls and keeper of the underworld, telling me my rizz is w.>"
    new "1. <Cosechador de almas y guardián del inframundo, diciéndome que mi aura es +1000.>"

    # game/beyond the bet/day6dlc.rpy:2269
    old "1. <I feel I've made a mistake.>"
    new "1. <Siento que cometí un error.>"

    # game/beyond the bet/day6dlc.rpy:2274
    old "2. <I haven't had my eyes tested in awhile, maybe I should.>"
    new "2. <Hace un tiempo que no me reviso la vista, quizá debería.>"

    # game/beyond the bet/day6dlc.rpy:2278
    old "1. <Making phone calls suck, though...>"
    new "1. <Hacer llamadas es un asco, eso sí...>"

    # game/beyond the bet/day6dlc.rpy:2281
    old "1. <And, I mean, you're planning to whisk me away to the afterlife soon, right?>"
    new "1. <Y, o sea, ¿planeas llevarme pronto al más allá, no?>"

    # game/beyond the bet/day6dlc.rpy:2284
    old "1. <Glasses ain't cheap, or fast.>"
    new "1. <Las gafas no son baratas, ni rápidas.>"

    # game/beyond the bet/day6dlc.rpy:2288
    old "1. <I don't wanna spend my hard earned cash like that.>"
    new "1. <No quiero gastar así mi dinero ganado con esfuerzo.>"

    # game/beyond the bet/day6dlc.rpy:2292
    old "1. <On something that will arrive just in time to slip into my coffin.>"
    new "1. <En algo que llegará justo a tiempo para meterlo en mi ataúd.>"

    # game/beyond the bet/day6dlc.rpy:2299
    old "1. <Eh...>"
    new "1. <Eh...>"

    # game/beyond the bet/day6dlc.rpy:2302
    old "1. <OR...>"
    new "1. <O...>"

    # game/beyond the bet/day6dlc.rpy:2305
    old "1. <I could buy a pretty vase for my flowers :D>"
    new "1. <Podría comprar un jarrón bonito para mis flores :D>"

    # game/beyond the bet/day6dlc.rpy:2309
    old "1. <Sarcasm is the lowest form of wit, you know.>"
    new "1. <El sarcasmo es la forma más baja de ingenio, ¿sabes?>"

    # game/beyond the bet/day6dlc.rpy:2314
    old "1. <I would, but without glasses I can't even see myself in the mirror :(>"
    new "1. <Lo haría, pero sin gafas ni siquiera puedo verme en el espejo :(>"

    # game/beyond the bet/day6dlc.rpy:2323
    old "3. <Open your eyes SUPER WIDE and maybe you'll see.>"
    new "3. <Abre los ojos BIEN GRANDES y quizá veas.>"

    # game/beyond the bet/day6dlc.rpy:2330
    old "1. <In actual fact, you're usually too busy to talk to me.>"
    new "1. <En realidad, normalmente estás demasiado ocupado para hablar conmigo.>"

    # game/beyond the bet/day6dlc.rpy:2337
    old "1. <Okay, well, I think you're super distracting.>"
    new "1. <Okey, pues creo que me distraes muchísimo.>"

    # game/beyond the bet/day6dlc.rpy:2341
    old "1. <And if I spent all my normal days chatting with you, I'd never get anything done.>"
    new "1. <Y si pasara todos mis días normales charlando contigo, nunca haría nada.>"

    # game/beyond the bet/day6dlc.rpy:2346
    old "1. <I mean, your stupid face is alright, I guess.>"
    new "1. <O sea, tu cara tonta está bien, supongo.>"

    # game/beyond the bet/day6dlc.rpy:2352
    old "1. <You know, I'm coming to love how confident you are.>"
    new "1. <Sabes, estoy empezando a amar lo seguro que eres.>"

    # game/beyond the bet/day6dlc.rpy:2356
    old "1. <One moment you're as red as a tomato...>"
    new "1. <Un momento estás rojo como un tomate...>"

    # game/beyond the bet/day6dlc.rpy:2359
    old "1. <And the next you're confidently telling me about how perfect your face is.>"
    new "1. <Y al siguiente me estás diciendo con total seguridad lo perfecta que es tu cara.>"

    # game/beyond the bet/day6dlc.rpy:2362
    old "1. <I love me a man who can do both.>"
    new "1. <Me encanta un hombre que puede hacer ambas.>"

    # game/beyond the bet/day6dlc.rpy:2366
    old "1. <Don't get ahead of yourself, buddy.>"
    new "1. <No te adelantes, amigo.>"

    # game/beyond the bet/day6dlc.rpy:2375
    old "2. <Alluringly stupid.>"
    new "2. <Cautivadoramente tonto.>"

    # game/beyond the bet/day6dlc.rpy:2379
    old "1. <🤓🤓🤓>"
    new "1. <🤓🤓🤓>"

    # game/beyond the bet/day6dlc.rpy:2383
    old "1. <Those are *actual* emojis, FYI.>"
    new "1. <Son emojis 'de verdad', por cierto.>"

    # game/beyond the bet/day6dlc.rpy:2386
    old "1. <And they don't mean anything. I just felt like putting them there.>"
    new "1. <Y no significan nada. Solo tuve ganas de ponerlos ahí.>"

    # game/beyond the bet/day6dlc.rpy:2395
    old "1. <I'm kidding. I know you're smart.>"
    new "1. <Estoy bromeando. Sé que eres listo.>"

    # game/beyond the bet/day6dlc.rpy:2398
    old "1. <You're, like, information smart, but not very people smart.>"
    new "1. <Eres listo en información, pero no muy listo con la gente.>"

    # game/beyond the bet/day6dlc.rpy:2403
    old "1. <Well, doesn't that make me feel special?>"
    new "1. <Vaya, ¿eso no me hace sentir especial?>"

    # game/beyond the bet/day6dlc.rpy:2409
    old "3. <Honestly, yes.>"
    new "3. <Sinceramente, sí.>"

    # game/beyond the bet/day6dlc.rpy:2412
    old "1. <I do have to admit that over the last few days, I...>"
    new "1. <Tengo que admitir que en los últimos días, yo...>"

    # game/beyond the bet/day6dlc.rpy:2415
    old "1. <Have come to like you more than I probably should.>"
    new "1. <Me gustas más de lo que probablemente debería.>"

    # game/beyond the bet/day6dlc.rpy:2419
    old "1. <You're an alluring guy, Grimmy.>"
    new "1. <Eres un tipo cautivador, Parquita.>"

    # game/beyond the bet/day6dlc.rpy:2424
    old "1. <Honesty is the best policy.>"
    new "1. <La honestidad es lo mejor en la política.>"

    # game/beyond the bet/day6dlc.rpy:2435
    old "1. <I don't know if there's any specific reason.>"
    new "1. <No sé si hay alguna razón específica.>"

    # game/beyond the bet/day6dlc.rpy:2438
    old "1. <It's just going around again, I guess.>"
    new "1. <Supongo que la gripe está circulando otra vez.>"

    # game/beyond the bet/day6dlc.rpy:2443
    old "1. <I appreciate the sentiment, but it's really no biggie.>"
    new "1. <Aprecio el sentimiento, pero de verdad no es nada del otro mundo.>"

    # game/beyond the bet/day6dlc.rpy:2450
    old "1. <I'd say both.>"
    new "1. <Diría que ambos.>"

    # game/beyond the bet/day6dlc.rpy:2453
    old "1. <I feel so tired for a person that's done nothing but sleep.>"
    new "1. <Me siento muy cansad[letra] para ser alguien que no ha hecho más que dormir.>"

    # game/beyond the bet/day6dlc.rpy:2456
    old "1. <Well, not that I slept very well, but I've just been lounging around all day.>"
    new "1. <Bueno, no es que haya dormido muy bien, pero llevo todo el día tirad[letra] por ahí.>"

    # game/beyond the bet/day6dlc.rpy:2460
    old "1. <No? How did I look?>"
    new "1. <¿No? ¿Cómo me veía?>"

    # game/beyond the bet/day6dlc.rpy:2467
    old "1. <Me? [pretty!c] and flustered?>"
    new "1. <¿Yo? ¿[pretty!c] y sonrojad[letra]?>"

    # game/beyond the bet/day6dlc.rpy:2470
    old "1. <Hmmm.>"
    new "1. <Mmm.>"

    # game/beyond the bet/day6dlc.rpy:2473
    old "1. <Are you sure you're not thinking of yourself?>"
    new "1. <¿Seguro que no estás pensando en ti mismo?>"

    # game/beyond the bet/day6dlc.rpy:2478
    old "1. <I would NEVER be sarcastic to you, Grim.>"
    new "1. <JAMÁS sería sarcástic[letra] contigo, Parca.>"

    # game/beyond the bet/day6dlc.rpy:2483
    old "1. <I HAVE been practicing my jokes.>"
    new "1. <SÍ he estado practicando mis chistes.>"

    # game/beyond the bet/day6dlc.rpy:2486
    old "1. <Knock knock.>"
    new "1. <Toc toc.>"

    # game/beyond the bet/day6dlc.rpy:2490
    old "1. <KNOCK KNOCK.>"
    new "1. <TOC TOC.>"

    # game/beyond the bet/day6dlc.rpy:2494
    old "1. <The Grim Reaper.>"
    new "1. <La Parca.>"

    # game/beyond the bet/day6dlc.rpy:2498
    old "1. <Okay, I actually hadn't thought the joke this far through.>"
    new "1. <Okey, en realidad no había pensado el chiste hasta aquí.>"

    # game/beyond the bet/day6dlc.rpy:2501
    old "1. <I guess we'll never know.>"
    new "1. <Supongo que nunca lo sabremos.>"

    # game/beyond the bet/day6dlc.rpy:2505
    old "1. <You finish the joke, then.>"
    new "1. <Termina tú el chiste, entonces.>"

    # game/beyond the bet/day6dlc.rpy:2508
    old "1. <Lemme know when you work it out.>"
    new "1. <Avísame cuando lo resuelvas.>"

    # game/beyond the bet/day6dlc.rpy:2512
    old "1. <I'll be waiting :D>"
    new "1. <Estaré esperando :D>"

    # game/beyond the bet/day6dlc.rpy:2516
    old "2. <I can show you something dripping.>"
    new "2. <Puedo mostrarte algo que gotea.>"

    # game/beyond the bet/day6dlc.rpy:2520
    old "1. <Take a guess.>"
    new "1. <Adivina.>"

    # game/beyond the bet/day6dlc.rpy:2524
    old "1. <And if it was?>"
    new "1. <¿Y si lo fuera?>"

    # game/beyond the bet/day6dlc.rpy:2528
    old "1. <I think you already know what I mean, so no use in saying it ;D>"
    new "1. <Creo que ya sabes a qué me refiero, así que no hace falta decirlo ;D>"

    # game/beyond the bet/day6dlc.rpy:2530
    old "2. <I mean my nose, of course.>"
    new "2. <Me refiero a mi nariz, claro.>"

    # game/beyond the bet/day6dlc.rpy:2533
    old "1. <Aaargh, I hate being sick.>"
    new "1. <Aaargh, odio estar enferm[letra].>"

    # game/beyond the bet/day6dlc.rpy:2546
    old "1. <You sound so dirty right now.>"
    new "1. <Suenas muy atrevido ahora mismo.>"

    # game/beyond the bet/day6dlc.rpy:2554
    old "1. <I still don't feel like you've {i}'seen me in my entirety'{/i}.>"
    new "1. <Sigo sin sentir que me hayas {i}'visto por completo'{/i}.>"

    # game/beyond the bet/day6dlc.rpy:2557
    old "1. <Trust me, there's plenty more to see ;)>"
    new "1. <Créeme, hay mucho más que ver ;)>"

    # game/beyond the bet/day6dlc.rpy:2560
    old "2. <Pretty sure you couldn't see my whole body through a window, Grimmy.>"
    new "2. <Estoy bastante segur[letra] de que no podrías verme todo el cuerpo a través de una ventana, Parquita.>"

    # game/beyond the bet/day6dlc.rpy:2563
    old "1. <But I don't mind you looking.>"
    new "1. <Pero no me importa que mires.>"

    # game/beyond the bet/day6dlc.rpy:2566
    old "1. <Actually, I kinda feel like encouraging it.>"
    new "1. <De hecho, casi me dan ganas de animarte.>"

    # game/beyond the bet/day6dlc.rpy:2570
    old "1. <It's not too bad, actually.>"
    new "1. <En realidad, no está tan mal.>"

    # game/beyond the bet/day6dlc.rpy:2573
    old "1. <Being able to steal Death's gaze.>"
    new "1. <Poder robarle la mirada a la Muerte.>"

    # game/beyond the bet/day6dlc.rpy:2576
    old "1. <I bet not everyone can do that.>"
    new "1. <Apuesto a que no cualquiera puede hacerlo.>"

    # game/beyond the bet/day6dlc.rpy:2581
    old "1. <Aren't you lucky that I'm one of the ones who likes it.>"
    new "1. <¿No tienes suerte de que yo sea de quienes lo disfrutan?>"

    # game/beyond the bet/day6dlc.rpy:2588
    old "2. <I'm bleeding out of my eyes.>"
    new "2. <Estoy sangrando por los ojos.>"

    # game/beyond the bet/day6dlc.rpy:2591
    old "1. <And my nose.>"
    new "1. <Y por la nariz.>"

    # game/beyond the bet/day6dlc.rpy:2594
    old "1. <Maybe my ears?>"
    new "1. <¿Quizá por las orejas?>"

    # game/beyond the bet/day6dlc.rpy:2611
    old "1. <You love my personality.>"
    new "1. <Te encanta mi personalidad.>"

    # game/beyond the bet/day6dlc.rpy:2649
    old "1. <Ahaha... oh, uhhh... this is awkward.>"
    new "1. <Ajaja... oh, eh... esto es incómodo.>"

    # game/beyond the bet/day6dlc.rpy:2660
    old "1. <...Sorry, I didn't think you'd take me seriously...>"
    new "1. <...Perdón, no pensé que me tomarías en serio...>"

    # game/beyond the bet/day6dlc.rpy:2662
    old "1. <I was obviously joking.>"
    new "1. <Obviamente estaba bromeando.>"

    # game/beyond the bet/day6dlc.rpy:2669
    old "2. <Uh oh. I'm scared now.>"
    new "2. <Uy, uy. Ahora sí tengo miedo.>"

    # game/beyond the bet/day6dlc.rpy:2671
    old "1. <Am I going to be punished by the big scary reaper?>"
    new "1. <¿Me va a castigar la gran parca aterradora?>"

    # game/beyond the bet/day6dlc.rpy:2680
    old "1. <But it could be.>"
    new "1. <Pero podría ser.>"

    # game/beyond the bet/day6dlc.rpy:2685
    old "1. <Okay, okay, fine. I surrender.>"
    new "1. <Okey, okey, está bien. Me rindo.>"

    # game/beyond the bet/day6dlc.rpy:2688
    old "1. <We can always come back to this later, eh?>"
    new "1. <Siempre podemos volver a esto más tarde, ¿eh?>"

    # game/beyond the bet/day6dlc.rpy:2695
    old "2. <A topic for another time, then.>"
    new "2. <Un tema para otra ocasión, entonces.>"

    # game/beyond the bet/day6dlc.rpy:2704
    old "1. <Well, I am actually sick.>"
    new "1. <Bueno, sí estoy enferm[letra].>"

    # game/beyond the bet/day6dlc.rpy:2707
    old "1. <But I'm not bleeding out of every orifice.>"
    new "1. <Pero no estoy sangrando por todos los orificios.>"

    # game/beyond the bet/day6dlc.rpy:2710
    old "1. <And I am tired, despite doing nothing.>"
    new "1. <Y estoy cansad[letra], a pesar de no hacer nada.>"

    # game/beyond the bet/day6dlc.rpy:2737
    old "1. <Speaking of Azrael, where is he?>"
    new "1. <Hablando de Azrael, ¿dónde está?>"

    # game/beyond the bet/day6dlc.rpy:2742
    old "1. <Can you bring him over? I wanna see his cute lil face.>"
    new "1. <¿Puedes traerlo? Quiero ver su linda carita.>"

    # game/beyond the bet/day6dlc.rpy:2750
    old "1. <Pretty pleaaaase?>"
    new "1. <¿Por favoooor?>"

    # game/beyond the bet/day6dlc.rpy:2754
    old "1. <Can he not rest in your arms?>"
    new "1. <¿No puede descansar en tus brazos?>"

    # game/beyond the bet/day6dlc.rpy:2757
    old "1. <I wouldn't mind resting in your arms.>"
    new "1. <A mí no me importaría descansar en tus brazos.>"

    # game/beyond the bet/day6dlc.rpy:2762
    old "1. <Then how about my head against your chest?>"
    new "1. <¿Y qué tal mi cabeza contra tu pecho?>"

    # game/beyond the bet/day6dlc.rpy:2767
    old "1. <It looks pretty firm and supportive.>"
    new "1. <Se ve bastante firme y cómodo.>"

    # game/beyond the bet/day6dlc.rpy:2770
    old "1. <And while you hold me to your chest, I'll cuddle Az so he doesn't feel left out.>"
    new "1. <Y mientras me sostienes contra tu pecho, abrazaré a Az para que no se sienta excluido.>"

    # game/beyond the bet/day6dlc.rpy:2777
    old "1. <Well, when I come to visit I'll snuggle with him!>"
    new "1. <Bueno, ¡cuando vaya de visita me acurrucaré con él!>"

    # game/beyond the bet/day6dlc.rpy:2780
    old "1. <Then we won't be far apart at all.>"
    new "1. <Así no estaremos nada lejos.>"

    # game/beyond the bet/day6dlc.rpy:2790
    old "2. <I think he'd enjoy that.>"
    new "2. <Creo que le gustaría.>"

    # game/beyond the bet/day6dlc.rpy:2797
    old "1. <And we both know you snuggle him at night.>"
    new "1. <Y los dos sabemos que lo abrazas por las noches.>"

    # game/beyond the bet/day6dlc.rpy:2800
    old "1. <I like that you have a soft side.>"
    new "1. <Me gusta que tengas un lado tierno.>"

    # game/beyond the bet/day6dlc.rpy:2803
    old "1. <You act all tough and 'scary', but I know it's all a front.>"
    new "1. <Te haces el rudo y 'aterrador', pero sé que todo es una fachada.>"

    # game/beyond the bet/day6dlc.rpy:2812
    old "1. <Ah, whoops.>"
    new "1. <Ah, vaya.>"

    # game/beyond the bet/day6dlc.rpy:2815
    old "1. <I'll try my hardest to act more scared.>"
    new "1. <Haré todo lo posible por parecer más asustad[letra].>"

    # game/beyond the bet/day6dlc.rpy:2817
    old "1. <Let's practice.>"
    new "1. <Practiquemos.>"

    # game/beyond the bet/day6dlc.rpy:2824
    old "1. <AAAAAAAAAAAAAH!>"
    new "1. <¡AAAAAAAAAAAAAH!>"

    # game/beyond the bet/day6dlc.rpy:2826
    old "2. <Aaah.>"
    new "2. <Aaah.>"

    # game/beyond the bet/day6dlc.rpy:2829
    old "3. <Ah.>"
    new "3. <Ah.>"

    # game/beyond the bet/day6dlc.rpy:2833
    old "1. <Hehe.>"
    new "1. <Jeje.>"

    # game/beyond the bet/day6dlc.rpy:2839
    old "2. <I think you're more afraid of me than I am of you.>"
    new "2. <Creo que tú me tienes más miedo a mí que yo a ti.>"

    # game/beyond the bet/day6dlc.rpy:2843
    old "1. <Absolutely terrified.>"
    new "1. <Absolutamente aterrado.>"

    # game/beyond the bet/day6dlc.rpy:2848
    old "1. <And yet here we are.>"
    new "1. <Y sin embargo, aquí estamos.>"

    # game/beyond the bet/day6dlc.rpy:2851
    old "1. <You're scared of how easily I make you swoon \nand lose control.>"
    new "1. <Te asusta lo fácil que hago que te derritas y pierdas el control.>"

    # game/beyond the bet/day6dlc.rpy:2856
    old "1. <It's okay. You can let go of the reins, little reaper.>"
    new "1. <Está bien. Puedes soltar las riendas, parquita.>"

    # game/beyond the bet/day6dlc.rpy:2859
    old "1. <Maybe you need to take a little leap of faith.>"
    new "1. <Quizá necesites dar un pequeño salto de fe.>"

    # game/beyond the bet/day6dlc.rpy:2883
    old "1. <Oh? What's that?>"
    new "1. <¿Ah, sí? ¿Cómo?>"

    # game/beyond the bet/day6dlc.rpy:2886
    old "1. <Speak up, Grim.>"
    new "1. <Habla más fuerte, Parca.>"

    # game/beyond the bet/day6dlc.rpy:2889
    old "1. <I can't hear you when you're mumbling.>"
    new "1. <No te oigo cuando murmuras.>"

    # game/beyond the bet/day6dlc.rpy:2906
    old "1. <Oh.>"
    new "1. <Oh.>"

    # game/beyond the bet/day6dlc.rpy:2909
    old "1. <Do I?>"
    new "1. <¿Eso crees?>"

    # game/beyond the bet/day6dlc.rpy:2930
    old "1. <Well, I don't mind.>"
    new "1. <Bueno, no me importa.>"

    # game/beyond the bet/day6dlc.rpy:2933
    old "1. <It's nice when you call me cute.>"
    new "1. <Es agradable que me llames lind[letra].>"

    # game/beyond the bet/day6dlc.rpy:2953
    old "1. <Quite easily, actually.>"
    new "1. <Pues muy fácil, en realidad.>"

    # game/beyond the bet/day6dlc.rpy:2955
    old "1. <I'm sure I'll be fine by tomorrow.>"
    new "1. <Seguro que mañana estaré bien.>"

    # game/beyond the bet/day6dlc.rpy:2958
    old "1. <Kinda lame to spend my second last day \non Earth in bed, huh?>"
    new "1. <Qué patético pasar mi penúltimo día en la Tierra en la cama, ¿no?>"

    # game/beyond the bet/day6dlc.rpy:2960
    old "2. <I didn't have much choice in the matter.>"
    new "2. <No tuve muchas opciones.>"

    # game/beyond the bet/day6dlc.rpy:2962
    old "1. <It's not like I saw an ad for 'sick people near you' \nand rushed on over.>"
    new "1. <No es que haya visto un anuncio de 'enfermos cerca de ti' y haya venido corriendo.>"

    # game/beyond the bet/day6dlc.rpy:2965
    old "1. <It just happened.>"
    new "1. <Simplemente pasó.>"

    # game/beyond the bet/day6dlc.rpy:2968
    old "1. <Why are you making such a big deal about it, though?>"
    new "1. <¿Por qué le das tanta importancia, a todo esto?>"

    # game/beyond the bet/day6dlc.rpy:2971
    old "1. <Everyone gets sick.>"
    new "1. <Todo el mundo se enferma.>"

    # game/beyond the bet/day6dlc.rpy:2976
    old "1. <Like, ever?>"
    new "1. <¿O sea, jamás?>"

    # game/beyond the bet/day6dlc.rpy:2982
    old "1. <What about reaper sicknesses?>"
    new "1. <¿Y las enfermedades de las parcas?>"

    # game/beyond the bet/day6dlc.rpy:2995
    old "1. <That seems kinda worse than a cold.>"
    new "1. <Eso parece peor que un resfriado.>"

    # game/beyond the bet/day6dlc.rpy:3003
    old "1. <Hey!>"
    new "1. <¡Oye!>"

    # game/beyond the bet/day6dlc.rpy:3005
    old "2. <Oi...>"
    new "2. <Oye...>"

    # game/beyond the bet/day6dlc.rpy:3010
    old "1. <I'm sure there IS a reason, I just don't know it!>"
    new "1. <¡Estoy segur[letra] de que SÍ hay una razón, solo que no la sé!>"

    # game/beyond the bet/day6dlc.rpy:3019
    old "1. <Quite easily, I imagine.>"
    new "1. <Pues muy fácil, imagino.>"

    # game/beyond the bet/day6dlc.rpy:3021
    old "2. <Wait, doesn't that just make it simpler for you?>"
    new "2. <Espera, ¿eso no te lo pone más fácil?>"

    # game/beyond the bet/day6dlc.rpy:3027
    old "2. <I hate when you're right...>"
    new "2. <Odio cuando tienes razón...>"

    # game/beyond the bet/day6dlc.rpy:3033
    old "1. <Hah!>"
    new "1. <¡Ja!>"

    # game/beyond the bet/day6dlc.rpy:3036
    old "1. <You were gonna say always, weren't you?>"
    new "1. <Ibas a decir siempre, ¿verdad?>"

    # game/beyond the bet/day6dlc.rpy:3039
    old "1. <But that would've been a lie.>"
    new "1. <Pero eso habría sido una mentira.>"

    # game/beyond the bet/day6dlc.rpy:3044
    old "1. <It's more like 'rarely'.>"
    new "1. <Es más bien 'rara vez'.>"

    # game/beyond the bet/day6dlc.rpy:3053
    old "1. <Well, not much you can do about it, buddy.>"
    new "1. <Bueno, no hay mucho que puedas hacer al respecto, amigo.>"

    # game/beyond the bet/day6dlc.rpy:3055
    old "2. <I don't think your acceptance makes a difference.>"
    new "2. <No creo que tu aceptación cambie nada.>"

    # game/beyond the bet/day6dlc.rpy:3058
    old "1. <You can't exactly pull the sickness from my body, \ncan you?>"
    new "1. <No es que puedas sacarme la enfermedad del cuerpo, ¿verdad?>"

    # game/beyond the bet/day6dlc.rpy:3063
    old "1. <Hey, I never said anything about sucking. \nPulling, Casper. Pulling.>"
    new "1. <Oye, yo nunca dije nada de succionar. Sacar, Casper. Sacar.>"

    # game/beyond the bet/day6dlc.rpy:3066
    old "1. <But that's obviously not actually possible.>"
    new "1. <Pero es obvio que eso no es posible de verdad.>"

    # game/beyond the bet/day6dlc.rpy:3068
    old "2. <Too bad you can't really take it away.>"
    new "2. <Qué lástima que no puedas quitármela de verdad.>"

    # game/beyond the bet/day6dlc.rpy:3071
    old "1. <Maybe humans will evolve and become immune to being sick as well one day.>"
    new "1. <Quizá algún día los humanos evolucionen y se vuelvan inmunes a enfermarse también.>"

    # game/beyond the bet/day6dlc.rpy:3081
    old "1. <Huh. You live forever, right? Is the very first \nreaper still around?>"
    new "1. <Vaya. Tú vives para siempre, ¿no? ¿La primerísima parca sigue por ahí?>"

    # game/beyond the bet/day6dlc.rpy:3083
    old "1. <Who was it?>"
    new "1. <¿Quién fue?>"

    # game/beyond the bet/day6dlc.rpy:3091
    old "1. <Why wouldn't it be? You didn't just all \nappear out of nowhere.>"
    new "1. <¿Por qué no lo estaría? No aparecieron de la nada, sin más.>"

    # game/beyond the bet/day6dlc.rpy:3094
    old "1. <Right?>"
    new "1. <¿No?>"

    # game/beyond the bet/day6dlc.rpy:3100
    old "1. <Sounds like a mystery waiting to be solved to me.>"
    new "1. <A mí me suena a un misterio esperando ser resuelto.>"

    # game/beyond the bet/day6dlc.rpy:3104
    old "2. <Do you know the first reaper?>"
    new "2. <¿Conoces a la primera parca?>"

    # game/beyond the bet/day6dlc.rpy:3106
    old "1. <Are they your Boss?>"
    new "1. <¿Es tu jefe?>"

    # game/beyond the bet/day6dlc.rpy:3109
    old "1. <Or maybe they're retired? I'd retire if it was me.>"
    new "1. <¿O quizá se jubiló? Yo me jubilaría si fuera yo.>"

    # game/beyond the bet/day6dlc.rpy:3114
    old "1. <Wait, can you actually retire?>"
    new "1. <Espera, ¿de verdad puedes jubilarte?>"

    # game/beyond the bet/day6dlc.rpy:3123
    old "1. <It sounds lonely.>"
    new "1. <Suena solitario.>"

    # game/beyond the bet/day6dlc.rpy:3129
    old "2. <Soul-y, hehe.>"
    new "2. <Almamente, jeje>"

    # game/beyond the bet/day6dlc.rpy:3133
    old "1. <Not a bad pun, ey?>"
    new "1. <No está mal el chiste, ¿eh?>"

    # game/beyond the bet/day6dlc.rpy:3137
    old "2. <Take a walk along our soul bridge and chase it \naway for me.>"
    new "2. <Date un paseo por nuestro puente de almas y ahuyéntala por mí.>"

    # game/beyond the bet/day6dlc.rpy:3141
    old "1. <Is it not?>"
    new "1. <¿No lo es?>"

    # game/beyond the bet/day6dlc.rpy:3143
    old "2. <Are you suuure?>"
    new "2. <¿Estás seguuuro?>"

    # game/beyond the bet/day6dlc.rpy:3147
    old "1. <Have you tried?>"
    new "1. <¿Lo has intentado?>"

    # game/beyond the bet/day6dlc.rpy:3152
    old "1. <Then you can't be 100 percent certain, can you?>"
    new "1. <Entonces no puedes estar 100 por ciento seguro, ¿o sí?>"

    # game/beyond the bet/day6dlc.rpy:3155
    old "1. <Nothing in life is certain, Casper.>"
    new "1. <Nada en la vida es seguro, Casper.>"

    # game/beyond the bet/day6dlc.rpy:3163
    old "1. <Just shoo the ickies off.>"
    new "1. <Solo espanta a los bichitos.>"

    # game/beyond the bet/day6dlc.rpy:3169
    old "1. <Ugh... what CAN you do, then?>"
    new "1. <Ugh... ¿qué PUEDES hacer, entonces?>"

    # game/beyond the bet/day6dlc.rpy:3175
    old "1. <Fine, fine. Then...>"
    new "1. <Bien, bien. Entonces...>"

    # game/beyond the bet/day6dlc.rpy:3180
    old "1. <Forget me being sick for a second, okay?>"
    new "1. <Olvida por un segundo que estoy enferm[letra], ¿okey?>"

    # game/beyond the bet/day6dlc.rpy:3183
    old "1. <I have a question.>"
    new "1. <Tengo una pregunta.>"

    # game/beyond the bet/day6dlc.rpy:3188
    old "1. <I really like your name.>"
    new "1. <Me gusta mucho tu nombre.>"

    # game/beyond the bet/day6dlc.rpy:3199
    old "1. <Shh.>"
    new "1. <Shh.>"

    # game/beyond the bet/day6dlc.rpy:3202
    old "1. <I'm getting to it.>"
    new "1. <Ya voy a eso.>"

    # game/beyond the bet/day6dlc.rpy:3205
    old "1. <How did you get your name?>"
    new "1. <¿Cómo conseguiste tu nombre?>"

    # game/beyond the bet/day6dlc.rpy:3209
    old "1. <Do you have reaper parents who gave it to you?>"
    new "1. <¿Tienes padres parca que te lo dieron?>"

    # game/beyond the bet/day6dlc.rpy:3219
    old "1. <Wait, you don't have parents?>"
    new "1. <Espera, ¿no tienes padres?>"

    # game/beyond the bet/day6dlc.rpy:3222
    old "1. <What, did you just spring into existence one day?>"
    new "1. <¿Qué, simplemente apareciste un día de la nada?>"

    # game/beyond the bet/day6dlc.rpy:3227
    old "1. <Huh???>"
    new "1. <¿¿¿Eh???>"

    # game/beyond the bet/day6dlc.rpy:3242
    old "1. <But you had to be created somehow!>"
    new "1. <¡Pero tuvieron que crearte de alguna manera!>"

    # game/beyond the bet/day6dlc.rpy:3249
    old "1. <So, how'd you get your name?>"
    new "1. <Entonces, ¿cómo conseguiste tu nombre?>"

    # game/beyond the bet/day6dlc.rpy:3265
    old "1. <You already broke rules telling me your name, \ndidn't you?>"
    new "1. <Ya rompiste reglas al decirme tu nombre, ¿no?>"

    # game/beyond the bet/day6dlc.rpy:3278
    old "1. <I like it.>"
    new "1. <Me gusta.>"

    # game/beyond the bet/day6dlc.rpy:3284
    old "1. <Do you enjoy when I say your name?>"
    new "1. <¿Te gusta cuando digo tu nombre?>"

    # game/beyond the bet/day6dlc.rpy:3292
    old "1. <Caaaaasper.>"
    new "1. <Caaaaasper.>"

    # game/beyond the bet/day6dlc.rpy:3297
    old "1. <Steve?>"
    new "1. <¿Steve?>"

    # game/beyond the bet/day6dlc.rpy:3307
    old "1. <Yeah, you're definitely a Casper.>"
    new "1. <Sí, definitivamente eres un Casper.>"

    # game/beyond the bet/day6dlc.rpy:3311
    old "2. <You know what your name would sound great with? My last name.>"
    new "2. <¿Sabes con qué quedaría genial tu nombre? Con mi apellido.>"

    # game/beyond the bet/day6dlc.rpy:3315
    old "1. <Casper [playerlastname].>"
    new "1. <Casper [playerlastname].>"

    # game/beyond the bet/day6dlc.rpy:3318
    old "1. <Isn't that cute?>"
    new "1. <¿A que es lindo?>"

    # game/beyond the bet/day6dlc.rpy:3323
    old "1. <Well, we could just get married.>"
    new "1. <Bueno, podríamos casarnos sin más.>"

    # game/beyond the bet/day6dlc.rpy:3334
    old "1. <It's on my bucket list.>"
    new "1. <Está en mi lista de cosas por hacer.>"

    # game/beyond the bet/day6dlc.rpy:3339
    old "1. <Not really.>"
    new "1. <La verdad es que no.>"

    # game/beyond the bet/day6dlc.rpy:3342
    old "1. <There's only you.>"
    new "1. <Solo estás tú.>"

    # game/beyond the bet/day6dlc.rpy:3345
    old "2. <I hadn't thought of marriage before, but I \nwouldn't mind doing it.>"
    new "2. <Antes no había pensado en el matrimonio, pero no me importaría hacerlo.>"

    # game/beyond the bet/day6dlc.rpy:3348
    old "1. <If it was with you, that is.>"
    new "1. <Si fuera contigo, claro.>"

    # game/beyond the bet/day6dlc.rpy:3351
    old "1. <I don't know if anyone else is to my \nstandards anymore.>"
    new "1. <Ya no sé si alguien más está a la altura de mis estándares.>"

    # game/beyond the bet/day6dlc.rpy:3366
    old "1. <Making you fall hopelessly and completely in \nlove with me?>"
    new "1. <¿Hacer que te enamores perdidamente y por completo de mí?>"

    # game/beyond the bet/day6dlc.rpy:3376
    old "1. <That's one way to get out of our bet, hey?>"
    new "1. <Esa es una forma de salir de nuestra apuesta, ¿eh?>"

    # game/beyond the bet/day6dlc.rpy:3383
    old "1. <Can't you just lie and say you took it?>"
    new "1. <¿No puedes simplemente mentir y decir que la tomaste?>"

    # game/beyond the bet/day6dlc.rpy:3392
    old "1. <To be fair, you're also asking me to die.>"
    new "1. <Para ser just[letra], tú también me estás pidiendo que muera.>"

    # game/beyond the bet/day6dlc.rpy:3398
    old "1. <It seems a little unfair.>"
    new "1. <Me parece un poco injusto.>"

    # game/beyond the bet/day6dlc.rpy:3401
    old "1. <I like talking to you, Casper.>"
    new "1. <Me gusta hablar contigo, Casper.>"

    # game/beyond the bet/day6dlc.rpy:3406
    old "1. <It's not fair that has to be over so quickly.>"
    new "1. <No es justo que tenga que acabar tan pronto.>"

    # game/beyond the bet/day6dlc.rpy:3409
    old "1. <And I know, I know, life is unfair, yadda yadda.>"
    new "1. <Y lo sé, lo sé, la vida es injusta, bla, bla.>"

    # game/beyond the bet/day6dlc.rpy:3412
    old "1. <But this sucks.>"
    new "1. <Pero esto es un asco.>"

    # game/beyond the bet/day6dlc.rpy:3437
    old "1. <I know.>"
    new "1. <Lo sé.>"

    # game/beyond the bet/day6dlc.rpy:3439
    old "2. <Yeah...>"
    new "2. <Sí...>"

    # game/beyond the bet/day6dlc.rpy:3441
    old "3. <I understand.>"
    new "3. <Lo entiendo.>"

    # game/beyond the bet/day6dlc.rpy:3444
    old "1. <I actually feel sorry for you.>"
    new "1. <En realidad siento lástima por ti.>"

    # game/beyond the bet/day6dlc.rpy:3448
    old "1. <You're stuck where you are.>"
    new "1. <Estás atrapado donde estás.>"

    # game/beyond the bet/day6dlc.rpy:3451
    old "1. <Sure, us 'mortals' live, and die, and all that.>"
    new "1. <Claro, nosotros los 'mortales' vivimos, morimos y todo eso.>"

    # game/beyond the bet/day6dlc.rpy:3454
    old "1. <But we're capable of change.>"
    new "1. <Pero somos capaces de cambiar.>"

    # game/beyond the bet/day6dlc.rpy:3457
    old "1. <We're capable of making decisions that affect our lives.>"
    new "1. <Somos capaces de tomar decisiones que afectan nuestras vidas.>"

    # game/beyond the bet/day6dlc.rpy:3460
    old "1. <It feels like you can't do anything but keep existing, doing the same thing day in and out.>"
    new "1. <Parece que no puedes hacer otra cosa que seguir existiendo, haciendo lo mismo día tras día.>"

    # game/beyond the bet/day6dlc.rpy:3471
    old "1. <Huh?>"
    new "1. <¿Eh?>"

    # game/beyond the bet/day6dlc.rpy:3492
    old "2. <Grimmy?>"
    new "2. <¿Parquita?>"

    # game/beyond the bet/day6dlc.rpy:3495
    old "1. <Where'd you go?>"
    new "1. <¿Adónde fuiste?>"

    # game/beyond the bet/day6dlc.rpy:3498
    old "1. <Helloooooooooo?>"
    new "1. <¿Holaaaaaaaaaa?>"

    # game/beyond the bet/day6dlc.rpy:3555
    old "1. <Casper?!>"
    new "1. <¡¿Casper?!>"

    # game/beyond the bet/day6dlc.rpy:3564
    old "1. <The Grim Reaper's in my apartment.>"
    new "1. <La Parca está en mi apartamento.>"

    # game/beyond the bet/day6dlc.rpy:3567
    old "1. <Wait, are you here for my soul?>"
    new "1. <Espera, ¿vienes por mi alma?>"

    # game/beyond the bet/day6dlc.rpy:3575
    old "1. <Are you calling me ugly?>"
    new "1. <¿Me estás llamando fe[letra]?>"

    # game/beyond the bet/day6dlc.rpy:3577
    old "2. <Wow, I look that bad?>"
    new "2. <Wow, ¿tan mal me veo?>"

    # game/beyond the bet/day6dlc.rpy:3603
    old "1. <I wasn't really feeling like->"
    new "1. <En realidad no tenía ganas de->"

    # game/beyond the bet/day6dlc.rpy:3623
    old "2. <I'll be fine.>"
    new "2. <Estaré bien.>"

    # game/beyond the bet/day6dlc.rpy:3633
    old "1. <Yeah, I haven't eaten yet.>"
    new "1. <Sí, todavía no he comido.>"

    # game/beyond the bet/day6dlc.rpy:3638
    old "1. <I don't like how you call it a 'mortal meal'.>"
    new "1. <No me gusta cómo lo llamas 'comida de mortales'.>"

    # game/beyond the bet/day6dlc.rpy:3642
    old "1. <Is that any different to what YOU eat?>"
    new "1. <¿Es acaso distinto de lo que comes TÚ?>"

    # game/beyond the bet/day6dlc.rpy:3650
    old "1. <Alright...>"
    new "1. <Muy bien...>"

    # game/beyond the bet/day6dlc.rpy:3671
    old "1. <What the hell was all of that?>"
    new "1. <¿Qué demonios fue todo eso?>"

    # game/beyond the bet/day6dlc.rpy:3673
    old "2. <I'm a bit scared to ask...>"
    new "2. <Me da un poco de miedo preguntar...>"

    # game/beyond the bet/day6dlc.rpy:3675
    old "1. <But what was all of that?>"
    new "1. <Pero ¿qué fue todo eso?>"

    # game/beyond the bet/day6dlc.rpy:3680
    old "1. <The banging and clattering and stuff!>"
    new "1. <¡Los golpes y el traqueteo y todo eso!>"

    # game/beyond the bet/day6dlc.rpy:3686
    old "1. <It's a room! Not a beast!>"
    new "1. <¡Es una habitación! ¡No una bestia!>"

    # game/beyond the bet/day6dlc.rpy:3689
    old "1. <Is there any kitchen left?>"
    new "1. <¿Queda algo de cocina?>"

    # game/beyond the bet/day6dlc.rpy:3696
    old "1. <The worst part is knowing you can't lie...>"
    new "1. <Lo peor es saber que no puedes mentir...>"

    # game/beyond the bet/day6dlc.rpy:3699
    old "2. <Right, right... just one...>"
    new "2. <Ya, ya... solo uno...>"

    # game/beyond the bet/day6dlc.rpy:3703
    old "1. <I'm sure it was terrified.>"
    new "1. <Seguro que estaba aterrorizado.>"

    # game/beyond the bet/day6dlc.rpy:3706
    old "3. <...My fire alarm needs new batteries, then.>"
    new "3. <...Entonces mi alarma de incendios necesita pilas nuevas.>"

    # game/beyond the bet/day6dlc.rpy:3711
    old "1. <But it didn't go off when you started a fire.>"
    new "1. <Pero no sonó cuando provocaste un incendio.>"

    # game/beyond the bet/day6dlc.rpy:3716
    old "1. <You pulled it down...?>"
    new "1. <¿La quitaste...?>"

    # game/beyond the bet/day6dlc.rpy:3720
    old "1. <A precautionary measure would be leaving it up!>"
    new "1. <¡Una medida de precaución sería dejarla puesta!>"

    # game/beyond the bet/day6dlc.rpy:3725
    old "1. <You knew it was going to go off...>"
    new "1. <Sabías que iba a sonar...>"

    # game/beyond the bet/day6dlc.rpy:3734
    old "1. <That's true.>"
    new "1. <Eso es cierto.>"

    # game/beyond the bet/day6dlc.rpy:3769
    old "1. <Have you ever made this before, Casper?>"
    new "1. <¿Habías hecho esto antes, Casper?>"

    # game/beyond the bet/day6dlc.rpy:3776
    old "1. <They're perfect.>"
    new "1. <Están perfectos.>"

    # game/beyond the bet/day6dlc.rpy:3780
    old "2. <They're... quite charred.>"
    new "2. <Están... bastante carbonizados.>"

    # game/beyond the bet/day6dlc.rpy:3784
    old "1. <Haha... hahahaha...>"
    new "1. <Jaja... jajajaja...>"

    # game/beyond the bet/day6dlc.rpy:3787
    old "1. <Oh, Casper, you're so cute.>"
    new "1. <Ay, Casper, qué lindo eres.>"

    # game/beyond the bet/day6dlc.rpy:3790
    old "1. <They're perfect, really.>"
    new "1. <Están perfectos, de verdad.>"

    # game/beyond the bet/day6dlc.rpy:3795
    old "1. <My bad.>"
    new "1. <Mi error.>"

    # game/beyond the bet/day6dlc.rpy:3799
    old "1. <Thank you, Grimmy.>"
    new "1. <Gracias, Parquita.>"

    # game/beyond the bet/day6dlc.rpy:3806
    old "1. <The least?>"
    new "1. <¿Lo mínimo?>"

    # game/beyond the bet/day6dlc.rpy:3809
    old "1. <The least you could do was not come over, tuck me into bed, and feed me dinner.>"
    new "1. <Lo mínimo habría sido no venir, ni arroparme en la cama ni darme de cenar.>"

    # game/beyond the bet/day6dlc.rpy:3829
    old "1. <It was... interesting.>"
    new "1. <Fue... interesante.>"

    # game/beyond the bet/day6dlc.rpy:3831
    old "2. <The best pancakes I've ever had.>"
    new "2. <Los mejores panqueques que he probado.>"

    # game/beyond the bet/day6dlc.rpy:3833
    old "3. <Maybe you've missed your calling.>"
    new "3. <Quizá te equivocaste de vocación.>"

    # game/beyond the bet/day6dlc.rpy:3835
    old "1. <Chef Casper.>"
    new "1. <Chef Casper.>"

    # game/beyond the bet/day6dlc.rpy:3841
    old "1. <You've outdone yourself.>"
    new "1. <Te superaste a ti mismo.>"

    # game/beyond the bet/day6dlc.rpy:3847
    old "1. <You sure can, Casper Wasper.>"
    new "1. <Claro que puedes, Casper Wasper.>"

    # game/beyond the bet/day6dlc.rpy:3849
    old "2. <Somehow, I'm not surprised.>"
    new "2. <De algún modo, no me sorprende.>"

    # game/beyond the bet/day6dlc.rpy:3893
    old "1. <Some people say they feel a spark...>"
    new "1. <Algunos dicen que sienten una chispa...>"

    # game/beyond the bet/day6dlc.rpy:3895
    old "1. <I didn't think that happened literally...>"
    new "1. <No pensé que eso ocurriera literalmente...>"

    # game/beyond the bet/day6dlc.rpy:3902
    old "2. <What was that?>"
    new "2. <¿Qué fue eso?>"

    # game/beyond the bet/day6dlc.rpy:3923
    old "1. <Yes, Casper?>"
    new "1. <¿Sí, Casper?>"

    # game/beyond the bet/day6dlc.rpy:3929
    old "1. <{i}Reach out and take his hand.{/i}>"
    new "1. <{i}Extender la mano y tomar la suya.{/i}>"

    # game/beyond the bet/day6dlc.rpy:3932
    old "1. <Will you stay, instead?>"
    new "1. <¿Te quedarías conmigo, mejor?>"

    # game/beyond the bet/day6dlc.rpy:3934
    old "2. <Wait! Don't leave.>"
    new "2. <¡Espera! No te vayas.>"

    # game/beyond the bet/day6dlc.rpy:3936
    old "3. <Please don't...>"
    new "3. <Por favor no...>"

    # game/beyond the bet/day6dlc.rpy:3941
    old "1. <You know. I'm so sick.>"
    new "1. <Sabes. Estoy muy enferm[letra].>"

    # game/beyond the bet/day6dlc.rpy:3944
    old "1. <Who knows what will happen if you leave me?>"
    new "1. <¿Quién sabe qué pasará si me dejas?>"

    # game/beyond the bet/day6dlc.rpy:3948
    old "1. <Please?>"
    new "1. <¿Por favor?>"

    # game/beyond the bet/day6dlc.rpy:3955
    old "1. <I only have one bed, though.>"
    new "1. <Solo tengo una cama, eso sí.>"

    # game/beyond the bet/day6dlc.rpy:3960
    old "1. <Would you do it with me anyway?>"
    new "1. <¿Lo harías conmigo igualmente?>"

    # game/beyond the bet/day6dlc.rpy:3965
    old "1. <Yeah.>"
    new "1. <Sí.>"

    # game/beyond the bet/day6dlc.rpy:3971
    old "1. <I mean.>"
    new "1. <O sea.>"

    # game/beyond the bet/day6dlc.rpy:3974
    old "1. <Literally sleep.>"
    new "1. <Dormir, literalmente.>"

    # game/beyond the bet/day6dlc.rpy:3977
    old "1. <Snooze.>"
    new "1. <Echarse una siesta.>"

    # game/beyond the bet/day6dlc.rpy:3980
    old "1. <Catch some zzz's.>"
    new "1. <Pegar unos zzz.>"

    # game/beyond the bet/day6dlc.rpy:3994
    old "1. <I don't mind.>"
    new "1. <No me importa.>"

    # game/beyond the bet/day6dlc.rpy:3996
    old "1. <I... would be happy to have you here.>"
    new "1. <Yo... me alegraría de tenerte aquí.>"

    # game/beyond the bet/day6dlc.rpy:4000
    old "2. <It's a risk I'm willing to take.>"
    new "2. <Es un riesgo que estoy dispuest[letra] a correr.>"

    # game/beyond the bet/day6dlc.rpy:4003
    old "1. <I'm serious, though.>"
    new "1. <Hablo en serio, eso sí.>"

    # game/beyond the bet/day6dlc.rpy:4006
    old "3. <I like a challenge.>"
    new "3. <Me gustan los desafíos.>"

    # game/beyond the bet/day6dlc.rpy:4013
    old "1. <And I'm listening, I'm just... choosing for myself.>"
    new "1. <Y te escucho, solo que... elijo por mí mism[letra].>"

    # game/beyond the bet/day6dlc.rpy:4017
    old "1. <You said it yourself. I was meant to die a long time ago, right?>"
    new "1. <Tú mismo lo dijiste. Se suponía que debía haber muerto hace mucho, ¿no?>"

    # game/beyond the bet/day6dlc.rpy:4020
    old "1. <I think I lived all this extra time to meet you.>"
    new "1. <Creo que viví todo este tiempo extra para conocerte.>"

    # game/beyond the bet/day6dlc.rpy:4036
    old "1. <Do you ever wish things were different?>"
    new "1. <¿Alguna vez desearías que las cosas fueran diferentes?>"

    # game/beyond the bet/day6dlc.rpy:4046
    old "1. <Like what?>"
    new "1. <¿Como qué?>"

    # game/beyond the bet/day6dlc.rpy:4058
    old "1. <Why not do it?>"
    new "1. <¿Por qué no hacerlo?>"

    # game/beyond the bet/day6dlc.rpy:4064
    old "1. <What would you do if you were human?>"
    new "1. <¿Qué harías si fueras humano?>"

    # game/beyond the bet/day6dlc.rpy:4071
    old "1. <You've always been a little foolish, Casper.>"
    new "1. <Siempre has sido un poco insensato, Casper.>"

    # game/beyond the bet/day6dlc.rpy:4073
    old "2. <It's good to be foolish sometimes.>"
    new "2. <Está bien ser insensato a veces.>"

