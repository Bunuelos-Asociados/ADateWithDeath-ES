init python:

    def actualizar_nombres():
        global playername, playerstatus 
        
    # Si el idioma está en español Y el nombre todavía es el que viene por defecto
        if renpy.game.preferences.language == "es" and playername == "Soul#8129":
            playername = "Alma#8129"

    # Lo mismo para el estado
        if renpy.game.preferences.language == "es" and playerstatus == "Awaiting status...":
            playerstatus = "Esperando estado..."

    # Ejecutar después de cargar un save
    config.after_load_callbacks.append(lambda: actualizar_nombres())

   # Función para obtener textos dinámicos traducidos
    def textos_runner(runinstance):
        if renpy.game.preferences.language == "es":
            score_text = f"Esquivados: {runinstance.score}"
            speed_text = f"Velocidad: {runinstance.speed}"
        else:
            score_text = f"Dodged: {runinstance.score}"
            speed_text = f"Speed: {runinstance.speed}"
        return score_text, speed_text

# Ahora declaramos el screen fuera de init python
screen runner_screen(runinstance = runner_instance):
    modal True
    tag computer
    zorder 201
    use computer_screen
    add "gui/custom/computer/pong_base.png" at popup_transformtest
    text _("runner.exe") color "#000" align 0.33, 0.085 at popup_transformtest
    textbutton "x" action Hide("runner_screen", dissolve) align 0.865, 0.08  text_color "#000" text_hover_color "#3b36ff" at popup_transformtest
    hbox:
        viewport:
            area (560, 148, 1142, 725)
            add "pa_1" align 0.5, 0.5 at popup_transformtest
            add "pa_2" align 0.5, 0.5 at scrollbg1, popup_transformtest
            add "pa_3" align 0.5, 0.5 at scrollbg2, popup_transformtest
            add "pa_4" align 0.5, 0.5 at scrollbg3, popup_transformtest
            add "pa_5" align 0.5, 0.5 at scrollbg4, popup_transformtest

    key "K_SPACE" action Function(runinstance.jump)
    for i in runinstance.women:
        add i align .5,.5
    add runinstance align .5,.5 at logo_transform
    if runinstance.stage == "running":
        if not runinstance.caught:
            timer .1 repeat True action Function(runinstance.run)
            timer (random.random()*3)+1 repeat True action Function(runinstance.spawn)

        else:
            hbox:
                viewport:
                    area (560, 148, 1142, 725)
                    add "#000"

            vbox spacing 10:
                xalign 0.5
                yalign 0.5
                xanchor 0.5
                xpos 1130

                text _("Perdiste.") color "#fff" size 50 xalign 0.5
                textbutton _("Jugar de nuevo") action Function(runinstance.restart):
                    text_color "#fff"
                    text_hover_color "#3b36ff"
                    xalign 0.5
                textbutton _("Salir") action [Function(runinstance.restart), Hide("runner_screen", dissolve), Show("computer_screen")]:
                    text_color "#fff"
                    text_hover_color "#3b36ff"
                    xalign 0.5
        vbox:
            xalign 0.0
            yalign 0.78
            xanchor 0.0
            xpos 580
            text _("Esquivados: {score}").format(score=runinstance.score) at logo_transform
            text _("Velocidad: {speed}").format(speed=runinstance.speed) at logo_transform

    add "gui/custom/computer/games_hover.png" zoom 0.5 align 0.51, 0.961
    add "gui/custom/computer/active_app.png" align 0.513, 0.968





label before_main_menu:
    $ renpy.change_language("es")
    $ actualizar_nombres()
    return

