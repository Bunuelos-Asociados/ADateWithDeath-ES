init python:

    def actualizar_genero():

        global letra, arti, arti_2, buen
        global las, cara, pecador

        if she == __("she"):
            letra = "a"
            arti = "la"
            arti_2 = "una"
            buen = "buena"
            las = "Las"
            cara = "cara"
            pecador = "pecadora"

        elif she == __("he"):
            letra = "o"
            arti = "el"
            arti_2 = "un"
            buen = "bueno"
            las = "Los"
            cara = "rostro"
            pecador = "pecador"

        else:
            letra = "e"
            arti = "le"
            arti_2 = "une"
            buen = "buene"
            las = "Les"
            cara = "rostro"
            pecador = "pecadore"


    def actualizar_genero_pet():

        global letra_pet, arti_pet, arti_2_pet, buen_pet

        if pet_she == __("she"):
            letra_pet = "a"
            arti_pet = "la"
            arti_2_pet = "una"
            buen_pet = "buena"

        elif pet_she == __("he"):
            letra_pet = "o"
            arti_pet = "el"
            arti_2_pet = "un"
            buen_pet = "bueno"


init 1000 python:
    renpy.game.preferences.language = "Spanish"
    
label before_main_menu:
    $ actualizar_genero()
    $ actualizar_genero_pet()
    return

label after_load:
    $ actualizar_genero()
    $ actualizar_genero_pet()
    return
